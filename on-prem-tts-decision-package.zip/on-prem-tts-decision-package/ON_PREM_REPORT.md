# On-prem TTS report

4 vendors evaluated, 4 with saved audio, 6 exact model families and 9 verified decision recordings.

| Vendor | Status | Deployment | Exact models | Measured languages | License | Compute basis |
|---|---|---|---|---|---|---|
| Kokoro | audio complete | Local CPU batch | hexgrad/Kokoro-82M | hi-IN, en-US | Apache License 2.0 | Self-hosted compute |
| Maya Research | audio complete | Self-hosted GPU batch | maya-research/Veena, maya-research/maya1 | hi-IN, en-IN, hi-en | Apache License 2.0 for both published checkpoints | $0.74/hour observed Runpod creation rate |
| NVIDIA Speech NIM | hosted audio local deployment failed | Hosted Build API verified; self-hosted NIM attempted | magpie-tts-multilingual | hi-IN | Build model card: NVIDIA Open Model License; NGC listing: NVIDIA Community Model License | Hosted trial endpoint; self-hosted L40S observed at $1.09/hour and stopped after 29.5 minutes |
| Qwen3-TTS | english pass hindi lora failed | Self-hosted GPU batch | Qwen/Qwen3-TTS-12Hz-1.7B-Base, aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned | en-IN clone fixture, hi-IN failed qualification | Apache License 2.0 for the official model and community adapter; Rasa training data CC-BY-4.0 | $0.74/hour observed Runpod creation rate; Pod deleted after the bounded run |

## Kokoro

Hindi and US English batch synthesis observed; Indian English is not an eligible exact-locale result.

### License

Model: **Apache License 2.0**. Runtime: Kokoro/Misaki dependency licenses apply separately.

Permitted by the published model license

Self-hosting and modification permitted; retain the Apache license, notices and modification notices when redistributing covered material.

Sources: [1](https://huggingface.co/hexgrad/Kokoro-82M), [2](https://www.apache.org/licenses/LICENSE-2.0).

### hexgrad/Kokoro-82M

Revision: `Pinned artifacts; hashes retained in run records`. Hardware: Apple Silicon CPU.

- hi-IN · hf_alpha · 5.85 s · [audio](../ui/public/evidence/audio/5a4fe57acf1c491d86a9eda00932077a.wav)
- en-US · af_heart · 5.17 s · [audio](../ui/public/evidence/audio/a808945fd7d441ea8e980e39d6fefdd3.wav)

## Maya Research

Veena produced Hindi, Indian-English-request and mixed-text audio; Maya1 produced its English accent-control sample.

### License

Model: **Apache License 2.0 for both published checkpoints**. Runtime: Transformers, PyTorch and SNAC dependency licenses apply separately.

Permitted by the published checkpoint licenses

Self-hosting and modification permitted; retain the Apache license, notices and modification notices when redistributing covered material.

Sources: [1](https://huggingface.co/maya-research/Veena), [2](https://huggingface.co/maya-research/maya1), [3](https://www.apache.org/licenses/LICENSE-2.0).

### maya-research/Veena

Revision: `8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f`. Hardware: Runpod RTX 4090.

- hi-IN · kavya · 2.22 s · [audio](../ui/public/evidence/audio/veena-hi-IN-kavya.wav)
- en-IN · agastya · 2.82 s · [audio](../ui/public/evidence/audio/veena-en-IN-agastya.wav)
- hi-en · maitri · 2.05 s · [audio](../ui/public/evidence/audio/veena-hi-en-maitri.wav)
### maya-research/maya1

Revision: `21c682a0afef8c13a89b2512733c8bf5f0c52eb7`. Hardware: Runpod RTX 4090.

- en-IN · Indian English male, conversational, warm baritone, clear diction and natural call-centre pacing · 4.86 s · [audio](../ui/public/evidence/audio/maya1-en-IN.wav)

## NVIDIA Speech NIM

The hosted NVIDIA Build endpoint returned a valid Hindi WAV after live voice discovery in 1.62 seconds. The exact 1.10.0 self-hosted container did not become ready on Runpod L40S after 29.5 minutes; no local synthesis request was sent, and the Pod plus temporary registry credential were deleted.

### License

Model: **Build model card: NVIDIA Open Model License; NGC listing: NVIDIA Community Model License**. Runtime: NVIDIA Software License Agreement plus Product-Specific Terms for NVIDIA AI Products.

The current model card states commercial use is supported. The developer-program NIM entitlement is limited to internal evaluation, development and testing; production NIM deployment requires the applicable NVIDIA production entitlement unless a stated Community Product exception applies.

The Runpod pilot was an evaluation deployment. NVIDIA licenses the NIM runtime separately from the model. The Build model card and NGC catalog use different model-license labels, so production review must bind the chosen image digest/tag to its accompanying terms.

Sources: [1](https://build.nvidia.com/nvidia/magpie-tts-multilingual/modelcard), [2](https://catalog.ngc.nvidia.com/orgs/nim/nvidia/containers/magpie-tts-multilingual/latest), [3](https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-software-license-agreement/), [4](https://www.nvidia.com/en-us/agreements/enterprise-software/product-specific-terms-for-ai-products/), [5](https://docs.nvidia.com/ai-enterprise/planning-resource/licensing-guide/latest/licensing.html).

### magpie-tts-multilingual

Revision: `hosted Build function plus nvcr.io/nim/nvidia/magpie-tts-multilingual:1.10.0`. Hardware: NVIDIA hosted API; Runpod L40S self-hosted attempt.

- hi-IN · Magpie-Multilingual.HI-IN.Sofia · 4.46 s · [audio](../ui/public/evidence/audio/nvidia-magpie--hi-IN.wav)

## Qwen3-TTS

The official Base model produced a 4.56 s Indian-English clone fixture in 10.47 s (RTF 2.30); Scribe recovered every amount/date entity despite a raw NFC WER of 0.60 from number formatting and spelling. The Hindi LoRA hit the 512-token cap, returned 40.88 s for a short sentence, had RTF 3.05, and produced an empty Scribe transcript (WER/CER 1.00), so it failed. The released API has no playable chunk stream or request cancel; isolated-worker SIGTERM completed in 0.365 s and released GPU process memory. Hindi output peak was 0.0 dBFS with non-zero clipping.

### License

Model: **Apache License 2.0 for the official model and community adapter; Rasa training data CC-BY-4.0**. Runtime: qwen-tts, PEFT, PyTorch and Transformers dependency licenses apply separately.

The published model and adapter terms permit commercial use; preserve Apache notices and Rasa attribution.

Self-hosting is permitted. Archive the exact adapter, dataset and dependency notices before production.

Sources: [1](https://github.com/QwenLM/Qwen3-TTS), [2](https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-Base), [3](https://huggingface.co/aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned), [4](https://huggingface.co/datasets/ai4bharat/Rasa).

### Qwen/Qwen3-TTS-12Hz-1.7B-Base

Revision: `022e286b98fbec7e1e916cb940cdf532cd9f488e`. Hardware: Runpod RTX 4090, BF16, SDPA.

- en-IN · Voice clone from the saved Maya1 Indian-English-request reference · 4.56 s · [audio](../ui/public/evidence/audio/qwen3-base-en-IN.wav)
### aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned

Revision: `b84766274af71506758ccf45a9965bd1d934297b`. Hardware: Runpod RTX 4090, BF16, SDPA; corrected underlying-model PEFT load.

- hi-IN · Aguken Hindi female LoRA; failed bounded lexical qualification · 40.88 s · [audio](../ui/public/evidence/audio/qwen3-hindi-lora-hi-IN.wav)
