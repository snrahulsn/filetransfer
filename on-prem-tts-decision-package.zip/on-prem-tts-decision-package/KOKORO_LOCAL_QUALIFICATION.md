# Kokoro local CPU qualification — 15 September 2026

**Kokoro produced usable audio for Hindi, English and mixed-script Hinglish on this Mac. Repeated calls with the model retained worked, and Hindi/English speech duration moved in the expected direction when speed changed.** These are descriptive results from short synthetic text, not native quality validation or production load statistics.

We attempted **12 local generations total**, preserving **11 WAV files**. The first process encountered a real disk-full error after its third generation; that third audio could not be saved. The original checkpoint and two saved WAVs were preserved. After disk space returned, a new process completed only the remaining nine allowed generations. No weights or dependencies were downloaded.

[Structured qualification summary](../artifacts/local-20260915/kokoro/qualification-summary.json) · [Recovery event/results record](../artifacts/local-20260915/kokoro/qualification-recovery/result.json) · [Original failure record](../artifacts/local-20260915/kokoro/qualification/failure-status.json).

## Measured setup

macOS 15.6.1 ARM64; Python 3.12.12; CPU inference with two PyTorch intra-operation threads and one inter-operation thread. Kokoro0.9.4, Misaki0.9.4, PyTorch2.14.0, spaCy3.8.16 and en_core_web_sm3.8.0. Existing Kokoro82M revision `f3ff3571791e39611d31c381e3a41a3af07b4987` used local config, weights and voice files; actual artifact hashes are in the result.

One model instance was retained while the Hindi (`hf_alpha`) and American-English (`af_heart`) pipelines were reused. Hinglish went through the Hindi pipeline. English output here is **en-US**, not an Indian-English voice claim. Both processes had their own initialization; data across that restart is not presented as one uninterrupted warm process.

Recovery process initialization took **4.938 seconds**, including imports/prerequisites3.108seconds, model construction/loading0.393seconds and pipeline initialization1.437seconds. This is process initialization with existing filesystem cache; it is not a disk-cold benchmark.

| Fixture | Speed | Audio duration | Synthesis wall time | Observation |
|---|---:|---:|---:|---|
| Hindi | 1.0 first | 4.375 s | 0.826 s | First model call in recovery process |
| Hindi | 1.0 repeated | 4.375 s | 0.781 s | Same retained model/pipeline |
| Hindi | 0.8 | 5.500 s | 1.039 s | Slower setting yielded longer audio |
| Hindi | 1.2 | 3.650 s | 0.654 s | Faster setting yielded shorter audio |
| English | 1.0 | 2.725 s | 0.488 s | Retained model; first English pipeline call |
| English | 0.8 | 3.350 s | 0.578 s | Slower setting yielded longer audio |
| English | 1.2 | 2.425 s | 0.459 s | Faster setting yielded shorter audio |
| Hinglish | 1.0 first | 3.700 s | 0.675 s | Hindi pipeline had already been exercised |
| Hinglish | 1.0 repeated | 3.700 s | 0.661 s | Same retained model/pipeline |

The Hindi/English slow-to-fast duration ratios were1.507 and1.381 respectively. This demonstrates direction on these utterances, not exact proportional speed or preserved pronunciation/prosody. Hinglish speed variation was left untested to preserve the12-generation budget after the storage failure.

Warm speed1.0 synthesis/audio-duration ratios were about0.179 for both Hindi and Hinglish. All nine recovery observations fell between0.172 and0.189. No p50/p95/p99, concurrency capacity or production SLA is inferred from these samples. Pipeline output was one complete chunk per request, so first-pipeline-chunk timings were essentially batch completion timings, not true streaming first-audio latency.

## Resource and integrity findings

The recovery process peaked at **1,903,296,512 bytes RSS (~1.773 GiB)** as reported by `resource.getrusage`. This is a process-lifetime high-water mark, not instantaneous memory, system-wide usage or per-request allocation. Total recovery wall time was11.173seconds including initialization and file writes. Per-request process CPU time is preserved separately from wall time.

All11 saved WAVs were reopened and verified as mono24kHz16-bit PCM; decoded bytes matched their recorded hashes. The saved samples had zero numerically clipped samples. These checks do not measure naturalness or whether the intended words were spoken. Repeated Hindi/Hinglish waveforms were not byte-identical even though durations matched; no deterministic-output guarantee was established.

The initial disk exhaustion is a **storage failure**, not a model/language quality failure. The script now atomically replaces checkpoints and checks for20MB free before each generation. That guard reduces this particular failure risk; it cannot guarantee against external disk consumption or swap pressure. The original `result.json` is the last valid pre-failure checkpoint and still says running; its adjacent failure-status file records that the process exited.

## Passes, limits and pending checks

- Observed: local audio delivery, retained-model reuse, repeated Hindi/Hinglish calls, Hindi/English speed direction, saved audio format/hash integrity, initialization/resource separation.
- Failed: the first batch could not save its third output because the disk was full. Recovery completed the remaining nine requests.
- Unknown: native pronunciation, content accuracy, naturalness, Indian-English accent, Hinglish speed variation, speaker stability, wider regional languages, long-running memory stability, cancellation, streaming, concurrency and production telephone performance.

[Bounded runner](../scripts/qualify_kokoro_local.py) has durable output-directory guards and an explicit recovery mode; it refuses an accidental full replay. [Summary module](../tts_arena/kokoro_qualification.py) has four offline tests covering speed grouping, missing evidence, different transcripts and failures. No UI, shared runner or export code was changed. Maya work remains separate and was not run here.
