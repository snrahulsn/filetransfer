# Reproduction code

This directory contains the repository code used to generate, validate, and package the on-prem evidence. No credential file, private blind-review key, SSH key, or secret value is included. Live scripts require the operator to pass a private credential path at runtime.

The tests establish their named offline or bounded-live contract only. They do not certify native-language quality, production load, billing, or universal vendor correctness.

```bash
uv sync --frozen
uv run python -m unittest tests.test_on_prem_report tests.test_on_prem_blind_review tests.test_nvidia_nim_preflight tests.test_runpod_nim_pilot tests.test_runpod_nim_pod
```

Included repository files: 271. Verify with `../SHA256SUMS`.
