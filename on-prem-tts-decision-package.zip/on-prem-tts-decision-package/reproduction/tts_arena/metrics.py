"""Explicit metric definitions. Missing evidence stays null, never becomes zero."""
from collections import defaultdict
import math
import random
import statistics
import unicodedata


def percentile(values, q):
    if not 0 <= q <= 1:
        raise ValueError("Quantile outside [0,1]")
    values = sorted(values)
    if not values:
        return None
    pos = (len(values) - 1) * q
    low = math.floor(pos)
    high = math.ceil(pos)
    return values[low] + (values[high] - values[low]) * (pos - low)


def distribution(values):
    values = [float(v) for v in values if v is not None]
    if any(not math.isfinite(v) for v in values):
        raise ValueError("Non-finite metric")
    return {"n": len(values), "mean": statistics.mean(values) if values else None,
            **{f"p{q}": percentile(values, q / 100) for q in (50, 90, 95, 99)}}


def bootstrap_mean(values, seed=1729, repetitions=2000):
    if repetitions < 100:
        raise ValueError("Use at least 100 resamples")
    if len(values) < 2:
        return {"estimate": values[0] if values else None, "low": None, "high": None, "n": len(values)}
    rng = random.Random(seed)
    means = [statistics.mean(rng.choices(values, k=len(values))) for _ in range(repetitions)]
    return {"estimate": statistics.mean(values), "low": percentile(means, .025), "high": percentile(means, .975), "n": len(values), "seed": seed, "resamples": repetitions}


def paired_cluster_difference(rows, cluster="scenario_id", seed=1729):
    grouped = defaultdict(list)
    for row in rows:
        grouped[row[cluster]].append(row["candidate"] - row["baseline"])
    # Equal cluster weights; deliberately not a row-wise pseudo-replicated interval.
    return {**bootstrap_mean([statistics.mean(v) for v in grouped.values()], seed), "unit": cluster, "weighting": "equal_cluster"}


def error_rate(reference, hypothesis, unit="word"):
    def units(text):
        text = unicodedata.normalize("NFC", text)
        return text.split() if unit == "word" else list(text)
    if unit not in {"word", "codepoint"}:
        raise ValueError("Choose word or codepoint, not grapheme")
    a, b = units(reference), units(hypothesis)
    row = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        nxt = [i]
        for j, y in enumerate(b, 1):
            nxt.append(min(nxt[-1] + 1, row[j] + 1, row[j-1] + (x != y)))
        row = nxt
    return {"distance": row[-1], "reference_units": len(a), "rate": row[-1] / len(a) if a else None,
            "unit": unit, "normalization": "NFC_only", "warning": "Transcript diagnostic; not naturalness or native-accent validation"}


def text_units(text):
    return {"unicode_codepoints": len(text), "utf8_bytes": len(text.encode("utf-8")),
            "utf16_code_units": len(text.encode("utf-16-le")) // 2,
            "nfc_codepoints": len(unicodedata.normalize("NFC", text)),
            "billing_unit": "unverified_until_vendor_invoice_reconciliation"}


def barge_in(onset_sample, response_segments, sample_rate, expected_interrupt, observation_end_sample, cancel_sample=None, next_response_sample=None, correction_correct=None, threshold_ms=500, observation_complete=None):
    if sample_rate <= 0 or onset_sample < 0 or observation_end_sample < onset_sample:
        raise ValueError("Invalid timeline")
    if any(a < 0 or b <= a or b > observation_end_sample for a, b in response_segments):
        raise ValueError("Segments must be observed half-open sample intervals")
    # Segments belong ONLY to the interrupted response, not its replacement.
    active = any(a <= onset_sample < b for a, b in response_segments)
    after = [(max(a, onset_sample), b) for a, b in response_segments if b > onset_sample]
    last = max((b for _, b in after), default=None)
    censored = (observation_complete is False) or (last == observation_end_sample if last is not None else False)
    latency = (last - onset_sample) * 1000 / sample_rate if last is not None and not censored else None
    if cancel_sample is not None and cancel_sample < onset_sample:
        raise ValueError("Cancellation precedes caller onset; scope cancellation to this trial")
    stale = sum(max(0, b - max(a, cancel_sample)) for a, b in response_segments) if cancel_sample is not None else None
    stopped_in_time = latency is not None and latency <= threshold_ms
    return {"active_at_onset": active, "stop_latency_ms": latency, "right_censored": censored,
            "stop_latency_lower_bound_ms": max(0,(last or onset_sample)-onset_sample) * 1000 / sample_rate if censored else None,
            "missed_interruption": (not stopped_in_time) if expected_interrupt and active else None,
            "false_interruption": (cancel_sample is not None) if not expected_interrupt and active else None,
            "stale_audio_ms": stale * 1000 / sample_rate if stale is not None else None,
            "next_response_from_onset_ms": (next_response_sample - onset_sample) * 1000 / sample_rate if next_response_sample is not None else None,
            "correction_correct": correction_correct,
            "sample_resolution_ms": 1000 / sample_rate,
            "timing_accuracy_ms": None,
            "boundary": "provided_receiver_sample_timeline",
            "note": "Resolution is not calibrated accuracy. Recovery from caller end requires its separate timestamp."}


def summarize_runs(runs):
    from .registry import digest
    groups = defaultdict(list)
    for run in runs:
        config_hash=run.get("config_sha256",digest(run.get("config",{})))
        condition=run.get("condition_id","unspecified")
        groups[(run["provider"], run["language"],config_hash,condition,run.get("stratum","unspecified"))].append(run)
    result = []
    for (provider, language,config_hash,condition,stratum), rows in sorted(groups.items()):
        success = [r for r in rows if r["status"] == "success"]
        result.append({"provider": provider, "language": language, "stratum":stratum,"config_sha256":config_hash,"condition_id":condition,
                       "model":rows[0].get("config",{}).get("model"),"voice":rows[0].get("config",{}).get("voice"),
                       "attempts": len(rows), "successes": len(success),
                       "failure_rate": 1 - len(success) / len(rows),
                       "first_audio_ms_success_only": distribution([r.get("first_audio_ms") for r in success]),
                       "elapsed_ms_all_attempts": distribution([r.get("elapsed_ms") for r in rows]),
                       "queue_wait_ms_all_attempts": distribution([r.get("queue_wait_ms") for r in rows])})
    return result
