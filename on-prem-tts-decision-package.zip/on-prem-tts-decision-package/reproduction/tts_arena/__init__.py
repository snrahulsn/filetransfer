"""Auditable TTS measurements and vendor conformance evidence."""
__version__ = "0.1.0"
