"""Verify every published comparison WAV and all retained streaming originals."""
import hashlib
import json
import wave
from collections import Counter
from pathlib import Path

from tts_arena.streaming_wav import repair_header


def verify(root):
    root = Path(root).resolve()
    snapshot = json.loads((root / 'ui/public/evidence/snapshot.json').read_text())
    public = root / 'ui/public'
    rows = [*snapshot['runs'], *snapshot['local_runs'], *snapshot['maya_local_runs'],
            *snapshot['native_audio_runs'], *snapshot['studio_audio_runs']]
    checked = []
    repairs = Counter()
    seen = set()
    for row in rows:
        url = row.get('audio_url')
        if not url:
            continue
        if not url.startswith('/evidence/audio/') or not url.endswith('.wav') or url in seen:
            raise ValueError('Published audio URL invalid or repeated')
        seen.add(url)
        file = (public / url.lstrip('/')).resolve()
        if not file.is_relative_to(public / 'evidence/audio') or not file.is_file():
            raise ValueError('Published audio escaped or is missing')
        playable = file.read_bytes()
        expected_hash = row.get('listening_audio_sha256') or row.get('audio_sha256')
        if hashlib.sha256(playable).hexdigest() != expected_hash:
            raise ValueError('Published audio hash differs from snapshot')
        with wave.open(str(file), 'rb') as decoded:
            duration = decoded.getnframes() / decoded.getframerate()
            if decoded.getnframes() <= 0 or decoded.getframerate() <= 0:
                raise ValueError('Published WAV has no bounded frames')
        expected_duration = row.get('duration_seconds')
        if expected_duration is None or not 0 < duration <= 30 or abs(duration - expected_duration) > .05:
            raise ValueError('Published WAV duration differs from saved measurement')
        repair = row.get('audio_header_repair')
        if repair:
            raw_url = row.get('raw_listening_audio_url')
            if not raw_url or not raw_url.startswith('/evidence/audio/') or not raw_url.endswith('.wav'):
                raise ValueError('Streaming original URL missing')
            original_file = (public / raw_url.lstrip('/')).resolve()
            if not original_file.is_relative_to(public / 'evidence/audio'):
                raise ValueError('Streaming original escaped public evidence')
            original = original_file.read_bytes()
            if hashlib.sha256(original).hexdigest() != row['raw_listening_audio_sha256']:
                raise ValueError('Streaming original hash differs from saved run')
            regenerated, metadata = repair_header(original)
            if not metadata['header_repaired'] or regenerated != playable or any(
                repair[k] != metadata[k] for k in repair):
                raise ValueError('Standard WAV is not derived only by header repair')
            repairs[row['provider']] += 1
        checked.append((url, expected_hash, round(duration, 3)))
    if len(checked) != sum(bool(r.get('audio_url')) for r in rows) or (
        sum(repairs.values()) != sum(bool(r.get('audio_header_repair')) for r in rows)):
        raise ValueError('Public audio count or streaming repair inventory changed')
    encoded = json.dumps(sorted(checked), separators=(',', ':')).encode()
    return {'status': 'all_published_wavs_verified', 'recordings': len(checked),
            'streaming_headers_repaired': sum(repairs.values()),
            'repairs_by_provider': dict(sorted(repairs.items())),
            'audio_inventory_sha256': hashlib.sha256(encoded).hexdigest(),
            'snapshot_code_sha256': snapshot['code_sha256'],
            'boundary': 'Container/hash/frame integrity only; no perceptual quality, language or phone playout certification'}
