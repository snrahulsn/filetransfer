"""Verify the bounded two-request Neuphonic Hindi PCM speed observation."""
import hashlib
import json
import math
from pathlib import Path


EXPECTED_VOICE = "8a8d385c-21b6-4a61-8927-f14a0ee2856b"
EXPECTED_TEXT = "नमस्ते, आपकी बैठक कल दोपहर तीन बजे है।"
EXPECTED_BASE_CONFIG = {
    "voice": EXPECTED_VOICE,
    "language": "hi",
    "format": "pcm_linear",
    "sample_rate": 24000,
}
EXPECTED_SPEEDS = [0.7, 1.5]


def verify(folder):
    """Return a provenance-bound audit or reject altered/out-of-scope evidence."""
    folder = Path(folder).resolve()
    if folder.name != "neuphonic-speed-20260916":
        raise ValueError("Unexpected Neuphonic speed evidence root")
    report = json.loads((folder / "summary.json").read_text())
    records = report.get("records")
    if (
        report.get("schema") != "neuphonic_speed_pair_v1"
        or report.get("provider") != "neuphonic"
        or report.get("voice") != EXPECTED_VOICE
        or report.get("voice_name") != "Priya"
        or report.get("language") != "hi-IN"
        or report.get("reference_text") != EXPECTED_TEXT
        or report.get("request_limit") != 2
        or report.get("automatic_retries") != 0
        or report.get("speed_values") != EXPECTED_SPEEDS
        or report.get("status") != "measured_pair"
        or report.get("completed") is not True
        or not isinstance(records, list)
        or len(records) != 2
    ):
        raise ValueError("Neuphonic speed pair scope differs")
    run_ids = [row.get("run_id") for row in records]
    if len(set(run_ids)) != 2 or any(not isinstance(run_id, str) or not run_id for run_id in run_ids):
        raise ValueError("Neuphonic saved run identity differs")
    saved_dirs = {path.name for path in (folder / "runs").iterdir() if path.is_dir()}
    if saved_dirs != set(run_ids):
        raise ValueError("Neuphonic saved runs differ from exact two-record scope")

    clips = []
    for expected_speed, entry in zip(EXPECTED_SPEEDS, records):
        config = entry.get("config")
        if (
            entry.get("speed") != expected_speed
            or not isinstance(config, dict)
            or config != {**EXPECTED_BASE_CONFIG, "speed": expected_speed}
        ):
            raise ValueError("Neuphonic speed control differs")
        result_path = folder / "runs" / entry["run_id"] / "result.json"
        result = json.loads(result_path.read_text())
        if (
            result.get("run_id") != entry["run_id"]
            or result.get("provider") != "neuphonic"
            or result.get("language") != "hi-IN"
            or result.get("stratum") != "speed_paired_control"
            or result.get("scenario_id") != f"hindi-speed-{expected_speed}"
            or result.get("text") != EXPECTED_TEXT
            or result.get("config") != config
            or result.get("status") != "success"
            or result.get("http_status") != 200
            or result.get("evidence_class") != "live_http"
            or any(result.get(key) != entry.get(key) for key in (
                "status", "http_status", "error_type", "duration_seconds", "audio_sha256",
                "first_audio_ms", "elapsed_ms",
            ))
        ):
            raise ValueError("Neuphonic saved result identity or outcome differs")
        audio_name = result.get("audio_file")
        if not isinstance(audio_name, str) or Path(audio_name).name != audio_name:
            raise ValueError("Neuphonic saved audio path is unsafe")
        pcm_path = result_path.parent / audio_name
        pcm = pcm_path.read_bytes()
        duration = len(pcm) / 48000
        analysis = result.get("audio_analysis", {})
        if (
            len(pcm) < 2 or len(pcm) % 2
            or len(pcm) != result.get("audio_bytes")
            or hashlib.sha256(pcm).hexdigest() != result.get("audio_sha256")
            or not math.isclose(duration, result.get("duration_seconds", -1), abs_tol=0.001)
            or analysis.get("analysis_status") != "measured_pcm"
            or analysis.get("sample_rate") != 24000
            or analysis.get("channels") != 1
            or not math.isclose(duration, analysis.get("duration_seconds", -1), abs_tol=0.001)
        ):
            raise ValueError("Neuphonic decoded PCM provenance or duration differs")
        clips.append({
            "run_id": result["run_id"], "speed": expected_speed, "duration_seconds": duration,
            "audio_bytes": len(pcm), "audio_sha256": result["audio_sha256"],
            "first_audio_ms": result["first_audio_ms"],
        })

    ratio = clips[1]["duration_seconds"] / clips[0]["duration_seconds"]
    if (
        report.get("duration_seconds") != [clips[0]["duration_seconds"], clips[1]["duration_seconds"]]
        or not math.isclose(ratio, report.get("duration_ratio_high_over_low", -1), abs_tol=0.002)
        or report.get("direction_observation") != ("shorter_at_higher_setting" if ratio < 1 else "not_shorter_at_higher_setting")
        or report.get("native_speed_accuracy") != "unverified"
    ):
        raise ValueError("Neuphonic paired duration interpretation differs")
    return {
        "schema": "neuphonic_speed_pair_audit_v1", "provider": "neuphonic", "voice": "Priya",
        "language": "hi-IN", "requests": 2, "automatic_retries": 0, "clips": clips,
        "duration_ratio_high_over_low": ratio, "shorter_at_higher_speed": ratio < 1,
        "native_speed_effect_certified": False,
        "boundary": "One same-text, same-voice pair with distinct documented speed buckets; no replicates or listener judgment.",
    }
