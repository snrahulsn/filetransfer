"""Generate scoped conformance attestations, not a universal 'perfect' badge."""
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import unittest
import sys
import platform
import importlib.metadata

from .registry import ROOT, code_digest, digest, provider


class EvidenceResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.cases = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.cases.append({"test":test.id(),"status":"passed"})

    def addFailure(self, test, err):
        super().addFailure(test,err)
        self.cases.append({"test":test.id(),"status":"failed"})

    def addError(self, test, err):
        super().addError(test,err)
        self.cases.append({"test":test.id(),"status":"error"})

    def addSkip(self, test, reason):
        super().addSkip(test,reason)
        self.cases.append({"test":test.id(),"status":"skipped","reason":reason})

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test,subtest,err)
        self.cases.append({"test":test.id(),"subtest":str(subtest),"status":"passed" if err is None else "failed"})


def self_test(destination):
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    stream = io.StringIO()
    outcome = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=EvidenceResult).run(suite)
    report = {"created_at":datetime.now(timezone.utc).isoformat(),"code_sha256":code_digest(),
              "environment":{"python":sys.version,"platform":platform.platform(),"dependencies":{name:importlib.metadata.version(name) for name in ("httpx","websockets")}},
              "evidence_class":"offline_contract_and_measurement_tests", "passed":outcome.wasSuccessful(),
              "tests_run":outcome.testsRun, "skipped":len(outcome.skipped),"cases":outcome.cases,
              "live_vendor_certification":False}
    destination = Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    (destination / "tests.json").write_text(json.dumps(report,indent=2)+"\n")
    (destination / "tests.txt").write_text(stream.getvalue())
    return report


def attest(provider_id, test_report, live_runs=()):
    item = provider(provider_id)
    current = code_digest()
    matching_tests = [t for t in test_report.get("cases",[]) if t["test"].startswith(f"tests.test_{provider_id}.")]
    contract_ok = bool(matching_tests) and all(t["status"] == "passed" for t in matching_tests)
    current_evidence = test_report.get("code_sha256") == current
    valid_runs = [r for r in live_runs if r.get("provider") == provider_id and r.get("code_sha256") == current
                  and r.get("vendor_spec_sha256") == digest(item) and r.get("evidence_class") == "live_http"]
    return {"provider":provider_id,"created_at":datetime.now(timezone.utc).isoformat(),"code_sha256":current,
            "vendor_spec_sha256":digest(item),"catalog_state":item["integration_status"],
            "request_contract":"passed" if contract_ok and current_evidence else "not_verified",
            "measurement_suite":"passed" if current_evidence and test_report.get("passed") else "not_verified",
            "contract_test_count":len(matching_tests),"live_attempts":len(valid_runs),
            "live_successes":sum(r.get("status")=="success" for r in valid_runs),
            "certification":"NOT_CERTIFIED",
            "scope":"Local contract tests and any attached HTTP run evidence only; not vendor endorsement",
            "remaining_gates":["per-model live feature conformance", "independent spec review", "native language and accent validation",
                               "production receiver barge-in", "target-load qualification", "billing reconciliation"],
            "features":{key:{"vendor_claim":value["status"],"behavior_verification":"not_verified"} for key,value in item["features"].items()}}
