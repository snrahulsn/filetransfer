"""Independently bind matched code-switch ASR scores to the nine public WAVs."""
import hashlib
import json
import wave
from pathlib import Path

from .transcript_quality import evaluate_transcripts


def verify(root):
    root = Path(root).resolve()
    folder = root / 'artifacts/indic-codemix-matched-20260916'
    plan_raw = (folder / 'plan.json').read_bytes()
    plan = json.loads(plan_raw)
    refs = json.loads((folder / 'canonical_references.json').read_text())
    observations = json.loads((folder / 'observations.json').read_text())
    private = json.loads((folder / 'private_sanitized_responses.json').read_text())
    status = json.loads((folder / 'status.json').read_text())
    summary = json.loads((folder / 'result-summary.json').read_text())
    snapshot = json.loads((root / 'ui/public/evidence/snapshot.json').read_text())
    source_raw = (root / 'artifacts/transcript-references-20260915/references.json').read_bytes()
    source_refs = {row['reference_id']: row for row in json.loads(source_raw)}
    if plan['schema'] != 'indic_matched_codemix_asr_v1' or (
        plan['asr_model'], plan['asr_mode'], plan['language_code'], plan['retries']) != (
        'saaras:v3', 'codemix', 'unknown', 0):
        raise ValueError('Matched ASR model/mode/retry contract changed')
    if (status['status'] != 'complete' or status['completed_requests'] != 9 or
        plan['requests_limit'] != 9 or plan['audio_seconds_limit'] != 55 or
        len(plan['items']) != len(refs) != len(observations) != len(private) != 9 or
        summary['schema'] != 'indic_matched_codemix_asr_summary_v1' or
        summary['status'] != 'complete' or summary['engine'] != 'sarvam.saaras:v3.codemix' or
        summary['completed_requests'] != 9 or summary['plan_sha256'] != hashlib.sha256(plan_raw).hexdigest() or
        plan['source_references_sha256'] != hashlib.sha256(source_raw).hexdigest()):
        raise ValueError('Matched ASR request/summary inventory changed')
    by_run = {run['run_id']: run for run in snapshot['runs']}
    by_ref = {ref['reference_id']: ref for ref in refs}
    by_private = {row['reference_id']: row for row in private}
    if (len(by_ref) != 9 or len(by_private) != 9 or
        {x['provider'] for x in plan['items']} != {'cartesia', 'elevenlabs', 'google',
        'hume', 'inworld', 'minimax', 'murf', 'rime', 'smallest'} or
        hashlib.sha256(refs[0]['text'].encode()).hexdigest() != plan['text_sha256']):
        raise ValueError('Matched ASR identities repeated')
    durations = []
    for item in plan['items']:
        ref = by_ref[item['reference_id']]
        original = source_refs.get(item['reference_id'])
        run = by_run[ref['run_id']]
        if (not original or any(original[k] != ref[k] for k in
            ('reference_id', 'run_id', 'provider', 'model', 'language', 'text', 'native_reviewed')) or
            ref['native_reviewed'] is not False or ref['text'] != refs[0]['text'] or
            ref['provider'] == 'sarvam' or ref['provider'] != item['provider'] or
            ref['model'] != item['model'] or ref['language'] != 'hi-IN' or
            item['audio_url'] != run['audio_url'] or
            item['audio_sha256'] != ref['audio_sha256'] != run['listening_audio_sha256']):
            raise ValueError('Matched reference/model/audio identity changed')
        url = item['audio_url']
        if not url.startswith('/evidence/audio/') or not url.endswith('.wav'):
            raise ValueError('Matched public WAV path invalid')
        file = (root / 'ui/public' / url.lstrip('/')).resolve()
        if not file.is_relative_to(root / 'ui/public/evidence/audio'):
            raise ValueError('Matched public WAV escaped evidence folder')
        raw = file.read_bytes()
        if hashlib.sha256(raw).hexdigest() != item['audio_sha256']:
            raise ValueError('Matched public WAV hash changed')
        with wave.open(str(file), 'rb') as wav:
            duration = wav.getnframes() / wav.getframerate()
            if wav.getnchannels() != 1 or wav.getsampwidth() != 2 or not 0 < duration <= 12:
                raise ValueError('Matched public WAV format/duration changed')
        if abs(duration - item['duration_seconds']) > .001 or abs(duration - run['duration_seconds']) > .05:
            raise ValueError('Matched public WAV duration changed')
        durations.append(duration)
    if sum(durations) > 55 or abs(sum(durations) - plan['planned_audio_seconds']) > .01:
        raise ValueError('Matched ASR total duration changed')
    for row in private:
        code = row['sanitized_response'].get('language_code')
        observation = next((o for o in observations if o['reference_id'] == row['reference_id']), None)
        if (not isinstance(code, str) or not code or not row['sanitized_response'].get('transcript') or
            not observation or row['sanitized_response']['transcript'] != observation['text']):
            raise ValueError('Matched ASR sanitized response incomplete')
    scored = evaluate_transcripts(observations, refs, {})
    if scored['rejected'] or len(scored['observations']) != 9:
        raise ValueError('Matched ASR diagnostic scoring rejected records')
    detected = {k: v['sanitized_response']['language_code'] for k, v in by_private.items()}
    expected = [{'provider': score['provider'], 'model': score['model'],
                 'language': score['language'], 'reference_id': score['reference_id'],
                 'audio_sha256': score['audio_sha256'],
                 'detected_language': detected[score['reference_id']],
                 'wer_raw': score['wer']['rate'], 'cer_raw': score['cer']['rate'],
                 'word_edit_distance': score['wer']['distance'],
                 'draft_word_units': score['wer']['reference_units']}
                for score in scored['observations']]
    if summary['results'] != expected or summary['native_reviewed_references'] != 0 or summary['human_ratings'] != 0:
        raise ValueError('Matched ASR published scores differ from raw observations')
    published = []
    for row in expected:
        ref = by_ref[row['reference_id']]
        published.append(dict(row, run_id=ref['run_id'], audio_url=by_run[ref['run_id']]['audio_url'],
                              quality_certified=False))
    return {'status': 'nine_matched_diagnostics_verified', 'engine': summary['engine'],
            'asr_mode': 'codemix', 'synthesis_prompt_sha256': plan['text_sha256'],
            'planned_requests': 9, 'completed_requests': 9, 'automatic_retries': 0,
            'total_audio_seconds': round(sum(durations), 3),
            'native_reviewed_references': 0, 'human_ratings': 0,
            'results': published,
            'boundary': summary['boundary']}
