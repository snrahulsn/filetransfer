"""Independent checks on saved Soniox native cancel and software playout evidence."""
import hashlib
import io
import json
import wave
from pathlib import Path
from .audio import samples_from_pcm


def verify(folder):
    root = Path(folder)
    bridge = json.loads((root / 'soniox-bridge.json').read_text())
    receiver = json.loads((root / 'result.json').read_text())
    plan = json.loads((root / 'plan.json').read_text())
    if (bridge['schema'], bridge['provider'], bridge['model'], bridge['voice'],
        bridge['sample_rate'], bridge['status'], receiver['status'], receiver['sample_rate']) != (
        'soniox_software_playout_v1', 'soniox', 'tts-rt-v2', 'Kavya', 24000,
        'observed', 'observed', 24000):
        raise ValueError('Soniox model, rate or status differs from source')
    if (bridge['production_telephony_verified'] is not False or
        receiver['production_telephony_verified'] is not False or
        not all(bridge[key] for key in ('native_cancel_sent',
            'cancel_before_old_terminal', 'old_terminated', 'recovery_started',
            'new_terminated')) or bridge['bridge_timeout'] or bridge['error_type']):
        raise ValueError('Soniox native cancel/recovery terminal gate failed')
    original = root.parent / 'calibration/soniox-caller-tone-24000.wav'
    if hashlib.sha256(original.read_bytes()).hexdigest() != plan['caller_sha256']:
        raise ValueError('Caller fixture digest changed')
    raw = {}
    for label in ('old_before_cancel', 'old_after_cancel', 'recovery'):
        item = bridge['artifacts'][label]
        data = (root / item['file']).read_bytes()
        if not data or len(data) % 2 or len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('Captured Soniox PCM differs from manifest')
        raw[label] = data
    wav = (root / 'recovery.wav').read_bytes()
    item = bridge['artifacts']['recovery_wav']
    if len(wav) != item['bytes'] or hashlib.sha256(wav).hexdigest() != item['sha256']:
        raise ValueError('Recovered WAV digest differs from manifest')
    with wave.open(io.BytesIO(wav), 'rb') as media:
        if (media.getnchannels(), media.getsampwidth(), media.getframerate(),
            media.getcomptype()) != (1, 2, 24000, 'NONE') or media.readframes(media.getnframes()) != raw['recovery']:
            raise ValueError('Playable recovery WAV differs from captured PCM')
    for name in ('bot.wav', 'caller.wav'):
        with wave.open(str(root / name), 'rb') as media:
            if (media.getnchannels(), media.getsampwidth(), media.getframerate()) != (1, 2, 24000) or media.getnframes() == 0:
                raise ValueError('Software receiver timeline WAV invalid')
    events = bridge['events']
    kinds = [e['event_type'] for e in events]
    required = ('old_text_sent', 'local_playout_cleared', 'native_cancel_sent',
                'recovery_text_sent', 'old_audio_after_cancel_discarded',
                'vendor_terminated', 'vendor_audio_end')
    if not all(k in kinds for k in required) or not (
        kinds.index('old_text_sent') < kinds.index('local_playout_cleared') <
        kinds.index('native_cancel_sent') < kinds.index('recovery_text_sent') <
        kinds.index('old_audio_after_cancel_discarded')):
        raise ValueError('Native cancel/control order differs from stored events')
    old_terminal = [e for e in events if e['event_type'] == 'vendor_terminated' and e.get('response') == 'old']
    new_terminal = [e for e in events if e['event_type'] == 'vendor_terminated' and e.get('response') == 'recovery']
    if len(old_terminal) != 1 or len(new_terminal) != 1 or not (
        kinds.index('native_cancel_sent') < old_terminal[0]['sequence'] < new_terminal[0]['sequence']):
        raise ValueError('Soniox terminal acknowledgment ordering invalid')
    if any(e['event_type'] == 'playout_frame_sent' and e.get('response') == 'old'
           for e in events if e['sequence'] > kinds.index('local_playout_cleared')):
        raise ValueError('Old response forwarded after local clear')
    observed = receiver['events']
    onset = next(e for e in observed if e['event_type'] == 'caller_onset')
    clear = next(e for e in observed if e['event_type'] == 'clear_received' and e.get('response_id') == 'old')
    old_playout = [e for e in observed if e['event_type'] == 'playout' and e.get('response_id') == 'old']
    recovery_playout = [e for e in observed if e['event_type'] == 'playout' and e.get('response_id') == 'recovery']
    if (not old_playout or not recovery_playout or not (
        old_playout[0]['sequence'] < onset['sequence'] < clear['sequence'] < recovery_playout[0]['sequence']) or
        any(e['sequence'] > clear['sequence'] for e in old_playout)):
        raise ValueError('Software receiver timeline has old post-clear audio or missing recovery')
    metrics = receiver['metrics']
    if (not metrics['active_at_onset'] or metrics['right_censored'] or
        metrics['missed_interruption'] or metrics['stop_latency_ms'] is None or
        metrics['stop_latency_ms'] > 500 or
        metrics['next_response_from_onset_ms'] is None or
        metrics['next_response_from_onset_ms'] <= 0):
        raise ValueError('Measured Soniox interruption/recovery gate failed')
    with wave.open(str(root / 'bot.wav'), 'rb') as media:
        timeline = media.readframes(media.getnframes())
    audible_starts = []
    for event in recovery_playout:
        offset = event['sample_index'] * 2
        frame = timeline[offset:offset + 960]
        if len(frame) == 960:
            samples = samples_from_pcm(frame)
            if sum(x*x for x in samples) / len(samples) >= 100**2:
                audible_starts.append(event['sample_index'])
    if not audible_starts:
        raise ValueError('Recovered response has no audible software playout')
    measured_recovery = (min(audible_starts) - onset['sample_index']) / 24
    if abs(measured_recovery - metrics['next_response_from_onset_ms']) > .05:
        raise ValueError('Recovery metric differs from playout sample timeline')
    if 'fixture-key' in (root / 'soniox-bridge.json').read_text():
        raise ValueError('Fixture secret leaked')
    return {'schema': 'soniox_playout_audit_v1', 'provider': 'soniox',
            'model': 'tts-rt-v2', 'language': 'hi-IN', 'voice': 'Kavya',
            'status': 'observed', 'boundary': 'synthetic_tone_software_PCM_receiver',
            'production_telephony_verified': False,
            'old_active_at_onset': True,
            'software_stop_latency_ms': metrics['stop_latency_ms'],
            'recovery_from_caller_onset_ms': metrics['next_response_from_onset_ms'],
            'old_after_cancel_discarded_bytes': len(raw['old_after_cancel']),
            'post_clear_old_playout_frames': 0,
            'native_cancel_sent': True, 'old_terminated': True,
            'recovery_terminated': True,
            'recovery_wav_sha256': hashlib.sha256(wav).hexdigest(),
            'caller_fixture_sha256': plan['caller_sha256'],
            'recovery_wav_bytes': len(wav)}
