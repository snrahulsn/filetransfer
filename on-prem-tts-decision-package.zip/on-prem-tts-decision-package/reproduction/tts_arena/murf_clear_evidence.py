"""Independent verification of two bounded Murf context clear/recovery captures."""
import hashlib
import json
from pathlib import Path

from tts_arena.murf_native_evidence import repack_streaming_wav
from tts_arena.sessions.murf import decode_message


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _decode_frames(path):
    audio = {'old-turn': bytearray(), 'new-turn': bytearray()}
    counts = {'old-turn': 0, 'new-turn': 0}
    finals = {'old-turn': 0, 'new-turn': 0}
    times = {'old-turn': [], 'new-turn': []}
    for line in path.read_text().splitlines():
        frame = json.loads(line)
        if not isinstance(frame['payload'], str):
            raise ValueError('Murf wire payload must be JSON text')
        for event in decode_message(frame['payload']):
            context = event.get('context_id')
            if event['type'] == 'error':
                raise ValueError('Murf wire returned an error')
            if event['type'] == 'audio':
                if context not in audio:
                    raise ValueError('Unexpected Murf audio context')
                audio[context].extend(event['audio'])
                counts[context] += 1
                if 'elapsed_ms' in frame:
                    times[context].append(frame['elapsed_ms'])
            elif event['type'] == 'done':
                if context not in finals:
                    raise ValueError('Unexpected Murf final context')
                finals[context] += 1
    return audio, counts, finals, times


def verify(root):
    root = Path(root).resolve()
    control_dir = root / 'artifacts/murf-clear-recovery-20260916'
    adaptive_dir = root / 'artifacts/murf-adaptive-clear-20260916'
    control = json.loads((control_dir / 'manifest.json').read_text())
    adaptive = json.loads((adaptive_dir / 'manifest.json').read_text())
    for capture in (control, adaptive):
        if (capture['provider'], capture['model'], capture['language'], capture['retries'],
            capture['socket_limit'], capture['text_request_limit'], capture['clear_request_limit']) != (
            'murf', 'falcon-2', 'hi-IN', 0, 1, 2, 1):
            raise ValueError('Murf clear capture scope changed')
        if capture['old_text'] != control['old_text'] or capture['new_text'] != control['new_text']:
            raise ValueError('Murf control and adaptive texts differ')
    result_path = (root / control['result_path']).resolve()
    if not result_path.is_relative_to(control_dir / 'sessions'):
        raise ValueError('Murf control result escaped capture directory')
    result = json.loads(result_path.read_text())
    if (control['status'], control['error_type'], control['sent_action_count'],
        result['status'], result['error_type'], result['sent_action_count']) != (
        'inconclusive', None, 3, 'inconclusive', None, 3):
        raise ValueError('Murf control capture status changed')
    if control['actions'] != result['actions'] or result['config']['voice'] != 'hi-IN-khyati':
        raise ValueError('Murf control wire actions changed')
    control_audio, control_counts, control_finals, _ = _decode_frames(
        result_path.parent / result['capture_journals']['raw_frames'])
    if (control_counts, control_finals) != (
        {'old-turn': 28, 'new-turn': 19}, {'old-turn': 0, 'new-turn': 1}):
        raise ValueError('Murf control context payload/final counts changed')
    control_events = result['events']
    clear_events = [e for e in control_events if e['event_type'] == 'action_sent'
                    and e.get('action_type') == 'cancel']
    if len(clear_events) != 1:
        raise ValueError('Murf control clear not sent exactly once')
    control_clear_ms = clear_events[0]['elapsed_ms']
    if abs(control_clear_ms - control['cancel_sent_ms']) > .01:
        raise ValueError('Murf control clear timing disagrees')
    old_after = [e for e in control_events if e['event_type'] == 'audio_payload_received'
                 and e.get('context_id') == 'old-turn' and e['elapsed_ms'] > control_clear_ms]
    if old_after or control['contexts']['old-turn']['audio_after_clear_payloads'] != 0:
        raise ValueError('Murf control old audio arrived after clear')
    saved_control_audio = {item['context_id']: item for item in result['audio']}
    if set(saved_control_audio) != set(control_audio):
        raise ValueError('Murf control raw audio contexts changed')
    wavs = {}
    clips = []
    for context in ('old-turn', 'new-turn'):
        item = saved_control_audio[context]
        saved = (result_path.parent / item['path']).read_bytes()
        if saved != bytes(control_audio[context]) or len(saved) != item['bytes'] or _sha(saved) != item['sha256']:
            raise ValueError('Murf control raw audio disagrees with wire frames')
        wav, pcm = repack_streaming_wav(saved)
        key = 'control-' + context
        wavs[key] = wav
        clips.append({'id': key, 'context_id': context, 'audio_payloads': control_counts[context],
                      'final_events': control_finals[context], 'duration_seconds': round(len(pcm) / 48000, 3),
                      'raw_sha256': _sha(saved), 'playable_wav_sha256': _sha(wav),
                      'partial': context == 'old-turn'})
    if (adaptive['status'], adaptive['error_type'], adaptive['key_saved'],
        adaptive['payload_counts'], adaptive['final_counts']) != (
        'observed_new_final', None, False,
        {'old-turn': 1, 'new-turn': 19}, {'old-turn': 0, 'new-turn': 1}):
        raise ValueError('Murf adaptive capture status changed')
    if (adaptive['config']['model'], adaptive['config']['voice'], adaptive['config']['sample_rate']) != (
        'falcon-2', 'hi-IN-khyati', 24000):
        raise ValueError('Murf adaptive config changed')
    if adaptive['actions'] != [
        {'type': 'text', 'context_id': 'old-turn', 'text': control['old_text'], 'end': False},
        {'type': 'cancel', 'context_id': 'old-turn'},
        {'type': 'text', 'context_id': 'new-turn', 'text': control['new_text'], 'end': True}]:
        raise ValueError('Murf adaptive actions changed')
    adaptive_audio, adaptive_counts, adaptive_finals, adaptive_times = _decode_frames(
        adaptive_dir / adaptive['frames_file'])
    if adaptive_counts != adaptive['payload_counts'] or adaptive_finals != adaptive['final_counts']:
        raise ValueError('Murf adaptive wire frame counts disagree with manifest')
    events = adaptive['events']
    selected = [e for e in events if e['kind'] in ('old_text_sent', 'clear_sent', 'new_text_sent',
                                                  'final_received')]
    if [e['kind'] for e in selected] != ['old_text_sent', 'clear_sent', 'new_text_sent', 'final_received']:
        raise ValueError('Murf adaptive event sequence changed')
    clear_ms = selected[1]['elapsed_ms']
    if clear_ms != adaptive['clear_sent_ms'] or not adaptive_times['old-turn'] or not (
        selected[0]['elapsed_ms'] < adaptive_times['old-turn'][0] < clear_ms <
        selected[2]['elapsed_ms'] < adaptive_times['new-turn'][0] < selected[3]['elapsed_ms']):
        raise ValueError('Murf adaptive clear/audio timing changed')
    if any(t > clear_ms for t in adaptive_times['old-turn']) or (
        adaptive['old_payloads_after_clear'], adaptive['old_bytes_after_clear']) != (0, 0):
        raise ValueError('Murf adaptive old audio arrived after clear')
    for context in ('old-turn', 'new-turn'):
        item = adaptive['audio'][context]
        saved = (adaptive_dir / item['file']).read_bytes()
        if saved != bytes(adaptive_audio[context]) or len(saved) != item['bytes'] or _sha(saved) != item['sha256']:
            raise ValueError('Murf adaptive raw audio disagrees with wire frames')
        wav, pcm = repack_streaming_wav(saved)
        key = 'adaptive-' + context
        wavs[key] = wav
        clips.append({'id': key, 'context_id': context, 'audio_payloads': adaptive_counts[context],
                      'final_events': adaptive_finals[context], 'duration_seconds': round(len(pcm) / 48000, 3),
                      'raw_sha256': _sha(saved), 'playable_wav_sha256': _sha(wav),
                      'partial': context == 'old-turn'})
    audit = {'provider': 'murf', 'model': 'falcon-2', 'language': 'hi-IN', 'voice': 'hi-IN-khyati',
             'status': 'wire_and_audio_verified', 'control_status': 'inconclusive_no_old_final',
             'adaptive_status': 'observed_new_final', 'clear_message': {'context_id': 'old-turn', 'clear': True},
             'control_clear_sent_ms': round(control_clear_ms, 3),
             'adaptive_clear_sent_ms': clear_ms, 'adaptive_old_payloads_after_clear': 0,
             'adaptive_new_final_events': 1, 'clips': clips,
             'documented_clear_scope': 'cancels pending synthesis; audio already generating can continue',
             'production_barge_in_certified': False, 'quality_certified': False,
             'boundary': 'one adaptive synthetic clear and one late clear; no caller VAD, software playout, SIP/RTP, handset or repeated causal trials',
             'source': 'https://murf.ai/api/docs/text-to-speech/web-sockets/context-id'}
    return audit, wavs
