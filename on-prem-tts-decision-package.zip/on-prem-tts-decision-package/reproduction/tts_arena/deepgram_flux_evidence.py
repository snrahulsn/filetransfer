"""Verify the bounded Flux TTS software-playout interruption trace before publication."""
import hashlib
import io
import json
import wave
from pathlib import Path

ROOT_NAME='deepgram-flux-interrupt-20260915-v3'
FILES=('caller_fixture','old_received','old_played','recovery')

def _wav(path,expected_hash,rate=24000):
 raw=path.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=expected_hash:raise ValueError('Flux WAV hash mismatch: '+path.name)
 with wave.open(io.BytesIO(raw),'rb') as w:
  if w.getnchannels()!=1 or w.getsampwidth()!=2 or w.getframerate()!=rate or w.getcomptype()!='NONE':
   raise ValueError('Flux WAV shape mismatch: '+path.name)
  duration_ms=w.getnframes()*1000/rate
 return {'bytes':len(raw),'sha256':expected_hash,'duration_ms':duration_ms}

def verify(root):
 root=Path(root)
 if root.name!=ROOT_NAME:raise ValueError('Unexpected Flux interruption evidence root')
 r=json.loads((root/'result.json').read_text())
 if r.get('schema')!='deepgram_flux_software_interrupt_v1' or r.get('provider')!='deepgram' or r.get('model')!='flux-priya-en' or r.get('request_limit')!=1 or r.get('automatic_retries')!=0 or r.get('network_attempted') is not True:
  raise ValueError('Flux request scope mismatch')
 if r.get('status')!='inconclusive_model_identity' or r.get('production_telephony_verified') is not False or r.get('caller_detection')!='deterministic_fixture_schedule_not_VAD':
  raise ValueError('Flux observation boundary mismatch')
 if r.get('native_connected_model_name')!='priya' or r.get('native_connected_model_match') is not False:
  raise ValueError('Flux resolved voice name discrepancy changed')
 expected={'caller_fixture':r['caller_fixture_sha256']}
 for name in FILES[1:]:expected[name]=r[name+'_wav']['sha256']
 files={name:_wav(root/(name+'.wav'),expected[name]) for name in FILES}
 for name in FILES[1:]:
  if files[name]['bytes']!=r[name+'_wav']['bytes'] or abs(files[name]['duration_ms']-r[name+'_wav']['duration_ms'])>0.01:
   raise ValueError('Flux media metadata mismatch: '+name)
 if abs(files['caller_fixture']['duration_ms']-120)>0.01 or abs(files['old_played']['duration_ms']-160)>0.01 or files['old_received']['duration_ms']<=160 or files['recovery']['duration_ms']<=0:
  raise ValueError('Flux caller/playout/recovery duration mismatch')
 with wave.open(str(root/'old_received.wav'),'rb') as received,wave.open(str(root/'old_played.wav'),'rb') as played:
  if received.readframes(played.getnframes())!=played.readframes(played.getnframes()):
   raise ValueError('Flux played PCM is not a prefix of received PCM')
 if r['old_received_not_played_bytes_discarded']!=files['old_received']['bytes']-files['old_played']['bytes'] or r.get('recovery_old_pcm_played_bytes')!=0:
  raise ValueError('Flux discarded PCM accounting mismatch')
 split=r['speech_interrupted']
 if split.get('audio_played_ms')!=160 or not isinstance(split.get('text_spoken'),str) or not isinstance(split.get('text_remaining'),str) or split['text_spoken']+split['text_remaining']!=r['first_text']:
  raise ValueError('Flux spoken/remaining text split mismatch')
 if r['recovery_metadata']['audio_duration_ms']!=round(files['recovery']['duration_ms']) or r['recovery_metadata']['billable_character_count']!=len(r['recovery_text']):
  raise ValueError('Flux recovery metadata mismatch')
 events=r['events'];names=[e['kind'] for e in events]
 required=['websocket_connected','first_speak_sent','native_connected','speech_started','old_pcm_received','caller_fixture_onset','local_playout_cleared','interrupt_sent','speech_interrupted','recovery_speak_sent','recovery_flush_sent','recovery_complete','close_sent','session_complete']
 if any(names.count(name)!=1 for name in required if name not in {'old_pcm_received','speech_started'}) or names.count('speech_started')!=2 or names.count('old_pcm_received')<1:
  raise ValueError('Flux lifecycle events missing or duplicated')
 if any(names.index(a)>=names.index(b) for a,b in zip(required,required[1:])):
  raise ValueError('Flux lifecycle event order mismatch')
 played=[e for e in events if e['kind']=='software_frame_played']
 if len(played)!=8 or [e['played_ms'] for e in played]!=list(range(20,161,20)) or not (played[-1]['t_ms']<r['synthetic_caller_onset_ms']<=r['local_playout_stop_ms']<=r['interrupt_sent_ms']):
  raise ValueError('Flux receiver playout timing mismatch')
 if abs(next(e['t_ms'] for e in events if e['kind']=='speech_interrupted')-r['interrupt_sent_ms']-r['native_interrupt_ack_ms'])>0.02:
  raise ValueError('Flux native interrupt ACK timing mismatch')
 controls=[e['type'] for e in events if e['kind']=='native_control_received']
 if controls!=['Connected','SpeechStarted','SpeechInterrupted','SpeechStarted','Flushed','SpeechMetadata','SessionMetadata'] or r.get('provider_notices'):
  raise ValueError('Flux native control order or warnings mismatch')
 return {'provider':'deepgram','model':'flux-priya-en','status':'observed_with_resolved_name_discrepancy',
  'requested_model':'flux-priya-en','connected_model_name':'priya','connected_model_name_matches_requested_id':False,
  'boundary':r['boundary'],'production_telephony_verified':False,'caller_detection':r['caller_detection'],
  'caller_fixture_sha256':files['caller_fixture']['sha256'],'caller_onset_ms':r['synthetic_caller_onset_ms'],
  'local_playout_stop_ms':r['local_playout_stop_ms'],'played_audio_ms':160,
  'native_interrupt_ack_ms':r['native_interrupt_ack_ms'],'old_received_not_played_bytes_discarded':r['old_received_not_played_bytes_discarded'],
  'text_spoken':split['text_spoken'],'text_remaining':split['text_remaining'],'recovery_audio_duration_ms':files['recovery']['duration_ms'],
  'files':files,'source_result':'artifacts/'+ROOT_NAME+'/result.json'}
