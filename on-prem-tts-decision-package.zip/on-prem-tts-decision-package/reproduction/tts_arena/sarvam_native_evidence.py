"""Verify the saved Bulbul v3 native MP3 stream, terminal event and playable decode."""
import hashlib
import io
import json
import subprocess
import wave
from pathlib import Path

from .sessions.sarvam import decode_message


def verify(folder):
    root = Path(folder)
    runs = list(root.glob('*/result.json'))
    if len(runs) != 1:
        raise ValueError('Expected exactly one capped Sarvam native run')
    result_file = runs[0]
    directory = result_file.parent
    report = json.loads(result_file.read_text())
    if (report['provider'], report['status'], report['encoding'],
        report['sample_rate'], report['sent_action_count']) != (
        'sarvam', 'observed', 'mp3', 24000, 3):
        raise ValueError('Sarvam native session did not meet model/output gate')
    config = report['config']
    if (config.get('model'), config.get('language'), config.get('speaker'),
        config.get('format'), config.get('sample_rate')) != (
        'bulbul:v3', 'hi-IN', 'shubh', 'mp3', 24000):
        raise ValueError('Sarvam native route settings differ')
    actions = report['actions']
    if [a['type'] for a in actions] != ['text', 'text', 'flush'] or not all(
        1 <= len(a['text']) <= 2500 for a in actions[:2]):
        raise ValueError('Sarvam text/flush schedule differs')
    if len(report['audio']) != 1 or report['audio'][0]['context_id'] != 'default':
        raise ValueError('Sarvam native capture lacks one complete audio context')
    media = report['audio'][0]
    source = (directory / media['path']).read_bytes()
    if not 0 < len(source) <= 8_000_000 or media['bytes'] != len(source) or hashlib.sha256(source).hexdigest() != media['sha256']:
        raise ValueError('Sarvam native MP3 differs from saved hash')
    frames = [json.loads(line) for line in (directory / 'frames.partial.jsonl').read_text().splitlines()]
    audio = bytearray()
    terminal_count = 0
    received_types = []
    for frame in frames:
        if frame.get('type') != 'text':
            raise ValueError('Sarvam native route returned non-JSON frame')
        decoded = decode_message(frame['payload'])
        for event in decoded:
            received_types.append(event['type'])
            if event['type'] == 'audio':
                if terminal_count:
                    raise ValueError('Sarvam audio arrived after final event')
                audio.extend(event['audio'])
            elif event['type'] == 'done':
                terminal_count += 1
            else:
                raise ValueError('Sarvam returned an error event')
    if bytes(audio) != source or terminal_count != 1 or received_types.count('audio') != 25:
        raise ValueError('Sarvam raw frames differ from original saved MP3 or final event')
    events = report['events']
    sent = [(e['sequence'], e['action_type']) for e in events if e['event_type'] == 'action_sent']
    payloads = [e for e in events if e['event_type'] == 'audio_payload_received']
    terminal = [e for e in events if e['event_type'] == 'provider_event' and
                e.get('details', {}).get('type') == 'done']
    if ([kind for _,kind in sent] != ['text', 'text', 'flush'] or
        len(payloads) != 25 or len(terminal) != 1 or not (
        sent[0][0] < sent[1][0] < sent[2][0] < payloads[0]['sequence'] <
        payloads[-1]['sequence'] < terminal[0]['sequence'])):
        raise ValueError('Sarvam client action/audio/final order differs')
    wav_path = directory / 'decoded.wav'
    wav = wav_path.read_bytes()
    with wave.open(io.BytesIO(wav), 'rb') as media_file:
        if (media_file.getnchannels(), media_file.getsampwidth(),
            media_file.getframerate(), media_file.getcomptype()) != (1, 2, 24000, 'NONE'):
            raise ValueError('Sarvam decoded WAV format differs')
        pcm = media_file.readframes(media_file.getnframes())
        duration = media_file.getnframes() / 24000
    if not 3 <= duration <= 15 or not pcm:
        raise ValueError('Sarvam decoded audio duration outside bounded trial')
    decoder = subprocess.run(
        ['ffmpeg', '-nostdin', '-v', 'error', '-f', 'mp3', '-i', 'pipe:0',
         '-ac', '1', '-ar', '24000', '-f', 's16le', 'pipe:1'],
        input=source, capture_output=True, timeout=25, check=True)
    if decoder.stdout != pcm:
        raise ValueError('Sarvam WAV PCM differs from independent MP3 decode')
    return {'schema': 'sarvam_native_audit_v1', 'provider': 'sarvam',
            'model': 'bulbul:v3', 'voice': 'shubh', 'language': 'hi-IN',
            'status': 'observed', 'boundary': 'native_websocket_payload_received_not_played',
            'text_fragments': 2, 'flush_sent': True, 'audio_before_final_text': False,
            'audio_chunks': 25, 'mp3_bytes': len(source),
            'mp3_sha256': hashlib.sha256(source).hexdigest(),
            'wav_bytes': len(wav), 'wav_sha256': hashlib.sha256(wav).hexdigest(),
            'duration_seconds': round(duration, 3),
            'first_received_audio_after_first_text_ms': round(
                payloads[0]['elapsed_ms'] - next(e for e in events
                if e['event_type'] == 'action_sent' and e.get('action_type') == 'text')['elapsed_ms'], 3),
            'final_event_observed': True,
            'native_cancel_supported': False,
            'production_telephony_verified': False}
