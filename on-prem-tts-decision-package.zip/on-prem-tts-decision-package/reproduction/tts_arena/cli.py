import argparse
import asyncio
import csv
import json
from pathlib import Path
import sys

from .registry import catalog, provider, validate


def read_json(path):
    return json.loads(Path(path).read_text())


def emit(value):
    print(json.dumps(value,ensure_ascii=False,indent=2))


def main(argv=None):
    parser=argparse.ArgumentParser(description="Auditable TTS experiments. Vendor claims and measured behavior are separate.")
    sub=parser.add_subparsers(dest="command",required=True)
    sub.add_parser("catalog")
    sub.add_parser("validate")
    show=sub.add_parser("show");show.add_argument("provider")
    tests=sub.add_parser("self-test");tests.add_argument("--output",default="artifacts/verification")
    report=sub.add_parser("report");report.add_argument("--output",default="artifacts/report");report.add_argument("--tests")
    attest=sub.add_parser("attest");attest.add_argument("provider");attest.add_argument("--tests",required=True);attest.add_argument("--runs",nargs="*",default=[])
    run=sub.add_parser("run");run.add_argument("provider");run.add_argument("--config",required=True);run.add_argument("--text",required=True);run.add_argument("--output",default="artifacts/runs");run.add_argument("--timeout",type=float,default=60);run.add_argument("--cancel-after",type=float)
    run.add_argument("--evaluation-language");run.add_argument("--stratum",default="unspecified")
    session=sub.add_parser("session");session.add_argument("provider");session.add_argument("--config",required=True);session.add_argument("--actions",required=True);session.add_argument("--seconds",type=float,default=10);session.add_argument("--output",default="artifacts/runs")
    feature=sub.add_parser("check-feature");feature.add_argument("feature");feature.add_argument("--evidence",required=True);feature.add_argument("--thresholds")
    load=sub.add_parser("load");load.add_argument("--jobs",required=True);load.add_argument("--concurrency",type=int,default=1);load.add_argument("--rate",type=float,default=1);load.add_argument("--max-requests",type=int,required=True);load.add_argument("--output",default="artifacts/runs")
    load.add_argument("--manifests");load.add_argument("--connection-policy",choices=["cold","pooled"],default="cold")
    replay=sub.add_parser("replay");replay.add_argument("--endpoint",required=True);replay.add_argument("--caller",required=True);replay.add_argument("--output",required=True);replay.add_argument("--sample-rate",type=int,default=8000);replay.add_argument("--offset-ms",type=float,default=300);replay.add_argument("--seconds",type=float,default=5);replay.add_argument("--acknowledgement",action="store_true");replay.add_argument("--allow-local",action="store_true")
    bill=sub.add_parser("reconcile");bill.add_argument("--runs",nargs="+",required=True);bill.add_argument("--invoice",required=True)
    study=sub.add_parser("prepare-study");study.add_argument("--items",required=True);study.add_argument("--output",required=True)
    score=sub.add_parser("score-ratings");score.add_argument("--ratings",required=True);score.add_argument("--roster",required=True);score.add_argument("--key",required=True)
    emotion=sub.add_parser("score-emotion-ratings");emotion.add_argument("--ratings",required=True);emotion.add_argument("--roster",required=True);emotion.add_argument("--key",required=True)
    transcripts=sub.add_parser("score-transcripts");transcripts.add_argument("--observations",required=True);transcripts.add_argument("--references",required=True);transcripts.add_argument("--roster",required=True)
    timing=sub.add_parser("compare-word-timestamps");timing.add_argument("--reference",required=True);timing.add_argument("--observed",required=True)
    onboard=sub.add_parser("onboard");onboard.add_argument("prompt");onboard.add_argument("--execute",action="store_true");onboard.add_argument("--output");onboard.add_argument("--timeout",type=int,default=1800);onboard.add_argument("--model")
    args=parser.parse_args(argv)
    try:
        if args.command=="catalog":
            emit([{k:p[k] for k in ("id","name","kind","integration_status")} for p in catalog()])
        elif args.command=="show": emit(provider(args.provider))
        elif args.command=="validate":
            issues={p["id"]:validate(p) for p in catalog() if validate(p)}
            emit({"count":len(catalog()),"errors":issues});return 1 if issues else 0
        elif args.command=="self-test":
            from .certification import self_test
            result=self_test(args.output);emit({k:v for k,v in result.items() if k!="cases"});return 0 if result["passed"] else 1
        elif args.command=="report":
            from .reporting import build_report
            emit(build_report(args.output,read_json(args.tests) if args.tests else None))
        elif args.command=="attest":
            from .certification import attest
            emit(attest(args.provider,read_json(args.tests),[read_json(p) for p in args.runs]))
        elif args.command=="run":
            from .runner import run_one
            result=asyncio.run(run_one(args.provider,args.text,read_json(args.config),args.output,timeout=args.timeout,cancel_after=args.cancel_after,evaluation_language=args.evaluation_language,stratum=args.stratum))
            emit(result);return 0 if result["status"]=="success" else 1
        elif args.command=="load":
            from .runner import run_load
            emit(asyncio.run(run_load(read_json(args.jobs),args.output,args.concurrency,args.rate,args.max_requests,comparison_manifests=read_json(args.manifests) if args.manifests else None,connection_policy=args.connection_policy)))
        elif args.command=="session":
            from .session_runner import run_session
            emit(asyncio.run(run_session(args.provider,read_json(args.config),read_json(args.actions),args.output,seconds=args.seconds)))
        elif args.command=="check-feature":
            from .conformance import evaluate
            emit(evaluate(args.feature,read_json(args.evidence),read_json(args.thresholds) if args.thresholds else None))
        elif args.command=="replay":
            from .replay import replay
            emit(asyncio.run(replay(args.endpoint,args.caller,args.output,args.sample_rate,args.offset_ms,args.seconds,not args.acknowledgement,allow_local=args.allow_local)))
        elif args.command=="reconcile":
            from .billing import reconcile
            with open(args.invoice,newline="") as file:
                emit(reconcile([read_json(p) for p in args.runs],list(csv.DictReader(file))))
        elif args.command=="prepare-study":
            from .quality import prepare_study
            emit(prepare_study(read_json(args.items),args.output))
        elif args.command=="score-ratings":
            from .quality import score_ratings
            emit(score_ratings(read_json(args.ratings),read_json(args.roster),read_json(args.key)))
        elif args.command=="score-emotion-ratings":
            from .emotion_quality import score_emotion_ratings
            emit(score_emotion_ratings(read_json(args.ratings),read_json(args.roster),read_json(args.key)))
        elif args.command=="score-transcripts":
            from .transcript_quality import evaluate_transcripts
            emit(evaluate_transcripts(read_json(args.observations),read_json(args.references),read_json(args.roster)))
        elif args.command=="compare-word-timestamps":
            from .timestamp_quality import compare_word_timestamps
            emit(compare_word_timestamps(read_json(args.reference),read_json(args.observed)))
        elif args.command=="onboard":
            from .onboarding import onboard
            emit(onboard(args.prompt,args.execute,args.output,args.timeout,args.model))
    except (ValueError,KeyError,FileNotFoundError) as exc:
        print(f"{type(exc).__name__}: {exc}",file=sys.stderr);return 2
    return 0
