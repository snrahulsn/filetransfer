import asyncio
import hashlib
import importlib
import json
import os
import shutil
import base64
from pathlib import Path
import time
import uuid
from datetime import datetime,timezone

from .registry import code_digest,digest,provider,valid_id
from .runner import ensure_no_secrets
from .transport import safe_url
from .credentials import redact


async def run_session(provider_id,config,actions,destination,seconds=10,plugin=None,connector=None,allow_local=False,env=None):
    from websockets.asyncio.client import connect
    valid_id(provider_id);ensure_no_secrets(config)
    if not 0<seconds<=600 or not isinstance(actions,list) or len(actions)>10000:
        raise ValueError("Bounded session/action list required")
    previous=-1
    for action in actions:
        when=action.get("at_ms")
        if not isinstance(when,(int,float)) or not previous<=when<seconds*1000 or when<0:
            raise ValueError("Actions must have ordered finite at_ms inside observation window")
        previous=when
    module=plugin or importlib.import_module(f"tts_arena.sessions.{provider_id}")
    serialize=getattr(module,"encode_message",json.dumps)
    if not callable(serialize): raise ValueError("Session encode_message must be callable")
    def wire_message(message):
        payload=serialize(message)
        if not isinstance(payload,(str,bytes)): raise ValueError("Session serializer must return str or bytes")
        return payload
    spec=module.build_session(config,os.environ if env is None else env)
    if not actions and not spec.initial_messages:
        raise ValueError("Session needs actions or an initial synthesis request")
    if spec.metadata.get("single_request_only") and (len(actions)!=1 or actions[0].get("type")!="text"):
        raise ValueError("This session profile requires exactly one complete-text action")
    safe_url(spec.url.replace("wss://","https://",1).replace("ws://","http://",1),allow_local)
    # Validate every operation before network access, including unsupported cancellation.
    registered=spec.metadata.get("registered_context_ids",[])
    if not isinstance(registered,list) or any(not isinstance(x,str) or not x for x in registered):
        raise ValueError("registered_context_ids must be a list of nonempty strings")
    registered=set(registered)
    encoded=[];closed=set();opened=set();cancelled=set()
    for action in actions:
        context=action.get("context_id",config.get("context_id","default"))
        if context in closed and not (spec.metadata.get("cancel_after_end_input") and action.get("type")=="cancel" and context not in cancelled):
            raise ValueError("Closed contexts require a new ID; no implicit reuse")
        encoded.append(module.encode_action(action,config))
        if spec.metadata.get("require_open_turn"):
            if action["type"] in {"end_input","cancel"} and context not in opened:
                raise ValueError("Action requires an open turn")
            if action["type"]=="text": opened.add(context)
        if action["type"] in {"cancel","end_input"}:closed.add(context)
        if action["type"]=="cancel":cancelled.add(context)
    root=Path(destination)/uuid.uuid4().hex;root.mkdir(parents=True,exist_ok=False)
    if shutil.disk_usage(root).free < 500*1024*1024:
        raise OSError(28,"Session capture requires at least500MiB free before network access")
    capture_env=os.environ if env is None else env
    def safe_json(value):return redact(json.dumps(value,ensure_ascii=False),capture_env)
    def journal(name,value):
        with (root/name).open("a") as stream:
            stream.write(safe_json(value)+"\n");stream.flush()
    events=[];contexts={};origin=None;status="observed";error=None
    raw_bytes=0
    ready=asyncio.Event();terminal=set();sent_contexts=set();sent_action_count=0
    if not spec.metadata.get("handshake_event"): ready.set()
    def event(kind,**fields):
        now=time.perf_counter_ns()
        entry={"sequence":len(events),"monotonic_ns":now,"elapsed_ms":(now-origin)/1e6,"event_type":kind,**fields}
        journal("events.partial.jsonl",entry)
        events.append(entry)
    def violation(reason,kind,context=None):
        event("protocol_violation",context_id=context,provider_event_type=kind,reason=reason)
        raise ValueError(reason)
    async def send(ws):
        nonlocal sent_action_count
        await ready.wait()
        for action,messages in zip(actions,encoded):
            target=origin+round(action["at_ms"]*1e6)
            await asyncio.sleep(max(0,(target-time.perf_counter_ns())/1e9))
            if action["type"]=="text":
                sent_contexts.add("default" if spec.metadata.get("single_request_only") else str(action.get("context_id",config.get("context_id","default"))))
            for message in messages:
                await ws.send(wire_message(message))
            sent_action_count+=1
            event("action_sent",action_type=action["type"],context_id=action.get("context_id",config.get("context_id","default")),message_count=len(messages),schedule_error_ms=(time.perf_counter_ns()-target)/1e6)
    async def receive(ws):
        nonlocal raw_bytes
        async for raw in ws:
            raw_bytes+=len(raw.encode("utf8") if isinstance(raw,str) else raw)
            if raw_bytes>64_000_000:raise ValueError("Session raw frames exceed64MB")
            journal("frames.partial.jsonl",{"type":"text","payload":raw} if isinstance(raw,str) else {"type":"binary","base64":base64.b64encode(raw).decode()})
            for decoded in module.decode_message(raw):
                kind=decoded.get("type")
                if kind=="error": raise ValueError("Provider WebSocket error event")
                handshake=spec.metadata.get("handshake_event")
                if handshake and not ready.is_set():
                    if kind!=handshake: violation("Expected protocol handshake before turn events",kind,decoded.get("context_id"))
                    ready.set()
                elif handshake and kind==handshake:
                    violation("Duplicate protocol handshake",kind)
                if (spec.metadata.get("strict_terminal_contexts") or spec.metadata.get("single_request_only")) and kind in {"audio","done","cancelled"}:
                    ctx="default" if spec.metadata.get("single_request_only") else str(decoded.get("context_id") or "")
                    if spec.metadata.get("single_request_only") and kind=="cancelled": violation("Single-request profile requires done",kind,ctx)
                    if ctx not in sent_contexts and not (kind=="done" and ctx in registered): violation("Event for unsent context",kind,ctx)
                    if ctx in terminal: violation("Event after context terminator",kind,ctx)
                    if kind in {"done","cancelled"}: terminal.add(ctx)
                if kind=="audio":
                    data=decoded.get("audio")
                    if not isinstance(data,bytes): raise ValueError("Session decoder audio must be bytes")
                    context=str(decoded.get("context_id") or "default")
                    buf=contexts.setdefault(context,bytearray())
                    if sum(map(len,contexts.values()))+len(data)>32_000_000: raise ValueError("Session audio exceeds32MB")
                    partial=root/(hashlib.sha256(context.encode()).hexdigest()[:20]+".audio.partial")
                    with partial.open("ab") as stream:stream.write(data);stream.flush()
                    buf.extend(data)
                    event("audio_payload_received",context_id=context,byte_count=len(data),cumulative_bytes=len(buf))
                else:
                    event("provider_event",details=decoded)
    try:
        async with (connector or connect)(spec.url,additional_headers=spec.headers,max_size=2_000_000,open_timeout=min(seconds,30)) as ws:
            origin=time.perf_counter_ns()
            event("connected")
            for message in spec.initial_messages:
                await ws.send(wire_message(message))
            event("initial_messages_sent",count=len(spec.initial_messages))
            tasks=[asyncio.create_task(send(ws)),asyncio.create_task(receive(ws))]
            try:
                done,pending=await asyncio.wait(tasks,timeout=seconds,return_when=asyncio.FIRST_EXCEPTION)
                for task in done:
                    if task.exception(): raise task.exception()
                if not ready.is_set(): raise ValueError("Required protocol handshake missing")
                if (spec.metadata.get("strict_terminal_contexts") or spec.metadata.get("single_request_only")) and sent_contexts-terminal:
                    status="inconclusive"
                    event("missing_terminal",context_ids=sorted(sent_contexts-terminal))
                event("observation_end",pending_tasks=len(pending))
            finally:
                for task in tasks: task.cancel()
                await asyncio.gather(*tasks,return_exceptions=True)
    except Exception as exc:
        status="error";error=type(exc).__name__
    if sent_action_count != len(actions):
        if status!="error": status="inconclusive"
        if origin is not None: event("missing_actions",planned_count=len(actions),sent_count=sent_action_count)
    if not contexts and status!="error": status="inconclusive"
    artifacts=[]
    for context,audio in contexts.items():
        name=hashlib.sha256(context.encode()).hexdigest()[:20]+".audio"
        partial=root/(name+".partial")
        if partial.stat().st_size!=len(audio):raise OSError("Audio checkpoint size mismatch")
        os.replace(partial,root/name)
        artifacts.append({"context_id":context,"path":name,"bytes":len(audio),"sha256":hashlib.sha256(audio).hexdigest()})
    item=provider(provider_id) if plugin is None else {}
    report={"provider":provider_id,"status":status,"error_type":error,"created_at":datetime.now(timezone.utc).isoformat(),
            "config":config,"actions":actions,"sent_action_count":sent_action_count,"code_sha256":code_digest(),"vendor_spec_sha256":digest(item),
            "events":events,"audio":artifacts,"sample_rate":spec.sample_rate,"encoding":spec.encoding,
            "evidence_class":"native_websocket_session" if plugin is None else "local_protocol_fixture",
            "boundary":"WebSocket_payload_received_not_played","certification":"not_live_verified","result_file":str(root/"result.json")}
    report["capture_journals"]={"raw_frames":"frames.partial.jsonl","events":"events.partial.jsonl","durability":"flushed per frame/event; not fsync; disk I/O included in client observation timing"}
    temporary=root/"result.json.partial"
    temporary.write_text(safe_json(report)+"\n")
    os.replace(temporary,root/"result.json")
    return report
