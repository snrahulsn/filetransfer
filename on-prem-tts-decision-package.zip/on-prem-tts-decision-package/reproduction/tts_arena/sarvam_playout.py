"""Bulbul v3 close/reconnect interruption measured through a software PCM receiver."""
import asyncio
import base64
import hashlib
import json
import math
import subprocess
import time
from pathlib import Path

from websockets.asyncio.client import connect
from websockets.asyncio.server import serve

from .credentials import redact
from .replay import load_caller, replay
from .sessions.sarvam import build_session
from .transport import safe_url

FRAME_BYTES = 960
MAX_CAPTURE_BYTES = 8_000_000


def mp3_to_pcm(chunk):
    if not isinstance(chunk, bytes) or not 0 < len(chunk) <= 200_000:
        raise ValueError('Bounded nonempty Sarvam MP3 chunk required')
    result = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-f', 'mp3',
                             '-i', 'pipe:0', '-ac', '1', '-ar', '24000',
                             '-f', 's16le', 'pipe:1'], input=chunk,
                            capture_output=True, timeout=5)
    if result.returncode or not result.stdout or len(result.stdout) % 2 or len(result.stdout) > 2_000_000:
        raise ValueError('Sarvam MP3 chunk did not decode to bounded PCM16')
    return result.stdout


def preflight(caller_wav, old_text, new_text, env, observation_seconds,
              vendor_url=None, allow_local=False):
    if not isinstance(old_text, str) or not 50 <= len(old_text) <= 400:
        raise ValueError('Bounded old Hindi response required')
    if not isinstance(new_text, str) or not 10 <= len(new_text) <= 100:
        raise ValueError('Bounded recovery Hindi response required')
    if (type(observation_seconds) not in (int, float) or not math.isfinite(observation_seconds)
        or not 2 <= observation_seconds <= 15):
        raise ValueError('Observation must be 2..15 seconds')
    caller = load_caller(caller_wav, 24000)
    if len(caller) / 48000 > .25:
        raise ValueError('Synthetic caller WAV must be <=250 ms')
    spec = build_session({'model':'bulbul:v3','language':'hi-IN','speaker':'shubh',
                          'format':'mp3','sample_rate':24000}, env)
    target = vendor_url or spec.url
    safe_url(target.replace('wss://','https://',1).replace('ws://','http://',1), allow_local)
    return spec, target


async def replay_sarvam(caller_wav, destination, old_text, new_text, env, *,
                        onset_offset_ms=150, observation_seconds=10,
                        stop_threshold_ms=500, vendor_url=None,
                        vendor_connector=None, allow_local=False):
    spec, target = preflight(caller_wav, old_text, new_text, env,
                              observation_seconds, vendor_url, allow_local)
    output = Path(destination)
    if output.exists():
        raise FileExistsError('Sarvam playout destination already attempted')
    events = []
    origin = time.perf_counter_ns()
    audio = {'old_before_close':bytearray(), 'old_after_clear_discarded':bytearray(),
             'recovery':bytearray()}
    state = {'cleared':False,'old_final_before_clear':False,
             'old_final':False,'old_socket_closed':False,
             'new_socket_connected':False,'recovery_final':False,
             'error_type':None, 'recovery_task':None}
    pending = {'old':bytearray(),'recovery':bytearray()}

    def event(kind, **fields):
        events.append({'sequence':len(events),
                       'elapsed_ms':round((time.perf_counter_ns()-origin)/1e6,3),
                       'event_type':kind, **fields})

    connector = vendor_connector or connect

    async def bot(local_ws):
        start = json.loads(await local_ws.recv())
        if start != {'type':'start','sample_rate':24000,
                     'format':'pcm_s16le','frame_ms':20}:
            raise ValueError('Software PCM receiver start contract changed')
        lock = asyncio.Lock()
        old_ws = None

        async def forward(response):
            queue = pending[response]
            while len(queue) >= FRAME_BYTES:
                frame = bytes(queue[:FRAME_BYTES]);del queue[:FRAME_BYTES]
                if response == 'old' and state['cleared']:
                    continue
                await local_ws.send(json.dumps({'type':'audio','response_id':response,
                    'audio':base64.b64encode(frame).decode()}))
                event('playout_frame_sent',response=response,byte_count=len(frame))

        async def capture_message(raw,response):
            if not isinstance(raw,str) or len(raw)>2_000_000:
                raise ValueError('Sarvam socket returned oversized/non-JSON frame')
            message=json.loads(raw)
            if not isinstance(message,dict) or not isinstance(message.get('data'),dict):
                raise ValueError('Sarvam event envelope invalid')
            kind=message.get('type');data=message['data']
            if kind=='error':
                raise ValueError('Sarvam WebSocket error event')
            if kind=='event':
                if data.get('event_type')!='final':
                    raise ValueError('Unexpected Sarvam event')
                state['old_final' if response=='old' else 'recovery_final']=True
                event('vendor_final',response=response)
                return True
            if kind!='audio' or data.get('content_type') not in {'audio/mp3','audio/mpeg'}:
                raise ValueError('Sarvam MP3 audio event required')
            chunk=base64.b64decode(data['audio'],validate=True)
            if not 0<len(chunk)<=200_000:
                raise ValueError('Invalid Sarvam MP3 payload')
            if response=='old' and state['cleared']:
                bucket=audio['old_after_clear_discarded']
                if len(bucket)+len(chunk)>MAX_CAPTURE_BYTES:raise ValueError('Old late MP3 capture too large')
                bucket.extend(chunk)
                event('old_mp3_after_clear_discarded',byte_count=len(chunk))
                return False
            pcm=await asyncio.to_thread(mp3_to_pcm,chunk)
            async with lock:
                if response=='old' and state['cleared']:
                    bucket=audio['old_after_clear_discarded']
                    if len(bucket)+len(chunk)>MAX_CAPTURE_BYTES:raise ValueError('Old late MP3 capture too large')
                    bucket.extend(chunk)
                    event('old_mp3_after_clear_discarded',byte_count=len(chunk))
                    return False
                bucket=audio['old_before_close' if response=='old' else 'recovery']
                if len(bucket)+len(pcm)>MAX_CAPTURE_BYTES:raise ValueError('Decoded PCM capture too large')
                bucket.extend(pcm)
                pending[response].extend(pcm)
                event('vendor_mp3_decoded',response=response,mp3_bytes=len(chunk),pcm_bytes=len(pcm))
                await forward(response)
            return False

        async def vendor_receive(ws,response):
            try:
                async for raw in ws:
                    done=await capture_message(raw,response)
                    if done:break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                state['error_type']=type(exc).__name__
                event('bridge_error',response=response,error_type=state['error_type'])
            finally:
                try:
                    await local_ws.send(json.dumps({'type':'response_end','response_id':response}))
                except Exception:
                    pass
                event('response_closed',response=response)

        async def connect_recovery():
            try:
                async with connector(target,additional_headers=spec.headers,
                                     open_timeout=5,max_size=2_000_000,
                                     close_timeout=3) as new_ws:
                    state['new_socket_connected']=True
                    event('recovery_socket_connected')
                    await new_ws.send(json.dumps(spec.initial_messages[0]))
                    await new_ws.send(json.dumps({'type':'text','data':{'text':new_text}}))
                    await new_ws.send(json.dumps({'type':'flush'}))
                    event('recovery_text_flush_sent')
                    await vendor_receive(new_ws,'recovery')
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                state['error_type']=type(exc).__name__
                event('bridge_error',response='recovery',error_type=state['error_type'])

        async def caller_actions():
            async for raw in local_ws:
                message=json.loads(raw)
                if message.get('type')!='caller_audio':
                    raise ValueError('Unexpected software receiver action')
                async with lock:
                    if state['cleared']:continue
                    state['cleared']=True
                    state['old_final_before_clear']=state['old_final']
                    pending['old'].clear()
                    await local_ws.send(json.dumps({'type':'clear','response_id':'old'}))
                    event('local_playout_cleared')
                await old_ws.close()
                state['old_socket_closed']=True
                event('old_vendor_socket_closed')
                state['recovery_task']=asyncio.create_task(connect_recovery())

        try:
            async with connector(target,additional_headers=spec.headers,
                                 open_timeout=5,max_size=2_000_000,
                                 close_timeout=3) as old_ws:
                event('old_socket_connected')
                await old_ws.send(json.dumps(spec.initial_messages[0]))
                await old_ws.send(json.dumps({'type':'text','data':{'text':old_text}}))
                await old_ws.send(json.dumps({'type':'flush'}))
                event('old_text_flush_sent')
                old_task=asyncio.create_task(vendor_receive(old_ws,'old'))
                caller_task=asyncio.create_task(caller_actions())
                await local_ws.wait_closed()
                old_task.cancel();caller_task.cancel()
                await asyncio.gather(old_task,caller_task,return_exceptions=True)
                if state['recovery_task']:
                    state['recovery_task'].cancel()
                    await asyncio.gather(state['recovery_task'],return_exceptions=True)
        except Exception as exc:
            state['error_type']=type(exc).__name__
            event('bridge_error',response='old',error_type=state['error_type'])

    async with serve(bot,'127.0.0.1',0) as server:
        port=server.sockets[0].getsockname()[1]
        receiver=await replay(f'ws://127.0.0.1:{port}',caller_wav,output,
                              sample_rate=24000,onset_offset_ms=onset_offset_ms,
                              observation_seconds=observation_seconds,
                              stop_threshold_ms=stop_threshold_ms,allow_local=True)
    artifacts={}
    for label,raw in audio.items():
        if raw:
            path=output/(label+'.raw')
            path.write_bytes(raw)
            artifacts[label]={'file':path.name,'bytes':len(raw),
                              'sha256':hashlib.sha256(raw).hexdigest()}
    metrics=receiver.get('metrics') or {}
    status=('observed' if receiver['status']=='observed' and
            metrics.get('active_at_onset') and not metrics.get('right_censored') and
            not metrics.get('missed_interruption') and
            metrics.get('stop_latency_ms') is not None and
            metrics['stop_latency_ms']<=stop_threshold_ms and
            metrics.get('next_response_from_onset_ms') is not None and
            state['cleared'] and not state['old_final_before_clear'] and
            state['old_socket_closed'] and state['new_socket_connected'] and
            state['recovery_final'] and audio['recovery'] and
            not state['error_type'] else 'inconclusive')
    bridge={'schema':'sarvam_software_playout_v1','provider':'sarvam',
            'model':'bulbul:v3','voice':'shubh','requested_language':'hi-IN',
            'sample_rate':24000,'status':status,
            'synthetic_caller_onset':True,'production_telephony_verified':False,
            'in_band_cancel_supported':False,'local_playout_cleared':state['cleared'],
            'old_final_before_clear':state['old_final_before_clear'],
            'old_vendor_socket_closed':state['old_socket_closed'],
            'recovery_socket_connected':state['new_socket_connected'],
            'recovery_final':state['recovery_final'],
            'error_type':state['error_type'],'artifacts':artifacts,'events':events,
            'boundary':'Synthetic tone into 24 kHz software PCM receiver; close old TTS socket and reconnect for recovery; no VAD, SIP/RTP, handset or production call'}
    (output/'sarvam-bridge.json').write_text(redact(json.dumps(bridge,indent=2),env)+'\n')
    receiver['sarvam_bridge']=bridge
    return receiver
