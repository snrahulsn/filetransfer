"""Outbound worker v1: fixed local profiles, durable no-replay journal, no remote code."""
import argparse
import asyncio
import contextlib
import fcntl
import importlib
import io
import hashlib
import time
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit
import wave
import httpx
from .credentials import read_credentials
from .jobs import JobQueue,KINDS
from .runner import run_one,ensure_no_secrets
from .registry import provider,code_digest

# Capture once after loading runner/transport. A new Worker in this same process
# must not treat changed disk code as newly imported executable code.
STARTUP_CODE_DIGEST=code_digest()

LIMIT=10*1024*1024
ID=re.compile(r'[A-Za-z0-9_-]{1,100}\Z')
SUMMARY_FIELDS={'run_id','provider','language','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms','audio_sha256','code_sha256','vendor_spec_sha256'}

class RemoteError(Exception):pass

def server_url(value):
    u=urlsplit(value)
    if u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
        raise ValueError('Server must be an origin without credentials/path/query')
    if u.scheme!='https' and not(u.scheme=='http' and u.hostname in {'localhost','127.0.0.1','::1'}):
        raise ValueError('HTTPS required except loopback fixtures')
    if not u.hostname:raise ValueError('Server hostname required')
    return value.rstrip('/')

def load_profiles(path):
    data=json.loads(Path(path).read_text());rows=data['profiles']
    result={}
    for row in rows:
        key=row['id']
        if not isinstance(key,str) or not ID.fullmatch(key) or key in result:raise ValueError('Invalid profile ID')
        if not isinstance(row['provider'],str) or not ID.fullmatch(row['provider']):raise ValueError('Invalid provider')
        ensure_no_secrets(row['config'])
        if not isinstance(row['config'],dict):raise ValueError('Invalid config')
        # Profiles are local trusted files; still reject endpoints and filesystem overrides.
        if any(k in row['config'] for k in ('url','endpoint','base_url','path','model_path','output_root')):raise ValueError('Unsafe profile config')
        result[key]=row
    return result

def sync_directory(path):
    fd=os.open(path,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)

def durable_json(path,value):
    path=Path(path);temp=path.with_suffix('.tmp')
    with temp.open('w') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
    temp.replace(path);sync_directory(path.parent)

def exact_wav(record,folder):
    """Verify canonical bytes, then rebuild metadata-free WAV preserving all PCM frames."""
    name=record.get('audio_file')
    if name not in {'audio.wav','audio.bin'}:raise ValueError('Unrecognized local audio filename')
    source=Path(folder)/name
    if source.stat().st_size>LIMIT:raise ValueError('Audio exceeds upload limit')
    data=source.read_bytes()
    if hashlib.sha256(data).hexdigest()!=record.get('audio_sha256'):raise ValueError('Canonical audio hash mismatch')
    if record.get('audio_analysis',{}).get('analysis_status')!='measured_pcm':raise ValueError('Audio not verified PCM')
    if data.startswith(b'RIFF'):
        with wave.open(io.BytesIO(data),'rb') as w:
            if w.getcomptype()!='NONE' or w.getsampwidth()!=2:raise ValueError('Unsupported WAV')
            channels,rate,frames=w.getnchannels(),w.getframerate(),w.getnframes()
            pcm=w.readframes(frames)
            if len(pcm)!=frames*channels*2:raise ValueError('Truncated WAV')
    else:
        spec=record['request_contract'];rate=spec.get('sample_rate');channels=record['audio_analysis'].get('channels')
        if spec.get('encoding') not in {'pcm_s16le','pcm16','pcm','linear16'} or type(rate)is not int or not 8000<=rate<=192000 or len(data)%2 or channels!=1:
            raise ValueError('Unverified raw PCM format')
        pcm=data
    out=io.BytesIO()
    with wave.open(out,'wb') as w:
        w.setparams((channels,2,rate,0,'NONE','not compressed'));w.writeframes(pcm)
    clean=out.getvalue()
    if len(clean)>LIMIT:raise ValueError('WAV exceeds upload limit')
    return clean

class Worker:
    def __init__(self,server,root,profiles,state,token,site_token=None,worker_id='local-arena',credentials=None,client=None):
        self.server=server_url(server);self.root=Path(root).resolve();self.profiles=profiles;self.state=Path(state).resolve();self.state.mkdir(parents=True,exist_ok=True)
        if not isinstance(worker_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',worker_id):raise ValueError('Invalid worker ID')
        if not token or '\n' in token or '\r' in token:raise ValueError('Worker token required')
        self.worker_id=worker_id;self.credentials=credentials
        self.startup_code_digest=STARTUP_CODE_DIGEST
        headers={'Authorization':'Bearer '+token}
        if site_token:
            if '\n' in site_token or '\r' in site_token:raise ValueError('Invalid Site token')
            headers['OAI-Sites-Authorization']='Bearer '+site_token
        self.client=client or httpx.Client(timeout=30,trust_env=False,follow_redirects=False)
        self.headers=headers
    def post(self,path,body=None,data=None,claim=None):
        headers=dict(self.headers)
        if claim:headers['X-Arena-Claim']=claim
        if data is not None:
            if len(data)>LIMIT:raise ValueError('Artifact too large')
            headers['Content-Type']='application/octet-stream'
        try:r=self.client.post(self.server+path,json=body,content=data,headers=headers)
        except httpx.HTTPError:raise RemoteError('Remote transport failure') from None
        if r.status_code!=200:raise RemoteError('Remote HTTP '+str(r.status_code))
        try:return r.json()
        except ValueError:raise RemoteError('Invalid remote JSON') from None
    def execute(self,job,folder):
        kind=job['kind'];payload=job['payload'];timeout=job['timeout_seconds']
        if type(timeout)is not int or not 1<=timeout<=600:raise ValueError('Invalid job timeout')
        if not isinstance(payload,dict):raise ValueError('Invalid payload')
        if kind in KINDS:
            if payload:raise ValueError('Offline payload must be empty')
            queue=JobQueue(self.root,folder/'offline');queue.submit(kind,timeout=min(timeout,KINDS[kind]),idempotency_key=job['id']);r=queue.run_next()
            return {'kind':kind,'status':r['status'],'exit_code':r.get('exit_code')},None
        if kind!='synthesize' or set(payload)!={'profile','text'}:raise ValueError('Unsupported job/payload')
        if not isinstance(payload['text'],str) or not 1<=len(payload['text'])<=500:raise ValueError('Invalid text length')
        if not isinstance(payload['profile'],str):raise ValueError('Invalid profile ID')
        profile=self.profiles.get(payload['profile'])
        if profile is None:raise ValueError('Unknown local profile')
        module=importlib.import_module('tts_arena.adapters.'+profile['provider'])
        if hasattr(module,'synthesize_local'):raise ValueError('Hosted worker excludes local model loading')
        c=read_credentials(self.credentials) if self.credentials else {}
        required=provider(profile['provider']).get('credentials',[])
        previous={k:os.environ.get(k) for k in required}
        try:
            for k in required:
                if k in c:os.environ[k]=c[k]
                else:os.environ.pop(k,None)
            r=asyncio.run(run_one(profile['provider'],payload['text'],profile['config'],folder/'runs',timeout=min(45,timeout),scenario_id='hosted-'+job['id'],evaluation_language=profile.get('language'),stratum='owner_requested_single_probe'))
        finally:
            for k,v in previous.items():
                if v is None:os.environ.pop(k,None)
                else:os.environ[k]=v
        summary={k:r[k] for k in SUMMARY_FIELDS if k in r};summary['profile']=payload['profile'];summary['kind']=kind
        summary['status']='succeeded' if r['status']=='success' else 'failed'
        audio=None
        if summary['status']=='succeeded':
            try:audio=exact_wav(r,folder/'runs'/r['run_id'])
            except (ValueError,OSError,EOFError,wave.Error):summary['audio_upload_status']='unsupported_or_invalid_pcm'
        return summary,audio
    def once(self):
        # Fail before contacting the claim route: retained imports cannot claim
        # a later source digest as their executable identity.
        try:current_digest=code_digest()
        except OSError:return {'state':'restart_required','reason':'source_digest_unavailable'}
        if current_digest!=self.startup_code_digest:
            return {'state':'restart_required','reason':'source_changed_since_import','loaded_code_sha256':self.startup_code_digest,'current_code_sha256':current_digest}
        with (self.state/'worker.lock').open('a+b') as lock:
            try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:return {'state':'worker_busy'}
            response=self.post('/api/worker/claim',{'worker_id':self.worker_id});job=response.get('job')
            if job is None:return {'state':'empty'}
            if not isinstance(job,dict) or not isinstance(job.get('id'),str) or not ID.fullmatch(job['id']):raise RemoteError('Invalid job ID')
            claim=job.get('claim_token')
            if not isinstance(claim,str) or not claim or any(c in claim for c in '\r\n'):raise RemoteError('Invalid claim token')
            folder=self.state/job['id']
            try:folder.mkdir(exist_ok=False)
            except FileExistsError:return {'state':'duplicate_claim_not_executed','job_id':job['id']}
            sync_directory(self.state);sync_directory(folder)
            # Claim token never persisted. Directory creation precedes any provider call.
            journal={'job_id':job['id'],'state':'claimed','automatic_retries':0}
            def save():
                durable_json(folder/'journal.json',journal)
            save()
            try:summary,audio=self.execute(job,folder)
            except BaseException as exc:
                summary={'status':'interrupted' if isinstance(exc,(KeyboardInterrupt,SystemExit)) else 'failed','error_type':type(exc).__name__};audio=None
            raw=json.dumps(summary,ensure_ascii=False).encode()
            if len(raw)>65536:summary={'status':'failed','error_type':'ResultTooLarge'};raw=json.dumps(summary).encode()
            durable_json(folder/'result.json',summary);journal.update(state='executed',result=summary);save()
            try:
                base='/api/worker/jobs/'+job['id']
                self.post(base+'/artifacts/result.json',data=raw,claim=claim)
                if audio is not None:self.post(base+'/artifacts/audio.wav',data=audio,claim=claim)
                self.post(base+'/complete',{'claim_token':claim,'status':summary['status'],'result':summary})
            except (RemoteError,ValueError):
                journal['state']='delivery_failed_remote_claim_will_expire';save();return journal
            journal['state']='completed';save();return journal

def poll(worker,seconds,on_result=print,quiet_idle=False):
    if type(seconds) not in (int,float) or not 1<=seconds<=3600:raise ValueError('Poll interval must be1..3600seconds')
    try:
        while True:
            try:result=worker.once()
            except RemoteError:result={'state':'remote_request_failed_no_job_retry'}
            if not quiet_idle or result.get('state') not in {'empty','worker_busy'}:on_result(json.dumps(result))
            if result.get('state')=='restart_required':return 75
            if result.get('result',{}).get('status')=='interrupted':return 130
            time.sleep(seconds)
    except KeyboardInterrupt:
        return 0

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--server',required=True);p.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));p.add_argument('--profiles');p.add_argument('--state-dir');p.add_argument('--credentials',required=True);p.add_argument('--worker-id',default='local-arena')
    p.add_argument('--quiet-idle',action='store_true')
    mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--once',action='store_true');mode.add_argument('--poll-seconds',type=float)
    a=p.parse_args(argv)
    try:
        w=Worker(a.server,a.root,load_profiles(a.profiles or Path(a.root)/'execution_profiles.json'),a.state_dir or Path(a.root)/'artifacts/remote-worker',os.environ.get('ARENA_WORKER_TOKEN'),os.environ.get('ARENA_SITE_ACCESS_TOKEN'),a.worker_id,a.credentials)
        if a.poll_seconds is not None:return poll(w,a.poll_seconds,quiet_idle=a.quiet_idle)
        result=w.once();print(json.dumps(result));return 0 if result['state'] in {'completed','empty'} else 1
    except KeyboardInterrupt:return 130
    except (ValueError,RemoteError,OSError,KeyError):print(json.dumps({'state':'worker_error','details':'Local configuration or remote request failed; no automatic retry'}));return 1
if __name__=='__main__':raise SystemExit(main())
