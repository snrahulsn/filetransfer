"""Independent check of the saved Cartesia 8 kHz G.711 response."""

import hashlib
import json
from pathlib import Path

from tts_arena.audio import inspect_audio
from tts_arena.g711 import mulaw_to_wav


def verify_cartesia_telephony(folder: Path) -> dict:
    folder = Path(folder).resolve()
    root = folder.parents[1]
    summary = json.loads((folder / 'summary.json').read_text())
    if (summary.get('provider'), summary.get('model'), summary.get('language'),
        summary.get('status'), summary.get('http_status'), summary.get('telephony_delivery')) != (
        'cartesia', 'sonic-3.6', 'hi-IN', 'success', 200, 'observed_decodable_8khz_mulaw'):
        raise ValueError('Cartesia telephony status/model/locale mismatch')
    if summary.get('max_requests') != 1 or summary.get('automatic_retries') != 0:
        raise ValueError('Cartesia telephony request budget mismatch')
    if summary.get('config', {}).get('encoding') != 'pcm_mulaw' or summary['config'].get('sample_rate') != 8000:
        raise ValueError('Cartesia telephony requested format mismatch')
    result_path = (root / summary['result_path']).resolve()
    if not result_path.is_relative_to(folder):
        raise ValueError('Cartesia telephony result outside study')
    result = json.loads(result_path.read_text())
    if any(result.get(key) != summary.get(key) for key in ('run_id', 'status', 'http_status', 'audio_sha256')):
        raise ValueError('Cartesia telephony result provenance mismatch')
    if result.get('text') != summary.get('requested_text') or result.get('config') != summary.get('config'):
        raise ValueError('Cartesia telephony prompt/config mismatch')
    contract = result.get('request_contract', {})
    if any(contract.get(key) != value for key, value in {'method':'POST', 'url_host':'api.cartesia.ai',
                                                         'response_mode':'binary', 'encoding':'mulaw',
                                                         'sample_rate':8000}.items()):
        raise ValueError('Cartesia telephony saved request contract mismatch')
    raw_path = (result_path.parent / result['audio_file']).resolve()
    if not raw_path.is_relative_to(folder):
        raise ValueError('Cartesia telephony payload outside study')
    raw = raw_path.read_bytes()
    if len(raw) < 800 or raw.startswith((b'RIFF', b'ID3', b'{')):
        raise ValueError('Cartesia telephony payload is not headerless audio')
    digest = hashlib.sha256(raw).hexdigest()
    if digest != result['audio_sha256'] or digest != summary['raw_payload_sha256'] or len(raw) != summary['raw_payload_bytes']:
        raise ValueError('Cartesia telephony raw payload hash/length mismatch')
    wav = mulaw_to_wav(raw)
    if hashlib.sha256(wav).hexdigest() != summary['listening_wav_sha256']:
        raise ValueError('Cartesia telephony derived WAV hash mismatch')
    if hashlib.sha256((result_path.parent/'listen.wav').read_bytes()).hexdigest() != summary['listening_wav_sha256']:
        raise ValueError('Cartesia telephony saved listening WAV mismatch')
    analysis = inspect_audio(wav)
    if analysis['sample_rate'] != 8000 or analysis['rms'] < 10 or abs(len(raw)/8000-summary['decoded_duration_seconds']) > 0.001:
        raise ValueError('Cartesia telephony decoded audio diagnostics mismatch')
    return {'provider':'cartesia', 'model':'sonic-3.6', 'language':'hi-IN',
            'run_id':result['run_id'], 'status':'observed_decodable_8khz_mulaw',
            'http_status':200, 'raw_payload_bytes':len(raw), 'raw_payload_sha256':digest,
            'listening_wav_sha256':summary['listening_wav_sha256'],
            'duration_seconds':len(raw)/8000, 'decoded_pcm_rms':analysis['rms'],
            'source':summary['source'], 'boundary':summary['boundary']}
