"""Verify the one signed-in Voicemaker Studio Hindi download and WAV derivative."""
import hashlib
import json
from pathlib import Path
import subprocess
import wave


def verify(directory: Path) -> dict:
    directory = Path(directory).resolve()
    manifest = json.loads((directory / 'manifest.json').read_text())
    if (manifest.get('provider'), manifest.get('evidence_class'),
        manifest.get('requested_language'), manifest.get('generated_outputs_this_locale')) != (
        'voicemaker', 'signed_in_browser_studio_download', 'hi-IN', 1):
        raise ValueError('Voicemaker Studio identity or single-output policy differs')
    if manifest.get('language_selector') != 'Hindi (hi-IN)' or manifest.get('model') != 'proplus':
        raise ValueError('Voicemaker Studio model or explicit locale differs')
    files = [(manifest['source_mp3'], manifest['source_mp3_sha256']),
             (manifest['decoded_wav'], manifest['decoded_wav_sha256'])]
    for name, expected in files:
        source = (directory / name).resolve()
        if not source.is_relative_to(directory) or not source.is_file():
            raise ValueError('Voicemaker Studio source escaped evidence directory')
        if hashlib.sha256(source.read_bytes()).hexdigest() != expected:
            raise ValueError('Voicemaker Studio source hash differs')
    mp3 = directory / manifest['source_mp3']
    wav = directory / manifest['decoded_wav']
    if mp3.stat().st_size != manifest['source_mp3_bytes']:
        raise ValueError('Voicemaker Studio MP3 size differs')
    with wave.open(str(wav), 'rb') as decoded:
        shape = (decoded.getframerate(), decoded.getnchannels(),
                 decoded.getsampwidth(), decoded.getnframes())
        pcm = decoded.readframes(decoded.getnframes())
    if shape != (manifest['decoded_sample_rate'], manifest['decoded_channels'],
                 manifest['decoded_sample_width_bytes'], manifest['decoded_frames']):
        raise ValueError('Voicemaker Studio WAV shape differs')
    if abs(shape[3] / shape[0] - manifest['decoded_duration_seconds']) > .001:
        raise ValueError('Voicemaker Studio WAV duration differs')
    independently_decoded = subprocess.run(
        ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(mp3),
         '-f', 's16le', '-ac', '1', '-ar', str(shape[0]), 'pipe:1'],
        check=True, capture_output=True, timeout=15,
    ).stdout
    if independently_decoded != pcm:
        raise ValueError('Voicemaker Studio WAV is not the exact MP3 PCM decode')
    return {k: manifest[k] for k in ('provider', 'evidence_class', 'created_at',
                                    'model', 'visible_subengine', 'voice',
                                    'requested_language', 'language_selector', 'text',
                                    'source_mp3_sha256', 'decoded_wav_sha256',
                                    'decoded_sample_rate', 'decoded_duration_seconds',
                                    'ui_boundary', 'api_access_state', 'billing', 'quality')}


REGIONAL = {'bn-IN', 'mr-IN', 'te-IN', 'ta-IN', 'gu-IN', 'kn-IN', 'ml-IN'}


def verify_regional(directory: Path, corpus: Path) -> list[dict]:
    directory = Path(directory).resolve()
    manifest = json.loads((directory / 'regional-manifest.json').read_text())
    clips = manifest.get('clips')
    if manifest.get('schema_version') != 1 or not isinstance(clips, list):
        raise ValueError('Voicemaker regional manifest schema differs')
    locales = [clip.get('locale') for clip in clips]
    if len(locales) != len(set(locales)) or not set(locales) <= REGIONAL:
        raise ValueError('Voicemaker regional Studio locales are repeated or ineligible')
    seeds = {}
    for line in Path(corpus).read_text().splitlines():
        row = json.loads(line)
        if row.get('language') in REGIONAL and row.get('stratum') == 'native_script':
            seeds.setdefault(row['language'], (row['id'], row['text']))
    for clip in clips:
        locale = clip['locale']
        if (clip.get('model'), clip.get('visible_subengine'), clip.get('language_selector')) != (
            'proplus', 'Expressive', locale):
            raise ValueError('Voicemaker regional model or exact selector differs')
        if (clip.get('text_id'), clip.get('text')) != seeds.get(locale):
            raise ValueError('Voicemaker regional text differs from corpus seed')
        mp3 = (directory / clip['source_mp3']).resolve()
        wav = (directory / clip['decoded_wav']).resolve()
        if (not mp3.is_relative_to(directory) or not wav.is_relative_to(directory)
            or not mp3.is_file() or not wav.is_file()):
            raise ValueError('Voicemaker regional audio missing or outside evidence')
        if (mp3.stat().st_size != clip['source_mp3_bytes']
            or hashlib.sha256(mp3.read_bytes()).hexdigest() != clip['source_mp3_sha256']
            or hashlib.sha256(wav.read_bytes()).hexdigest() != clip['decoded_wav_sha256']):
            raise ValueError('Voicemaker regional source size/hash differs')
        with wave.open(str(wav), 'rb') as decoded:
            shape = (decoded.getframerate(), decoded.getnchannels(),
                     decoded.getsampwidth(), decoded.getnframes())
            pcm = decoded.readframes(decoded.getnframes())
        if shape != (clip['decoded_sample_rate'], clip['decoded_channels'],
                     clip['decoded_sample_width_bytes'], clip['decoded_frames']):
            raise ValueError('Voicemaker regional WAV shape differs')
        if abs(shape[3] / shape[0] - clip['decoded_duration_seconds']) > .001:
            raise ValueError('Voicemaker regional WAV duration differs')
        independent = subprocess.run(
            ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(mp3),
             '-f', 's16le', '-ac', '1', '-ar', str(shape[0]), 'pipe:1'],
            check=True, capture_output=True, timeout=15,
        ).stdout
        if independent != pcm:
            raise ValueError('Voicemaker regional WAV is not exact MP3 PCM decode')
    return sorted(clips, key=lambda clip: clip['locale'])
