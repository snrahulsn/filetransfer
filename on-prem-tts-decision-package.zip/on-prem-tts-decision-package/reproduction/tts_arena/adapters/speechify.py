"""Speechify stream/speech, explicit model and API version."""
import re
import json
import math
from datetime import date
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check,key,choice,nonempty,metadata


def build_request(text,config,env):
    check(text,config,{'model','voice','language','format','api_version','mode'}, {'model','voice','language','format','api_version','mode'})
    choice(config['model'],{'simba-3.2','simba-3.0','simba-multilingual'},'model')
    choice(config['mode'],{'speech','stream','stream_with_timestamps'},'mode')
    nonempty(config['voice'],'voice')
    if not isinstance(config['api_version'],str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',config['api_version']): raise ValueError('api_version must be YYYY-MM-DD')
    date.fromisoformat(config['api_version'])
    language=config['language']
    nonempty(language,'language')
    if config['model']=='simba-multilingual':
        if config['mode']=='stream_with_timestamps': raise UnsupportedFeature('Legacy model cannot produce streamed speech marks')
        if config['api_version']>='2026-09-21': raise UnsupportedFeature('simba-multilingual retired on API versions >= 2026-09-21')
        choice(language,{'en-IN','en','hi-IN','bn-IN','mr-IN','te-IN','ta-IN','gu-IN','ur-IN'},'legacy documented language subset')
    else:
        english = re.fullmatch(r'en(?:-[A-Za-z]{2}|-[0-9]{3})?', language, re.IGNORECASE) is not None
        european = config['model']=='simba-3.0' and language in {'de-DE','es-ES','es-MX','fr-FR','it-IT','pt-BR'}
        if not (english or european):
            raise UnsupportedFeature('Language outside documented current model subset; no automatic model fallback')
    formats={'pcm_16000':(16000,'pcm_s16le'),'ulaw_8000':(8000,'mulaw')}
    choice(config['format'],formats,'implemented explicit output formats')
    if len(text)>(2000 if config['mode']=='speech' else 20000): raise ValueError('input exceeds endpoint limit')
    body={'input':text,'voice_id':config['voice'],'model':config['model'],'language':language,'output_format':config['format']}
    sr,enc=formats[config['format']]
    timed=config['mode']=='stream_with_timestamps'
    extra={'sse_decoder_module':__name__,'sse_terminal_event':'speech.done','validate_audio_content_type':True,'audio_content_type_header':'speechify-audio-content-type'} if timed else {}
    return RequestSpec('POST','https://api.speechify.ai/v1/audio/'+('stream/with-timestamps' if timed else config['mode']),
        {'Authorization':'Bearer '+key(env,'SPEECHIFY_API_KEY'),'Content-Type':'application/json','Speechify-Version':config['api_version']},body,
        response_mode='sse_base64' if timed else 'json_base64' if config['mode']=='speech' else 'binary', audio_path='audio_data' if config['mode']=='speech' else None,
        sample_rate=sr,encoding=enc,metadata=metadata(config,scope='Check GET /v1/audio/models and voice locale compatibility; English locale input does not establish an Indian accent',**extra))


def decode_sse_event(kind,payload):
    """Vendor SSE schema; marks use synthesis-global milliseconds, never chunk offsets."""
    known={'speech.chunk','speech.done','speech.error'}
    if kind not in known and kind!='message': return None
    value=json.loads(payload)
    if not isinstance(value,dict): raise ValueError('SSE payload must be object')
    event_type=value.get('type')
    if kind=='message': kind=event_type
    if kind not in known: return None
    if event_type!=kind: raise ValueError('SSE event and payload types disagree')
    if kind=='speech.error':
        error=value.get('error')
        if not isinstance(error,dict) or not isinstance(error.get('code'),str): raise ValueError('Malformed error event')
        return {'error':True,'metadata':{'type':kind,'error_code':error['code']}}
    if kind=='speech.done':
        for field in ('audio_duration_ms','billable_characters_count'):
            if type(value.get(field)) is not int or value[field]<0: raise ValueError('Malformed completion totals')
        return {'terminal':True,'metadata':{'type':kind,'audio_duration_ms':value['audio_duration_ms']},'usage':{'billable_characters_count':value['billable_characters_count']}}
    if 'audio' not in value and 'speech_marks' not in value: raise ValueError('Empty speech chunk')
    if 'audio' in value and not isinstance(value['audio'],str): raise ValueError('Malformed audio field')
    marks=value.get('speech_marks',[])
    if not isinstance(marks,list): raise ValueError('Speech marks must be a list')
    for mark in marks:
        if not isinstance(mark,dict): raise ValueError('Speech mark must be object')
        for field in ('start','end','start_time','end_time'):
            if field not in mark: continue
            number=mark[field]
            if isinstance(number,bool) or not isinstance(number,(int,float)) or not math.isfinite(number) or number<0: raise ValueError('Invalid mark coordinate')
            if field in {'start','end'} and type(number) is not int: raise ValueError('Text offsets must be integers')
        for begin,end in (('start','end'),('start_time','end_time')):
            if begin in mark and end in mark and mark[end]<mark[begin]: raise ValueError('Reversed mark interval')
        for field in ('type','value'):
            if field in mark and not isinstance(mark[field],str): raise ValueError('Invalid mark text')
    return {'audio':value.get('audio'),'metadata':{'type':kind,'speech_marks':marks,'time_unit':'milliseconds','time_origin':'synthesis_start'}}
