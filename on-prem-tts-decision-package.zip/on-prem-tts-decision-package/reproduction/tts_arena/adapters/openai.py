"""OpenAI POST /v1/audio/speech; standalone TTS, not Realtime."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check, key, choice, number, nonempty, metadata


def build_request(text, config, env):
    check(text, config, {'model','voice','language','format','speed','instructions','stream_format'}, {'model','voice','language','format'})
    choice(config['model'], {'tts-1','tts-1-hd','gpt-4o-mini-tts','gpt-4o-mini-tts-2025-12-15'}, 'model')
    choice(config['format'], {'mp3','opus','aac','flac','wav','pcm'}, 'format')
    choice(config['language'], {'auto','en-IN','hi-IN','mr-IN','ur-IN','kn-IN','ta-IN'}, 'documented language subset')
    if len(text) > 4096:
        raise ValueError('input exceeds 4096 characters')
    voice = config['voice']
    if isinstance(voice, dict):
        if set(voice) != {'id'}:
            raise ValueError('custom voice must contain exactly id')
        nonempty(voice['id'], 'voice.id')
    else:
        choice(voice, {'alloy','ash','ballad','coral','echo','fable','onyx','nova','sage','shimmer','verse','marin','cedar'}, 'voice')
    body = {'input': text, 'model': config['model'], 'voice': voice, 'response_format': config['format']}
    for name in ('speed','instructions','stream_format'):
        if name in config:
            body[name] = config[name]
    if 'speed' in config:
        number(config['speed'], .25, 4, 'speed')
    if 'instructions' in config:
        nonempty(config['instructions'], 'instructions')
        if len(config['instructions']) > 4096:
            raise ValueError('instructions exceeds 4096 characters')
        if config['model'] in {'tts-1','tts-1-hd'}:
            raise UnsupportedFeature('instructions unavailable on tts-1 / tts-1-hd')
    stream = config.get('stream_format', 'audio')
    choice(stream, {'audio','sse'}, 'stream_format')
    if stream == 'sse' and config['model'] in {'tts-1','tts-1-hd'}:
        raise UnsupportedFeature('SSE unavailable on tts-1 / tts-1-hd')
    return RequestSpec('POST','https://api.openai.com/v1/audio/speech',
        {'Authorization':'Bearer '+key(env,'OPENAI_API_KEY'),'Content-Type':'application/json'}, body,
        response_mode='sse_base64' if stream == 'sse' else 'binary', audio_path='audio' if stream == 'sse' else None,
        sample_rate=24000 if config['format']=='pcm' else None, encoding='pcm_s16le' if config['format']=='pcm' else config['format'],
        metadata=metadata(config, language_control='input text and optional instructions; locale is an evaluation label, not a wire parameter; Indian accent unverified'))
