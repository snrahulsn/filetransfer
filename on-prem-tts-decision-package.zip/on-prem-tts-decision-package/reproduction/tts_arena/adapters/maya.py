"""Maya Calyx HTTP contract, captured 2026-09-15 (not legacy Maya 2)."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

VOICES = frozenset('Aarav Kabir Rohan Amit Kavita Sagar Arushi Neeraj SagarM Diya Neha Samar Gargi Nila Sana Rahul Rehan Seema Riya Shailika Shreeraj Tarini Tripti Vikas Vikram Zara Riley Christine Jackson Christopher Vance'.split())
LANGUAGES = frozenset('hi bn gu kn ml mr or pa ta te en'.split())


def build_request(text, config, env):
    allowed = {'model', 'voice', 'language', 'format', 'sample_rate'}
    if set(config) - allowed:
        raise UnsupportedFeature(f'Maya Calyx unsupported controls: {sorted(set(config)-allowed)}; region and seed are ignored by the API and cannot be benchmark controls')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('Non-empty plain text required')
    for key in allowed:
        if key not in config:
            raise ValueError(f'Explicit {key} required')
    if config['model'] != 'Maya Calyx':
        raise UnsupportedFeature('Only the documented Maya Calyx contract is implemented')
    if not isinstance(config['voice'], str) or config['voice'] not in VOICES:
        raise ValueError('Select an exact case-sensitive Maya Calyx voice')
    language = config['language']
    if not isinstance(language, str):
        raise ValueError('Explicit language code or auto required')
    language = {code+'-IN':code for code in LANGUAGES}.get(language, language)
    if language not in LANGUAGES | {'auto'}:
        raise UnsupportedFeature('Unsupported Maya Calyx language; no silent fallback')
    if config['format'] not in ('pcm_s16le', 'mulaw'):
        raise UnsupportedFeature('Maya HTTP supports pcm_s16le or mulaw')
    if type(config['sample_rate']) is not int or config['sample_rate'] not in (8000, 16000, 24000):
        raise ValueError('Maya sample_rate must be 8000, 16000 or 24000')
    token = env.get('MAYA_API_KEY')
    if not isinstance(token, str) or not token.strip() or any(c.isspace() for c in token):
        raise ValueError('A non-empty MAYA_API_KEY without whitespace is required')
    body = {'model': 'Maya Calyx', 'voice': config['voice'], 'text': text,
            'sample_rate': config['sample_rate'], 'encoding': config['format']}
    if language != 'auto':
        body['language'] = language
    return RequestSpec('POST', 'https://tts.mayaresearch.ai/v1/tts',
        {'Authorization': 'Bearer '+token, 'Content-Type': 'application/json', 'User-Agent': 'tts-arena/0.1'},
        body, sample_rate=config['sample_rate'], encoding=config['format'],
        metadata={'certification': 'not_live_verified', 'api_profile': 'Maya Calyx HTTP',
                  'validate_audio_content_type': True,
                  'language_mode': 'automatic_explicitly_requested' if language == 'auto' else 'explicit',
                  'region': 'automatically routed; no residency guarantee',
                  'model_version': 'vendor alias; immutable weights not pinned'})
