"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","sample_rate","speed"}, "SMALLEST_API_KEY")
    if config["model"] not in ("lightning_v3.1", "lightning_v3.1_pro"): raise UnsupportedFeature("Only reviewed v3.1 pools supported")
    if not isinstance(config["voice"],str): raise ValueError("voice ID must be string")
    langs = {x+"-IN":x for x in "en hi bn mr te ta gu kn ml pa".split()}
    if config["language"] not in langs: raise ValueError("language not in reviewed Indian subset")
    rate = config.get("sample_rate",24000)
    if rate not in (8000,16000,24000,44100): raise ValueError("sample_rate")
    fmt = config["format"]
    if fmt not in ("wav","pcm","mp3","ulaw","alaw"): raise ValueError("format")
    body = {"text":text,"voice_id":config["voice"],"model":config["model"],"language":langs[config["language"]],"sample_rate":rate,"output_format":fmt}
    if "speed" in config: body["speed"] = _range(config["speed"],.5,2,"speed")
    return RequestSpec("POST","https://api.smallest.ai/waves/v1/tts",{"Authorization":"Bearer "+key,"Content-Type":"application/json"},body,sample_rate=rate,encoding=fmt,metadata={"voice_language_pair_requires_catalog_check":True})
