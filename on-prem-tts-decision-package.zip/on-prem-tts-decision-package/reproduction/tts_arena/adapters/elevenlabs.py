"""ElevenLabs HTTP output streaming. WebSocket input streaming is separate."""
from urllib.parse import quote, urlencode
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check,key,choice,number,boolean,nonempty,metadata


def build_request(text,config,env):
    allowed={'model','voice','language','language_mode','format','voice_settings','seed','enable_logging','apply_text_normalization','pronunciation_dictionary_locators'}
    check(text,config,allowed,{'model','voice','language','format'})
    choice(config['model'],{'eleven_v3','eleven_multilingual_v2','eleven_flash_v2_5','eleven_turbo_v2_5'},'model')
    nonempty(config['voice'],'voice')
    langs={'en-IN':'en','hi-IN':'hi','ta-IN':'ta'}
    if config['model']=='eleven_multilingual_v2':
        if config.get('language_mode')!='auto':
            raise UnsupportedFeature('multilingual_v2 does not support language_code enforcement; explicit language_mode=auto required')
    elif 'language_mode' in config:
        choice(config['language_mode'],{'enforced'},'language_mode')
    if config['model']=='eleven_v3':
        langs.update({'bn-IN':'bn','mr-IN':'mr','te-IN':'te','gu-IN':'gu','ur-IN':'ur','kn-IN':'kn','ml-IN':'ml'})
    choice(config['language'],langs,'language for selected model')
    formats={'mp3_44100_128':(44100,'mp3'),'pcm_16000':(16000,'pcm_s16le'),'pcm_24000':(24000,'pcm_s16le'),'ulaw_8000':(8000,'mulaw')}
    choice(config['format'],formats,'format')
    body={'text':text,'model_id':config['model'],'language_code':langs[config['language']]}
    if config['model']=='eleven_multilingual_v2':
        body.pop('language_code')
    for name in ('seed','apply_text_normalization','pronunciation_dictionary_locators'):
        if name in config:
            body[name]=config[name]
    if 'seed' in config: number(config['seed'],0,4294967295,'seed',True)
    if 'apply_text_normalization' in config: choice(config['apply_text_normalization'],{'auto','on','off'},'normalization')
    if 'pronunciation_dictionary_locators' in config:
        loc=config['pronunciation_dictionary_locators']
        if not isinstance(loc,list) or len(loc)>3: raise ValueError('at most 3 dictionary locators')
        for item in loc:
            if not isinstance(item,dict) or set(item)-{'pronunciation_dictionary_id','version_id'} or not item.get('pronunciation_dictionary_id'):
                raise ValueError('invalid dictionary locator')
    if 'voice_settings' in config:
        if config['model']=='eleven_v3':
            raise UnsupportedFeature('Eleven v3 voice_settings model-specific behavior is not contract-validated by this adapter; use explicit v2-family model or extend v3 conformance')
        settings=config['voice_settings']
        if not isinstance(settings,dict) or set(settings)-{'stability','similarity_boost','style','use_speaker_boost','speed'}:
            raise UnsupportedFeature('unsupported voice_settings field')
        for n,v in settings.items():
            if n=='use_speaker_boost': boolean(v,n)
            else: number(v,.7 if n=='speed' else 0,1.2 if n=='speed' else 1,n)
        body['voice_settings']=dict(settings)
    query={'output_format':config['format']}
    if 'enable_logging' in config:
        boolean(config['enable_logging'],'enable_logging'); query['enable_logging']=str(config['enable_logging']).lower()
    sr,enc=formats[config['format']]
    return RequestSpec('POST','https://api.elevenlabs.io/v1/text-to-speech/'+quote(config['voice'],safe='')+'/stream?'+urlencode(query),
        {'xi-api-key':key(env,'ELEVENLABS_API_KEY'),'Content-Type':'application/json'},body,sample_rate=sr,encoding=enc,
        metadata=metadata(config,scope='HTTP streaming only; seed best effort; zero retention entitlement not validated'))
