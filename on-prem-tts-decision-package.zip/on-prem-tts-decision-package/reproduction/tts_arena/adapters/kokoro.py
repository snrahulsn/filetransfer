"""Local Kokoro batch synthesis with explicit pinned artifact paths."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def build_request(text, config, env):
    raise UnsupportedFeature('Local KPipeline runtime, pinned hexgrad/Kokoro-82M weights and espeak-ng are required; no official hosted HTTP endpoint exists in this model card. Use the local synthesis worker with explicit artifact paths.')


def synthesize_local(text,config):
    import time
    started=time.perf_counter()
    import shutil
    from ._local_runtime import validate,local_path,dependency,pcm16,versions,hashes
    validate(text,config,{'model','language','voice','config_path','weights_path','voice_path','speed'})
    if config.get('model')!='hexgrad/Kokoro-82M':
        raise UnsupportedFeature('Only the reviewed Kokoro-82M base checkpoint is implemented')
    languages={'en-US':'a','en-GB':'b','hi-IN':'h'}
    if config.get('language') not in languages:
        raise UnsupportedFeature('Reviewed local path supports en-US/en-GB/hi-IN; en-IN is not a documented base voice accent')
    code=languages[config['language']]
    voice=config.get('voice')
    if not isinstance(voice,str) or not voice.startswith(code):
        raise ValueError('voice ID must match selected language prefix')
    files=[local_path(config,k) for k in ('config_path','weights_path','voice_path')]
    if not files[2].endswith('.pt'):
        raise ValueError('voice_path must end in .pt so KPipeline treats it as a local file, not a Hub voice ID')
    speed=config.get('speed',1.0)
    if type(speed) not in (int,float) or not .5<=speed<=2:
        raise ValueError('Arena tested speed range is [.5,2]')
    if not shutil.which('espeak-ng'):
        raise UnsupportedFeature('Install espeak-ng before invoking local Kokoro; no automatic fallback download')
    if code in 'ab':
        spacy=dependency('spacy')
        if not spacy.util.is_package('en_core_web_sm'):
            raise UnsupportedFeature('Install en_core_web_sm separately; Misaki would otherwise auto-download it')
        # Ensure the offline espeak fallback works before KPipeline can replace it.
        dependency('misaki.espeak').EspeakFallback(british=code=='b')
    provenance=hashes(files)
    runtime=dependency('kokoro')
    model=runtime.KModel(repo_id=config['model'],config=files[0],model=files[1]).to(config['device']).eval()
    pipeline=runtime.KPipeline(lang_code=code,repo_id=config['model'],model=model,device=config['device'])
    initialized=time.perf_counter()
    chunks=[]
    for result in pipeline(text,voice=files[2],speed=speed):
        audio=result.audio if hasattr(result,'audio') else result[2]
        chunks.append(pcm16(audio))
    completed=time.perf_counter()
    if not chunks:
        raise ValueError('Kokoro produced no audio')
    return {'audio':b''.join(chunks),'sample_rate':24000,'encoding':'pcm_s16le',
            'model_revision':config['model_revision'],'dependency_versions':versions(['kokoro','misaki','torch']),
            'artifact_sha256':provenance,'initialization_seconds':initialized-started,
            'synthesis_seconds':completed-initialized,'streaming':False,'certification':'not_live_verified'}
