"""Azure Speech regional REST synthesis, selected standard Neural voices."""
import re
from xml.sax.saxutils import escape, quoteattr
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check, key, choice, metadata


def build_request(text, config, env):
    check(text,config,{'model','voice','language','format','region'}, {'model','voice','language','format','region'})
    choice(config['model'], {'neural'}, 'model family (HD/custom require another contract)')
    if not isinstance(config['region'], str) or not re.fullmatch(r'[a-z][a-z0-9-]{1,40}', config['region']):
        raise ValueError('invalid Azure region')
    if not isinstance(config['voice'],str) or ':' in config['voice'] or not config['voice'].startswith(config['language']+'-') or not config['voice'].endswith('Neural'):
        raise UnsupportedFeature('This adapter requires a locale-matched standard Neural voice')
    formats = {'raw-8khz-8bit-mono-mulaw':(8000,'mulaw'), 'raw-16khz-16bit-mono-pcm':(16000,'pcm_s16le'),
               'raw-24khz-16bit-mono-pcm':(24000,'pcm_s16le'), 'riff-24khz-16bit-mono-pcm':(24000,'wav'),
               'audio-24khz-48kbitrate-mono-mp3':(24000,'mp3')}
    choice(config['format'],formats,'format')
    sr, enc = formats[config['format']]
    body = '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang='+quoteattr(config['language'])+'><voice name='+quoteattr(config['voice'])+'>'+escape(text)+'</voice></speak>'
    return RequestSpec('POST',f"https://{config['region']}.tts.speech.microsoft.com/cognitiveservices/v1",
        {'Ocp-Apim-Subscription-Key':key(env,'AZURE_SPEECH_KEY'),'Content-Type':'application/ssml+xml',
         'X-Microsoft-OutputFormat':config['format'],'User-Agent':'tts-arena'},body, sample_rate=sr,encoding=enc,
        metadata=metadata(config, region=config['region'], scope='plain text escaped into SSML; advanced SSML/SDK events not implemented'))
