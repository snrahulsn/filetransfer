"""MiniMax HTTP with hex response; streaming is deliberately a separate contract."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text, config, env):
    allowed = {'model','voice','language','format','sample_rate','speed','volume','pitch','emotion','pronunciation_dict','channels'}
    if set(config)-allowed:
        raise UnsupportedFeature(f'MiniMax adapter does not implement: {sorted(set(config)-allowed)}')
    if not isinstance(text,str) or not text.strip() or len(text)>=10000:
        raise ValueError('text must contain fewer than 10000 characters')
    for k in ('model','voice','language','format','sample_rate'):
        if k not in config or config[k] in ('',None):
            raise ValueError(f'Explicit {k} required')
    model=config['model']
    if model not in {'speech-2.8-hd','speech-2.8-turbo','speech-2.6-hd','speech-2.6-turbo','speech-02-hd','speech-02-turbo','speech-01-hd','speech-01-turbo'}:
        raise UnsupportedFeature('Unreviewed MiniMax model')
    languages={'auto','Chinese','Chinese,Yue','English','Arabic','Russian','Spanish','French','Portuguese','German','Turkish','Dutch','Ukrainian','Vietnamese','Indonesian','Japanese','Italian','Korean','Thai','Polish','Romanian','Greek','Czech','Finnish','Hindi','Bulgarian','Danish','Hebrew','Malay','Persian','Slovak','Swedish','Croatian','Filipino','Hungarian','Norwegian','Slovenian','Catalan','Nynorsk','Tamil','Afrikaans'}
    if config['language'] not in languages:
        raise UnsupportedFeature('Use exact documented language_boost name')
    if config['language'] in {'Tamil','Persian','Filipino'} and model.startswith(('speech-01','speech-02')):
        raise UnsupportedFeature('This language is unsupported in speech-01/02')
    fmt, rate=config['format'], config['sample_rate']
    if fmt not in {'mp3','pcm','wav','flac','pcmu_raw','pcmu_wav','opus'}:
        raise ValueError('Unsupported audio format')
    if type(rate) is not int or rate not in {8000,16000,22050,24000,32000,44100}:
        raise ValueError('Unsupported sample_rate')
    if fmt in {'pcmu_raw','pcmu_wav'} and rate!=8000:
        raise ValueError('G.711 requires 8000 Hz')
    channels=config.get('channels',1)
    if type(channels) is not int or channels not in (1,2):
        raise ValueError('channels must be 1 or 2')
    if not isinstance(config['voice'],str):
        raise ValueError('voice_id must be string')
    voice={'voice_id':config['voice']}
    for key,target,lo,hi in [('speed','speed',.5,2),('volume','vol',0,10),('pitch','pitch',-12,12)]:
        if key in config:
            v=config[key]
            if type(v) not in (int,float) or not lo<=v<=hi or (key=='volume' and v==0) or (key=='pitch' and type(v) is not int):
                raise ValueError(f'Invalid {key}')
            voice[target]=v
    if 'emotion' in config:
        e=config['emotion']
        if e not in {'happy','sad','angry','fearful','disgusted','surprised','calm','fluent','whisper'}:
            raise ValueError('Invalid emotion')
        if e in {'fluent','whisper'} and model not in {'speech-2.6-hd','speech-2.6-turbo'}:
            raise UnsupportedFeature('fluent/whisper limited to reviewed 2.6 models')
        voice['emotion']=e
    body={'text':text,'model':model,'stream':False,'output_format':'hex','language_boost':config['language'],
          'voice_setting':voice,'audio_setting':{'format':fmt,'sample_rate':rate,'channel':channels}}
    if 'pronunciation_dict' in config:
        p=config['pronunciation_dict']
        if not isinstance(p,dict) or set(p)!={'tone'} or not isinstance(p['tone'],list) or not all(isinstance(x,str) and '/' in x for x in p['tone']):
            raise ValueError('pronunciation_dict must contain tone list of word/replacement strings')
        body['pronunciation_dict']={'tone':list(p['tone'])}
    if not env.get('MINIMAX_API_KEY'):
        raise ValueError('MINIMAX_API_KEY required')
    return RequestSpec('POST','https://api.minimax.io/v1/t2a_v2',
                       {'Authorization':'Bearer '+env['MINIMAX_API_KEY'],'Content-Type':'application/json'},body,
                       response_mode='json_hex',audio_path='data.audio',sample_rate=rate,channels=channels,
                       encoding={'pcm':'pcm_s16le','pcmu_raw':'mulaw','pcmu_wav':'wav'}.get(fmt,fmt),
                       metadata={'streaming':False,'certification':'not_live_verified'})
