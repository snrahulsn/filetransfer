"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","speaking_rate","user_instructions"}, "CAMB_API_KEY")
    model=config["model"]
    if model not in ("mars-flash","mars-pro","mars-8.1-flash-beta","mars-8.1-pro-beta","mars-instruct"): raise ValueError("model")
    if not 3<=len(text)<=3000: raise ValueError("text length must be 3..3000")
    if type(config["voice"]) is not int or config["voice"]<=0: raise ValueError("voice ID must be positive integer")
    if config["language"] not in "en-IN hi-IN bn-IN mr-IN te-IN ta-IN gu-IN ur-IN kn-IN ml-IN".split(): raise ValueError("language outside reviewed subset")
    if model in ("mars-flash","mars-pro") and config["language"] in ("gu-IN","ur-IN"): raise UnsupportedFeature("Locale requires MARS 8.1 or instruct")
    fmt=config["format"]
    if fmt not in ("wav","mp3","flac","adts","pcm_s16le","pcm_s16be","pcm_s32be","pcm_s32le","pcm_f32le","pcm_f32be"): raise ValueError("format")
    if model=="mars-instruct" and fmt in ("mp3","pcm_s16be"): raise UnsupportedFeature("format unavailable for mars-instruct")
    body={"text":text,"speech_model":model,"voice_id":config["voice"],"language":config["language"].lower(),"output_configuration":{"format":fmt}}
    if "speaking_rate" in config:
        value=config["speaking_rate"]
        if type(value) not in (int,float) or not 0 < value < float("inf"): raise ValueError("speaking_rate must be finite positive; vendor range unspecified")
        body["voice_settings"]={"speaking_rate":value}
    if "user_instructions" in config:
        if model!="mars-instruct": raise UnsupportedFeature("user_instructions requires mars-instruct")
        if not isinstance(config["user_instructions"],str): raise ValueError("user_instructions")
        body["user_instructions"]=config["user_instructions"]
    return RequestSpec("POST","https://client.camb.ai/apis/tts-stream",{"x-api-key":key,"Content-Type":"application/json"},body,encoding=fmt,metadata={"sample_rate_requires_response_inspection":True})
