"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

# Model and locale are determined by speaker_no, not independent wire fields.
_SPEAKERS={
 182:("neo.one","hi-IN"),181:("neo.one","hi-IN"),184:("neo.one","en-IN"),185:("neo.one","en-IN"),
 199:("neo.one","bn-IN"),198:("neo.one","bn-IN"),200:("neo.one","kn-IN"),193:("neo.one","gu-IN"),
 188:("neo.one","ml-IN"),190:("neo.one","mr-IN"),194:("neo.one","ta-IN"),196:("neo.one","te-IN"),
 1190:("candy.two","hi-IN"),1191:("candy.two","hi-IN"),
 1194:("candy.two","en-IN"),1220:("candy.two","bn-IN"),1222:("candy.two","te-IN"),
 1224:("candy.two","ta-IN"),1226:("candy.two","kn-IN"),1228:("candy.two","ml-IN"),
}
def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","sample_rate","audio_streaming","instructions"}, "DUBVERSE_API_KEY")
    if type(config["voice"]) is not int: raise ValueError("voice must be integer speaker_no")
    if _SPEAKERS.get(config["voice"]) != (config["model"],config["language"]): raise ValueError("speaker/model/language combination absent from reviewed subset")
    if config["format"] != "wav": raise UnsupportedFeature("Documented endpoint returns WAV")
    rate=config.get("sample_rate",22050)
    if "sample_rate" in config and config['model']!='neo.one': raise UnsupportedFeature('sample_rate is documented only for neo.one speakers')
    if rate != 22050: raise UnsupportedFeature("Only documented example sample rate tested")
    streaming=config.get("audio_streaming",False)
    if type(streaming) is not bool: raise ValueError("audio_streaming must be bool")
    cfg={"use_streaming_response":streaming}
    if config['model']=='neo.one': cfg['sample_rate']=rate
    if "instructions" in config:
        raise UnsupportedFeature('instructions is documented only for Mermish speakers; none are implemented in this reviewed subset')
    return RequestSpec("POST","https://audio.dubverse.ai/api/tts",{"X-API-KEY":key,"Content-Type":"application/json"},{"text":text,"speaker_no":config["voice"],"config":cfg},sample_rate=rate if config['model']=='neo.one' else None,encoding="wav")
