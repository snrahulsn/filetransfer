"""Resemble synchronous/stream synthesis; voice selects model."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check,key,choice,boolean,nonempty,metadata


def build_request(text,config,env):
    check(text,config,{'model','voice','language','format','sample_rate','precision','mode','use_hd','apply_custom_pronunciations'},
          {'model','voice','language','format','sample_rate','precision','mode'})
    choice(config['model'],{'voice-selected'},'model (vendor automatically selects from voice)')
    choice(config['mode'],{'synthesize','stream'},'mode')
    choice(config['format'],{'wav','mp3'} if config['mode']=='synthesize' else {'wav'},'format')
    choice(config['sample_rate'],{8000,16000,22050,32000,44100,48000},'sample_rate')
    choice(config['precision'],{'MULAW','PCM_16','PCM_24','PCM_32'},'precision')
    if config['format']=='mp3': raise UnsupportedFeature('MP3 with explicit precision not implemented; use WAV')
    nonempty(config['voice'],'voice'); nonempty(config['language'],'language')
    if len(text)>2000: raise ValueError('conservative 2000 character ceiling: synchronous docs conflict at 2000/3000')
    body={'voice_uuid':config['voice'],'data':text,'sample_rate':config['sample_rate'],'precision':config['precision']}
    if config['mode']=='synthesize': body['output_format']=config['format']
    for n in ('use_hd','apply_custom_pronunciations'):
        if n in config: boolean(config[n],n); body[n]=config[n]
    return RequestSpec('POST','https://f.cluster.resemble.ai/'+config['mode'],
        {'Authorization':'Bearer '+key(env,'RESEMBLE_API_KEY'),'Content-Type':'application/json'},body,
        response_mode='json_base64' if config['mode']=='synthesize' else 'binary',audio_path='audio_content' if config['mode']=='synthesize' else None,
        sample_rate=config['sample_rate'],encoding='wav',metadata=metadata(config,language_control='voice/text-selected; requested locale is an evaluation label, not a wire parameter'))
