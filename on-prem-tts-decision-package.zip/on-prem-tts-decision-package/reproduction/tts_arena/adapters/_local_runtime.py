"""Small offline helpers shared by the three optional local model adapters."""
import hashlib
import importlib
import importlib.metadata
import math
from pathlib import Path
import struct

from tts_arena.contracts import UnsupportedFeature


def dependency(name):
    try:
        return importlib.import_module(name)
    except ImportError as exc:
        raise UnsupportedFeature(f'Install the pinned optional local runtime dependency {name}: {exc}') from exc


def validate(text, config, allowed):
    unknown=set(config)-allowed-{'allow_model_download','model_revision','device','format'}
    if unknown:
        raise UnsupportedFeature(f'Local adapter does not implement: {sorted(unknown)}')
    if config.get('allow_model_download',False) is not False:
        raise UnsupportedFeature('This offline adapter never downloads model files; provision the cache separately')
    if not isinstance(text,str) or not text.strip():
        raise ValueError('Non-empty text required')
    if not isinstance(config.get('model_revision'),str) or not config['model_revision'].strip():
        raise ValueError('Explicit model_revision required; returned file hashes identify supplied artifacts')
    if config.get('device') not in ('cpu','cuda','mps'):
        raise ValueError('Explicit device cpu/cuda/mps required')
    if config.get('format')!='pcm_s16le':
        raise UnsupportedFeature('Local adapters return mono pcm_s16le only; no implicit resampling')


def local_path(config,key,directory=False):
    v=config.get(key)
    if not isinstance(v,str) or not v:
        raise UnsupportedFeature(f'Local runtime requires explicit {key}')
    p=Path(v).expanduser()
    if not p.is_absolute():
        raise ValueError(f'{key} must be an absolute local path')
    if not (p.is_dir() if directory else p.is_file()):
        raise UnsupportedFeature(f'Local runtime artifact missing: {key}={p}')
    return str(p.resolve())


def pcm16(audio):
    if hasattr(audio,'detach'):
        audio=audio.detach().cpu()
    if hasattr(audio,'tolist'):
        audio=audio.tolist()
    if isinstance(audio,(list,tuple)) and len(audio)==1 and isinstance(audio[0],(list,tuple)):
        audio=audio[0]
    if not isinstance(audio,(list,tuple)) or not audio:
        raise ValueError('Model returned no mono samples')
    out=bytearray()
    for v in audio:
        if isinstance(v,(list,tuple)) or not isinstance(v,(int,float)) or not math.isfinite(v):
            raise ValueError('Model output must be finite mono samples')
        out.extend(struct.pack('<h',max(-32768,min(32767,round(v*32768)))))
    return bytes(out)


def versions(names):
    result={}
    for name in names:
        try:result[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:result[name]='not_installed_or_test_double'
    return result


def hashes(paths):
    result={}
    for path in paths:
        h=hashlib.sha256()
        with open(path,'rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
        result[path]=h.hexdigest()
    return result
