"""Strict helpers for explicitly scoped global-vendor request builders."""
import math
from tts_arena.contracts import UnsupportedFeature


def check(text, config, allowed, required):
    if not isinstance(text, str) or not text.strip():
        raise ValueError('text must be a non-empty string')
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature('Unimplemented configuration fields: ' + ', '.join(sorted(unknown)))
    for key in required:
        if key not in config or config[key] is None or config[key] == '':
            raise ValueError('Explicit configuration required: ' + key)


def key(env, name):
    value = env.get(name)
    if not isinstance(value, str) or not value.strip() or '\n' in value or '\r' in value:
        raise ValueError('Valid credential required: ' + name)
    return value


def choice(value, choices, name):
    try:
        valid = value in choices
    except TypeError:
        valid = False
    if not valid:
        raise UnsupportedFeature(f'{name} outside implemented subset: {value!r}')


def number(value, low, high, name, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(name + ' must be a finite number')
    if integer and not isinstance(value, int):
        raise ValueError(name + ' must be an integer')
    if not low <= value <= high:
        raise ValueError(f'{name} must be in [{low}, {high}]')


def boolean(value, name):
    if not isinstance(value, bool):
        raise ValueError(name + ' must be boolean')


def nonempty(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(name + ' must be a non-empty string')


def metadata(config, **extra):
    return {'model': config.get('model'), 'voice': config.get('voice'),
            'language': config.get('language'), 'verification': 'not_live_verified', **extra}
