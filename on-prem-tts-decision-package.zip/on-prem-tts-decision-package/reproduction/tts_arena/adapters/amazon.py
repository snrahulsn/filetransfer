"""Polly SynthesizeSpeech: narrow, explicit Indic subset with AWS SigV4.

The signer accepts a canonical constant path and no query; it is not a general
AWS signer. Request body bytes must be transmitted unchanged. Credentials are
provided per build; no profile/metadata credential discovery or refresh occurs.
"""
import hashlib
import hmac
import json
import re
from datetime import datetime, timezone
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check, key, choice, metadata


def _authorization(method, canonical_path, headers, payload, access, secret,
                   region, service, timestamp):
    if not re.fullmatch(r"/[A-Za-z0-9/_-]*", canonical_path):
        raise ValueError("Signer supports canonical ASCII paths without queries only")
    canonical = {k.lower(): " ".join(v.split()) for k, v in headers.items()}
    names = sorted(canonical)
    signed = ";".join(names)
    header_block = "".join(k + ":" + canonical[k] + "\n" for k in names)
    request = "\n".join((method, canonical_path, "", header_block, signed,
                           hashlib.sha256(payload).hexdigest()))
    day = timestamp[:8]
    scope = f"{day}/{region}/{service}/aws4_request"
    to_sign = "\n".join(("AWS4-HMAC-SHA256", timestamp, scope,
                           hashlib.sha256(request.encode()).hexdigest()))
    signing_key = ("AWS4" + secret).encode()
    for part in (day, region, service, "aws4_request"):
        signing_key = hmac.new(signing_key, part.encode(), hashlib.sha256).digest()
    signature = hmac.new(signing_key, to_sign.encode(), hashlib.sha256).hexdigest()
    return (f"AWS4-HMAC-SHA256 Credential={access}/{scope}, "
            f"SignedHeaders={signed}, Signature={signature}")


def build_request(text, config, env):
    required = {"model", "voice", "language", "format", "region", "sample_rate"}
    check(text, config, required | {"lexicon_names"}, required)
    if len(text) > 3000:
        raise UnsupportedFeature("Plain-text subset limited to 3000 characters per request")
    choice(config["region"], {"ap-south-1", "us-east-1", "eu-west-1"}, "region")
    choice(config["model"], {"standard", "neural"}, "engine")
    choice(config["language"], {"en-IN", "hi-IN"}, "language")
    voices = {("standard", "en-IN"): {"Aditi", "Raveena"},
              ("standard", "hi-IN"): {"Aditi"},
              ("neural", "en-IN"): {"Kajal"}, ("neural", "hi-IN"): {"Kajal"}}
    choice(config["voice"], voices[(config["model"], config["language"])], "voice/engine/language")
    formats = {"pcm": ({8000, 16000}, "pcm_s16le"),
               "mp3": ({8000, 16000, 22050, 24000}, "mp3"),
               "ogg_vorbis": ({8000, 16000, 22050, 24000}, "ogg_vorbis"),
               "mulaw": ({8000}, "mulaw"), "alaw": ({8000}, "alaw")}
    choice(config["format"], formats, "format")
    rates, encoding = formats[config["format"]]
    rate = config["sample_rate"]
    if type(rate) is not int:
        raise ValueError("sample_rate must be an integer")
    choice(rate, rates, "format/sample_rate")
    body = {"Engine": config["model"], "VoiceId": config["voice"],
            "LanguageCode": config["language"], "OutputFormat": config["format"],
            "SampleRate": str(rate), "Text": text, "TextType": "text"}
    if "lexicon_names" in config:
        lexicons = config["lexicon_names"]
        if not isinstance(lexicons, list) or len(lexicons) > 5 or any(
                not isinstance(x, str) or not re.fullmatch(r"[0-9A-Za-z]{1,20}", x) for x in lexicons):
            raise ValueError("lexicon_names must contain at most five alphanumeric names of 1-20 characters")
        body["LexiconNames"] = lexicons
    payload = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    host = f"polly.{config['region']}.amazonaws.com"
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    headers = {"Host": host, "Content-Type": "application/json", "X-Amz-Date": timestamp}
    if "AWS_SESSION_TOKEN" in env:
        headers["X-Amz-Security-Token"] = key(env, "AWS_SESSION_TOKEN")
    headers["Authorization"] = _authorization("POST", "/v1/speech", headers, payload,
        key(env, "AWS_ACCESS_KEY_ID"), key(env, "AWS_SECRET_ACCESS_KEY"),
        config["region"], "polly", timestamp)
    return RequestSpec("POST", f"https://{host}/v1/speech", headers, payload,
        sample_rate=rate, encoding=encoding,
        metadata=metadata(config, region=config["region"], signature_version="AWS4-HMAC-SHA256",
                          scope="plain text; build immediately before dispatch; caller refreshes credentials"))
