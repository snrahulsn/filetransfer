"""NVIDIA NIM HTTP adapter; requires an explicitly selected deployed server."""
from urllib.parse import urlsplit
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text, config, env):
    allowed={'endpoint','allow_endpoint_override','model','voice','language','format','sample_rate','custom_dictionary'}
    if set(config)-allowed:
        raise UnsupportedFeature(f'NIM HTTP adapter does not implement: {sorted(set(config)-allowed)}')
    if not isinstance(text,str) or not text.strip() or len(text)>2000:
        raise ValueError('text must contain 1-2000 characters; server also checks normalized length')
    for k in ('endpoint','model','voice','language','format','sample_rate'):
        if k not in config or config[k] in ('',None):
            raise ValueError(f'Explicit {k} required')
    if config.get('allow_endpoint_override') is not True:
        raise ValueError('Explicit allow_endpoint_override=true required for your NIM deployment')
    u=urlsplit(config['endpoint'])
    if u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
        raise ValueError('endpoint must be an origin without credentials/path/query')
    if not u.hostname or not (u.scheme=='https' or (u.scheme=='http' and u.hostname in {'localhost','127.0.0.1','::1'})):
        raise ValueError('HTTPS required except loopback NIM')
    if config['model']!='magpie-tts-multilingual':
        raise UnsupportedFeature('This adapter covers deployed magpie-tts-multilingual only')
    if config['language'] not in {'en-US','es-US','fr-FR','de-DE','zh-CN','vi-VN','it-IT','hi-IN','ja-JP','ko-KR','ar-XA','pt-BR'}:
        raise UnsupportedFeature('Locale outside reviewed Magpie NIM support matrix')
    if config['format'] not in ('wav','pcm_s16le'):
        raise UnsupportedFeature('NIM HTTP supports WAV offline or raw LPCM online only')
    rate=config['sample_rate']
    if type(rate) is not int or rate<=0:
        raise ValueError('sample_rate must be a positive integer; deployed server validates supported rates')
    values={'text':text,'language':config['language'],'voice':config['voice'],'sample_rate_hz':str(rate),'encoding':'LINEAR_PCM'}
    if 'custom_dictionary' in config:
        if not isinstance(config['custom_dictionary'],str):
            raise ValueError('custom_dictionary must be the documented rules string')
        values['custom_dictionary']=config['custom_dictionary']
    if not isinstance(config['voice'],str):
        raise ValueError('voice must be an exact list_voices value')
    boundary='tts-arena-nim-boundary-v1'
    if any(boundary in v for v in values.values()):
        raise ValueError('Input collides with multipart boundary')
    parts=[]
    for name,value in values.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n')
    body=(''.join(parts)+f'--{boundary}--\r\n').encode('utf-8')
    path='/v1/audio/synthesize_online' if config['format']=='pcm_s16le' else '/v1/audio/synthesize'
    return RequestSpec('POST',config['endpoint'].rstrip('/')+path,
                       {'Content-Type':'multipart/form-data; boundary='+boundary},body,sample_rate=rate,encoding=config['format'],
                       metadata={'expected_deployment_model':config['model'],'requires_model_discovery':True,'certification':'not_live_verified'})
