"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","sample_rate","speed","pitch"}, "REVERIE_API_KEY")
    app=env.get("REVERIE_APP_ID")
    if not app or "\n" in app or "\r" in app: raise ValueError("REVERIE_APP_ID required")
    if config["model"] != "tts": raise UnsupportedFeature("Reverie endpoint exposes appname tts; no model selector")
    lang=config["language"].split("-")[0]
    if config["language"] not in "en-IN hi-IN bn-IN mr-IN te-IN ta-IN gu-IN kn-IN ml-IN pa-IN".split(): raise ValueError("language")
    if config["voice"] not in (lang+"_male",lang+"_female"): raise UnsupportedFeature("Adapter reviewed subset is base male/female voice IDs")
    fmt=config["format"]
    if fmt not in ("WAV","MP3","FLAC","OGG","OPUS","PCM"): raise ValueError("format")
    rate=config.get("sample_rate",22050)
    if rate not in (8000,16000,22050,24000,44100,48000): raise ValueError("sample_rate")
    body={"text":text,"format":fmt,"sample_rate":rate}
    if "speed" in config: body["speed"]=_range(config["speed"],.5,1.5,"speed")
    if "pitch" in config: body["pitch"]=_range(config["pitch"],-3,3,"pitch")
    return RequestSpec("POST","https://revapi.reverieinc.com/",{"REV-API-KEY":key,"REV-APP-ID":app,"REV-APPNAME":"tts","speaker":config["voice"],"Content-Type":"application/json"},body,sample_rate=rate,encoding=fmt.lower(),metadata={"response_content_type_requires_live_check":True})
