"""Qwen3 non-realtime HTTP synthesis; returned URL download is host constrained."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text,config,env):
    allowed={'model','voice','language','region','allow_download_hosts'}
    if set(config)-allowed:
        raise UnsupportedFeature(f'Qwen HTTP does not implement these controls: {sorted(set(config)-allowed)}')
    if not isinstance(text,str) or not text.strip() or len(text)>600:
        raise ValueError('Qwen3 text must contain 1-600 characters')
    for k in ('model','voice','language','region','allow_download_hosts'):
        if k not in config or not config[k]:
            raise ValueError(f'Explicit {k} required')
    if config['model'] not in {'qwen3-tts-flash','qwen3-tts-flash-2025-11-27','qwen3-tts-flash-2025-09-18'}:
        raise UnsupportedFeature('This adapter covers Qwen3-TTS-Flash HTTP only')
    if config['language'] not in {'Auto','Chinese','English','German','Italian','Portuguese','Spanish','Japanese','Korean','French','Russian'}:
        raise UnsupportedFeature('Language outside documented Qwen3-TTS list; Hindi is not supported')
    if not isinstance(config['voice'],str):
        raise ValueError('voice must be string')
    hosts=config['allow_download_hosts']
    if not isinstance(hosts,list) or not hosts or not all(isinstance(h,str) and '.' in h and all(c.isalnum() or c in '.-' for c in h) for h in hosts):
        raise ValueError('allow_download_hosts requires explicit exact hostnames; no wildcard or URL')
    base={'singapore':'https://dashscope-intl.aliyuncs.com','beijing':'https://dashscope.aliyuncs.com'}
    if config['region'] not in base:
        raise ValueError('region must be singapore or beijing')
    if not env.get('DASHSCOPE_API_KEY'):
        raise ValueError('Region-specific DASHSCOPE_API_KEY required')
    return RequestSpec('POST',base[config['region']]+'/api/v1/services/aigc/multimodal-generation/generation',
                       {'Authorization':'Bearer '+env['DASHSCOPE_API_KEY'],'Content-Type':'application/json'},
                       {'model':config['model'],'input':{'text':text,'voice':config['voice'],'language_type':config['language']}},
                       response_mode='json_url',audio_path='output.audio.url',encoding='wav',
                       metadata={'download_hosts':list(hosts),'streaming':False,'certification':'not_live_verified'})
