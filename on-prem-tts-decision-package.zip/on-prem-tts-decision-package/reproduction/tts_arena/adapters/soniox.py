"""Soniox tts-rt-v2 REST request subset, pinned to reviewed API fields."""
from __future__ import annotations

import math
from tts_arena.contracts import RequestSpec, UnsupportedFeature

LOCALES = {"en-IN":"en","hi-IN":"hi","bn-IN":"bn","mr-IN":"mr","te-IN":"te",
           "ta-IN":"ta","gu-IN":"gu","ur-IN":"ur","kn-IN":"kn","ml-IN":"ml"}
SAMPLE_RATES = {8000, 16000, 24000, 44100, 48000}
VOICES = {"Arjun","Rohan","Priya","Kavya","Aarav","Dev","Nikhil","Ashok","Ishita",
          "Aman","Shalini","Manav","Nisha","Karthik","Meena","Vani","Surya","Deepa",
          "Sundar","Gurpreet","Madhura","Venkat","Rajan","Lekha","Sneha","Bhavana",
          "Mohan","Divya"}


def build_request(text, config, env):
    if not isinstance(text,str) or not text.strip() or len(text)>5000:
        raise ValueError("Soniox text must be 1..5000 characters")
    allowed={"model","voice","language","format","sample_rate","speed","reduce_silence","region"}
    unknown=set(config)-allowed
    if unknown: raise UnsupportedFeature(f"Soniox REST adapter does not implement {sorted(unknown)}")
    for field in ("model","voice","language","format"):
        if not isinstance(config.get(field),str) or not config[field]:raise ValueError(f"Explicit {field} required")
    if config["model"]!="tts-rt-v2":
        raise UnsupportedFeature("Only active tts-rt-v2 is evaluated; no v1 fallback")
    if config["language"] not in LOCALES:
        raise UnsupportedFeature("Use one of the ten reviewed requested locales")
    if config["voice"] not in VOICES:
        raise UnsupportedFeature("Choose a discovered Indian-accent built-in voice; cloned IDs require separate enrollment")
    if config["format"]!="wav":
        raise UnsupportedFeature("This REST evidence route uses PCM WAV only")
    rate=config.get("sample_rate",24000)
    if type(rate) is not int or rate not in SAMPLE_RATES:raise ValueError("Invalid WAV sample_rate")
    region=config.get("region","global")
    if region not in {"global","in"}:raise UnsupportedFeature("Only global and India domains mapped")
    key=env.get("SONIOX_API_KEY")
    if not isinstance(key,str) or not key or "\n" in key or "\r" in key:raise ValueError("SONIOX_API_KEY required")
    body={"model":"tts-rt-v2","language":LOCALES[config["language"]],"voice":config["voice"],
          "audio_format":"wav","sample_rate":rate,"text":text}
    if "speed" in config:
        speed=config["speed"]
        if type(speed) not in (int,float) or not math.isfinite(speed) or not .7<=speed<=1.3:
            raise ValueError("Soniox speed must be 0.7..1.3")
        body["speed"]=speed
    if "reduce_silence" in config:
        if type(config["reduce_silence"]) is not bool:raise ValueError("reduce_silence must be boolean")
        body["reduce_silence"]=config["reduce_silence"]
    host="tts-rt.in.soniox.com" if region=="in" else "tts-rt.soniox.com"
    return RequestSpec("POST",f"https://{host}/tts",
                       {"Authorization":"Bearer "+key,"Content-Type":"application/json","Accept":"audio/wav"},
                       body,response_mode="binary",sample_rate=rate,encoding="wav",
                       metadata={"model":"tts-rt-v2","voice":config["voice"],"locale_wire":LOCALES[config["language"]],
                                 "region":region,"certification":"not_native_quality_verified"})
