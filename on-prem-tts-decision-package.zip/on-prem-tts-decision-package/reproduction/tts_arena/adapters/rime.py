"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","sample_rate","timeScaleFactor"}, "RIME_API_KEY")
    if config["model"]!="coda": raise UnsupportedFeature("This adapter implements Coda HTTP only")
    if len(text)>1000: raise ValueError("Coda maximum 1000 characters")
    if not isinstance(config["voice"],str): raise ValueError("voice ID must be string")
    langs={"en-IN":"en","en-US":"en","hi-IN":"hi"}
    if config["language"] not in langs: raise UnsupportedFeature("Only English and Hindi in reviewed subset")
    formats={"wav":"audio/wav","mp3":"audio/mpeg","pcm_s16le":"audio/L16","ulaw":"audio/PCMU","webm":"audio/webm;codecs=opus","ogg":"audio/ogg;codecs=opus"}
    if config["format"] not in formats: raise ValueError("format")
    rate=config.get("sample_rate",24000)
    if type(rate) is not int or rate<=0: raise ValueError("positive sample_rate required")
    body={"text":text,"speaker":config["voice"],"modelId":"coda","lang":langs[config["language"]],"samplingRate":rate}
    if "timeScaleFactor" in config: body["timeScaleFactor"]=_range(config["timeScaleFactor"],.4,2.5,"timeScaleFactor")
    return RequestSpec("POST","https://users.rime.ai/v1/rime-tts",{"Authorization":"Bearer "+key,"Content-Type":"application/json","Accept":formats[config["format"]]},body,sample_rate=rate,encoding=config["format"],metadata={"indian_accent_requires_voice_catalog_check":config["language"]=="en-IN"})
