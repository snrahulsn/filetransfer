"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def _v1_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format"}, "FONADA_API_KEY")
    if config["model"] != "fonada-v1": raise UnsupportedFeature("Klone V2 Pro requires multipart /v1/voice-clone/chunks; not implemented here")
    if len(text)>450: raise ValueError("Fonada V1 maximum 450 characters")
    if config["format"] != "wav": raise UnsupportedFeature("Current Fonada V1 HTTP contract returns WAV; MP3 requests are not silently substituted")
    langs={"hi-IN":"Hindi","ta-IN":"Tamil","te-IN":"Telugu","en-IN":"English"}
    if config["language"] not in langs: raise ValueError("Fonada V1 supports four languages only")
    if not isinstance(config["voice"],str): raise ValueError("voice name string required")
    return RequestSpec("POST","https://api.fonada.ai/tts/generate-audio-large",{"Authorization":"Bearer "+key,"Content-Type":"application/json"},{"input":text,"voice":config["voice"],"language":langs[config["language"]]},sample_rate=24000,encoding="wav",metadata={"accent_requires_listener_validation":True,"protocol_profile":"v1-http-current-docs"})

def build_request(text, config, env):
    if config.get("model") != "klone-v2-pro":
        return _v1_request(text, config, env)
    key=_validate(text,config,env,{"model","voice","language","format","speed","instruct"},"FONADA_API_KEY")
    voice=config["voice"]
    if not isinstance(voice,str) or len(voice)!=8 or not voice.isascii() or not voice.isalnum(): raise ValueError("Klone voice must be eight-character share_id")
    # Exact codes observed from authenticated /v1/voice-clone/languages on 2026-09-15.
    languages={"hi-IN":"hi","en-IN":"en","ta-IN":"ta","bn-IN":"bn","mr-IN":"mr","te-IN":"te","gu-IN":"gu","ur-IN":"ur","kn-IN":"kn","ml-IN":"ml"}
    if config["language"] not in languages: raise UnsupportedFeature("Language outside the reviewed Klone target-locale subset")
    fmt=config["format"]
    if fmt not in ("wav","mp3","opus","pcm","mulaw","alaw"): raise ValueError("Klone format")
    if fmt in ("mp3","opus") and len(text)>450: raise ValueError("MP3/Opus maximum450 characters")
    fields={"share_id":voice,"text":text,"language":languages[config["language"]],"output_audio_codec":fmt}
    if "speed" in config: fields["speed"]=str(_range(config["speed"],.25,4,"speed"))
    if "instruct" in config:
        if not isinstance(config["instruct"],str): raise ValueError("instruct string required")
        fields["instruct"]=config["instruct"]
    # A deterministic non-colliding boundary makes the request auditable.
    import hashlib
    boundary="tts-arena-"+hashlib.sha256(repr(fields).encode()).hexdigest()
    while any(boundary in value for value in fields.values()): boundary += "x"
    body=b"".join((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode("utf-8") for name,value in fields.items())
    body+=f"--{boundary}--\r\n".encode()
    rate=8000 if fmt in ("mulaw","alaw") else 48000 if fmt=="opus" else 24000
    return RequestSpec("POST","https://api.fonada.ai/v1/voice-clone/chunks",{"Authorization":"Bearer "+key,"Content-Type":"multipart/form-data; boundary="+boundary},body,sample_rate=rate,encoding="pcm_s16le" if fmt=="pcm" else fmt,metadata={"voice_source":"share_id","indian_accent_requires_listener_validation":config["language"]=="en-IN"})
