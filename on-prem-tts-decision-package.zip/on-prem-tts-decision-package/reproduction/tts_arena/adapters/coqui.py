"""Explicit runtime prerequisite gate; not an inference implementation."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def build_request(text, config, env):
    raise UnsupportedFeature('Local TTS/XTTS runtime, compatible pinned checkpoint, conditioning audio, and applicable CPML deployment rights are required. No current hosted Coqui API is assumed. Local inference is not implemented in this HTTP adapter.')


def synthesize_local(text,config):
    import time
    started=time.perf_counter()
    from ._local_runtime import validate,local_path,dependency,pcm16,versions,hashes
    validate(text,config,{'model','language','config_path','weights_path','vocab_path','reference_audio_path','speed'})
    if config.get('model')!='coqui/XTTS-v2':
        raise UnsupportedFeature('Only coqui/XTTS-v2 implemented')
    language={'en':'en','en-US':'en','en-GB':'en','hi':'hi','hi-IN':'hi'}.get(config.get('language'))
    if language is None:
        raise UnsupportedFeature('Reviewed local path supports English/Hindi; Indian English accent remains unverified')
    files=[local_path(config,k) for k in ('config_path','weights_path','vocab_path','reference_audio_path')]
    speed=config.get('speed',1.0)
    if type(speed) not in (int,float) or not .5<=speed<=2:
        raise ValueError('Arena tested speed range is [.5,2]')
    provenance=hashes(files)
    Config=dependency('TTS.tts.configs.xtts_config').XttsConfig
    Model=dependency('TTS.tts.models.xtts').Xtts
    model_config=Config()
    model_config.load_json(files[0])
    if language not in model_config.languages:
        raise UnsupportedFeature('Supplied checkpoint does not list the requested language')
    model=Model.init_from_config(model_config)
    model.load_checkpoint(model_config,checkpoint_path=files[1],vocab_path=files[2],eval=True,use_deepspeed=False)
    model.to(config['device']).eval()
    initialized=time.perf_counter()
    # Include conditioning in synthesis cost rather than silently assuming a warm cache.
    conditioning,speaker=model.get_conditioning_latents(audio_path=[files[3]])
    out=model.inference(text,language,conditioning,speaker,speed=speed)
    completed=time.perf_counter()
    return {'audio':pcm16(out['wav']),'sample_rate':24000,'encoding':'pcm_s16le',
            'model_revision':config['model_revision'],'dependency_versions':versions(['TTS','torch']),
            'artifact_sha256':provenance,'initialization_seconds':initialized-started,
            'synthesis_seconds':completed-initialized,'conditioning_included':True,'streaming':False,'certification':'not_live_verified'}
