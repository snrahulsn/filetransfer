"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","sample_rate","pace","temperature","dict_id"}, "SARVAM_API_KEY")
    if config["model"] != "bulbul:v3":
        raise UnsupportedFeature("This adapter implements bulbul:v3 REST only")
    if len(text) > 2500: raise ValueError("bulbul:v3 text maximum is 2500 characters")
    voices = "shubh aditya ritu priya neha rahul pooja rohan simran kavya amit dev ishita shreya ratan varun manan sumit roopa kabir aayan ashutosh advait anand tanya tarun sunny mani gokul vijay shruti suhani mohit kavitha rehan soham rupali".split()
    if config["voice"] not in voices: raise ValueError("voice not in reviewed bulbul:v3 catalog")
    if config["language"] not in "en-IN hi-IN bn-IN mr-IN te-IN ta-IN gu-IN kn-IN ml-IN pa-IN".split(): raise ValueError("unsupported language")
    if config["format"] != "wav": raise UnsupportedFeature("REST adapter currently validates WAV only")
    rate = config.get("sample_rate", 24000)
    if rate not in (8000,16000,22050,24000,32000,44100,48000): raise ValueError("sample_rate")
    body = {"text":text,"language_code":config["language"],"speaker":config["voice"],"model":"bulbul:v3","output_audio_codec":"wav","speech_sample_rate":rate}
    if "pace" in config: body["pace"] = _range(config["pace"],.5,2,"pace")
    if "temperature" in config: body["temperature"] = _range(config["temperature"],.01,2,"temperature")
    if "dict_id" in config:
        if not isinstance(config["dict_id"],str) or not config["dict_id"]: raise ValueError("dict_id")
        body["dict_id"] = config["dict_id"]
    return RequestSpec("POST","https://api.sarvam.ai/text-to-speech",{"api-subscription-key":key,"Content-Type":"application/json"},body,response_mode="json_base64",audio_path="audios.0",sample_rate=rate,encoding="wav")
