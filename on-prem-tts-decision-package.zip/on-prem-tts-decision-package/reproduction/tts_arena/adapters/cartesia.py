"""Cartesia bytes API pinned to 2026-08-14 request shape."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check,key,choice,number,nonempty,metadata


def build_request(text,config,env):
    check(text,config,{'model','voice','language','format','sample_rate','encoding','speed','volume','emotion','normalization','pronunciation_dict_id'}, {'model','voice','language','format','sample_rate','encoding'})
    choice(config['model'],{'sonic-3.6','sonic-3.6-2026-08-27'},'model subset')
    nonempty(config['voice'],'voice')
    choice(config['language'],{'en-IN','hi-IN','bn-IN','mr-IN','te-IN','ta-IN','gu-IN','ur-IN','kn-IN','ml-IN','en','hi'},'language')
    choice(config['format'],{'raw','wav'},'container subset')
    choice(config['encoding'],{'pcm_s16le','pcm_f32le','pcm_mulaw','pcm_alaw'},'encoding')
    choice(config['sample_rate'],{8000,16000,22050,24000,44100,48000},'sample_rate')
    if config['format']=='wav' and config['encoding']!='pcm_s16le': raise UnsupportedFeature('WAV subset implements pcm_s16le only')
    body={'model_id':config['model'],'transcript':text,'voice':config['voice'],'locale':config['language'],
        'output_format':{'container':config['format'],'encoding':config['encoding'],'sample_rate':config['sample_rate']}}
    generation={}
    for n,lo,hi in [('speed',.6,1.5),('volume',.5,2)]:
        if n in config: number(config[n],lo,hi,n); generation[n]=config[n]
    if 'emotion' in config:
        if not config['language'].startswith('en'): raise UnsupportedFeature('Emotion guidance only documented for English')
        choice(config['emotion'],{'neutral','calm','angry','content','sad','scared'},'implemented primary emotion subset'); generation['emotion']=config['emotion']
    if generation: body['generation_config']=generation
    for n in ('normalization','pronunciation_dict_id'):
        if n in config: nonempty(config[n],n); body[n]=config[n]
    if 'normalization' in config:
        choice(config['normalization'],{'auto','off','en','hi','bn','mr','te','ta','gu','ur','kn','ml','en-IN','hi-IN','bn-IN','mr-IN','te-IN','ta-IN','gu-IN','ur-IN','kn-IN','ml-IN'},'normalization reviewed mode/locale')
    response_encoding={'pcm_mulaw':'mulaw','pcm_alaw':'alaw'}.get(config['encoding'],config['encoding'])
    return RequestSpec('POST','https://api.cartesia.ai/tts/bytes',{'Authorization':'Bearer '+key(env,'CARTESIA_API_KEY'),
        'Cartesia-Version':'2026-08-14','Content-Type':'application/json'},body,sample_rate=config['sample_rate'],
        encoding='wav' if config['format']=='wav' else response_encoding,metadata=metadata(config,scope='complete text / streamed response; accent requires compatible voice; WS controls not implemented'))
