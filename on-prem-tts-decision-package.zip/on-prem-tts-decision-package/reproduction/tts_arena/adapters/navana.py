"""Navana TTS access is not defined by the public Bodhi ASR contract."""
from tts_arena.contracts import UnsupportedFeature

def build_request(text, config, env):
    raise UnsupportedFeature("Navana Bodhi TTS requires vendor-issued TTS endpoint, authentication, model/voice catalog and response protocol; public Bodhi docs inspected are ASR only. TTS API platform currently advertises waitlist access.")
