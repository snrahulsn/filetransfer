"""Inworld synchronous HTTP; no silent substitution of streaming APIs."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text, config, env):
    allowed = {'model', 'voice', 'language', 'format', 'sample_rate', 'speed', 'region', 'instruction', 'delivery_mode', 'timestamp_type'}
    if set(config) - allowed:
        raise UnsupportedFeature(f'Inworld adapter does not implement: {sorted(set(config)-allowed)}')
    if not isinstance(text, str) or not text.strip() or len(text) > 2000:
        raise ValueError('text must contain 1-2000 characters')
    for key in ('model', 'voice', 'language', 'format', 'sample_rate'):
        if key not in config or config[key] in ('', None):
            raise ValueError(f'Explicit {key} required')
    if config['model'] not in {'inworld-tts-2', 'inworld-tts-2-flash'}:
        raise UnsupportedFeature('This adapter pins the TTS-2 family only')
    for key in ('voice', 'language'):
        if not isinstance(config[key], str):
            raise ValueError(f'{key} must be a string')
    fmt = config['format']
    if fmt not in {'LINEAR16', 'MP3', 'OGG_OPUS', 'ALAW', 'MULAW', 'FLAC', 'PCM', 'WAV'}:
        raise ValueError('Use exact Inworld audioEncoding enum')
    rate = config['sample_rate']
    if type(rate) is not int or rate not in {8000, 16000, 22050, 24000, 32000, 44100, 48000}:
        raise ValueError('Unsupported sample_rate')
    audio = {'audioEncoding': fmt, 'sampleRateHertz': rate}
    if 'speed' in config:
        speed = config['speed']
        if type(speed) not in (float, int) or not .5 <= speed <= 1.5:
            raise ValueError('speed must be in [.5,1.5]')
        audio['speakingRate'] = speed
    controls = {}
    for key in ('instruction', 'delivery_mode'):
        if key in config and config['model'] != 'inworld-tts-2':
            raise UnsupportedFeature(f'{key} is ignored by TTS-2-flash; refusing silent discard')
    if 'instruction' in config:
        if not isinstance(config['instruction'], str):
            raise ValueError('instruction must be an English speaking-style string; empty means unset')
        controls['instruction'] = config['instruction']
    if 'delivery_mode' in config:
        if not isinstance(config['delivery_mode'], str) or config['delivery_mode'] not in {'DELIVERY_MODE_UNSPECIFIED', 'STABLE', 'BALANCED', 'CREATIVE'}:
            raise ValueError('Use exact deliveryMode enum')
        controls['deliveryMode'] = config['delivery_mode']
    if 'timestamp_type' in config:
        if not isinstance(config['timestamp_type'],str) or config['timestamp_type'] not in {'WORD','CHARACTER','TIMESTAMP_TYPE_UNSPECIFIED'}:raise ValueError('Use exact timestampType enum')
        controls['timestampType']=config['timestamp_type']
    if not env.get('INWORLD_API_KEY'):
        raise ValueError('INWORLD_API_KEY required (already encoded Basic credential)')
    regions={'us':'api.inworld.ai','eu':'api.eu.inworld.ai','india':'api.in.inworld.ai'}
    region=config.get('region','us')
    if region not in regions:
        raise ValueError('region must be us/eu/india; regional keys and Enterprise access required')
    return RequestSpec('POST', 'https://'+regions[region]+'/tts/v1/voice',
                       {'Authorization': 'Basic ' + env['INWORLD_API_KEY'], 'Content-Type': 'application/json'},
                       {'text': text, 'voiceId': config['voice'], 'modelId': config['model'], 'language': config['language'], 'audioConfig': audio, **controls},
                       response_mode='json_base64', audio_path='audioContent', sample_rate=rate,
                       encoding={'PCM':'pcm_s16le','LINEAR16':'wav','WAV':'wav','MULAW':'mulaw','ALAW':'alaw'}.get(fmt,fmt.lower()),
                       metadata={'streaming': False, 'certification':'not_live_verified', **({'json_metadata_decoder_module':__name__, 'requested_timestamp_type':config['timestamp_type']} if config.get('timestamp_type') in {'WORD','CHARACTER'} else {})})


def decode_json_metadata(value,metadata):
    """Retain only validated timing fields; WORD includes whitespace/punctuation tokens."""
    import math
    mode=metadata['requested_timestamp_type']
    info=value.get('timestampInfo')
    if not isinstance(info,dict):raise ValueError('Requested timestampInfo missing')
    branch='wordAlignment' if mode=='WORD' else 'characterAlignment'
    row=info.get(branch)
    if not isinstance(row,dict):raise ValueError('Requested alignment missing')
    labels,starts,ends=('words','wordStartTimeSeconds','wordEndTimeSeconds') if mode=='WORD' else ('characters','characterStartTimeSeconds','characterEndTimeSeconds')
    def number(v):
        if type(v) not in (int,float) or not math.isfinite(v) or v<0:raise ValueError('Invalid timestamp number')
        return v
    arrays=[row.get(k) for k in (labels,starts,ends)]
    if any(not isinstance(a,list) for a in arrays) or len({len(a) for a in arrays})!=1 or not 0<len(arrays[0])<=10000:raise ValueError('Missing or inconsistent timing arrays')
    if any(not isinstance(v,str) for v in arrays[0]):raise ValueError('Invalid label')
    for a,b in zip(arrays[1],arrays[2]):
        if number(b)<number(a):raise ValueError('Reversed alignment interval')
    clean={k:row[k] for k in (labels,starts,ends)}
    if mode=='CHARACTER' and ('phoneticDetails' in row or 'phoneticDetails' in info):raise ValueError('Phonetics are WORD only')
    if mode=='WORD' and 'phoneticDetails' in row:
        details=row['phoneticDetails']
        if not isinstance(details,list) or len(details)>10000:raise ValueError('Invalid phonetic details')
        clean['phoneticDetails']=[]
        for entry in details:
            if not isinstance(entry,dict) or type(entry.get('wordIndex')) is not int or not 0<=entry['wordIndex']<len(arrays[0]):raise ValueError('Invalid wordIndex')
            phones=entry.get('phones')
            if not isinstance(phones,list) or len(phones)>1000:raise ValueError('Invalid phones')
            item={'wordIndex':entry['wordIndex'],'phones':[]}
            if 'isPartial' in entry:
                if type(entry['isPartial']) is not bool:raise ValueError('Invalid partial flag')
                item['isPartial']=entry['isPartial']
            for phone in phones:
                if not isinstance(phone,dict) or any(not isinstance(phone.get(k),str) for k in ('phoneSymbol','visemeSymbol')):raise ValueError('Invalid phonetic symbols')
                item['phones'].append({k:phone[k] for k in ('phoneSymbol','visemeSymbol','startTimeSeconds','durationSeconds')})
                number(phone['startTimeSeconds']);number(phone['durationSeconds'])
            clean['phoneticDetails'].append(item)
    return {'timestampInfo':{branch:clean},'timestamp_type':mode,'time_unit':'seconds','time_origin':'synthesis_start','alignment_accuracy':'unverified'}
