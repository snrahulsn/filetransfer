"""Provider-specific request builders; conformance states are separate from code presence."""
