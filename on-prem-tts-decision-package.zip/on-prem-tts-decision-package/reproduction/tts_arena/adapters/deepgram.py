"""Strict Aura v1 and Indian-accent Flux TTS v2 batch REST subsets."""
from urllib.parse import urlencode
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check,key,choice,number,boolean,metadata


def build_request(text,config,env):
    if config.get('model') in {'flux-meena-en','flux-naveen-en','flux-priya-en'}:
        check(text,config,{'model','voice','language','format','sample_rate'}, {'model','voice','language','format','sample_rate'})
        if config['voice'] != config['model']:
            raise ValueError('Deepgram Flux voice is encoded in model; set voice equal to model')
        choice(config['language'],{'en-IN'},'documented Indian English Flux voice scope')
        choice(config['format'],{'linear16'},'Flux batch output subset')
        choice(config['sample_rate'],{24000},'Flux batch sample rate subset')
        query={'model':config['model'],'encoding':'linear16','container':'wav','sample_rate':24000}
        return RequestSpec('POST','https://api.deepgram.com/v2/speak?'+urlencode(query),
            {'Authorization':'Token '+key(env,'DEEPGRAM_API_KEY'),'Content-Type':'application/json'}, {'text':text},
            sample_rate=24000,encoding='pcm_s16le',metadata=metadata(config,transport='batch_rest'))
    check(text,config,{'model','voice','language','format','sample_rate','speed','mip_opt_out'}, {'model','voice','language','format','sample_rate'})
    choice(config['model'],{'aura-2-thalia-en','aura-2-andromeda-en','aura-2-helena-en','aura-2-apollo-en'},'implemented model subset')
    if config['voice'] != config['model']:
        raise ValueError('Deepgram voice is encoded in model; set voice equal to model')
    choice(config['language'],{'en','en-US'},'Aura language/accent; Indian English not documented')
    choice(config['format'],{'linear16','mulaw','alaw'},'encoding subset')
    choice(config['sample_rate'],{8000} if config['format'] in {'mulaw','alaw'} else {8000,16000,24000,32000,48000},'sample_rate')
    query={'model':config['model'],'encoding':config['format'],'container':'none','sample_rate':config['sample_rate']}
    if 'speed' in config: number(config['speed'],.7,1.5,'speed'); query['speed']=config['speed']
    if 'mip_opt_out' in config: boolean(config['mip_opt_out'],'mip_opt_out'); query['mip_opt_out']=str(config['mip_opt_out']).lower()
    return RequestSpec('POST','https://api.deepgram.com/v1/speak?'+urlencode(query),
        {'Authorization':'Token '+key(env,'DEEPGRAM_API_KEY'),'Content-Type':'application/json'}, {'text':text},
        sample_rate=config['sample_rate'],encoding='pcm_s16le' if config['format']=='linear16' else config['format'],metadata=metadata(config))
