"""Fish REST single-speaker adapter; canonical OpenAPI, reviewed 2026-09-15."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text, config, env):
    allowed = {'model', 'voice', 'language', 'format', 'sample_rate', 'speed',
               'temperature', 'top_p', 'chunk_length', 'latency', 'normalize'}
    unknown = set(config) - allowed
    if unknown:
        raise UnsupportedFeature(f'Fish adapter does not implement: {sorted(unknown)}')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('Non-empty text required')
    for key in ('model', 'voice', 'language', 'format', 'sample_rate'):
        if key not in config or config[key] in ('', None):
            raise ValueError(f'Explicit {key} required')
    model = config['model']
    if model not in {'s1', 's2-pro', 's2.1-pro', 's2.1-pro-free', 'drama-3-preview'}:
        raise ValueError('Unknown Fish model; vendor otherwise silently falls back')
    if config['language'] != 'auto':
        raise UnsupportedFeature('Fish REST has no language selector; use language=auto and label fixture language separately')
    if not isinstance(config['voice'], str):
        raise UnsupportedFeature('This adapter implements a single reference_id only')
    formats = {'pcm': {8000, 16000, 24000, 32000, 44100},
               'wav': {8000, 16000, 24000, 32000, 44100},
               'mp3': {32000, 44100}, 'opus': {48000}}
    fmt, rate = config['format'], config['sample_rate']
    if fmt not in formats or type(rate) is not int or rate not in formats[fmt]:
        raise ValueError('Unsupported format/sample_rate combination')
    body = {'text': text, 'reference_id': config['voice'], 'format': fmt, 'sample_rate': rate}
    for key in ('temperature', 'top_p'):
        if key in config:
            v = config[key]
            if type(v) not in (int, float) or not 0 <= v <= 1:
                raise ValueError(f'{key} must be in [0,1]')
            body[key] = v
    if 'speed' in config:
        v = config['speed']
        if type(v) not in (int, float) or not .5 <= v <= 2:
            raise ValueError('speed must be in [.5,2]')
        body['prosody'] = {'speed': v}
    if 'chunk_length' in config:
        v = config['chunk_length']
        if type(v) is not int or not 100 <= v <= 300:
            raise ValueError('chunk_length must be integer in [100,300]')
        body['chunk_length'] = v
    if 'latency' in config:
        if config['latency'] not in {'normal', 'balanced', 'low'}:
            raise ValueError('Invalid latency setting')
        body['latency'] = config['latency']
    if 'normalize' in config:
        if type(config['normalize']) is not bool:
            raise ValueError('normalize must be boolean')
        body['normalize'] = config['normalize']
    if not env.get('FISH_API_KEY'):
        raise ValueError('FISH_API_KEY required')
    return RequestSpec('POST', 'https://api.fish.audio/v1/tts',
                       {'Authorization': 'Bearer ' + env['FISH_API_KEY'], 'Content-Type': 'application/json', 'model': model},
                       body, sample_rate=rate, encoding='pcm_s16le' if fmt == 'pcm' else fmt,
                       metadata={'language_mode': 'automatic', 'certification': 'not_live_verified'})
