"""Voicemaker convert API; model labels select documented voice families, not wire model IDs."""
import re
import xml.etree.ElementTree as ET
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from tts_arena.adapters._global_common import check, key, choice, number, boolean, nonempty

MODELS = {"ai1", "ai2", "ai3", "ai4", "ai5", "ai6", "pro1", "pro2", "proplus"}
LANGUAGES = {"en-US", "en-GB", "en-IN", "hi-IN", "bn-IN", "mr-IN", "te-IN", "ta-IN", "gu-IN", "ur-IN", "kn-IN", "ml-IN"}
_COMMON = {"model", "voice", "language", "format", "sample_rate", "speed", "pitch", "volume", "effect", "pro_engine", "stability", "similarity", "ssml"}


def _payload(text, config, *, websocket=False):
    allowed = _COMMON if websocket else _COMMON | {"response_type", "file_store"}
    check(text, config, allowed, {"model", "voice", "language", "format", "sample_rate"} | (set() if websocket else {"response_type"}))
    if len(text) > (3000 if websocket else 10000):
        raise ValueError("Text exceeds documented character limit")
    model = config["model"]
    choice(model, MODELS, "model family")
    voice = config["voice"]
    nonempty(voice, "voice")
    if not voice.startswith(model + "-") or not re.fullmatch(r"[A-Za-z0-9_-]+", voice):
        raise ValueError("voice must belong to the explicit model family; custom clones require separate support")
    choice(config["language"], LANGUAGES, "language")
    choice(config["format"], {"mp3", "wav", "ogg", "opus", "aac", "ulaw", "alaw"}, "format")
    number(config["sample_rate"], 8000, 48000, "sample_rate", True)
    choice(config["sample_rate"], {8000, 16000, 22050, 24000, 44100, 48000}, "sample_rate")
    if config["format"] in {"ulaw", "alaw"} and config["sample_rate"] != 8000:
        raise UnsupportedFeature("Reviewed telephony profile requires 8000 Hz")
    if "ssml" in config:
        boolean(config["ssml"], "ssml")
    if config.get("ssml", False):
        if model not in {"ai1", "ai2", "ai3", "ai4"}:
            raise UnsupportedFeature("REST specification limits inline SSML to AI1–AI4; no broader WS assumption")
        try:
            root = ET.fromstring("<root>" + text + "</root>")
        except ET.ParseError as exc:
            raise ValueError("Malformed inline SSML") from exc
        attrs = {"break": {"time"}, "emphasis": {"level"}, "prosody": {"rate", "pitch", "volume"}}
        for el in list(root.iter())[1:]:
            if el.tag not in attrs or set(el.attrib) - attrs[el.tag]:
                raise UnsupportedFeature("SSML tag/attribute outside documented example subset")
    elif re.search(r"<[/!A-Za-z]", text):
        raise UnsupportedFeature("Markup requires explicit ssml=true; it is never silently passed as plain text")
    body = {"VoiceId": voice, "Text": text, "LanguageCode": config["language"], "OutputFormat": config["format"], "SampleRate": str(config["sample_rate"])}
    if model in {"pro1", "pro2", "proplus"}:
        body.update(LanguageCode="multi-lang", AccentCode=config["language"])
    for src, dst, low, high in [("speed", "MasterSpeed", -100, 100), ("pitch", "MasterPitch", -100, 100), ("volume", "MasterVolume", -20, 20)]:
        if src in config:
            number(config[src], low, high, src)
            if src == "pitch" and model == "ai1":
                raise UnsupportedFeature("AI1 pitch is not supported with default neural/advanced_v1; advanced_v2 not implemented")
            body[dst] = str(config[src])
    if "effect" in config:
        nonempty(config["effect"], "effect")
        body["Effect"] = config["effect"]
    if model == "proplus":
        if "pro_engine" not in config:
            raise ValueError("Explicit pro_engine required to avoid hidden highres billing default")
        choice(config["pro_engine"], {"turbo", "highres", "expressive"}, "pro_engine")
        body["ProEngine"] = config["pro_engine"]
    elif {"pro_engine", "stability", "similarity"} & set(config):
        raise UnsupportedFeature("ProEngine/Stability/Similarity implemented for ProPlus only")
    for src, dst in [("stability", "Stability"), ("similarity", "Similarity")]:
        if src in config:
            number(config[src], 0, 100, src, True)
            body[dst] = config[src]
    if not websocket:
        choice(config["response_type"], {"file", "stream"}, "response_type")
        body["ResponseType"] = config["response_type"]
        if "file_store" in config:
            if config["response_type"] != "file":
                raise UnsupportedFeature("FileStore does not apply to stream responses")
            number(config["file_store"], 1, 240, "file_store", True)
            body["FileStore"] = config["file_store"]
    return body


def build_request(text, config, env):
    body = _payload(text, config)
    token = key(env, "VOICEMAKER_API_KEY")
    file = config["response_type"] == "file"
    return RequestSpec("POST", "https://developer.voicemaker.in/api/v1/voice/convert",
        {"Authorization": "Bearer " + token, "Content-Type": "application/json"}, body,
        response_mode="json_url" if file else "binary", audio_path="path" if file else None,
        sample_rate=config["sample_rate"], encoding=config["format"],
        metadata={"verification": "not_live_verified", "download_hosts": ["developer.voicemaker.in"] if file else [],
                  "voice_locale_effect_requires_catalog_check": True, "model_is_local_family_label": True,
                  "http_incremental_audio_unverified": True, "channels_requires_live_verification": True})
