"""Pinned Maya1/Veena local batch inference; independent of hosted Maya2/Calyx."""
import hashlib
import json
import math
import time
from pathlib import Path
from tts_arena.contracts import UnsupportedFeature
from ._local_runtime import dependency, pcm16, versions

PROFILES = {'maya-research/maya1': {'revision': '21c682a0afef8c13a89b2512733c8bf5f0c52eb7', 'parameters': 3300928512, 'files': {'chat_template.jinja': {'bytes': 3827, 'hash_kind': 'git_blob_sha1', 'digest': '1bad6a0f648dccdbec523ca79ba90fbcfc806af0'}, 'config.json': {'bytes': 860, 'hash_kind': 'git_blob_sha1', 'digest': '40c05c8013f3658cfee0c0ad296c9d983a6918c5'}, 'generation_config.json': {'bytes': 228, 'hash_kind': 'git_blob_sha1', 'digest': '776c9340606cb019dc334afac1f2d740d66fcc8a'}, 'model-00001-of-00002.safetensors': {'bytes': 4991160848, 'hash_kind': 'sha256', 'digest': 'f1dae409f70c5beb92916662c6bc389b9b235ac8aa5edd19a4dcb87e37a73074'}, 'model-00002-of-00002.safetensors': {'bytes': 1610725592, 'hash_kind': 'sha256', 'digest': 'df22e9a90c1bea262250982640b119e6020474736991da482cb6ed56dd23d045'}, 'model.safetensors.index.json': {'bytes': 20955, 'hash_kind': 'git_blob_sha1', 'digest': '9e16ad6538a683f3b12ec741a656d3a17898ef63'}, 'special_tokens_map.json': {'bytes': 3333, 'hash_kind': 'git_blob_sha1', 'digest': 'c16e4b73418778a6d7e1b07e85b58027fa148f93'}, 'tokenizer.json': {'bytes': 22853258, 'hash_kind': 'sha256', 'digest': '6c5e5b1d89b7e3738e5a5a4f93c326d8f3292ea83f9c560b8dbb6d66fb851973'}, 'tokenizer_config.json': {'bytes': 5407227, 'hash_kind': 'git_blob_sha1', 'digest': '510237684b49036844dd3f9a8858fbd28cebcba4'}}}, 'maya-research/Veena': {'revision': '8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f', 'parameters': 3783054336, 'files': {'chat_template.jinja': {'bytes': 3827, 'hash_kind': 'git_blob_sha1', 'digest': '1bad6a0f648dccdbec523ca79ba90fbcfc806af0'}, 'config.json': {'bytes': 839, 'hash_kind': 'git_blob_sha1', 'digest': 'f2b83304bbe5bed2a641859ca8f1c6d24002c938'}, 'generation_config.json': {'bytes': 180, 'hash_kind': 'git_blob_sha1', 'digest': '27a9e4c5a8b7c8e0394f0e31149ae19d4822dcd3'}, 'model-00001-of-00002.safetensors': {'bytes': 4991105552, 'hash_kind': 'sha256', 'digest': '8c5ebde2fe9cb1f46ed0880c5bcf4f906f8dffe82acbbd59082cc68c1167e266'}, 'model-00002-of-00002.safetensors': {'bytes': 2575032728, 'hash_kind': 'sha256', 'digest': '11a48e332797d11470fd71f4ddc28929ee912b7ce567d58542021436a843d9fc'}, 'model.safetensors.index.json': {'bytes': 20977, 'hash_kind': 'git_blob_sha1', 'digest': '185a9ce91decb34327cabfecdee81cd6cfb0df16'}, 'special_tokens_map.json': {'bytes': 697, 'hash_kind': 'git_blob_sha1', 'digest': '6f180fad1e27a8bb8f87e4162de0713792d2d00d'}, 'tokenizer.json': {'bytes': 22851621, 'hash_kind': 'sha256', 'digest': 'c88f202c5216ed6485367f5a606093d54f9a89ef3c654001ccc10026fcd276f2'}, 'tokenizer_config.json': {'bytes': 5405560, 'hash_kind': 'git_blob_sha1', 'digest': 'c2a0026b9e5630b0d75221ed36bf24c339f00ed8'}}}, 'hubertsiuzdak/snac_24khz': {'revision': 'd73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec', 'parameters': None, 'files': {'config.json': {'bytes': 300, 'hash_kind': 'git_blob_sha1', 'digest': 'a9e7ef62bf7e1eb94d2713721029837aacab3b55'}, 'pytorch_model.bin': {'bytes': 79488254, 'hash_kind': 'sha256', 'digest': '4b8164cc6606bfa627f1a784734c1e539891518f1191ed9194fe1e3b9b4bff40'}}}}

CODE_START=128257
CODE_END=128258
AI_END=128262
OFFSET=128266
CODEC='hubertsiuzdak/snac_24khz'


def build_request(text,config,env):
    raise UnsupportedFeature('Maya1/Veena are explicit local inference profiles, not hosted Maya2 or Calyx HTTP endpoints')


def validate_config(text,config):
    allowed={'model','model_revision','model_path','codec_revision','codec_path','device','dtype','format','language','voice','description','max_new_tokens','temperature','top_p','repetition_penalty','seed','memory_budget_gib','allow_model_download'}
    if set(config)-allowed:raise UnsupportedFeature('Unimplemented Maya local controls: '+', '.join(sorted(set(config)-allowed)))
    if config.get('allow_model_download',False) is not False:raise UnsupportedFeature('Provision pinned snapshots separately; local adapter never downloads')
    if not isinstance(text,str) or not text.strip() or len(text)>1000 or '<|' in text:raise ValueError('Require1-1000characters without reserved tokenizer delimiters')
    model=config.get('model')
    if model not in { 'maya-research/maya1','maya-research/Veena'}:raise UnsupportedFeature('Only public Maya1 and Veena; no Maya2/Calyx equivalence')
    if config.get('model_revision')!=PROFILES[model]['revision'] or config.get('codec_revision')!=PROFILES[CODEC]['revision']:raise UnsupportedFeature('Exact reviewed model and codec revisions required')
    if config.get('device') not in {'cpu','mps','cuda'}:raise UnsupportedFeature('Use explicit cpu, mps or cuda; no automatic offload or fallback')
    if config.get('dtype') not in {'float16','bfloat16','float32'}:raise ValueError('Explicit float16/bfloat16/float32 required')
    if config.get('format')!='pcm_s16le':raise UnsupportedFeature('Output is mono24kHzPCM16 only')
    if model.endswith('/maya1'):
        if config.get('language') not in {'en-US','en-GB','en-IN'}:raise UnsupportedFeature('Maya1 model card only documents English; Indian accent remains unverified')
        desc=config.get('description')
        if not isinstance(desc,str) or not desc.strip() or len(desc)>600 or any(c in desc for c in ['"','<','>']):raise ValueError('Explicit voice description cannot contain attribute/token delimiters')
        if 'voice' in config:raise UnsupportedFeature('Maya1 uses description, not preset voice ID')
    else:
        if config.get('language') not in {'hi-IN','hi-en','en-IN','en-US','en-GB'}:raise UnsupportedFeature('Veena documents only Hindi/English/code-mixed text')
        if config.get('voice') not in {'kavya','agastya','maitri','vinaya'}:raise ValueError('Use exact documented Veena speaker')
        if 'description' in config:raise UnsupportedFeature('Veena preset-speaker profile has no description control')
    n=config.get('max_new_tokens')
    if type(n)is not int or not 28<=n<=2048:raise ValueError('Explicit max_new_tokens28-2048 required for bounded local probe')
    for name,lo,hi in [('temperature',.01,2),('top_p',.01,1),('repetition_penalty',1,2)]:
        v=config.get(name)
        if type(v) not in (float,int) or not math.isfinite(v) or not lo<=v<=hi:raise ValueError('Explicit finite '+name+' required within arena probe bounds')
    if type(config.get('seed'))is not int or not 0<=config['seed']<=4294967295:raise ValueError('Explicit uint32seed required')
    budget=config.get('memory_budget_gib')
    max_budget=24 if config['device']=='cuda' else 12
    if type(budget) not in (float,int) or not math.isfinite(budget) or not 1<=budget<=max_budget:raise ValueError('Explicit memory budget required within host bound')
    estimate=PROFILES[model]['parameters']*(4 if config['dtype']=='float32' else 2)/2**30+3
    if estimate>budget:raise UnsupportedFeature('Weights plus3GiB planning reserve exceed configured budget; not a measured peak estimate')
    return {'estimated_weights_plus_reserve_gib':estimate,'memory_budget_gib':budget,'peak_memory_verified':False}


def verify_snapshot(path,profile):
    path=Path(path).expanduser()
    if not path.is_absolute() or not path.is_dir():raise ValueError('Snapshot must be an existing absolute local directory')
    checked={}
    for name,expected in profile['files'].items():
        file=path/name
        if not file.is_file() or file.stat().st_size!=expected['bytes']:raise ValueError('Missing or wrong-size pinned artifact: '+name)
        h=hashlib.sha256() if expected['hash_kind']=='sha256' else hashlib.sha1()
        if expected['hash_kind']=='git_blob_sha1':h.update(('blob '+str(expected['bytes'])+'\0').encode())
        with file.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
        if h.hexdigest()!=expected['digest']:raise ValueError('Pinned artifact checksum mismatch: '+name)
        checked[name]=expected.copy()
    return str(path.resolve()),checked


def prompt_ids(tokenizer,text,config):
    if config['model']=='maya-research/maya1':
        middle=tokenizer.encode('<description="'+config['description']+'"> '+text,add_special_tokens=False)
        return [128259,128000,*middle,128009,128260,128261,CODE_START]
    middle=tokenizer.encode('<spk_'+config['voice']+'> '+text,add_special_tokens=False)
    return [128259,*middle,128260,128261,CODE_START]


def unpack_generated(tokens,model):
    eos={CODE_END} if model=='maya-research/maya1' else {CODE_END,AI_END}
    terminal=next((i for i,t in enumerate(tokens) if t in eos),None)
    if terminal is None:raise ValueError('Generation lacks end-of-speech marker; bounded output is incomplete')
    codes=[t for t in tokens[:terminal] if OFFSET<=t<OFFSET+7*4096]
    if not codes or len(codes)%7:raise ValueError('Incomplete SNAC frame sequence; no silent truncation')
    levels=[[],[],[]]
    for i in range(0,len(codes),7):
        slots=codes[i:i+7]
        vals=[(t-OFFSET)%4096 for t in slots] if model=='maya-research/maya1' else [t-OFFSET-j*4096 for j,t in enumerate(slots)]
        if any(not 0<=v<4096 for v in vals):raise ValueError('Veena SNAC codebook position mismatch')
        levels[0].append(vals[0]);levels[1].extend([vals[1],vals[4]]);levels[2].extend([vals[2],vals[3],vals[5],vals[6]])
    return levels,{'generated_tokens':len(tokens),'snac_tokens':len(codes),'ignored_non_audio_tokens':terminal-len(codes),'terminal_token':tokens[terminal]}


def synthesize_local(text,config):
    started=time.perf_counter();planning=validate_config(text,config)
    path,model_hashes=verify_snapshot(config.get('model_path',''),PROFILES[config['model']])
    codec_path,codec_hashes=verify_snapshot(config.get('codec_path',''),PROFILES[CODEC])
    torch=dependency('torch');transformers=dependency('transformers');snac=dependency('snac')
    if config['device']=='mps' and not torch.backends.mps.is_available():raise UnsupportedFeature('MPS unavailable; no implicit CPU fallback')
    if config['device']=='cuda' and not torch.cuda.is_available():raise UnsupportedFeature('CUDA unavailable; no implicit CPU fallback')
    if config['device']=='cuda':
        free,total=torch.cuda.mem_get_info()
        if planning['estimated_weights_plus_reserve_gib']*2**30>free:raise UnsupportedFeature('CUDA free VRAM below model planning reserve')
        planning.update({'cuda_free_gib_before_load':free/2**30,'cuda_total_gib':total/2**30})
    if config['device']=='mps' and __import__('os').environ.get('PYTORCH_ENABLE_MPS_FALLBACK')=='1':raise UnsupportedFeature('Disable silent MPS fallback for this measured device profile')
    torch.manual_seed(config['seed'])
    tokenizer=transformers.AutoTokenizer.from_pretrained(path,local_files_only=True,trust_remote_code=False)
    ids=prompt_ids(tokenizer,text,config)
    if len(ids)+config['max_new_tokens']>2048:raise ValueError('Arena conservative total context bound2048 exceeded')
    model=transformers.AutoModelForCausalLM.from_pretrained(path,local_files_only=True,trust_remote_code=False,use_safetensors=True,torch_dtype=getattr(torch,config['dtype']),device_map={'':config['device']},low_cpu_mem_usage=True,attn_implementation='sdpa').eval()
    # Explicit local construction avoids SNAC Hub fallback and uses restricted weight deserialization.
    codec=snac.SNAC.from_config(str(Path(codec_path)/'config.json'))
    codec.load_state_dict(torch.load(str(Path(codec_path)/'pytorch_model.bin'),map_location='cpu',weights_only=True));codec.eval()
    initialized=time.perf_counter()
    input_ids=torch.tensor([ids],dtype=torch.long,device=config['device'])
    attention_mask=torch.ones_like(input_ids)
    eos=CODE_END if config['model']=='maya-research/maya1' else [CODE_END,AI_END]
    with torch.inference_mode():
        output=model.generate(input_ids=input_ids,attention_mask=attention_mask,max_new_tokens=config['max_new_tokens'],**({'min_new_tokens':28} if config['model']=='maya-research/maya1' else {}),do_sample=True,temperature=config['temperature'],top_p=config['top_p'],repetition_penalty=config['repetition_penalty'],eos_token_id=eos,pad_token_id=tokenizer.pad_token_id,use_cache=True)
        generated=output[0,len(ids):].tolist();levels,token_stats=unpack_generated(generated,config['model'])
        codes=[torch.tensor([level],dtype=torch.long,device='cpu') for level in levels]
        audio=codec.decode(codes)[0,0]
        trim=2048 if config['model']=='maya-research/maya1' and audio.numel()>2048 else 0
        if trim:audio=audio[trim:]
        samples=audio.float().cpu()
    if config['device']=='mps':torch.mps.synchronize()
    if config['device']=='cuda':torch.cuda.synchronize()
    finished=time.perf_counter()
    return {'audio':pcm16(samples),'sample_rate':24000,'encoding':'pcm_s16le','model_revision':config['model_revision'],'codec_revision':config['codec_revision'],'dependency_versions':versions(['torch','transformers','accelerate','snac']),'artifact_hashes':{'model':model_hashes,'codec':codec_hashes},'initialization_seconds':initialized-started,'synthesis_seconds':finished-initialized,'streaming':False,'certification':'not_live_verified','device':config['device'],'dtype':config['dtype'],'decoder_device':'cpu','memory_planning':planning,'token_stats':token_stats,'warmup_trim_samples':trim,'language_mode':'input_text_and_description; locale annotation not acoustic validation'}
