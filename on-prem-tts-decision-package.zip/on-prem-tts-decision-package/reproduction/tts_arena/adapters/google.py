"""Google v1 synchronous text.synthesize; OAuth token supplied by caller."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature
from ._global_common import check,key,choice,number,metadata


def build_request(text,config,env):
    if config.get("model")=="gemini-3.1-flash-tts-preview":
        return _gemini_request(text,config,env)
    check(text,config,{'model','voice','language','format','sample_rate','speed','pitch','volume_gain_db'}, {'model','voice','language','format'})
    choice(config['model'],{'voice-selected'},'model (encoded in exact voice name)')
    voice=config['voice']
    if not isinstance(voice,str) or not voice.startswith(config['language']+'-'):
        raise ValueError('voice must match explicit locale')
    choice(config['format'],{'LINEAR16','MP3','OGG_OPUS','MULAW','ALAW'},'format')
    if len(text.encode('utf-8'))>5000: raise ValueError('input exceeds 5000 UTF-8 bytes')
    audio={'audioEncoding':config['format']}
    for source,target,lo,hi in [('speed','speakingRate',.25,2),('pitch','pitch',-20,20),('volume_gain_db','volumeGainDb',-96,16),('sample_rate','sampleRateHertz',8000,48000)]:
        if source in config:
            if 'Chirp3' in voice and source=='pitch': raise UnsupportedFeature('Chirp 3 pitch not implemented')
            number(config[source],lo,hi,source,source=='sample_rate'); audio[target]=config[source]
    return RequestSpec('POST','https://texttospeech.googleapis.com/v1/text:synthesize',
        {'Authorization':'Bearer '+key(env,'GOOGLE_ACCESS_TOKEN'),'Content-Type':'application/json'},
        {'input':{'text':text},'voice':{'languageCode':config['language'],'name':voice},'audioConfig':audio},
        response_mode='json_base64',audio_path='audioContent',sample_rate=config.get('sample_rate'),
        encoding={'LINEAR16':'wav','MP3':'mp3','OGG_OPUS':'opus','MULAW':'wav_mulaw','ALAW':'wav_alaw'}[config['format']],
        metadata=metadata(config,scope='synchronous REST; StreamingSynthesize gRPC and SSML not implemented'))


def _gemini_request(text,config,env):
    """Current Gemini model through documented GenerateContent compatibility API."""
    check(text,config,{'model','voice','language','language_mode','format','instructions'}, {'model','voice','language','language_mode','format'})
    choice(config['language_mode'],{'auto'},'Gemini detects language from text; explicit auto acknowledgement required')
    choice(config['language'],{'en-IN','hi-IN','bn-IN','mr-IN','te-IN','ta-IN','gu-IN','ur-IN','kn-IN','ml-IN'},'evaluation language')
    choice(config['voice'],{'Kore','Puck','Charon','Fenrir','Aoede'},'reviewed prebuilt voice subset')
    choice(config['format'],{'pcm_s16le'},'Gemini raw PCM output')
    prompt=text
    if 'instructions' in config:
        from ._global_common import nonempty
        nonempty(config['instructions'],'instructions')
        prompt=config['instructions']+'\n'+text
    body={'contents':[{'parts':[{'text':prompt}]}],
          'generationConfig':{'responseModalities':['AUDIO'],'speechConfig':{'voiceConfig':{'prebuiltVoiceConfig':{'voiceName':config['voice']}}}}}
    return RequestSpec('POST','https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent',
        {'x-goog-api-key':key(env,'GOOGLE_API_KEY'),'Content-Type':'application/json'},body,
        response_mode='json_base64',audio_path='candidates.0.content.parts.0.inlineData.data',sample_rate=24000,encoding='pcm_s16le',
        metadata=metadata(config,scope='Gemini3.1 single-speaker GenerateContent compatibility API; complete JSON output. Interactions and native streaming not implemented.',language_control='auto-detected from text; locale is evaluation label, not wire enforcement; accent requires listening'))
