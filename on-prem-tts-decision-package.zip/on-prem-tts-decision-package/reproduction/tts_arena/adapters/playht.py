"""PlayHT documented REST stream contract; live availability requires check."""
from tts_arena.contracts import RequestSpec
from ._global_common import check,key,choice,number,nonempty,metadata


def build_request(text,config,env):
    check(text,config,{'model','voice','language','format','sample_rate','speed','seed','temperature','quality'}, {'model','voice','language','format','sample_rate'})
    choice(config['model'],{'Play3.0-mini','PlayDialog'},'implemented engine subset')
    nonempty(config['voice'],'voice')
    languages={'en-IN':'english','hi-IN':'hindi','bn-IN':'bengali','ur-IN':'urdu'}
    choice(config['language'],languages,'language')
    choice(config['format'],{'mp3','mulaw','wav','ogg','flac'},'format')
    number(config['sample_rate'],8000,48000,'sample_rate',True)
    if len(text)>(20000 if config['model']=='Play3.0-mini' else 2000): raise ValueError('input exceeds engine character limit')
    body={'text':text,'voice':config['voice'],'voice_engine':config['model'],'language':languages[config['language']],
          'output_format':config['format'],'sample_rate':config['sample_rate']}
    for n,lo,hi,integer in [('speed',.1,5,False),('seed',0,2**53-1,True),('temperature',0,2,False)]:
        if n in config: number(config[n],lo,hi,n,integer); body[n]=config[n]
    if 'quality' in config: choice(config['quality'],{'draft','low','medium','high','premium'},'quality'); body['quality']=config['quality']
    return RequestSpec('POST','https://api.play.ht/api/v2/tts/stream',{'Authorization':key(env,'PLAYHT_API_KEY'),
        'X-USER-ID':key(env,'PLAYHT_USER_ID'),'Content-Type':'application/json','Accept':'*/*'},body,
        sample_rate=config['sample_rate'],encoding=config['format'],metadata=metadata(config,scope='Indian accent depends on selected voice; endpoint not live verified'))
