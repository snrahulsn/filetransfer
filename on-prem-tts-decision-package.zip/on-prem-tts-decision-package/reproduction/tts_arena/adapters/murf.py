"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

def build_request(text, config, env):
    key = _validate(text, config, env, {"model","voice","language","format","sample_rate","rate","pitch","style","region"}, "MURF_API_KEY")
    if config["model"] != "falcon-2": raise UnsupportedFeature("Only Falcon 2 streaming implemented")
    region=config.get("region")
    if region not in ("global","us-east","us-west","in","ca","kr","me","jp","au","eu-central","uk","sa-east"): raise ValueError("explicit documented region required")
    if not isinstance(config["voice"],str): raise ValueError("voice ID must be string")
    if config["language"] not in "en-IN hi-IN bn-IN te-IN ta-IN gu-IN kn-IN ml-IN mr-IN pa-IN en-US".split(): raise ValueError("language outside reviewed Falcon subset")
    fmt=config["format"]
    if fmt not in ("WAV","MP3","FLAC","ALAW","ULAW","OGG","PCM"): raise ValueError("format must be uppercase vendor enum")
    rate=config.get("sample_rate",24000)
    if rate not in (8000,16000,24000,44100,48000): raise ValueError("sample_rate")
    body={"text":text,"voiceId":config["voice"],"model":"falcon-2","locale":config["language"],"format":fmt,"sampleRate":rate,"channelType":"MONO"}
    for field in ("rate","pitch"):
        if field in config:
            if type(config[field]) is not int: raise ValueError(field+" must be integer")
            body[field]=_range(config[field],-50,50,field)
    if "style" in config:
        if not isinstance(config["style"],str): raise ValueError("style")
        body["style"]=config["style"]
    return RequestSpec("POST",f"https://{region}.api.murf.ai/v1/speech/stream",{"api-key":key,"Content-Type":"application/json"},body,sample_rate=rate,encoding=fmt.lower(),metadata={"voice_locale_style_requires_catalog_check":True})
