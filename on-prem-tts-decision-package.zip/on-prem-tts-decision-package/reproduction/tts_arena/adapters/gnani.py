"""Documented request subset; offline contract tests do not certify vendor behavior."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def _validate(text, config, env, allowed, credential):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("nonempty text required")
    unknown = set(config) - set(allowed)
    if unknown:
        raise UnsupportedFeature("Unimplemented config fields: " + ", ".join(sorted(unknown)))
    for field in ("model", "voice", "language", "format"):
        if field not in config or config[field] is None or config[field] == "":
            raise ValueError(field + " must be explicit")
    key = env.get(credential)
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError(credential + " required and must not contain newlines")
    return key

def _range(value, lo, hi, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not lo <= value <= hi:
        raise ValueError(field + " outside supported range")
    return value

_VOICES={"en-IN":"Kaveri Trupti Devika Pranav Shlok Girish", "hi-IN":"Nalini Bhavna Yashvi Urmila Jwala Chitra Ambuja Deepak Roopesh Vikrant Hemraj Jalaj Omkar", "hi-en":"Poorvi", "ta-IN":"Asmita Trisha Brinda Vedika Noopur", "te-IN":"Suhana Lehara Lavanya Yukti Varuni", "kn-IN":"Saanvi Kavin", "ml-IN":"Reshma Riyaan", "mr-IN":"Zahira Ishaan", "bn-IN":"Kirra Dhruva", "gu-IN":"Falak Veera", "pa-IN":"Mehuli Zayan"}
def build_request(text, config, env):
    key=_validate(text,config,env,{"model","voice","language","format","sample_rate","speed","audio_streaming"},"GNANI_API_KEY_ID")
    if config["model"]!="timbre-v2.5": raise UnsupportedFeature("Only current Timbre v2.5 contract implemented")
    if config["language"] not in _VOICES or config["voice"] not in _VOICES[config["language"]].split(): raise ValueError("voice must match reviewed preferred language catalog")
    fmt=config["format"]
    if fmt not in ("wav","raw","mp3","ogg","mulaw","alaw"): raise ValueError("format")
    rate=config.get("sample_rate",8000 if fmt in ("mulaw","alaw") else 48000)
    if type(rate) is not int or rate not in (8000,16000,22050,24000,44100,48000): raise ValueError("sample_rate")
    if fmt in ("mulaw","alaw") and rate!=8000: raise ValueError("telephony formats force 8000; make config explicit")
    stream=config.get("audio_streaming",False)
    if type(stream) is not bool: raise ValueError("audio_streaming must be bool")
    if stream and fmt=="ogg": raise UnsupportedFeature("Gnani OGG is delivered as one chunk; no streaming")
    audio={"container":fmt,"num_channels":1,"sample_width":2,"sample_rate":rate}
    if fmt in ("wav","raw"): audio["encoding"]="linear_pcm"
    body={"text":text,"model":"timbre-v2.5","voice":config["voice"],"language":config["language"],"audio_config":audio}
    if "speed" in config: body["speed"]=_range(config["speed"],.85,1.15,"speed")
    return RequestSpec("POST","https://api.vachana.ai/api/v1/tts/"+("sse" if stream else "inference"),{"X-API-Key-ID":key,"Content-Type":"application/json"},body,response_mode="sse_base64" if stream else "binary",audio_path="audio" if stream else None,sample_rate=rate,encoding="pcm_s16le" if fmt=="raw" else fmt,metadata={"sse_audio_event":"chunk","sse_terminal_event":"complete"} if stream else {})
