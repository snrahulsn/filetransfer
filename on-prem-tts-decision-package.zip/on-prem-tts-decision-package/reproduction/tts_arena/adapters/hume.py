"""Octave binary HTTP output stream, explicit version and pre-existing voice."""
import math
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text,config,env):
    allowed={'model','voice','language','format','speed','description','trailing_silence','temperature'}
    if set(config)-allowed:
        raise UnsupportedFeature(f'Hume adapter does not implement: {sorted(set(config)-allowed)}')
    if not isinstance(text,str) or not text.strip() or len(text)>5000:
        raise ValueError('text must contain 1-5000 characters')
    for k in ('model','voice','language','format'):
        if k not in config or config[k] in ('',None):
            raise ValueError(f'Explicit {k} required')
    if config['model'] not in ('1','2'):
        raise ValueError('model is the exact Octave version string 1 or 2')
    if config['language']!='auto':
        raise UnsupportedFeature('No language field in reviewed utterance API; use auto and label fixture language separately')
    if config['format'] not in ('mp3','wav','pcm'):
        raise ValueError('format must be mp3,wav,pcm')
    if not isinstance(config['voice'],str):
        raise ValueError('voice must be an existing voice ID')
    utterance={'text':text,'voice':{'id':config['voice']}}
    for k in ('speed','trailing_silence'):
        if k in config:
            v=config[k]
            if type(v) not in (int,float) or not math.isfinite(v) or v<0 or (k=='speed' and v==0):
                raise ValueError(f'Invalid {k}')
            utterance[k]=v
    if 'description' in config:
        if config['model']=='2':
            raise UnsupportedFeature('Octave 2 acting instructions documented as coming soon')
        if not isinstance(config['description'],str) or len(config['description'])>1000:
            raise ValueError('description must contain at most 1000 characters')
        utterance['description']=config['description']
    body={'utterances':[utterance],'version':config['model'],'format':{'type':config['format']},
          'num_generations':1,'instant_mode':True,'strip_headers':True}
    if 'temperature' in config:
        v=config['temperature']
        if type(v) not in (int,float) or not .1<=v<=1:
            raise ValueError('temperature must be [.1,1]')
        body['temperature']=v
    if not env.get('HUME_API_KEY'):
        raise ValueError('HUME_API_KEY required')
    return RequestSpec('POST','https://api.hume.ai/v0/tts/stream/file',
                       {'X-Hume-Api-Key':env['HUME_API_KEY'],'Content-Type':'application/json'},body,
                       sample_rate=48000,encoding='pcm_s16le' if config['format']=='pcm' else config['format'],metadata={'language_mode':'automatic','sample_rate':'fixed48000 per official Hume TTS LiveKit integration constraints; verify actual WAV header when present','certification':'not_live_verified'})
