"""Neuphonic SSE adapter; voice determines model on current documented API."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature


def build_request(text, config, env):
    allowed = {'voice','language','format','sample_rate','speed','temperature'}
    if set(config)-allowed:
        raise UnsupportedFeature(f'Neuphonic does not implement these selectors: {sorted(set(config)-allowed)}; model is selected by voice_id')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('Non-empty text required')
    for key in ('voice','language','format','sample_rate'):
        if key not in config or config[key] in ('',None):
            raise ValueError(f'Explicit {key} required')
    langs = {'ar','bg','zh','hr','cs','da','nl','en','et','fi','fr','de','el','hi','hu','id','it','ja','ko','lv','lt','mk','mt','fa','pl','pt','ro','ru','sk','sl','es','sv','th','tr','uk','ur','vi'}
    if config['language'] not in langs:
        raise UnsupportedFeature('Use a documented two-letter Neuphonic lang_code')
    if config['format'] not in {'pcm_linear','pcm_mulaw'}:
        raise UnsupportedFeature('This SSE adapter implements pcm_linear and pcm_mulaw')
    if type(config['sample_rate']) is not int or config['sample_rate'] not in {8000,16000,22050,24000}:
        raise ValueError('Invalid sample_rate')
    if not isinstance(config['voice'],str):
        raise ValueError('voice must be a voice_id string')
    body = {'text':text,'voice_id':config['voice'],'lang_code':config['language'],
            'encoding':config['format'],'sampling_rate':config['sample_rate']}
    if 'speed' in config:
        if config['speed'] not in (.7,1.0,1.5) or isinstance(config['speed'],bool):
            raise ValueError('Use exact speed bucket .7,1.0,1.5; vendor snaps intermediate values')
        body['speed'] = config['speed']
    if 'temperature' in config:
        v=config['temperature']
        if type(v) not in (int,float) or not 0 <= v <= 1:
            raise ValueError('temperature must be [0,1]')
        body['temperature']=v
    if not env.get('NEUPHONIC_API_KEY'):
        raise ValueError('NEUPHONIC_API_KEY required')
    return RequestSpec('POST','https://api.neuphonic.com/sse/speak/'+config['language'],
                       {'X-API-KEY':env['NEUPHONIC_API_KEY'],'Content-Type':'application/json','Accept':'text/event-stream'},
                       body,response_mode='sse_base64',audio_path='data.audio',sample_rate=config['sample_rate'],
                       encoding='pcm_s16le' if config['format']=='pcm_linear' else 'mulaw',
                       metadata={'model_selection':'voice_id','certification':'not_live_verified'})
