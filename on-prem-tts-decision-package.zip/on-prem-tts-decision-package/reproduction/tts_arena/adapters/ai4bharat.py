"""Explicit runtime prerequisite gate; not an inference implementation."""
from tts_arena.contracts import RequestSpec, UnsupportedFeature

def build_request(text, config, env):
    raise UnsupportedFeature('Gated ai4bharat/indic-parler-tts checkpoint access, Parler-TTS runtime, tokenizer, description and local inference worker are required. No official HTTP synthesis endpoint is documented in the model card.')


def synthesize_local(text,config):
    import time
    started=time.perf_counter()
    from pathlib import Path
    from ._local_runtime import validate,local_path,dependency,pcm16,versions,hashes
    validate(text,config,{'model','language','model_path','prompt_tokenizer_path','description_tokenizer_path','description'})
    if config.get('model')!='ai4bharat/indic-parler-tts':
        raise UnsupportedFeature('Only ai4bharat/indic-parler-tts implemented')
    if config.get('language')!='auto':
        raise UnsupportedFeature('Parler detects language from transcript; use auto and record target locale in fixture')
    if not isinstance(config.get('description'),str) or not config['description'].strip():
        raise ValueError('Explicit description caption required; voice/emotion is controlled through this caption')
    paths=[local_path(config,k,directory=True) for k in ('model_path','prompt_tokenizer_path','description_tokenizer_path')]
    # Reject empty directories before allowing SDK loading; local_files_only prevents remote fallback.
    files=sorted({str(p) for d in paths for p in Path(d).rglob('*') if p.is_file()})
    if not files or not (Path(paths[0])/'config.json').is_file():
        raise UnsupportedFeature('Local runtime requires complete model and tokenizer snapshots with config.json')
    provenance=hashes(files)
    Model=dependency('parler_tts').ParlerTTSForConditionalGeneration
    Tokenizer=dependency('transformers').AutoTokenizer
    torch=dependency('torch')
    model=Model.from_pretrained(paths[0],local_files_only=True).to(config['device']).eval()
    prompt_tokenizer=Tokenizer.from_pretrained(paths[1],local_files_only=True,trust_remote_code=False)
    description_tokenizer=Tokenizer.from_pretrained(paths[2],local_files_only=True,trust_remote_code=False)
    initialized=time.perf_counter()
    prompt=prompt_tokenizer(text,return_tensors='pt').to(config['device'])
    description=description_tokenizer(config['description'],return_tensors='pt').to(config['device'])
    with torch.inference_mode():
        generation=model.generate(input_ids=description.input_ids,attention_mask=description.attention_mask,
                                  prompt_input_ids=prompt.input_ids,prompt_attention_mask=prompt.attention_mask)
    completed=time.perf_counter()
    rate=model.config.sampling_rate
    if type(rate) is not int or rate<=0:
        raise ValueError('Model returned invalid sampling_rate')
    return {'audio':pcm16(generation),'sample_rate':rate,'encoding':'pcm_s16le',
            'model_revision':config['model_revision'],'dependency_versions':versions(['parler-tts','transformers','torch']),
            'artifact_sha256':provenance,'initialization_seconds':initialized-started,
            'synthesis_seconds':completed-initialized,'streaming':False,'certification':'not_live_verified'}
