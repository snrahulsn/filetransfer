"""Transparent list-rate calculations; never account billing conclusions."""

def per_sample_minute_rate(rate_per_1k_characters, text_codepoints, duration_seconds):
    if rate_per_1k_characters is None or type(text_codepoints) is not int or text_codepoints < 1:
        return None
    if not isinstance(duration_seconds, (int, float)) or duration_seconds <= 0:
        return None
    return rate_per_1k_characters * text_codepoints / 1000 * 60 / duration_seconds
