"""Verify the sixteen no-retry regional ASR diagnostics against saved WAVs."""
import hashlib
import json
import wave
from pathlib import Path

from .transcript_quality import evaluate_transcripts

EXPECTED_PAIRS = [('smallest', lang) for lang in
                  ('bn-IN', 'mr-IN', 'te-IN', 'gu-IN', 'kn-IN', 'ml-IN')]
EXPECTED_PAIRS += [(provider, 'ta-IN') for provider in
                   ('gnani', 'fonada', 'fish', 'inworld', 'minimax', 'murf')]
EXPECTED_PAIRS += [('camb', 'hi-IN'), ('dubverse', 'hi-IN'),
                   ('hume', 'hi-IN'), ('speechify', 'en-IN')]


def verify(root):
    root = Path(root).resolve()
    folder = root / 'artifacts/indic-regional-asr-20260916'
    plan_raw = (folder / 'plan.json').read_bytes()
    plan = json.loads(plan_raw)
    refs = json.loads((folder / 'canonical_references.json').read_text())
    observations = json.loads((folder / 'observations.json').read_text())
    private = json.loads((folder / 'private_sanitized_responses.json').read_text())
    status = json.loads((folder / 'status.json').read_text())
    summary = json.loads((folder / 'result-summary.json').read_text())
    source_raw = (root / 'artifacts/transcript-references-20260915/references.json').read_bytes()
    source_refs = {row['reference_id']: row for row in json.loads(source_raw)}
    snapshot = json.loads((root / 'ui/public/evidence/snapshot.json').read_text())
    runs = {row['run_id']: row for row in snapshot['runs']}
    if (plan['schema'] != 'indic_regional_asr_v1' or
        (plan['asr_model'], plan['asr_mode'], plan['language_code'],
         plan['automatic_retries'], plan['requests_limit'], plan['audio_seconds_limit']) !=
        ('saaras:v3', 'verbatim', 'unknown', 0, 16, 80) or
        plan['source_references_sha256'] != hashlib.sha256(source_raw).hexdigest() or
        summary['schema'] != 'indic_regional_asr_summary_v1' or
        summary['engine'] != 'sarvam.saaras:v3.verbatim' or
        summary['status'] != status['status'] != 'complete' or
        summary['planned_requests'] != summary['completed_requests'] !=
        status['planned_requests'] != status['completed_requests'] != 16 or
        summary['plan_sha256'] != hashlib.sha256(plan_raw).hexdigest() or
        len(plan['items']) != len(refs) != len(observations) != len(private) != 16 or
        [(item['provider'], item['language']) for item in plan['items']] != EXPECTED_PAIRS):
        raise ValueError('Regional ASR fixed batch/model/source inventory changed')
    by_ref = {row['reference_id']: row for row in refs}
    by_private = {row['reference_id']: row for row in private}
    by_observation = {row['reference_id']: row for row in observations}
    if len(by_ref) != len(by_private) != len(by_observation) != 16:
        raise ValueError('Regional ASR reference/response identity repeated')
    seconds = 0
    for item in plan['items']:
        ref = by_ref[item['reference_id']]
        original = source_refs.get(item['reference_id'])
        run = runs[item['run_id']]
        if (not original or any(original[k] != ref[k] for k in
            ('reference_id', 'run_id', 'provider', 'model', 'language', 'text', 'native_reviewed')) or
            ref['native_reviewed'] is not False or
            (ref['run_id'], ref['provider'], ref['model'], ref['language']) !=
            (item['run_id'], item['provider'], item['model'], item['language']) or
            run['status'] != 'success' or
            (run['provider'], run['language'], run['config'].get('model'), run['text']) !=
            (ref['provider'], ref['language'], ref['model'], ref['text']) or
            item['audio_url'] != run['audio_url'] or
            item['audio_sha256'] != ref['audio_sha256'] != run['listening_audio_sha256']):
            raise ValueError('Regional ASR run/reference/model/audio identity changed')
        url = item['audio_url']
        if not url.startswith('/evidence/audio/') or not url.endswith('.wav'):
            raise ValueError('Regional ASR public WAV path invalid')
        file = (root / 'ui/public' / url.lstrip('/')).resolve()
        if not file.is_relative_to(root / 'ui/public/evidence/audio'):
            raise ValueError('Regional ASR public WAV escaped evidence folder')
        if hashlib.sha256(file.read_bytes()).hexdigest() != item['audio_sha256']:
            raise ValueError('Regional ASR public WAV hash changed')
        with wave.open(str(file), 'rb') as media:
            duration = media.getnframes() / media.getframerate()
            if media.getnchannels() != 1 or media.getsampwidth() != 2 or not 0 < duration <= 12:
                raise ValueError('Regional ASR WAV format/duration changed')
        if abs(duration - item['duration_seconds']) > .001 or abs(duration - run['duration_seconds']) > .05:
            raise ValueError('Regional ASR WAV duration changed')
        seconds += duration
        response = by_private[item['reference_id']]['sanitized_response']
        observation = by_observation[item['reference_id']]
        if (not isinstance(response.get('language_code'), str) or
            not response['language_code'] or not response.get('transcript') or
            response['transcript'] != observation['text']):
            raise ValueError('Regional ASR sanitized response differs from score input')
    if seconds > 80 or abs(seconds - plan['planned_audio_seconds']) > .01:
        raise ValueError('Regional ASR total audio cap changed')
    scored = evaluate_transcripts(observations, refs, {})
    if scored['rejected'] or len(scored['observations']) != 16:
        raise ValueError('Regional ASR scoring rejected observations')
    detected = {key: row['sanitized_response']['language_code'] for key, row in by_private.items()}
    expected = [{'provider': score['provider'], 'model': score['model'],
                 'language': score['language'], 'reference_id': score['reference_id'],
                 'audio_sha256': score['audio_sha256'],
                 'detected_language': detected[score['reference_id']],
                 'wer_raw': score['wer']['rate'], 'cer_raw': score['cer']['rate'],
                 'word_edit_distance': score['wer']['distance'],
                 'draft_word_units': score['wer']['reference_units']}
                for score in scored['observations']]
    if (summary['results'] != expected or summary['native_reviewed_references'] != 0 or
        summary['human_ratings'] != 0):
        raise ValueError('Regional ASR published scores differ from raw observations')
    published = [dict(row, run_id=by_ref[row['reference_id']]['run_id'],
                      audio_url=runs[by_ref[row['reference_id']]['run_id']]['audio_url'],
                      quality_certified=False) for row in expected]
    return {'status': 'sixteen_regional_diagnostics_verified', 'engine': summary['engine'],
            'asr_mode': 'verbatim', 'planned_requests': 16, 'completed_requests': 16,
            'automatic_retries': 0, 'total_audio_seconds': round(seconds, 3),
            'native_reviewed_references': 0, 'human_ratings': 0,
            'requested_locale_detected_count': sum(r['language'] == r['detected_language'] for r in published),
            'results': published, 'boundary': summary['boundary']}
