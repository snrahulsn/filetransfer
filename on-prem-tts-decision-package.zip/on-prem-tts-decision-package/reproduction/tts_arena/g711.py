"""G.711 mu-law decode for original-rate browser listening copies."""

import array
import io
import sys
import wave


def mulaw_to_wav(raw: bytes, sample_rate: int = 8000) -> bytes:
    if not raw or sample_rate != 8000:
        raise ValueError('Explicit nonempty 8 kHz mu-law expected')
    values = array.array('h')
    for byte in raw:
        code = (~byte) & 0xff
        magnitude = (((code & 0x0f) << 3) + 0x84) << ((code >> 4) & 7)
        pcm = magnitude - 0x84
        values.append(-pcm if code & 0x80 else pcm)
    if sys.byteorder != 'little':
        values.byteswap()
    out = io.BytesIO()
    with wave.open(out, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(values.tobytes())
    return out.getvalue()
