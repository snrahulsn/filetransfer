"""Verify the balanced Fish REST/WebSocket first-playable-PCM evidence."""
import base64
import hashlib
import json
import math
from pathlib import Path
import wave

import msgpack

from .matched_latency_evidence import interval
from .metrics import percentile
from .sessions.fish import decode_message

ROOT_NAME = 'fish-transport-latency-20260916'


def verify(root):
    root = Path(root).resolve()
    if root.name != ROOT_NAME:
        raise ValueError('Unexpected Fish transport evidence root')
    project = root.parents[1]
    manifest = json.loads((root / 'manifest.json').read_text())
    expected_orders = [['rest', 'websocket'] if i % 2 == 0 else ['websocket', 'rest'] for i in range(12)]
    config = {'model': 's2.1-pro-free', 'voice': '9a9cf47702da476aa4629e2506d4a857',
              'language': 'auto', 'format': 'pcm', 'sample_rate': 24000,
              'chunk_length': 100, 'latency': 'normal'}
    if (manifest.get('schema') != 'fish_balanced_rest_vs_timestamp_websocket_pcm_v1'
        or manifest.get('status') != 'complete' or manifest.get('order') != expected_orders
        or manifest.get('repetitions_per_route') != 12 or manifest.get('max_vendor_requests') != 24
        or manifest.get('automatic_retries') != 0 or manifest.get('attempts_total') != 24
        or manifest.get('successful') != {'rest': 12, 'websocket': 12}
        or manifest.get('client_egress_country_start') != 'IN'
        or manifest.get('client_egress_country_end') != 'IN'
        or manifest.get('config') != config or manifest.get('language') != 'hi-IN'
        or manifest.get('audio_condition') != 'provider-native mono PCM16 at 24 kHz; no resampling'
        or len(manifest.get('results', [])) != 24):
        raise ValueError('Fish transport trial scope or completion mismatch')
    transcript = manifest.get('transcript')
    if not isinstance(transcript, str) or hashlib.sha256(transcript.encode()).hexdigest() != manifest.get('text_sha256'):
        raise ValueError('Fish transport prompt digest mismatch')
    if not isinstance(manifest.get('source_code_sha256'), str) or len(manifest['source_code_sha256']) != 64:
        raise ValueError('Fish transport source code digest missing')
    values = {'rest': [], 'websocket': []}
    order_values = {'rest': [[], []], 'websocket': [[], []]}
    pair = {}
    rest_contract = None
    for index, row in enumerate(manifest['results']):
        ordinal, position = divmod(index, 2)
        ordinal += 1
        route = expected_orders[ordinal - 1][position]
        if row.get('route') != route or row.get('ordinal') != ordinal or row.get('status') != 'success':
            raise ValueError('Fish balanced route order or row status changed')
        relative = row.get('source_result')
        if not isinstance(relative, str) or relative.startswith('/') or '..' in Path(relative).parts:
            raise ValueError('Unsafe Fish transport result path')
        source = (project / relative).resolve()
        if not source.is_relative_to(root) or not source.is_file():
            raise ValueError('Fish transport result escaped saved evidence')
        result = json.loads(source.read_text())
        if (result.get('provider') != 'fish' or result.get('status') != 'success'
            or result.get('code_sha256', result.get('source_code_sha256')) != manifest['source_code_sha256']
            or result.get('config') != ({**config, 'timestamp_mode': True} if route == 'websocket' else config)
            or (result.get('text_sha256') if route == 'websocket' else hashlib.sha256(result.get('text', '').encode()).hexdigest()) != manifest['text_sha256']):
            raise ValueError('Fish saved request identity differs from manifest')
        if route == 'rest':
            if any(result.get(k) != row.get(k) for k in ('run_id', 'status', 'http_status', 'error_type',
                                                         'first_audio_ms', 'audio_bytes', 'audio_sha256')):
                raise ValueError('Fish REST result and manifest differ')
            if result.get('http_status') != 200 or result.get('audio_analysis', {}).get('analysis_status') != 'measured_pcm':
                raise ValueError('Fish REST response was not verified PCM')
            if (result['audio_analysis'].get('sample_rate') != 24000
                or result['audio_analysis'].get('channels') != 1):
                raise ValueError('Fish REST PCM rate/channel changed')
            timings = [result.get(k) for k in ('first_byte_ms', 'first_payload_ms', 'first_audio_ms', 'elapsed_ms')]
            if any(type(t) not in (int, float) or not math.isfinite(t) or t <= 0 for t in timings) or timings != sorted(timings):
                raise ValueError('Fish REST timing sequence invalid')
            contract = result.get('request_contract', {})
            if any(contract.get(k) != v for k, v in {'method': 'POST', 'url_host': 'api.fish.audio',
                       'response_mode': 'binary', 'encoding': 'pcm_s16le', 'sample_rate': 24000}.items()):
                raise ValueError('Fish REST synthesis contract changed')
            if rest_contract is not None and contract != rest_contract:
                raise ValueError('Fish REST contract varied between rounds')
            rest_contract = contract
            pcm_file = source.parent / result.get('audio_file', '')
            if pcm_file.resolve().parent != source.parent:
                raise ValueError('Fish REST audio path escaped result')
            pcm = pcm_file.read_bytes()
        else:
            if any(result.get(k) != row.get(k) for k in ('status', 'first_audio_ms', 'audio_bytes', 'audio_sha256')):
                raise ValueError('Fish WebSocket result and manifest differ')
            if (result.get('schema') != 'fish_timestamp_websocket_latency_result_v1'
                or result.get('route') != 'websocket' or result.get('ordinal') != ordinal
                or result.get('model') != config['model'] or result.get('voice') != config['voice']
                or result.get('sample_rate') != 24000 or result.get('encoding') != 'pcm_s16le'
                or result.get('terminal_observed') is not True):
                raise ValueError('Fish WebSocket model or response scope changed')
            sent = result.get('sent', [])
            if [x.get('event') for x in sent] != ['start', 'text', 'flush', 'stop']:
                raise ValueError('Fish WebSocket controls changed')
            if any(type(x.get('elapsed_ms')) not in (int, float) or x['elapsed_ms'] < 0 for x in sent):
                raise ValueError('Fish WebSocket send clock invalid')
            frame_file = source.parent / 'frames.jsonl'
            pcm_buffer = bytearray()
            first_frame_ms = None
            finish = False
            previous_elapsed = 0
            frames = frame_file.read_text().splitlines()
            for line in frames:
                frame = json.loads(line)
                elapsed = frame.get('elapsed_ms')
                if (frame.get('type') != 'binary' or type(elapsed) not in (int, float)
                    or not math.isfinite(elapsed) or elapsed < previous_elapsed or finish):
                    raise ValueError('Fish WebSocket frame clock or sequence invalid')
                previous_elapsed = elapsed
                raw = base64.b64decode(frame['base64'], validate=True)
                decoded = decode_message(raw)
                packet = msgpack.unpackb(raw, raw=False, strict_map_key=True)
                if packet.get('event') == 'audio':
                    for event in decoded:
                        if event['type'] == 'audio' and event['audio']:
                            first_frame_ms = elapsed if first_frame_ms is None else first_frame_ms
                            pcm_buffer.extend(event['audio'])
                elif packet.get('event') == 'finish':
                    if packet.get('reason') != 'stop':
                        raise ValueError('Fish WebSocket terminal reason changed')
                    finish = True
            if not finish or first_frame_ms != result.get('first_audio_ms') or len(frames) != result.get('frames'):
                raise ValueError('Fish WebSocket first audio or terminal differs from wire')
            if not sent[-1]['elapsed_ms'] < first_frame_ms:
                raise ValueError('Fish WebSocket audio arrived before complete request')
            pcm_file = source.parent / result.get('audio_file', '')
            if pcm_file.resolve().parent != source.parent:
                raise ValueError('Fish WebSocket audio path escaped result')
            pcm = pcm_file.read_bytes()
            if pcm != pcm_buffer:
                raise ValueError('Fish WebSocket PCM differs from wire frames')
            wav_file = source.parent / result.get('playable_file', '')
            if wav_file.resolve().parent != source.parent:
                raise ValueError('Fish WebSocket WAV path escaped result')
            with wave.open(str(wav_file), 'rb') as wav:
                if (wav.getnchannels(), wav.getsampwidth(), wav.getframerate()) != (1, 2, 24000):
                    raise ValueError('Fish WebSocket playable WAV format changed')
                if wav.readframes(wav.getnframes()) != pcm:
                    raise ValueError('Fish WebSocket WAV does not contain saved PCM')
        if (len(pcm) != result['audio_bytes'] or len(pcm) < 2 or len(pcm) % 2
            or hashlib.sha256(pcm).hexdigest() != result['audio_sha256']
            or len(pcm) != row['audio_bytes'] or result['audio_sha256'] != row['audio_sha256']):
            raise ValueError('Fish transport audio digest or PCM size differs')
        timing = result['first_audio_ms']
        if type(timing) not in (int, float) or not math.isfinite(timing) or timing <= 0:
            raise ValueError('Fish transport first-playable timing invalid')
        values[route].append(timing)
        order_values[route][position].append(timing)
        pair.setdefault(ordinal, {})[route] = timing
    if any(len(values[route]) != 12 or len(order_values[route][position]) != 6
           for route in values for position in (0, 1)):
        raise ValueError('Fish transport route balance incomplete')
    differences = [pair[i]['rest'] - pair[i]['websocket'] for i in range(1, 13)]
    groups = {route: {'model': config['model'], 'voice': config['voice'], 'language': 'hi-IN',
                      'encoding': 'pcm_s16le', 'sample_rate': 24000, 'trials': 12,
                      'values_ms': [round(v, 2) for v in values[route]],
                      'first_in_pair_values_ms': [round(v, 2) for v in order_values[route][0]],
                      'second_in_pair_values_ms': [round(v, 2) for v in order_values[route][1]],
                      'p50': interval(values[route], .5, 4410 + i),
                      'p95': interval(values[route], .95, 5510 + i)}
              for i, route in enumerate(('rest', 'websocket'))}
    return {'schema': 'fish_transport_latency_audit_v1', 'provider': 'fish',
            'model': config['model'], 'voice': config['voice'], 'requested_locale': 'hi-IN',
            'status': 'observed_balanced_same_vendor_routes',
            'source_manifest': str((root / 'manifest.json').relative_to(project)),
            'source_code_sha256': manifest['source_code_sha256'],
            'client_egress_country': 'IN', 'route_order_balanced': True,
            'first_audio_boundary': manifest['latency_boundary'],
            'same_prompt_model_voice_pcm': True, 'qualified_route_comparison': True,
            'quality_certification': False, 'cost_reconciled': False,
            'production_playout_verified': False, 'successful_requests': 24,
            'groups': groups, 'paired_rest_minus_websocket_ms': {
                'values_ms': [round(v, 2) for v in differences],
                'median_ms': round(percentile(differences, .5), 2),
                'rest_slower_pairs': sum(v > 0 for v in differences)},
            'limitations': ['First received PCM at this client, not first audible telephone audio.',
                            'Timestamp WebSocket and REST route settings were pinned, but deployed serving regions were not disclosed.',
                            'Twelve unloaded trials per route give a broad p95 interval; no production concurrency result.']}
