import html
import json
from pathlib import Path

from .registry import ROOT, catalog, code_digest, validate
from .live_evidence import load_live_runs, summarize_live_runs
from .evidence_inventory import inventory


def build_report(destination, test_report=None):
    items=catalog()
    separate=inventory(ROOT)
    runs,issues=load_live_runs(ROOT/'artifacts')
    live=summarize_live_runs(runs,code_digest(),items)
    report={"candidate_count":len(items),"companies":sum(i["kind"]=="vendor" for i in items),
            "open_models":sum(i["kind"]=="open_model" for i in items),"code_sha256":code_digest(),
            "integration_counts":{s:sum(i["integration_status"]==s for i in items) for s in ("implemented","blocked")},
            "live_certified":0,"tests":test_report,"offline_evidence_current":bool(test_report and test_report.get("code_sha256")==code_digest()),"providers":items,
            "live_evidence":live,"live_evidence_inventory_issues":issues,"separate_evidence_inventory":separate,
            "user_skipped_candidates":[i["id"] for i in items if i.get("assessment_status")=="user_skipped"],
            "catalog_errors":{i["id"]:validate(i) for i in items if validate(i)}}
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    (destination/"catalog.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    esc=html.escape
    rows=[]
    for item in items:
        scope=item.get("evaluation_scope", {})
        deployment="Hosted: " + scope.get("hosted_api", "unverified") + "; On-prem: " + scope.get("on_prem", "unverified")
        langs=item["languages"]
        regional=sum(langs.get(k,{}).get("status")=="documented" for k in ("bn-IN","mr-IN","te-IN","ta-IN","gu-IN","ur-IN","kn-IN","ml-IN"))
        sources=" ".join(f'<a href="{esc(s["url"],quote=True)}" target="_blank" rel="noreferrer">{esc(s["id"])}</a>' for s in item["sources"])
        rows.append(f'<tr><td>{esc(item["name"])}</td><td>{esc(item["kind"])}</td><td>{esc(deployment)}</td><td>{esc(item.get("assessment_status",item["integration_status"]))}</td><td>{esc(langs["en-IN"]["status"])}</td><td>{esc(langs["hi-IN"]["status"])}</td><td>{regional}/8</td><td>{sources}</td></tr>')
    details=[]
    for item in items:
        feature_rows="".join(f'<tr><td>{esc(k)}</td><td>{esc(v["status"])}</td><td>{esc(v["notes"])}</td></tr>' for k,v in item["features"].items())
        language_rows="".join(f'<tr><td>{esc(k)}</td><td>{esc(v["status"])}</td><td>{esc(v["notes"])}</td></tr>' for k,v in item["languages"].items())
        scope_notes=esc(item.get("evaluation_scope",{}).get("notes", "Evaluation scope does not establish deployment availability."))
        pricing=esc(item.get("pricing",{}).get("notes","Pricing requires current account-specific confirmation"))
        credentials=esc(", ".join(item.get("credentials",[])) or "Local runtime / access prerequisites; see dossier")
        details.append(f'<details><summary>{esc(item["name"])}</summary><p>{esc(item["integration_notes"])}</p><p>Deployment scope: {scope_notes}</p><p>Credential variable names: {credentials}</p><p>Pricing evidence: {pricing}</p><h3>Language evidence</h3><table>{language_rows}</table><h3>Vendor claims — not live verification</h3><table>{feature_rows}</table></details>')
    page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TTS Arena evidence report</title><style>body{font:16px system-ui;margin:40px auto;max-width:1300px;padding:0 24px;color:#202124;background:#fff}h1{font-size:30px}p{max-width:95ch;line-height:1.6}table{width:100%;border-collapse:collapse;margin:20px 0;font-size:14px}td,th{text-align:left;padding:12px;border-bottom:1px solid #ddd;vertical-align:top}thead{background:#f5f5f5}details{border-top:1px solid #aaa;padding:18px 0}summary{font-weight:600;cursor:pointer}input{padding:10px;width:330px;font:inherit}a{color:#145fa5}</style><h1>TTS Arena evidence report</h1>'''
    page+=f'<p>{len(items)} candidates; {report["companies"]} service/company entries and {report["open_models"]} open-model entries. “Implemented” means a scoped request adapter exists. No vendor is live certified. Documentation of English does not prove an Indian accent. Regional counts are model-qualified claims; expand each candidate for limitations.</p>'
    page+=f'<p>Saved live HTTP attempts: {live["historical_attempts"]}; successful audio runs: {live["historical_successes"]}; non-successes: {live["historical_non_successes"]}. These cover {live["providers_attempted"]} providers. Exact-current code and catalog hash matches: {live["exact_current_hash_attempts"]}. Historical runs remain valid records of earlier executions; they do not qualify changed code. No native-listener quality certification or production-call validation has been completed.</p>'
    page+=f'<p>Verified primary-source captures: {separate["verified_source_captures"]} of {separate["source_manifest_entries"]} manifest entries. Separate native WebSocket sessions: {separate["native_session_attempts"]}, including {separate["native_sessions_with_audio"]} with audio. Browser studio result records: {separate["browser_studio_result_records"]}. These are not added to HTTP attempts or vendor certifications. User-skipped candidates: {esc(", ".join(report["user_skipped_candidates"]) or "none")}.</p>'
    page+='<p>Evidence details: <a href="../../docs/LIVE_ACCESS_STATUS.md">HTTP access</a> · <a href="../../docs/LIVE_SESSION_STATUS.md">Native sessions</a> · <a href="../../docs/BROWSER_ACCESS_STATUS.md">Browser access</a> · <a href="../../docs/REGIONAL_COVERAGE_STATUS.md">Regional coverage</a> · <a href="../../docs/LISTENING_STUDY_STATUS.md">Listening study preparation</a>. No native-listener ratings collected.</p>'
    if test_report:
        state=("passed" if test_report["passed"] else "FAILED") if report["offline_evidence_current"] else "STALE — rerun after source/code changes"
        page+=f'<p>Offline suite: {test_report["tests_run"]} tests; {state}. Test evidence is stored separately from vendor claims.</p>'
    page+='<label>Filter candidates <input id="filter" placeholder="Name, language or feature"></label><table id="vendors"><thead><tr><th>Candidate</th><th>Type</th><th>Evaluation deployment scope</th><th>Adapter</th><th>Indian English</th><th>Hindi</th><th>Regional claims</th><th>Sources</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table>'+''.join(details)
    page+='''<script>document.getElementById('filter').addEventListener('input',e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('#vendors tbody tr,details').forEach(x=>x.hidden=!x.textContent.toLowerCase().includes(q))})</script></html>'''
    (destination/"index.html").write_text(page)
    return {k:v for k,v in report.items() if k not in {"providers","tests"}}
