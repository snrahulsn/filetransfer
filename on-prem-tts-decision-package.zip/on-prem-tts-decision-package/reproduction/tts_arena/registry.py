"""Filesystem plugins; adding a provider never requires editing a switch statement."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
LANGUAGES = ("en-IN", "hi-IN", "bn-IN", "mr-IN", "te-IN", "ta-IN", "gu-IN", "ur-IN", "kn-IN", "ml-IN")
FEATURES = ("text_input_streaming", "audio_streaming", "flush", "cancel", "connection_reuse", "word_timestamps", "pronunciation_dictionary", "ssml", "speed", "emotion", "voice_cloning", "cross_language_voice", "telephony_formats", "seed", "concurrency_limits", "data_residency", "retention")
CLAIM_STATES = {"documented", "unsupported", "unverified"}


def valid_id(value):
    if not re.fullmatch(r"[a-z][a-z0-9_]{1,50}", value):
        raise ValueError("Provider ID must be a lowercase identifier")
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def code_digest():
    h = hashlib.sha256()
    paths = sorted((ROOT / "tts_arena").rglob("*.py")) + sorted((ROOT / "catalog").glob("*.json")) + sorted((ROOT / "tests").rglob("*.py")) + sorted((ROOT/"scripts").glob("*.py"))
    paths += [p for p in (ROOT/"vendor_evidence/manifest.json",ROOT/"pyproject.toml",ROOT/"docs/SPECIFICATION.md",ROOT/"IMPLEMENTATION_CONTRACT.md") if p.exists()]
    paths += sorted((ROOT/"ui/app").rglob("*.tsx")) + sorted((ROOT/"ui/app").rglob("*.css")) + sorted((ROOT/"ui/lib").glob("*.ts"))
    paths += sorted((ROOT/"ui/app").rglob("*.ts")) + sorted((ROOT/"ui/db").rglob("*.ts"))
    paths += sorted((ROOT/"ui/drizzle").rglob("*.sql")) + sorted((ROOT/"ui/drizzle").rglob("*.json"))
    paths += sorted((ROOT/"ui/tests").glob("*.mjs"))
    paths += [p for p in (ROOT/"ui/package.json",ROOT/"ui/package-lock.json",ROOT/"ui/next.config.ts",ROOT/"ui/vite.config.ts",ROOT/"ui/.openai/hosting.json",ROOT/"execution_profiles.json",ROOT/"ui/lib/execution_profiles.json") if p.exists()]
    for path in paths:
        h.update(str(path.relative_to(ROOT)).encode())
        h.update(path.read_bytes())
    return h.hexdigest()


def validate(item):
    errors = []
    try:
        valid_id(item["id"])
    except (KeyError, ValueError):
        errors.append("invalid id")
    if item.get("kind") not in {"vendor", "open_model"}:
        errors.append("kind must distinguish vendor from open_model")
    if item.get("integration_status") not in {"implemented", "blocked"}:
        errors.append("invalid integration_status")
    sources = item.get("sources", [])
    ids = {s.get("id") for s in sources}
    if len(ids) != len(sources):
        errors.append("duplicate source ids")
    for s in sources:
        if not s.get("url", "").startswith("https://") or not s.get("title") or not s.get("accessed"):
            errors.append("source needs https URL, title and access date")
    for group, keys in (("languages", LANGUAGES), ("features", FEATURES)):
        for key in keys:
            claim = item.get(group, {}).get(key, {})
            if claim.get("status") not in CLAIM_STATES:
                errors.append(f"{group}.{key}: missing/invalid status")
            refs = claim.get("source_ids", [])
            if any(ref not in ids for ref in refs):
                errors.append(f"{group}.{key}: nonexistent source")
            if claim.get("status") != "unverified" and not refs:
                errors.append(f"{group}.{key}: asserted claim needs evidence")
            if not claim.get("notes"):
                errors.append(f"{group}.{key}: missing scope/notes")
    for model, scope in item.get("model_language_scope", {}).items():
        if model not in item.get("models", []):
            errors.append(f"model_language_scope.{model}: model not listed")
        supported = scope.get("supported_languages", [])
        unsupported = scope.get("unsupported_languages", [])
        if not isinstance(supported, list) or not isinstance(unsupported, list):
            errors.append(f"model_language_scope.{model}: language lists required")
            continue
        if len(supported) != len(set(supported)) or len(unsupported) != len(set(unsupported)) or set(supported) & set(unsupported):
            errors.append(f"model_language_scope.{model}: duplicate or conflicting languages")
        if any(language not in LANGUAGES for language in supported + unsupported):
            errors.append(f"model_language_scope.{model}: unknown language")
        refs = scope.get("source_ids", [])
        if not refs or any(ref not in ids for ref in refs):
            errors.append(f"model_language_scope.{model}: source required")
        if not scope.get("notes"):
            errors.append(f"model_language_scope.{model}: notes required")
    return errors


def catalog():
    return [json.loads(p.read_text()) for p in sorted((ROOT / "catalog").glob("*.json"))]


def provider(provider_id):
    path = ROOT / "catalog" / (valid_id(provider_id) + ".json")
    if not path.exists():
        raise ValueError(f"Unknown provider {provider_id}")
    return json.loads(path.read_text())


def build_request(provider_id, text, config, env=None):
    item = provider(provider_id)
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Nonempty text is required")
    if item["integration_status"] == "blocked":
        from .contracts import UnsupportedFeature
        raise UnsupportedFeature(item.get("integration_notes", "Adapter blocked"))
    module = importlib.import_module(f"tts_arena.adapters.{valid_id(provider_id)}")
    return module.build_request(text, config, os.environ if env is None else env)


def assert_tts_only(configs):
    """Everything except explicitly nested tts settings must be identical."""
    if len(configs) < 2:
        raise ValueError("Comparison requires at least two manifests")
    base = {k: v for k, v in configs[0].items() if k != "tts"}
    required = {"stt", "llm", "turn_detection", "text_chunks", "region", "codec", "transport"}
    if not required <= base.keys():
        raise ValueError(f"Missing invariants: {sorted(required - base.keys())}")
    for config in configs[1:]:
        if digest(base) != digest({k: v for k, v in config.items() if k != "tts"}):
            raise ValueError("Non-TTS configuration changed")
    return digest(base)
