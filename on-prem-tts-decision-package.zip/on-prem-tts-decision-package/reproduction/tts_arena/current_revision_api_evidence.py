"""Verify one-shot hosted API regression runs against saved request and audio bytes."""
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse

from .registry import build_request, code_digest, digest

EXPECTED = {'camb', 'cartesia', 'deepgram', 'dubverse', 'elevenlabs', 'fish',
            'fonada', 'gnani', 'google', 'hume', 'inworld', 'minimax', 'murf',
            'neuphonic', 'rime', 'sarvam', 'smallest', 'soniox', 'speechify'}


def verify(root):
    root = Path(root).resolve()
    folder = root / 'artifacts/current-revision-api-20260916'
    plan = json.loads((folder / 'plan.json').read_text())
    source = (folder / 'reference-attempt.json').read_bytes()
    reference = json.loads(source)
    status = json.loads((folder / 'status.json').read_text())
    snapshot = json.loads((root / 'ui/public/evidence/snapshot.json').read_text())
    code = code_digest()
    if (plan['schema'] != 'current_revision_api_plan_v1' or
        plan['source_reference_sha256'] != hashlib.sha256(source).hexdigest() or
        plan['snapshot_code_sha256'] != status['source_code_sha256'] or
        snapshot['code_sha256'] != code or
        (plan['planned_requests'], plan['request_limit'], plan['automatic_retries'],
         plan['timeout_seconds_per_request']) != (19, 19, 0, 35) or
        status['schema'] != 'current_revision_api_status_v1' or
        status['planned_requests'] != status['completed_requests'] != 19 or
        status['status'] != 'complete' or status['automatic_retries'] != 0 or
        len(plan['jobs']) != len(status['results']) != len(reference['routes']) != 19):
        raise ValueError('Current-revision API release/source/request inventory changed')
    jobs = {job['provider']: job for job in plan['jobs']}
    routes = {route['provider']: route for route in reference['routes']}
    results = {row['provider']: row for row in status['results']}
    if set(jobs) != set(routes) != set(results) != EXPECTED:
        raise ValueError('Current-revision API provider set differs from plan/reference')
    runs = {row['run_id']: row for row in snapshot['runs']}
    source_folders = root / 'artifacts/runs/current-revision-api-20260916'
    if len(list(source_folders.glob('*/result.json'))) != 19:
        raise ValueError('Current-revision API raw run count changed')
    published = []
    for provider in sorted(EXPECTED):
        job, route, observed = jobs[provider], routes[provider], results[provider]
        if (job['text'], job['config'], job['source_run_id'], job['body_sha256']) != (
            route['example_text'], route['example_config'], route['example_run_id'],
            route['request_body_sha256']):
            raise ValueError('Current-revision API replay prompt/config/body changed')
        if job['method'] != route['method'] or (
            job['endpoint_host'], job['endpoint_path']) != (
            urlparse(route['endpoint']).hostname, urlparse(route['endpoint']).path):
            raise ValueError('Current-revision API replay method/endpoint changed')
        dummy = {name: 'synthetic-test-credential' for name in job['credential_names']}
        rebuilt = build_request(provider, job['text'], job['config'], dummy)
        rebuilt_hash = hashlib.sha256(rebuilt.body).hexdigest() if isinstance(rebuilt.body, bytes) else digest(rebuilt.body)
        if (rebuilt.method, rebuilt.url, rebuilt.response_mode,
            rebuilt.encoding, rebuilt.sample_rate, rebuilt_hash,
            set(rebuilt.headers)) != (
            route['method'], route['endpoint'], route['response_mode'],
            route['encoding'], route['sample_rate'], route['request_body_sha256'],
            set(route['all_header_names'])):
            raise ValueError('Present adapter request differs from exact live request contract')
        run_id = observed.get('run_id')
        if not isinstance(run_id, str) or run_id not in runs:
            raise ValueError('Current-revision API saved run is missing from public snapshot')
        public = runs[run_id]
        raw_file = (source_folders / run_id / 'result.json').resolve()
        if not raw_file.is_relative_to(source_folders) or not raw_file.is_file():
            raise ValueError('Current-revision API source path invalid')
        raw = json.loads(raw_file.read_text())
        if (raw['run_id'] != run_id or raw['provider'] != provider or
            raw['code_sha256'] != plan['snapshot_code_sha256'] or raw['text'] != job['text'] or
            raw['config'] != job['config'] or public['run_id'] != run_id or
            public['status'] != raw['status'] != observed['status'] or
            observed.get('http_status') != raw.get('http_status') or
            observed.get('audio_sha256') != raw.get('audio_sha256')):
            raise ValueError('Current-revision API public/source/status run identity differs')
        contract = raw.get('request_contract', {})
        if contract and (contract.get('method'), contract.get('url_host'),
            contract.get('response_mode'), contract.get('encoding'),
            contract.get('sample_rate'), contract.get('body_sha256'),
            set(contract.get('headers', []))) != (
            route['method'], job['endpoint_host'], route['response_mode'],
            route['encoding'], route['sample_rate'], route['request_body_sha256'],
            set(route['all_header_names'])):
            raise ValueError('Current-revision API actual request differs from replay contract')
        if not contract and (raw['status'] == 'success' or not raw.get('error_type')):
            raise ValueError('Current-revision API outcome lacks request contract or bounded error evidence')
        if raw['status'] == 'success':
            if raw.get('http_status') != 200 or not raw.get('audio_file') or not public.get('audio_url'):
                raise ValueError('Current-revision API success lacks HTTP 200 or published audio')
            saved_audio = (raw_file.parent / raw['audio_file']).resolve()
            if not saved_audio.is_relative_to(source_folders) or not saved_audio.is_file() or (
                hashlib.sha256(saved_audio.read_bytes()).hexdigest() != raw['audio_sha256']):
                raise ValueError('Current-revision API retained synthesis audio hash differs')
            playable = (root / 'ui/public' / public['audio_url'].lstrip('/')).resolve()
            if not playable.is_relative_to(root / 'ui/public/evidence/audio') or (
                hashlib.sha256(playable.read_bytes()).hexdigest() != public['listening_audio_sha256']):
                raise ValueError('Current-revision API published playable WAV hash differs')
            if not 0 < public['duration_seconds'] <= 30:
                raise ValueError('Current-revision API published audio duration invalid')
        published.append({'provider': provider, 'model': str(job['config'].get('model', 'implicit')),
                          'run_id': run_id, 'status': raw['status'],
                          'http_status': raw.get('http_status'),
                          'audio_url': public.get('audio_url'),
                          'duration_seconds': public.get('duration_seconds'),
                          'created_at': raw['created_at']})
    if len({row['run_id'] for row in published}) != 19:
        raise ValueError('Current-revision API run IDs repeated')
    successes = sum(row['status'] == 'success' for row in published)
    return {'status': 'nineteen_live_attempts_and_current_contracts_verified',
            'observed_source_code_sha256': plan['snapshot_code_sha256'],
            'current_export_code_sha256': code,
            'same_global_revision': code == plan['snapshot_code_sha256'],
            'current_request_contracts_match': True,
            'attempts': 19, 'audio_successes': successes,
            'automatic_retries': 0, 'results': published,
            'boundary': 'One saved short prompt/model/config per route. Present adapter requests reconstruct the saved live method/host/body/header/format contract. Edits outside that contract can change the global export hash; no native quality, billed cost, scale or production reliability claim'}
