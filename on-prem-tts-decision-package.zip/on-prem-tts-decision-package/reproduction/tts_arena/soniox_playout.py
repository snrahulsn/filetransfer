"""Bounded Soniox native cancel/recovery bridged into measured software PCM playout."""
import asyncio
import base64
import hashlib
import io
import json
import math
import time
import wave
from pathlib import Path
from uuid import uuid4

from websockets.asyncio.client import connect
from websockets.asyncio.server import serve

from .credentials import redact
from .replay import load_caller, replay
from .transport import safe_url

OFFICIAL_URL = 'wss://tts-rt.soniox.com/tts-websocket'
FRAME_BYTES = 24000 // 50 * 2
MAX_CAPTURE = 8_000_000


def preflight(caller_wav, old_text, recovery_text, env, observation_seconds,
              vendor_url=OFFICIAL_URL, allow_local=False):
    if not isinstance(env, dict) or not isinstance(env.get('SONIOX_API_KEY'), str) or not env['SONIOX_API_KEY']:
        raise ValueError('A Soniox evaluation key is required only in memory')
    if (not isinstance(old_text, str) or not isinstance(recovery_text, str) or
        not 20 <= len(old_text) <= 180 or not 10 <= len(recovery_text) <= 80):
        raise ValueError('Bounded Soniox Hindi old/recovery texts required')
    if (type(observation_seconds) not in (int, float) or not math.isfinite(observation_seconds)
        or not 1 <= observation_seconds <= 15):
        raise ValueError('Observation must be 1..15 seconds')
    if type(allow_local) is not bool:
        raise ValueError('Local vendor test opt-in must be boolean')
    safe_url(vendor_url.replace('wss://', 'https://', 1).replace('ws://', 'http://', 1), allow_local)
    caller = load_caller(caller_wav, 24000)
    if len(caller) / 48000 > .25:
        raise ValueError('Synthetic caller fixture must be <=250 ms')
    return caller


def pcm_wav(raw):
    if not raw or len(raw) % 2:
        raise ValueError('Nonempty 24 kHz mono PCM16 required')
    output = io.BytesIO()
    with wave.open(output, 'wb') as media:
        media.setnchannels(1)
        media.setsampwidth(2)
        media.setframerate(24000)
        media.writeframes(raw)
    return output.getvalue()


async def replay_soniox(caller_wav, destination, old_text, recovery_text, env, *,
                        onset_offset_ms=150, observation_seconds=8,
                        stop_threshold_ms=500, vendor_url=OFFICIAL_URL,
                        vendor_connector=None, allow_local=False):
    preflight(caller_wav, old_text, recovery_text, env, observation_seconds,
              vendor_url=vendor_url, allow_local=allow_local)
    output = Path(destination)
    if output.exists():
        raise FileExistsError('Soniox playout destination already attempted')
    old_id, new_id = 'old-' + uuid4().hex, 'new-' + uuid4().hex
    events, old_before, old_after, recovery = [], bytearray(), bytearray(), bytearray()
    pending = {old_id: bytearray(), new_id: bytearray()}
    state = {'cancelled': False, 'cancel_before_old_terminal': False,
             'old_terminated': False, 'new_terminated': False,
             'recovery_started': False, 'bridge_timeout': False,
             'old_audio_end': False, 'new_audio_end': False,
             'error_type': None}
    origin = time.perf_counter_ns()

    def event(kind, **fields):
        events.append({'sequence': len(events),
                       'elapsed_ms': round((time.perf_counter_ns() - origin) / 1e6, 3),
                       'event_type': kind, **fields})

    def config(stream_id):
        return {'api_key': env['SONIOX_API_KEY'], 'model': 'tts-rt-v2',
                'language': 'hi', 'voice': 'Kavya', 'audio_format': 'pcm_s16le',
                'sample_rate': 24000, 'stream_id': stream_id}

    async def local_bot(local_ws):
        start = json.loads(await local_ws.recv())
        if start != {'type': 'start', 'sample_rate': 24000,
                     'format': 'pcm_s16le', 'frame_ms': 20}:
            raise ValueError('Software receiver PCM start contract changed')
        connector = vendor_connector or connect
        async with connector(vendor_url, max_size=2_000_000,
                             open_timeout=min(observation_seconds, 10)) as vendor_ws:
            await vendor_ws.send(json.dumps(config(old_id)))
            await vendor_ws.send(json.dumps({'text': old_text, 'text_end': True,
                                             'stream_id': old_id}))
            event('old_text_sent')
            lock = asyncio.Lock()

            async def send_frames(stream_id):
                current = pending[stream_id]
                while len(current) >= FRAME_BYTES:
                    frame = bytes(current[:FRAME_BYTES])
                    del current[:FRAME_BYTES]
                    if stream_id == old_id and state['cancelled']:
                        continue
                    await local_ws.send(json.dumps({'type': 'audio',
                        'response_id': 'old' if stream_id == old_id else 'recovery',
                        'audio': base64.b64encode(frame).decode()}))
                    event('playout_frame_sent', response='old' if stream_id == old_id else 'recovery',
                          byte_count=len(frame))

            async def receive_vendor():
                async for raw in vendor_ws:
                    message = json.loads(raw)
                    stream_id = message.get('stream_id')
                    if stream_id not in (old_id, new_id):
                        raise ValueError('Unexpected Soniox stream ID')
                    if message.get('error_type'):
                        state['error_type'] = str(message['error_type'])[:60]
                        event('vendor_error', response='old' if stream_id == old_id else 'recovery',
                              error_type=state['error_type'])
                    if message.get('audio'):
                        pcm = base64.b64decode(message['audio'], validate=True)
                        if not pcm or len(pcm) % 2 or len(pcm) > 2_000_000:
                            raise ValueError('Invalid Soniox PCM16 frame')
                        async with lock:
                            bucket = (old_after if state['cancelled'] else old_before) if stream_id == old_id else recovery
                            if len(bucket) + len(pcm) > MAX_CAPTURE:
                                raise ValueError('Soniox audio capture exceeded bounded size')
                            bucket.extend(pcm)
                            if stream_id == old_id and state['cancelled']:
                                event('old_audio_after_cancel_discarded', byte_count=len(pcm))
                            else:
                                pending[stream_id].extend(pcm)
                                event('vendor_audio_received', response='old' if stream_id == old_id else 'recovery',
                                      byte_count=len(pcm))
                                await send_frames(stream_id)
                    if message.get('audio_end') is True:
                        state['old_audio_end' if stream_id == old_id else 'new_audio_end'] = True
                        event('vendor_audio_end', response='old' if stream_id == old_id else 'recovery')
                    if message.get('terminated') is True:
                        state['old_terminated' if stream_id == old_id else 'new_terminated'] = True
                        await local_ws.send(json.dumps({'type': 'response_end',
                            'response_id': 'old' if stream_id == old_id else 'recovery'}))
                        event('vendor_terminated', response='old' if stream_id == old_id else 'recovery')
                        if state['old_terminated'] and state['new_terminated']:
                            return

            async def receive_caller():
                async for raw in local_ws:
                    message = json.loads(raw)
                    if message.get('type') != 'caller_audio':
                        raise ValueError('Software receiver sent unexpected action')
                    async with lock:
                        if state['cancelled']:
                            continue
                        state['cancelled'] = True
                        state['cancel_before_old_terminal'] = not state['old_terminated']
                        pending[old_id].clear()
                        await local_ws.send(json.dumps({'type': 'clear', 'response_id': 'old'}))
                        event('local_playout_cleared')
                        await vendor_ws.send(json.dumps({'stream_id': old_id, 'cancel': True}))
                        event('native_cancel_sent')
                        await vendor_ws.send(json.dumps(config(new_id)))
                        await vendor_ws.send(json.dumps({'text': recovery_text,
                            'text_end': True, 'stream_id': new_id}))
                        state['recovery_started'] = True
                        event('recovery_text_sent')

            vendor_task = asyncio.create_task(receive_vendor())
            caller_task = asyncio.create_task(receive_caller())
            try:
                await asyncio.wait_for(vendor_task, timeout=observation_seconds + 1)
                # Keep the local receiver connected through its observation window.
                # Closing as soon as Soniox terminates both streams can interrupt
                # a still-in-flight synthetic caller frame.
                await local_ws.wait_closed()
            except TimeoutError:
                state['bridge_timeout'] = True
                event('bridge_timeout')
            except Exception as exc:
                state['error_type'] = type(exc).__name__
                event('bridge_error', error_type=state['error_type'])
            finally:
                for task in (vendor_task, caller_task):
                    task.cancel()
                await asyncio.gather(vendor_task, caller_task, return_exceptions=True)

    async with serve(local_bot, '127.0.0.1', 0) as server:
        port = server.sockets[0].getsockname()[1]
        receiver = await replay(f'ws://127.0.0.1:{port}', caller_wav, output,
                                sample_rate=24000, onset_offset_ms=onset_offset_ms,
                                observation_seconds=observation_seconds,
                                stop_threshold_ms=stop_threshold_ms, allow_local=True)
    artifacts = {}
    for label, raw in [('old_before_cancel', old_before),
                       ('old_after_cancel', old_after), ('recovery', recovery)]:
        if raw:
            file = output / (label + '.pcm')
            file.write_bytes(raw)
            artifacts[label] = {'file': file.name, 'bytes': len(raw),
                                'sha256': hashlib.sha256(raw).hexdigest(),
                                'duration_ms': round(len(raw) / 48, 3)}
    if recovery:
        wav = pcm_wav(recovery)
        (output / 'recovery.wav').write_bytes(wav)
        artifacts['recovery_wav'] = {'file': 'recovery.wav', 'bytes': len(wav),
                                     'sha256': hashlib.sha256(wav).hexdigest()}
    metrics = receiver.get('metrics') or {}
    status = ('observed' if receiver['status'] == 'observed' and
              metrics.get('active_at_onset') and not metrics.get('right_censored') and
              not metrics.get('missed_interruption') and
              metrics.get('stop_latency_ms') is not None and
              metrics['stop_latency_ms'] <= stop_threshold_ms and
              metrics.get('next_response_from_onset_ms') is not None and
              state['cancel_before_old_terminal'] and
              state['old_terminated'] and state['new_terminated'] and recovery and
              not state['bridge_timeout'] and not state['error_type'] else 'inconclusive')
    bridge = {'schema': 'soniox_software_playout_v1', 'provider': 'soniox',
              'model': 'tts-rt-v2', 'voice': 'Kavya', 'requested_language': 'hi-IN',
              'sample_rate': 24000, 'status': status,
              'synthetic_caller_onset': True, 'production_telephony_verified': False,
              'native_cancel_sent': state['cancelled'],
              'cancel_before_old_terminal': state['cancel_before_old_terminal'],
              'old_terminated': state['old_terminated'],
              'recovery_started': state['recovery_started'],
              'new_terminated': state['new_terminated'],
              'old_audio_end': state['old_audio_end'],
              'new_audio_end': state['new_audio_end'],
              'post_cancel_old_audio_played_locally': False,
              'bridge_timeout': state['bridge_timeout'],
              'error_type': state['error_type'],
              'artifacts': artifacts, 'events': events,
              'boundary': 'Synthetic tone into 24 kHz software PCM receiver; native WebSocket cancel/recovery on one connection; no VAD, SIP/RTP, handset or production call'}
    (output / 'soniox-bridge.json').write_text(redact(json.dumps(bridge, ensure_ascii=False, indent=2), env) + '\n')
    receiver['soniox_bridge'] = bridge
    return receiver
