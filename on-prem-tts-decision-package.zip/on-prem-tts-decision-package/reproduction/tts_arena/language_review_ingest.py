"""Strict offline ingestion of genuine blinded Indic listening exports.

An export is evidence of a listener's entries, not evidence of qualification.
Only separately verified native-language roster and corrected reference records
can promote an entry into a numerical result.
"""

from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path

from .metrics import bootstrap_mean

DIMENSIONS = ('naturalness', 'accent', 'intelligibility', 'text_fidelity')
OBSERVATIONS = ('entity_or_pronunciation_error', 'code_switch_or_emotion_note')


def _digest(payload):
    return sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                             separators=(',', ':')).encode()).hexdigest()


def evaluate(study_id, public_items, private_key, exports, roster, references):
    """Validate inputs and return model/locale evidence without vendor certification.

    `roster` is an independently verified ID-to-qualification mapping. `references`
    must bind every scored item to a native-reviewed spoken/reference text and the
    reviewer who checked it. No missing or failed qualification is imputed.
    """
    if not isinstance(study_id, str) or not study_id.strip():
        raise ValueError('Study ID required')
    if not isinstance(public_items, list) or not isinstance(private_key, dict):
        raise ValueError('Public manifest and private key have wrong types')
    if not isinstance(exports, list) or not isinstance(roster, dict) or not isinstance(references, dict):
        raise ValueError('Exports, roster and references have wrong types')
    manifest = {}
    for item in public_items:
        if not isinstance(item, dict) or not isinstance(item.get('item_id'), str) or not item['item_id']:
            raise ValueError('Invalid public item')
        if item['item_id'] in manifest:
            raise ValueError('Duplicate public item')
        manifest[item['item_id']] = item
    if set(manifest) != set(private_key):
        raise ValueError('Private key does not match public item IDs')
    if not exports:
        return {'schema': 'indic_language_review_ingest_v1', 'study_id': study_id,
                'export_count': 0, 'submitted_ratings': 0, 'accepted_ratings': 0,
                'pending_qualification': 0, 'pending_reference': 0,
                'qualified_model_locale_groups': [], 'vendor_certifications': 0,
                'evidence_hashes': {'public_manifest_sha256': _digest(public_items),
                                    'private_key_sha256': _digest(private_key),
                                    'roster_sha256': _digest(roster), 'references_sha256': _digest(references)}}
    seen = set()
    submitted = accepted = qualification_missing = reference_missing = 0
    groups = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    item_ratters = defaultdict(set)
    export_hashes = []
    for export in exports:
        if not isinstance(export, dict) or export.get('schema') != 'indic_language_review_v1' or export.get('study_id') != study_id:
            raise ValueError('Wrong review export schema or study')
        rows = export.get('ratings')
        if not isinstance(rows, list) or not rows:
            raise ValueError('Review export has no completed ratings')
        export_hashes.append(_digest(export))
        for row in rows:
            submitted += 1
            if not isinstance(row, dict) or set(row) != {'reviewer_id', 'item_id', *DIMENSIONS, 'observations'}:
                raise ValueError('Unexpected review rating fields')
            reviewer_id, item_id = row['reviewer_id'], row['item_id']
            if not isinstance(reviewer_id, str) or not reviewer_id.strip() or not isinstance(item_id, str) or item_id not in manifest:
                raise ValueError('Invalid reviewer or unknown item')
            pair = (reviewer_id, item_id)
            if pair in seen:
                raise ValueError('Duplicate reviewer-item entry across exports')
            seen.add(pair)
            if any(type(row[dimension]) is not int or not 1 <= row[dimension] <= 5 for dimension in DIMENSIONS):
                raise ValueError('All four ratings must be integers 1–5')
            observations = row['observations']
            if not isinstance(observations, dict) or set(observations) != set(OBSERVATIONS) or any(
                    not isinstance(observations[name], str) or len(observations[name]) > 1200 for name in OBSERVATIONS):
                raise ValueError('Invalid free-text observations')
            private = private_key[item_id]
            public = manifest[item_id]
            if not isinstance(private, dict) or private.get('language') != public.get('language') or private.get('text') != public.get('text'):
                raise ValueError('Private/public item identity differs')
            if not isinstance(private.get('provider'), str) or not isinstance(private.get('model'), str) or not isinstance(
                    private.get('source_audio_sha256'), str) or len(private['source_audio_sha256']) != 64:
                raise ValueError('Exact provider/model/audio source identity missing from private key')
            person = roster.get(reviewer_id)
            if not isinstance(person, dict) or person.get('screening_passed') is not True or not isinstance(
                    person.get('verified_native_languages'), list) or private['language'] not in person['verified_native_languages']:
                qualification_missing += 1
                continue
            reference = references.get(item_id)
            if (not isinstance(reference, dict) or reference.get('native_reviewed') is not True or not isinstance(
                    reference.get('reviewed_text'), str) or not reference['reviewed_text'].strip() or not isinstance(
                    reference.get('reviewer_id'), str) or not reference['reviewer_id'].strip() or reference.get('language') != private['language'] or
                    reference.get('source_audio_sha256') != private['source_audio_sha256'] or
                    reference['reviewed_text'] != public['text'] or
                    reference['reviewer_id'] == reviewer_id):
                reference_missing += 1
                continue
            reference_person = roster.get(reference['reviewer_id'])
            if not isinstance(reference_person, dict) or reference_person.get('screening_passed') is not True or not isinstance(
                    reference_person.get('verified_native_languages'), list) or private['language'] not in reference_person['verified_native_languages']:
                reference_missing += 1
                continue
            accepted += 1
            key = (private['provider'], private['model'], private['language'])
            item_ratters[(key, item_id)].add(reviewer_id)
            for dimension in DIMENSIONS:
                groups[key][dimension][reviewer_id].append(row[dimension])
    result = []
    for (provider, model, language), dimensions in sorted(groups.items()):
        key = (provider, model, language)
        rater_ids = set(dimensions['naturalness'])
        item_ids = {item_id for group_key, item_id in item_ratters if group_key == key}
        per_item_two_raters = sum(len(item_ratters[(key, item_id)]) >= 2 for item_id in item_ids)
        result.append({'provider': provider, 'model': model, 'language': language,
                       'distinct_items': len(item_ids), 'qualified_native_reviewers': len(rater_ids),
                       'items_with_two_independent_reviewers': per_item_two_raters,
                       'all_items_double_reviewed': bool(item_ids) and per_item_two_raters == len(item_ids),
                       'dimensions': {name: bootstrap_mean([
                           sum(scores) / len(scores) for _, scores in sorted(by_reviewer.items())])
                                      for name, by_reviewer in dimensions.items()},
                       'inference_unit': 'reviewer; item effects and unequal prompts are not controlled',
                       'vendor_certified': False})
    return {'schema': 'indic_language_review_ingest_v1', 'study_id': study_id,
            'export_count': len(exports), 'submitted_ratings': submitted, 'accepted_ratings': accepted,
            'pending_qualification': qualification_missing, 'pending_reference': reference_missing,
            'qualified_model_locale_groups': result, 'vendor_certifications': 0,
            'evidence_hashes': {'public_manifest_sha256': _digest(public_items),
                                'private_key_sha256': _digest(private_key),
                                'roster_sha256': _digest(roster), 'references_sha256': _digest(references),
                                'export_sha256': export_hashes}}


def evaluate_files(package_dir, export_paths, roster_path, references_path):
    package = Path(package_dir)
    status = json.loads((package / 'package-status.json').read_text())
    public = json.loads((package / 'public/items.json').read_text())
    private = json.loads((package / 'public-private-key.json').read_text())
    exports = [json.loads(Path(path).read_text()) for path in export_paths]
    roster = json.loads(Path(roster_path).read_text())
    references = json.loads(Path(references_path).read_text())
    return evaluate(status['study_id'], public, private, exports, roster, references)
