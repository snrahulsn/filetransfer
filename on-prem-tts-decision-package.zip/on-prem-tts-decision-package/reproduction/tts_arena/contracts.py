from dataclasses import dataclass, field
from typing import Any


class UnsupportedFeature(ValueError):
    """The requested behavior is not implemented; never silently substitute."""


@dataclass(frozen=True)
class RequestSpec:
    method: str
    url: str
    headers: dict[str, str]
    body: dict | str | bytes | None = None
    response_mode: str = "binary"
    audio_path: str | None = None
    sample_rate: int | None = None
    channels: int = 1
    encoding: str = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class WebSocketSpec:
    url: str
    headers: dict[str,str] = field(default_factory=dict)
    initial_messages: list[dict] = field(default_factory=list)
    sample_rate: int | None = None
    encoding: str = "unknown"
    metadata: dict[str,Any] = field(default_factory=dict)
