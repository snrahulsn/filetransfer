"""Independent wire/audio verification of the bounded Murf Falcon 2 socket capture."""
import hashlib
import io
import json
import struct
import wave
from pathlib import Path

from tts_arena.sessions.murf import decode_message


def repack_streaming_wav(raw_audio):
    """Validate Murf's unknown-length WAV header and return standard WAV plus PCM."""
    if raw_audio[:12] != b'RIFF\xff\xff\xff\xffWAVE':
        raise ValueError('Expected Murf streaming WAV header with unknown length')
    if raw_audio[12:20] != b'fmt \x10\x00\x00\x00' or raw_audio[36:44] != b'data\xff\xff\xff\xff':
        raise ValueError('Unexpected Murf streaming WAV layout')
    format_tag, channels, sample_rate, byte_rate, block_align, bits = struct.unpack('<HHIIHH', raw_audio[20:36])
    if (format_tag, channels, sample_rate, byte_rate, block_align, bits) != (
        1, 1, 24000, 48000, 2, 16):
        raise ValueError('Murf audio format is not PCM16 mono 24 kHz')
    pcm = raw_audio[44:]
    if not pcm or len(pcm) % 2:
        raise ValueError('Truncated Murf PCM samples')
    out = io.BytesIO()
    with wave.open(out, 'wb') as file:
        file.setnchannels(1)
        file.setsampwidth(2)
        file.setframerate(24000)
        file.writeframes(pcm)
    wav = out.getvalue()
    with wave.open(io.BytesIO(wav), 'rb') as file:
        if file.getnframes() != len(pcm) // 2:
            raise ValueError('Repacked Murf WAV is incomplete')
    return wav, pcm


def verify(root):
    root = Path(root)
    manifest = json.loads((root / 'artifacts/murf-native-20260916/manifest.json').read_text())
    if (manifest.get('provider'), manifest.get('model'), manifest.get('language'),
        manifest.get('transport'), manifest.get('retries'), manifest.get('request_limit')) != (
        'murf', 'falcon-2', 'hi-IN', 'native_websocket', 0, 1):
        raise ValueError('Unexpected Murf native scope')
    result_path = (root / manifest['result_path']).resolve()
    if not result_path.is_relative_to(root / 'artifacts'):
        raise ValueError('Murf result outside private evidence root')
    result = json.loads(result_path.read_text())
    if (result.get('provider'), result.get('status'), result.get('error_type'),
        result.get('evidence_class'), result.get('sent_action_count'),
        result.get('sample_rate'), result.get('encoding')) != (
        'murf', 'observed', None, 'native_websocket_session', 1, 24000, 'wav_stream_chunks'):
        raise ValueError('Murf native session did not finish as captured')
    config = result['config']
    if (config.get('model'), config.get('voice'), config.get('language'), config.get('region'),
        config.get('format'), config.get('sample_rate'), config.get('context_id')) != (
        'falcon-2', 'hi-IN-khyati', 'hi-IN', 'global', 'WAV', 24000, 'hindi-turn-1'):
        raise ValueError('Unexpected Murf native request config')
    if result['actions'] != [{'at_ms': 0, 'type': 'text', 'context_id': 'hindi-turn-1',
                             'text': manifest['text'], 'end': True}]:
        raise ValueError('Murf actions/text differ from live manifest')
    if len(result['audio']) != 1 or result['audio'][0]['context_id'] != 'hindi-turn-1':
        raise ValueError('One tagged Murf audio stream required')
    audio_file = result_path.parent / result['audio'][0]['path']
    raw_audio = audio_file.read_bytes()
    if (len(raw_audio) != result['audio'][0]['bytes'] or
        hashlib.sha256(raw_audio).hexdigest() != result['audio'][0]['sha256']):
        raise ValueError('Murf raw stream hash mismatch')
    frames = result_path.parent / result['capture_journals']['raw_frames']
    extracted = bytearray()
    audio_frames = 0
    terminal = 0
    for line in frames.read_text().splitlines():
        frame = json.loads(line)
        if frame['type'] != 'text':
            raise ValueError('Murf documented protocol requires JSON text frames')
        for event in decode_message(frame['payload']):
            if event['type'] == 'audio':
                if event['context_id'] != 'hindi-turn-1':
                    raise ValueError('Audio returned on the wrong context')
                extracted.extend(event['audio'])
                audio_frames += 1
            if event['type'] == 'done':
                if event['context_id'] != 'hindi-turn-1':
                    raise ValueError('Final event returned on the wrong context')
                terminal += 1
    if bytes(extracted) != raw_audio or audio_frames != 23 or terminal != 1:
        raise ValueError('Decoded Murf wire frames disagree with saved raw stream')
    wav, pcm = repack_streaming_wav(raw_audio)
    events = result['events']
    payload = [e['elapsed_ms'] for e in events if e['event_type'] == 'audio_payload_received'
               and e.get('context_id') == 'hindi-turn-1']
    if len(payload) != audio_frames or not 0 < payload[0] < payload[-1]:
        raise ValueError('Murf audio event timing disagrees with frames')
    audit = {'provider': 'murf', 'model': 'falcon-2', 'language': 'hi-IN',
             'voice': config['voice'], 'transport': 'native_websocket',
             'endpoint': manifest['documented_endpoint'], 'region': config['region'],
             'format': 'WAV stream, repacked PCM16 mono 24 kHz',
             'context_id': 'hindi-turn-1', 'status': 'observed',
             'audio_payloads': audio_frames, 'terminal_events': terminal,
             'first_payload_ms': round(payload[0], 3),
             'duration_seconds': round(len(pcm) / 48000, 3),
             'raw_audio_sha256': hashlib.sha256(raw_audio).hexdigest(),
             'playable_wav_sha256': hashlib.sha256(wav).hexdigest(),
             'code_sha256_at_capture': result['code_sha256'],
             'request_limit': 1, 'retries': 0,
             'quality_certified': False, 'production_barge_in_certified': False,
             'cancel_scope': 'documented clear only cancels pending synthesis; already generating audio continues',
             'source': manifest['source'],
             'boundary': 'client received WebSocket payload; no telephony playout'}
    return audit, wav
