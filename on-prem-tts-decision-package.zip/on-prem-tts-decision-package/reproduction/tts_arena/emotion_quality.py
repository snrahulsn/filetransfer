"""Validate blinded emotion identification; no automated perceptual certification."""
from collections import defaultdict

EMOTIONS = frozenset({'neutral', 'calm', 'cheerful', 'angry', 'curious', 'excited', 'sad', 'fearful', 'disgusted', 'surprised', 'unclear', 'other'})


def score_emotion_ratings(ratings, roster, private_items):
    """Target is hidden during identification. Group exact model/language/target.

    Reports descriptive counts, never a population accuracy estimate or MOS.
    All judgments require screened native-language reviewers.
    """
    if not isinstance(ratings,list) or not isinstance(roster,dict) or not isinstance(private_items,dict):
        raise ValueError("Ratings must be a list; roster and item key must be mappings")
    seen, rejected, groups = set(), [], defaultdict(list)
    for row in ratings:
        if not isinstance(row,dict) or any(not isinstance(row.get(k),str) or not row[k].strip() for k in ('rater_id','item_id')):
            raise ValueError('Nonempty rater/item IDs required')
        pair = (row['rater_id'], row['item_id'])
        if pair in seen:
            raise ValueError('Duplicate rater/item')
        seen.add(pair)
        if row['item_id'] not in private_items:
            raise ValueError('Unknown emotion item')
        item = private_items[row['item_id']]
        if not isinstance(item,dict) or any(not isinstance(item.get(k),str) or not item[k].strip() for k in ('provider','model','language','target_emotion')):
            raise ValueError('Invalid private emotion model/language identity')
        target = item['target_emotion']
        if target not in EMOTIONS - {'other', 'unclear'}:
            raise ValueError('Invalid private target')
        if row.get('perceived_emotion') not in EMOTIONS:
            raise ValueError('Invalid perceived emotion')
        for field in ('naturalness', 'text_fidelity'):
            value = row.get(field)
            if type(value) is not int or not 1 <= value <= 5:
                raise ValueError(field + ' requires integer 1..5')
        person = roster.get(row['rater_id'], {})
        languages=person.get('verified_native_languages') if isinstance(person,dict) else None
        qualified=(isinstance(person,dict) and person.get('screening_passed') is True
                   and isinstance(languages,list) and all(isinstance(v,str) for v in languages)
                   and item['language'] in languages)
        if not qualified:
            rejected.append({'rater_id': row['rater_id'], 'item_id': row['item_id'], 'reason': 'not_qualified_for_language'})
            continue
        key = (item['provider'], item['model'], item['language'], target)
        groups[key].append(row)
    output = []
    for (provider, model, language, target), rows in sorted(groups.items()):
        confusion = {emotion: sum(r['perceived_emotion'] == emotion for r in rows) for emotion in sorted(EMOTIONS)}
        output.append({'provider': provider, 'model': model, 'language': language, 'target_emotion': target,
                       'ratings': len(rows), 'listeners': len({r['rater_id'] for r in rows}),
                       'items': len({r['item_id'] for r in rows}), 'identified_target_count': confusion[target],
                       'perceived_counts': confusion,
                       'naturalness_mean': sum(r['naturalness'] for r in rows)/len(rows),
                       'text_fidelity_mean': sum(r['text_fidelity'] for r in rows)/len(rows)})
    return {'status': 'descriptive_native_ratings' if output else 'not_measured', 'groups': output,
            'rejected': rejected, 'certification': False,
            'limitation': 'Unequal targets and few texts are not a fair provider ranking; no population interval or universal emotion accuracy claim.'}
