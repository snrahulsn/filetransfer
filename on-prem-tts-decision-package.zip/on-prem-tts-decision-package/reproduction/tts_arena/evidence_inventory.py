"""Separate source, native-session and browser evidence inventories; no certifications."""
import hashlib
import json
from pathlib import Path


def inventory(root):
    root=Path(root)
    manifest=root/'vendor_evidence/manifest.json'
    sources=json.loads(manifest.read_text()) if manifest.exists() else []
    verified=0;issues=[]
    for item in sources:
        name=item.get('file','')
        if not isinstance(name,str) or not name or Path(name).is_absolute():
            issues.append({'kind':'unsafe_source_capture_path','file':name});continue
        path=(root/name).resolve()
        if not path.is_relative_to(root.resolve()):
            issues.append({'kind':'unsafe_source_capture_path','file':name});continue
        if not path.is_file():
            issues.append({'kind':'missing_source_capture','file':name});continue
        if hashlib.sha256(path.read_bytes()).hexdigest()!=item.get('sha256'):
            issues.append({'kind':'source_hash_mismatch','file':name});continue
        verified+=1
    sessions=[];seen=set()
    for path in sorted((root/'artifacts').rglob('result.json')):
        try:d=json.loads(path.read_text())
        except (ValueError,OSError):
            if any(part.startswith('sessions-access-') for part in path.parts):issues.append({'kind':'invalid_session_json','file':str(path.relative_to(root))})
            continue
        if not isinstance(d,dict) or d.get('evidence_class')!='native_websocket_session':continue
        relative=str(path.relative_to(root))
        provenance=d.get('provenance') if d.get('record_kind')=='derived_failure_observation' else None
        if d.get('record_kind')=='derived_failure_observation' and (not isinstance(provenance,dict) or d.get('status')!='failed'):
            issues.append({'kind':'invalid_derived_session_source','file':relative});continue
        if provenance is not None:
            source=(root/provenance.get('source_file','')).resolve()
            if not source.is_relative_to((root/'artifacts').resolve()) or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest()!=provenance.get('source_sha256'):
                issues.append({'kind':'invalid_derived_session_source','file':relative});continue
            identity=('derived',provenance['source_sha256'],provenance['source_file'])
        else:identity=('canonical',hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest())
        if identity in seen:continue
        seen.add(identity)
        audio=d.get('audio',[]);verified_audio=0;seen_audio=set()
        if not isinstance(audio,list):
            issues.append({'kind':'invalid_native_audio_manifest','file':relative});audio=[]
        for entry in audio:
            if not isinstance(entry,dict):issues.append({'kind':'invalid_native_audio_entry','file':relative});continue
            name=entry.get('path');target=(path.parent/name).resolve() if isinstance(name,str) else None
            if not target or Path(name).is_absolute() or not target.is_relative_to(path.parent.resolve()) or not target.is_file():
                issues.append({'kind':'missing_or_unsafe_native_audio','file':relative,'audio_path':name});continue
            if target in seen_audio:
                issues.append({'kind':'duplicate_native_audio_entry','file':relative,'audio_path':name});continue
            seen_audio.add(target)
            data=target.read_bytes()
            if type(entry.get('bytes'))is not int or len(data)!=entry['bytes']:
                issues.append({'kind':'native_audio_size_mismatch','file':relative,'audio_path':name});continue
            if hashlib.sha256(data).hexdigest()!=entry.get('sha256'):
                issues.append({'kind':'native_audio_hash_mismatch','file':relative,'audio_path':name});continue
            if data:verified_audio+=1
        model=d.get('config',{}).get('model')
        sessions.append({'provider':d.get('provider'),'model':model,'status':d.get('status'),'audio_contexts':verified_audio,'declared_audio_contexts':len(audio),'audio_integrity_verified':verified_audio==len(audio) and bool(audio),'record_kind':d.get('record_kind','canonical_session_observation'),'code_sha256':d.get('code_sha256'),'result_path':relative,'boundary':d.get('boundary'),'current_model_qualification':'not_certified','certification':'not_live_verified'})
    browser=[]
    for folder in sorted((root/'artifacts').glob('browser-access-*')):
        for path in sorted(folder.rglob('result.json')):
            try:d=json.loads(path.read_text())
            except (ValueError,OSError):issues.append({'kind':'invalid_browser_json','file':str(path.relative_to(root))});continue
            if d.get('evidence_kind')!='live_browser_studio':continue
            browser.append({'provider':d.get('provider'),'result_path':str(path.relative_to(root)),'duration_seconds':d.get('duration_seconds'),'adapter_verified':False,'linguistic_quality_verified':False})
    local=[]
    for path in sorted((root/'artifacts').rglob('result.json')):
        try:d=json.loads(path.read_text())
        except (ValueError,OSError):continue
        if d.get('evidence_class')!='local_model_execution':continue
        valid_audio=False
        if d.get('status')=='success':
            audio_name=d.get('audio_file')
            audio=(path.parent/audio_name).resolve() if isinstance(audio_name,str) else None
            if not audio or not audio.is_relative_to((root/'artifacts').resolve()) or not audio.is_file():
                issues.append({'kind':'missing_local_audio','file':str(path.relative_to(root))})
            elif hashlib.sha256(audio.read_bytes()).hexdigest()!=d.get('audio_sha256'):
                issues.append({'kind':'local_audio_hash_mismatch','file':str(path.relative_to(root))})
            else:valid_audio=True
        local.append({'provider':d.get('provider'),'status':d.get('status'),'language':d.get('language'),'stratum':d.get('stratum'),'audio_verified':valid_audio,'result_path':str(path.relative_to(root)),'boundary':d.get('first_audio_boundary'),'certification':'not_live_verified'})
    return {'local_model_attempts':len(local),'local_runs_with_audio':sum(x['audio_verified'] for x in local),'local_model_evidence':local,'source_manifest_entries' :len(sources),'verified_source_captures':verified,'native_session_attempts':len(sessions),'native_session_failed_attempts':sum(x['status'] in {'failed','error','blocked'} for x in sessions),'native_sessions_with_audio':sum(x['audio_contexts']>0 for x in sessions),'native_session_evidence':sessions,'browser_studio_result_records':len(browser),'browser_studio_evidence':browser,'issues':issues}
