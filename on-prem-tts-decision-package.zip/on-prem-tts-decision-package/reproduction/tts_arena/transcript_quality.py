"""Auditable NFC-only transcript diagnostics; never perceptual certification.

References: list of {reference_id, run_id, provider, model, language,
audio_sha256, text, native_reviewed: bool}. Each run/audio has one reference.
Observations: list of {observation_id, reference_id, run_id, provider, model,
language, audio_sha256, source: 'human'|'asr', transcriber_id, text}.
Human transcriber IDs address roster entries with screening_passed exactly True
and verified_native_languages containing the exact language. ASR transcriber IDs
must identify the engine/version; they are retained, not treated as reviewers.

Reference text must be supplied explicitly; synthesis markup is not stripped or
interpreted. Hash matching binds supplied records, not proof of file contents.
"""
from collections import defaultdict
import re

from .metrics import error_rate

_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:@/+\-]*\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_IDENTITY = ('run_id', 'provider', 'model', 'language', 'audio_sha256')


def _identifier(value, field):
    if not isinstance(value, str) or not _ID.fullmatch(value):
        raise ValueError(f'Invalid {field}')


def _record(row, id_field):
    if not isinstance(row, dict):
        raise ValueError('Records must be objects')
    _identifier(row.get(id_field), id_field)
    for field in _IDENTITY:
        value = row.get(field)
        if field == 'audio_sha256':
            if not isinstance(value, str) or not _HASH.fullmatch(value):
                raise ValueError('Invalid audio_sha256: lowercase SHA-256 required')
        elif not isinstance(value, str) or not value.strip() or value != value.strip() or any(ord(c) < 32 for c in value):
            raise ValueError(f'Invalid {field}')
    _identifier(row['run_id'], 'run_id')
    if not isinstance(row.get('text'), str):
        raise ValueError('text must be a string')


def evaluate_transcripts(observations, references, roster):
    """Return per-record edit counts and raw micro totals, with rejected humans.

    Word units use whitespace splitting; CER counts NFC Unicode codepoints,
    including whitespace and punctuation, not graphemes. No case folding,
    transliteration, number expansion, punctuation removal or language coercion.
    Repeated transcriptions are separate observations, not independent audio.
    """
    if not isinstance(observations, list) or not isinstance(references, list) or not isinstance(roster, dict):
        raise ValueError('observations/references must be lists and roster a mapping')
    if not references:
        raise ValueError('At least one reference is required')
    lookup, audio_runs = {}, set()
    for reference in references:
        _record(reference, 'reference_id')
        if type(reference.get('native_reviewed')) is not bool:
            raise ValueError('native_reviewed must be boolean')
        if not reference['text'].strip():
            raise ValueError('Reference must contain at least one word')
        rid = reference['reference_id']
        key = (reference['run_id'], reference['audio_sha256'])
        if rid in lookup or key in audio_runs:
            raise ValueError('Duplicate reference ID or run/audio reference')
        lookup[rid] = reference
        audio_runs.add(key)

    seen, pairs, rejected, details, groups = set(), set(), [], [], defaultdict(list)
    for observation in observations:
        _record(observation, 'observation_id')
        _identifier(observation.get('reference_id'), 'reference_id')
        _identifier(observation.get('transcriber_id'), 'transcriber_id')
        source = observation.get('source')
        if source not in ('human', 'asr'):
            raise ValueError('source must be human or asr')
        oid, rid = observation['observation_id'], observation['reference_id']
        pair = (rid, source, observation['transcriber_id'])
        if oid in seen or pair in pairs:
            raise ValueError('Duplicate observation ID or reference/source/transcriber')
        seen.add(oid)
        pairs.add(pair)
        if rid not in lookup:
            raise ValueError('Unknown reference_id')
        reference = lookup[rid]
        if any(observation[field] != reference[field] for field in _IDENTITY):
            raise ValueError('Observation/reference identity mismatch')
        if source == 'human':
            person = roster.get(observation['transcriber_id'])
            languages = person.get('verified_native_languages') if isinstance(person, dict) else None
            qualified = (isinstance(person, dict) and person.get('screening_passed') is True
                         and isinstance(languages, list) and all(isinstance(x, str) for x in languages)
                         and reference['language'] in languages)
            if not qualified:
                rejected.append({'observation_id': oid, 'reference_id': rid,
                                 'reason': 'human_not_qualified_for_exact_locale'})
                continue
        result = {key: observation[key] for key in ('observation_id', 'reference_id', *_IDENTITY, 'source', 'transcriber_id')}
        result.update(reference_native_reviewed=reference['native_reviewed'],
                      asr_engine_id=observation['transcriber_id'] if source == 'asr' else None,
                      wer=error_rate(reference['text'], observation['text'], 'word'),
                      cer=error_rate(reference['text'], observation['text'], 'codepoint'))
        details.append(result)
        groups[tuple(result[k] for k in ('provider', 'model', 'language', 'source', 'reference_native_reviewed', 'asr_engine_id'))].append(result)
    summaries = []
    for key, rows in sorted(groups.items()):
        summary = dict(zip(('provider', 'model', 'language', 'source', 'reference_native_reviewed', 'asr_engine_id'), key))
        summary.update(observations=len(rows), references=len({r['reference_id'] for r in rows}),
                       transcriber_ids=sorted({r['transcriber_id'] for r in rows}))
        for metric in ('wer', 'cer'):
            distance = sum(r[metric]['distance'] for r in rows)
            denominator = sum(r[metric]['reference_units'] for r in rows)
            summary[metric] = {'distance': distance, 'reference_units': denominator,
                               'rate': distance / denominator if denominator else None,
                               'aggregation': 'micro_over_observations'}
        summaries.append(summary)
    return {'status': 'transcript_diagnostics' if details else 'not_measured',
            'normalization': 'NFC_only', 'certification': False,
            'groups': summaries, 'observations': details, 'rejected': rejected,
            'limitation': 'ASR is diagnostic only. Native reviewer screening and reference review are supplied declarations. '
                          'WER/CER do not establish naturalness, accent, emotion or universal accuracy. '
                          'Repeated transcriptions reuse audio; no independence or confidence interval is claimed.'}
