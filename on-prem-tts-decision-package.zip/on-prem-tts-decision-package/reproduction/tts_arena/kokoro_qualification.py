"""Pure descriptive summaries for bounded retained-model local observations."""
from collections import defaultdict


def summarize(records):
    groups=defaultdict(list)
    for r in records:
        if r.get('status')!='success':continue
        groups[(r['stratum'],r['text_sha256'],r['voice'],r['language'])].append(r)
    result=[]
    for (stratum,text_hash,voice,language),rows in sorted(groups.items()):
        normal=[r for r in rows if r['speed']==1.0]
        slow=[r for r in rows if r['speed']==.8]
        fast=[r for r in rows if r['speed']==1.2]
        direction=None if not slow or not fast else slow[0]['duration_seconds']>fast[0]['duration_seconds']
        result.append({'stratum':stratum,'voice':voice,'language':language,'text_sha256':text_hash,'successful_samples':len(rows),
          'speed_1_wall_seconds':[r['synthesis_wall_seconds'] for r in normal],
          'speed_1_duration_seconds':[r['duration_seconds'] for r in normal],
          'slow_duration_seconds':slow[0]['duration_seconds'] if slow else None,'fast_duration_seconds':fast[0]['duration_seconds'] if fast else None,
          'speed_direction_observed':direction,'slow_to_fast_duration_ratio':slow[0]['duration_seconds']/fast[0]['duration_seconds'] if slow and fast and fast[0]['duration_seconds']>0 else None,
          'warm_speed_1_realtime_factor':normal[1]['realtime_factor'] if len(normal)>1 else None,
          'warm_speed_1_audio_identical_to_first':normal[0]['audio_sha256']==normal[1]['audio_sha256'] if len(normal)>1 else None})
    return {'attempts':len(records),'successful_samples':sum(r.get('status')=='success' for r in records),'groups':result,
       'all_three_groups_complete':len(result)==3 and all(r['successful_samples']==4 for r in result),'scope':'Descriptive low-n single-process CPU observations; no production percentiles, naturalness or language correctness claims.'}
