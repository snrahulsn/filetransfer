"""Independent source-WAV check for the bounded Soniox speed pair."""
import hashlib
import io
import json
import math
from pathlib import Path
import wave
from .streaming_wav import repair_header


def verify(folder):
    folder = Path(folder)
    report = json.loads((folder / 'summary.json').read_text())
    if (report.get('schema') != 'soniox_speed_pair_v1' or not report.get('completed') or
            report.get('provider') != 'soniox' or report.get('model') != 'tts-rt-v2' or
            report.get('language') != 'hi-IN' or report.get('max_requests') != 2 or
            report.get('automatic_retries') != 0 or len(report.get('attempts', [])) != 2 or
            len(report.get('configs', [])) != 2):
        raise ValueError('Soniox speed pair scope or request count differs')
    rows, configs = [], []
    for entry, config in zip(report['attempts'], report['configs']):
        if entry['requested_speed'] != config.get('speed') or not .7 <= entry['requested_speed'] <= 1.3:
            raise ValueError('Soniox requested speed differs')
        run_id = entry['run_id']
        path = folder / 'runs' / run_id
        if Path(entry['result_path']).name != 'result.json' or Path(entry['result_path']).parent.name != run_id:
            raise ValueError('Soniox result path differs')
        result = json.loads((path / 'result.json').read_text())
        if (result['run_id'] != run_id or result['provider'] != 'soniox' or result['language'] != 'hi-IN' or
                result['config'] != config or result['text'] != report['text'] or
                result['status'] != entry['status'] or result['status'] != 'success' or
                result.get('http_status') != 200 or entry.get('http_status') != 200 or
                result.get('evidence_class') != 'live_http' or result.get('stratum') != 'speed_paired_control'):
            raise ValueError('Soniox result identity or HTTP success differs')
        audio_file = result['audio_file']
        if Path(audio_file).name != audio_file:
            raise ValueError('Soniox audio path unsafe')
        raw = (path / audio_file).read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if sha != result['audio_sha256'] or sha != entry['saved_audio_sha256'] or sha != entry['audio_sha256'] or len(raw) != entry['audio_bytes']:
            raise ValueError('Soniox source WAV bytes/hash differ')
        playable, header = repair_header(raw)
        if not header['header_repaired']:
            raise ValueError('Soniox streaming WAV header sentinel was not repaired')
        with wave.open(io.BytesIO(playable), 'rb') as wav:
            if wav.getnchannels() != 1 or wav.getsampwidth() != 2 or wav.getframerate() != 24000:
                raise ValueError('Soniox WAV format differs')
            duration = wav.getnframes() / wav.getframerate()
        if not math.isfinite(duration) or duration <= 0 or abs(duration - entry['duration_seconds']) > .005 or abs(duration - result['duration_seconds']) > .005:
            raise ValueError('Soniox decoded duration differs')
        rows.append({'run_id': run_id, 'speed': config['speed'], 'duration_seconds': duration,
                     'source_wav_sha256': sha, 'source_wav_bytes': len(raw),
                     'playable_wav_sha256': hashlib.sha256(playable).hexdigest()})
        configs.append({key: value for key, value in config.items() if key != 'speed'})
    if configs[0] != configs[1] or report['configs'][0]['speed'] >= report['configs'][1]['speed']:
        raise ValueError('Soniox pair changed a control other than speed')
    ratio = rows[1]['duration_seconds'] / rows[0]['duration_seconds']
    paired = report.get('paired_output', {})
    if (abs(ratio - paired.get('duration_ratio_high_over_low', -1)) > .002 or
            paired.get('shorter_at_higher_speed') is not (ratio < 1) or
            paired.get('wav_hashes_differ') is not (rows[0]['source_wav_sha256'] != rows[1]['source_wav_sha256']) or
            paired.get('qualifies_native_speed_effect') is not False):
        raise ValueError('Soniox paired duration/quality interpretation differs')
    return {'schema': 'soniox_speed_pair_audit_v1', 'provider': 'soniox', 'model': 'tts-rt-v2',
            'language': 'hi-IN', 'text': report['text'], 'voice': report['voice'],
            'source': report['source'], 'requests': len(rows), 'automatic_retries': 0,
            'clips': rows, 'duration_ratio_high_over_low': ratio,
            'shorter_at_higher_speed': ratio < 1, 'native_speed_effect_certified': False,
            'boundary': report['boundary']}


def verify_four_setting_sweep(root):
    """Join the previous two-setting trial to the newer bounded pair without reruns."""
    root = Path(root)
    fresh = verify(root / 'artifacts/soniox-speed-20260916')
    old = json.loads((root / 'artifacts/speed-pairs-20260915/summary.json').read_text())
    pair = old['pairs']['soniox']
    if (old['reference_text'] != fresh['text'] or pair['status'] != 'measured_pair' or
            pair['provider'] != 'soniox' or pair['model'] != fresh['model'] or
            pair['voice'] != fresh['voice'] or old['automatic_retries'] != 0 or
            len(pair['records']) != 2):
        raise ValueError('Previous Soniox speed pair scope differs')
    clips = list(fresh['clips'])
    for entry in pair['records']:
        path = root / 'artifacts/runs/speed-pairs-20260915' / entry['run_id']
        result = json.loads((path / 'result.json').read_text())
        config = result['config']
        if (result['provider'] != 'soniox' or result['status'] != 'success' or
                result.get('http_status') != 200 or entry['status'] != 'success' or
                entry['http_status'] != 200 or result['run_id'] != entry['run_id'] or
                result['text'] != fresh['text'] or result['language'] != 'hi-IN' or
                config != entry['config'] or config.get('speed') != entry['speed'] or
                config.get('model') != fresh['model'] or config.get('voice') != fresh['voice'] or
                config.get('sample_rate') != 24000 or config.get('format') != 'wav'):
            raise ValueError('Previous Soniox speed result identity differs')
        audio_file = result['audio_file']
        if Path(audio_file).name != audio_file:
            raise ValueError('Previous Soniox audio path unsafe')
        raw = (path / audio_file).read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if sha != entry['audio_sha256'] or sha != result['audio_sha256'] or len(raw) != result['audio_bytes']:
            raise ValueError('Previous Soniox speed source WAV hash differs')
        playable, _ = repair_header(raw)
        with wave.open(io.BytesIO(playable), 'rb') as wav:
            duration = wav.getnframes() / wav.getframerate()
            if wav.getframerate() != 24000 or wav.getnchannels() != 1 or wav.getsampwidth() != 2:
                raise ValueError('Previous Soniox speed WAV format differs')
        if abs(duration - entry['duration_seconds']) > .005 or abs(duration - result['duration_seconds']) > .005:
            raise ValueError('Previous Soniox speed WAV duration differs')
        clips.append({'run_id': entry['run_id'], 'speed': entry['speed'],
                      'duration_seconds': duration, 'source_wav_sha256': sha,
                      'source_wav_bytes': len(raw),
                      'playable_wav_sha256': hashlib.sha256(playable).hexdigest()})
    clips.sort(key=lambda row: row['speed'])
    if [row['speed'] for row in clips] != [.8, .85, 1.15, 1.2]:
        raise ValueError('Soniox four-setting control values differ')
    if len({row['run_id'] for row in clips}) != 4:
        raise ValueError('Soniox four-setting runs duplicate')
    monotonic = all(left['duration_seconds'] > right['duration_seconds'] for left, right in zip(clips, clips[1:]))
    return {**fresh, 'four_setting_observation': {
        'speeds': [row['speed'] for row in clips],
        'durations_seconds': [row['duration_seconds'] for row in clips],
        'durations_decrease_at_all_higher_settings_in_these_samples': monotonic,
        'same_text_model_voice': True, 'same_setting_replicates': 0,
        'native_intelligibility_verified': False},
        'sweep_clips': clips,
        'sweep_boundary': 'Four distinct settings in two bounded pairs; no same-setting repeats or listener judgment.'}
