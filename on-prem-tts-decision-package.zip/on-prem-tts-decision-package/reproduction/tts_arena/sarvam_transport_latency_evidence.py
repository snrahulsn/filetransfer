"""Recompute the bounded Sarvam transport comparison from its saved MP3/WAV files."""
import hashlib
import json
import math
import subprocess
import wave
from pathlib import Path

from .matched_latency_evidence import interval
from .metrics import percentile


def verify(root):
    root = Path(root).resolve()
    if root.name != 'sarvam-transport-latency-20260916-v2':
        raise ValueError('Unexpected Sarvam transport evidence root')
    project = root.parents[1]
    manifest = json.loads((root / 'manifest.json').read_text())
    order = [['http_stream', 'websocket'] if i % 2 == 0 else ['websocket', 'http_stream'] for i in range(12)]
    if (manifest.get('schema') != 'sarvam_bulbul_v3_mp3_balanced_transport_v1'
        or manifest.get('status') != 'complete' or manifest.get('order') != order
        or manifest.get('successful') != {'http_stream': 12, 'websocket': 12}
        or manifest.get('attempts_total') != 24 or manifest.get('automatic_retries') != 0
        or manifest.get('client_egress_country_start') != 'IN'
        or manifest.get('client_egress_country_end') != 'IN'
        or manifest.get('provider') != 'sarvam' or manifest.get('model') != 'bulbul:v3'
        or manifest.get('language') != 'hi-IN' or manifest.get('voice') != 'shubh'
        or manifest.get('account_specific_cost_verified') is not False
        or len(manifest.get('results', [])) != 24):
        raise ValueError('Sarvam transport trial scope or completion changed')
    text = manifest['text']
    if hashlib.sha256(text.encode()).hexdigest() != manifest['text_sha256']:
        raise ValueError('Sarvam transport transcript hash changed')
    if len(text) * 24 > manifest['max_text_characters'] or len(text) * 24 * 30 / 10000 > manifest['published_rate_trial_cap_rupees']:
        raise ValueError('Sarvam transport spending cap breached')
    rest = manifest['rest_request']
    config = manifest['websocket_config']['data']
    for left, right in [('model', 'model'), ('language_code', 'language_code'),
                        ('speaker', 'speaker'), ('pace', 'pace'), ('temperature', 'temperature'),
                        ('output_audio_codec', 'output_audio_codec')]:
        if left == 'model':
            if rest[left] != manifest['model']:
                raise ValueError('REST model changed')
        elif rest[left] != config[right]:
            raise ValueError('Matched route setting changed: ' + left)
    if (rest['speech_sample_rate'] != 24000 or config['speech_sample_rate'] != '24000'
        or rest['output_audio_bitrate'] != '128k'
        or rest['enable_preprocessing'] is not False or rest['enable_cached_responses'] is not False):
        raise ValueError('Sarvam MP3 rate or HTTP normalization condition changed')
    samples = {'http_stream': [], 'websocket': []}
    positions = {'http_stream': [[], []], 'websocket': [[], []]}
    pairs = {}
    clips = []
    for index, row in enumerate(manifest['results']):
        ordinal, position = divmod(index, 2)
        ordinal += 1
        route = order[ordinal-1][position]
        if row.get('route') != route or row.get('ordinal') != ordinal or row.get('status') != 'success':
            raise ValueError('Sarvam route order or row changed')
        if route == 'http_stream' and row.get('http_status') != 200:
            raise ValueError('Sarvam HTTP route lacked successful status')
        if route == 'websocket' and row.get('terminal_observed') is not True:
            raise ValueError('Sarvam WebSocket lacked final event')
        timing = row.get('first_audio_ms')
        if type(timing) not in (int, float) or not math.isfinite(timing) or timing <= 0:
            raise ValueError('Sarvam MP3 first-audio timing invalid')
        if sum(row.get('received_chunk_bytes', [])) != row['mp3_bytes']:
            raise ValueError('Sarvam received MP3 byte count changed')
        paths = []
        for key in ('mp3_path', 'wav_path'):
            path = (project / row[key]).resolve()
            if not path.is_relative_to(root / route / f'{ordinal:02d}') or not path.is_file():
                raise ValueError('Sarvam audio path escaped trial scope')
            paths.append(path)
        mp3, wav = paths
        original = mp3.read_bytes()
        playable = wav.read_bytes()
        if (len(original) != row['mp3_bytes'] or len(original) > 2_000_000
            or hashlib.sha256(original).hexdigest() != row['mp3_sha256']
            or hashlib.sha256(playable).hexdigest() != row['wav_sha256']):
            raise ValueError('Sarvam MP3/WAV digest changed')
        fresh = subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(mp3),
                                '-ac', '1', '-ar', '24000', '-f', 's16le', '-'],
                               capture_output=True, timeout=15, check=True).stdout
        with wave.open(str(wav), 'rb') as reader:
            if (reader.getnchannels(), reader.getsampwidth(), reader.getframerate()) != (1, 2, 24000):
                raise ValueError('Sarvam WAV format changed')
            if reader.readframes(reader.getnframes()) != fresh:
                raise ValueError('Sarvam WAV does not decode from saved MP3')
            if abs(reader.getnframes()/24000 - row['duration_seconds']) > 1/24000:
                raise ValueError('Sarvam WAV duration changed')
        samples[route].append(timing)
        positions[route][position].append(timing)
        pairs.setdefault(ordinal, {})[route] = timing
        clips.append({'route': route, 'ordinal': ordinal, 'wav_sha256': row['wav_sha256'],
                      'duration_seconds': row['duration_seconds'],
                      'source_wav': row['wav_path'], 'first_audio_ms': round(timing, 2)})
    if any(len(samples[r]) != 12 or len(positions[r][p]) != 6 for r in samples for p in (0, 1)):
        raise ValueError('Sarvam balanced route count changed')
    delta = [pairs[i]['http_stream'] - pairs[i]['websocket'] for i in range(1, 13)]
    groups = {route: {'model': 'bulbul:v3', 'voice': 'shubh', 'locale': 'hi-IN',
                      'codec': 'mp3', 'sample_rate': 24000, 'trials': 12,
                      'values_ms': [round(x, 2) for x in samples[route]],
                      'first_in_pair_values_ms': [round(x, 2) for x in positions[route][0]],
                      'second_in_pair_values_ms': [round(x, 2) for x in positions[route][1]],
                      'p50': interval(samples[route], .5, 6610 + i),
                      'p95': interval(samples[route], .95, 7710 + i)}
              for i, route in enumerate(('http_stream', 'websocket'))}
    return {'schema': 'sarvam_transport_latency_audit_v1', 'provider': 'sarvam',
            'model': 'bulbul:v3', 'voice': 'shubh', 'requested_locale': 'hi-IN',
            'status': 'observed_balanced_same_vendor_routes',
            'source_manifest': str((root/'manifest.json').relative_to(project)),
            'client_egress_country': 'IN', 'route_order_balanced': True,
            'first_audio_boundary': manifest['latency_boundary'],
            'same_prompt_model_voice_mp3': True, 'qualified_route_comparison': True,
            'quality_certification': False, 'cost_reconciled': False,
            'production_playout_verified': False, 'successful_requests': 24,
            'list_rate_trial_estimate_rupees': round(len(text)*24*30/10000, 2),
            'groups': groups, 'paired_http_minus_websocket_ms': {
                'values_ms': [round(x, 2) for x in delta],
                'median_ms': round(percentile(delta, .5), 2),
                'http_slower_pairs': sum(x > 0 for x in delta)},
            'clips': clips,
            'limitations': ['Client first received MP3 bytes, not first audible telephone audio.',
                            'The instrumented arrival timestamps were saved in the manifest; raw packet timestamps were not captured independently.',
                            'Vendor serving region and account-specific billing were not verified.',
                            'Twelve unloaded trials per route do not measure production concurrency.']}
