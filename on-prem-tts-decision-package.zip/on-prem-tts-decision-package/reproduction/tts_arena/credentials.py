"""Read an explicitly selected credential file without executing shell statements."""
from pathlib import Path
import re

ALIASES = {'DEEPGRAM_API_KEY':'Deepgram','RIME_API_KEY':'Rime','SARVAM_API_KEY':'Sarvam',
    'SMALLEST_API_KEY':'Smallest','FISH_API_KEY':'Fish','GNANI_API_KEY_ID':'Gnani',
    'CARTESIA_API_KEY':'Cartesia','MURF_API_KEY':'Murf','HUME_API_KEY':'Hume_API',
    'INWORLD_API_KEY':'Inworld_API_Key','SONIOX_API_KEY':'Soniox'}

def read_credentials(path):
    values = {}
    for line in Path(path).read_text().splitlines():
        match = re.match(r'^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$', line)
        if not match: continue
        name, value = match.groups()
        value = value.strip()
        if value.startswith(('"', "'")):
            quote=value[0]; end=value.find(quote,1)
            if end < 0: raise ValueError('Unterminated quoted credential')
            value=value[1:end]
        else:
            value=re.split(r'\s+#',value,maxsplit=1)[0].strip()
        if value: values[name]=value
    for target,source in ALIASES.items():
        if target not in values and source in values: values[target]=values[source]
    return values

def redact(value, credentials):
    """Sanitize text diagnostics before displaying/persisting them."""
    text=str(value)
    for secret in sorted(set(credentials.values()),key=len,reverse=True):
        if len(secret)>=4: text=text.replace(secret,'[REDACTED]')
    text=re.sub(r'(?i)(bearer|basic|token)\s+[A-Za-z0-9_./+=:-]+',r'\1 [REDACTED]',text)
    return text
