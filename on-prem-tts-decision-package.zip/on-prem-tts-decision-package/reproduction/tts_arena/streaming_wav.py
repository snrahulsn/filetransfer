"""Repair unknown-length PCM WAV stream headers without changing the audio samples."""
import io
import struct
import wave


def repair_header(raw):
    """Return (playable WAV, audit). Preserve every non-data chunk and the exact PCM."""
    if not isinstance(raw, bytes) or raw[:4] != b'RIFF' or raw[8:12] != b'WAVE':
        raise ValueError('Expected RIFF/WAVE bytes')
    if len(raw) < 44 or len(raw) >= 2**32:
        raise ValueError('WAV size outside supported bounds')
    offset = 12
    fmt = None
    data_header = None
    data_start = None
    data_declared = None
    while offset + 8 <= len(raw):
        kind = raw[offset:offset + 4]
        declared = struct.unpack_from('<I', raw, offset + 4)[0]
        start = offset + 8
        if kind == b'fmt ':
            if declared < 16 or start + declared > len(raw) or fmt is not None:
                raise ValueError('Invalid WAV format chunk')
            fmt = struct.unpack_from('<HHIIHH', raw, start)
        if kind == b'data':
            if fmt is None or data_header is not None:
                raise ValueError('WAV data chunk missing format or repeated')
            data_header, data_start, data_declared = offset, start, declared
            break
        next_offset = start + declared + (declared & 1)
        if next_offset > len(raw):
            raise ValueError('WAV metadata chunk exceeds file')
        offset = next_offset
    if data_header is None:
        raise ValueError('WAV data chunk missing')
    format_tag, channels, sample_rate, byte_rate, block_align, bits = fmt
    if (format_tag, channels, bits) != (1, 1, 16) or not 0 < sample_rate <= 96000 or (
        block_align != 2 or byte_rate != sample_rate * 2):
        raise ValueError('Streaming WAV repair supports PCM16 mono only')
    remaining = len(raw) - data_start
    if remaining <= 0 or remaining % block_align:
        raise ValueError('WAV PCM is missing or truncated')
    riff_declared = struct.unpack_from('<I', raw, 4)[0]
    streaming = data_declared > remaining or riff_declared > len(raw) - 8
    if streaming:
        mutable = bytearray(raw)
        struct.pack_into('<I', mutable, 4, len(raw) - 8)
        struct.pack_into('<I', mutable, data_header + 4, remaining)
        repaired = bytes(mutable)
    else:
        repaired = raw
    with wave.open(io.BytesIO(repaired), 'rb') as parsed:
        if (parsed.getnchannels(), parsed.getsampwidth(), parsed.getframerate()) != (1, 2, sample_rate):
            raise ValueError('Repaired WAV decoder format changed')
        expected_frames = remaining // 2 if streaming or data_declared == remaining else data_declared // 2
        if parsed.getnframes() != expected_frames:
            raise ValueError('Repaired WAV frame count differs from PCM bytes')
        decoded = parsed.readframes(expected_frames)
        if decoded != raw[data_start:data_start + expected_frames * 2]:
            raise ValueError('Repaired WAV samples changed')
    return repaired, {'header_repaired': streaming, 'sample_rate': sample_rate,
                      'pcm_bytes': expected_frames * 2, 'duration_seconds': expected_frames / sample_rate,
                      'original_riff_size': riff_declared, 'original_data_size': data_declared,
                      'data_offset': data_start}
