"""Bounded HTTP transport, independently testable against a local fixture server."""
import asyncio
import base64
import codecs
import hashlib
import importlib
import json
import struct
import time
from urllib.parse import urlparse

import httpx


def dotted(value, path):
    if not path:
        return value
    for key in path.split("."):
        value = value[int(key)] if isinstance(value, list) else value[key]
    return value


class SSEDecoder:
    def __init__(self):
        self.decoder = codecs.getincrementaldecoder("utf-8")()
        self.buffer = ""

    def feed(self, data, final=False):
        self.buffer += self.decoder.decode(data, final=final)
        # CRLF can be split across network reads. Only complete lines are consumed.
        events = []
        normalized = self.buffer.replace("\r\n", "\n")
        while "\n\n" in normalized:
            block, normalized = normalized.split("\n\n", 1)
            event, lines = "message", []
            for line in block.split("\n"):
                if line.startswith("event:"):
                    event = line[6:].lstrip(" ")
                elif line.startswith("data:"):
                    lines.append(line[5:].lstrip(" "))
            if lines:
                events.append((event, "\n".join(lines)))
        self.buffer = normalized
        if final and self.buffer.strip():
            raise ValueError("Truncated SSE event (missing event delimiter)")
        return events


def decode_audio(value, mode):
    if not isinstance(value, str):
        raise ValueError("Audio field must be encoded string")
    return bytes.fromhex(value) if mode.endswith("hex") else base64.b64decode(value, validate=True)


def safe_url(url, allow_local=False):
    parsed = urlparse(url)
    local = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
    if parsed.username or parsed.password or (parsed.scheme != "https" and not (allow_local and local and parsed.scheme == "http")):
        raise ValueError("HTTPS endpoint required; localhost HTTP requires explicit test opt-in")
    return parsed


async def synthesize(spec, timeout=60.0, max_bytes=32_000_000, allow_local=False, cancel_after=None, client=None):
    safe_url(spec.url, allow_local)
    if timeout <= 0 or max_bytes < 1 or (cancel_after is not None and cancel_after < 0):
        raise ValueError("Invalid transport bounds")
    modes = {"binary", "json_base64", "json_hex", "json_url", "sse_base64", "sse_hex"}
    if spec.response_mode not in modes:
        raise ValueError(f"Unsupported response mode {spec.response_mode}")
    origin = time.perf_counter_ns()
    events, audio, wire = [], bytearray(), bytearray()
    result = {"status": "pending", "first_byte_ms": None, "first_payload_ms": None, "first_audio_ms": None, "http_status": None,
              "first_audio_boundary": "first_complete_PCM_frame_received_not_played; null_for_undecoded_formats", "provider_request_id": None,
              "cancel_semantics": "client_http_task_abort_only" if cancel_after is not None else None,
              "provider_usage":[],"provider_metadata":[],"connection_policy":"pooled_explicit_client" if client is not None else "new_client_per_request"}

    def event(kind, **fields):
        stamp = time.perf_counter_ns()
        events.append({"sequence": len(events), "monotonic_ns": stamp, "elapsed_ms": (stamp-origin)/1e6, "event_type": kind, **fields})

    def check_envelope(value):
        if not isinstance(value,dict): return
        status=value.get("status_code")
        if value.get("error") or value.get("errors") or value.get("type")=="error" or (isinstance(status,int) and status>=400):
            raise ValueError("Provider reported an error envelope")
        if isinstance(value.get("base_resp"),dict) and value["base_resp"].get("status_code",0)!=0:
            raise ValueError("Provider reported nonzero base response status")
        selected={k:v for k,v in value.items() if k in {"alignment","normalized_alignment","timestamps","model","model_id","modelId","request_id","usage"}}
        if selected: result["provider_metadata"].append(selected)
        decoder_module=spec.metadata.get("json_metadata_decoder_module")
        if decoder_module:
            try:
                if not isinstance(decoder_module,str) or not decoder_module.startswith("tts_arena.adapters.") or any(not part.isidentifier() for part in decoder_module.split('.')):raise ValueError("Invalid JSON metadata decoder")
                decoded=importlib.import_module(decoder_module).decode_json_metadata(value,spec.metadata)
                if not isinstance(decoded,dict) or len(json.dumps(decoded).encode())>1_000_000:raise ValueError("Metadata decoder result exceeds bounds")
                result["provider_metadata"].append(decoded)
            except Exception as exc:
                # Metadata quality is separate from successful audio/network synthesis.
                result.setdefault("provider_metadata_errors",[]).append({"error_type":type(exc).__name__,"stage":"json_metadata_decode"})


    def append_audio(data):
        if data and result["first_payload_ms"] is None:
            result["first_payload_ms"] = (time.perf_counter_ns()-origin)/1e6
        if len(audio) + len(data) > max_bytes:
            raise ValueError("Decoded audio exceeds byte bound")
        audio.extend(data)
        if result["first_audio_ms"] is None:
            playable = False
            if audio[:4] == b"RIFF":
                pos, pcm_frame_size = 12, None
                while len(audio) >= pos + 8:
                    name, size = bytes(audio[pos:pos+4]), struct.unpack_from("<I", audio, pos+4)[0]
                    if name == b"fmt " and len(audio) >= pos+24:
                        fmt, channels, rate, byte_rate, alignment, bits = struct.unpack_from("<HHIIHH", audio, pos+8)
                        if fmt == 1 and bits == 16:
                            pcm_frame_size = alignment
                    if name == b"data":
                        playable = bool(pcm_frame_size and len(audio) >= pos+8+pcm_frame_size)
                        break
                    pos += 8 + size + size % 2
            elif spec.encoding in {"pcm_s16le", "pcm16", "pcm", "linear16"} and len(audio) >= 2 * spec.channels:
                playable = True
            if playable:
                result["first_audio_ms"] = (time.perf_counter_ns()-origin)/1e6
        if data:
            event("audio_payload", byte_count=len(data), cumulative_bytes=len(audio))

    async def perform(http):
        kwargs = {"json": spec.body} if isinstance(spec.body, dict) else {"content": spec.body}
        event("request_start")
        parser = SSEDecoder()
        terminal_seen=False
        decoder_module=spec.metadata.get("sse_decoder_module")
        decoder=None
        if decoder_module:
            if not isinstance(decoder_module,str) or not decoder_module.startswith("tts_arena.adapters.") or any(not part.isidentifier() for part in decoder_module.split('.')):
                raise ValueError("SSE decoder must be a local adapter module")
            decoder=importlib.import_module(decoder_module).decode_sse_event

        def consume_sse(items):
            nonlocal terminal_seen
            for kind, payload in items:
                event("sse_event", name=kind)
                if decoder:
                    decoded=decoder(kind,payload)
                    if decoded is None: continue
                    if terminal_seen: raise ValueError("Event after terminal synthesis event")
                    if decoded.get("metadata"):
                        result["provider_metadata"].append(decoded["metadata"])
                        event("provider_timing",metadata=decoded["metadata"])
                    if decoded.get("error"): raise ValueError("Provider SSE error event")
                    if decoded.get("usage"): result["provider_usage"].append(decoded["usage"])
                    if decoded.get("audio") is not None: append_audio(decode_audio(decoded["audio"],spec.response_mode))
                    terminal_seen=decoded.get("terminal",False)
                    continue
                if kind in {"error", "failed"}:
                    raise ValueError("Provider SSE error event")
                if payload == "[DONE]":
                    continue
                terminal=spec.metadata.get("sse_terminal_event")
                if terminal and kind==terminal:
                    terminal_value=json.loads(payload)
                    check_envelope(terminal_value)
                    if terminal=="complete" and terminal_value.get("is_final") is not True:
                        raise ValueError("Completion event did not confirm final synthesis")
                    terminal_seen=True
                target = spec.metadata.get("sse_audio_event")
                if target and kind != target:
                    continue
                if spec.metadata.get("sse_data_format") == "raw_base64":
                    append_audio(decode_audio(payload, spec.response_mode))
                    continue
                value = json.loads(payload)
                check_envelope(value)
                if isinstance(value, dict) and (value.get("error") or value.get("type") == "error"):
                    raise ValueError("Provider error in SSE payload")
                if isinstance(value,dict) and isinstance(value.get("usage"),dict):
                    result["provider_usage"].append({k:v for k,v in value["usage"].items() if isinstance(v,(int,float,dict))})
                try:
                    encoded = dotted(value, spec.audio_path)
                except (KeyError, IndexError):
                    # Usage, end and timestamp events are not audio. Preserve event timing.
                    continue
                if encoded is not None:
                    append_audio(decode_audio(encoded, spec.response_mode))

        async with http.stream(spec.method, spec.url, headers=spec.headers, **kwargs) as response:
            result["http_status"] = response.status_code
            result["provider_request_id"] = next((response.headers[k] for k in ("x-request-id", "request-id", "x-ms-request-id", "x-amzn-requestid", "speechify-request-id") if k in response.headers), None)
            request_characters=response.headers.get("x-amzn-requestcharacters")
            if request_characters and request_characters.isdigit():
                result["provider_usage"].append({"request_characters":int(request_characters),"source":"x-amzn-requestcharacters"})
            event("response_headers", status=response.status_code)
            response.raise_for_status()
            content_type=response.headers.get("content-type","").split(";",1)[0].lower()
            result["content_type"]=content_type
            if decoder and content_type!="text/event-stream":
                raise ValueError("Expected SSE content type")
            if spec.metadata.get("validate_audio_content_type"):
                # Opt-in raw-audio contract: a differing rate must fail rather than
                # producing plausible but incorrectly timed benchmark measurements.
                header_name=spec.metadata.get("audio_content_type_header","content-type")
                parts=response.headers.get(header_name, "").lower().split(";")
                params={}
                for part in parts[1:]:
                    key,sep,value=part.strip().partition("=")
                    key=key.strip()
                    if sep:
                        if key in params: raise ValueError("Duplicate audio content-type parameter")
                        params[key]=value.strip().strip('"')
                expected_type="audio/basic" if spec.encoding=="mulaw" else "audio/l16"
                if parts[0].strip()!=expected_type or params.get("rate")!=str(spec.sample_rate):
                    raise ValueError("Actual audio format/rate differs from requested contract")
                if params.get("channels", "1" if spec.encoding=="mulaw" else "")!=str(spec.channels):
                    raise ValueError("Actual audio channels differ from requested contract")
                result["observed_audio_format"]={"encoding":spec.encoding,"sample_rate":spec.sample_rate,"channels":spec.channels,"source":header_name+"; PCM byte order follows vendor specification"}
            if spec.response_mode=="binary" and (content_type in {"application/json","text/html","text/plain"} or content_type.endswith("+json")):
                raise ValueError("Non-audio content type for binary audio contract")
            async for chunk in response.aiter_bytes():
                if not chunk:
                    continue
                if result["first_byte_ms"] is None:
                    result["first_byte_ms"] = (time.perf_counter_ns()-origin)/1e6
                if len(wire) + len(chunk) > max_bytes:
                    raise ValueError("Wire response exceeds byte bound")
                wire.extend(chunk)
                event("wire_chunk", byte_count=len(chunk))
                if spec.response_mode == "binary":
                    append_audio(chunk)
                elif spec.response_mode.startswith("sse_"):
                    consume_sse(parser.feed(chunk))
            if spec.response_mode.startswith("sse_"):
                consume_sse(parser.feed(b"", final=True))
                if spec.metadata.get("sse_terminal_event") and not terminal_seen:
                    raise ValueError("Truncated synthesis: required terminal event missing")
            elif spec.response_mode.startswith("json_"):
                value = json.loads(wire)
                check_envelope(value)
                if isinstance(value, dict) and value.get("error"):
                    raise ValueError("Provider error in JSON response")
                if isinstance(value,dict):
                    usage={k:v for k,v in value.items() if k in {"billable_characters_count","billable_characters","usage"} and isinstance(v,(int,float,dict))}
                    if usage: result["provider_usage"].append(usage)
                encoded = dotted(value, spec.audio_path)
                if spec.response_mode == "json_url":
                    parsed = safe_url(encoded)
                    if parsed.hostname not in spec.metadata.get("download_hosts", []):
                        raise ValueError("Returned audio URL host is not explicitly allowed")
                    # New unauthenticated client; never forward vendor credentials to storage.
                    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, trust_env=False) as download:
                        async with download.stream("GET", encoded) as downloaded:
                            downloaded.raise_for_status()
                            async for chunk in downloaded.aiter_bytes():
                                append_audio(chunk)
                else:
                    append_audio(decode_audio(encoded, spec.response_mode))
        if not audio:
            raise ValueError("Successful HTTP response contained no audio")
        if spec.response_mode=="binary" and bytes(audio[:32]).lstrip().startswith((b'{"error"',b'<html',b'<!DOCTYPE')):
            raise ValueError("Non-audio error payload")
        if spec.encoding in {"pcm_s16le","pcm16","pcm","linear16"} and not audio.startswith(b"RIFF") and len(audio)%(2*spec.channels):
            raise ValueError("Truncated PCM audio frame")

    async def timed(http):
        task = asyncio.create_task(perform(http))
        try:
            await asyncio.wait_for(task, timeout=min(timeout, cancel_after) if cancel_after is not None else timeout)
        except asyncio.TimeoutError:
            if cancel_after is not None and cancel_after < timeout:
                event("client_cancel")
                result["status"] = "cancelled"
                return
            raise

    try:
        if client is None:
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, trust_env=False) as http:
                await timed(http)
        else:
            await timed(client)
        if result["status"] == "pending":
            result["status"] = "success"
    except Exception as exc:
        result["status"] = "error"
        # Exception strings can contain credential-bearing URLs. Do not persist them.
        result["error_type"] = type(exc).__name__
        event("request_error", error_type=type(exc).__name__)
    result.update(elapsed_ms=(time.perf_counter_ns()-origin)/1e6, audio_bytes=len(audio), wire_bytes=len(wire),
                  audio_sha256=hashlib.sha256(audio).hexdigest(), events=events,
                  duration_seconds=None, realtime_factor=None)
    return result, bytes(audio)
