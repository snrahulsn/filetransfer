"""Validate a capped repeated first-playable-PCM observation before publication."""
import hashlib
import json
import math
from pathlib import Path
import random

from .metrics import percentile


def interval(values, quantile, seed):
    if len(values)<5:raise ValueError('At least five complete trials required')
    rng=random.Random(seed)
    draws=[percentile(rng.choices(values,k=len(values)),quantile) for _ in range(5000)]
    return {'estimate_ms':round(percentile(values,quantile),2),
            'bootstrap_95_percent_interval_ms':[round(percentile(draws,.025),2),round(percentile(draws,.975),2)],
            'method':'nonparametric trial resampling; 5000 draws; percentile interval','seed':seed}


def verify(root,manifest=None,read_result=None,read_audio=None):
    root=Path(root).resolve()
    if manifest is None:manifest=json.loads((root/'manifest.json').read_text())
    balanced=manifest.get('schema')=='balanced_hindi_first_playable_pcm_v2'
    if manifest.get('schema') not in {'matched_hindi_first_playable_pcm_v1','balanced_hindi_first_playable_pcm_v2'} or manifest.get('status')!='complete':
        raise ValueError('Trial did not complete under the expected schema')
    repetitions=12 if balanced else 8
    budget=24 if balanced else 16
    if manifest.get('max_vendor_requests' if balanced else 'max_requests')!=budget or manifest.get('automatic_retries')!=0 or manifest.get('repetitions_per_provider')!=repetitions:
        raise ValueError('Unexpected request budget or retry policy')
    providers=manifest.get('providers')
    if not isinstance(providers,dict) or set(providers)!={'cartesia','elevenlabs'}:
        raise ValueError('Unexpected provider set')
    if manifest.get('attempts_total')!=budget or len(manifest.get('results',[]))!=budget:
        raise ValueError('Incomplete or extra request inventory')
    condition=('binary provider-native mono PCM16 at 24 kHz; no resampling' if balanced else
               'provider-native output PCM16 24 kHz, raw or decoded from binary PCM; no resampling')
    if manifest.get('audio_condition')!=condition:
        raise ValueError('Audio condition changed')
    if balanced:
        orders=manifest.get('provider_orders')
        expected=[['cartesia','elevenlabs'] if i%2==0 else ['elevenlabs','cartesia'] for i in range(repetitions)]
        if orders!=expected or manifest.get('client_egress_country_start')!='IN' or manifest.get('client_egress_country_end')!='IN':
            raise ValueError('Balanced provider order or India egress not established')
        if manifest.get('country_probe')!='Cloudflare trace loc, HTTP GET with trust_env=False before and after vendor requests':
            raise ValueError('Egress probe scope changed')
    text=manifest.get('transcript')
    if not isinstance(text,str) or hashlib.sha256(text.encode()).hexdigest()!=manifest.get('text_sha256'):
        raise ValueError('Transcript hash mismatch')
    by_provider={p:[] for p in providers};contracts={};seen=set()
    for index,row in enumerate(manifest['results']):
        provider=manifest['provider_orders'][index//2][index%2] if balanced else manifest['provider_order'][index%2]
        ordinal=index//2+1
        if row.get('provider')!=provider or row.get('ordinal')!=ordinal or (provider,ordinal) in seen:
            raise ValueError('Unexpected provider order or repeated ordinal')
        if balanced and row.get('order_position')!=index%2+1:
            raise ValueError('Balanced order position mismatch')
        seen.add((provider,ordinal))
        if row.get('text_sha256')!=manifest['text_sha256'] or row.get('config')!=providers[provider].get('config'):
            raise ValueError('Model, voice, locale or text changed')
        source=Path(row.get('source_result',''))
        if not source.is_absolute():source=(root.parent.parent/source).resolve()
        if not source.is_relative_to(root/'runs') or not source.exists():
            raise ValueError('Unsafe or missing saved result')
        result=(read_result or (lambda p:json.loads(p.read_text())))(source)
        if any(result.get(k)!=row.get(k) for k in ('run_id','status','http_status','error_type','first_byte_ms','first_payload_ms','first_audio_ms','elapsed_ms','audio_sha256','audio_bytes','duration_seconds')):
            raise ValueError('Manifest/result metric mismatch')
        if result.get('provider')!=provider or result.get('config')!=row['config'] or result.get('text')!=text or result.get('code_sha256')!=manifest.get('source_code_sha256'):
            raise ValueError('Saved run identity mismatch')
        if result.get('status')!='success' or result.get('http_status')!=200 or result.get('audio_bytes',0)<=0:
            raise ValueError('Provider did not return playable audio')
        timing=[result.get(k) for k in ('first_byte_ms','first_payload_ms','first_audio_ms','elapsed_ms')]
        if any(type(x) not in (int,float) or not math.isfinite(x) or x<=0 for x in timing) or timing!=sorted(timing):
            raise ValueError('First playable audio timing invalid')
        audio_path=source.parent/result.get('audio_file','')
        if audio_path.resolve().parent!=source.parent or not audio_path.exists():
            raise ValueError('Unsafe or missing audio path')
        blob=(read_audio or (lambda p:p.read_bytes()))(audio_path)
        if len(blob)!=result['audio_bytes'] or hashlib.sha256(blob).hexdigest()!=result['audio_sha256']:
            raise ValueError('Audio byte count or hash mismatch')
        analysis=result.get('audio_analysis',{})
        if analysis.get('analysis_status')!='measured_pcm' or analysis.get('sample_rate')!=24000 or analysis.get('channels')!=1 or not result.get('duration_seconds',0)>0:
            raise ValueError('24 kHz PCM audio not verified')
        contract=result.get('request_contract',{})
        expected={'method':'POST','response_mode':'binary','encoding':'pcm_s16le','sample_rate':24000}
        if any(contract.get(k)!=v for k,v in expected.items()) or contract.get('url_host') not in {'api.cartesia.ai','api.elevenlabs.io'} or not contract.get('body_sha256'):
            raise ValueError('Request contract changed')
        if contract.get('url_host')!=('api.cartesia.ai' if provider=='cartesia' else 'api.elevenlabs.io'):
            raise ValueError('Request sent to wrong host')
        if provider in contracts and contract!=contracts[provider]:raise ValueError('Within-provider request was not pinned')
        contracts[provider]=contract
        by_provider[provider].append(result['first_audio_ms'])
    if any(providers[p].get('attempts')!=repetitions or providers[p].get('successes')!=repetitions or providers[p].get('stopped') for p in providers):
        raise ValueError('Provider totals inconsistent')
    groups={p:{'model':providers[p]['config']['model'],'voice':providers[p]['config']['voice'],
               'language':'hi-IN','sample_rate':24000,'encoding':'pcm_s16le','trials':repetitions,
               'values_ms':[round(v,2) for v in values],
               'p50':interval(values,.5,1729+i),'p95':interval(values,.95,2729+i)}
            for i,(p,values) in enumerate(by_provider.items())}
    limitations=(['Client egress country was India before and after; vendor serving regions were their deployed routes and not user-pinned.',
                  'Only these model/voice routes and one prompt are compared; twelve requests per route leave p95 uncertainty.',
                  'HTTP first-playable PCM is not telephone audible-start, sustained load or a capacity test.'] if balanced else
                 ['Vendor serving regions and client egress location were not independently logged.',
                  'Order was always Cartesia then ElevenLabs; time/order effects cannot be separated.',
                  'Models and voices differ; eight requests per route give broad p95 uncertainty.',
                  'HTTP first-playable PCM is not first audible telephone audio or a load/capacity test.'])
    return {'status':'observed_balanced_hindi_first_playable_pcm' if balanced else 'observed_repeated_first_playable_pcm',
            'source_manifest':str((root/'manifest.json').relative_to(root.parent.parent)),
            'source_code_sha256':manifest['source_code_sha256'],'client_policy':manifest['client_policy'],
            'audio_condition':manifest['audio_condition'],
            'server_region':manifest['provider_serving_region'] if balanced else manifest['server_region'],
            'client_egress_country':manifest['client_egress_country_start'] if balanced else None,
            'matched_route_comparison_qualified':balanced,'cross_vendor_ranking_qualified':False,
            'limitations':limitations,'groups':groups,'successful_requests':budget,'automatic_retries':0}
