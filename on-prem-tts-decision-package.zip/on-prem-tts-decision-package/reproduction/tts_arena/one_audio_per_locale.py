"""Refuse repeat synthesis after any saved playable vendor-locale output."""
import json
from pathlib import Path

from .live_evidence import load_live_runs


def assert_missing_audio(root: Path, provider: str, locale: str) -> None:
    root = Path(root).resolve()
    if not provider or not locale:
        raise ValueError('Provider and requested locale must be explicit')
    snapshot = json.loads((root / 'ui/public/evidence/snapshot.json').read_text())
    for group in ('runs', 'local_runs', 'native_audio_runs', 'maya_local_runs', 'studio_audio_runs'):
        for row in snapshot[group]:
            vendor = 'maya' if group == 'maya_local_runs' else row['provider']
            if vendor == provider and row['language'] == locale and row.get('audio_url'):
                raise ValueError(f'Already published playable audio for {provider}/{locale}')
    runs, issues = load_live_runs(root / 'artifacts')
    if issues:
        raise ValueError('Live inventory has unresolved integrity issues')
    for run in runs:
        if run['provider'] == provider and run['language'] == locale and run.get('status') == 'success' and run.get('audio_file'):
            raise ValueError(f'Already saved synthesis output for {provider}/{locale}')
