"""Verify scoped Urdu voice discovery and two saved Neuphonic SSE PCM runs."""
import hashlib
import json
import math
from pathlib import Path

from .registry import build_request, digest


def verify(root):
    root = Path(root).resolve()
    if root.name != 'neuphonic-urdu-20260916':
        raise ValueError('Unexpected Neuphonic Urdu evidence root')
    project = root.parents[1]
    manifest = json.loads((root / 'manifest.json').read_text())
    selected = manifest.get('selected')
    if (manifest.get('schema') != 'neuphonic_urdu_standard_voice_pair_v1'
        or manifest.get('status') != 'complete' or manifest.get('provider') != 'neuphonic'
        or manifest.get('requested_locale') != 'ur-IN'
        or manifest.get('documented_lang_code') != 'ur'
        or manifest.get('voice_list_url') != 'https://api.neuphonic.com/voices'
        or manifest.get('voice_list_http_status') != 200
        or manifest.get('voice_count') != 108
        or manifest.get('max_synthesis_requests') != 2 or manifest.get('automatic_retries') != 0
        or manifest.get('attempts') != 2 or len(manifest.get('results', [])) != 2
        or not isinstance(selected, list) or len(selected) != 2
        or [v.get('default') for v in selected] != [True, False]
        or any(v.get('lang_code') != 'ur' or v.get('type') != 'Standard'
               or not isinstance(v.get('voice_id'), str) for v in selected)
        or len({v['voice_id'] for v in selected}) != 2):
        raise ValueError('Neuphonic Urdu voice discovery scope changed')
    for digest_field in ('voice_list_sha256', 'text_sha256', 'source_code_sha256'):
        value = manifest.get(digest_field)
        if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('Neuphonic discovery digest missing')
    text = manifest.get('text')
    if not isinstance(text, str) or hashlib.sha256(text.encode()).hexdigest() != manifest['text_sha256']:
        raise ValueError('Neuphonic Urdu prompt digest mismatch')
    summary = []
    for ordinal, (voice, row) in enumerate(zip(selected, manifest['results']), 1):
        relative = row.get('source_result')
        if not isinstance(relative, str) or relative.startswith('/') or '..' in Path(relative).parts:
            raise ValueError('Unsafe Neuphonic run result path')
        result_path = (project / relative).resolve()
        if not result_path.is_relative_to(root / 'runs') or not result_path.is_file():
            raise ValueError('Neuphonic run result escaped evidence root')
        result = json.loads(result_path.read_text())
        cfg = {'voice': voice['voice_id'], 'language': 'ur',
               'format': 'pcm_linear', 'sample_rate': 24000}
        if (row.get('ordinal') != ordinal or row.get('voice_id') != voice['voice_id']
            or row.get('default') != voice['default']
            or any(result.get(k) != row.get(k) for k in ('run_id', 'status', 'http_status',
                   'error_type', 'audio_bytes', 'audio_sha256', 'first_audio_ms', 'duration_seconds'))
            or result.get('provider') != 'neuphonic' or result.get('language') != 'ur-IN'
            or result.get('stratum') != 'neuphonic_urdu_voice_pair'
            or result.get('scenario_id') != f'urdu-standard-{ordinal}'
            or result.get('config') != cfg or result.get('text') != text
            or result.get('code_sha256') != manifest['source_code_sha256']
            or result.get('status') != 'success' or result.get('http_status') != 200
            or result.get('error_type') is not None):
            raise ValueError('Neuphonic run identity or HTTP outcome differs')
        spec = build_request('neuphonic', text, cfg, {'NEUPHONIC_API_KEY': 'placeholder'})
        contract = result.get('request_contract', {})
        if any(contract.get(k) != v for k, v in {
            'method': spec.method, 'url_host': 'api.neuphonic.com',
            'response_mode': spec.response_mode, 'encoding': spec.encoding,
            'sample_rate': spec.sample_rate, 'headers': sorted(spec.headers),
            'body_sha256': digest(spec.body)}.items()):
            raise ValueError('Neuphonic saved SSE contract differs from current adapter')
        analysis = result.get('audio_analysis', {})
        if (analysis.get('analysis_status') != 'measured_pcm'
            or analysis.get('sample_rate') != 24000 or analysis.get('channels') != 1):
            raise ValueError('Neuphonic run has no measured 24 kHz mono PCM')
        audio_file = (result_path.parent / result.get('audio_file', '')).resolve()
        if audio_file.parent != result_path.parent or not audio_file.is_file():
            raise ValueError('Neuphonic PCM file outside saved run')
        pcm = audio_file.read_bytes()
        if (len(pcm) != result['audio_bytes'] or len(pcm) < 2 or len(pcm) % 2
            or hashlib.sha256(pcm).hexdigest() != result['audio_sha256']
            or not math.isclose(len(pcm) / 48000, result['duration_seconds'], abs_tol=.001)):
            raise ValueError('Neuphonic PCM size, duration or hash mismatch')
        first = result.get('first_audio_ms')
        if type(first) not in (int, float) or not math.isfinite(first) or first <= 0:
            raise ValueError('Neuphonic first PCM timing invalid')
        summary.append({'voice_id': voice['voice_id'], 'default': voice['default'],
                        'run_id': result['run_id'], 'audio_sha256': result['audio_sha256'],
                        'audio_bytes': len(pcm), 'duration_seconds': result['duration_seconds'],
                        'first_audio_ms': first})
    return {'schema': 'neuphonic_urdu_voice_pair_audit_v1', 'provider': 'neuphonic',
            'requested_locale': 'ur-IN', 'lang_code': 'ur', 'status': 'observed',
            'voice_list_http_status': 200, 'voice_count': 108,
            'compatible_urdu_standard_voices': 2, 'synthesis_requests': 2,
            'successful_http_200_pcm': 2, 'source_manifest': str((root / 'manifest.json').relative_to(project)),
            'source_code_sha256': manifest['source_code_sha256'],
            'results': summary, 'native_quality': 'unreviewed',
            'backend_model_identity': 'not_disclosed_by_voice_listing',
            'boundary': manifest['boundary']}
