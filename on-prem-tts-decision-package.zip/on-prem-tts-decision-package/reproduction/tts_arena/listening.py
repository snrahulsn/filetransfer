"""Static, offline exploratory listening UI; ratings are supplied only by a listener."""
import json
from pathlib import Path


def write_listening_page(public_directory, strata, matched_text=False, sample_strata=None):
    directory=Path(public_directory)
    items=json.loads((directory/'items.json').read_text())
    allowed={'item_id','audio_file','language','text'}
    if any(set(item)!=allowed for item in items): raise ValueError('Unexpected public item fields')
    for item in items:
        if Path(item['audio_file']).name!=item['audio_file'] or not (directory/item['audio_file']).is_file():
            raise ValueError('Missing or unsafe public audio path')
        item['model_group']=strata[item['item_id']]
        if not item['model_group'].startswith('System '): raise ValueError('Anonymous model group required')
        if sample_strata is not None: item['sample_stratum']=sample_strata[item['item_id']]
    (directory/'items.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    data=json.dumps(items,ensure_ascii=False).replace('<','\\u003c')
    page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; media-src 'self' blob:; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>Exploratory blind listening</title><style>
body{font:16px system-ui;margin:32px auto;max-width:1050px;padding:0 24px;color:#17202a;background:#f6f7f9}h1{font-size:30px}p{line-height:1.55}.note{background:#fff4d7;padding:18px;border-left:4px solid #ad7600}article{background:white;border:1px solid #d5dce4;border-radius:8px;padding:20px;margin:18px 0}label{display:block;margin:12px 0 5px}input,select,textarea,button{font:inherit;padding:9px;border:1px solid #a7b0ba;border-radius:4px}textarea{display:block;width:95%;min-height:56px}button{background:#143e67;color:#fff;cursor:pointer}button:disabled{opacity:.5}audio{width:100%;margin-top:10px}.controls{display:flex;gap:24px;align-items:end;flex-wrap:wrap}.muted{color:#505b68}.reference{font-size:19px}.optional{border-top:1px solid #e0e5ea;padding-top:10px}
</style><h1>Exploratory blind listening</h1>
<p class="note"><strong>Unmatched samples — not a fair provider ranking.</strong> Texts, voices, settings and recording conditions differ. These samples can help identify promising voices and audible issues. They cannot establish comparative MOS or certify language quality. System letters hide model identities; samples in the same group used the same named model, with potentially different voices.</p>
<p>Listen only in languages you understand well. Reference text is a draft and has not received native review. Self-reported language knowledge does not replace the separate verified listener roster required by the scoring system.</p>
<div class="controls"><div><label for="rater">Anonymous listener ID</label><input id="rater" placeholder="e.g. listener-001" autocomplete="off"></div><div><label for="language">Language</label><select id="language"><option value="">All languages</option></select></div><div><button id="download" disabled>Download ratings JSON</button></div></div>
<p id="progress" aria-live="polite">No ratings entered.</p><p class="muted">No uploads or external services. Ratings stay in this page until you download them. Reloading clears unsaved ratings. The download contains only rated items, without provider identities. Only naturalness is supported by the existing numerical scorer; optional observations are retained for manual review.</p><main id="samples"></main>
<script id="sample-data" type="application/json">DATA</script><script>
const items=JSON.parse(document.getElementById('sample-data').textContent), rows=new Map();
const language=document.getElementById('language'), rater=document.getElementById('rater'), button=document.getElementById('download');
for(const lang of [...new Set(items.map(x=>x.language))].sort()){const o=document.createElement('option');o.value=lang;o.textContent=lang;language.append(o)}
function element(tag,text){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e}
function progress(){const n=[...rows.values()].filter(r=>r.naturalness!==null).length;document.getElementById('progress').textContent=`${n} of ${items.length} samples rated. Blank ratings are excluded.`;button.disabled=!n||!rater.value.trim()}
for(const item of items){
 const card=element('article');card.dataset.language=item.language;card.append(element('h2',`${item.model_group} · ${item.language}${item.sample_stratum?' · '+item.sample_stratum:''}`));
 const ref=element('p',item.text);ref.className='reference';card.append(ref);
 const audio=element('audio');audio.controls=true;audio.preload='none';audio.src=item.audio_file;card.append(audio);
 const row={item_id:item.item_id,naturalness:null,observations:{phonetic_or_content_notes:'',perceived_rate:'',emotion_notes:''}};rows.set(item.item_id,row);
 const rateLabel=element('label','Naturalness — how human-like did the speech sound?');const select=element('select');select.setAttribute('aria-label','Naturalness '+item.item_id);
 for(const [value,label] of [['','Not rated'],['1','1 — Very unnatural'],['2','2 — Unnatural'],['3','3 — Neither natural nor unnatural'],['4','4 — Natural'],['5','5 — Very natural']]){const o=element('option',label);o.value=value;select.append(o)}
 select.addEventListener('change',()=>{row.naturalness=select.value?Number(select.value):null;progress()});rateLabel.append(select);card.append(rateLabel);
 const details=element('details');details.className='optional';details.append(element('summary','Optional observations — manual review only'));
 for(const [key,label] of [['phonetic_or_content_notes','Pronunciation, missing words or other content errors'],['emotion_notes','Emotion heard; appropriateness for the reference text']]){const l=element('label',label);const t=element('textarea');t.maxLength=2000;t.setAttribute('aria-label',label);t.addEventListener('input',()=>row.observations[key]=t.value);l.append(t);details.append(l)}
 const speedLabel=element('label','Perceived speaking rate');const speed=element('select');for(const [v,t] of [['','No observation'],['too_slow','Too slow'],['comfortable','Comfortable'],['too_fast','Too fast']]){const o=element('option',t);o.value=v;speed.append(o)}speed.addEventListener('change',()=>row.observations.perceived_rate=speed.value);speedLabel.append(speed);details.append(speedLabel);card.append(details);
 card.append(element('p','Anonymous item '+item.item_id));document.getElementById('samples').append(card)
}
language.addEventListener('change',()=>document.querySelectorAll('article').forEach(c=>c.hidden=Boolean(language.value&&c.dataset.language!==language.value)));
rater.addEventListener('input',progress);
button.addEventListener('click',()=>{const id=rater.value.trim();if(!id)return;const ratings=[...rows.values()].filter(r=>r.naturalness!==null).map(r=>({rater_id:id,...r,study_scope:'exploratory_unmatched',observations_scoring:'manual_review_only'}));const url=URL.createObjectURL(new Blob([JSON.stringify(ratings,null,2)+'\\n'],{type:'application/json'}));const a=element('a');a.href=url;a.download='exploratory-ratings.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});
</script></html>'''.replace('DATA</script>',data+'</script>')
    if matched_text:
        page=page.replace('Unmatched samples — not a fair provider ranking.','Matched text — exploratory listening, not a certified ranking.')
        page=page.replace('Texts, voices, settings and recording conditions differ.','Reference text is held fixed within each sample stratum. Voices, instruction prompts, native audio formats, sample rates and recording conditions can still differ. Audio has not been loudness-normalized or resampled.')
        page=page.replace("study_scope:'exploratory_unmatched'","study_scope:'exploratory_matched_text'")
    (directory/'index.html').write_text(page)
    return {'items':len(items),'anonymous_model_groups':len(set(strata.values())),'ratings_created':0}
