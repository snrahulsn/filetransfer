"""Verify Fish timestamp WebSocket evidence against saved binary wire frames."""
import base64
import hashlib
import json
from pathlib import Path

import msgpack

from tts_arena.sessions.fish import decode_message


def verify(root):
    root = Path(root).resolve()
    project = root.parents[1]
    summary = json.loads((root / 'summary.json').read_text())
    relative = summary['raw_session_result']
    if not isinstance(relative, str) or relative.startswith('/') or '..' in Path(relative).parts:
        raise ValueError('Fish session result path is not project-relative')
    result_path = (project / relative).resolve()
    if not result_path.is_relative_to(root / 'session'):
        raise ValueError('Fish session result escaped evidence directory')
    result = json.loads(result_path.read_text())
    if (summary['provider'] != 'fish' or summary['model'] != 's2.1-pro-free'
        or summary['requested_locale'] != 'hi-IN' or summary['request_limit'] != 1
        or summary['automatic_retries'] != 0 or summary['status'] != 'observed'
        or result['status'] != 'observed' or result['error_type'] is not None
        or result['config'].get('timestamp_mode') is not True
        or result['config']['model'] != 's2.1-pro-free'
        or result['sample_rate'] != 24000 or result['encoding'] != 'pcm_s16le'
        or not summary['terminal_observed'] or len(result['audio']) != 1):
        raise ValueError('Fish timestamp session scope mismatch')
    if summary['actions'] != result['actions'] or len(result['actions']) != 5:
        raise ValueError('Fish timestamp actions mismatch')
    frames = result_path.parent / 'frames.partial.jsonl'
    if not frames.is_file():
        raise ValueError('Missing Fish wire-frame capture')
    audio = bytearray()
    latest = {}
    marks = 0
    terminal = False
    previous_seq = previous_offset = -1
    for line in frames.read_text().splitlines():
        record = json.loads(line)
        if record.get('type') != 'binary':
            raise ValueError('Fish server sent an unexpected text frame')
        raw = base64.b64decode(record['base64'], validate=True)
        decoded = decode_message(raw)
        packet = msgpack.unpackb(raw, raw=False, strict_map_key=True)
        if terminal:
            raise ValueError('Fish frame arrived after terminal event')
        if packet['event'] == 'audio':
            audio.extend(packet['audio'])
            for event in decoded:
                if event['type'] != 'timestamps':
                    continue
                mark = event['metadata']
                seq, offset = mark['chunk_seq'], mark['chunk_audio_offset_sec']
                if seq < previous_seq or offset < previous_offset:
                    raise ValueError('Fish timing chunk sequence or offset decreased')
                previous_seq, previous_offset = seq, offset
                latest[seq] = mark
                marks += 1
        elif packet['event'] == 'finish':
            if packet.get('reason') != 'stop':
                raise ValueError('Fish terminal reason differs from requested stop')
            terminal = True
    if not terminal or not audio or len(audio) % 2:
        raise ValueError('Fish wire capture has no completed PCM synthesis')
    item = result['audio'][0]
    raw_file = (result_path.parent / item['path']).resolve()
    if not raw_file.is_relative_to(root / 'session') or raw_file.read_bytes() != audio:
        raise ValueError('Fish saved PCM differs from wire audio')
    sha = hashlib.sha256(audio).hexdigest()
    if sha != item['sha256'] or len(audio) != item['bytes'] or len(audio) != summary['audio_bytes']:
        raise ValueError('Fish PCM length or digest mismatch')
    global_segments = []
    for seq, mark in sorted(latest.items()):
        for word in mark['alignment']['segments']:
            global_segments.append({'chunk_seq': seq, 'text': word['text'],
                'start_sec': round(mark['chunk_audio_offset_sec'] + word['start'], 4),
                'end_sec': round(mark['chunk_audio_offset_sec'] + word['end'], 4)})
    reported = summary['timing']
    if (marks != reported['timestamp_frames'] or len(latest) != reported['text_chunks_with_alignment']
        or len(global_segments) != reported['word_segments_in_latest_snapshots']
        or global_segments != reported['global_segments'] or not global_segments):
        raise ValueError('Fish timing summary differs from saved wire snapshots')
    duration = len(audio) / (24000 * 2)
    if max(word['end_sec'] for word in global_segments) > duration + 0.1:
        raise ValueError('Fish timing exceeds decoded PCM duration')
    events = result['events']
    if summary['audio_payload_events'] != sum(e['event_type'] == 'audio_payload_received' for e in events):
        raise ValueError('Fish client audio event count mismatch')
    texts = [e for e in events if e['event_type'] == 'action_sent' and e.get('action_type') == 'text']
    payloads = [e for e in events if e['event_type'] == 'audio_payload_received']
    if len(texts) != 2 or not payloads:
        raise ValueError('Fish staged text/audio events missing')
    return {'provider': 'fish', 'model': 's2.1-pro-free', 'requested_locale': 'hi-IN',
            'status': 'observed', 'audio_bytes': len(audio), 'audio_sha256': sha,
            'pcm_duration_seconds': duration, 'timestamp_frames': marks,
            'text_chunks_with_alignment': len(latest), 'word_segments': len(global_segments),
            'first_audio_before_second_text': payloads[0]['elapsed_ms'] < texts[1]['elapsed_ms'],
            'terminal_observed': terminal, 'alignment_accuracy': 'unverified',
            'raw_audio_file': raw_file}
