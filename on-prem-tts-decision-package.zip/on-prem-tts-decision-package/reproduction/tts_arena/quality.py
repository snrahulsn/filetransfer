"""Blind listener-study packaging and validated rating ingestion; no fabricated MOS."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import random
import shutil

from .metrics import bootstrap_mean


def prepare_study(items, destination, seed=1729):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    public, private = [], {}
    rng = random.Random(seed)
    ids = set()
    for item in items:
        if item["id"] in ids:
            raise ValueError("Duplicate item")
        ids.add(item["id"])
        original = Path(item["audio_file"])
        token = hashlib.sha256(f"{seed}:{item['id']}".encode()).hexdigest()[:20]
        target = token + original.suffix
        shutil.copyfile(original, destination / target)
        public.append({"item_id": token, "audio_file": target, "language": item["language"], "text": item["text"]})
        private[token] = item
    rng.shuffle(public)
    (destination / "items.json").write_text(json.dumps(public, ensure_ascii=False, indent=2))
    # Keep the answer/provider key outside the public listening directory.
    (destination.parent / (destination.name + "-private-key.json")).write_text(json.dumps(private, ensure_ascii=False, indent=2))
    return {"items": len(public), "seed": seed, "status": "awaiting_qualified_native_ratings"}


def score_ratings(ratings, roster, item_map):
    if not isinstance(ratings,list) or not isinstance(roster,dict) or not isinstance(item_map,dict):
        raise ValueError("Ratings must be a list; roster and item key must be mappings")
    seen, accepted, rejected = set(), [], []
    for row in ratings:
        if not isinstance(row,dict) or any(not isinstance(row.get(k),str) or not row[k].strip() for k in ("rater_id","item_id")):
            raise ValueError("Nonempty rater/item IDs required")
        pair = (row["rater_id"], row["item_id"])
        if pair in seen:
            raise ValueError("Duplicate rater/item; repeated sessions must be modelled explicitly")
        seen.add(pair)
        if row["item_id"] not in item_map:
            raise ValueError("Unknown listening item")
        item = item_map[row["item_id"]]
        if not isinstance(item,dict) or any(not isinstance(item.get(k),str) or not item[k].strip() for k in ("provider","language")) or ("model" in item and (not isinstance(item["model"],str) or not item["model"].strip())):
            raise ValueError("Invalid private model/language identity")
        person = roster.get(row["rater_id"], {})
        languages=person.get("verified_native_languages") if isinstance(person,dict) else None
        qualified=(isinstance(person,dict) and person.get("screening_passed") is True
                   and isinstance(languages,list) and all(isinstance(v,str) for v in languages)
                   and item["language"] in languages)
        if not qualified:
            rejected.append({"rater_id": row["rater_id"], "item_id": row["item_id"], "reason": "not_qualified_for_language"})
            continue
        score = row["naturalness"]
        if isinstance(score, bool) or not isinstance(score, (int,float)) or not 1 <= score <= 5:
            raise ValueError("Naturalness must be a 1–5 score")
        accepted.append({**row, "provider": item["provider"], "model":item.get("model","unspecified"), "language": item["language"]})
    groups = defaultdict(lambda: defaultdict(list))
    for row in accepted:
        groups[(row["provider"],row["model"],row["language"])][row["rater_id"]].append(row["naturalness"])
    result = []
    for (p,m,l),listeners in sorted(groups.items()):
        means = [sum(v)/len(v) for v in listeners.values()]
        result.append({"provider":p,"model":m,"language":l,"listener_mean_naturalness":bootstrap_mean(means),
                       "rating_count":sum(map(len,listeners.values())),"interval_unit":"listener",
                       "limitation":"Does not account for crossed item effects; no vendor certification from this aggregate alone"})
    return {"groups":result,"rejected":rejected,"accepted_count":len(accepted)}
