"""Independent Sarvam close/reconnect software receiver and PCM evidence audit."""
import hashlib
import io
import json
import wave
from pathlib import Path

from .audio import samples_from_pcm


def wav_from_pcm(raw):
    if not raw or len(raw) % 2:
        raise ValueError('Nonempty 24 kHz PCM16 required')
    out=io.BytesIO()
    with wave.open(out,'wb') as media:
        media.setnchannels(1)
        media.setsampwidth(2)
        media.setframerate(24000)
        media.writeframes(raw)
    return out.getvalue()


def verify(folder):
    root=Path(folder)
    bridge=json.loads((root/'sarvam-bridge.json').read_text())
    receiver=json.loads((root/'result.json').read_text())
    plan=json.loads((root/'plan.json').read_text())
    if (bridge['schema'],bridge['provider'],bridge['model'],bridge['voice'],
        bridge['sample_rate'],bridge['status'],receiver['status'],receiver['sample_rate']) != (
        'sarvam_software_playout_v1','sarvam','bulbul:v3','shubh',24000,
        'observed','observed',24000):
        raise ValueError('Sarvam playout model, sample rate or observed status differs')
    if (bridge['production_telephony_verified'] is not False or
        bridge['in_band_cancel_supported'] is not False or
        not all(bridge[key] for key in ('local_playout_cleared',
            'old_vendor_socket_closed','recovery_socket_connected','recovery_final')) or
        bridge['old_final_before_clear'] or bridge['error_type']):
        raise ValueError('Sarvam close/reconnect qualification gate failed')
    caller=root.parent/'calibration/soniox-caller-tone-24000.wav'
    if hashlib.sha256(caller.read_bytes()).hexdigest()!=plan['caller_sha256']:
        raise ValueError('Sarvam synthetic caller fixture changed')
    raw={}
    for label in ('old_before_close','old_after_clear_discarded','recovery'):
        manifest=bridge['artifacts'].get(label)
        if manifest is None and label=='old_after_clear_discarded':
            raw[label]=b''
            continue
        if manifest is None:
            raise ValueError('Sarvam required source media absent')
        payload=(root/manifest['file']).read_bytes()
        if not payload or len(payload)!=manifest['bytes'] or hashlib.sha256(payload).hexdigest()!=manifest['sha256']:
            raise ValueError('Sarvam saved media differs from manifest')
        raw[label]=payload
    for name in ('bot.wav','caller.wav'):
        with wave.open(str(root/name),'rb') as media:
            if (media.getnchannels(),media.getsampwidth(),media.getframerate())!=(1,2,24000) or media.getnframes()==0:
                raise ValueError('Sarvam receiver timeline media invalid')
    events=bridge['events'];kinds=[e['event_type'] for e in events]
    required=('old_socket_connected','old_text_flush_sent','local_playout_cleared',
        'old_vendor_socket_closed',
        'recovery_socket_connected','recovery_text_flush_sent','vendor_final')
    if not all(x in kinds for x in required) or not (
        kinds.index('old_socket_connected')<kinds.index('old_text_flush_sent')<
        kinds.index('local_playout_cleared')<kinds.index('old_vendor_socket_closed')<
        kinds.index('recovery_socket_connected')<kinds.index('recovery_text_flush_sent')):
        raise ValueError('Sarvam local clear, close and reconnect order invalid')
    clear_index=kinds.index('local_playout_cleared')
    close_index=kinds.index('old_vendor_socket_closed')
    if any(e['event_type']=='old_mp3_after_clear_discarded' and not
           clear_index<e['sequence']<close_index for e in events):
        raise ValueError('Sarvam late old MP3 event outside clear/close window')
    late_bytes=sum(e['byte_count'] for e in events if
        e['event_type']=='old_mp3_after_clear_discarded')
    old_pcm_bytes=sum(e['pcm_bytes'] for e in events if
        e['event_type']=='vendor_mp3_decoded' and e.get('response')=='old')
    recovery_pcm_bytes=sum(e['pcm_bytes'] for e in events if
        e['event_type']=='vendor_mp3_decoded' and e.get('response')=='recovery')
    if (late_bytes!=len(raw['old_after_clear_discarded']) or
        old_pcm_bytes!=len(raw['old_before_close']) or
        recovery_pcm_bytes!=len(raw['recovery'])):
        raise ValueError('Sarvam captured media bytes differ from bridge event totals')
    if any(e['event_type']=='vendor_final' and e.get('response')=='old' and
           e['sequence']<clear_index for e in events) or not any(
        e['event_type']=='vendor_final' and e.get('response')=='recovery' and
        e['sequence']>kinds.index('recovery_text_flush_sent') for e in events):
        raise ValueError('Old/recovery completion boundaries differ')
    if any(e['event_type']=='playout_frame_sent' and e.get('response')=='old'
        for e in events if e['sequence']>clear_index):
        raise ValueError('Old PCM forwarded after local playout clear')
    recv=receiver['events']
    onset=next(e for e in recv if e['event_type']=='caller_onset')
    clear=next(e for e in recv if e['event_type']=='clear_received' and e.get('response_id')=='old')
    old_play=[e for e in recv if e['event_type']=='playout' and e.get('response_id')=='old']
    new_play=[e for e in recv if e['event_type']=='playout' and e.get('response_id')=='recovery']
    if not old_play or not new_play or not (
        old_play[0]['sequence']<onset['sequence']<clear['sequence']<new_play[0]['sequence']) or any(
        e['sequence']>clear['sequence'] for e in old_play):
        raise ValueError('Sarvam receiver has old post-clear playout or missing recovery')
    metrics=receiver['metrics']
    if (not metrics['active_at_onset'] or metrics['right_censored'] or
        metrics['missed_interruption'] or metrics['stop_latency_ms'] is None or
        metrics['stop_latency_ms']>500 or
        metrics['next_response_from_onset_ms'] is None or
        metrics['next_response_from_onset_ms']<=0):
        raise ValueError('Sarvam software interruption metrics fail qualification gate')
    with wave.open(str(root/'bot.wav'),'rb') as media:timeline=media.readframes(media.getnframes())
    audible=[]
    for event in new_play:
        start=event['sample_index'];frame=timeline[start*2:start*2+960]
        if len(frame)==960:
            samples=samples_from_pcm(frame)
            if sum(value*value for value in samples)/len(samples)>=100**2:
                audible.append(start)
    if not audible or abs((min(audible)-onset['sample_index'])/24-
        metrics['next_response_from_onset_ms'])>.05:
        raise ValueError('Sarvam audible recovery time differs from receiver waveform')
    old_wav=wav_from_pcm(raw['old_before_close'])
    new_wav=wav_from_pcm(raw['recovery'])
    return {'schema':'sarvam_playout_audit_v1','provider':'sarvam',
            'model':'bulbul:v3','language':'hi-IN','voice':'shubh',
            'status':'observed','boundary':'synthetic_tone_software_PCM_receiver',
            'production_telephony_verified':False,
            'native_cancel_supported':False,'old_active_at_onset':True,
            'software_stop_latency_ms':metrics['stop_latency_ms'],
            'recovery_from_caller_onset_ms':metrics['next_response_from_onset_ms'],
            'old_mp3_after_clear_discarded_bytes':len(raw['old_after_clear_discarded']),
            'post_clear_old_playout_frames':0,'old_socket_closed_before_final':True,
            'recovery_new_socket_final':True,
            'old_wav_sha256':hashlib.sha256(old_wav).hexdigest(),
            'old_wav_bytes':len(old_wav),
            'recovery_wav_sha256':hashlib.sha256(new_wav).hexdigest(),
            'recovery_wav_bytes':len(new_wav),
            'caller_fixture_sha256':plan['caller_sha256']}
