"""Offline blinded language review form; it creates no ratings or scores."""
import json
from pathlib import Path


def write_page(public_directory, groups, strata, study_id):
    directory = Path(public_directory)
    items = json.loads((directory / 'items.json').read_text())
    if not items or len({row['item_id'] for row in items}) != len(items):
        raise ValueError('Empty or duplicate language-review items')
    if set(groups) != {row['item_id'] for row in items} or set(strata) != set(groups):
        raise ValueError('Private/public item mapping differs')
    for row in items:
        base = {'item_id', 'audio_file', 'language', 'text'}
        if set(row) not in (base, base | {'system', 'sample_stratum'}):
            raise ValueError('Unexpected public item fields')
        if Path(row['audio_file']).name != row['audio_file'] or not (directory / row['audio_file']).is_file():
            raise ValueError('Unsafe or missing reviewer audio')
        group = groups[row['item_id']]
        if not isinstance(group, str) or not group.startswith('System '):
            raise ValueError('Reviewer group must be anonymous')
        if 'system' in row and (row['system'] != group or row['sample_stratum'] != strata[row['item_id']]):
            raise ValueError('Existing anonymous item assignment changed')
        row['system'] = group
        row['sample_stratum'] = strata[row['item_id']]
    (directory / 'items.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n')
    data = json.dumps(items, ensure_ascii=False).replace('<', '\\u003c')
    page = r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; media-src 'self' blob:; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>Indic TTS blinded language review</title><style>
body{font:15px system-ui;color:#172027;background:#f3f5f6;max-width:1150px;margin:0 auto;padding:22px}h1{font-size:24px;margin:0 0 9px}p{line-height:1.45}.bar{display:flex;gap:16px;align-items:end;flex-wrap:wrap;padding:15px;background:#fff;border:1px solid #cbd4d8;margin:18px 0}.bar label{display:grid;gap:5px}input,select,textarea,button{font:inherit;padding:8px;border:1px solid #a7b5bc;border-radius:3px}button{background:#17415c;color:white;cursor:pointer}button:disabled{opacity:.5;cursor:default}.card{background:#fff;border:1px solid #cbd4d8;padding:18px;margin:12px 0}.card h2{font-size:17px;margin:0 0 8px}.reference{font-size:17px;white-space:pre-wrap}.ratings{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.ratings label{display:grid;gap:5px}.card audio{width:100%}.note{color:#45545d}textarea{width:min(100%,820px);min-height:55px;box-sizing:border-box}
</style><h1>Indic TTS blinded language review</h1>
<p class="note">Saved audio only. Vendor and model names are withheld. Prompts, voices and recording settings differ, so these entries do not form a fair cross-vendor ranking. The displayed text is an unreviewed synthesis request, not a verified spoken transcript. Rate only languages you know natively. Qualification and reference correction are checked separately before any score is accepted.</p>
<div class="bar"><label>Reviewer ID<input id="reviewer" autocomplete="off" placeholder="Assigned anonymous ID"></label><label>Language<select id="language"><option value="">All languages</option></select></label><button id="previous" disabled>Previous</button><button id="next">Next</button><span id="page-count" aria-live="polite"></span><button id="download" disabled>Download completed ratings</button><span id="progress" aria-live="polite">0 completed</span></div>
<p class="note">Scores: 1 = severe failure; 5 = excellent. Naturalness means human-like sound; accent means a plausible local accent for the requested language; intelligibility means understandable speech; text fidelity means the words and named entities heard match the displayed draft request. Report uncertain text rather than inferring correctness. Ratings remain in this browser until downloaded; there is no upload.</p>
<main id="items"></main><script id="data" type="application/json">DATA</script><script>
const items=JSON.parse(document.getElementById('data').textContent), rows=new Map(), pageSize=20;
const reviewer=document.getElementById('reviewer'), language=document.getElementById('language'), download=document.getElementById('download'), previous=document.getElementById('previous'), next=document.getElementById('next');let pageIndex=0;
const dimensions=[['naturalness','Human-like naturalness'],['accent','Requested-language local accent'],['intelligibility','Intelligibility'],['text_fidelity','Draft-text fidelity']];
for(const lang of [...new Set(items.map(x=>x.language))].sort()){const option=document.createElement('option');option.value=lang;option.textContent=lang;language.append(option)}
language.value=items.some(item=>item.language==='hi-IN')?'hi-IN':'';
function el(tag,text){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;return node}
function complete(row){return dimensions.every(([name])=>Number.isInteger(row[name])&&row[name]>=1&&row[name]<=5)}
function progress(){const count=[...rows.values()].filter(complete).length;document.getElementById('progress').textContent=`${count} / ${items.length} complete`;download.disabled=!count||!reviewer.value.trim()}
for(const item of items){rows.set(item.item_id,{item_id:item.item_id,naturalness:null,accent:null,intelligibility:null,text_fidelity:null,observations:{entity_or_pronunciation_error:'',code_switch_or_emotion_note:''}})}
function render(){const filtered=items.filter(item=>!language.value||item.language===language.value), totalPages=Math.max(1,Math.ceil(filtered.length/pageSize));pageIndex=Math.min(pageIndex,totalPages-1);const target=document.getElementById('items');target.replaceChildren();
for(const item of filtered.slice(pageIndex*pageSize,(pageIndex+1)*pageSize)){const card=el('article');card.className='card';card.append(el('h2',`${item.system} · ${item.language}`));
const ref=el('p',item.text);ref.className='reference';card.append(ref);const audio=el('audio');audio.controls=true;audio.preload='none';audio.src=item.audio_file;card.append(audio);
const row=rows.get(item.item_id), grid=el('div');grid.className='ratings';for(const [name,label] of dimensions){const holder=el('label',label), select=el('select');select.setAttribute('aria-label',`${label} ${item.item_id}`);for(const [value,title] of [['','Not rated'],['1','1'],['2','2'],['3','3'],['4','4'],['5','5']]){const option=el('option',title);option.value=value;select.append(option)}select.value=row[name]===null?'':String(row[name]);select.addEventListener('change',()=>{row[name]=select.value?Number(select.value):null;progress()});holder.append(select);grid.append(holder)}card.append(grid);
for(const [name,label] of [['entity_or_pronunciation_error','Words, named entities or pronunciation heard incorrectly'],['code_switch_or_emotion_note','Code-switching, emotion or other observation']]){const holder=el('label',label), field=el('textarea');field.maxLength=1200;field.value=row.observations[name];field.setAttribute('aria-label',`${label} ${item.item_id}`);field.addEventListener('input',()=>row.observations[name]=field.value);holder.append(field);card.append(holder)}card.append(el('p',`Anonymous item ${item.item_id}`));target.append(card)}
previous.disabled=pageIndex===0;next.disabled=pageIndex===totalPages-1;document.getElementById('page-count').textContent=`Page ${pageIndex+1} / ${totalPages} · ${filtered.length} recordings`}
language.addEventListener('change',()=>{pageIndex=0;render()});previous.addEventListener('click',()=>{pageIndex--;render()});next.addEventListener('click',()=>{pageIndex++;render()});reviewer.addEventListener('input',progress);
download.addEventListener('click',()=>{const id=reviewer.value.trim();if(!id)return;const ratings=[...rows.values()].filter(complete).map(row=>({reviewer_id:id,...row}));const payload={schema:'indic_language_review_v1',study_id:'STUDY',ratings,qualification:'requires_verified_roster_and_reviewed_reference'};const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)+'\n'],{type:'application/json'}));const link=el('a');link.href=url;link.download='indic-language-ratings.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});render();progress();
</script></html>'''.replace('DATA</script>', data + '</script>').replace("study_id:'STUDY'", 'study_id:' + json.dumps(study_id))
    (directory / 'index.html').write_text(page)
    return {'items': len(items), 'anonymous_system_locale_cells': len({(groups[row['item_id']], row['language']) for row in items}),
            'anonymous_systems': len(set(groups.values())), 'ratings_created': 0}
