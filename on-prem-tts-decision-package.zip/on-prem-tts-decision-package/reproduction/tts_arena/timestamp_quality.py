"""Word timestamp diagnostics against an explicitly audio-bound reference.

Unit-cost Levenshtein alignment uses suffix distances, traversed from the start.
Ties prefer exact match, substitution, deletion, then insertion. Timing never
influences token alignment. Repeated words can therefore be ambiguous; this is
not forced alignment. Tokens undergo NFC only (no splitting or case folding).
"""
import math
import re
import statistics
import unicodedata

MAX_TIME_SECONDS = 604800  # Explicit seven-day measurement range, not a vendor limit.
MAX_ALIGNMENT_CELLS = 1_000_000

IDENTITY = ('run_id', 'provider', 'model', 'language', 'audio_sha256',
            'time_origin', 'time_unit')


def _validate(record, reference=False):
    if not isinstance(record, dict):
        raise ValueError('Timestamp record must be an object')
    for field in IDENTITY:
        value = record.get(field)
        if not isinstance(value, str) or not value.strip() or value != value.strip() or any(ord(c) < 32 for c in value):
            raise ValueError(f'Invalid {field}')
    if not re.fullmatch(r'[0-9a-f]{64}', record['audio_sha256']):
        raise ValueError('audio_sha256 must be lowercase SHA-256')
    if record['time_origin'] != 'synthesis_start' or record['time_unit'] != 'seconds':
        raise ValueError('Explicit synthesis_start origin and seconds unit required')
    if reference and type(record.get('native_reviewed')) is not bool:
        raise ValueError('native_reviewed must be boolean')
    words = record.get('words')
    if not isinstance(words, list) or (reference and not words):
        raise ValueError('words must be a list; reference must not be empty')
    previous_start = previous_end = -1
    normalized = []
    for word in words:
        if not isinstance(word, dict) or not isinstance(word.get('text'), str) or not word['text'].strip():
            raise ValueError('Each word must contain nonblank text')
        for field in ('start', 'end'):
            value = word.get(field)
            try:
                valid = type(value) in (int, float) and math.isfinite(value) and 0 <= value <= MAX_TIME_SECONDS
            except OverflowError:
                valid = False
            if not valid:
                raise ValueError('Word times must be finite numbers in [0, 604800] seconds, not booleans')
        start, end = word['start'], word['end']
        if end < start or start < previous_start or end < previous_end:
            raise ValueError('Word end must follow start; starts and ends must be monotonic')
        previous_start, previous_end = start, end
        normalized.append(unicodedata.normalize('NFC', word['text']))
    return normalized


def _distribution(values):
    # Linear interpolation at (n - 1) * quantile; no population inference.
    ordered = sorted(values)
    def percentile(q):
        index = (len(ordered) - 1) * q
        low, high = math.floor(index), math.ceil(index)
        return ordered[low] + (ordered[high] - ordered[low]) * (index - low)
    return {'count': len(values), 'values': values,
            'mean': statistics.fmean(values) if values else None,
            'min': ordered[0] if values else None,
            'median': percentile(.5) if values else None,
            'p95': percentile(.95) if values else None,
            'max': ordered[-1] if values else None}


def compare_word_timestamps(reference, observed):
    """Compare supplied word timings; declarations do not authenticate annotations.

    Errors are observed minus reference seconds, only for NFC-exact matches.
    Inter-word overlap is allowed; both starts and ends must be nondecreasing.
    Input hashes bind records to each other, not to independently inspected audio.
    Measurement times are limited to seven days and alignment to 1,000,000
    matrix cells. These are implementation limits, not vendor restrictions.
    """
    expected, actual = _validate(reference, True), _validate(observed)
    if any(reference[k] != observed[k] for k in IDENTITY):
        raise ValueError('Reference/observed identity mismatch')
    n, m = len(expected), len(actual)
    if (n + 1) * (m + 1) > MAX_ALIGNMENT_CELLS:
        raise ValueError('Alignment exceeds implementation limit of 1000000 matrix cells')
    distance = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n, -1, -1):
        for j in range(m, -1, -1):
            if i == n:
                distance[i][j] = m - j
            elif j == m:
                distance[i][j] = n - i
            else:
                distance[i][j] = min(distance[i+1][j+1] + (expected[i] != actual[j]),
                                     1 + distance[i+1][j], 1 + distance[i][j+1])
    operations, counts = [], dict(matched=0, substituted=0, deleted=0, inserted=0)
    onset, ending = [], []
    i = j = 0
    while i < n or j < m:
        if i < n and j < m and expected[i] == actual[j] and distance[i][j] == distance[i+1][j+1]:
            kind = 'matched'
        elif i < n and j < m and distance[i][j] == 1 + distance[i+1][j+1]:
            kind = 'substituted'
        elif i < n and distance[i][j] == 1 + distance[i+1][j]:
            kind = 'deleted'
        else:
            kind = 'inserted'
        ri, oi = (i if kind != 'inserted' else None), (j if kind != 'deleted' else None)
        row = {'operation': kind, 'reference_index': ri, 'observed_index': oi,
               'reference': {k: reference['words'][ri][k] for k in ('text', 'start', 'end')} if ri is not None else None,
               'observed': {k: observed['words'][oi][k] for k in ('text', 'start', 'end')} if oi is not None else None}
        if kind == 'matched':
            start_error = observed['words'][j]['start'] - reference['words'][i]['start']
            end_error = observed['words'][j]['end'] - reference['words'][i]['end']
            row.update(onset_error_seconds=start_error, end_error_seconds=end_error)
            onset.append(start_error)
            ending.append(end_error)
        counts[kind] += 1
        operations.append(row)
        i += kind != 'inserted'
        j += kind != 'deleted'
    return {**{k: reference[k] for k in IDENTITY},
            'status': 'timestamp_diagnostics', 'certification': False,
            'reference_native_reviewed': reference['native_reviewed'],
            'reference_scope': 'declared_native_reviewed' if reference['native_reviewed'] else 'unreviewed_diagnostic',
            'normalization': 'NFC_only',
            'alignment_policy': 'unit_cost_levenshtein_forward_match_substitution_deletion_insertion',
            'percentile_method': 'linear_interpolation_at_(n-1)*q',
            'reference_words': n, 'observed_words': m, 'edit_distance': distance[0][0],
            'counts': counts, 'operations': operations,
            'timing': {name: {'signed_seconds': _distribution(values),
                              'absolute_seconds': _distribution([abs(v) for v in values])}
                       for name, values in (('onset', onset), ('end', ending))},
            'limitations': 'Timing covers NFC-exact matched tokens only. Repeated-token alignment can be ambiguous. '
                           'Native review is a supplied declaration. Audio hashes are not verified against files. '
                           'No native accuracy, alignment certification or quality threshold is claimed.'}
