"""Sample-position recording with explicit gaps, no arrival-time compression."""
import array
import io
import math
import sys
import wave


def samples_from_pcm(data):
    if len(data) % 2:
        raise ValueError("Truncated PCM16 sample")
    samples = array.array("h")
    samples.frombytes(data)
    if sys.byteorder != "little":
        samples.byteswap()
    return samples


def pcm_from_samples(samples):
    values = array.array("h", samples)
    if sys.byteorder != "little":
        values.byteswap()
    return values.tobytes()


class TimelineRecorder:
    def __init__(self, sample_rate, max_seconds=600):
        if sample_rate <= 0 or max_seconds <= 0:
            raise ValueError("Invalid recording bounds")
        self.sample_rate = sample_rate
        self.limit = int(sample_rate * max_seconds)
        self.samples = array.array("h")
        self.intervals = []

    def write_at(self, sample_index, pcm):
        values = samples_from_pcm(pcm)
        end = sample_index + len(values)
        if sample_index < 0 or end > self.limit:
            raise ValueError("Recording outside bounds")
        if any(sample_index < b and end > a for a, b in self.intervals):
            raise ValueError("Overlapping writes would overwrite evidence")
        if end > len(self.samples):
            self.samples.extend([0] * (end - len(self.samples)))
        self.samples[sample_index:end] = values
        self.intervals.append((sample_index, end))

    def wav(self, end_sample=None):
        if end_sample is not None:
            if end_sample < len(self.samples) or end_sample > self.limit:
                raise ValueError("Cannot trim evidence or exceed bounds")
            self.samples.extend([0] * (end_sample - len(self.samples)))
        stream = io.BytesIO()
        with wave.open(stream, "wb") as wav:
            wav.setparams((1, 2, self.sample_rate, 0, "NONE", "not compressed"))
            wav.writeframes(pcm_from_samples(self.samples))
        return stream.getvalue()


def inspect_audio(data, encoding="unknown", sample_rate=None, channels=1):
    if data.startswith(b"RIFF"):
        with wave.open(io.BytesIO(data), "rb") as wav:
            if wav.getsampwidth() != 2 or wav.getcomptype() != "NONE":
                raise ValueError("Only uncompressed PCM16 WAV analysis is implemented")
            channels, sample_rate = wav.getnchannels(), wav.getframerate()
            data = wav.readframes(wav.getnframes())
    elif encoding not in {"pcm_s16le", "pcm16", "pcm", "linear16"}:
        return {"duration_seconds": None, "analysis_status": "unsupported_encoding", "encoding": encoding}
    if not sample_rate or channels < 1:
        raise ValueError("Explicit sample rate/channels required for raw PCM")
    values = samples_from_pcm(data)
    if len(values) % channels:
        raise ValueError("Incomplete interleaved frame")
    n = len(values)
    rms = math.sqrt(sum(x*x for x in values)/n) if n else 0
    return {"duration_seconds": n / channels / sample_rate, "sample_rate": sample_rate, "channels": channels,
            "peak": max((abs(x) for x in values), default=0), "rms": rms,
            "clipped_sample_fraction": sum(abs(x) >= 32767 for x in values) / n if n else None,
            "analysis_status": "measured_pcm", "silence_threshold": None,
            "quality_note": "Level diagnostics are not a perceptual quality score"}


def active_segments(samples, threshold=100):
    if threshold < 1:
        raise ValueError("Positive threshold required")
    result, start = [], None
    for i, value in enumerate(samples):
        if abs(value) >= threshold and start is None:
            start = i
        if abs(value) < threshold and start is not None:
            result.append((start, i))
            start = None
    if start is not None:
        result.append((start, len(samples)))
    return result
