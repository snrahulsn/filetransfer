"""Explicit request-ID reconciliation. Never convert characters to money by assumption."""
from collections import defaultdict
from decimal import Decimal


def reconcile(runs, invoice_rows):
    invoices = {}
    for row in invoice_rows:
        key = (row["provider"], row["request_id"])
        if key in invoices:
            raise ValueError("Duplicate invoice request ID; aggregate line items explicitly first")
        amount = Decimal(str(row["amount"]))
        if not amount.is_finite() or not row["currency"]:
            raise ValueError("Invalid amount/currency")
        invoices[key] = {**row, "amount": str(amount)}
    matched, missing, seen = [], [], set()
    for run in runs:
        request_id = run.get("provider_request_id")
        key = (run["provider"], request_id)
        if request_id and key in seen:
            raise ValueError("Duplicate run request ID; retry attempts require distinct evidence")
        if request_id:
            seen.add(key)
        if request_id and key in invoices:
            matched.append({"run_id": run["run_id"], "status": run["status"], "language": run["language"],
                            "duration_seconds": run.get("duration_seconds"), **invoices[key]})
        else:
            missing.append(run["run_id"])
    totals = defaultdict(lambda: Decimal("0"))
    for row in matched:
        totals[(row["provider"], row["currency"])]+=Decimal(row["amount"])
    return {"status": "reconciled" if not missing and len(matched) == len(invoices) else "incomplete",
            "matched": matched, "unmatched_run_ids": missing,
            "unmatched_invoice_rows": [v for k,v in invoices.items() if k not in seen],
            "totals": [{"provider": p, "currency": c, "amount": str(a)} for (p,c),a in sorted(totals.items())],
            "note": "Includes failed and cancelled requests. No currency conversion or per-minute price inferred."}
