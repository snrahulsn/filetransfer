"""Verify native Hindi Eleven v3 G.711 bytes and the original-rate listening copy."""
import hashlib
import json
from pathlib import Path

from .audio import inspect_audio
from .g711 import mulaw_to_wav


def verify(folder: Path) -> dict:
    folder = Path(folder).resolve()
    root = folder.parents[1]
    manifest = json.loads((folder / 'manifest.json').read_text())
    if any(manifest.get(k) != v for k, v in {
        'schema': 'elevenlabs_telephony_single_v1', 'provider': 'elevenlabs',
        'model': 'eleven_v3', 'language': 'hi-IN', 'format': 'ulaw_8000',
        'max_requests': 1, 'automatic_retries': 0, 'status': 'success',
        'http_status': 200, 'quality_certification': False,
        'production_telephony_verified': False}.items()):
        raise ValueError('ElevenLabs telephony manifest boundary mismatch')
    result_path = (root / manifest['source_result']).resolve()
    if not result_path.is_relative_to(folder):
        raise ValueError('ElevenLabs telephony result escaped folder')
    result = json.loads(result_path.read_text())
    if any(result.get(k) != manifest[k] for k in ('run_id', 'status', 'http_status')):
        raise ValueError('ElevenLabs telephony result provenance mismatch')
    if result.get('config') != manifest['config'] or result.get('text') != manifest['text']:
        raise ValueError('ElevenLabs telephony text/config mismatch')
    if any(result.get('request_contract', {}).get(k) != v for k, v in {
        'method':'POST', 'url_host':'api.elevenlabs.io', 'response_mode':'binary',
        'encoding':'mulaw', 'sample_rate':8000}.items()):
        raise ValueError('ElevenLabs telephony request contract mismatch')
    raw_path = (result_path.parent / result['audio_file']).resolve()
    if not raw_path.is_relative_to(folder):
        raise ValueError('ElevenLabs telephony audio escaped folder')
    raw = raw_path.read_bytes()
    if len(raw) < 800 or raw.startswith((b'RIFF', b'ID3', b'{')):
        raise ValueError('ElevenLabs telephony output is not headerless G.711')
    raw_sha = hashlib.sha256(raw).hexdigest()
    if raw_sha != result.get('audio_sha256') or len(raw) != result.get('audio_bytes'):
        raise ValueError('ElevenLabs telephony raw payload mismatch')
    wav = mulaw_to_wav(raw)
    analysis = inspect_audio(wav)
    if analysis['sample_rate'] != 8000 or analysis['channels'] != 1 or analysis['rms'] < 10:
        raise ValueError('ElevenLabs telephony decoded audio is invalid or silent')
    return {'provider':'elevenlabs', 'model':'eleven_v3', 'language':'hi-IN',
            'run_id':manifest['run_id'], 'source':manifest['source_result'],
            'status':'observed_decodable_8khz_mulaw', 'http_status':200,
            'raw_payload_bytes':len(raw), 'raw_payload_sha256':raw_sha,
            'listening_wav_sha256':hashlib.sha256(wav).hexdigest(),
            'duration_seconds':len(raw)/8000, 'decoded_pcm_rms':analysis['rms'],
            'boundary':'One Hindi HTTP stream on Eleven v3; codec bytes and original-rate WAV verified; SIP/RTP, handset playout, and sustained load untested',
            'vendor_spec_url':manifest['vendor_spec_url']}
