"""Prepare a macOS LaunchAgent; never install, start, stop or contact a provider."""
import argparse
import json
import math
import os
from pathlib import Path
import plistlib
import re
import signal
import stat
import sys
from .credentials import read_credentials
from .remote_worker import main as worker_main,server_url

LABEL='com.ttsarena.outbound-worker'
TOKEN_NAMES=('ARENA_WORKER_TOKEN','ARENA_SITE_ACCESS_TOKEN')

def absolute(value):
    p=Path(value).expanduser()
    if not p.is_absolute():raise ValueError('Absolute paths required')
    return os.path.abspath(p)

def config(root,python,profiles,state,token_file,credentials,server,worker_id='local-arena',poll_seconds=5):
    values={k:absolute(v) for k,v in {'root':root,'python':python,'profiles':profiles,'state':state,'token_file':token_file,'credentials':credentials}.items()}
    if type(poll_seconds) not in (int,float) or not math.isfinite(poll_seconds) or not 1<=poll_seconds<=3600:raise ValueError('Invalid polling interval')
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',worker_id):raise ValueError('Invalid worker ID')
    if not Path(values['python']).is_file() or not os.access(values['python'],os.X_OK):raise ValueError('Python executable missing')
    if not (Path(values['root'])/'tts_arena/remote_worker.py').is_file():raise ValueError('Workspace missing worker')
    if not Path(values['profiles']).is_file():raise ValueError('Profiles file missing')
    values.update(server=server_url(server),worker_id=worker_id,poll_seconds=poll_seconds)
    return values

def manifest(settings,config_path,log_dir):
    config_path=absolute(config_path);log_dir=absolute(log_dir)
    return {'Label':LABEL,'ProgramArguments':[settings['python'],'-u','-m','tts_arena.worker_service','launch','--config',config_path],
            'WorkingDirectory':settings['root'],'RunAtLoad':True,'KeepAlive':True,'ThrottleInterval':30,
            'ExitTimeOut':60,'ProcessType':'Background','Umask':0o077,
            'StandardOutPath':str(Path(log_dir)/'worker.stdout.log'),'StandardErrorPath':str(Path(log_dir)/'worker.stderr.log')}

def private_write(path,data):
    path=Path(path)
    if path.is_symlink():raise ValueError('Refusing symlink output')
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,'wb',closefd=False) as f:f.write(data);f.flush();os.fsync(f.fileno())
    finally:os.close(fd)

def prepare(settings,output):
    output=Path(absolute(output));output.mkdir(parents=True,exist_ok=True);output.chmod(0o700)
    logs=output/'logs';logs.mkdir(exist_ok=True);logs.chmod(0o700)
    for name in ('worker.stdout.log','worker.stderr.log'):
        path=logs/name
        if not path.exists():private_write(path,b'')
        elif path.is_symlink():raise ValueError('Refusing symlink log')
        else:path.chmod(0o600)
    cp=output/'worker-config.json';private_write(cp,json.dumps(settings,indent=2).encode())
    pp=output/(LABEL+'.plist');private_write(pp,plistlib.dumps(manifest(settings,cp,logs)))
    return {'config':str(cp),'plist':str(pp),'installed':False,'started':False}

def check_private_file(path):
    p=Path(path)
    if p.is_symlink():raise ValueError('Token file must not be a symlink')
    st=p.stat()
    if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_mode&0o077:raise ValueError('Token file must be owner-only regular file')
    return p

def load_private_tokens(path):
    p=check_private_file(path)
    values=read_credentials(p)
    if not values.get('ARENA_WORKER_TOKEN'):raise ValueError('Worker token missing')
    return {k:values[k] for k in TOKEN_NAMES if values.get(k)}

def launch(path):
    settings=json.loads(check_private_file(path).read_text())
    checked=config(**settings)
    tokens=load_private_tokens(checked['token_file'])
    old={k:os.environ.get(k) for k in TOKEN_NAMES}
    old_handler=signal.getsignal(signal.SIGTERM)
    stopping=False
    def interrupt(signum,frame):
        nonlocal stopping
        if stopping:return
        stopping=True
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,interrupt)
    try:
        for k in TOKEN_NAMES:
            if k in tokens:os.environ[k]=tokens[k]
            else:os.environ.pop(k,None)
        # Foreground worker and LaunchAgent must share this exact durable state directory.
        return worker_main(['--server',checked['server'],'--root',checked['root'],'--profiles',checked['profiles'],'--state-dir',checked['state'],'--credentials',checked['credentials'],'--worker-id',checked['worker_id'],'--poll-seconds',str(checked['poll_seconds']),'--quiet-idle'])
    finally:
        signal.signal(signal.SIGTERM,old_handler)
        for k,v in old.items():
            if v is None:os.environ.pop(k,None)
            else:os.environ[k]=v

def main(argv=None):
    p=argparse.ArgumentParser(description='Prepare or launch local outbound worker; no launchctl execution')
    sub=p.add_subparsers(dest='action',required=True)
    make=sub.add_parser('prepare')
    for arg in ('root','python','profiles','state','token-file','credentials','server','output'):make.add_argument('--'+arg,required=True)
    make.add_argument('--worker-id',default='local-arena');make.add_argument('--poll-seconds',type=int,default=5)
    run=sub.add_parser('launch');run.add_argument('--config',required=True)
    args=vars(p.parse_args(argv));action=args.pop('action')
    try:
        if action=='launch':return launch(args['config'])
        output=args.pop('output');print(json.dumps(prepare(config(**args),output)));return 0
    except (ValueError,OSError,KeyError,TypeError):print(json.dumps({'status':'service_setup_failed','detail':'Check private configuration, permissions and absolute paths; secret values omitted'}));return 1
if __name__=='__main__':raise SystemExit(main())
