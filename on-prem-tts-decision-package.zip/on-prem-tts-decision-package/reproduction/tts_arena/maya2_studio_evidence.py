"""Verify signed-in Maya 2 Native Studio WAV downloads without treating them as API runs."""
from __future__ import annotations

import hashlib
import json
import math
import wave
from pathlib import Path


LOCALES = ("bn-IN", "mr-IN", "te-IN", "ta-IN", "gu-IN", "kn-IN", "ml-IN")


def _seeds(corpus: Path) -> dict[str, tuple[str, str]]:
    expected = {locale: f"{locale}-amount_date-001" for locale in LOCALES}
    found: dict[str, tuple[str, str]] = {}
    for line in Path(corpus).read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        locale = row.get("language")
        if expected.get(locale) == row.get("id"):
            found[locale] = (row["id"], row["text"])
    if set(found) != set(LOCALES):
        raise ValueError("Maya Studio corpus seeds are incomplete")
    return found


def verify(directory: Path, corpus: Path) -> list[dict]:
    directory = Path(directory).resolve()
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    clips = manifest.get("clips")
    if not isinstance(clips, list) or (
        manifest.get("schema_version"), manifest.get("provider"), manifest.get("evidence_class"),
        manifest.get("route"), manifest.get("model"), manifest.get("voice"),
        manifest.get("output_format"), manifest.get("generated_outputs_per_locale"),
    ) != (1, "maya", "signed_in_browser_studio_download", "Signed-in Maya Studio download",
          "Maya 2 Native", "Ananya", "wav", 1):
        raise ValueError("Maya Studio manifest identity or one-output policy differs")
    locales = [clip.get("locale") for clip in clips]
    if tuple(locales) != LOCALES or len(locales) != len(set(locales)):
        raise ValueError("Maya Studio locale inventory differs or repeats")
    seeds = _seeds(corpus)
    seen_hashes = set()
    for clip in clips:
        locale = clip["locale"]
        if (clip.get("text_id"), clip.get("text")) != seeds[locale]:
            raise ValueError("Maya Studio text differs from fixed corpus seed")
        name = clip.get("wav")
        source = (directory / str(name)).resolve()
        if not source.is_relative_to(directory) or not source.is_file():
            raise ValueError("Maya Studio WAV is missing or escapes evidence directory")
        raw = source.read_bytes()
        if len(raw) != clip.get("wav_bytes") or hashlib.sha256(raw).hexdigest() != clip.get("wav_sha256"):
            raise ValueError("Maya Studio WAV size or hash differs")
        if clip["wav_sha256"] in seen_hashes:
            raise ValueError("Maya Studio WAV is reused across locales")
        seen_hashes.add(clip["wav_sha256"])
        with wave.open(str(source), "rb") as decoded:
            shape = (decoded.getframerate(), decoded.getnchannels(), decoded.getsampwidth(), decoded.getnframes())
            frames = decoded.readframes(decoded.getnframes())
        if shape != (clip.get("sample_rate"), clip.get("channels"), clip.get("sample_width_bytes"), clip.get("frames")):
            raise ValueError("Maya Studio WAV shape differs")
        duration = shape[3] / shape[0]
        if abs(duration - clip.get("duration_seconds", -1)) > .001:
            raise ValueError("Maya Studio WAV duration differs")
        samples = memoryview(frames).cast("h")
        rms = math.sqrt(sum(sample * sample for sample in samples) / len(samples)) if samples else 0
        if rms <= 0:
            raise ValueError("Maya Studio WAV has no signal")
    return sorted(clips, key=lambda clip: LOCALES.index(clip["locale"]))


def verify_usage(directory: Path) -> dict:
    directory = Path(directory).resolve()
    usage = json.loads((directory / "studio-usage.json").read_text(encoding="utf-8"))
    before, after = usage.get("before"), usage.get("after")
    if (usage.get("schema_version"), usage.get("provider"), usage.get("route"), usage.get("allowance_kind")) != (
        1, "maya", "Signed-in Maya Studio", "free credits"):
        raise ValueError("Maya Studio usage identity differs")
    if before != {"remaining_credits": 100000, "used_credits": 0, "tts_requests": 0}:
        raise ValueError("Maya Studio usage before-boundary differs")
    expected_after = {"remaining_credits": 99797, "used_credits": 203, "tts_requests": 7,
                      "concurrency_limit": 5, "first_audio_median_ms": 764, "total_median_ms": 1659}
    if after != expected_after or usage.get("developer_api_key_management") != "disabled; coming soon":
        raise ValueError("Maya Studio usage after-boundary differs")
    if before["remaining_credits"] - after["remaining_credits"] != after["used_credits"]:
        raise ValueError("Maya Studio free-credit arithmetic differs")
    return usage
