"""Generate an offline, blinded emotion-rating page; never create ratings."""
import json
from pathlib import Path
import re

from tts_arena.emotion_quality import EMOTIONS


# Shared by the browser and executable Node state-transition tests.
STATE_JS = r"""
function newRating(item_id) {
  return {item_id, perceived_emotion:null, naturalness:null, text_fidelity:null,
          heard:false, locked:false};
}
function lockEmotion(row, emotion) {
  if (!row.heard || row.locked || !EMOTIONS.includes(emotion)) return false;
  row.perceived_emotion=emotion; row.locked=true; return true;
}
function setScore(row, field, value) {
  if (!row.locked || !['naturalness','text_fidelity'].includes(field)) return false;
  if (value!==null && (!Number.isInteger(value) || value<1 || value>5)) return false;
  row[field]=value; return true;
}
function exportRatings(rows, rater) {
  const id=typeof rater==='string'?rater.trim():'';
  if (!id) return [];
  return rows.filter(r=>r.locked && r.heard && EMOTIONS.includes(r.perceived_emotion)
    && Number.isInteger(r.naturalness) && r.naturalness>=1 && r.naturalness<=5
    && Number.isInteger(r.text_fidelity) && r.text_fidelity>=1 && r.text_fidelity<=5)
    .map(r=>({rater_id:id,item_id:r.item_id,perceived_emotion:r.perceived_emotion,
              naturalness:r.naturalness,text_fidelity:r.text_fidelity}));
}
"""


def write_emotion_listening_page(public_directory):
    """Read the public four-field manifest, validate it, and write index.html.

    Reference text is withheld from the rendered UI until emotion is locked.
    The playback-ended event enables rating; it does not prove attentive or full listening.
    Text remains in the offline file; this is procedural blinding, not protection
    against a reviewer inspecting source. Qualification comes from a separate
    verified roster and is never asserted by this page.
    """
    directory = Path(public_directory).resolve()
    items = json.loads((directory / 'items.json').read_text(encoding='utf-8'))
    if not isinstance(items, list) or not items:
        raise ValueError('Nonempty public item list required')
    seen = set()
    for item in items:
        if not isinstance(item, dict) or set(item) != {'item_id', 'audio_file', 'language', 'text'}:
            raise ValueError('Public items require exactly item_id, audio_file, language and text')
        if any(not isinstance(value, str) or not value.strip() for value in item.values()):
            raise ValueError('Public fields must be nonempty strings')
        if item['item_id'] in seen:
            raise ValueError('Duplicate public item ID')
        seen.add(item['item_id'])
        name = item['audio_file']
        if not re.fullmatch(r'[A-Za-z0-9_-]+\.wav', name):
            raise ValueError('Anonymous local WAV filename required')
        audio = directory / name
        if audio.is_symlink() or not audio.is_file() or not audio.resolve().is_relative_to(directory):
            raise ValueError('Missing or unsafe public audio path')
        with audio.open('rb') as stream:
            header = stream.read(12)
        if header[:4] != b'RIFF' or header[8:12] != b'WAVE':
            raise ValueError('Public audio must be a WAV file')
    data = json.dumps(items, ensure_ascii=False).replace('<', r'\u003c')
    state = 'const EMOTIONS=' + json.dumps(sorted(EMOTIONS)) + ';\n' + STATE_JS
    page = """<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; media-src 'self' blob:; connect-src 'none'; base-uri 'none'; form-action 'none'">
<title>Blind emotion evaluation</title><style>
body{font:16px system-ui;max-width:900px;margin:32px auto;padding:0 20px;color:#18232f;background:#f5f7fa}p{line-height:1.5}article{background:white;border:1px solid #bec7d1;padding:20px;margin:18px 0}label{display:block;margin:12px 0}input,select,button{font:inherit;padding:9px;max-width:100%;box-sizing:border-box}button{cursor:pointer}button:disabled{cursor:default;opacity:.5}audio{display:block;width:100%;margin:12px 0}.reference{white-space:pre-wrap;font-size:19px}[hidden]{display:none!important}:focus-visible{outline:3px solid #1865c0;outline-offset:3px}
</style><h1>Blind emotion evaluation</h1>
<p>Play the sample, select the emotion you heard, then lock that answer. The reference text and quality ratings appear afterward. Emotion answers cannot be revised after seeing the reference text.</p>
<p>Use your assigned listener ID. Eligibility is checked against a separate verified native-language reviewer roster. This page does not qualify listeners. Reference text requires native review. Unequal targets and few texts do not support a fair vendor ranking.</p>
<label>Assigned listener ID <input id="rater" autocomplete="off" maxlength="200"></label>
<label>Language <select id="language"><option value="">All languages</option></select></label>
<button id="download" disabled>Download complete ratings</button><p id="progress" role="status" aria-live="polite"></p>
<p>Only fully rated samples are downloaded. No uploads or automatic saving. Reloading clears your entries. The offline file contains reference text; do not inspect its source during evaluation.</p><main id="samples"></main>
<script id="sample-data" type="application/json">__DATA__</script>
<script>__STATE__
const items=JSON.parse(document.getElementById('sample-data').textContent), rows=[];
const rater=document.getElementById('rater'), download=document.getElementById('download'), language=document.getElementById('language');
function el(tag,text){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e}
function update(){const complete=exportRatings(rows,'count-only').length;document.getElementById('progress').textContent=`${complete} of ${items.length} samples complete. Incomplete samples are excluded.`;download.disabled=exportRatings(rows,rater.value).length===0}
for(const lang of [...new Set(items.map(i=>i.language))].sort()){const o=el('option',lang);o.value=lang;language.append(o)}
items.forEach((item,index)=>{
 const row=newRating(item.item_id);rows.push(row);const card=el('article');card.dataset.language=item.language;
 card.append(el('h2',`Sample ${index+1} · ${item.language}`));const audio=el('audio');audio.controls=true;audio.preload='none';audio.src=item.audio_file;audio.setAttribute('aria-label',`Sample ${index+1} audio`);card.append(audio);
 const label=el('label','Perceived emotion '), choice=el('select');choice.disabled=true;const blank=el('option','Select after listening');blank.value='';choice.append(blank);
 EMOTIONS.forEach(e=>{const o=el('option',e);o.value=e;choice.append(o)});label.append(choice);card.append(label);
 const lock=el('button','Lock emotion and show reference');lock.type='button';lock.disabled=true;card.append(lock);
 const status=el('p','Play the sample before identifying emotion.');status.setAttribute('role','status');card.append(status);
 const detail=el('section');detail.hidden=true;card.append(detail);
 audio.addEventListener('ended',()=>{row.heard=true;if(!row.locked){choice.disabled=false;status.textContent='Select the perceived emotion.';lock.disabled=!choice.value}});
 choice.addEventListener('change',()=>{lock.disabled=!row.heard||!choice.value||row.locked});
 lock.addEventListener('click',()=>{if(!lockEmotion(row,choice.value))return;choice.disabled=true;lock.disabled=true;status.textContent='Emotion locked. Complete both quality ratings.';
   detail.append(el('h3','Reference text'));const ref=el('p',item.text);ref.className='reference';detail.append(ref);
   for(const [field,title,anchors] of [
     ['naturalness','Naturalness — how human-like does the speech sound?',['Very unnatural','Unnatural','Neither natural nor unnatural','Natural','Very natural']],
     ['text_fidelity','Text fidelity — how accurately does the audio match the reference?',['Very poor match','Poor match','Moderate match','Good match','Complete match']]]){
     const l=el('label',title+' '), score=el('select'), empty=el('option','Not rated');empty.value='';score.append(empty);
     anchors.forEach((text,i)=>{const o=el('option',`${i+1} — ${text}`);o.value=String(i+1);score.append(o)});
     score.addEventListener('change',()=>{setScore(row,field,score.value?Number(score.value):null);update()});l.append(score);detail.append(l)
   }detail.hidden=false;detail.querySelector('select').focus();update()
 });document.getElementById('samples').append(card)
});
language.addEventListener('change',()=>document.querySelectorAll('article').forEach(c=>c.hidden=Boolean(language.value&&c.dataset.language!==language.value)));
rater.addEventListener('input',update);
download.addEventListener('click',()=>{const ratings=exportRatings(rows,rater.value);if(!ratings.length)return;const url=URL.createObjectURL(new Blob([JSON.stringify(ratings,null,2)+'\n'],{type:'application/json'}));const a=el('a');a.href=url;a.download='emotion-ratings.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});
update();</script></html>"""
    page = page.replace('__STATE__', state).replace('__DATA__', data)
    # Escape the literal newline in the browser string without changing content.
    page = page.replace("JSON.stringify(ratings,null,2)+'\n'", "JSON.stringify(ratings,null,2)+'\\n'")
    output = directory / 'index.html'
    if output.is_symlink():
        raise ValueError('Unsafe output path')
    output.write_text(page, encoding='utf-8')
    return {'items': len(items), 'ratings_created': 0, 'page': str(output)}
