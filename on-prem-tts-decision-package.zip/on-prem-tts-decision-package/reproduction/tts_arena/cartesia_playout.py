"""Bounded Cartesia-to-replay bridge for software PCM playout measurements.

This is a local WebSocket bridge, not a telephony integration.  It uses the
Cartesia session codec for the documented context messages and keeps provider
audio received after native cancellation out of the replay playout stream.
"""
import asyncio
import base64
import hashlib
import json
import math
from pathlib import Path
import time

from websockets.asyncio.client import connect as websocket_connect
from websockets.asyncio.server import serve

from .credentials import redact
from .replay import load_caller, replay
from .sessions import cartesia
from .transport import safe_url


_MAX_CAPTURE_BYTES = 32_000_000


def _finite(value, name, minimum, maximum):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError(f"{name} must be finite and within [{minimum}, {maximum}]")


def preflight(config, text, env, caller_wav, sample_rate, observation_seconds):
    """Validate every caller-controlled input without connecting or writing output."""
    if not isinstance(config, dict) or not isinstance(env, dict):
        raise ValueError("Cartesia config and credentials must be mappings")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Cartesia bridge text must be nonempty")
    if type(sample_rate) is not int:
        raise ValueError("Cartesia bridge sample rate must be an integer")
    _finite(observation_seconds, "Cartesia bridge observation", 0.1, 600)
    # This also rejects unknown controls, non-raw formats, and invalid model/voice/locale.
    spec = cartesia.build_session(config, env)
    if spec.sample_rate != sample_rate or spec.encoding != "pcm_s16le":
        raise ValueError("Cartesia bridge and replay must use the same raw pcm_s16le sample rate")
    context_id = config.get("context_id", "cartesia-replay")
    if not isinstance(context_id, str) or not context_id:
        raise ValueError("Cartesia bridge context_id must be nonempty")
    cartesia.encode_action({"type": "text", "context_id": context_id, "text": text}, config)
    cartesia.encode_action({"type": "end_input", "context_id": context_id}, config)
    cartesia.encode_action({"type": "cancel", "context_id": context_id}, config)
    # Replay's output directory is deliberately not created until this fixture is sound.
    load_caller(caller_wav, sample_rate)
    return spec, context_id


async def replay_cartesia(
    caller_wav,
    destination,
    config,
    text,
    env,
    *,
    sample_rate=8000,
    onset_offset_ms=300,
    observation_seconds=5,
    stop_threshold_ms=500,
    allow_local=False,
    vendor_url=None,
    vendor_connector=None,
    caller_fixture_label="unclassified_caller_fixture",
):
    """Play one bounded Cartesia response into :func:`replay` and inject caller PCM.

    The first ``caller_audio`` clears replay's local queue before sending the
    documented ``{context_id, cancel: true}`` message.  Vendor payloads that
    arrive afterwards are captured separately and never forwarded as bot audio.
    """
    spec, context_id = preflight(
        config, text, env, caller_wav, sample_rate, observation_seconds
    )
    if vendor_url is None:
        vendor_url = spec.url
    safe_url(
        vendor_url.replace("wss://", "https://", 1).replace("ws://", "http://", 1),
        allow_local,
    )
    output = Path(destination)
    if output.exists():
        raise FileExistsError("Cartesia bridge output destination already exists")

    events = []
    post_cancel = bytearray()
    state = {
        "cancelled": False,
        "cancel_sent": False,
        "response_ended": False,
        "bridge_timeout": False,
    }
    origin = time.perf_counter_ns()

    def event(kind, **fields):
        events.append(
            {
                "sequence": len(events),
                "elapsed_ms": (time.perf_counter_ns() - origin) / 1e6,
                "event_type": kind,
                **fields,
            }
        )

    async def local_bot(local_ws):
        raw_start = await local_ws.recv()
        start = json.loads(raw_start)
        if start != {
            "type": "start",
            "sample_rate": sample_rate,
            "format": "pcm_s16le",
            "frame_ms": 20,
        }:
            raise ValueError("Replay start message does not match the PCM bridge contract")
        event("replay_started")
        connector = vendor_connector or websocket_connect
        async with connector(
            vendor_url,
            additional_headers=spec.headers,
            max_size=2_000_000,
            open_timeout=min(float(observation_seconds), 30),
        ) as vendor_ws:
            initial = cartesia.encode_action(
                {"type": "text", "context_id": context_id, "text": text}, config
            )
            end_input = cartesia.encode_action(
                {"type": "end_input", "context_id": context_id}, config
            )
            for message in initial:
                await vendor_ws.send(json.dumps(message))
            event("vendor_text_sent", context_id=context_id)
            for message in end_input:
                await vendor_ws.send(json.dumps(message))
            event("vendor_end_input_sent", context_id=context_id)
            send_lock = asyncio.Lock()
            frame_bytes = sample_rate // 50 * 2
            pending = bytearray()

            async def emit_frames():
                while len(pending) >= frame_bytes and not state["cancelled"]:
                    frame = bytes(pending[:frame_bytes])
                    del pending[:frame_bytes]
                    await local_ws.send(
                        json.dumps(
                            {
                                "type": "audio",
                                "response_id": context_id,
                                "audio": base64.b64encode(frame).decode("ascii"),
                            }
                        )
                    )
                    event("playout_frame_sent", byte_count=len(frame))

            async def receive_vendor():
                async for raw in vendor_ws:
                    decoded_messages = cartesia.decode_message(raw)
                    for decoded in decoded_messages:
                        kind = decoded["type"]
                        if kind == "audio":
                            audio = decoded["audio"]
                            if state["cancelled"]:
                                remaining = _MAX_CAPTURE_BYTES - len(post_cancel)
                                if remaining <= 0:
                                    raise ValueError("Post-cancel Cartesia capture exceeds 32MB")
                                post_cancel.extend(audio[:remaining])
                                event(
                                    "provider_audio_after_cancel",
                                    byte_count=len(audio),
                                    captured_bytes=min(len(audio), remaining),
                                )
                            else:
                                async with send_lock:
                                    if state["cancelled"]:
                                        continue
                                    pending.extend(audio)
                                    event("provider_audio_before_cancel", byte_count=len(audio))
                                    await emit_frames()
                        elif kind in {"done", "cancelled"}:
                            async with send_lock:
                                if not state["response_ended"]:
                                    await local_ws.send(
                                        json.dumps({"type": "response_end", "response_id": context_id})
                                    )
                                    state["response_ended"] = True
                            event("provider_terminal", provider_type=kind)
                            return
                        elif kind == "error":
                            raise ValueError("Cartesia provider reported an error")
                        else:
                            event("provider_event", provider_type=kind)

            async def receive_caller():
                async for raw in local_ws:
                    message = json.loads(raw)
                    if message.get("type") != "caller_audio":
                        raise ValueError("Replay bot sent an unexpected message")
                    async with send_lock:
                        if state["cancelled"]:
                            continue
                        state["cancelled"] = True
                        pending.clear()
                        # Clearing local playout precedes vendor cancellation by design.
                        await local_ws.send(
                            json.dumps({"type": "clear", "response_id": context_id})
                        )
                        event("local_playout_cleared", response_id=context_id)
                        cancel = cartesia.encode_action(
                            {"type": "cancel", "context_id": context_id}, config
                        )
                        for message in cancel:
                            await vendor_ws.send(json.dumps(message))
                        state["cancel_sent"] = True
                        event("native_cancel_sent", context_id=context_id)
            vendor_task = asyncio.create_task(receive_vendor())
            caller_task = asyncio.create_task(receive_caller())
            try:
                done, pending_tasks = await asyncio.wait_for(
                    asyncio.wait(
                        (vendor_task, caller_task), return_when=asyncio.FIRST_EXCEPTION
                    ),
                    timeout=float(observation_seconds) + 1,
                )
                for task in done:
                    if not task.cancelled() and task.exception():
                        raise task.exception()
                # A normal vendor close is a terminal condition even when it did not send done.
                if vendor_task in done and not state["response_ended"]:
                    async with send_lock:
                        await local_ws.send(json.dumps({"type": "response_end", "response_id": context_id}))
                        state["response_ended"] = True
                    event("provider_closed_without_terminal")
                await asyncio.gather(*pending_tasks)
            except TimeoutError:
                state["bridge_timeout"] = True
                event(
                    "bridge_timeout",
                    timeout_seconds=float(observation_seconds) + 1,
                    reason="vendor_or_local_receive_task_did_not_finish",
                )
            finally:
                for task in (vendor_task, caller_task):
                    task.cancel()
                await asyncio.gather(vendor_task, caller_task, return_exceptions=True)

    async with serve(local_bot, "127.0.0.1", 0) as server:
        port = server.sockets[0].getsockname()[1]
        result = await replay(
            f"ws://127.0.0.1:{port}",
            caller_wav,
            destination,
            sample_rate=sample_rate,
            onset_offset_ms=onset_offset_ms,
            observation_seconds=observation_seconds,
            stop_threshold_ms=stop_threshold_ms,
            allow_local=True,
        )
    bridge_root = Path(destination)
    post_path = bridge_root / "provider-after-cancel.pcm"
    if post_cancel:
        post_path.write_bytes(post_cancel)
    report = {
        "provider": "cartesia",
        "model": config.get("model"),
        "boundary": "software_PCM_playout_bridge_not_production_telephony",
        "certification": "not_live_verified",
        "context_id": context_id,
        "status": "inconclusive" if state["bridge_timeout"] else "observed",
        "caller_fixture_label": caller_fixture_label,
        "native_cancel_sent": state["cancel_sent"],
        "provider_payload_after_cancel": {
            "path": post_path.name if post_cancel else None,
            "bytes": len(post_cancel),
            "sha256": hashlib.sha256(post_cancel).hexdigest() if post_cancel else None,
            "played_locally": False,
        },
        "events": events,
    }
    (bridge_root / "cartesia-bridge.json").write_text(
        redact(json.dumps(report, indent=2, ensure_ascii=False), env) + "\n"
    )
    result["cartesia_bridge"] = report
    if state["bridge_timeout"]:
        result["status"] = "inconclusive"
        result["error_type"] = "BridgeTimeout"
        saved = bridge_root / "result.json"
        persisted = json.loads(saved.read_text())
        persisted["status"] = "inconclusive"
        persisted["error_type"] = "BridgeTimeout"
        persisted["bridge_timeout"] = {
            "timeout_seconds": float(observation_seconds) + 1,
            "reason": "vendor_or_local_receive_task_did_not_finish",
        }
        saved.write_text(redact(json.dumps(persisted, indent=2), env) + "\n")
    return result
