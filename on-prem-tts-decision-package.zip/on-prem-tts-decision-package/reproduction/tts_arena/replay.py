"""PCM WebSocket caller probe. Boundary is software playout, not a physical handset."""
import asyncio
import base64
import hashlib
import io
import json
import math
from pathlib import Path
import time
import wave

from .audio import TimelineRecorder, samples_from_pcm
from .metrics import barge_in
from .registry import code_digest
from .transport import safe_url


def load_caller(path, sample_rate):
    source = path if isinstance(path, bytes) else Path(path).read_bytes()
    try:
        with wave.open(io.BytesIO(source),"rb") as wav:
            if (wav.getnchannels(),wav.getsampwidth(),wav.getframerate(),wav.getcomptype()) != (1,2,sample_rate,"NONE"):
                raise ValueError("Caller fixture must be mono PCM16 WAV at the configured sample rate; no implicit resampling")
            frames = wav.getnframes()
            caller = wav.readframes(frames + 1)
            if frames <= 0 or len(caller) != frames * 2:
                raise ValueError("Caller fixture must contain nonempty, complete PCM16 frames")
            return caller
    except (wave.Error, EOFError) as exc:
        raise ValueError("Caller fixture must be a complete PCM WAV file") from exc


async def replay(endpoint, caller_wav, destination, sample_rate=8000, onset_offset_ms=300, observation_seconds=5,
                 expected_interrupt=True, stop_threshold_ms=500, allow_local=False, connector=None):
    # Validate all caller-controlled configuration before network or output side effects.
    def finite_number(value):
        try:
            return type(value) in (int, float) and math.isfinite(value)
        except OverflowError:
            return False

    if type(sample_rate) is not int or sample_rate not in {8000,16000,24000,48000}:
        raise ValueError("Replay sample rate must be a supported integer")
    if not finite_number(onset_offset_ms) or onset_offset_ms < 0:
        raise ValueError("Replay onset offset must be finite and nonnegative")
    if not finite_number(stop_threshold_ms) or stop_threshold_ms <= 0:
        raise ValueError("Replay stop threshold must be finite and positive")
    if not finite_number(observation_seconds) or not 0 < observation_seconds <= 600:
        raise ValueError("Replay observation must be finite and within (0, 600] seconds")
    if type(expected_interrupt) is not bool or type(allow_local) is not bool:
        raise ValueError("Replay expected_interrupt and allow_local must be booleans")
    from websockets.asyncio.client import connect
    # Same security policy as HTTPS with explicit localhost opt-in.
    safe_url(endpoint.replace("wss://","https://",1).replace("ws://","http://",1),allow_local)
    caller_source=Path(caller_wav).read_bytes()
    caller=load_caller(caller_source,sample_rate)
    if len(caller)/2/sample_rate + onset_offset_ms/1000 + stop_threshold_ms/1000 >= observation_seconds:
        raise ValueError("Observation window must include caller and the full stop deadline tail")
    output=Path(destination);output.mkdir(parents=True,exist_ok=False)
    plan = {
        "caller_sha256": hashlib.sha256(caller_source).hexdigest(),
        "caller_pcm_sha256": hashlib.sha256(caller).hexdigest(),
        "code_sha256": code_digest(),
        "sample_rate": sample_rate,
        "onset_offset_ms": onset_offset_ms,
        "observation_seconds": observation_seconds,
        "expected_interrupt": expected_interrupt,
        "stop_threshold_ms": stop_threshold_ms,
        "allow_local": allow_local,
        "boundary": "software_PCM_playout_probe",
    }
    (output / "plan.json").write_text(json.dumps(plan, indent=2, allow_nan=False) + "\n")
    frame_samples=sample_rate//50
    queue=asyncio.Queue(maxsize=1000)
    first_playback=asyncio.Event()
    origin=time.perf_counter_ns()
    bot=TimelineRecorder(sample_rate,observation_seconds+1)
    user=TimelineRecorder(sample_rate,observation_seconds+1)
    tracks={};events=[];completed=set();speech_frames={}
    state={"onset":None,"cancel":None,"response":None,"first_playback_ns":None,"clock_errors":[],"last_speech":None}

    def log(kind,**fields):
        now=time.perf_counter_ns()
        events.append({"sequence":len(events),"monotonic_ns":now,"elapsed_ms":(now-origin)/1e6,"event_type":kind,**fields})

    def position():
        return round((time.perf_counter_ns()-origin)*sample_rate/1e9)

    async def receive(ws):
        async for raw in ws:
            value=json.loads(raw)
            if value["type"]=="audio":
                audio=base64.b64decode(value["audio"],validate=True)
                if len(audio)!=frame_samples*2:
                    raise ValueError("Bot must send exactly 20ms mono PCM16 frames")
                response_id=str(value["response_id"])
                log("audio_received",response_id=response_id,queue_depth=queue.qsize())
                await queue.put((response_id,audio))
            elif value["type"]=="clear":
                target=value.get("response_id",state["response"])
                if state["onset"] is not None and state["cancel"] is None and target==state["response"]:
                    state["cancel"]=position()
                removed=0
                retained=[]
                while not queue.empty():
                    queued=queue.get_nowait()
                    if "response_id" not in value or queued[0]==str(value["response_id"]):
                        removed+=1
                    else: retained.append(queued)
                for queued in retained: queue.put_nowait(queued)
                log("clear_received",response_id=value.get("response_id"),scope="response" if "response_id" in value else "global",discarded_frames=removed)
            elif value["type"]=="response_end":
                completed.add(str(value["response_id"]))
                log("response_end",response_id=str(value["response_id"]))
            elif value["type"]=="error":
                raise ValueError("Bot reported protocol error")
            else:
                log("bot_event",name=str(value["type"]))

    async def playback():
        next_tick=time.perf_counter()
        end_index=0
        while True:
            await asyncio.sleep(max(0,next_tick-time.perf_counter()))
            next_tick+=.02
            actual=position()
            start=max(actual,end_index)
            if queue.empty():
                log("playout_silence",sample_index=start)
                continue
            response_id,audio=queue.get_nowait()
            bot.write_at(start,audio)
            tracks.setdefault(response_id,TimelineRecorder(sample_rate,observation_seconds+1)).write_at(start,audio)
            end_index=start+frame_samples
            log("playout",sample_index=start,end_sample=end_index,response_id=response_id,queue_depth=queue.qsize(),scheduling_lag_samples=start-actual)
            values=samples_from_pcm(audio)
            # Frame RMS avoids classifying individual waveform zero crossings as silence.
            audible=sum(x*x for x in values)/len(values)>=100**2
            if audible:
                speech_frames.setdefault(response_id,[]).append((start,end_index))
                state["last_speech"]=(response_id,start,end_index)
            if audible and not first_playback.is_set():
                state["first_playback_ns"]=time.perf_counter_ns()
                first_playback.set()

    async def inject(ws):
        await first_playback.wait()
        target=state["first_playback_ns"]+int(onset_offset_ms*1e6)
        await asyncio.sleep(max(0,(target-time.perf_counter_ns())/1e9))
        inject_origin=time.perf_counter()
        last_end=0
        for offset in range(0,len(caller),frame_samples*2):
            await asyncio.sleep(max(0,inject_origin+offset/2/sample_rate-time.perf_counter()))
            chunk=caller[offset:offset+frame_samples*2]
            start=max(position(),last_end)
            if state["onset"] is None:
                # Fixture onset is annotated at sample zero; silence-prefixed fixtures need trimmed/annotated onset.
                state["onset"]=start
                last=state["last_speech"]
                if last and start-last[2]<=frame_samples:
                    state["response"]=last[0]
                log("caller_onset",sample_index=start,injection_error_ms=(time.perf_counter_ns()-target)/1e6)
            user.write_at(start,chunk)
            last_end=start+len(chunk)//2
            await ws.send(json.dumps({"type":"caller_audio","audio":base64.b64encode(chunk).decode(),"sample_rate":sample_rate}))
        log("caller_end",sample_index=last_end)

    error=None
    async with (connector or connect)(endpoint,max_size=2_000_000) as ws:
        origin=time.perf_counter_ns()
        await ws.send(json.dumps({"type":"start","sample_rate":sample_rate,"format":"pcm_s16le","frame_ms":20}))
        tasks=[asyncio.create_task(receive(ws)),asyncio.create_task(playback()),asyncio.create_task(inject(ws))]
        deadline=time.perf_counter()+observation_seconds
        try:
            while time.perf_counter()<deadline:
                for task in tasks:
                    if task.done() and not task.cancelled() and task.exception():
                        raise task.exception()
                await asyncio.sleep(min(.02,max(0,deadline-time.perf_counter())))
        except Exception as exc:
            error=type(exc).__name__
        finally:
            for task in tasks: task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
    end=max(position(),len(bot.samples),len(user.samples))
    (output/"bot.wav").write_bytes(bot.wav(end))
    (output/"caller.wav").write_bytes(user.wav(end))
    interrupted=tracks.get(state["response"])
    metrics=None
    if state["onset"] is not None and interrupted is not None:
        segments=[]
        for a,b in speech_frames.get(state["response"],[]):
            # Bridge <=one-frame scheduler gaps for eligibility; disclose frame granularity.
            if segments and a-segments[-1][1]<=frame_samples:
                segments[-1]=(segments[-1][0],b)
            else: segments.append((a,b))
        complete=state["response"] in completed and queue.empty()
        replacement_starts=[a for response_id,frames in speech_frames.items()
                            if response_id!=state["response"] for a,_ in frames
                            if a>=state["onset"]]
        metrics=barge_in(state["onset"],segments,sample_rate,expected_interrupt,end,
                         cancel_sample=state["cancel"],
                         next_response_sample=min(replacement_starts) if replacement_starts else None,
                         threshold_ms=stop_threshold_ms,observation_complete=complete)
        metrics["speech_activity_method"]="20ms_frame_RMS_threshold_100; gaps_up_to_20ms_merged"
        metrics["timing_resolution_ms"]=20
    report={"status":"error" if error else "observed" if metrics else "inconclusive","error_type":error,
            "boundary":"software_PCM_playout_probe","sample_rate":sample_rate,"frame_ms":20,
            "timing_accuracy_ms":None,"caller_onset_assumption":"fixture first sample is annotated speech onset",
            "metrics":metrics,"events":events,"production_telephony_verified":False,
            "human_language_validation":False,"observation_seconds":observation_seconds,
            "target_response_id":state["response"],"completed_response_ids":sorted(completed)}
    (output/"result.json").write_text(json.dumps(report,indent=2)+"\n")
    return report
