"""Durable allowlisted offline jobs. Not a hosted/UI worker or arbitrary command API."""
import argparse
import contextlib
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import sqlite3
import subprocess
import sys
import threading
import time
import uuid

KINDS={'validate':60,'self-test':180,'inventory':60}
STATUSES={'queued','running','succeeded','failed','interrupted'}
MAX_LOG_BYTES=2*1024*1024


def _run_process(command,cwd,output,timeout,lock_fd):
    """Internal fixed-command executor. Caller constructs command from an allowlist."""
    output.mkdir(parents=True,exist_ok=True)
    env={'PATH':os.defpath,'LANG':'en_US.UTF-8','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'}
    for key in ('TMPDIR','SYSTEMROOT'):
        if key in os.environ:env[key]=os.environ[key]
    child=subprocess.Popen(command,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,pass_fds=(lock_fd,))
    truncated={};log_errors=[]
    def drain(stream,name):
        total=0
        try:
            with (output/name).open('wb') as target:
                for chunk in iter(lambda:stream.read(8192),b''):
                    available=max(0,MAX_LOG_BYTES-total)
                    if available:target.write(chunk[:available])
                    total+=len(chunk)
            truncated[name]=total>MAX_LOG_BYTES
        except OSError as exc:log_errors.append({'log':name,'error_type':type(exc).__name__})
        finally:stream.close()
    threads=[threading.Thread(target=drain,args=(child.stdout,'stdout.log'),daemon=True),threading.Thread(target=drain,args=(child.stderr,'stderr.log'),daemon=True)]
    for thread in threads:thread.start()
    timed_out=False
    try:code=child.wait(timeout=timeout+.25)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(child.pid,signal.SIGTERM)
        try:code=child.wait(timeout=2)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=2)
    for thread in threads:thread.join(timeout=3)
    return {'exit_code':code,'timed_out':timed_out,'log_truncated':truncated,'log_errors':log_errors}


class JobQueue:
    def __init__(self,root,state_dir=None):
        self.root=Path(root).resolve()
        if not (self.root/'tts_arena/__init__.py').is_file() or not (self.root/'catalog').is_dir():raise ValueError('root must be a TTS Arena workspace')
        self.state=Path(state_dir).resolve() if state_dir else self.root/'artifacts/jobs'
        self.state.mkdir(parents=True,exist_ok=True)
        self.db=self.state/'jobs.sqlite';self.interpreter=sys.executable
        with self.connection() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('''CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,kind TEXT NOT NULL,status TEXT NOT NULL,created REAL NOT NULL,started REAL,finished REAL,timeout INTEGER NOT NULL,idempotency_key TEXT UNIQUE,exit_code INTEGER,error TEXT,output_dir TEXT,execution_json TEXT)''')
            db.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
            row=db.execute("SELECT value FROM settings WHERE key='root'").fetchone()
            if row and row[0]!=str(self.root):raise ValueError('Queue database belongs to another workspace')
            db.execute("INSERT OR IGNORE INTO settings VALUES('root',?)",(str(self.root),))

    @contextlib.contextmanager
    def connection(self):
        db=sqlite3.connect(self.db,timeout=10);db.row_factory=sqlite3.Row
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback();raise
        finally:db.close()

    def submit(self,kind,timeout=None,idempotency_key=None):
        if not isinstance(kind,str) or kind not in KINDS:raise ValueError('Only validate, self-test and inventory jobs are allowed')
        timeout=KINDS[kind] if timeout is None else timeout
        if type(timeout)is not int or not 1<=timeout<=600:raise ValueError('timeout must be integer1-600seconds')
        if idempotency_key is not None and (not isinstance(idempotency_key,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',idempotency_key)):raise ValueError('Invalid idempotency key')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            if idempotency_key is not None:
                row=db.execute('SELECT * FROM jobs WHERE idempotency_key=?',(idempotency_key,)).fetchone()
                if row:
                    if row['kind']!=kind or row['timeout']!=timeout:raise ValueError('Idempotency key already bound to different job parameters')
                    return dict(row)
            job_id=uuid.uuid4().hex
            db.execute('INSERT INTO jobs(id,kind,status,created,timeout,idempotency_key) VALUES(?,?,?,?,?,?)',(job_id,kind,'queued',time.time(),timeout,idempotency_key))
            return dict(db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone())

    def status(self,job_id=None):
        with self.connection() as db:
            if job_id:
                row=db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()
                if row is None:raise ValueError('Unknown job ID')
                return dict(row)
            return [dict(row) for row in db.execute('SELECT * FROM jobs ORDER BY created,id')]

    def run_next(self):
        with (self.state/'worker.lock').open('a+b') as lock:
            try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:return {'dispatch':'worker_busy'}
            # Child inherits this lock. A restart cannot run another job until any orphan child exits.
            with self.connection() as db:
                db.execute('BEGIN IMMEDIATE')
                recovered=db.execute("UPDATE jobs SET status='interrupted',finished=?,error='Previous worker ended without terminal status; not automatically replayed' WHERE status='running'",(time.time(),)).rowcount
                row=db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created,id LIMIT 1").fetchone()
                if row is None:return {'dispatch':'empty','recovered_interrupted':recovered}
                row=dict(row);output=self.state/'outputs'/row['id']
                db.execute("UPDATE jobs SET status='running',started=?,output_dir=? WHERE id=? AND status='queued'",(time.time(),str(output),row['id']))
            command=[self.interpreter,'-m','tts_arena.jobs','_execute',row['kind'],'--output',str(output),'--timeout',str(row['timeout'])]
            try:
                execution=_run_process(command,str(self.root),output,row['timeout'],lock.fileno())
                execution.update(interpreter=self.interpreter,workspace_root=str(self.root),job_kind=row['kind'])
                status='succeeded' if execution['exit_code']==0 and not execution['timed_out'] and not execution.get('log_errors') else 'failed'
                error='Bounded execution timed out' if execution['timed_out'] else None if status=='succeeded' else 'Offline job exited unsuccessfully; see bounded logs'
            except BaseException as exc:
                status='interrupted' if isinstance(exc,(KeyboardInterrupt,SystemExit)) else 'failed'
                execution={'exception_type':type(exc).__name__};error='Worker interrupted' if status=='interrupted' else 'Job launch/execution failed'
            with self.connection() as db:
                db.execute("UPDATE jobs SET status=?,finished=?,exit_code=?,error=?,execution_json=? WHERE id=? AND status='running'",(status,time.time(),execution.get('exit_code'),error,json.dumps(execution),row['id']))
            result=self.status(row['id']);result['recovered_interrupted']=recovered
            return result


def _offline_execution(kind,output,timeout):
    if kind not in KINDS:raise ValueError('Unknown offline job')
    # Block outbound connections even if a future offline regression accidentally attempts one.
    import socket
    original=socket.socket.connect
    original_dns=socket.getaddrinfo
    def local_dns(host,*args,**kwargs):
        if host not in {None,'localhost','127.0.0.1','::1'}:raise PermissionError('Offline verification forbids remote DNS')
        return original_dns(host,*args,**kwargs)
    socket.getaddrinfo=local_dns
    def loopback_only(sock,address):
        if sock.family in (socket.AF_INET,socket.AF_INET6) and address[0] not in {'localhost','127.0.0.1','::1'}:raise PermissionError('Offline verification forbids remote network')
        return original(sock,address)
    socket.socket.connect=loopback_only
    def alarm(signum,frame):raise TimeoutError('Offline job deadline exceeded')
    old_handler=signal.signal(signal.SIGALRM,alarm);signal.alarm(timeout)
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    try:
        if kind=='validate':
            from .registry import catalog,validate
            items=catalog();issues={p['id']:validate(p) for p in items if validate(p)}
            result={'count':len(items),'errors':issues};code=bool(issues)
        elif kind=='self-test':
            from .certification import self_test
            result=self_test(output/'verification');code=not result['passed']
        else:
            from .registry import ROOT
            from .evidence_inventory import inventory
            result=inventory(ROOT);code=bool(result['issues'])
        (output/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'kind':kind,'result_file':str(output/'result.json'),'passed':not code}));return int(code)
    finally:
        signal.alarm(0);signal.signal(signal.SIGALRM,old_handler)
        socket.socket.connect=original;socket.getaddrinfo=original_dns


def main(argv=None):
    parser=argparse.ArgumentParser(description='Durable allowlisted offline verification queue; no provider calls')
    parser.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));parser.add_argument('--state-dir')
    sub=parser.add_subparsers(dest='action',required=True)
    submit=sub.add_parser('submit');submit.add_argument('kind',choices=sorted(KINDS));submit.add_argument('--timeout',type=int);submit.add_argument('--idempotency-key')
    status=sub.add_parser('status');status.add_argument('job_id',nargs='?')
    sub.add_parser('run-next')
    execute=sub.add_parser('_execute',help=argparse.SUPPRESS);execute.add_argument('kind',choices=sorted(KINDS));execute.add_argument('--output',required=True);execute.add_argument('--timeout',type=int,required=True)
    args=parser.parse_args(argv)
    if args.action=='_execute':
        if not 1<=args.timeout<=600:raise ValueError('Invalid internal job timeout')
        return _offline_execution(args.kind,args.output,args.timeout)
    queue=JobQueue(args.root,args.state_dir)
    if args.action=='submit':result=queue.submit(args.kind,args.timeout,args.idempotency_key)
    elif args.action=='status':result=queue.status(args.job_id)
    else:result=queue.run_next()
    print(json.dumps(result,indent=2));return 1 if isinstance(result,dict) and result.get('status') in {'failed','interrupted'} else 0

if __name__=='__main__':raise SystemExit(main())
