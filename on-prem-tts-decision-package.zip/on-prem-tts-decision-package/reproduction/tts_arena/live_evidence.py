"""Inventory saved HTTP observations without promoting historical runs to certification."""
import json
from pathlib import Path
from .registry import digest


def load_live_runs(directory):
    runs, issues = {}, []
    conflicts = set()
    for path in sorted(Path(directory).rglob('result.json')):
        try:
            value=json.loads(path.read_text())
            if not isinstance(value,dict): raise ValueError('record is not an object')
            if value.get('evidence_class')!='live_http': continue
            host=value.get('request_contract',{}).get('url_host')
            if not host or host in {'localhost','127.0.0.1','::1'}:
                issues.append({'path':str(path),'reason':'missing_vendor_host_or_local_fixture'}); continue
            run_id=value.get('run_id')
            if not run_id or not value.get('provider') or value.get('status') not in {'success','error','blocked','cancelled'}:
                raise ValueError('missing identity or terminal status')
            if run_id in runs and runs[run_id]!=value:
                conflicts.add(run_id)
                issues.append({'path':str(path),'reason':'conflicting_duplicate_run_id'})
            else:
                runs[run_id]=value
        except (ValueError,TypeError,AttributeError,OSError):
            issues.append({'path':str(path),'reason':'invalid_or_unreadable_record'})
    return [v for k,v in runs.items() if k not in conflicts],issues


def summarize_live_runs(runs, current_hash, items):
    specs={i['id']:digest(i) for i in items}
    current=[r for r in runs if r.get('code_sha256')==current_hash
             and r.get('vendor_spec_sha256')==specs.get(r.get('provider'))
             and r.get('provider') in specs and r.get('evidence_class')=='live_http']
    counts={}
    for provider in sorted({r['provider'] for r in runs}):
        group=[r for r in runs if r['provider']==provider]
        counts[provider]={'attempts':len(group),'successes':sum(r.get('status')=='success' for r in group)}
    return {'historical_attempts':len(runs),'historical_successes':sum(r.get('status')=='success' for r in runs),
            'historical_non_successes':sum(r.get('status')!='success' for r in runs),
            'providers_attempted':len(counts),'providers_with_success':sum(v['successes']>0 for v in counts.values()),
            'exact_current_hash_attempts':len(current),'exact_current_hash_successes':sum(r.get('status')=='success' for r in current),
            'historical_only_attempts':len(runs)-len(current),'by_provider':counts,
            'scope':'Saved HTTP observations, including failed attempts. Exact-current eligibility also requires matching vendor catalog hash. Neither count certifies quality or vendor behavior.'}
