"""Behavior checks over explicit recorded evidence. Never infer effects from accepted fields."""
import math


def evaluate(feature, evidence, thresholds=None):
    thresholds=thresholds or {}
    result={"feature":feature,"status":"inconclusive","measurements":{},"reason":None}
    def need(*keys):
        return all(key in evidence and evidence[key] is not None for key in keys)
    if evidence.get("vendor_status")=="unsupported":
        return {**result,"status":"unsupported","reason":"Model-specific vendor specification excludes this feature"}
    if feature=="text_input_streaming" and need("first_audio_ns","last_text_sent_ns"):
        delta=(evidence["last_text_sent_ns"]-evidence["first_audio_ns"])/1e6
        result.update(status="passed" if delta>0 else "failed",measurements={"audio_before_input_completion_ms":delta})
    elif feature=="audio_streaming" and need("audio_chunk_times_ns","response_end_ns"):
        times=evidence["audio_chunk_times_ns"]
        if len(times)<2:
            result.update(status="inconclusive",reason="Need multiple nonempty audio payloads on a sufficiently long fixture")
        else:
            result.update(status="passed" if times[0]<times[-1]<=evidence["response_end_ns"] else "failed")
    elif feature=="cancel" and need("cancel_ns","last_old_response_playout_ns","observation_complete"):
        delay=max(0,(evidence["last_old_response_playout_ns"]-evidence["cancel_ns"])/1e6)
        result.update(status=("passed" if delay<=thresholds.get("max_tail_ms",100) else "failed") if evidence["observation_complete"] else "inconclusive",measurements={"old_audio_tail_ms":delay})
    elif feature=="flush" and need("flush_ns","pending_audio_ns","input_ended_before_flush"):
        delay=(evidence["pending_audio_ns"]-evidence["flush_ns"])/1e6
        result.update(status="passed" if not evidence["input_ended_before_flush"] and 0<=delay<=thresholds.get("max_flush_ms",1000) else "failed",measurements={"flush_to_pending_audio_ms":delay})
    elif feature=="connection_reuse" and need("session_ids","request_successes"):
        sessions=evidence["session_ids"];successes=evidence["request_successes"]
        result.update(status="passed" if len(sessions)>=2 and len(sessions)==len(successes) and len(set(sessions))==1 and all(successes) else "failed")
    elif feature=="speed" and need("baseline_duration_seconds","controlled_duration_seconds","requested_speed_ratio"):
        baseline,controlled,ratio=(evidence[k] for k in ("baseline_duration_seconds","controlled_duration_seconds","requested_speed_ratio"))
        if any(not isinstance(x,(int,float)) or not math.isfinite(x) or x<=0 for x in (baseline,controlled,ratio)):
            raise ValueError("Durations and ratio must be finite and positive")
        observed=baseline/controlled
        relative_error=abs(observed-ratio)/ratio
        result.update(status="passed" if relative_error<=thresholds.get("relative_tolerance",.15) else "failed",measurements={"observed_speed_ratio":observed,"relative_error":relative_error})
    elif feature=="word_timestamps" and need("predicted_ms","reference_ms","reference_human_verified"):
        a,b=evidence["predicted_ms"],evidence["reference_ms"]
        if evidence["reference_human_verified"] and a and len(a)==len(b):
            errors=[abs(x-y) for x,y in zip(a,b)]
            result.update(status="passed" if max(errors)<=thresholds.get("max_error_ms",50) else "failed",measurements={"max_boundary_error_ms":max(errors),"boundary_count":len(errors)})
    elif feature in {"pronunciation_dictionary","ssml","emotion","voice_cloning","cross_language_voice","indian_accent"}:
        if need("review_artifact","native_review_verified","effect_observed","content_preserved") and evidence["native_review_verified"]:
            result.update(status="passed" if evidence["effect_observed"] and evidence["content_preserved"] else "failed",measurements={"review_artifact":evidence["review_artifact"]})
        else:
            result["reason"]="Requires auditable language-qualified listening/alignment evidence; parameter acceptance is insufficient"
    if result["status"]=="inconclusive" and result["reason"] is None:
        result["reason"]="Missing required observation or insufficient fixture"
    result["evidence_trust"]="Caller-supplied observations; hashes and independent review required for attestation"
    return result
