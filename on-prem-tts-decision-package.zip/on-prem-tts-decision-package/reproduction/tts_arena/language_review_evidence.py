"""Independent integrity check for the published blinded language-review package."""
import hashlib
import json
from pathlib import Path


def verify(root, study_id=None):
    root = Path(root)
    pointer_path = root / 'artifacts/listening/current-language-study.json'
    if study_id is None:
        pointer = json.loads(pointer_path.read_text()) if pointer_path.exists() else None
        study_id = pointer['study_id'] if pointer else 'indic-language-02c80dcdde9f'
    else:
        pointer = None
    package = root / 'artifacts/listening' / study_id
    original = package / 'public'
    published = root / 'ui/public/review' / study_id
    status = json.loads((package / 'package-status.json').read_text())
    audit = json.loads((package / 'publish-audit.json').read_text())
    mapping = json.loads((package / 'public-private-key.json').read_text())
    items = json.loads((original / 'items.json').read_text())
    if status['study_id'] != audit['study_id'] or status['study_id'] != study_id:
        raise ValueError('Language-review study identity differs')
    if pointer and (pointer.get('schema') != 'current_indic_language_review_v1' or
                    pointer.get('source_inventory_sha256') != status['source_inventory_sha256']):
        raise ValueError('Current language-review pointer differs from source inventory')
    if status['ratings_created'] != audit['ratings_created'] or audit['ratings_created'] != 0:
        raise ValueError('Language-review ratings were invented')
    if status['native_reviewed_references'] != audit['native_reviewed_references'] or audit['native_reviewed_references'] != 0:
        raise ValueError('Language-review reference status differs')
    if len(items) != len(mapping) or len(items) != status['items'] or len(items) != audit['items']:
        raise ValueError('Language-review item count differs')
    if len({item['item_id'] for item in items}) != len(items):
        raise ValueError('Language-review public IDs duplicate')
    if set(mapping) != {item['item_id'] for item in items}:
        raise ValueError('Language-review private answer key differs')
    expected = {'index.html', 'items.json'} | {item['audio_file'] for item in items}
    if {entry.name for entry in original.iterdir()} != expected or {entry.name for entry in published.iterdir()} != expected:
        raise ValueError('Language-review public file inventory differs')
    if any(entry.is_symlink() or not entry.is_file() for folder in (original, published) for entry in folder.iterdir()):
        raise ValueError('Language-review public file is unsafe')
    source_audio = (root / 'ui/public/evidence/audio').resolve()
    cells = set()
    for item in items:
        token = item['item_id']
        if set(item) != {'item_id', 'audio_file', 'language', 'text', 'system', 'sample_stratum'}:
            raise ValueError('Language-review public metadata includes extra fields')
        if not item['system'].startswith('System ') or item['audio_file'] != token + '.wav':
            raise ValueError('Language-review item anonymity differs')
        private = mapping[token]
        if (private['language'], private['text'], private['sample_stratum']) != (
                item['language'], item['text'], item['sample_stratum']):
            raise ValueError('Language-review private/public sample metadata differs')
        source = Path(private['audio_file']).resolve()
        if not source.is_relative_to(source_audio) or not source.is_file():
            raise ValueError('Language-review source WAV is missing or unsafe')
        expected_hash = private['source_audio_sha256']
        raw = source.read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected_hash:
            raise ValueError('Language-review source WAV hash changed')
        if raw != (original / item['audio_file']).read_bytes() or raw != (published / item['audio_file']).read_bytes():
            raise ValueError('Language-review copied WAV differs from source')
        cells.add((private['provider'], private['language']))
    if len(cells) != status['vendor_locale_cells'] or len(cells) != audit['vendor_locale_cells']:
        raise ValueError('Language-review vendor-locale coverage differs')
    if audit['published_audio_hashes_verified'] != len(items) or audit['private_mapping_published'] is not False:
        raise ValueError('Language-review publication audit differs')
    for name, field in (('items.json', 'public_items_sha256'), ('index.html', 'public_page_sha256')):
        original_bytes = (original / name).read_bytes()
        if original_bytes != (published / name).read_bytes() or hashlib.sha256(original_bytes).hexdigest() != audit[field]:
            raise ValueError('Language-review published page or manifest changed')
    if audit['public_review_url'] != '/review/' + study_id + '/index.html':
        raise ValueError('Language-review public route differs')
    if pointer:
        snapshot = json.loads((root / 'ui/public/evidence/snapshot.json').read_text())
        access = {row['provider']: row['access_state'] for row in snapshot['access_audit']}
        eligible = set()
        locales = {'en-IN', 'hi-IN', 'bn-IN', 'mr-IN', 'te-IN', 'ta-IN', 'gu-IN', 'ur-IN', 'kn-IN', 'ml-IN'}
        for row in [*snapshot['runs'], *snapshot['local_runs']]:
            if ((row.get('audio_url') or '').startswith('/evidence/audio/') and row['audio_url'].endswith('.wav') and
                    row.get('text') and not any(char in row['text'] for char in '<>[]') and
                    row['language'] in locales and access[row['provider']] not in {'skipped_by_user', 'deferred_by_deployment_scope'}):
                eligible.add((row['run_id'], row['listening_audio_sha256']))
        for row in snapshot['maya_local_runs']:
            if ((row.get('audio_url') or '').startswith('/evidence/audio/') and row['audio_url'].endswith('.wav') and
                    row.get('text') and not any(char in row['text'] for char in '<>[]') and row['language'] in locales and
                    access['maya'] not in {'skipped_by_user', 'deferred_by_deployment_scope'}):
                eligible.add(('maya:' + row['model'] + ':' + row['audio_sha256'], row['audio_sha256']))
        for row in snapshot.get('studio_audio_runs', []):
            if ((row.get('audio_url') or '').startswith('/evidence/audio/') and row['audio_url'].endswith('.wav') and
                    row.get('text') and not any(char in row['text'] for char in '<>[]') and row['language'] in locales and
                    access[row['provider']] not in {'skipped_by_user', 'deferred_by_deployment_scope'}):
                eligible.add(('studio:' + row['provider'] + ':' + row['language'] + ':' + row['audio_sha256'],
                              row['audio_sha256']))
        packaged = {(item['source_record_id'], item['source_audio_sha256']) for item in mapping.values()}
        if packaged != eligible:
            raise ValueError('Current language review omitted or invented saved audio')
    return audit
