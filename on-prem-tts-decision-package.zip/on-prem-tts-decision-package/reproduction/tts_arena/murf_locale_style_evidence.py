"""Recompute Falcon 2 style eligibility from the saved authenticated voice response."""
import hashlib
import json
from pathlib import Path

LOCALES = ('en-IN', 'hi-IN', 'bn-IN', 'mr-IN', 'te-IN', 'ta-IN', 'gu-IN',
           'kn-IN', 'ml-IN', 'ur-IN')


def verify(root):
    folder = Path(root) / 'artifacts/murf-locale-style-discovery-20260916'
    report = json.loads((folder / 'report.json').read_text())
    raw = (folder / 'voices.json').read_bytes()
    if (report['provider'], report['model'], report['http_status'], report['synthesis_requests'],
        report['retries'], report['requested_locales'], report['raw_response_sha256']) != (
        'murf', 'falcon-2', 200, 0, 0, list(LOCALES), hashlib.sha256(raw).hexdigest()):
        raise ValueError('Murf voice catalog provenance changed')
    if report['endpoint'] != 'https://api.murf.ai/v1/speech/voices?model=falcon-2':
        raise ValueError('Murf voice catalog endpoint changed')
    voices = json.loads(raw)
    if not isinstance(voices, list) or len(voices) != report['voice_count'] or len(voices) > 300:
        raise ValueError('Murf raw voice catalog count changed')
    if len({v['voiceId'] for v in voices}) != len(voices):
        raise ValueError('Murf voice IDs are not unique')
    rows = {}
    for locale in LOCALES:
        choices = []
        for voice in voices:
            locale_info = (voice.get('supportedLocales') or {}).get(locale)
            if locale_info is None:
                continue
            styles = locale_info.get('availableStyles') or []
            if not isinstance(styles, list) or any(not isinstance(s, str) for s in styles):
                raise ValueError('Murf locale style list changed shape')
            choices.append({'voiceId': voice['voiceId'], 'styles': styles})
        rows[locale] = {'voice_count': len(choices),
                        'multi_style_voice_count': sum(len(c['styles']) > 1 for c in choices),
                        'distinct_styles': sorted({s for c in choices for s in c['styles']}),
                        'voices': choices}
    if rows != report['locale_styles']:
        raise ValueError('Murf saved locale style report differs from raw response')
    if rows['hi-IN']['voice_count'] != 28 or any(r['multi_style_voice_count'] for r in rows.values()):
        raise ValueError('Murf sampled Indic style eligibility changed')
    first = json.loads((Path(root) / 'artifacts/murf-hindi-style-discovery-20260916/report.json').read_text())
    if first['http_status'] != 200 or first['hindi_voice_count'] != rows['hi-IN']['voice_count'] or (
        {v['voiceId']: v['hindi_styles'] for v in first['hindi_styles']} !=
        {v['voiceId']: v['styles'] for v in rows['hi-IN']['voices']}):
        raise ValueError('Two bounded Murf Hindi catalog reads disagree')
    return {'provider': 'murf', 'model': 'falcon-2', 'status': 'authenticated_raw_catalog_verified',
            'observed_at': report['observed_at'], 'voice_count': len(voices),
            'raw_response_sha256': hashlib.sha256(raw).hexdigest(),
            'locales': {locale: {k: row[k] for k in ('voice_count', 'multi_style_voice_count',
                                                  'distinct_styles')} for locale, row in rows.items()},
            'control_scope': 'No requested locale has a Falcon 2 voice with more than one catalog-listed style; this does not test prompt steering or perceived emotion',
            'source': report['source'], 'synthesis_requests': 0,
            'catalog_get_requests': report['catalog_get_requests']}
