"""Native provider WebSocket protocol plugins."""
