"""Murf Falcon 2 input-stream WebSocket contract (documented WAV subset)."""
import base64
import json
from urllib.parse import urlencode

from tts_arena.contracts import UnsupportedFeature, WebSocketSpec
from tts_arena.adapters.murf import build_request


def build_session(config, env):
    if set(config) - {'model', 'voice', 'language', 'format', 'sample_rate', 'region',
                      'context_id', 'style', 'rate', 'pitch'}:
        raise UnsupportedFeature('Unknown Murf WebSocket config field')
    if config.get('region') != 'global':
        raise UnsupportedFeature('The documented WebSocket example uses the global router; regional WebSocket hosts need live qualification')
    if config.get('format') != 'WAV' or config.get('sample_rate') != 24000:
        raise UnsupportedFeature('Reviewed Murf WebSocket subset requires 24 kHz mono WAV')
    context = config.get('context_id', 'default')
    if not isinstance(context, str) or not context or len(context) > 128:
        raise ValueError('Bounded nonempty context_id required')
    http_config = {k: v for k, v in config.items() if k != 'context_id'}
    request = build_request('offline validation', http_config, env)
    voice = {'voiceId': config['voice'], 'locale': config['language']}
    for field in ('style', 'rate', 'pitch'):
        if field in config:
            voice[field] = config[field]
    query = urlencode({'api-key': request.headers['api-key'], 'model': 'falcon-2',
                       'sample_rate': 24000, 'channel_type': 'MONO', 'format': 'WAV'})
    return WebSocketSpec('wss://global.api.murf.ai/v1/speech/stream-input?' + query,
                         {}, [{'voice_config': voice}], 24000, 'wav_stream_chunks',
                         {'protocol': 'murf_falcon_2_input_stream',
                          'strict_terminal_contexts': True,
                          'auth_location': 'query_api_key; never publish the full URL',
                          'cancel_semantics': 'clear discards pending synthesis only; already generating audio can continue',
                          'buffer_parameters': {'min_buffer_size': [40, 160],
                                                'max_buffer_delay_in_ms': [0, 1000]},
                          'verification': 'not_live_verified'})


def encode_action(action, config):
    if not isinstance(action, dict) or set(action) - {'type', 'text', 'context_id', 'at_ms', 'end'}:
        raise UnsupportedFeature('Unknown Murf action field')
    kind = action.get('type')
    context = action.get('context_id', config.get('context_id', 'default'))
    if not isinstance(context, str) or not context or len(context) > 128:
        raise ValueError('Bounded nonempty context_id required')
    if kind == 'cancel':
        if set(action) & {'text', 'end'}:
            raise UnsupportedFeature('clear carries only context_id')
        return [{'context_id': context, 'clear': True}]
    if kind != 'text':
        raise UnsupportedFeature('Murf input stream requires text with explicit end; no empty-text flush substitution')
    text = action.get('text')
    if not isinstance(text, str) or not text.strip() or len(text) > 5000:
        raise ValueError('Bounded nonempty Murf text required')
    end = action.get('end')
    if type(end) is not bool:
        raise ValueError('Murf text requires explicit boolean end')
    message = {'context_id': context, 'text': text, 'end': end}
    return [message]


def decode_message(raw):
    if not isinstance(raw, str) or len(raw) > 2_000_000:
        raise ValueError('Bounded Murf JSON text frame required')
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError('Murf response object required')
    context = data.get('context_id', 'default')
    if not isinstance(context, str) or not context or len(context) > 128:
        raise ValueError('Invalid Murf response context_id')
    if data.get('error') or (type(data.get('status_code')) is int and data['status_code'] >= 400):
        return [{'type': 'error', 'context_id': context,
                 'metadata': {'status_code': data.get('status_code'), 'message': str(data.get('error'))[:300]}}]
    events = []
    if 'audio' in data:
        encoded = data['audio']
        if not isinstance(encoded, str):
            raise ValueError('Murf audio must be base64 text')
        audio = base64.b64decode(encoded, validate=True)
        if audio:
            events.append({'type': 'audio', 'context_id': context, 'audio': audio})
    if 'final' in data and type(data['final']) is not bool:
        raise ValueError('Murf final must be boolean')
    if data.get('final'):
        events.append({'type': 'done', 'context_id': context, 'metadata': {'final': True}})
    if not events:
        events.append({'type': 'metadata', 'context_id': context,
                       'metadata': {k: v for k, v in data.items() if k not in {'audio', 'error'}}})
    return events
