"""Complete-text Lightning WS request with opt-in word events; no inferred cancellation."""
import base64,json,math
from tts_arena.adapters.smallest import build_request
from tts_arena.contracts import WebSocketSpec,UnsupportedFeature

def payload(text,config,env):
    cfg=dict(config);timed=cfg.pop('word_timestamps',False)
    if type(timed) is not bool:raise ValueError('word_timestamps must be boolean')
    if cfg.get('format')!='pcm':raise UnsupportedFeature('Reviewed WS subset requires raw PCM')
    if timed and (cfg.get('voice') not in {'meher','devansh','kartik','maithili','liam','avery'} or cfg.get('language') not in {'hi-IN','en-IN'}):raise UnsupportedFeature('Word events only on reviewed Hindi/English base voices; other families silently omit them')
    spec=build_request(text,cfg,env);body=dict(spec.body)
    if 'word_timestamps' in config:body['word_timestamps']=timed
    return spec,body

def build_session(config,env):
    spec,_=payload('validation',config,env)
    return WebSocketSpec('wss://api.smallest.ai/waves/v1/tts/live',spec.headers,[],spec.sample_rate,'pcm_s16le',{'single_request_only':True,'strict_terminal_contexts':True,'require_open_turn':True,'text_input_streaming':False,'word_timestamp_units':'seconds','cancel_semantics':'not_implemented','verification':'not_live_verified'})

def encode_action(action,config):
    if not isinstance(action,dict) or set(action)-{'type','text','at_ms','context_id'}:raise UnsupportedFeature('Unknown Smallest action fields')
    if action.get('type')!='text' or action.get('context_id','default')!='default':raise UnsupportedFeature('Only one complete-text request; no continuation/flush/cancel claim')
    return [payload(action.get('text'),config,{'SMALLEST_API_KEY':'validation-only'})[1]]

def decode_message(message):
    if not isinstance(message,str):raise ValueError('Expected JSON text frame')
    value=json.loads(message)
    if not isinstance(value,dict):raise ValueError('Expected response object')
    status=value.get('status')
    if status=='error':return [{'type':'error','context_id':'default','message':value.get('message','Provider error'),'metadata':{'status':status}}]
    if status=='complete':return [{'type':'done','context_id':'default','metadata':{'status':status,'request_id':value.get('request_id')}}]
    if status=='chunk':
        data=value.get('data')
        if not isinstance(data,dict) or not isinstance(data.get('audio'),str):raise ValueError('Chunk requires base64 audio')
        audio=base64.b64decode(data['audio'],validate=True)
        return [{'type':'audio','context_id':'default','audio':audio}] if audio else []
    if status=='word_timestamp':
        data=value.get('data')
        if not isinstance(data,dict) or type(data.get('id')) is not int or data['id']<0 or not isinstance(data.get('word'),str) or not data['word']:raise ValueError('Invalid word identity')
        for field in ('start','end'):
            if type(data.get(field)) not in (int,float) or not math.isfinite(data[field]) or data[field]<0:raise ValueError('Invalid word time')
        if data['end']<data['start']:raise ValueError('Reversed word time')
        return [{'type':'metadata','context_id':'default','metadata':{'status':status,'word_timestamp':data,'time_unit':'seconds','time_origin':'request_audio_start','request_id':value.get('request_id')}}]
    if status is None and value.get('type')!='pong':raise ValueError('Missing response status')
    return [{'type':'metadata','context_id':'default','metadata':{'uninterpreted_control':value}}]
