"""ElevenLabs TTS multi-context protocol; no claim of immediate cancellation."""
import base64
import json
from urllib.parse import quote, urlencode
from tts_arena.contracts import WebSocketSpec, UnsupportedFeature
from tts_arena.adapters._global_common import check, choice, nonempty, boolean, number, key

_FORMATS = {'pcm_16000': (16000, 'pcm_s16le'), 'pcm_24000': (24000, 'pcm_s16le'), 'ulaw_8000': (8000, 'mulaw'), 'mp3_44100_128': (44100, 'mp3')}

def _validate(config):
    if config.get("model") in {"eleven_v3", "eleven_v3_conversational"}:
        return _validate_dialogue(config)
    check('validation', config, {'model','voice','language','format','context_id','sync_alignment','auto_mode','inactivity_timeout','enable_logging','apply_text_normalization','seed','enable_ssml_parsing'}, {'model','voice','language','format'})
    choice(config['model'], {'eleven_flash_v2_5','eleven_turbo_v2_5'}, 'WS model subset (v3 uses different endpoint; multilingual_v2 does not enforce language)')
    choice(config['language'], {'en-IN','hi-IN','ta-IN'}, 'language')
    choice(config['format'], _FORMATS, 'format')
    nonempty(config['voice'], 'voice')
    nonempty(config.get('context_id','default'), 'context_id')
    for name in ('sync_alignment','auto_mode','enable_logging','enable_ssml_parsing'):
        if name in config: boolean(config[name],name)
    if 'inactivity_timeout' in config: number(config['inactivity_timeout'],1,180,'inactivity_timeout',True)
    if 'seed' in config: number(config['seed'],0,4294967295,'seed',True)
    if 'apply_text_normalization' in config: choice(config['apply_text_normalization'], {'auto','on','off'}, 'normalization')

def build_session(config, env):
    _validate(config)
    if config["model"].startswith("eleven_v3"):
        return _build_dialogue(config,env)
    query={'model_id':config['model'],'language_code':config['language'].split('-')[0],'output_format':config['format']}
    for n in ('sync_alignment','auto_mode','inactivity_timeout','enable_logging','apply_text_normalization','seed','enable_ssml_parsing'):
        if n in config: query[n]=str(config[n]).lower() if isinstance(config[n],bool) else config[n]
    sr,encoding=_FORMATS[config['format']]
    return WebSocketSpec('wss://api.elevenlabs.io/v1/text-to-speech/'+quote(config['voice'],safe='')+'/multi-stream-input?'+urlencode(query), {'xi-api-key':key(env,'ELEVENLABS_API_KEY')}, [], sr, encoding,
        {'verification':'not_live_verified','protocol':'tts_multi_context','cancel_semantics':'close_context; already-flushing audio continues','max_contexts':5,'context_reuse':'after close a reused ID is a new unrelated context','timestamps_origin':'audio_chunk','timestamps_unit':'milliseconds'})

def encode_action(action, config):
    _validate(config)
    if config["model"].startswith("eleven_v3"):
        return _encode_dialogue(action,config)
    if set(action)-{'type','text','context_id','at_ms'}: raise UnsupportedFeature('Unknown session action field')
    kind=action.get('type'); choice(kind, {'text','flush','cancel','end_input'}, 'action')
    ctx=action.get('context_id',config.get('context_id','default')); nonempty(ctx,'context_id')
    if kind=='text':
        nonempty(action.get('text'),'text')
        # Vendor requires a trailing space. Reject rather than mutate transcript/cost.
        if not action['text'].endswith(' '): raise ValueError('ElevenLabs streamed text must end with a space')
        return [{'context_id':ctx,'text':action['text']}]
    if 'text' in action: raise UnsupportedFeature('text is only accepted on text actions')
    if kind=='flush': return [{'context_id':ctx,'flush':True}]
    if kind=='cancel': return [{'context_id':ctx,'close_context':True}]
    return [{'context_id':ctx,'flush':True},{'context_id':ctx,'close_context':True}]

def decode_message(message):
    data=json.loads(message)
    if not isinstance(data,dict): raise ValueError('Expected JSON object')
    ctx=data.get('contextId',data.get('context_id'))
    if 'contextId' in data and 'context_id' in data and data['contextId']!=data['context_id']: raise ValueError('Conflicting context identifiers')
    events=[]
    if data.get('is_final_audio_for_turn') is True:
        events.append({'type':'turn_done','context_id':ctx,'metadata':{'provider_turn_final':True}})
    if 'error' in data or data.get('type')=='error': return [{'type':'error','context_id':ctx,'metadata':data}]
    if data.get('audio') is not None:
        events.append({'type':'audio','context_id':ctx,'audio':base64.b64decode(data['audio'],validate=True)})
    for field in ('alignment','normalizedAlignment','normalized_alignment'):
        if data.get(field) is not None:
            a=data[field]
            if isinstance(a,dict) and 'char_start_times_ms' in a:
                a={'chars':a.get('chars'),'charStartTimesMs':a.get('char_start_times_ms'),'charDurationsMs':a.get('char_durations_ms')}
            if not isinstance(a,dict) or not all(isinstance(a.get(n),list) for n in ('chars','charStartTimesMs','charDurationsMs')) or len({len(a[n]) for n in ('chars','charStartTimesMs','charDurationsMs')})!=1: raise ValueError('Malformed character alignment')
            events.append({'type':'timestamps','context_id':ctx,'metadata':{'kind':field,'unit':'milliseconds','origin':'audio_chunk','alignment':a}})
    if data.get('isFinal') is True or data.get('is_final') is True: events.append({'type':'done','context_id':ctx,'metadata':{'provider_final':True}})
    return events or [{'type':'metadata','context_id':ctx,'metadata':data}]


def _validate_dialogue(config):
    check('validation',config,{'model','voice','language','format','context_id','contexts','sync_alignment','apply_text_normalization','seed','enable_logging'}, {'model','voice','language','format','contexts'})
    choice(config['model'],{'eleven_v3','eleven_v3_conversational'},'dialogue model')
    nonempty(config['voice'],'voice'); choice(config['language'],{'hi-IN','en-IN','ta-IN'},'language');choice(config['format'],_FORMATS,'format')
    contexts=config['contexts']
    if not isinstance(contexts,list) or not 1<=len(contexts)<=5 or any(not isinstance(x,str) or not x.strip() for x in contexts) or len(set(contexts))!=len(contexts):
        raise ValueError('contexts must contain 1-5 unique nonempty context IDs')
    if config.get('context_id','default') not in contexts: raise ValueError('context_id must be registered')
    for name in ('sync_alignment','enable_logging'):
        if name in config: boolean(config[name],name)
    if 'seed' in config:number(config['seed'],0,4294967295,'seed',True)
    if 'apply_text_normalization' in config:choice(config['apply_text_normalization'],{'auto','on','off'},'normalization')


def _build_dialogue(config,env):
    query={'model_id':config['model'],'language_code':config['language'].split('-')[0],'output_format':config['format']}
    for n in ('sync_alignment','apply_text_normalization','seed','enable_logging'):
        if n in config:query[n]=str(config[n]).lower() if isinstance(config[n],bool) else config[n]
    sr,encoding=_FORMATS[config['format']]
    return WebSocketSpec('wss://api.elevenlabs.io/v1/text-to-dialogue/multi-stream-input?'+urlencode(query),{'xi-api-key':key(env,'ELEVENLABS_API_KEY')},[{'context_id':ctx,'voices':[config['voice']]} for ctx in config['contexts']],sr,encoding,{'protocol':'v3_dialogue_multi_context','verification':'not_live_verified','cancel_semantics':'unsupported; close_context flushes remaining audio','strict_terminal_contexts':True,'registered_context_ids':list(config['contexts']),'context_reuse':'separate pre-registered context IDs on one connection','max_contexts':5})


def _encode_dialogue(action,config):
    if set(action)-{'type','text','context_id','at_ms'}:raise UnsupportedFeature('Unknown dialogue session action field')
    kind=action.get('type')
    if kind=='cancel':raise UnsupportedFeature('v3 dialogue close_context FLUSHES remaining audio; no discard cancellation in documented contract')
    choice(kind,{'text','flush','end_input'},'dialogue action')
    ctx=action.get('context_id',config.get('context_id','default'))
    if ctx not in config['contexts']:raise ValueError('Action context must be pre-registered')
    if kind=='text':
        nonempty(action.get('text'),'text')
        return [{'context_id':ctx,'inputs':[{'text':action['text'],'voice_id':config['voice']}]}]
    if 'text' in action:raise UnsupportedFeature('text is only accepted on text actions')
    return [{'context_id':ctx,'flush' if kind=='flush' else 'close_context':True}]
