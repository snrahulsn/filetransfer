"""Fonada V1 one-request WebSocket, pinned to official SDK 2.2.3.

The documentation's input/voice table conflicts with SDK text/voice_id.
An explicit profile is therefore required; this is not live certification.
"""
import json

from tts_arena.contracts import UnsupportedFeature, WebSocketSpec

_LANGUAGES = {"hi-IN": "Hindi", "en-IN": "English", "ta-IN": "Tamil", "te-IN": "Telugu"}


def build_session(config, env):
    allowed = {"model", "voice", "language", "format", "sample_rate", "initial_text", "protocol_profile"}
    unknown = set(config) - allowed
    if unknown:
        raise UnsupportedFeature("Unimplemented Fonada WS fields: " + ", ".join(sorted(unknown)))
    if config.get("model") != "fonada-v1":
        raise UnsupportedFeature("Only Fonada V1 WS is documented; Klone uses a separate HTTP contract")
    if config.get("protocol_profile") != "sdk-2.2.3":
        raise UnsupportedFeature("Explicit protocol_profile=sdk-2.2.3 required because vendor docs and SDK field names conflict")
    if config.get("format") != "pcm_s16le" or config.get("sample_rate") != 24000:
        raise ValueError("Current Fonada V1 WS output is raw pcm_s16le, 24000 Hz mono")
    language = config.get("language")
    if language not in _LANGUAGES:
        raise UnsupportedFeature("Fonada V1 covers Hindi, English, Tamil and Telugu only")
    voice = config.get("voice")
    if not isinstance(voice, str) or not voice.strip():
        raise ValueError("An explicit catalog voice name is required")
    text = config.get("initial_text")
    if not isinstance(text, str) or not text.strip() or len(text) > 450:
        raise ValueError("initial_text must contain 1..450 characters")
    key = env.get("FONADA_API_KEY")
    if not isinstance(key, str) or not key or "\r" in key or "\n" in key:
        raise ValueError("FONADA_API_KEY is required")
    return WebSocketSpec(
        url="wss://api.fonada.ai/tts/generate-audio-ws",
        initial_messages=[{
            "api_key": key,
            "text": text,
            "voice_id": voice,
            "language": _LANGUAGES[language],
        }],
        sample_rate=24000,
        encoding="pcm_s16le",
        metadata={
            "protocol_profile": "sdk-2.2.3",
            "one_request_per_session": True,
            "text_input_streaming": False,
            "native_cancel_verified": False,
            "credential_fields": ["api_key"],
            "spec_discrepancy": "SDK text/voice_id versus docs input/voice; live acceptance unverified",
        },
    )


def encode_action(action, config):
    """No incremental-input or stream-control action exists in the inspected protocol."""
    if not isinstance(action, dict) or not isinstance(action.get("type"), str):
        raise ValueError("Action must have a string type")
    raise UnsupportedFeature(
        "Fonada V1 SDK defines one initial authenticated request only; "
        + action["type"] + " is not a documented in-session operation. "
        "Socket closure is not a native cancellation acknowledgement."
    )


def decode_message(message):
    """Preserve PCM bytes exactly, including fragments splitting sample boundaries."""
    if isinstance(message, bytes):
        if not message:
            return []
        return [{"type": "audio", "audio": message, "context_id": None}]
    if not isinstance(message, str):
        raise ValueError("WebSocket message must be str or bytes")
    try:
        data = json.loads(message)
    except json.JSONDecodeError:
        return [{"type": "error", "code": "invalid_json", "message": "Malformed Fonada WS text frame"}]
    if not isinstance(data, dict):
        return [{"type": "error", "code": "invalid_event", "message": "Fonada WS text frame must be a JSON object"}]
    status, msg_type = data.get("status"), data.get("type")
    # Error takes precedence if inconsistent status/type fields occur.
    if status == "error" or msg_type == "error":
        return [{"type": "error", "code": data.get("error", "provider_error"),
                 "message": data.get("message", "Fonada synthesis failed"),
                 "metadata": {"details": data.get("details")}}]
    if status == "complete" or msg_type == "complete":
        return [{"type": "done", "context_id": None, "metadata": {"stats": data.get("stats", {})}}]
    if status == "streaming" or msg_type == "status":
        return [{"type": "status", "metadata": {"status": status, "request_id": data.get("request_id")}}]
    return [{"type": "error", "code": "unknown_event", "message": "Unrecognized Fonada WS control frame"}]
