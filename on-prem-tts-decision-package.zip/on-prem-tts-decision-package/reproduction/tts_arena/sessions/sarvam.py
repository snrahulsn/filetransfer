"""Sarvam Bulbul v3 native WebSocket; flush ends input, no in-band cancellation."""
import base64
import json
import math

from tts_arena.contracts import UnsupportedFeature, WebSocketSpec

LOCALES = {'bn-IN', 'en-IN', 'gu-IN', 'hi-IN', 'kn-IN', 'ml-IN',
           'mr-IN', 'od-IN', 'pa-IN', 'ta-IN', 'te-IN'}
V3_SPEAKERS = {'shubh', 'aditya', 'ritu', 'priya', 'neha', 'rahul',
               'pooja', 'rohan', 'simran', 'kavya', 'amit', 'dev',
               'ishita', 'shreya', 'ratan', 'varun', 'manan', 'sumit',
               'roopa', 'kabir', 'aayan', 'ashutosh', 'advait', 'anand',
               'tanya', 'tarun', 'sunny', 'mani', 'gokul', 'vijay',
               'shruti', 'suhani', 'mohit', 'kavitha', 'rehan', 'soham',
               'rupali'}


def build_session(config, env):
    if not isinstance(config, dict) or set(config) - {
        'model', 'language', 'speaker', 'format', 'sample_rate', 'pace',
        'temperature', 'min_buffer_size', 'max_chunk_length', 'dict_id'}:
        raise UnsupportedFeature('Unknown Sarvam streaming setting')
    if config.get('model') != 'bulbul:v3':
        raise UnsupportedFeature('Streaming profile pins Bulbul v3; no model fallback')
    language = config.get('language')
    if language not in LOCALES:
        raise UnsupportedFeature('No documented Bulbul v3 WebSocket locale')
    speaker = config.get('speaker', 'shubh')
    if speaker not in V3_SPEAKERS:
        raise UnsupportedFeature('Speaker is not in the official Bulbul v3 set')
    if config.get('format', 'mp3') != 'mp3':
        raise UnsupportedFeature('Official current streaming codec text only confirms MP3')
    if config.get('sample_rate', 24000) != 24000:
        raise UnsupportedFeature('Pinned Bulbul v3 streaming output at 24 kHz')
    key = env.get('SARVAM_API_KEY') if isinstance(env, dict) else None
    if not isinstance(key, str) or not key:
        raise ValueError('Sarvam evaluation key required')
    data = {'language_code': language, 'speaker': speaker,
            'speech_sample_rate': '24000', 'output_audio_codec': 'mp3'}
    for name, low, high in (('pace', .5, 2), ('temperature', .01, 1)):
        value = config.get(name)
        if value is not None:
            if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
                raise ValueError(f'Bulbul v3 {name} outside documented range')
            data[name] = value
    for name, low, high in (('min_buffer_size', 30, 200),
                            ('max_chunk_length', 50, 500)):
        value = config.get(name)
        if value is not None:
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f'Bulbul v3 {name} outside documented range')
            data[name] = value
    if 'dict_id' in config:
        if not isinstance(config['dict_id'], str) or not config['dict_id']:
            raise ValueError('Pronunciation dictionary ID must be nonempty')
        data['dict_id'] = config['dict_id']
    return WebSocketSpec(
        'wss://api.sarvam.ai/text-to-speech/ws?model=bulbul%3Av3&send_completion_event=true',
        {'Api-Subscription-Key': key}, [{'type': 'config', 'data': data}],
        24000, 'mp3', {'protocol': 'sarvam_bulbul_v3_json',
                        'wire_encoding': 'JSON with base64 MP3 audio',
                        'strict_terminal_contexts': True,
                        'cancel_semantics': 'unsupported; clear local receiver then close socket and reconnect',
                        'connection_reuse': 'vendor documents multiple conversions per open socket; current generic capture uses one completed turn',
                        'verification': 'not_live_verified'})


def encode_action(action, config):
    if not isinstance(action, dict) or set(action) - {'type', 'text', 'at_ms', 'context_id'}:
        raise UnsupportedFeature('Unknown Sarvam action field')
    if action.get('context_id', 'default') != 'default':
        raise UnsupportedFeature('Sarvam completion event has no context ID')
    kind = action.get('type')
    if kind == 'text':
        text = action.get('text')
        if not isinstance(text, str) or not 1 <= len(text) <= 2500 or not text.strip():
            raise ValueError('Sarvam text must be 1..2500 nonblank characters')
        return [{'type': 'text', 'data': {'text': text}}]
    if 'text' in action:
        raise UnsupportedFeature('Text field allowed only for text actions')
    if kind == 'flush':
        return [{'type': 'flush'}]
    if kind == 'ping':
        return [{'type': 'ping'}]
    if kind == 'cancel':
        raise UnsupportedFeature('Sarvam has no server-side cancel; close and reconnect')
    raise UnsupportedFeature('Unknown Sarvam WebSocket action')


def decode_message(raw):
    if not isinstance(raw, str) or len(raw) > 2_000_000:
        raise ValueError('Sarvam WebSocket expects bounded JSON text')
    message = json.loads(raw)
    if not isinstance(message, dict) or not isinstance(message.get('data'), dict):
        raise ValueError('Sarvam event envelope required')
    kind, data = message.get('type'), message['data']
    if kind == 'audio':
        content = data.get('audio')
        if not isinstance(content, str) or not content:
            raise ValueError('Sarvam audio requires base64 payload')
        payload = base64.b64decode(content, validate=True)
        if not payload:
            raise ValueError('Sarvam audio payload empty')
        content_type = data.get('content_type')
        if content_type not in {'audio/mp3', 'audio/mpeg'}:
            raise ValueError('Captured Sarvam stream is not confirmed MP3')
        return [{'type': 'audio', 'context_id': 'default', 'audio': payload}]
    if kind == 'event':
        if data.get('event_type') != 'final':
            raise ValueError('Unknown Sarvam terminal event')
        return [{'type': 'done', 'context_id': 'default',
                 'metadata': {'event_type': 'final'}}]
    if kind == 'error':
        return [{'type': 'error', 'context_id': 'default',
                 'metadata': {'provider_code': data.get('code')}}]
    raise ValueError('Unexpected Sarvam WebSocket event')
