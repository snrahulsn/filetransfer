"""Sequential complete-text WS requests. No incremental utterance, flush or cancel inference."""
import base64
import json
from tts_arena.contracts import WebSocketSpec, UnsupportedFeature
from tts_arena.adapters.voicemaker import _payload
from tts_arena.adapters._global_common import key


def build_session(config, env):
    _payload("validation", config, websocket=True)
    return WebSocketSpec("wss://developer.voicemaker.in/api/v1/voice/convert",
        {"Authorization": "Bearer " + key(env, "VOICEMAKER_API_KEY")}, [], config["sample_rate"], config["format"],
        {"verification": "not_live_verified", "text_input_streaming": False, "single_request_only": True,
         "request_correlation": "sequential_only; no request IDs in documented protocol",
         "reuse": "vendor documents sequential messages; runner limited to one request until final-gated correlation exists",
         "native_cancel_verified": False})


def encode_action(action, config):
    if not isinstance(action, dict):
        raise ValueError("action must be an object")
    if set(action) - {"type", "text", "at_ms"}:
        raise UnsupportedFeature("Unknown session action fields")
    if action.get("type") != "text":
        raise UnsupportedFeature("Only complete-text messages documented; flush/cancel/end_input are not native operations")
    return [_payload(action.get("text"), config, websocket=True)]


def decode_message(message):
    if not isinstance(message, str):
        raise ValueError("Voicemaker WS expects JSON text, not binary frames")
    data = json.loads(message)
    if not isinstance(data, dict) or type(data.get("success")) is not bool:
        raise ValueError("Expected object with boolean success")
    if data["success"] is False:
        return [{"type": "error", "code": "provider_error", "message": data.get("message", "Synthesis failed"), "metadata": {"errors": data.get("errors")}}]
    if "isFinal" in data and type(data["isFinal"]) is not bool:
        raise ValueError("isFinal must be boolean")
    out = []
    if "audio" in data:
        if not isinstance(data["audio"], str):
            raise ValueError("audio must be base64 string")
        audio = base64.b64decode(data["audio"], validate=True)
        if audio:
            out.append({"type": "audio", "audio": audio, "context_id": None})
    elif not data.get("isFinal", False):
        raise ValueError("Missing audio in nonfinal event")
    if data.get("isFinal", False):
        out.append({"type": "done", "context_id": None})
    return out
