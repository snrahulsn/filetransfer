"""Maya Calyx WebSocket v2, official llm.txt accessed 2026-09-15."""
import base64
import json
from tts_arena.contracts import WebSocketSpec, UnsupportedFeature
from tts_arena.adapters.maya import build_request


def build_session(config, env):
    req = build_request("validation", config, env)
    if req.sample_rate != 24000 or req.encoding != "pcm_s16le":
        raise UnsupportedFeature("Maya WS profile requires 24 kHz PCM16 mono")
    allowed = {"model", "voice", "language", "format", "sample_rate"}
    if set(config) - allowed:
        raise UnsupportedFeature("Maya WS supports only sticky model, voice and language")
    start = {"type": "start", "v2": True, "model": req.body["model"], "voice": req.body["voice"]}
    if "language" in req.body: start["language"] = req.body["language"]
    return WebSocketSpec("wss://tts.mayaresearch.ai/v1/tts/stream",
        {"Authorization": req.headers["Authorization"]}, [start], 24000, "pcm_s16le",
        {"handshake_event": "metadata", "strict_terminal_contexts": True,
         "require_open_turn": True, "cancel_after_end_input": True, "verification": "not_live_verified",
         "protocol": "maya_v2", "cancel_semantics": "turn cancel; local playback must be muted separately"})


def encode_action(action, config):
    if set(action) - {"type", "context_id", "text", "at_ms"}:
        raise UnsupportedFeature("Unknown Maya action field")
    kind = action.get("type")
    if kind not in {"text", "end_input", "cancel", "ping"}:
        raise UnsupportedFeature("Maya v2 has no standalone flush; use end_input to close a turn")
    if kind == "ping":
        if set(action) - {"type", "at_ms"}: raise UnsupportedFeature("ping accepts no text or context")
        return [{"type": "ping"}]
    ctx = action.get("context_id")
    if not isinstance(ctx, str) or not ctx.strip(): raise ValueError("Explicit nonempty context_id required")
    if kind in {"text", "end_input"}:
        text = action.get("text", "")
        if not isinstance(text, str) or (kind == "text" and not text.strip()): raise ValueError("Nonempty text required")
        return [{"type": "text", "context_id": ctx, "text": text, "continue": kind == "text"}]
    if "text" in action: raise UnsupportedFeature("cancel has no text")
    return [{"type": "cancel", "context_id": ctx}]


def decode_message(message):
    data = json.loads(message)
    if not isinstance(data, dict): raise ValueError("Expected JSON object")
    kind = data.get("type")
    if kind == "error": return [{"type": "error", "context_id": data.get("context_id")}]
    if kind == "metadata":
        if type(data.get("sample_rate")) is not int or data["sample_rate"] != 24000 or type(data.get("channels")) is not int or data["channels"] != 1 or data.get("encoding") != "pcm_s16le":
            raise ValueError("Maya handshake does not match 24 kHz PCM16 mono profile")
        sid = data.get("session_id")
        if not isinstance(sid, str) or not sid.strip(): raise ValueError("Missing Maya session_id")
        return [{"type": "metadata", "sample_rate": 24000, "channels": 1, "encoding": "pcm_s16le", "session_id": sid}]
    if kind == "pong": return [{"type": "pong"}]
    if kind not in {"audio", "end", "cancelled"}: raise ValueError("Unknown Maya server message")
    ctx = data.get("context_id")
    if not isinstance(ctx, str) or not ctx.strip(): raise ValueError("Missing context_id")
    if kind == "audio":
        audio = base64.b64decode(data["audio"], validate=True)
        if len(audio) % 2: raise ValueError("Incomplete PCM16 frame")
        return [{"type": "audio", "audio": audio, "context_id": ctx}]
    return [{"type": "done" if kind == "end" else "cancelled", "context_id": ctx}]
