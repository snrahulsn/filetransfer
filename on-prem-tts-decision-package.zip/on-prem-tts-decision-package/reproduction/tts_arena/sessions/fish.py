"""Fish S2.1 native MessagePack protocol; stop drains audio, never cancels it."""
import math
import msgpack
from tts_arena.adapters.fish import build_request as http_request
from tts_arena.adapters._global_common import key
from tts_arena.contracts import UnsupportedFeature,WebSocketSpec

def build_session(config,env):
    timed=config.get('timestamp_mode',False)
    if type(timed) is not bool:raise ValueError('timestamp_mode must be boolean')
    if config.get('model') not in {'s2.1-pro','s2.1-pro-free'}:raise UnsupportedFeature('Current S2.1 family only; no server model fallback')
    if config.get('format')!='pcm':raise UnsupportedFeature('Native Fish reviewed subset requires PCM')
    key(env,'FISH_API_KEY')
    cfg={k:v for k,v in config.items() if k!='timestamp_mode'}
    spec=http_request('validation',cfg,env)
    body=dict(spec.body);body['text']=''
    url='wss://api.fish.audio/v1/tts/live/with-timestamp' if timed else 'wss://api.fish.audio/v1/tts/live'
    return WebSocketSpec(url,{'Authorization':spec.headers['Authorization'],'model':config['model']},
       [{'event':'start','request':body}],spec.sample_rate,'pcm_s16le',
       {'protocol':'fish_tts_msgpack','wire_encoding':'MessagePack binary','strict_terminal_contexts':True,'require_open_turn':True,
        'cancel_semantics':'unsupported; stop drains remaining buffered text then finish','connection_reuse':'one synthesis session per socket; no new start or multi-context reuse',
        'language_control':'automatic; evaluation locale not enforced','timestamp_mode':timed,
        'timestamp_unit':'seconds','timestamp_origin':'audio_start; segment times local to text chunk',
        'verification':'not_live_verified'})

def encode_action(action,config):
    if not isinstance(action,dict) or set(action)-{'type','text','at_ms','context_id'}:raise UnsupportedFeature('Unknown Fish action field')
    if action.get('context_id','default')!='default':raise UnsupportedFeature('Fish protocol has no context IDs; only default local stream')
    kind=action.get('type')
    if kind=='cancel':raise UnsupportedFeature('No documented native discard/cancel; stop is end_input and drains audio')
    if kind=='text':
        text=action.get('text')
        if not isinstance(text,str) or not text.strip():raise ValueError('Nonempty exact streamed text required')
        return [{'event':'text','text':text}]
    if 'text' in action:raise UnsupportedFeature('Text allowed only on text actions')
    if kind=='flush':return [{'event':'flush'}]
    if kind=='end_input':return [{'event':'stop'}]
    raise UnsupportedFeature('Unknown Fish action')

def encode_message(message):
    if not isinstance(message,dict):raise ValueError('Fish wire event must be an object')
    return msgpack.packb(message,use_bin_type=True)

def decode_message(message):
    if not isinstance(message,bytes) or len(message)>2_000_000:raise ValueError('Fish requires bounded binary MessagePack frames')
    data=msgpack.unpackb(message,raw=False,strict_map_key=True,max_str_len=2_000_000,max_bin_len=2_000_000,max_array_len=1024,max_map_len=128,max_ext_len=0)
    if not isinstance(data,dict) or not isinstance(data.get('event'),str):raise ValueError('Fish event object required')
    event=data['event']
    if event=='audio':
        if not isinstance(data.get('audio'),bytes):raise ValueError('Audio must be MessagePack binary bytes')
        events=[{'type':'audio','context_id':'default','audio':data['audio']}] if data['audio'] else []
        if any(k in data for k in ('alignment','chunk_seq','chunk_audio_offset_sec')):
            if not all(k in data for k in ('alignment','chunk_seq','chunk_audio_offset_sec','content')):
                raise ValueError('Timestamp frame lacks required Fish fields')
            seq=data['chunk_seq'];offset=data['chunk_audio_offset_sec'];content=data['content']
            if type(seq) is not int or seq<0 or type(offset) not in (int,float) or not math.isfinite(offset) or offset<0 or not isinstance(content,str):
                raise ValueError('Invalid Fish text chunk identity or offset')
            alignment=data['alignment']
            if alignment is not None:
                if not isinstance(alignment,dict) or set(alignment)!={'segments','audio_duration'} or type(alignment['audio_duration']) not in (int,float) or not math.isfinite(alignment['audio_duration']) or alignment['audio_duration']<0:
                    raise ValueError('Malformed Fish alignment snapshot')
                segments=alignment['segments']
                if not isinstance(segments,list) or len(segments)>512:raise ValueError('Bounded Fish word segments required')
                for segment in segments:
                    if (not isinstance(segment,dict) or not all(k in segment for k in ('text','start','end')) or not isinstance(segment['text'],str)
                        or any(type(segment[k]) not in (int,float) or not math.isfinite(segment[k]) for k in ('start','end'))
                        or not 0<=segment['start']<=segment['end']):
                        raise ValueError('Malformed Fish word segment')
                events.append({'type':'timestamps','context_id':'default','metadata':{'kind':'word_segments',
                    'time_unit':'seconds','time_origin':'chunk_audio_start','chunk_seq':seq,
                    'chunk_audio_offset_sec':offset,'content':content,'alignment':alignment}})
        return events
    if event=='finish':
        if data.get('reason')=='error':return [{'type':'error','context_id':'default','metadata':{'event':'finish','reason':'error'}}]
        if data.get('reason')!='stop':raise ValueError('Invalid finish reason')
        return [{'type':'done','context_id':'default','metadata':{'event':'finish','reason':'stop'}}]
    # Unknown event types are intentionally ignored per official forward-compatibility guidance.
    return [{'type':'metadata','context_id':'default','metadata':{'ignored_unknown_event':event}}]
