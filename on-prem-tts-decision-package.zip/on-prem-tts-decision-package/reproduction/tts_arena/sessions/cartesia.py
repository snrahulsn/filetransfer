"""Cartesia 2026-08-14 WebSocket input streaming and queued-request cancellation."""
import base64
import json
from tts_arena.contracts import WebSocketSpec, UnsupportedFeature
from tts_arena.adapters.cartesia import build_request
from tts_arena.adapters._global_common import nonempty, boolean, number, choice

_WS={'context_id','add_timestamps','add_phoneme_timestamps','use_normalized_timestamps','max_buffer_delay_ms'}

def _body(config,env):
    http={k:v for k,v in config.items() if k not in _WS}
    if http.get('format')!='raw': raise UnsupportedFeature('Cartesia WS supports raw container only')
    req=build_request('validation',http,env)
    nonempty(config.get('context_id','default'),'context_id')
    for n in ('add_timestamps','add_phoneme_timestamps','use_normalized_timestamps'):
        if n in config: boolean(config[n],n)
    if 'max_buffer_delay_ms' in config: number(config['max_buffer_delay_ms'],0,5000,'max_buffer_delay_ms',True)
    body=dict(req.body); body.pop('transcript')
    for n in _WS-{'context_id'}:
        if n in config: body[n]=config[n]
    return req,body

def build_session(config,env):
    req,_=_body(config,env)
    return WebSocketSpec('wss://api.cartesia.ai/tts/websocket?cartesia_version=2026-08-14', {'X-API-Key':env['CARTESIA_API_KEY']}, [], req.sample_rate, req.encoding,
        {'verification':'not_live_verified','protocol':'cartesia_contexts','cancel_semantics':'queued_requests_only; actively generating request continues per context guide','context_reuse':'new IDs after done/cancel/expiry; live contexts expire 1 second after last audio','api_version':'2026-08-14'})

def encode_action(action,config):
    _,body=_body(config,{'CARTESIA_API_KEY':'offline-validation'})
    if set(action)-{'type','text','context_id','at_ms'}: raise UnsupportedFeature('Unknown session action field')
    kind=action.get('type');choice(kind,{'text','flush','cancel','end_input'},'action')
    ctx=action.get('context_id',config.get('context_id','default')); nonempty(ctx,'context_id')
    if kind!='text' and 'text' in action: raise UnsupportedFeature('text is only accepted on text actions')
    if kind=='cancel': return [{'context_id':ctx,'cancel':True}]
    transcript=action.get('text') if kind=='text' else ''
    if kind=='text': nonempty(transcript,'text')
    body.update({'context_id':ctx,'transcript':transcript,'continue':kind!='end_input'})
    if kind=='flush': body['flush']=True
    return [body]

def decode_message(message):
    data=json.loads(message)
    if not isinstance(data,dict): raise ValueError('Expected JSON object')
    kind=data.get('type');ctx=data.get('context_id')
    metadata={k:v for k,v in data.items() if k not in {'data','context_id','type'}}
    if kind=='error' or (isinstance(data.get('status_code'),int) and data['status_code']>=400): return [{'type':'error','context_id':ctx,'metadata':metadata}]
    if kind=='chunk': return [{'type':'audio','context_id':ctx,'audio':base64.b64decode(data['data'],validate=True),'metadata':metadata}]
    if kind in {'timestamps','phoneme_timestamps'}:
        field='word_timestamps' if kind=='timestamps' else 'phoneme_timestamps';labels='words' if kind=='timestamps' else 'phonemes';a=data.get(field)
        if not isinstance(a,dict) or not all(isinstance(a.get(n),list) for n in (labels,'start','end')) or len({len(a[n]) for n in (labels,'start','end')})!=1: raise ValueError('Malformed timestamp arrays')
        metadata.update({'kind':kind,'unit':'seconds','origin':'provider_reported; continuation offset unverified'})
        return [{'type':'timestamps','context_id':ctx,'metadata':metadata}]
    return [{'type':kind if kind in {'done','flush_done'} else 'metadata','context_id':ctx,'metadata':metadata}]
