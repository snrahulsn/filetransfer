import asyncio
from dataclasses import asdict
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import time
import uuid
import importlib
import hashlib
import importlib.metadata
import sys
import platform
import os
import shutil
import math

from .audio import inspect_audio
from .metrics import summarize_runs, text_units
from .registry import build_request, code_digest, digest, provider
from .transport import synthesize


def ensure_no_secrets(config):
    if isinstance(config, dict):
        for key, value in config.items():
            if re.search(r"api[_-]?key|authorization|password|secret|access[_-]?token", key, re.I):
                raise ValueError("Credentials belong in environment variables, not persisted configuration")
            ensure_no_secrets(value)
    elif isinstance(config, list):
        for value in config:
            ensure_no_secrets(value)


MIN_FREE_BYTES = 500 * 1024 * 1024

class InsufficientDiskSpace(OSError):
    pass

def atomic_bytes(path, content):
    path = Path(path)
    temporary = path.with_name(path.name + ".partial")
    with temporary.open("wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


async def run_one(provider_id, text, config, output_root, timeout=60, cancel_after=None, scenario_id="adhoc", queue_wait_ms=0, client=None, evaluation_language=None, stratum="unspecified", min_free_bytes=MIN_FREE_BYTES):
    ensure_no_secrets(config)
    if type(min_free_bytes) is not int or not 100*1024*1024 <= min_free_bytes <= MIN_FREE_BYTES:
        raise ValueError("Disk evidence floor must be 100..500 MiB")
    item = provider(provider_id)
    run_id = uuid.uuid4().hex
    folder = Path(output_root) / run_id
    folder.mkdir(parents=True, exist_ok=False)
    record = {"run_id": run_id, "provider": provider_id, "language": evaluation_language or config.get("language", "unverified"),
              "stratum":stratum,"language_label_source":"fixture_annotation" if evaluation_language else "provider_config",
              "scenario_id": scenario_id, "created_at": datetime.now(timezone.utc).isoformat(), "config": config,
              "config_sha256": digest(config), "code_sha256": code_digest(), "vendor_spec_sha256": digest(item),
              "text": text, "text_units": text_units(text), "queue_wait_ms": queue_wait_ms,
              "environment": {"clock": "perf_counter_ns", "boundary": "HTTP client", "region": config.get("region", "unspecified"),
                              "python":sys.version,"platform":platform.platform(),
                              "dependencies":{name:importlib.metadata.version(name) for name in ("httpx","websockets")}},
              "billing": {"status": "not_reconciled", "amount": None}, "evidence_class": "live_http",
              "disk_floor_bytes":min_free_bytes}
    started = time.perf_counter_ns()
    phase = "preflight"
    try:
        record["disk_free_preflight_bytes"]=shutil.disk_usage(folder).free
        if record["disk_free_preflight_bytes"] < min_free_bytes:
            raise InsufficientDiskSpace("Insufficient space to retain evaluation evidence")
        phase = "generation"
        module=importlib.import_module(f"tts_arena.adapters.{provider_id}")
        local=getattr(module,"synthesize_local",None)
        if local:
            record["evidence_class"]="local_model_execution"
            record["environment"]["boundary"]="local batch worker including model initialization"
            if cancel_after is not None:
                from .contracts import UnsupportedFeature
                raise UnsupportedFeature("Local batch workers do not expose cancellation; no fake thread cancellation")
            # Local worker is synchronous; runtime/model loading cannot be safely killed by cancelling a thread.
            # Deliberately do not claim the HTTP timeout bounds this optional worker.
            generated=await asyncio.to_thread(local,text,config)
            audio=generated.pop("audio")
            elapsed=(time.perf_counter_ns()-started)/1e6
            from .contracts import RequestSpec
            spec=RequestSpec("LOCAL","local://model",{},sample_rate=generated["sample_rate"],encoding=generated["encoding"])
            result={"status":"success","elapsed_ms":elapsed,"first_audio_ms":elapsed,"first_byte_ms":None,
                    "first_audio_boundary":"batch_local_output_available_including_model_init","audio_bytes":len(audio),
                    "audio_sha256":hashlib.sha256(audio).hexdigest(),"events":[],"local_runtime":generated}
            record["evidence_class"]="local_model_execution"
        else:
            spec = build_request(provider_id, text, config)
            result, audio = await synthesize(spec, timeout=timeout, cancel_after=cancel_after,client=client)
        record.update(result)
        record["request_contract"] = {"method": spec.method, "url_host": __import__("urllib.parse", fromlist=["urlparse"]).urlparse(spec.url).hostname,
                                      "response_mode": spec.response_mode, "encoding": spec.encoding, "sample_rate": spec.sample_rate,
                                      "headers": sorted(spec.headers), "body_sha256": digest(spec.body) if not isinstance(spec.body, bytes) else __import__("hashlib").sha256(spec.body).hexdigest()}
        if audio:
            extension = ".wav" if audio.startswith(b"RIFF") else ".bin"
            phase = "audio_persistence"
            atomic_bytes(folder / ("audio" + extension), audio)
            record["audio_file"] = "audio" + extension
            phase = "audio_analysis"
            try:
                record["audio_analysis"] = inspect_audio(audio, spec.encoding, spec.sample_rate, spec.channels)
                duration = record["audio_analysis"]["duration_seconds"]
                record["duration_seconds"] = duration
                record["realtime_factor"] = record["elapsed_ms"] / 1000 / duration if duration else None
            except (ValueError, EOFError) as exc:
                record["audio_analysis"] = {"analysis_status": "invalid_or_unsupported", "error_type": type(exc).__name__}
                record["status"]="error"
    except Exception as exc:
        if phase == "audio_persistence":
            record["generation_status"] = record.get("status")
            record.update(status="error", error_type=type(exc).__name__, error_phase=phase, audio_file=None)
        else:
            record.update(status="blocked" if isinstance(exc, (ValueError, InsufficientDiskSpace)) else "error", error_type=type(exc).__name__, error_phase=phase,
                          elapsed_ms=(time.perf_counter_ns()-started)/1e6, first_audio_ms=None, events=[])
        record["network_attempted"] = phase != "preflight" and record["evidence_class"] == "live_http"
    atomic_bytes(folder / "result.json", (json.dumps(record, ensure_ascii=False, indent=2) + "\n").encode())
    return record


async def run_load(jobs, output_root, concurrency=1, arrivals_per_second=1, max_requests=100, timeout=60, comparison_manifests=None, connection_policy="cold"):
    if (type(concurrency) is not int or not 1 <= concurrency <= 1000
        or type(max_requests) is not int or not 1 <= max_requests <= 100000
        or type(arrivals_per_second) not in (int,float) or not math.isfinite(arrivals_per_second) or arrivals_per_second <= 0
        or type(timeout) not in (int,float) or not math.isfinite(timeout) or not 0 < timeout <= 600
        or not isinstance(jobs,list) or not 1 <= len(jobs) <= max_requests):
        raise ValueError("Invalid bounded load configuration")
    semaphore = asyncio.Semaphore(concurrency)
    if connection_policy not in {"cold","pooled"}: raise ValueError("Connection policy must be cold or pooled")
    from .registry import assert_tts_only
    invariant_hash=assert_tts_only(comparison_manifests) if comparison_manifests is not None else None
    if len({job["provider"] for job in jobs})>1 and invariant_hash is None:
        raise ValueError("Multi-provider load requires comparison_manifests with fixed non-TTS settings")
    if comparison_manifests:
        for job in jobs:
            matched=[m for m in comparison_manifests if m.get("tts",{}).get("provider")==job["provider"]
                     and digest(m.get("tts",{}).get("config",{}))==digest(job["config"])]
            if not matched: raise ValueError("Job TTS configuration is not bound to a comparison manifest")
            chunks=matched[0]["text_chunks"]
            if not isinstance(chunks,list) or "".join(c["text"] for c in chunks)!=job["text"]:
                raise ValueError("Job text is not the manifest's frozen chunk sequence")
    batch_id = uuid.uuid4().hex
    schedule = {"batch_id":batch_id,"created_at":datetime.now(timezone.utc).isoformat(),"arrivals_per_second":arrivals_per_second,"concurrency":concurrency,"connection_policy":connection_policy,"timeout_seconds":timeout,"automatic_retries":0,"jobs":[{"index":i,"scheduled_offset_ms":1000*i/arrivals_per_second,"provider":j["provider"],"text_sha256":digest(j["text"]),"config_sha256":digest(j["config"])} for i,j in enumerate(jobs)]}
    Path(output_root).mkdir(parents=True,exist_ok=True)
    atomic_bytes(Path(output_root)/f"schedule-{batch_id}.json",json.dumps(schedule,indent=2).encode())
    start = time.perf_counter()
    async def execute(index, job):
        scheduled = start + index / arrivals_per_second
        await asyncio.sleep(max(0, scheduled-time.perf_counter()))
        async with semaphore:
            queue_wait = max(0, (time.perf_counter()-scheduled)*1000)
            return await run_one(job["provider"], job["text"], job["config"], output_root, timeout=timeout,
                                 scenario_id=job.get("scenario_id", str(index)), queue_wait_ms=queue_wait,client=client,
                                 evaluation_language=job.get("evaluation_language"),stratum=job.get("stratum","unspecified"))
    import httpx
    client=None
    try:
        if connection_policy=="pooled": client=httpx.AsyncClient(timeout=timeout,follow_redirects=False,trust_env=False)
        results = await asyncio.gather(*(execute(i, job) for i, job in enumerate(jobs)))
    finally:
        if client is not None: await client.aclose()
    summary = {"batch_id":batch_id,"arrivals_per_second":arrivals_per_second,"timeout_seconds":timeout,"arrival_model": "open_loop_fixed_interval", "concurrency": concurrency, "requests": len(jobs),
            "automatic_retries": 0,"invariant_sha256":invariant_hash,"connection_policy":connection_policy,
               "summary": summarize_runs(results), "run_ids": [r["run_id"] for r in results]}
    Path(output_root).mkdir(parents=True, exist_ok=True)
    atomic_bytes(Path(output_root)/f"load-{batch_id}.json",(json.dumps(summary,indent=2)+"\n").encode())
    return summary
