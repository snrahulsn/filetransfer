# Shared implementation contract

Python 3.11+ package `tts_arena`, standard library core; optional httpx transport. Tests use unittest. Shell commands use `rtk proxy`.

Each researched candidate lives at `catalog/<id>.json`:
```
{
 "id":"id", "name":"Name", "kind":"vendor|open_model",
 "reviewed_at":"2026-09-15", "integration_status":"implemented|blocked",
 "integration_notes":"...", "credentials":["ENV_NAME"],
 "sources":[{"id":"s1","url":"https://...","title":"...","accessed":"2026-09-15","claims":["..."]}],
 "languages":{"en-IN":{"status":"documented|unsupported|unverified","source_ids":["s1"],"notes":"..."}},
 "features":{"audio_streaming":{"status":"documented|unsupported|unverified","source_ids":["s1"],"notes":"..."}},
 "models":["exact known model IDs"], "pricing":{"status":"unverified","notes":"...","source_ids":[]},
 "spec_tests":[{"id":"request_contract","description":"...","source_ids":["s1"]}]
}
```
Required language keys en-IN,hi-IN,bn-IN,mr-IN,te-IN,ta-IN,gu-IN,ur-IN,kn-IN,ml-IN. English support alone does not prove Indian accent. All language claims require source IDs, or mark unverified. Include model-specific exceptions.

Feature keys: text_input_streaming,audio_streaming,flush,cancel,connection_reuse,word_timestamps,pronunciation_dictionary,ssml,speed,emotion,voice_cloning,cross_language_voice,telephony_formats,seed,concurrency_limits,data_residency,retention. Each feature has status, source_ids, notes. No assumed capability from a generic compatible endpoint. Provider-wide support must be qualified by model.

Adapters live `tts_arena/adapters/<id>.py`, importing `RequestSpec` and `UnsupportedFeature` from `tts_arena.contracts`. Export `build_request(text: str, config: dict, env: Mapping[str,str]) -> RequestSpec`. No network, global secrets or SDK imports during build_request. Raise ValueError for missing required config/credentials; UnsupportedFeature for unimplemented protocol/feature, never silently fall back. Config includes explicit model,voice,language, format and vendor fields. Match exact vendor spec; no invented defaults.

RequestSpec dataclass fields: method:str, url:str, headers:dict[str,str], body:dict|str|bytes|None=None, response_mode:str='binary', audio_path:str|None=None, sample_rate:int|None=None, channels:int=1, encoding:str='unknown', metadata:dict=field(default_factory=dict). response_mode binary,json_base64,sse_base64; audio_path dot-separated path into JSON or SSE event. metadata may include query or unimplemented_features. Configured endpoint override MUST require explicit opt-in allow_endpoint_override and may not silently send credentials to arbitrary hosts. No secrets in metadata. Local/SDK/WebSocket adapters can raise UnsupportedFeature with exact requirement rather than claim implemented.

Tests live tests/test_<id>.py and run offline with synthetic credentials. Assert request details against documented examples, invalid config rejection, no unsupported controls silently dropped. Adapter tests should have literal expected values independent of the adapter. Do not make paid calls. Research official primary sources through web tools, capture source URL and exact source scope, not search results alone. Each agent writes docs/vendors/<id>.md with implementation, supported subset, spec references, language detail, verification gaps. Do not edit shared core, README, or other agents' files.

Certification is always initially not_live_verified. Passing local request tests is contract-tested, never certified vendor behavior. Private API candidates remain blocked with an exact access requirement. No production stack/keys/listeners currently supplied. Do not modify original evidence or assessment.
