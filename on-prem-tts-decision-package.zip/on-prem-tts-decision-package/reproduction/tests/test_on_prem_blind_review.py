import json
from pathlib import Path
import unittest
import zipfile

from scripts.package_on_prem_blind_review import PRIVATE_KEY, PUBLIC, ZIP_PATH, build


class OnPremBlindReviewTests(unittest.TestCase):
    def test_shareable_archive_is_blind_and_private_key_stays_external(self):
        status = build()
        first_hash = status["shareable_archive_sha256"]
        self.assertEqual(build()["shareable_archive_sha256"], first_hash)
        self.assertEqual((status["recordings"], status["anonymous_systems"]), (9, 6))
        key = json.loads(PRIVATE_KEY.read_text())
        self.assertEqual(len(key["items"]), 9)
        public_text = (PUBLIC / "README.md").read_text() + (PUBLIC / "manifest.json").read_text()
        for secret in ("Kokoro", "Maya Research", "NVIDIA", "hexgrad/Kokoro-82M", "maya-research/Veena", "maya-research/maya1", "magpie-tts-multilingual", "agastya", "kavya", "maitri"):
            self.assertNotIn(secret.lower(), public_text.lower())
        with zipfile.ZipFile(ZIP_PATH) as archive:
            names = archive.namelist()
            self.assertEqual(len([name for name in names if name.endswith(".wav")]), 9)
            self.assertFalse(any("private" in name.lower() for name in names))
            self.assertIn("on-prem-blind-review/README.md", names)
        self.assertIn("unmatched exploratory samples", (PUBLIC / "README.md").read_text())


if __name__ == "__main__":
    unittest.main()
