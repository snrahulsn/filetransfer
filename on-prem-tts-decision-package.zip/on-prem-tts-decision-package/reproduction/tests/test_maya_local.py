import hashlib,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,MagicMock
from tts_arena.adapters import maya_local as m
from tts_arena.contracts import UnsupportedFeature
class MayaLocalContract(unittest.TestCase):
 def config(self,model='maya-research/Veena'):
  c={'model':model,'model_revision':m.PROFILES[model]['revision'],'codec_revision':m.PROFILES[m.CODEC]['revision'],'device':'mps','dtype':'float16','format':'pcm_s16le','language':'hi-IN','voice':'kavya','max_new_tokens':256,'temperature':.4,'top_p':.9,'repetition_penalty':1.05,'seed':42,'memory_budget_gib':12}
  if model.endswith('maya1'):c.update(language='en-IN',description='An adult Indian English voice');c.pop('voice')
  return c
 def test_exact_prompt_sequences(self):
  tokenizer=MagicMock();tokenizer.encode.return_value=[123,456]
  self.assertEqual(m.prompt_ids(tokenizer,'Hello',self.config()),[128259,123,456,128260,128261,128257]);tokenizer.encode.assert_called_with('<spk_kavya> Hello',add_special_tokens=False)
  self.assertEqual(m.prompt_ids(tokenizer,'Hello',self.config('maya-research/maya1')),[128259,128000,123,456,128009,128260,128261,128257]);tokenizer.encode.assert_called_with('<description="An adult Indian English voice"> Hello',add_special_tokens=False)
 def test_independent_snac_hierarchy_fixture(self):
  # Literal seven codebook offsets plus distinct per-slot code numbers.
  codes=[128267,132364,136461,140558,144655,148752,152849,128258]
  levels,stats=m.unpack_generated(codes,'maya-research/Veena')
  self.assertEqual(levels,[[1],[2,5],[3,4,6,7]]);self.assertEqual(stats['snac_tokens'],7)
  self.assertEqual(m.unpack_generated(codes,'maya-research/maya1')[0],levels)
 def test_eos_truncation_and_malformed_frames_rejected(self):
  for ids in [[128267], [128267,128258], [128258], [128267,132364,136461,140558,144655,148752,128267,128258]]:
   with self.subTest(ids=ids),self.assertRaises(ValueError):m.unpack_generated(ids,'maya-research/Veena')
 def test_stop_at_first_terminal(self):
  ids=[128267,132364,136461,140558,144655,148752,152849,128262,128267]
  self.assertEqual(m.unpack_generated(ids,'maya-research/Veena')[1]['terminal_token'],128262)
 def test_no_hosted_alias_or_hindi_maya1(self):
  for changes in [{'model':'Maya Calyx'},{'model':'maya2-native'},{'language':'ta-IN'},{'allow_model_download':True},{'cancel':True},{'voice':'unknown'}]:
   with self.subTest(changes=changes),self.assertRaises((UnsupportedFeature,ValueError)):m.validate_config('Hello',dict(self.config(),**changes))
  with self.assertRaises(UnsupportedFeature):m.validate_config('नमस्ते',dict(self.config('maya-research/maya1'),language='hi-IN'))
 def test_exact_revision_and_memory_gate(self):
  m.validate_config('Hi',self.config())
  with self.assertRaises(UnsupportedFeature):m.validate_config('Hi',dict(self.config(),model_revision='main'))
  with self.assertRaises(UnsupportedFeature):m.validate_config('Hi',dict(self.config(),dtype='float32'))
  for changes in [{'max_new_tokens':True},{'temperature':float('nan')},{'seed':True},{'memory_budget_gib':20}]:
   with self.subTest(changes=changes),self.assertRaises(ValueError):m.validate_config('Hi',dict(self.config(),**changes))
 def test_snapshot_verification_binds_file_bytes(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'config.json';p.write_bytes(b'{}')
   profile={'files':{'config.json':{'bytes':2,'hash_kind':'git_blob_sha1','digest':hashlib.sha1(b'blob 2\0{}').hexdigest()}}}
   m.verify_snapshot(d,profile);p.write_bytes(b'[]')
   with self.assertRaises(ValueError):m.verify_snapshot(d,profile)
 def test_missing_snapshot_fails_before_runtime_import(self):
  with patch.object(m,'dependency') as dep,self.assertRaises(ValueError):m.synthesize_local('Hi',dict(self.config(),model_path='/never/existing/model',codec_path='/never/existing/codec'))
  dep.assert_not_called()
 def test_cuda_preflight_rejects_unavailable_or_insufficient_vram(self):
  c=dict(self.config(),device='cuda',memory_budget_gib=20,model_path='/fixture/model',codec_path='/fixture/codec')
  torch=MagicMock();torch.cuda.is_available.return_value=False
  with patch.object(m,'verify_snapshot',side_effect=[('/fixture/model',{}),('/fixture/codec',{})]),patch.object(m,'dependency',side_effect=lambda n:torch if n=='torch' else MagicMock()),self.assertRaises(UnsupportedFeature):m.synthesize_local('Hi',c)
  torch.cuda.is_available.return_value=True;torch.cuda.mem_get_info.return_value=(2*2**30,24*2**30)
  with patch.object(m,'verify_snapshot',side_effect=[('/fixture/model',{}),('/fixture/codec',{})]),patch.object(m,'dependency',side_effect=lambda n:torch if n=='torch' else MagicMock()),self.assertRaises(UnsupportedFeature):m.synthesize_local('Hi',c)
 def test_protocol_delimiter_injection_rejected(self):
  with self.assertRaises(ValueError):m.validate_config('<|end_of_text|>',self.config())
  with self.assertRaises(ValueError):m.validate_config('Hello',dict(self.config('maya-research/maya1'),description='broken" attr'))
 def test_runtime_wiring_stays_local_and_uses_restricted_codec_load(self):
  torch=MagicMock();transformers=MagicMock();snac=MagicMock()
  model=transformers.AutoModelForCausalLM.from_pretrained.return_value.eval.return_value
  tokenizer=transformers.AutoTokenizer.from_pretrained.return_value;tokenizer.encode.return_value=[7,8];tokenizer.pad_token_id=128263
  model.generate.return_value.__getitem__.return_value.tolist.return_value=[128267,132364,136461,140558,144655,148752,152849,128258]
  audio=MagicMock();audio.numel.return_value=2;audio.float.return_value.cpu.return_value=[.1,-.1]
  codec=snac.SNAC.from_config.return_value;codec.decode.return_value.__getitem__.return_value=audio
  config=dict(self.config(),model_path='/fixture/model',codec_path='/fixture/codec',device='cpu')
  with patch.object(m,'verify_snapshot',side_effect=[('/fixture/model',{}),('/fixture/codec',{})]),patch.object(m,'dependency',side_effect=lambda n:{'torch':torch,'transformers':transformers,'snac':snac}[n]):
   result=m.synthesize_local('Hello',config)
  kwargs=transformers.AutoModelForCausalLM.from_pretrained.call_args.kwargs
  self.assertTrue(kwargs['local_files_only']);self.assertFalse(kwargs['trust_remote_code']);self.assertTrue(kwargs['use_safetensors']);self.assertEqual(kwargs['device_map'],{'':'cpu'})
  torch.load.assert_called_once_with('/fixture/codec/pytorch_model.bin',map_location='cpu',weights_only=True)
  snac.SNAC.from_pretrained.assert_not_called();self.assertEqual(result['sample_rate'],24000);self.assertEqual(len(result['audio']),4);self.assertFalse(result['streaming'])
  self.assertEqual(model.generate.call_args.kwargs['eos_token_id'],[128258,128262])
