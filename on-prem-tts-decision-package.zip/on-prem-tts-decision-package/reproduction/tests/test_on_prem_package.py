import io
import tempfile
import unittest
import zipfile
from pathlib import Path

from scripts.package_on_prem_report import assert_no_secrets, scan_bytes


class OnPremPackageSecurityTests(unittest.TestCase):
    def test_scanner_rejects_known_token_forms_without_returning_value(self):
        value = "rpa_" + "A" * 40
        findings = scan_bytes("report.txt", value.encode())
        self.assertEqual(findings, ["Runpod API key: report.txt"])
        self.assertNotIn(value, "\n".join(findings))

    def test_scanner_rejects_private_paths_and_assigned_literals(self):
        findings = scan_bytes("private-key.json", b'api_key="' + b"a" * 24 + b'"')
        self.assertIn("forbidden path: private-key.json", findings)
        self.assertIn("literal assigned secret: private-key.json", findings)

    def test_scanner_enters_nested_archives(self):
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w") as archive:
            archive.writestr("credentials.env", "TOKEN=not-printed")
        findings = scan_bytes("nested.zip", stream.getvalue())
        self.assertEqual(findings, ["forbidden path: nested.zip!credentials.env"])

    def test_scanner_allows_hashes_placeholders_and_source_code(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "manifest.json").write_text(
                '{"audio_sha256":"' + "a" * 64 + '","api_key":"[REDACTED]"}')
            (root / "runner.py").write_text('header = "Bearer " + key\n')
            assert_no_secrets(root)


if __name__ == "__main__":
    unittest.main()
