import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from scripts.runpod_nim_pilot import hindi_voices, pilot, validate_metadata


class RunpodNimPilotTests(unittest.TestCase):
    def test_discovery_requires_exact_magpie_hindi_voice_and_model_metadata(self):
        voices = hindi_voices({'en-US,hi-IN': {'voices': [
            'Magpie-Multilingual.EN-US.Aria', 'Magpie-Multilingual.HI-IN.Asha',
            'Magpie-ZeroShot-Multilingual.HI-IN.Asha']}})
        self.assertEqual(voices, ['Magpie-Multilingual.HI-IN.Asha'])
        self.assertEqual(validate_metadata({'selectedModelProfileId': 'profile-hash',
                                           'modelInfo': [{'modelUrl': 'ngc://nim/nvidia/magpie-tts-multilingual:v1'}]}),
                         'profile-hash')
        with self.assertRaisesRegex(RuntimeError, 'does not identify'):
            validate_metadata({'selectedModelProfileId': 'profile-hash',
                               'modelInfo': [{'modelUrl': 'ngc://nim/nvidia/chatterbox:v1'}]})

    def test_failed_voice_discovery_cleans_both_resources_without_synthesis(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            key_file = base / 'private.env'
            key_file.write_text('RunPod=private-runpod\nNGC_API_KEY=private-ngc\n')
            deleted = []

            def get(origin, path):
                if path == '/v1/health/ready':
                    return {'status': 'ready'}
                if path == '/v1/metadata':
                    return {'selectedModelProfileId': 'p',
                            'modelInfo': [{'modelUrl': 'ngc://nim/nvidia/magpie-tts-multilingual:v1'}]}
                if path == '/v1/version':
                    return {'release': '1.8.0'}
                return {'en-US,hi-IN': {'voices': ['Magpie-Multilingual.EN-US.Aria']}}

            def delete(pod_id, auth_id, key):
                deleted.append((pod_id, auth_id, key))
                return {'pods': {'deleted': True}, 'containerregistryauth': {'deleted': True}}

            with self.assertRaisesRegex(RuntimeError, 'no Magpie Hindi voice'):
                asyncio.run(pilot(key_file, base / 'output', base / 'guard.json',
                                  create_pod=lambda *_: {'pod_id': 'pod1', 'registry_auth_id': 'auth1',
                                                         'hourly_usd': 0.74,
                                                         'https_origin': 'https://pod1-9000.proxy.runpod.net'},
                                  get=get, delete=delete,
                                  synthesize=lambda *_args, **_kwargs: self.fail('No synthesis allowed'),
                                  audio_guard=lambda *_: None))
            self.assertEqual(deleted, [('pod1', 'auth1', 'private-runpod')])
            self.assertTrue((base / 'output' / 'cleanup.json').exists())


if __name__ == '__main__':
    unittest.main()
