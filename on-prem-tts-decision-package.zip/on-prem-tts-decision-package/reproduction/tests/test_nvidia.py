import unittest
from email.parser import BytesParser
from email.policy import default
from tts_arena.adapters.nvidia import build_request


class TestNvidia(unittest.TestCase):
    config={'endpoint':'http://localhost:9000','allow_endpoint_override':True,
            'model':'magpie-tts-multilingual','voice':'Magpie-Multilingual.HI-IN.Aria',
            'language':'hi-IN','format':'pcm_s16le','sample_rate':22050}

    def test_multipart_matches_documented_fields(self):
        r=build_request('नमस्ते',self.config,{})
        self.assertEqual(r.url,'http://localhost:9000/v1/audio/synthesize_online')
        self.assertEqual(r.encoding,'pcm_s16le')
        msg=BytesParser(policy=default).parsebytes(('Content-Type: '+r.headers['Content-Type']+'\r\n\r\n').encode()+r.body)
        fields={p.get_param('name',header='content-disposition'):p.get_payload(decode=True).decode('utf-8') for p in msg.iter_parts()}
        self.assertEqual(fields,{'text':'नमस्ते','language':'hi-IN','voice':'Magpie-Multilingual.HI-IN.Aria','sample_rate_hz':'22050','encoding':'LINEAR_PCM'})
        self.assertNotIn('Authorization',r.headers)

    def test_offline_wav_route(self):
        r=build_request('hello',{**self.config,'format':'wav'},{})
        self.assertTrue(r.url.endswith('/v1/audio/synthesize'))
        self.assertEqual(r.encoding,'wav')

    def test_rejects_bad_controls(self):
        for k,v in {'allow_endpoint_override':False,'format':'mp3','language':'ta-IN','sample_rate':False,'speed':1,'model':'other'}.items():
            with self.subTest(key=k),self.assertRaises(ValueError):
                build_request('hello',{**self.config,k:v},{})

    def test_endpoint_validation(self):
        for endpoint in ['http://example.com','https://user:pass@example.com','https://example.com/path','https://example.com/?secret=1','https://example.com/#fragment']:
            with self.subTest(endpoint=endpoint),self.assertRaises(ValueError):
                build_request('hello',{**self.config,'endpoint':endpoint},{})

    def test_injection_and_empty_input(self):
        for text in ['', 'tts-arena-nim-boundary-v1', 'x'*2001]:
            with self.subTest(text=text[:30]),self.assertRaises(ValueError):
                build_request(text,self.config,{})
