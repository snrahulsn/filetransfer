"""Offline request conformance, not live certification. Expected wire fields are literal fixtures."""
import unittest
from tts_arena.adapters.qwen import build_request
from tts_arena.contracts import UnsupportedFeature

class TestQwen(unittest.TestCase):
    config={'model': 'qwen3-tts-flash', 'voice': 'Cherry', 'language': 'English', 'region': 'singapore', 'allow_download_hosts': ['dashscope-result-sg.oss-ap-southeast-1.aliyuncs.com']}
    env={'DASHSCOPE_API_KEY': 'synthetic'}

    def test_documented_request(self):
        result=build_request('नमस्ते',self.config,self.env)
        self.assertEqual(result.method,'POST')
        self.assertEqual(result.url,'https://dashscope-intl.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation')
        self.assertEqual(result.headers['Authorization'],'Bearer synthetic')
        self.assertEqual(result.body,{'model': 'qwen3-tts-flash', 'input': {'text': 'नमस्ते', 'voice': 'Cherry', 'language_type': 'English'}})
        self.assertEqual(result.response_mode,'json_url')
        self.assertEqual(result.metadata['certification'],'not_live_verified')
        self.assertNotIn('synthetic',str(result.metadata))

    def test_invalid_values_and_unimplemented_features(self):
        for key,value in {'model': 'unknown', 'language': 'Hindi', 'region': 'india', 'allow_download_hosts': ['*.aliyuncs.com'], 'format': 'wav', 'instructions': 'excited'}.items():
            with self.subTest(key=key):
                with self.assertRaises(ValueError):
                    build_request('hello',{**self.config,key:value},self.env)

    def test_missing_credentials(self):
        with self.assertRaises(ValueError):
            build_request('hello',self.config,{})

    def test_empty_input(self):
        for text in ('', '  ', None):
            with self.subTest(text=text), self.assertRaises(ValueError):
                build_request(text,self.config,self.env)

    def test_no_endpoint_override_or_silent_extra(self):
        for extra in ({'endpoint':'https://example.invalid'},{'surprise':False}):
            with self.assertRaises(UnsupportedFeature):
                build_request('hello',{**self.config,**extra},self.env)

    def test_does_not_mutate_configuration(self):
        import copy
        original=copy.deepcopy(self.config)
        build_request('hello',self.config,self.env)
        self.assertEqual(self.config,original)
