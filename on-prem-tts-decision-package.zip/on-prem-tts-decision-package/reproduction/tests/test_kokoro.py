import unittest
from tts_arena.adapters.kokoro import build_request
from tts_arena.contracts import UnsupportedFeature

class TestPrerequisite(unittest.TestCase):
    def test_runtime_is_explicitly_blocked(self):
        with self.assertRaisesRegex(UnsupportedFeature, 'runtime'):
            build_request('hello',{},{})
