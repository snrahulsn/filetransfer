import unittest
from pathlib import Path

from scripts.runpod_nim_pod import create
from scripts.runpod_nim_guard import cleanup


class RunpodNimPodTests(unittest.TestCase):
    def setUp(self):
        self.seen = []
        self.guard_calls = []

    def pod_api(self, method, key, payload=None):
        self.seen.append(('pods', method, payload))
        if method == 'GET':
            return 200, []
        self.assertEqual(method, 'POST')
        return 201, {'id': 'pod123', 'adjustedCostPerHr': 0.74}

    def registry_api(self, method, key, auth_id='', payload=None):
        self.seen.append(('registry', method, payload))
        if method == 'POST':
            return 200, {'id': 'auth123'}
        self.assertEqual((method, auth_id), ('DELETE', 'auth123'))
        return 204, None

    def test_launch_uses_private_nim_image_and_starts_guard(self):
        result = create({'RunPod': 'secret-runpod', 'NGC_API_KEY': 'secret-ngc'},
                        Path('/private/credentials.env'), Path('/private/guard.json'),
                        pods=self.pod_api, registry=self.registry_api,
                        guard=lambda *args: self.guard_calls.append(args),
                        audio_guard=lambda root, provider, locale: self.assertEqual((provider, locale), ('nvidia', 'hi-IN')))
        pod_payload = next(payload for kind, method, payload in self.seen if kind == 'pods' and method == 'POST')
        self.assertEqual(pod_payload['imageName'], 'nvcr.io/nim/nvidia/magpie-tts-multilingual:1.10.0')
        self.assertEqual(pod_payload['containerRegistryAuthId'], 'auth123')
        self.assertEqual(pod_payload['ports'], ['9000/http', '50051/tcp'])
        self.assertEqual(pod_payload['gpuTypeIds'], ['NVIDIA L40S'])
        self.assertEqual(pod_payload['env']['NIM_TAGS_SELECTOR'], 'name=magpie-tts-multilingual,batch_size=8')
        self.assertEqual(self.guard_calls[0][0:2], ('pod123', 'auth123'))
        self.assertEqual(result['hourly_usd'], 0.74)
        self.assertNotIn('secret-runpod', str(result))
        self.assertNotIn('secret-ngc', str(result))

    def test_over_cap_deletes_both_resources_before_returning(self):
        def over_cap(method, key, payload=None):
            if method == 'GET':
                return 200, []
            return 201, {'id': 'pod123', 'costPerHr': 1.71}

        deletions = []
        with self.assertRaisesRegex(RuntimeError, 'exceeded'):
            create({'RunPod': 'secret-runpod', 'NGC_API_KEY': 'secret-ngc'},
                   Path('/private/credentials.env'), Path('/private/guard.json'),
                   pods=over_cap, registry=self.registry_api,
                   guard=lambda *args: self.fail('Guard must not start for an over-cap Pod'),
                   cleanup_fn=lambda pod, auth, key: deletions.append((pod, auth)),
                   audio_guard=lambda *_: None)
        self.assertEqual(deletions, [('pod123', 'auth123')])

    def test_hard_stop_deletes_pod_then_registry_auth(self):
        calls = []
        result = cleanup('pod123', 'auth123', 'private',
                         delete=lambda kind, resource_id, key: calls.append((kind, resource_id)) or 204)
        self.assertEqual(calls, [('pods', 'pod123'), ('containerregistryauth', 'auth123')])
        self.assertTrue(result['pods']['deleted'])
        self.assertTrue(result['containerregistryauth']['deleted'])
        self.assertNotIn('private', str(result))

    def test_uncertain_registry_response_recovers_named_auth_without_duplicate_create(self):
        state = {'name': None, 'posts': 0}

        def uncertain_registry(method, key, auth_id='', payload=None):
            if method == 'POST':
                state['name'] = payload['name']
                state['posts'] += 1
                raise TimeoutError('response lost after create')
            if method == 'GET':
                return 200, [{'id': 'recovered-auth', 'name': state['name']}]
            self.fail('No cleanup should be needed on a successful recovery')

        result = create({'RunPod': 'private-runpod', 'NGC_API_KEY': 'private-ngc'},
                        Path('/private/credentials.env'), Path('/private/guard.json'),
                        pods=self.pod_api, registry=uncertain_registry,
                        guard=lambda *args: self.guard_calls.append(args),
                        audio_guard=lambda *_: None)
        self.assertEqual(result['registry_auth_id'], 'recovered-auth')
        self.assertEqual(state['posts'], 1)
        self.assertEqual(self.guard_calls[0][1], 'recovered-auth')
