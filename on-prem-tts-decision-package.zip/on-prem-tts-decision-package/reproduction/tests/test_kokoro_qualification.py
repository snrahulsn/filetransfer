import unittest
from tts_arena.kokoro_qualification import summarize
class KokoroQualificationTests(unittest.TestCase):
 def row(self,speed,duration=2,**kw):
  return dict(status='success',stratum='hindi',text_sha256='text',voice='hf_alpha',language='hi-IN',speed=speed,duration_seconds=duration,synthesis_wall_seconds=.5,realtime_factor=.25,audio_sha256='audio',**kw)
 def test_speed_direction_and_repeated_latency(self):
  s=summarize([self.row(1.),self.row(1.),self.row(.8,3),self.row(1.2,2)])['groups'][0]
  self.assertTrue(s['speed_direction_observed']);self.assertEqual(s['slow_to_fast_duration_ratio'],1.5);self.assertEqual(s['speed_1_wall_seconds'],[.5,.5]);self.assertTrue(s['warm_speed_1_audio_identical_to_first'])
 def test_missing_speed_is_unknown_not_pass(self):
  s=summarize([self.row(1.)]);self.assertIsNone(s['groups'][0]['speed_direction_observed']);self.assertFalse(s['all_three_groups_complete'])
 def test_different_text_not_used_as_speed_comparison(self):
  a=self.row(.8);b=self.row(1.2);b['text_sha256']='different'
  s=summarize([a,b]);self.assertEqual(len(s['groups']),2);self.assertTrue(all(x['speed_direction_observed'] is None for x in s['groups']))
 def test_failed_runs_counted_without_quality_inference(self):
  s=summarize([{'status':'error'}]);self.assertEqual(s['attempts'],1);self.assertEqual(s['successful_samples'],0);self.assertEqual(s['groups'],[])
