"""Dependency-injected local wire tests. No real model, tensor library, or network."""
from contextlib import nullcontext
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import struct
import unittest
from unittest.mock import patch

from tts_arena.adapters import kokoro, coqui, ai4bharat
from tts_arena.adapters._local_runtime import pcm16
from tts_arena.contracts import UnsupportedFeature


class Tensor:
    def __init__(self, values): self.values=values
    def detach(self): return self
    def cpu(self): return self
    def tolist(self): return self.values


class LocalContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name).resolve()
        for name in ('config.json','weights.pth','voice.pt','vocab.json','reference.wav'):
            (self.path/name).write_bytes(b'fixture-only')
        self.base={'device':'cpu','format':'pcm_s16le','model_revision':'fixture-revision'}

    def p(self,name):return str(self.path/name)

    def test_pcm_conversion_exact_and_invalid_samples(self):
        self.assertEqual(pcm16(Tensor([0,.5,-.5,1,-1])),struct.pack('<5h',0,16384,-16384,32767,-32768))
        for values in ([],[float('nan')],[float('inf')],[[.1],[.2]]):
            with self.assertRaises(ValueError): pcm16(values)

    def test_kokoro_uses_local_weights_and_voice(self):
        calls=[]
        class Model:
            def __init__(self,**kwargs):calls.append(('model',kwargs))
            def to(self,device):calls.append(('device',device));return self
            def eval(self):return self
        class Pipeline:
            def __init__(self,**kwargs):calls.append(('pipeline',kwargs))
            def __call__(self,text,**kwargs):
                calls.append(('synthesis',text,kwargs))
                yield ('g','p',Tensor([0,.5]))
                yield SimpleNamespace(audio=Tensor([-.5]))
        cfg={**self.base,'model':'hexgrad/Kokoro-82M','language':'hi-IN','voice':'hf_alpha',
             'config_path':self.p('config.json'),'weights_path':self.p('weights.pth'),'voice_path':self.p('voice.pt'),'speed':1.2}
        with patch('tts_arena.adapters._local_runtime.dependency',return_value=SimpleNamespace(KModel=Model,KPipeline=Pipeline)),patch('shutil.which',return_value='/fixture/espeak-ng'):
            result=kokoro.synthesize_local('नमस्ते',cfg)
        self.assertEqual(calls[0],('model',{'repo_id':'hexgrad/Kokoro-82M','config':self.p('config.json'),'model':self.p('weights.pth')}))
        self.assertEqual(calls[2][1]['lang_code'],'h')
        self.assertEqual(calls[3],('synthesis','नमस्ते',{'voice':self.p('voice.pt'),'speed':1.2}))
        self.assertEqual(result['audio'],struct.pack('<3h',0,16384,-16384))
        self.assertEqual(result['sample_rate'],24000)
        self.assertEqual(len(result['artifact_sha256']),3)
        self.assertFalse(result['streaming'])

    def test_xtts_checks_checkpoint_language_and_conditions_reference(self):
        calls=[]
        class Config:
            languages=['en','hi']
            def load_json(self,path):calls.append(('config',path))
        class Model:
            @classmethod
            def init_from_config(cls,c):calls.append(('init',c.languages));return cls()
            def load_checkpoint(self,c,**kwargs):calls.append(('load',kwargs))
            def to(self,d):return self
            def eval(self):return self
            def get_conditioning_latents(self,**kwargs):calls.append(('condition',kwargs));return 'conditioning','speaker'
            def inference(self,*args,**kwargs):calls.append(('inference',args,kwargs));return {'wav':[.25,-.25]}
        cfg={**self.base,'model':'coqui/XTTS-v2','language':'hi-IN','config_path':self.p('config.json'),
             'weights_path':self.p('weights.pth'),'vocab_path':self.p('vocab.json'),'reference_audio_path':self.p('reference.wav')}
        def dep(name):return SimpleNamespace(XttsConfig=Config) if name.endswith('xtts_config') else SimpleNamespace(Xtts=Model)
        with patch('tts_arena.adapters._local_runtime.dependency',side_effect=dep):result=coqui.synthesize_local('नमस्ते',cfg)
        self.assertEqual(calls[2],('load',{'checkpoint_path':self.p('weights.pth'),'vocab_path':self.p('vocab.json'),'eval':True,'use_deepspeed':False}))
        self.assertEqual(calls[3],('condition',{'audio_path':[self.p('reference.wav')]}))
        self.assertEqual(calls[4],('inference',('नमस्ते','hi','conditioning','speaker'),{'speed':1.0}))
        self.assertEqual(result['audio'],struct.pack('<2h',8192,-8192))
        Config.languages=['en']
        with patch('tts_arena.adapters._local_runtime.dependency',side_effect=dep),self.assertRaises(UnsupportedFeature):coqui.synthesize_local('नमस्ते',cfg)

    def test_parler_keeps_two_tokenizers_and_masks_separate(self):
        calls=[]
        for sub in ('prompt','description'):(self.path/sub).mkdir()
        class Model:
            config=SimpleNamespace(sampling_rate=44100)
            @classmethod
            def from_pretrained(cls,path,**kwargs):calls.append(('model',path,kwargs));return cls()
            def to(self,d):return self
            def eval(self):return self
            def generate(self,**kwargs):calls.append(('generate',kwargs));return Tensor([[0,-1,1]])
        class Tokenizer:
            def __init__(self,path):self.path=path
            @classmethod
            def from_pretrained(cls,path,**kwargs):calls.append(('tokenizer',path,kwargs));return cls(path)
            def __call__(self,text,**kwargs):
                label=Path(self.path).name
                calls.append(('tokenize',label,text,kwargs))
                return SimpleNamespace(to=lambda device:SimpleNamespace(input_ids=label+'-ids',attention_mask=label+'-mask'))
        modules={'parler_tts':SimpleNamespace(ParlerTTSForConditionalGeneration=Model),'transformers':SimpleNamespace(AutoTokenizer=Tokenizer),'torch':SimpleNamespace(inference_mode=nullcontext)}
        cfg={**self.base,'model':'ai4bharat/indic-parler-tts','language':'auto','model_path':str(self.path),
             'prompt_tokenizer_path':self.p('prompt'),'description_tokenizer_path':self.p('description'),'description':'Divya speaks calmly.'}
        with patch('tts_arena.adapters._local_runtime.dependency',side_effect=modules.__getitem__):result=ai4bharat.synthesize_local('नमस्ते',cfg)
        self.assertEqual(calls[0],('model',str(self.path),{'local_files_only':True}))
        self.assertEqual(calls[1][2],{'local_files_only':True,'trust_remote_code':False})
        self.assertEqual(calls[3],('tokenize','prompt','नमस्ते',{'return_tensors':'pt'}))
        self.assertEqual(calls[4],('tokenize','description','Divya speaks calmly.',{'return_tensors':'pt'}))
        self.assertEqual(calls[5],('generate',{'input_ids':'description-ids','attention_mask':'description-mask','prompt_input_ids':'prompt-ids','prompt_attention_mask':'prompt-mask'}))
        self.assertEqual(result['audio'],struct.pack('<3h',0,-32768,32767))
        self.assertEqual(result['sample_rate'],44100)

    def test_all_models_refuse_download_and_unknown_controls_before_import(self):
        for module in (kokoro,coqui,ai4bharat):
            for extra in ({'allow_model_download':True},{'cancel':True}):
                with self.subTest(module=module.__name__,extra=extra),patch('tts_arena.adapters._local_runtime.dependency') as dep:
                    with self.assertRaises(UnsupportedFeature):module.synthesize_local('hello',{**self.base,**extra})
                    dep.assert_not_called()

    def test_missing_artifacts_are_actionable(self):
        cfg={**self.base,'model':'coqui/XTTS-v2','language':'hi-IN','config_path':str(self.path/'missing.json')}
        with self.assertRaisesRegex(UnsupportedFeature,'artifact missing'):coqui.synthesize_local('hello',cfg)
