import unittest

from scripts.nvidia_nim_preflight import inspect


class NvidiaNimPreflightTests(unittest.TestCase):
    def test_preflight_never_exposes_keys_or_creates_pod(self):
        calls = []

        def fake_api(method, key):
            calls.append((method, key))
            return 200, []

        result = inspect({'RunPod': 'private-runpod-key', 'NGC_API_KEY': 'private-ngc-key'}, fake_api)
        self.assertTrue(result['can_launch'])
        self.assertEqual(result['active_pods'], 0)
        self.assertEqual(calls, [('GET', 'private-runpod-key')])
        self.assertNotIn('private-runpod-key', str(result))
        self.assertNotIn('private-ngc-key', str(result))


    def test_preflight_refuses_launch_without_ngc_or_with_existing_pod(self):
        without_ngc = inspect({'RunPod': 'private'}, lambda *_: (200, []))
        self.assertEqual(without_ngc['blocker'], 'No NVIDIA NGC Catalog key')
        with_pod = inspect({'RunPod': 'private', 'NGC_API_KEY': 'private'}, lambda *_: (200, [{'id': 'existing'}]))
        self.assertFalse(with_pod['can_launch'])
        self.assertEqual(with_pod['active_pods'], 1)
