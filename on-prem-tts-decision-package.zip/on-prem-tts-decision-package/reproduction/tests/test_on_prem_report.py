import json
import unittest
from pathlib import Path

from scripts.build_on_prem_report import build


ROOT = Path(__file__).resolve().parents[1]


class OnPremReportTests(unittest.TestCase):
    def test_report_binds_four_vendors_to_unique_model_language_audio(self):
        report = build()
        self.assertEqual((report["vendor_count"], report["audio_complete_vendor_count"], report["model_count"], report["recording_count"]), (4, 4, 6, 9))
        self.assertEqual({row["id"] for row in report["vendors"]}, {"kokoro", "maya", "nvidia", "qwen"})
        self.assertTrue(report["nvidia_lifecycle"]["pod_deleted"])
        self.assertTrue(report["nvidia_lifecycle"]["registry_auth_deleted"])
        self.assertFalse(report["nvidia_lifecycle"]["ready"])
        self.assertEqual(report["nvidia_lifecycle"]["synthesis_requests"], 0)
        self.assertTrue(report["nvidia_lifecycle"]["hosted_build_ready"])
        self.assertEqual(report["nvidia_lifecycle"]["hosted_build_synthesis_requests"], 1)
        keys = []
        for vendor in report["vendors"]:
            for model in vendor["models"]:
                for clip in model["recordings"]:
                    keys.append((model["model"], clip["language"]))
                    audio = ROOT / "ui/public" / clip["audio_url"].lstrip("/")
                    self.assertTrue(audio.is_file())
                    self.assertGreater(audio.stat().st_size, 44)
        self.assertEqual(len(keys), len(set(keys)))
        saved = json.loads((ROOT / "ui/public/evidence/on-prem-report.json").read_text())
        self.assertEqual(saved, report)


if __name__ == "__main__":
    unittest.main()
