import asyncio
import json
import tempfile
from dataclasses import replace
from types import SimpleNamespace
import unittest
from websockets.asyncio.server import serve
from tts_arena.contracts import UnsupportedFeature
from tts_arena.sessions import maya
from tts_arena.session_runner import run_session

CONFIG = {"model":"Maya Calyx","voice":"Aarav","language":"hi-IN","format":"pcm_s16le","sample_rate":24000}
META = {"type":"metadata","sample_rate":24000,"channels":1,"encoding":"pcm_s16le","session_id":"fixture-session"}
TEXT = {"at_ms":0,"type":"text","context_id":"t1","text":"नमस्ते।"}
END = {"at_ms":1,"type":"end_input","context_id":"t1"}

class MayaSessionContract(unittest.TestCase):
    def test_literal_handshake(self):
        spec=maya.build_session(CONFIG,{"MAYA_API_KEY":"synthetic"})
        self.assertEqual(spec.url,"wss://tts.mayaresearch.ai/v1/tts/stream")
        self.assertEqual(spec.headers,{"Authorization":"Bearer synthetic"})
        self.assertEqual(spec.initial_messages,[{"type":"start","v2":True,"model":"Maya Calyx","voice":"Aarav","language":"hi"}])
        self.assertEqual(spec.metadata["handshake_event"],"metadata")

    def test_literal_actions(self):
        self.assertEqual(maya.encode_action(TEXT,CONFIG),[{"type":"text","context_id":"t1","text":"नमस्ते।","continue":True}])
        self.assertEqual(maya.encode_action(END,CONFIG),[{"type":"text","context_id":"t1","text":"","continue":False}])
        self.assertEqual(maya.encode_action({"type":"cancel","context_id":"t1"},CONFIG),[{"type":"cancel","context_id":"t1"}])
        self.assertEqual(maya.encode_action({"type":"ping"},CONFIG),[{"type":"ping"}])

    def test_reject_unsupported_actions(self):
        for action in ({"type":"flush"},{"type":"text","text":"x"},{"type":"cancel","context_id":"t1","text":"x"},{"type":"text","context_id":"t1","text":" "},{"type":"text","context_id":"t1","text":"x","continue":False}):
            with self.subTest(action=action),self.assertRaises((ValueError,UnsupportedFeature)):
                maya.encode_action(action,CONFIG)

    def test_decode_and_metadata_validation(self):
        self.assertEqual(maya.decode_message(json.dumps(META))[0]["session_id"],"fixture-session")
        self.assertEqual(maya.decode_message('{"type":"audio","context_id":"t1","audio":"AQACAA=="}')[0]["audio"],b"\x01\x00\x02\x00")
        for kind,expected in (("end","done"),("cancelled","cancelled")):
            self.assertEqual(maya.decode_message(json.dumps({"type":kind,"context_id":"t1"}))[0]["type"],expected)
        for changes in ({"sample_rate":8000},{"channels":2},{"channels":True},{"encoding":"mulaw"},{"session_id":None}):
            with self.subTest(changes=changes),self.assertRaises(ValueError): maya.decode_message(json.dumps(META|changes))
        for item in ({"type":"audio","context_id":"t1","audio":"AQ=="},{"type":"audio","context_id":"t1","audio":"!"},{"type":"end"},{"type":"unknown"}):
            with self.subTest(item=item),self.assertRaises(ValueError): maya.decode_message(json.dumps(item))

class MayaSessionRunner(unittest.IsolatedAsyncioTestCase):
    async def exercise(self, mode, actions=None):
        received=[]
        async def server(ws):
            received.append(json.loads(await ws.recv()))
            if mode == "no_metadata": await ws.close(); return
            if mode == "early_audio":
                await ws.send('{"type":"audio","context_id":"t1","audio":"AQACAA=="}'); return
            await asyncio.sleep(.01)
            await ws.send(json.dumps(META))
            async for raw in ws:
                item=json.loads(raw);received.append(item)
                if item["type"]=="text" and item["continue"]:
                    await ws.send('{"type":"audio","context_id":"t1","audio":"AQACAA=="}')
                else:
                    if mode == "cancel_after_close" and item["type"]=="text": continue
                    if mode != "missing_end":
                        kind="cancelled" if mode in {"cancel","cancel_after_close"} else "end"
                        await ws.send(json.dumps({"type":kind,"context_id":"t1"}))
                    if mode=="late_audio": await ws.send('{"type":"audio","context_id":"t1","audio":"AQACAA=="}')
                    if mode=="duplicate_end": await ws.send('{"type":"end","context_id":"t1"}')
                    await ws.close();return
        with tempfile.TemporaryDirectory() as folder:
            async with serve(server,"127.0.0.1",0) as host:
                port=host.sockets[0].getsockname()[1]
                plugin=SimpleNamespace(build_session=lambda c,e:replace(maya.build_session(c,e),url=f"ws://127.0.0.1:{port}"),encode_action=maya.encode_action,decode_message=maya.decode_message)
                result=await run_session("fixture",CONFIG,actions or [TEXT,END],folder,seconds=.1,plugin=plugin,allow_local=True,env={"MAYA_API_KEY":"synthetic"})
        return result,received

    async def test_handshake_precedes_actions_and_end_completes(self):
        result,received=await self.exercise("normal")
        self.assertEqual(result["status"],"observed")
        self.assertEqual([r["type"] for r in received],["start","text","text"])
        kinds=[e["event_type"] for e in result["events"]]
        self.assertLess(kinds.index("provider_event"),kinds.index("action_sent"))
        self.assertEqual(result["audio"][0]["bytes"],4)

    async def test_cancelled_is_terminal(self):
        result,_=await self.exercise("cancel",[TEXT,{"at_ms":1,"type":"cancel","context_id":"t1"}])
        self.assertEqual(result["status"],"observed")
        self.assertTrue(any(e.get("details",{}).get("type")=="cancelled" for e in result["events"]))

    async def test_cancel_after_input_closed_is_allowed(self):
        result,received=await self.exercise("cancel_after_close",[TEXT,END,{"at_ms":30,"type":"cancel","context_id":"t1"}])
        self.assertEqual(result["status"],"observed")
        self.assertEqual(received[-1],{"type":"cancel","context_id":"t1"})

    async def test_protocol_violations_fail(self):
        for mode in ("no_metadata","early_audio","late_audio","duplicate_end"):
            with self.subTest(mode=mode):
                result,_=await self.exercise(mode)
                self.assertEqual(result["status"],"error")
                if mode in {"late_audio","duplicate_end"}:
                    violation=next(e for e in result["events"] if e["event_type"]=="protocol_violation")
                    self.assertEqual(violation["context_id"],"t1")
                    self.assertEqual(violation["reason"],"Event after context terminator")

    async def test_missing_terminal_is_inconclusive(self):
        result,_=await self.exercise("missing_end")
        self.assertEqual(result["status"],"inconclusive")

    async def test_early_close_cannot_claim_second_turn_sent(self):
        result,received=await self.exercise("normal",[TEXT,END,{"at_ms":50,"type":"text","context_id":"t2","text":"धन्यवाद।"}])
        self.assertNotEqual(result["status"],"observed")
        self.assertEqual(result["sent_action_count"],2)
        missing=next(e for e in result["events"] if e["event_type"]=="missing_actions")
        self.assertEqual((missing["planned_count"],missing["sent_count"]),(3,2))

    async def test_close_unopened_turn_rejected_offline(self):
        with tempfile.TemporaryDirectory() as folder,self.assertRaises(ValueError):
            await run_session("maya",CONFIG,[END],folder,env={"MAYA_API_KEY":"synthetic"})
