"""Literal current Calyx fixtures and HTTP response metadata validation; no vendor calls."""
import copy
import unittest
import httpx
from tts_arena.adapters.maya import build_request
from tts_arena.contracts import UnsupportedFeature
from tts_arena.transport import synthesize

CONFIG = dict(model='Maya Calyx', voice='Aarav', language='hi-IN', format='pcm_s16le', sample_rate=24000)
ENV = {'MAYA_API_KEY': 'offline-token'}


class MayaContractTests(unittest.TestCase):
    def test_literal_current_request(self):
        r = build_request('नमस्ते!', CONFIG, ENV)
        self.assertEqual((r.method,r.url),('POST','https://tts.mayaresearch.ai/v1/tts'))
        self.assertEqual(r.headers, {'Authorization':'Bearer offline-token','Content-Type':'application/json','User-Agent':'tts-arena/0.1'})
        self.assertEqual(r.body, {'model':'Maya Calyx','voice':'Aarav','text':'नमस्ते!','language':'hi','sample_rate':24000,'encoding':'pcm_s16le'})
        self.assertEqual((r.response_mode,r.sample_rate,r.channels,r.encoding),('binary',24000,1,'pcm_s16le'))
        self.assertNotIn('offline-token',str(r.metadata))

    def test_current_languages_and_explicit_auto(self):
        for code in ['en','hi','bn','mr','te','ta','gu','kn','ml','or','pa']:
            with self.subTest(code=code):
                self.assertEqual(build_request('test',dict(CONFIG,language=code+'-IN'),ENV).body['language'],code)
                self.assertEqual(build_request('test',dict(CONFIG,language=code),ENV).body['language'],code)
        self.assertNotIn('language',build_request('कल delivery होगी',dict(CONFIG,language='auto'),ENV).body)
        for code in ['ur-IN','en-US','en-GB','auto-IN','HI','',None]:
            with self.subTest(code=code),self.assertRaises(ValueError):
                build_request('text',dict(CONFIG,language=code),ENV)

    def test_voice_roster_and_legacy_generation_rejection(self):
        for voice in 'Aarav Kabir Rohan Amit Kavita Sagar Arushi Neeraj SagarM Diya Neha Samar Gargi Nila Sana Rahul Rehan Seema Riya Shailika Shreeraj Tarini Tripti Vikas Vikram Zara Riley Christine Jackson Christopher Vance'.split():
            self.assertEqual(build_request('text',dict(CONFIG,voice=voice),ENV).body['voice'],voice)
        for voice in ['Ananya','Arjun','Neha P','aarav','',None]:
            with self.assertRaises(ValueError):build_request('text',dict(CONFIG,voice=voice),ENV)
        for model in ['Maya2Native','Maya 2','maya calyx',None]:
            with self.assertRaises(UnsupportedFeature):build_request('text',dict(CONFIG,model=model),ENV)

    def test_ignored_or_undocumented_controls_rejected(self):
        for key in ['region','seed','speed','emotion','ssml','word_timestamps','endpoint','voice_cloning','flush','cancel']:
            with self.subTest(key=key),self.assertRaises(UnsupportedFeature):
                build_request('text',dict(CONFIG,**{key:True}),ENV)

    def test_formats_and_sample_rate_boundaries(self):
        for rate in (8000,16000,24000):
            for encoding in ('pcm_s16le','mulaw'):
                r=build_request('text',dict(CONFIG,sample_rate=rate,format=encoding),ENV)
                self.assertEqual((r.body['sample_rate'],r.body['encoding']),(rate,encoding))
        for rate in [True,24000.0,44100,0,float('nan'),None]:
            with self.assertRaises(ValueError):build_request('text',dict(CONFIG,sample_rate=rate),ENV)
        for encoding in ['mp3','wav','MULAW','pcm',None]:
            with self.assertRaises(ValueError):build_request('text',dict(CONFIG,format=encoding),ENV)

    def test_explicit_fields_credentials_and_no_mutation(self):
        before=copy.deepcopy(CONFIG)
        build_request('text',CONFIG,ENV)
        self.assertEqual(CONFIG,before)
        for key in CONFIG:
            c=dict(CONFIG);del c[key]
            with self.assertRaises(ValueError):build_request('text',c,ENV)
        for token in [None,'',' ','bad\rheader','bad\nheader','two words']:
            with self.assertRaises(ValueError):build_request('text',CONFIG,{'MAYA_API_KEY':token})
        for text in ['',None,'   ',42]:
            with self.assertRaises(ValueError):build_request(text,CONFIG,ENV)


class MayaHttpResponseTests(unittest.IsolatedAsyncioTestCase):
    async def run_response(self, content_type, body=b'\x01\x00'*24, status=200, config=None):
        def handler(request):
            self.assertEqual(request.url.path,'/v1/tts')
            return httpx.Response(status,headers={'content-type':content_type,'x-request-id':'maya-fixture'},content=body)
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            return await synthesize(build_request('text',config or CONFIG,ENV),client=client)

    async def test_pcm_header_contract_and_request_id(self):
        r,audio=await self.run_response('audio/L16; rate=24000; channels=1')
        self.assertEqual(r['status'],'success')
        self.assertEqual(r['provider_request_id'],'maya-fixture')
        self.assertEqual(r['observed_audio_format']['sample_rate'],24000)
        self.assertEqual(audio,b'\x01\x00'*24)

    async def test_mulaw_header_contract(self):
        r,audio=await self.run_response('audio/basic; rate=8000',b'\xff'*160,config=dict(CONFIG,format='mulaw',sample_rate=8000))
        self.assertEqual(r['status'],'success')
        self.assertEqual(len(audio),160)

    async def test_metadata_mismatch_cannot_be_successful_benchmark(self):
        for header in ['audio/L16; rate=8000; channels=1','audio/L16; rate=24000; channels=2','audio/basic; rate=24000','audio/L16','audio/L16; rate=24000; rate=8000; channels=1','application/json','']:
            with self.subTest(header=header):
                r,audio=await self.run_response(header)
                self.assertEqual(r['status'],'error')
                self.assertFalse(audio)

    async def test_errors_empty_and_truncated_pcm(self):
        for status,body in [(401,b'{"error":"invalid_key"}'),(429,b''),(502,b'{"error":"origin_error"}'),(200,b''),(200,b'\x01')]:
            with self.subTest(status=status,body=body):
                r,_=await self.run_response('audio/L16; rate=24000; channels=1',body,status)
                self.assertEqual(r['status'],'error')
