"""Six no-retry Dubverse candy.two samples matched to existing neo.one texts."""
import asyncio
import json
import os
import sys
from datetime import datetime,timezone
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT=ROOT/'artifacts/runs/dubverse-flagship-20260915'
SUMMARY=ROOT/'artifacts/dubverse-flagship-20260915/summary.json'
CASES=[
 ('en-IN',1194,'Your meeting is tomorrow afternoon.'),
 ('bn-IN',1220,'আপনার সভা আগামীকাল দুপুরে।'),
 ('te-IN',1222,'మీ సమావేశం రేపు మధ్యాహ్నం ఉంది.'),
 ('ta-IN',1224,'உங்கள் கூட்டம் நாளை மதியம் உள்ளது.'),
 ('kn-IN',1226,'ನಿಮ್ಮ ಸಭೆ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಇದೆ.'),
 ('ml-IN',1228,'നിങ്ങളുടെ യോഗം നാളെ ഉച്ചയ്ക്കാണ്.'),
]

async def main():
 if OUT.exists() or SUMMARY.exists():raise RuntimeError('Flagship trial already attempted; no repeat spend')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('DUBVERSE_API_KEY')
 if not key:raise RuntimeError('Authorized Dubverse key absent')
 plans=[]
 for locale,voice,text in CASES:
  config={'model':'candy.two','voice':voice,'language':locale,'format':'wav','audio_streaming':False}
  spec=build_request('dubverse',text,config,{'DUBVERSE_API_KEY':key})
  if len(text)>90 or spec.url!='https://audio.dubverse.ai/api/tts' or 'sample_rate' in spec.body['config']:
   raise ValueError('Flagship request preflight failed')
  plans.append((locale,config,text))
 OUT.mkdir(parents=True);SUMMARY.parent.mkdir(parents=True)
 report={'provider':'dubverse','model':'candy.two','created_at':datetime.now(timezone.utc).isoformat(),
  'request_limit':len(plans),'automatic_retries':0,'text_scope':'Short fictional regional strings identical to saved neo.one locale prompts',
  'native_quality':'unverified','results':[]}
 def save():SUMMARY.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'DUBVERSE_API_KEY':key}))
 save();os.environ['DUBVERSE_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=45,trust_env=False,follow_redirects=False) as client:
   for index,(locale,config,text) in enumerate(plans):
    if index:await asyncio.sleep(2)
    row={'locale':locale,'voice':config['voice'],'text':text,'status':'request_started'}
    report['results'].append(row);save()
    result=await run_one('dubverse',text,config,OUT,timeout=45,client=client,
     scenario_id='dubverse-flagship-'+locale,evaluation_language=locale,
     stratum='matched_neo_candy_model_output',min_free_bytes=300*1024*1024)
    row.update({k:result.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes',
                                         'audio_sha256','duration_seconds','first_audio_ms')})
    save();print(locale,result['status'],result.get('http_status'),flush=True)
    if result['status']!='success':
     report['stopped_after_failure']=True;save();break
 finally:os.environ.pop('DUBVERSE_API_KEY',None)
 report['completed']=True;report['successes']=sum(r['status']=='success' for r in report['results']);save()
 print(json.dumps({'attempts':len(report['results']),'successes':report['successes']}))

if __name__=='__main__':asyncio.run(main())
