"""One bounded Soniox native-stream cancellation probe with synthetic caller onset.

No phone call. Key and raw wire messages are never persisted.
"""
import asyncio
import base64
import hashlib
import json
import shutil
import sys
import time
from pathlib import Path
from uuid import uuid4

import websockets

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials

OUT = ROOT / "artifacts/soniox-cancel-20260915-v2"
FLOOR = 300 * 1024 * 1024
TEXT = "आपकी अगली किस्त पंद्रह सितंबर को देय है। क्या मैं भुगतान लिंक भेज दूँ?"


async def probe():
    if OUT.exists():
        raise RuntimeError("Existing probe evidence; no repeat or additional spend")
    free = shutil.disk_usage(ROOT).free
    if free < FLOOR:
        raise RuntimeError(f"Disk preflight failed: {free} free, {FLOOR} required")
    key = read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env").get("SONIOX_API_KEY")
    if not key:
        raise RuntimeError("No authorized Soniox key")
    sid = "barge-" + uuid4().hex
    started = time.perf_counter()
    now = lambda: round((time.perf_counter() - started) * 1000, 2)
    report = {"schema": "soniox_native_cancel_v1", "provider": "soniox", "model": "tts-rt-v2",
              "voice": "Kavya", "language": "hi-IN", "wire_language": "hi", "sample_rate": 24000,
              "audio_format": "pcm_s16le", "synthetic_caller_onset": True,
              "production_telephony_verified": False, "input_text": TEXT,
              "source": "https://soniox.com/docs/api-reference/tts/websocket-api",
              "client_stream_id": sid, "first_audio_ms": None, "cancel_sent_ms": None,
              "terminated_ms": None, "audio_chunks_before_cancel": 0,
              "audio_chunks_after_cancel": 0, "audio_bytes_before_cancel": 0,
              "audio_bytes_after_cancel": 0, "post_cancel_played_locally": False,
              "errors": [], "network_attempted": False, "status": "not_started"}
    OUT.mkdir(parents=True)
    chunks = []
    try:
        async with websockets.connect("wss://tts-rt.soniox.com/tts-websocket", open_timeout=10,
                                      close_timeout=5, max_size=2 * 1024 * 1024) as ws:
            report["network_attempted"] = True
            await ws.send(json.dumps({"api_key": key, "model": "tts-rt-v2", "language": "hi",
                                      "voice": "Kavya", "audio_format": "pcm_s16le",
                                      "sample_rate": 24000, "stream_id": sid}))
            await ws.send(json.dumps({"text": TEXT, "text_end": True, "stream_id": sid}))
            # Close input promptly per Soniox's stream timeout. First audio marks an active utterance; local caller
            # onset then discards queued PCM and sends Soniox's native cancel action.
            deadline = time.perf_counter() + 25
            while time.perf_counter() < deadline:
                frame = json.loads(await asyncio.wait_for(ws.recv(), timeout=max(0.1, deadline - time.perf_counter())))
                if frame.get("stream_id") != sid:
                    raise ValueError("Unexpected stream ID")
                if frame.get("error_type"):
                    report["errors"].append({"type": frame.get("error_type"), "code": frame.get("error_code")})
                if frame.get("audio"):
                    raw = base64.b64decode(frame["audio"], validate=True)
                    if len(raw) % 2:
                        raise ValueError("Non-16-bit PCM payload")
                    if report["cancel_sent_ms"] is None:
                        chunks.append(raw)
                        report["audio_chunks_before_cancel"] += 1
                        report["audio_bytes_before_cancel"] += len(raw)
                        report["first_audio_ms"] = report["first_audio_ms"] or now()
                        # One callback tick after audio arrival is a reproducible local
                        # interruption point; no telephony stack is implied.
                        report["synthetic_caller_onset_ms"] = now()
                        report["local_playout_stop_ms"] = now()
                        await ws.send(json.dumps({"stream_id": sid, "cancel": True}))
                        report["cancel_sent_ms"] = now()
                    else:
                        report["audio_chunks_after_cancel"] += 1
                        report["audio_bytes_after_cancel"] += len(raw)
                if frame.get("terminated") is True:
                    report["terminated_ms"] = now()
                    break
            report["status"] = "observed_cancelled" if report["first_audio_ms"] is not None and report["cancel_sent_ms"] is not None and report["terminated_ms"] is not None and not report["errors"] else "incomplete"
    except Exception as exc:
        report["status"] = "failed"
        report["exception_type"] = type(exc).__name__
    raw = b"".join(chunks)
    if raw:
        (OUT / "pre_cancel.pcm").write_bytes(raw)
        report["pre_cancel_audio_sha256"] = hashlib.sha256(raw).hexdigest()
        report["pre_cancel_audio_duration_ms"] = round(len(raw) / 48, 2)
    report["native_cancel_ack_ms"] = round(report["terminated_ms"] - report["cancel_sent_ms"], 2) if report["terminated_ms"] is not None and report["cancel_sent_ms"] is not None else None
    (OUT / "result.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ("status", "first_audio_ms", "cancel_sent_ms", "terminated_ms", "native_cancel_ack_ms", "audio_bytes_before_cancel", "audio_bytes_after_cancel", "errors")}))


if __name__ == "__main__":
    asyncio.run(probe())
