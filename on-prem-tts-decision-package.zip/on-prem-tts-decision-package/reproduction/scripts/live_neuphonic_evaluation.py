"""Bounded synthesis after explicitly corrected credential import; original401 retained."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
async def main():
 p=ROOT/'artifacts/access-20260915/neuphonic-corrected.json'
 if p.exists():raise SystemExit('Existing evaluation retained; no automatic retry')
 c=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');d=json.loads((p.parent/'neuphonic-corrected-discovery.json').read_text());assert d['http_status']==200
 result={'provider':'neuphonic','accessed':'2026-09-15','credential_alias':'NEUPHONIC_API_KEY','initial_401_cause':'Initial import was workspace identifier; corrected through actual API-key copy action, not vendor failure','discovery':'artifacts/access-20260915/neuphonic-corrected-discovery.json','backend_model_identity':'Not exposed by discovery; current hosted route selects backend by voice_id, not a pinned model revision','attempts':[],'automatic_retries':0,'quality_status':'not_evaluated'}
 def save():p.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),c)+'\n')
 errors=[]
 async def hook(r):
  if r.status_code>=400:
   await r.aread();errors.append({'status':r.status_code,'message':redact(r.text,c)[:1000]})
 save()
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  os.environ['NEUPHONIC_API_KEY']=c['NEUPHONIC_API_KEY']
  try:
   for lang,name,text,evaluation in [('hi','Priya','नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।','hi-IN'),('en','Aditya','Hello, we have received your payment. Thank you.','en-IN')]:
    voice=next(v for v in d['voices'] if v['name']==name and v['lang_code']==lang)
    config={'voice':voice['id'],'language':lang,'format':'pcm_linear','sample_rate':24000}
    errors.clear();r=await run_one('neuphonic',text,config,ROOT/'artifacts/runs/neuphonic-corrected-20260915',timeout=30,client=client,scenario_id='corrected-access-'+lang,stratum='draft_access_probe',evaluation_language=evaluation)
    a={k:r.get(k) for k in ['run_id','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms']};a.update(config=config,voice_metadata=voice,diagnostics=list(errors));result['attempts'].append(a);save();print(lang,r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
  finally:os.environ.pop('NEUPHONIC_API_KEY',None)
 result['successful_syntheses']=sum(a['status']=='success' for a in result['attempts']);result['current_access']='synthesis_confirmed' if result['successful_syntheses'] else 'synthesis_blocked';save()
if __name__=='__main__':asyncio.run(main())
