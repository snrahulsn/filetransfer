"""Guarded real Codex onboarding qualification in a small isolated source copy."""
import hashlib,json,os,shutil,subprocess,tempfile,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/onboarding-qualification-20260915'
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--model');parser.add_argument('--label',default='default');args=parser.parse_args()
    if args.label not in {'default','gpt55'}:raise ValueError('Unknown qualification label')
    global OUT
    if args.label!='default':OUT=ROOT/('artifacts/onboarding-qualification-20260915-'+args.label)
    if OUT.exists():raise RuntimeError('Existing qualification evidence; no duplicate dispatch')
    OUT.mkdir()
    isolated=Path(tempfile.mkdtemp(prefix='tts-onboard-qualification-'))
    allowed={'.py','.json','.md','.txt','.csv','.wav','.bin'}
    for folder in ['tts_arena','catalog','tests','scripts','docs','corpus','examples']:
        for source in (ROOT/folder).rglob('*'):
            if source.is_file() and source.suffix in allowed and '__pycache__' not in source.parts and source.stat().st_size<2_000_000:
                dest=isolated/source.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
    for name in ['AGENTS.md','IMPLEMENTATION_CONTRACT.md','pyproject.toml','execution_profiles.json']:
        shutil.copyfile(ROOT/name,isolated/name)
    removed=['catalog/inworld.json','tts_arena/adapters/inworld.py','docs/vendors/inworld.md']
    for name in removed:(isolated/name).unlink()
    # Interpreter is reused read-only; no credentials, artifacts, virtualenvs or user config copied.
    interpreter=str(ROOT/'.venv-fish/bin/python3')
    prompt=f'''Add Inworld as a provider using current TTS-2 synchronous HTTP API for Hindi and Indian English. Implement documented speed, instruction, delivery mode and WORD/CHARACTER timestamp controls, preserving the existing generic metadata hook. Research primary docs and create catalog, adapter, dossier and independent tests. This is an isolated reconstruction qualification: existing Inworld tests remain as regression requirements. Do not copy missing implementations from another workspace or inspect personal files. No provider network calls or credentials; public documentation reads only. You have 8 minutes. Run offline validation and full self-test with rtk proxy {interpreter}; this interpreter supplies dependencies, while cwd imports this isolated package. All existing adapters and tests must remain unchanged; new tests may be added. Do not edit shared core. Report any unfinished gate honestly.'''
    argv=['rtk','proxy',interpreter,'-m','tts_arena','onboard',prompt,'--execute','--timeout','600','--output',str(OUT/'execution')]
    if args.model:argv+=['--model',args.model]
    env={k:v for k,v in os.environ.items() if k in {'PATH','HOME','TMPDIR','LANG','LC_ALL','CODEX_HOME'}}
    meta={'isolated_workspace':str(isolated),'removed':removed,'codex_version':'0.144.1','agent_timeout_seconds':600,'provider_calls_authorized':False,'copied_credentials':False,'before_provider_count':len(list((isolated/'catalog').glob('*.json'))),'production_before':{x:hashlib.sha256((ROOT/x).read_bytes()).hexdigest() for x in removed}}
    meta['explicit_model']=args.model
    (OUT/'experiment.json').write_text(json.dumps(meta,indent=2)+'\n')
    with (OUT/'driver.log').open('w') as log:
        result=subprocess.run(argv,cwd=isolated,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    meta['driver_exit_code']=result.returncode
    meta['production_unchanged']=all(hashlib.sha256((ROOT/x).read_bytes()).hexdigest()==digest for x,digest in meta['production_before'].items())
    meta['after_provider_count']=len(list((isolated/'catalog').glob('*.json')))
    (OUT/'experiment.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
