"""Fonada Klone V2 Pro access probe with explicit observed public share ID."""
import asyncio
import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]

async def main(share_id=None):
    creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    key=creds.get('FONADA_API_KEY')
    path=ROOT/'artifacts/access-20260915/fonada.json';path.parent.mkdir(exist_ok=True)
    result=json.loads(path.read_text()) if path.exists() else {'provider':'fonada','model':'klone-v2-pro','checked_at':'2026-09-15',
       'scope':'Short authenticated audio delivery checks; language correctness/naturalness unverified','discovery':[],'runs':[],
       'sources':['https://fonadalabs.ai/docs/text-to-speech/klone-v2-pro','https://fonadalabs.ai/docs/voice-arena'],'automatic_retries':0}
    def save():path.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
    result['credential_present']=bool(key)
    if not key:result['blocker']='credential_missing';save();return
    errors=[]
    async def hook(response):
        if response.status_code>=400:
            await response.aread();errors.append({'http_status':response.status_code,'message':redact(response.text,creds)[:1500]})
    async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={'response':[hook]}) as client:
        if not result['discovery']:
            url='https://api.fonada.ai/v1/voice-clone/languages'
            response=await client.get(url,headers={'Authorization':'Bearer '+key})
            entry={'url':url,'http_status':response.status_code}
            if response.status_code==200:entry['languages']=response.json()
            else:entry['diagnostics']=errors.copy()
            result['discovery'].append(entry);save()
            print('Fonada language discovery HTTP '+str(response.status_code),flush=True)
            if response.status_code>=400:result['blocker']='language_discovery_failed';save();return
        if not share_id:
            result['blocker']='public_share_id_required';result['voice_catalog_note']='Current primary docs direct share-ID discovery to Voice Arena UI; no REST voice-list route was documented. No guessed IDs or fallback model used.';save();return
        if result['runs']:raise SystemExit('Synthesis evidence exists; refusing automatic rerun')
        if len(share_id)!=8 or not share_id.isascii() or not share_id.isalnum():raise ValueError('Invalid share ID')
        result['selected_voice']={'share_id':share_id,'source':'Voice Arena UI observed by root; public voice selection'}
        os.environ['FONADA_API_KEY']=key
        try:
            for language,text in [('hi-IN','नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।'),('en-IN','Hello, we have received your payment. Thank you.'),('ta-IN','வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி.')]:
                assert len(text)<=140
                config={'model':'klone-v2-pro','voice':share_id,'language':language,'format':'wav'}
                errors.clear()
                record=await run_one('fonada',text,config,ROOT/'artifacts/runs/access-20260915/fonada',timeout=30,client=client,scenario_id='access-klone-'+language,stratum='draft_access_probe')
                attempt={k:record.get(k) for k in ['run_id','status','http_status','error_type','language','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms','audio_analysis']}
                attempt.update(config=config,diagnostics=errors.copy(),observed_status='audio_returned' if record['status']=='success' else 'failed',linguistic_accuracy='unverified')
                result['runs'].append(attempt);save();print('Fonada '+language+' '+attempt['observed_status']+' HTTP '+str(record.get('http_status')),flush=True)
                if record['status']!='success':result['blocker']='synthesis_failed';save();break
            result['successful_syntheses']=sum(r['status']=='success' for r in result['runs'])
            if result['successful_syntheses']==3:result.pop('blocker',None)
            save()
        finally:os.environ.pop('FONADA_API_KEY',None)

if __name__=='__main__':asyncio.run(main(sys.argv[1] if len(sys.argv)>1 else None))
