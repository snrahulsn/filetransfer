"""Build a shareable blind Markdown/audio review pack from verified on-prem clips."""
from __future__ import annotations

import hashlib
import json
import random
import shutil
import wave
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "ui/public/evidence/on-prem-report.json"
PACKAGE_ROOT = ROOT / "artifacts/on-prem-blind-review"
PUBLIC = PACKAGE_ROOT / "public"
PRIVATE_KEY = PACKAGE_ROOT / "private-key.json"
STATUS = PACKAGE_ROOT / "package-status.json"
ZIP_PATH = ROOT / "artifacts/on-prem-blind-review.zip"
SEED = 20260916


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def wav_contract(path: Path) -> dict[str, int | float]:
    with wave.open(str(path), "rb") as audio:
        if (audio.getnchannels(), audio.getsampwidth()) != (1, 2) or audio.getframerate() <= 0:
            raise ValueError(f"Blind-review source must be mono PCM16 WAV: {path}")
        frames = audio.getnframes()
        sample_rate = audio.getframerate()
        return {
            "channels": 1,
            "sample_width_bytes": 2,
            "sample_rate_hz": sample_rate,
            "frames": frames,
            "duration_seconds": frames / sample_rate,
        }


def build() -> dict:
    report = json.loads(REPORT.read_text(encoding="utf-8"))
    recordings = []
    for vendor in report["vendors"]:
        for model in vendor["models"]:
            for clip in model["recordings"]:
                source = (ROOT / "ui/public" / clip["audio_url"].lstrip("/")).resolve()
                audio_root = (ROOT / "ui/public/evidence/audio").resolve()
                if not source.is_relative_to(audio_root) or not source.is_file():
                    raise ValueError(f"Unsafe or missing on-prem audio source: {source}")
                contract = wav_contract(source)
                if abs(contract["duration_seconds"] - clip["duration_seconds"]) > 0.001:
                    raise ValueError(f"Reported duration differs from WAV: {source}")
                source_hash = sha256(source)
                identity = f"{vendor['id']}:{model['model']}:{clip['language']}:{source_hash}"
                token = hashlib.sha256(f"{SEED}:{identity}".encode()).hexdigest()[:16]
                recordings.append({
                    "item_id": token,
                    "vendor_id": vendor["id"],
                    "vendor": vendor["name"],
                    "model": model["model"],
                    "model_revision": model["revision"],
                    "language": clip["language"],
                    "voice": clip["voice"],
                    "text": clip["text"],
                    "source_audio": str(source.relative_to(ROOT)),
                    "source_audio_sha256": source_hash,
                    "wav": contract,
                })
    if len(recordings) != report["recording_count"] or len(recordings) < 6:
        raise ValueError("Expected at least the six completed Kokoro, Veena and Maya1 recordings")
    required_models = {"hexgrad/Kokoro-82M", "maya-research/Veena", "maya-research/maya1"}
    if not required_models.issubset({row["model"] for row in recordings}):
        raise ValueError("Required Kokoro, Veena or Maya1 blind-review audio is missing")
    if len({row["item_id"] for row in recordings}) != len(recordings):
        raise ValueError("Anonymous item collision")

    systems = sorted({(row["vendor_id"], row["model"]) for row in recordings})
    random.Random(SEED).shuffle(systems)
    system_codes = {identity: f"System {index:02d}" for index, identity in enumerate(systems, 1)}
    for row in recordings:
        row["system"] = system_codes[(row["vendor_id"], row["model"])]

    if PACKAGE_ROOT.exists():
        shutil.rmtree(PACKAGE_ROOT)
    (PUBLIC / "audio").mkdir(parents=True)
    public_rows = []
    for row in recordings:
        filename = f"sample-{row['item_id']}.wav"
        source = ROOT / row["source_audio"]
        target = PUBLIC / "audio" / filename
        shutil.copy2(source, target)
        if sha256(target) != row["source_audio_sha256"]:
            raise ValueError("Blind audio copy differs from verified source")
        public_rows.append({
            "item_id": row["item_id"],
            "system": row["system"],
            "language": row["language"],
            "text": row["text"],
            "audio": f"audio/{filename}",
            "audio_sha256": row["source_audio_sha256"],
            "duration_seconds": round(row["wav"]["duration_seconds"], 6),
        })
    random.Random(SEED + 1).shuffle(public_rows)

    lines = [
        "# Blind on-prem TTS listening pack",
        "",
        f"This pack contains {len(recordings)} saved outputs from {len(systems)} self-hosted model families. Provider, model, voice and hardware identities are hidden. Reviewers should not receive the separate private key until ratings are frozen.",
        "",
        "> These are unmatched exploratory samples. Prompts, languages, voices and inference conditions differ, so the pack cannot support a fair system ranking or a MOS claim. No qualified listener ratings are included.",
        "",
        "For each sample, play the linked WAV and record a 1–5 naturalness rating plus free-text pronunciation or content notes. Use only reviewers qualified for that sample's language. The reference text is an engineering prompt and has not been certified by a native reviewer.",
        "",
        "| Item | Anonymous system | Language | Reference text | Audio | Naturalness (1–5) | Notes |",
        "|---|---|---|---|---|---|---|",
    ]
    for row in public_rows:
        safe_text = row["text"].replace("|", "\\|").replace("\n", " ")
        lines.append(
            f"| `{row['item_id']}` | {row['system']} | {row['language']} | {safe_text} | "
            f"[play/download]({row['audio']}) |  |  |"
        )
    lines += [
        "",
        "## Rating boundary",
        "",
        "Rate each clip independently. Do not average these rows into a provider comparison. Keep reviewer qualification records and exclusion reasons separately. Native naturalness, accent, intelligibility and entity accuracy remain unverified until qualified listeners assess them.",
        "",
    ]
    (PUBLIC / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (PUBLIC / "manifest.json").write_text(json.dumps({
        "schema": "on_prem_blind_review_public_v1",
        "study_scope": "exploratory_unmatched",
        "items": public_rows,
        "ratings_created": 0,
        "limitations": "Unmatched prompts, languages, voices and inference conditions; no qualified listener ratings.",
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    PRIVATE_KEY.write_text(json.dumps({
        "schema": "on_prem_blind_review_private_key_v1",
        "seed": SEED,
        "items": {row["item_id"]: row for row in recordings},
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    public_text = "\n".join(path.read_text(encoding="utf-8") for path in (PUBLIC / "README.md", PUBLIC / "manifest.json"))
    forbidden = {row["vendor"] for row in recordings} | {row["vendor_id"] for row in recordings} | {row["model"] for row in recordings} | {row["voice"] for row in recordings}
    if any(secret and secret.lower() in public_text.lower() for secret in forbidden):
        raise ValueError("Provider, model or voice identity leaked into public metadata")

    ZIP_PATH.unlink(missing_ok=True)
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(PUBLIC.rglob("*")):
            if path.is_file():
                archive_name = str(Path("on-prem-blind-review") / path.relative_to(PUBLIC))
                info = zipfile.ZipInfo(archive_name, date_time=(2026, 9, 16, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(ZIP_PATH) as archive:
        archived = set(archive.namelist())
        if any("private" in name.lower() for name in archived):
            raise ValueError("Private identity key entered the shareable archive")
        if len([name for name in archived if name.endswith(".wav")]) != len(recordings):
            raise ValueError("Shareable archive audio inventory changed")

    status = {
        "schema": "on_prem_blind_review_package_status_v1",
        "study_scope": "exploratory_unmatched",
        "recordings": len(recordings),
        "anonymous_systems": len(systems),
        "languages": sorted({row["language"] for row in recordings}),
        "copied_wav_hashes_verified": len(recordings),
        "ratings_created": 0,
        "shareable_archive": str(ZIP_PATH.relative_to(ROOT)),
        "shareable_archive_sha256": sha256(ZIP_PATH),
        "private_key": str(PRIVATE_KEY.relative_to(ROOT)),
        "nvidia": ("included" if any(row["vendor_id"] == "nvidia" for row in recordings)
                   else "pending successful live pilot audio"),
    }
    STATUS.write_text(json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(status, ensure_ascii=False, indent=2))
    return status


if __name__ == "__main__":
    build()
