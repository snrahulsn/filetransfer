"""Three Fonada Klone V2 Pro current-spec probes: Hindi speed pair and 8 kHz mu-law.

One pass, no retries, fixed model/share_id/text for speed. Keep raw telephony payload.
"""
import asyncio,json,os,sys,hashlib
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/fonada-feature-20260915';RUNS=ROOT/'artifacts/runs/fonada-feature-20260915'
SOURCE='https://fonadalabs.ai/docs/text-to-speech/klone-v2-pro'
TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
BASE={'model':'klone-v2-pro','voice':'4J4SEQ1X','language':'hi-IN','format':'wav'}
async def main():
 if OUT.exists() or RUNS.exists():raise RuntimeError('Fonada feature evidence already prepared/attempted; no automatic repeat')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');key=secrets.get('FONADA_API_KEY')
 if not key:raise RuntimeError('Authorized Fonada key unavailable')
 variants=[('speed-1.0',dict(BASE,speed=1.0)),('speed-1.4',dict(BASE,speed=1.4)),('telephony-mulaw',dict(BASE,format='mulaw'))]
 for _,cfg in variants:build_request('fonada',TEXT,cfg,{'FONADA_API_KEY':key})
 assert len(TEXT)<90
 OUT.mkdir(parents=True);RUNS.mkdir(parents=True)
 report={'provider':'fonada','model':'klone-v2-pro','voice':'4J4SEQ1X','source':SOURCE,'source_accessed':'2026-09-15','max_requests':3,'automatic_retries':0,'text':TEXT,'estimated_max_characters':3*len(TEXT),'max_documented_credits':.5*3*len(TEXT),'speed_effect':'unverified','native_speed_accuracy':'unverified','telephony_delivery':'unverified','records':[]}
 def save(): (OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',secrets))
 save();os.environ['FONADA_API_KEY']=key
 try:
  for index,(scenario,cfg) in enumerate(variants):
   if index:await asyncio.sleep(7)
   headers=[]
   async def hook(response):
    headers.append({k:response.headers.get(k) for k in ('content-type','x-output-codec','x-processing-time-ms','x-upstream-time-ms')})
   async with httpx.AsyncClient(timeout=40,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
    report['records'].append({'scenario':scenario,'status':'request_started','config':cfg});save()
    r=await run_one('fonada',TEXT,cfg,RUNS,timeout=40,client=client,scenario_id=scenario,evaluation_language='hi-IN',stratum='feature_bounded',min_free_bytes=300*1024*1024)
   row=report['records'][-1];row.update({k:r.get(k) for k in ('run_id','status','http_status','error_type','audio_file','audio_bytes','audio_sha256','duration_seconds','first_audio_ms','request_contract')});row['response_headers']=headers
   if scenario=='telephony-mulaw' and r.get('audio_file'):
    raw=(RUNS/r['run_id']/r['audio_file']).read_bytes();row['raw_payload_bytes']=len(raw);row['raw_payload_sha256']=hashlib.sha256(raw).hexdigest();row['headerless_audio']=not raw.startswith(b'RIFF')
   save();print(scenario,r['status'],r.get('http_status'),flush=True)
   if r['status']!='success':break
  speed=report['records'][:2]
  if len(speed)==2 and all(r['status']=='success' and r.get('duration_seconds') for r in speed):
   a,b=[r['duration_seconds'] for r in speed]
   report['speed_effect']={'baseline_seconds':a,'higher_speed_seconds':b,'duration_ratio':b/a,'direction':'shorter_at_higher_setting' if b<a else 'not_shorter_at_higher_setting','native_speed_accuracy':'unverified'}
  tele=next((r for r in report['records'] if r['scenario']=='telephony-mulaw'),None)
  if tele:report['telephony_delivery']='observed_raw_mulaw' if tele['status']=='success' and tele['headerless_audio'] and tele['response_headers'][0]['x-output-codec']=='mulaw' and tele['raw_payload_bytes']>0 else 'not_confirmed'
  report['complete']=True;save()
 finally:os.environ.pop('FONADA_API_KEY',None)
if __name__=='__main__':asyncio.run(main())
