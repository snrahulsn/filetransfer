"""Bounded one-clip-per-locale evaluation through AI4Bharat's official Space.

This obtains output from the exact published Indic Parler-TTS checkpoint while
gated-weight access is unavailable.  It is model-output evidence, not proof of
our own self-hosted deployment.  The script refuses to overwrite completed
locales and makes at most one generation request per configured locale.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

import httpx


ORIGIN = "https://ai4bharat-indic-parler-tts.hf.space"
API = ORIGIN + "/gradio_api/call/generate_finetuned"

CASES = {
    "en-IN": (
        "Your instalment is fifteen thousand rupees, payable on fifteen September.",
        "Mary speaks in a clear Indian English accent at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official Indian-English claim; recommended English voice",
    ),
    "hi-IN": (
        "आपकी किस्त पंद्रह हज़ार रुपये है और भुगतान पंद्रह सितंबर को करना है।",
        "Divya speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Hindi voice",
    ),
    "bn-IN": (
        "আপনার কিস্তির পরিমাণ পনেরো হাজার টাকা।",
        "Aditi speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Bengali voice",
    ),
    "mr-IN": (
        "तुमच्या हप्त्याची रक्कम पंधरा हजार रुपये आहे.",
        "Sunita speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Marathi voice",
    ),
    "te-IN": (
        "మీ వాయిదా మొత్తం పదిహేను వేల రూపాయలు.",
        "Lalitha speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Telugu voice",
    ),
    "ta-IN": (
        "உங்கள் தவணைத் தொகை பதினைந்தாயிரம் ரூபாய்.",
        "Jaya speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Tamil voice",
    ),
    "gu-IN": (
        "તમારા હપ્તાની રકમ પંદર હજાર રૂપિયા છે.",
        "Neha speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Gujarati voice",
    ),
    "kn-IN": (
        "ನಿಮ್ಮ ಕಂತಿನ ಮೊತ್ತ ಹದಿನೈದು ಸಾವಿರ ರೂಪಾಯಿ.",
        "Anu speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Kannada voice",
    ),
    "ml-IN": (
        "നിങ്ങളുടെ തവണത്തുക പതിനയ്യായിരം രൂപയാണ്.",
        "Anjali speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Malayalam voice",
    ),
    "ur-IN": (
        "آپ کی قسط کی رقم پندرہ ہزار روپے ہے۔",
        "A female Indian speaker speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official language; no recommended Urdu voice is listed in the card table",
    ),
    "or-IN": (
        "ଆପଣଙ୍କ କିସ୍ତି ରାଶି ପନ୍ଦର ହଜାର ଟଙ୍କା।",
        "Debjani speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "official; recommended Odia voice",
    ),
    "pa-IN": (
        "ਤੁਹਾਡੀ ਕਿਸ਼ਤ ਦੀ ਰਕਮ ਪੰਦਰਾਂ ਹਜ਼ਾਰ ਰੁਪਏ ਹੈ।",
        "Gurpreet speaks clearly at a moderate pace with a neutral professional tone. The recording is very high quality with no background noise.",
        "publisher labels Punjabi support unofficial; named voice is listed",
    ),
}


def complete_data(raw: str) -> dict:
    events = []
    for block in raw.split("\n\n"):
        lines = block.splitlines()
        event = next((line[7:] for line in lines if line.startswith("event: ")), None)
        data = next((line[6:] for line in lines if line.startswith("data: ")), None)
        if event and data:
            events.append((event, json.loads(data)))
    finished = [data for event, data in events if event == "complete"]
    if len(finished) != 1 or not isinstance(finished[0], list) or len(finished[0]) != 1:
        raise RuntimeError("Official Space did not return one completed audio item")
    item = finished[0][0]
    if not isinstance(item, dict) or not str(item.get("path", "")).startswith("/tmp/gradio/"):
        raise RuntimeError("Official Space returned an invalid audio file descriptor")
    return item


def duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=nw=1:nk=1", str(path)],
        check=True, capture_output=True, text=True,
    )
    value = float(result.stdout.strip())
    if not 0.2 < value < 120:
        raise ValueError("Generated audio duration outside guard")
    return value


def run(output: Path, *, timeout: float = 240) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    records = []
    with httpx.Client(timeout=timeout, follow_redirects=False, trust_env=False) as client:
        for locale, (text, description, support_note) in CASES.items():
            target = output / f"indic-parler--{locale}.mp3"
            metadata = output / f"indic-parler--{locale}.json"
            if target.exists() or metadata.exists():
                raise FileExistsError(f"Refusing a second output for {locale}: {target}")
            started = time.perf_counter()
            submitted = client.post(API, json={"data": [text, description]})
            submitted.raise_for_status()
            event_id = submitted.json().get("event_id")
            if not isinstance(event_id, str) or len(event_id) < 16:
                raise RuntimeError("Official Space did not return a valid event id")
            events = client.get(API + "/" + event_id)
            events.raise_for_status()
            item = complete_data(events.text)
            file_url = ORIGIN + "/gradio_api/file=" + item["path"]
            audio = client.get(file_url)
            audio.raise_for_status()
            raw = audio.content
            if len(raw) < 4096 or raw.startswith((b"{", b"[")):
                raise RuntimeError("Official Space returned no usable audio bytes")
            target.write_bytes(raw)
            record = {
                "provider": "AI4Bharat",
                "model": "ai4bharat/indic-parler-tts",
                "route": "publisher_official_hugging_face_space",
                "self_hosted_execution": False,
                "language": locale,
                "text": text,
                "description": description,
                "support_note": support_note,
                "audio_file": target.name,
                "audio_bytes": len(raw),
                "audio_sha256": hashlib.sha256(raw).hexdigest(),
                "duration_seconds": duration(target),
                "wall_seconds": time.perf_counter() - started,
                "one_output_per_language": True,
                "quality_certification": "pending_blind_native_review",
            }
            metadata.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
            records.append(record)
            print(json.dumps({"language": locale, "duration_seconds": record["duration_seconds"],
                              "wall_seconds": round(record["wall_seconds"], 2)}), flush=True)
    suite = {
        "schema": "official_indic_parler_suite_v1",
        "model": "ai4bharat/indic-parler-tts",
        "route": "publisher_official_hugging_face_space",
        "scope": "exact-model output evidence; not our self-hosted deployment proof",
        "recording_count": len(records),
        "languages": list(CASES),
        "records": records,
    }
    (output / "suite.json").write_text(json.dumps(suite, ensure_ascii=False, indent=2) + "\n")
    return suite


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path("artifacts/on-prem-candidates/indic-parler"))
    args = parser.parse_args()
    result = run(args.output)
    print(json.dumps({"recording_count": result["recording_count"],
                      "languages": result["languages"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
