"""Exactly two authorized Hindi pause variants, synchronous TTS-2; guarded against repeats."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
from scripts.live_feature_pairs import outcome
OUT=Path(__file__).resolve().parents[1]/'artifacts/inworld-pause-20260915'
TEXT='मैंने आपकी बात सुन ली है। अब हम आगे की योजना पर बात करेंगे।'
BASE=dict(model='inworld-tts-2',voice='Meher',language='hi-IN',format='WAV',sample_rate=24000,delivery_mode='BALANCED')
INSTRUCTIONS=['baseline','one_second_break']
TEXTS=[TEXT,TEXT.replace('है। अब','है। <break time="1s" /> अब')]
async def main():
 if OUT.exists():raise RuntimeError('Evidence guard exists; no repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');os.environ['INWORLD_API_KEY']=secrets['INWORLD_API_KEY']
 for text in TEXTS:build_request('inworld',text,BASE)
 OUT.mkdir(exist_ok=False);report={'max_requests':2,'attempts':0,'no_retries':True,'text':TEXT,'base_config':BASE,'variants':INSTRUCTIONS,'texts':TEXTS,'records':[],'diagnostics':[],'emotional_accuracy':'unverified'}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n')
 save()
 async def hook(response):
  if response.status_code>=400:report['diagnostics'].append({'http_status':response.status_code,'message':redact((await response.aread())[:3000].decode('utf8','replace'),secrets)})
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  for instruction,text in zip(INSTRUCTIONS,TEXTS):
   report['attempts']+=1;save()
   r=await run_one('inworld',text,BASE,OUT/'runs',timeout=30,client=client,evaluation_language='hi-IN',scenario_id='inworld_instruction_pair',stratum='paired_control')
   record={k:r.get(k) for k in ['run_id','provider','text','config','status','http_status','duration_seconds','audio_sha256','audio_bytes','error_type','provider_usage']};record['result_file']=str(OUT/'runs'/r['run_id']/'result.json');report['records'].append(record);save();print(r['status'],r.get('http_status'),flush=True)
   if r['status']!='success':break
 if len(report['records'])==2 and all(r['status']=='success' for r in report['records']):
  from scripts.pause_diagnostics import silence_gaps
  report['diagnostic_parameters']={'threshold_dbfs':-40,'window_ms':10,'minimum_gap_ms':80}
  for record in report['records']:
   f=Path(record['result_file']);raw=json.loads(f.read_text());record['silence_diagnostics']=silence_gaps(f.parent/raw['audio_file'])
  a,b=[r['silence_diagnostics']['longest_internal_gap_seconds'] for r in report['records']]
  report['outcome']={'longest_internal_gap_seconds':[a,b],'difference_seconds':b-a,'direction':'longer_with_break' if b>a else 'not_longer','requested_break_seconds':1,'semantic_alignment':'not_performed','ssml_certification':'not_certified'}
 report['complete']=True;save()
if __name__=='__main__':asyncio.run(main())
