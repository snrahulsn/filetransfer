"""Three bounded Soniox v2 controls: same-text Hindi tone pair and code mix."""
import asyncio
import json
import os
import sys
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT=ROOT/'artifacts/runs/soniox-controls-20260915'
MANIFEST=ROOT/'artifacts/soniox-controls-20260915/manifest.json'
CASES=[
 ('hi-IN','soniox-hindi-calm','[calm] आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'),
 ('hi-IN','soniox-hindi-excited','[excited] आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'),
 ('hi-IN','soniox-hindi-code-mix','नमस्ते, आपकी EMI payment कल due है। Please confirm the amount.'),
]

async def main():
 if OUT.exists() or MANIFEST.exists():raise RuntimeError('Existing control evidence; no repeat spend')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('SONIOX_API_KEY')
 if not key:raise RuntimeError('No authorized Soniox key')
 config={'model':'tts-rt-v2','voice':'Kavya','language':'hi-IN','format':'wav','sample_rate':24000,'region':'global'}
 for _,_,text in CASES:build_request('soniox',text,config,{'SONIOX_API_KEY':key})
 OUT.mkdir(parents=True);MANIFEST.parent.mkdir(parents=True)
 report={'provider':'soniox','model':'tts-rt-v2','voice':'Kavya','region':'global','request_limit':3,'retries':0,'native_emotion_accuracy':'unverified','native_code_mix_accuracy':'unverified','samples':[]}
 def save():MANIFEST.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'SONIOX_API_KEY':key}))
 save();os.environ['SONIOX_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   for locale,scenario,text in CASES:
    run=await run_one('soniox',text,config,OUT,timeout=35,client=client,scenario_id=scenario,evaluation_language=locale,stratum='soniox_control_probe',min_free_bytes=300*1024*1024)
    report['samples'].append({k:run.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','first_audio_ms')});save()
    print(scenario,run['status'],run.get('http_status'),flush=True)
    if run['status']!='success':break
    await asyncio.sleep(.5)
 finally:os.environ.pop('SONIOX_API_KEY',None)
 report['completed']=True;save()

if __name__=='__main__':asyncio.run(main())
