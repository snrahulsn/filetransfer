"""Explicitly bounded live access smoke probes. Never logs credential values."""
import asyncio
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials, redact
from tts_arena.runner import run_one

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'artifacts/access-20260915'
KEYS = {'sarvam':'SARVAM_API_KEY','smallest':'SMALLEST_API_KEY','gnani':'GNANI_API_KEY_ID','murf':'MURF_API_KEY'}
TEXT = {'hi-IN':'नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।',
        'en-IN':'Hello, we have received your payment. Thank you.',
        'ta-IN':'வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி.'}
SOURCES = {
 'sarvam':['https://docs.sarvam.ai/api-reference/text-to-speech/convert'],
 'smallest':['https://docs.smallest.ai/models/documentation/text-to-speech-lightning/voices-languages'],
 'gnani':['https://docs.gnani.ai/api/TTS/available-voices','https://docs.gnani.ai/api/TTS/tts-inference'],
 'murf':['https://murf.ai/api/docs/api-reference/voices/get-voices','https://murf.ai/api/docs/api-reference/text-to-speech/stream']}

async def main(selected):
    creds = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    OUT.mkdir(parents=True, exist_ok=True)
    for provider in selected:
        target = OUT / (provider+'.json')
        if target.exists():
            print(provider+': existing results retained; refusing automatic rerun')
            continue
        result = {'provider':provider,'accessed':'2026-09-15','sources':SOURCES[provider],
                  'scope':'Short live synthesis/access smoke tests only; no quality, load, billing or feature certification',
                  'credential_present':bool(creds.get(KEYS[provider])), 'discovery':[], 'attempts':[]}
        def save():
            target.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
        if not result['credential_present']:
            result['blocker']='credential_missing'; save(); continue
        os.environ[KEYS[provider]]=creds[KEYS[provider]]
        diagnostics=[]
        async def hook(response):
            if response.status_code>=400:
                # Only error responses are buffered; successful streaming timing is untouched.
                await response.aread()
                diagnostics.append({'http_status':response.status_code,'message':redact(response.text,creds)[:1500]})
        async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={'response':[hook]}) as client:
            configs=[]
            if provider=='sarvam':
                configs=[{'model':'bulbul:v3','voice':'shubh','language':lang,'format':'wav','sample_rate':24000} for lang in TEXT]
            elif provider=='gnani':
                configs=[{'model':'timbre-v2.5','voice':voice,'language':lang,'format':'wav','sample_rate':24000} for lang,voice in [('hi-IN','Nalini'),('en-IN','Kaveri'),('ta-IN','Asmita')]]
            else:
                url = 'https://api.smallest.ai/waves/v1/lightning-v3.1/get_voices' if provider=='smallest' else 'https://api.murf.ai/v1/speech/voices?model=falcon-2'
                headers = {'Authorization':'Bearer '+creds[KEYS[provider]]} if provider=='smallest' else {'api-key':creds[KEYS[provider]]}
                try:
                    response=await client.get(url,headers=headers)
                    discovery={'url':url,'http_status':response.status_code}
                    result['discovery'].append(discovery)
                    if response.status_code>=400:
                        discovery['diagnostic']=diagnostics[-1]; result['blocker']='voice_discovery_failed'; save(); continue
                    payload=response.json()
                    voices=payload.get('voices',[]) if isinstance(payload,dict) else payload
                    discovery['voice_count']=len(voices)
                    if provider=='smallest':
                        discovery['selected_voice_metadata']=[v for v in voices if v.get('voiceId') in ('sunidhi','rajeshwari')]
                        configs=[{'model':'lightning_v3.1','voice':voice,'language':lang,'format':'wav','sample_rate':24000} for lang,voice in [('hi-IN','sunidhi'),('en-IN','sunidhi'),('ta-IN','rajeshwari')]]
                    else:
                        discovery['selected_voice_metadata']=[]
                        for lang in TEXT:
                            candidates=[v for v in voices if v.get('locale')==lang]
                            if not candidates: candidates=[v for v in voices if lang in v.get('supportedLocales',{})]
                            if not candidates:
                                result.setdefault('unavailable_locales',[]).append(lang); continue
                            chosen=candidates[0]
                            discovery['selected_voice_metadata'].append(chosen)
                            configs.append({'model':'falcon-2','voice':chosen['voiceId'],'language':lang,'format':'WAV','sample_rate':24000,'region':'in'})
                except Exception as exc:
                    result['blocker']='discovery_transport_or_schema'; result['error_type']=type(exc).__name__; save(); continue
            for config in configs[:3]:
                diagnostics.clear()
                record=await run_one(provider,TEXT[config['language']],config,ROOT/'artifacts/runs/access-20260915'/provider,timeout=30,client=client,scenario_id='access-smoke-'+config['language'],stratum='draft_access_probe')
                attempt={k:record.get(k) for k in ['run_id','status','http_status','error_type','language','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms']}
                attempt['config']=config
                if diagnostics: attempt['diagnostics']=diagnostics.copy()
                result['attempts'].append(attempt); save()
                print(provider+' '+config['language']+': '+record['status']+' HTTP '+str(record.get('http_status')),flush=True)
                if record['status']!='success':
                    result['blocker']='synthesis_failed'; break
        result['successful_syntheses']=sum(a['status']=='success' for a in result['attempts'])
        save()
        os.environ.pop(KEYS[provider],None)

if __name__=='__main__':
    chosen=sys.argv[1:] or list(KEYS)
    if any(p not in KEYS for p in chosen): raise SystemExit('Unknown provider')
    asyncio.run(main(chosen))
