"""One capped Falcon 2 socket: old Hindi turn, clear, then new Hindi turn."""
import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.session_runner import run_session
from tts_arena.sessions import murf

FOLDER = ROOT / 'artifacts/murf-clear-recovery-20260916'
GUARD = FOLDER / 'attempt.started'
MANIFEST = FOLDER / 'manifest.json'
CONFIG = {'model': 'falcon-2', 'voice': 'hi-IN-khyati', 'language': 'hi-IN',
          'format': 'WAV', 'sample_rate': 24000, 'region': 'global', 'context_id': 'old-turn'}
OLD = 'नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
NEW = 'ठीक है, नई बैठक शुक्रवार को चार बजे रख दी गई है।'
ACTIONS = [
    {'at_ms': 0, 'type': 'text', 'context_id': 'old-turn', 'text': OLD, 'end': False},
    {'at_ms': 900, 'type': 'cancel', 'context_id': 'old-turn'},
    {'at_ms': 1000, 'type': 'text', 'context_id': 'new-turn', 'text': NEW, 'end': True},
]


async def main():
    if GUARD.exists() or MANIFEST.exists():
        raise RuntimeError('Murf clear/recovery attempt already started; no retry')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    secret = credentials.get('MURF_API_KEY')
    if not secret:
        raise RuntimeError('Authorized Murf API key missing')
    env = {'MURF_API_KEY': secret}
    spec = murf.build_session(CONFIG, env)
    if len(ACTIONS) != 3 or len(OLD) + len(NEW) >= 150 or spec.sample_rate != 24000:
        raise RuntimeError('Unreviewed bounded Murf scenario')
    for action in ACTIONS:
        murf.encode_action(action, CONFIG)
    FOLDER.mkdir(parents=True, exist_ok=True)
    GUARD.write_text('One live socket, two short Hindi texts, one clear, zero retries.\n')
    result = await run_session('murf', CONFIG, ACTIONS, FOLDER / 'sessions', seconds=18, env=env)
    events = result['events']
    cancel = next((e['elapsed_ms'] for e in events if e['event_type'] == 'action_sent' and
                   e.get('action_type') == 'cancel' and e.get('context_id') == 'old-turn'), None)
    contexts = {}
    for context in ('old-turn', 'new-turn'):
        audio = [e for e in events if e['event_type'] == 'audio_payload_received' and
                 e.get('context_id') == context]
        final = [e for e in events if e['event_type'] == 'provider_event' and
                 e.get('details', {}).get('type') == 'done' and
                 e.get('details', {}).get('context_id') == context]
        contexts[context] = {'audio_payloads': len(audio), 'final_events': len(final),
                             'first_audio_ms': audio[0]['elapsed_ms'] if audio else None,
                             'last_audio_ms': audio[-1]['elapsed_ms'] if audio else None,
                             'audio_after_clear_payloads': sum(cancel is not None and
                                                               e['elapsed_ms'] > cancel for e in audio)
                             if context == 'old-turn' else None}
    audit = {'provider': 'murf', 'model': 'falcon-2', 'language': 'hi-IN',
             'transport': 'native_websocket', 'retries': 0, 'socket_limit': 1,
             'text_request_limit': 2, 'clear_request_limit': 1,
             'old_text': OLD, 'new_text': NEW, 'actions': ACTIONS,
             'result_path': str(Path(result['result_file']).relative_to(ROOT)),
             'status': result['status'], 'error_type': result['error_type'],
             'sent_action_count': result['sent_action_count'],
             'cancel_sent_ms': cancel, 'contexts': contexts,
             'boundary': 'received WebSocket payload and scheduled clear; no caller VAD or phone playout',
             'documented_clear_scope': 'pending synthesis only; audio already generating can continue',
             'source': 'https://murf.ai/api/docs/text-to-speech/web-sockets/context-id'}
    MANIFEST.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: audit[k] for k in ('status', 'error_type', 'sent_action_count',
                                          'cancel_sent_ms', 'contexts')}, ensure_ascii=False))


if __name__ == '__main__':
    asyncio.run(main())
