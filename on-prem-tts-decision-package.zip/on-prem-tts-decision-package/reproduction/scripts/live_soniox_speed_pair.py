"""Two bounded Soniox Hindi speed-control requests, same voice/text/settings."""
import asyncio
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT = ROOT / 'artifacts/soniox-speed-20260916'
TEXT = 'नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
BASE = {'model': 'tts-rt-v2', 'voice': 'Kavya', 'language': 'hi-IN',
        'format': 'wav', 'sample_rate': 24000, 'region': 'global'}
SPEEDS = (0.85, 1.15)
SOURCE = 'https://soniox.com/docs/tts/concepts/speech-speed'


async def main():
    if OUT.exists():
        raise RuntimeError('Soniox speed evidence exists; no repeat')
    if len(TEXT) >= 90:
        raise ValueError('Prompt exceeds bounded test')
    secrets = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    token = secrets.get('SONIOX_API_KEY')
    if not token:
        raise RuntimeError('Authorized Soniox credential missing')
    plans = []
    for speed in SPEEDS:
        config = dict(BASE, speed=speed)
        spec = build_request('soniox', TEXT, config, {'SONIOX_API_KEY': token})
        if spec.body.get('speed') != speed or spec.body.get('text') != TEXT:
            raise ValueError('Soniox speed request contract differs')
        plans.append(config)
    OUT.mkdir(parents=True, exist_ok=False)
    report = {'schema': 'soniox_speed_pair_v1', 'provider': 'soniox', 'model': BASE['model'],
              'voice': BASE['voice'], 'language': BASE['language'], 'text': TEXT,
              'configs': plans, 'source': SOURCE, 'max_requests': 2,
              'automatic_retries': 0, 'attempts': [], 'completed': False,
              'boundary': 'One Hindi prompt and built-in voice; request/output control only, no perceptual or speed-fidelity certification.'}
    summary = OUT / 'summary.json'

    def save():
        summary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

    save()
    os.environ['SONIOX_API_KEY'] = token
    try:
        for config in plans:
            entry = {'requested_speed': config['speed'], 'status': 'request_started'}
            report['attempts'].append(entry)
            save()
            result = await run_one('soniox', TEXT, config, OUT / 'runs', timeout=35,
                                   scenario_id='soniox-speed-hi', evaluation_language='hi-IN',
                                   stratum='speed_paired_control', min_free_bytes=300*1024*1024)
            entry.update({key: result.get(key) for key in ('run_id', 'status', 'http_status', 'error_type',
                                                           'duration_seconds', 'audio_sha256', 'audio_bytes')})
            entry['result_path'] = str((OUT / 'runs' / result['run_id'] / 'result.json').relative_to(ROOT))
            if result.get('audio_file'):
                path = OUT / 'runs' / result['run_id'] / result['audio_file']
                entry['saved_audio_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
            save()
            print(json.dumps({key: entry.get(key) for key in ('requested_speed', 'status',
                                                               'http_status', 'duration_seconds')}), flush=True)
            if result['status'] != 'success':
                break
    finally:
        os.environ.pop('SONIOX_API_KEY', None)
    if len(report['attempts']) == 2 and all(row['status'] == 'success' for row in report['attempts']):
        a, b = report['attempts']
        report['paired_output'] = {'duration_ratio_high_over_low': b['duration_seconds'] / a['duration_seconds'],
                                   'shorter_at_higher_speed': b['duration_seconds'] < a['duration_seconds'],
                                   'wav_hashes_differ': a['audio_sha256'] != b['audio_sha256'],
                                   'qualifies_native_speed_effect': False}
    report['completed'] = True
    save()
    print(json.dumps({'requests': len(report['attempts']), 'paired_output': report.get('paired_output')}))


if __name__ == '__main__':
    asyncio.run(main())
