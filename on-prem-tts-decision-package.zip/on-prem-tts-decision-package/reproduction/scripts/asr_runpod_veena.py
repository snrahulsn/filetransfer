"""Three bounded ASR diagnostics for generated Veena smoke WAVs."""
import hashlib
import json
from pathlib import Path

from sarvam_saaras_v3_asr import read_key, request_one

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "artifacts/runpod/veena-20260915"
CASES = (
    ("veena-hi-IN-kavya", "verbatim"),
    ("veena-en-IN-agastya", "verbatim"),
    ("veena-hi-en-maitri", "codemix"),
)


def main():
    key = read_key()
    observations = []
    for stem, mode in CASES:
        record = json.loads((SOURCE / (stem + ".json")).read_text(encoding="utf-8"))
        audio = (SOURCE / (stem + ".wav")).read_bytes()
        if len(audio) > 200_000 or not audio.startswith(b"RIFF"):
            raise ValueError("Unexpected Veena audio payload")
        result = request_one(audio, stem + ".wav", mode, key)
        observations.append({
            "case": stem,
            "model": record["model"],
            "requested_language": record["language"],
            "draft_input_text": record["text"],
            "audio_sha256": hashlib.sha256(audio).hexdigest(),
            "asr_engine": "sarvam.saaras:v3." + mode,
            "detected_language": result["language_code"],
            "asr_transcript": result["transcript"],
            "native_reviewed": False,
            "quality_certified": False,
        })
    output = SOURCE / "asr-diagnostics.json"
    output.write_text(json.dumps({"schema":"veena_asr_smoke_v1","observations":observations}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"requests":len(observations),"detected_languages":[r["detected_language"] for r in observations],"saved":str(output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
