"""One current-model CAMB regional pass: at most eight locales, no retry."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/runs/camb-regional-20260915'
MANIFEST=ROOT/'artifacts/camb-regional-20260915/manifest.json'
PROMPTS=[('bn-IN','নমস্কার, আপনার পেমেন্ট পাওয়া গেছে। ধন্যবাদ।'),('mr-IN','नमस्कार, तुमचे पेमेंट मिळाले आहे. धन्यवाद।'),('te-IN','నమస్కారం, మీ చెల్లింపు అందింది. ధన్యవాదాలు.'),('ta-IN','வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி.'),('gu-IN','નમસ્તે, તમારી ચુકવણી મળી ગઈ છે. આભાર.'),('kn-IN','ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು.'),('ml-IN','നമസ്കാരം, നിങ്ങളുടെ പണം ലഭിച്ചു. നന്ദി.'),('ur-IN','آپ کی قسط کی رقم ₹15,000 ہے۔')]
BASE={'model':'mars-instruct','voice':170924,'format':'wav','user_instructions':'Warm, cheerful and enthusiastic.'}

async def main():
 if OUT.exists() or MANIFEST.exists():raise RuntimeError('Existing CAMB regional batch; no repeat')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('CAMB_API_KEY')
 if not key:raise RuntimeError('No authorized CAMB key')
 for locale,text in PROMPTS:build_request('camb',text,{**BASE,'language':locale},{'CAMB_API_KEY':key})
 OUT.mkdir(parents=True);MANIFEST.parent.mkdir(parents=True)
 report={'provider':'camb','model':'mars-instruct','voice':170924,'region':'vendor_default','limit':8,'retries':0,'native_language_quality':'unverified','voice_cross_language_quality':'unverified','samples':[]}
 def save():MANIFEST.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'CAMB_API_KEY':key}))
 save();os.environ['CAMB_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   for locale,text in PROMPTS:
    r=await run_one('camb',text,{**BASE,'language':locale},OUT,timeout=35,client=client,scenario_id='payment-'+locale,evaluation_language=locale,stratum='regional_delivery_bounded',min_free_bytes=300*1024*1024)
    report['samples'].append({k:r.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms')});report['samples'][-1]['locale']=locale;save()
    print(locale,r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
    await asyncio.sleep(.5)
 finally:os.environ.pop('CAMB_API_KEY',None)
 report['completed']=True;save()

if __name__=='__main__':asyncio.run(main())
