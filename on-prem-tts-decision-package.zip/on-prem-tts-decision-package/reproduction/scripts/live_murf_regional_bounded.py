"""Six Falcon 2 locales with authenticated voice eligibility; no Urdu fallback."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/runs/murf-regional-20260915'
MANIFEST=ROOT/'artifacts/murf-regional-20260915/manifest.json'
DISCOVERY=ROOT/'artifacts/murf-falcon-discovery-20260915.json'
PROMPTS=[('bn-IN','নমস্কার, আপনার পেমেন্ট পাওয়া গেছে। ধন্যবাদ।'),('mr-IN','नमस्कार, तुमचे पेमेंट मिळाले आहे. धन्यवाद।'),('te-IN','నమస్కారం, మీ చెల్లింపు అందింది. ధన్యవాదాలు.'),('gu-IN','નમસ્તે, તમારી ચુકવણી મળી ગઈ છે. આભાર.'),('kn-IN','ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು.'),('ml-IN','നമസ്കാരം, നിങ്ങളുടെ പണം ലഭിച്ചു. നന്ദി.')]

async def main():
 if OUT.exists() or MANIFEST.exists():raise RuntimeError('Existing Murf regional batch; no repeat')
 discovery=json.loads(DISCOVERY.read_text())
 if discovery['http_status']!=200 or set(discovery['selected'])!={l for l,_ in PROMPTS} or 'ur-IN' in discovery['selected']:raise RuntimeError('Unreviewed Falcon voice discovery')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('MURF_API_KEY')
 if not key:raise RuntimeError('No authorized Murf key')
 configs=[{'model':'falcon-2','voice':discovery['selected'][locale]['voice_id'],'language':locale,'format':'WAV','sample_rate':24000,'region':'in'} for locale,_ in PROMPTS]
 for (_,text),config in zip(PROMPTS,configs):build_request('murf',text,config,{'MURF_API_KEY':key})
 OUT.mkdir(parents=True);MANIFEST.parent.mkdir(parents=True)
 report={'provider':'murf','model':'falcon-2','region':'in','request_limit':6,'retries':0,'ur_IN':'no_eligible_Falcon_2_voice_in_authenticated_catalog; no synthesis request','native_quality':'unverified','samples':[]}
 def save():MANIFEST.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'MURF_API_KEY':key}))
 save();os.environ['MURF_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   for (locale,text),config in zip(PROMPTS,configs):
    r=await run_one('murf',text,config,OUT,timeout=35,client=client,scenario_id='payment-'+locale,evaluation_language=locale,stratum='regional_delivery_bounded',min_free_bytes=300*1024*1024)
    report['samples'].append({k:r.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms')});report['samples'][-1].update(locale=locale,voice=config['voice']);save()
    print(locale,config['voice'],r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
    await asyncio.sleep(.5)
 finally:os.environ.pop('MURF_API_KEY',None)
 report['completed']=True;save()

if __name__=='__main__':asyncio.run(main())
