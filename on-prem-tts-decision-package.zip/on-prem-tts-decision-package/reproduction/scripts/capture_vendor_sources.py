"""Archive primary source bodies with bounded reads; preserve failures rather than invent evidence."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
from urllib.request import Request,urlopen

ROOT=Path(__file__).resolve().parent.parent
def capture(job):
    provider,source=job
    destination=ROOT/"vendor_evidence"/provider
    destination.mkdir(parents=True,exist_ok=True)
    record={"provider":provider,"source_id":source["id"],"url":source["url"],"captured_at":datetime.now(timezone.utc).isoformat()}
    try:
        request=Request(source["url"],headers={"User-Agent":"TTS-Arena-Spec-Research/0.1"})
        with urlopen(request,timeout=20) as response:
            data=response.read(4_000_001)
            if len(data)>4_000_000: raise ValueError("Source exceeds4MB capture bound")
            record.update(status=response.status,final_url=response.url,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
            path=destination/(source["id"]+"-"+record["sha256"][:16]+".snapshot")
            path.write_bytes(data);record["file"]=str(path.relative_to(ROOT))
    except Exception as exc:
        record.update(status="capture_failed",error_type=type(exc).__name__)
    return record

jobs=[]
for path in sorted((ROOT/"catalog").glob("*.json")):
    item=json.loads(path.read_text())
    jobs.extend((item["id"],s) for s in item["sources"])
with ThreadPoolExecutor(max_workers=8) as pool:
    result=list(pool.map(capture,jobs))
(ROOT/"vendor_evidence"/"manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"sources":len(result),"captured":sum(isinstance(r["status"],int) for r in result),"failed":sum(r["status"]=="capture_failed" for r in result)}))
