"""One-shot, read-only account-cost evidence probe.

This script intentionally knows only the documented ElevenLabs usage endpoint.
It reads the pre-existing, explicitly named local credential file without
printing it, makes one request with no retry, and saves a whitelist-only
summary.  Other providers are recorded as not attempted when their public
documentation did not specify an API-key-readable account-cost endpoint.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tts_arena.credentials import read_credentials, redact


OUT = ROOT / "artifacts" / "account-cost-20260916"
CREDENTIAL_FILE = "/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env"
ELEVEN_USAGE_URL = "https://api.elevenlabs.io/v1/workspace/analytics/query/usage-by-product-over-time"


def utc_ms(year: int, month: int, day: int) -> int:
    return int(datetime(year, month, day, tzinfo=timezone.utc).timestamp() * 1000)


def safe_rows(value):
    """Retain documented aggregate table values but cap response size."""
    if not isinstance(value, list):
        return []
    result = []
    for row in value[:100]:
        if isinstance(row, list):
            result.append(row[:20])
    return result


def elevenlabs_usage(credentials: dict[str, str]) -> dict:
    key = credentials.get("ELEVENLABS_API_KEY")
    now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    payload = {
        "start_time": utc_ms(2026, 9, 1),
        "end_time": now_ms,
        "interval_seconds": 2678400,
        "group_by": ["product"],
    }
    result = {
        "provider": "elevenlabs",
        "endpoint": ELEVEN_USAGE_URL,
        "source": "https://elevenlabs.io/docs/api-reference/analytics/workspace/usage",
        "request_method": "POST",
        "request_count": 0,
        "automatic_retries": 0,
        "request_window_utc": {"start_time": payload["start_time"], "end_time": payload["end_time"]},
        "read_only_intent": "workspace aggregate usage export",
        "observed_at": datetime.now(timezone.utc).isoformat(),
    }
    if not key:
        result.update({"outcome": "not_attempted", "reason": "authorized credential file lacks ELEVENLABS_API_KEY"})
        return result
    request = Request(
        ELEVEN_USAGE_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"xi-api-key": key, "Content-Type": "application/json"},
        method="POST",
    )
    result["request_count"] = 1
    try:
        with urlopen(request, timeout=20) as response:
            body = json.loads(response.read().decode("utf-8"))
            result.update({
                "outcome": "http_response",
                "http_status": response.status,
                "columns": body.get("columns") if isinstance(body, dict) else None,
                "column_types": body.get("column_types") if isinstance(body, dict) else None,
                "column_units": body.get("column_units") if isinstance(body, dict) else None,
                "rows": safe_rows(body.get("rows")) if isinstance(body, dict) else [],
                "money_cost_verified": False,
                "limitation": "Usage/credit aggregate only; no invoice allocation or usable generated-minute denominator.",
            })
    except HTTPError as error:
        result.update({"outcome": "http_error", "http_status": error.code, "error": redact(error.read().decode("utf-8", "replace")[:1000], credentials)})
    except (URLError, TimeoutError, ValueError) as error:
        result.update({"outcome": "transport_or_parse_error", "error_type": type(error).__name__, "error": redact(str(error)[:1000], credentials)})
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=False)
    credentials = read_credentials(CREDENTIAL_FILE)
    eleven = elevenlabs_usage(credentials)
    documented = {
        "sarvam": {
            "status": "not_attempted",
            "reason": "Official billing documentation names dashboard Settings → Usage and Billing, but no API-key account-cost read endpoint was documented.",
            "source": "https://docs.sarvam.ai/api/platform/billing",
        },
        "smallest": {
            "status": "not_attempted",
            "reason": "Official documentation exposes subscription/credits in the account dashboard; no API-key account-cost read endpoint was identified.",
            "source": "https://docs.smallest.ai/voice-agents/platform/account/subscription-plans",
        },
        "fonada": {
            "status": "not_attempted",
            "reason": "No official API-key account-cost read endpoint was identified; existing studio credit observations disagree and are not reconciled billing evidence.",
            "source": "https://fonadalabs.ai/docs/text-to-speech",
        },
        "cartesia": {
            "status": "not_attempted",
            "reason": "Cartesia's official API index documents API-key-authenticated service endpoints and pricing, but no account-cost/usage endpoint was identified.",
            "source": "https://docs.cartesia.ai/llms.txt",
        },
        "google": {
            "status": "not_attempted",
            "reason": "The authorized file has GOOGLE_API_KEY but no GOOGLE_ACCESS_TOKEN. Cloud Billing reads require OAuth billing/cloud-platform scopes, not a Gemini API key.",
            "source": "https://cloud.google.com/billing/docs/reference/rest/v1/services.skus/list",
        },
    }
    summary = {
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "scope": "One documented, authenticated, read-only usage export; no synthesis, purchase, account mutation, or retries.",
        "credential_presence_only": {name: bool(credentials.get(name)) for name in (
            "SARVAM_API_KEY", "SMALLEST_API_KEY", "ELEVENLABS_API_KEY", "FONADA_API_KEY",
            "CARTESIA_API_KEY", "GOOGLE_API_KEY", "GOOGLE_ACCESS_TOKEN",
        )},
        "elevenlabs": eleven,
        "other_routes": documented,
    }
    (OUT / "account-cost-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
