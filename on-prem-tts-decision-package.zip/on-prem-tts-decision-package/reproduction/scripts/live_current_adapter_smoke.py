"""One current-adapter Hindi request each for Google Gemini and Murf Falcon 2."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/current-adapter-smoke-20260915';RUNS=ROOT/'artifacts/runs/current-adapter-smoke-20260915'
TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया पुष्टि करें।'
PROFILES={
 'google':{'key':'GOOGLE_API_KEY','config':{'model':'gemini-3.1-flash-tts-preview','voice':'Kore','language':'hi-IN','language_mode':'auto','format':'pcm_s16le','instructions':'Read the following Hindi text naturally. Read only the text, not these instructions.'},'source':'https://ai.google.dev/gemini-api/docs/speech-generation'},
 'murf':{'key':'MURF_API_KEY','config':{'model':'falcon-2','voice':'hi-IN-khyati','language':'hi-IN','region':'in','format':'WAV','sample_rate':24000},'source':'https://murf.ai/api/docs/api-reference/text-to-speech/stream'},
}
async def main():
 if OUT.exists() or RUNS.exists():raise RuntimeError('Current adapter smoke already attempted; no repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 assert len(TEXT)<100
 for provider,profile in PROFILES.items():
  key=secrets.get(profile['key']);assert key
  build_request(provider,TEXT,profile['config'],{profile['key']:key})
 OUT.mkdir(parents=True);RUNS.mkdir(parents=True)
 report={'request_limit':2,'automatic_retries':0,'purpose':'Verify current adapter config after historical run schema changes','samples':[]}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',secrets))
 save()
 for provider,profile in PROFILES.items():
  os.environ[profile['key']]=secrets[profile['key']]
  row={'provider':provider,'source':profile['source'],'source_accessed':'2026-09-15','text':TEXT,'config':profile['config'],'status':'request_started'};report['samples'].append(row);save()
  try:
   async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
    r=await run_one(provider,TEXT,profile['config'],RUNS,timeout=35,client=client,scenario_id='current-adapter-hindi',evaluation_language='hi-IN',stratum='current_adapter_smoke',min_free_bytes=300*1024*1024)
   row.update({k:r.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','first_audio_ms','audio_bytes','audio_sha256','request_contract')});save();print(provider,r['status'],r.get('http_status'),flush=True)
  finally:os.environ.pop(profile['key'],None)
 report['complete']=True;save()
if __name__=='__main__':asyncio.run(main())
