"""Read-only aggregation of saved current-model delivery evidence; no quality claims."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tts_arena.live_evidence import load_live_runs
ROOT=Path(__file__).resolve().parents[1]
MODELS={'google':'gemini-3.1-flash-tts-preview','elevenlabs':'eleven_v3'}
LOCALES=['en-IN','hi-IN','bn-IN','mr-IN','te-IN','ta-IN','gu-IN','kn-IN','ml-IN','ur-IN']

def main():
    records,issues=load_live_runs(ROOT/'artifacts')
    paths={}
    for path in (ROOT/'artifacts').rglob('result.json'):
        try:r=json.loads(path.read_text())
        except (OSError,ValueError):continue
        if r.get('run_id'):paths[r['run_id']]=path
    output={'scope':'Historical current-model audio-delivery coverage, not native pronunciation/accent/quality validation','models':{},'inventory_issues':issues}
    lines=['# Current Gemini and Eleven regional coverage','',
           'Coverage is based on saved, successful current-model audio requests. Language names label the requested input, not independent verification of the speech. All draft texts still need native-language review; no quality scores or certification are implied. Prior failures remain linked separately.','',
           '| Model | Locale | Delivery | Latest successful evidence |','|---|---|---|---|']
    for provider,model in MODELS.items():
        model_rows=[r for r in records if r.get('provider')==provider and r.get('config',{}).get('model')==model]
        states={}
        for locale in LOCALES:
            matching=sorted([r for r in model_rows if r.get('language')==locale],key=lambda r:r['created_at'])
            successful=[r for r in matching if r.get('status')=='success' and r.get('audio_file') and paths.get(r['run_id']) and (paths[r['run_id']].parent/r['audio_file']).exists()]
            selected=successful[-1] if successful else None
            state={'status':'audio_returned' if selected else 'failed' if matching else 'not_tested','linguistic_accuracy':'unverified',
                   'successful_run_ids':[r['run_id'] for r in successful],
                   'failed_records':[{'run_id':r['run_id'],'error_type':r.get('error_type'),'http_status':r.get('http_status'),'record':str(paths[r['run_id']].relative_to(ROOT))} for r in matching if r.get('status')!='success']}
            link='—'
            if selected:
                source=paths[selected['run_id']];state['latest_success_record']=str(source.relative_to(ROOT));link='[Record](../'+state['latest_success_record']+')'
            states[locale]=state;lines.append(f"| {model} | {locale} | {state['status']} | {link} |")
        output['models'][model]={'provider':provider,'locales':states,'delivered_locale_count':sum(s['status']=='audio_returned' for s in states.values())}
    lines+=['','Gemini uses Kore with automatic language detection and explicit language instructions. Eleven uses the existing Bella preset with base-language enforcement. Neither proves native regional accent quality.',
            '', 'The first Gemini Marathi timeout, Urdu rate-window429, and Eleven Bengali local storage failure remain in original records. Subsequent requests were explicitly authorized recovery batches; no automatic retries or legacy fallbacks were used. The final Gemini pair waits at least60 seconds between completed requests.',
            '', '[Full aggregation with historical failures](../artifacts/coverage-20260915/global-current.json). [Initial recovery report](REGIONAL_GLOBAL_RECOVERY_STATUS.md).']
    path=ROOT/'artifacts/coverage-20260915/global-current.json';path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'docs/GLOBAL_REGIONAL_CURRENT_STATUS.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({model:entry['delivered_locale_count'] for model,entry in output['models'].items()}))

if __name__=='__main__':main()
