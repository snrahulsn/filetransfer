"""Create one guarded disposable Runpod Pod for the pinned Veena smoke test."""
import argparse
import json
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path


BASE = "https://rest.runpod.io/v1/pods"
USER_AGENT = "Mozilla/5.0 Chrome/124.0.0.0 Safari/537.36"
NAME = "tts-arena-veena-bounded-smoke"


def api(method: str, key: str, path: str = "", payload: dict | None = None):
    body = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(
        BASE + path,
        data=body,
        method=method,
        headers={
            "Authorization": f"Bearer {key}",
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read()
            return response.status, json.loads(data) if data else None
    except urllib.error.HTTPError as error:
        body = error.read(2048).decode("utf-8", "replace")
        raise RuntimeError(f"Runpod API HTTP {error.code}: {body}") from error


def create_guarded(key_file: Path, public_key_file: Path, log_file: Path, *, name: str = NAME, guard_seconds: int = 3600):
    if not 300 <= guard_seconds <= 3600:raise ValueError('Guard must be between 5 and 60 minutes')
    if not name.startswith('tts-arena-') or len(name)>64:raise ValueError('Pod name must be scoped to this evaluation')
    key = key_file.read_text(encoding="utf-8").strip()
    public_key = public_key_file.read_text(encoding="utf-8").strip()
    status, pods = api("GET", key)
    if status != 200 or not isinstance(pods, list):
        raise RuntimeError("Runpod account Pod inventory unavailable")
    if pods:
        raise RuntimeError("Refuse Pod creation while account already has a Pod")
    payload = {
        "name": name,
        "cloudType": "SECURE",
        "computeType": "GPU",
        "gpuCount": 1,
        "gpuTypeIds": ["NVIDIA GeForce RTX 4090"],
        "imageName": "runpod/pytorch:1.0.2-cu1281-torch280-ubuntu2404",
        "containerDiskInGb": 50,
        "volumeInGb": 20,
        "volumeMountPath": "/workspace",
        "ports": ["22/tcp"],
        "supportPublicIp": True,
        "interruptible": False,
        "env": {"SSH_PUBLIC_KEY": public_key},
    }
    try:
        status, pod = api("POST", key, payload=payload)
    except Exception:
        # A timed-out POST may still have created a billable Pod. Reconcile before returning.
        status, found = api("GET", key)
        matches = [p for p in found if p.get("name") == name]
        if len(matches) != 1:
            raise
        pod = matches[0]
    if status not in (200, 201) or not isinstance(pod, dict) or not pod.get("id"):
        raise RuntimeError("Pod creation outcome cannot be identified")
    pod_id = pod["id"]
    guard = Path(__file__).with_name("runpod_pod_guard.py")
    try:
        subprocess.Popen(
            [sys.executable, str(guard), "--pod-id", pod_id,
             "--key-file", str(key_file), "--seconds", str(guard_seconds), "--log", str(log_file)],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, start_new_session=True,
        )
    except Exception:
        api("DELETE", key, "/" + pod_id)
        raise
    hourly = float(pod.get("adjustedCostPerHr") or pod.get("costPerHr") or 0)
    if hourly <= 0 or hourly > 1.0:
        api("DELETE", key, "/" + pod_id)
        raise RuntimeError(f"Unexpected Pod hourly price: ${hourly:.2f}; deleted")
    return {"id": pod_id, "name": pod.get("name"), "hourly_usd": hourly,
            "desired_status": pod.get("desiredStatus"), "guard_seconds": guard_seconds}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["list", "create", "get", "delete"])
    parser.add_argument("--key-file", type=Path, required=True)
    parser.add_argument("--public-key-file", type=Path)
    parser.add_argument("--guard-log", type=Path)
    parser.add_argument("--pod-id")
    parser.add_argument("--name", default=NAME)
    parser.add_argument("--guard-seconds", type=int, default=3600)
    args = parser.parse_args()
    key = args.key_file.read_text(encoding="utf-8").strip()
    if args.action == "create":
        if not args.public_key_file or not args.guard_log:
            raise ValueError("create requires public key and guard log")
        result = create_guarded(args.key_file, args.public_key_file, args.guard_log, name=args.name, guard_seconds=args.guard_seconds)
    elif args.action == "list":
        _, pods = api("GET", key)
        result = [{"id": p.get("id"), "name": p.get("name"),
                   "desired_status": p.get("desiredStatus"),
                   "hourly_usd": p.get("adjustedCostPerHr") or p.get("costPerHr")}
                  for p in pods]
    elif args.action == "get":
        _, pod = api("GET", key, "/" + args.pod_id)
        result = {k: pod.get(k) for k in ["id", "name", "desiredStatus",
                  "lastStatusChange", "publicIp", "runtime", "portMappings",
                  "costPerHr", "adjustedCostPerHr"]}
    else:
        status, _ = api("DELETE", key, "/" + args.pod_id)
        result = {"id": args.pod_id, "delete_status": status}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
