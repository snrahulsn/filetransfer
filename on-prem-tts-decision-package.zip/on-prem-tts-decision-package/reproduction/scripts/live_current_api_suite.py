"""Bounded current-route verification for hosted APIs not freshly tested after 15:00 UTC."""
import asyncio,json,os,sys
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlparse
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
REFERENCE=ROOT/'ui/public/evidence/working-api-reference.json'
OUT=ROOT/'artifacts/current-api-suite-20260915';RUNS=ROOT/'artifacts/runs/current-api-suite-20260915'
CUTOFF=datetime.fromisoformat('2026-09-15T15:00:00+00:00')
async def main():
 if OUT.exists() or RUNS.exists():raise RuntimeError('Current-route suite already prepared/attempted; no repeats')
 routes=json.loads(REFERENCE.read_text())['routes']
 selected=[r for r in routes if datetime.fromisoformat(r['example_created_at'])<CUTOFF]
 if len(selected)>14:raise ValueError('Verification request cap exceeded')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 plan=[]
 for route in selected:
  pid=route['provider'];config=route['example_config'];text=route['example_text']
  if not 0<len(text)<=100:raise ValueError('Short saved synthetic text required: '+pid)
  env={k:secrets[k] for k in route['credential_environment_names'] if secrets.get(k)}
  if not env:raise ValueError('Authorized credential missing: '+pid)
  spec=build_request(pid,text,config,env)
  if (spec.method,spec.url,spec.response_mode)!=(route['method'],route['endpoint'],route['response_mode']):raise ValueError('Current adapter differs from reference: '+pid)
  plan.append({'provider':pid,'config':config,'text':text,'credential_names':sorted(env),'endpoint_host':urlparse(spec.url).hostname})
 OUT.mkdir(parents=True);RUNS.mkdir(parents=True)
 report={'request_limit':14,'planned_requests':len(plan),'automatic_retries':0,'source_reference_generated_at':json.loads(REFERENCE.read_text())['generated_from_snapshot'],'scope':'One request per older hosted route, saved same model/voice/text/config; no load or native quality inference','results':[]}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',secrets))
 save()
 for index,job in enumerate(plan):
  pid=job['provider'];env={k:secrets[k] for k in job['credential_names']}
  if index:await asyncio.sleep(2)
  os.environ.update(env)
  row={'provider':pid,'endpoint_host':job['endpoint_host'],'config':job['config'],'text':job['text'],'status':'request_started'};report['results'].append(row);save()
  try:
   async with httpx.AsyncClient(timeout=45,trust_env=False,follow_redirects=False) as client:
    r=await run_one(pid,job['text'],job['config'],RUNS,timeout=45,client=client,scenario_id='current-api-one-shot',evaluation_language=('hi-IN' if 'hi-IN' in job['config'].get('language','') else job['config'].get('language','unverified')),stratum='current_api_verification',min_free_bytes=300*1024*1024)
   row.update({k:r.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','first_audio_ms','audio_sha256','request_contract')});save();print(pid,r['status'],r.get('http_status'),flush=True)
  finally:
   for k in env:os.environ.pop(k,None)
 report['complete']=True;save()
if __name__=='__main__':asyncio.run(main())
