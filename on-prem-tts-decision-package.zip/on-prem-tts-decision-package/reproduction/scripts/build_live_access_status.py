"""Replace stale access totals with an exact snapshot-derived summary.

Keep the original first-access run detail as historical evidence after the summary.
"""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / 'ui/public/evidence/snapshot.json'
DEST = ROOT / 'docs/LIVE_ACCESS_STATUS.md'
ARCHIVE_MARKER = '## Historical first-access probe details — 15 September 2026'


def build() -> dict:
    source = SNAPSHOT.read_bytes()
    snapshot = json.loads(source)
    existing = DEST.read_text()
    if ARCHIVE_MARKER in existing:
        historical = existing.split(ARCHIVE_MARKER, 1)[1]
    else:
        historical = existing[existing.index('\n## CAMB.AI'):]
    if '## CAMB.AI' not in historical:
        raise ValueError('Historical first-access detail missing')
    providers = {p['id']: p for p in snapshot['providers']}
    access = {row['provider']: row for row in snapshot['access_audit']}
    if set(access) != set(providers):
        raise ValueError('Access audit does not cover the catalog exactly')
    excluded = {'skipped_by_user', 'deferred_by_deployment_scope'}
    counts = defaultdict(Counter)
    linked = defaultdict(list)
    for run in snapshot['runs']:
        provider = run['provider']
        if provider not in providers or run.get('evidence_class') != 'live_http':
            raise ValueError('Unknown or non-HTTP run in hosted access summary')
        counts[provider]['attempts'] += 1
        if run['status'] == 'success' and run.get('audio_url'):
            counts[provider]['audio'] += 1
            linked[provider].append(run)
    active = [p for p in providers if access[p]['access_state'] not in excluded]
    audio_routes = [p for p in active if counts[p]['audio']]
    without_audio = [p for p in active if not counts[p]['audio'] and p not in {'kokoro', 'maya'}]
    summary = snapshot['summary']
    if (sum(c['attempts'] for c in counts.values()) != summary['historical_attempts'] or
        sum(c['audio'] for c in counts.values()) != summary['historical_successes'] or
        len(audio_routes) != summary['providers_with_success']):
        raise ValueError('Derived hosted totals disagree with saved snapshot summary')
    lines = [
        '# Live access status', '',
        f"Generated from [the published evidence snapshot](../ui/public/evidence/snapshot.json) on {snapshot['generated_at']}. "
        f"Snapshot SHA-256: `{hashlib.sha256(source).hexdigest()}`. "
        'The counts below cover saved hosted HTTP synthesis; Kokoro and Maya local audio, native WebSocket captures and browser evidence are separate.',
        '',
        f"**{sum(c['attempts'] for c in counts.values())} saved HTTP attempts; "
        f"{sum(c['audio'] for c in counts.values())} successful playable outputs; "
        f"{len(audio_routes)} hosted providers with playable audio.** "
        f"Of {len(active)} active candidates, {len(without_audio)} have no hosted playable output. "
        'Azure and Navana remain user-skipped. No vendor is certified for native speech quality, actual billed savings or production carrier operation.',
        '',
        '| Provider | HTTP attempts | Playable HTTP outputs | Current access state | Latest playable run |',
        '|---|---:|---:|---|---|',
    ]
    for p in sorted(active):
        name = providers[p]['name'].replace('|', '\\|')
        state = access[p]['access_state'].replace('_', ' ').replace('|', '\\|')
        run = linked[p][0] if linked[p] else None
        if run and not (ROOT / 'ui/public' / run['audio_url'].lstrip('/')).is_file():
            raise ValueError('Linked latest audio file missing: ' + p)
        evidence = (f"[audio](../ui/public{run['audio_url']}) · `{run['run_id'][:12]}`" if run else '—')
        lines.append(f"| {name} | {counts[p]['attempts']} | {counts[p]['audio']} | {state} | {evidence} |")
    lines += ['',
        'A playable requested-language file establishes API access and delivery, not native accent or language correctness. '
        'HTTP failures are retained in the snapshot. The current-model and request-contract details for all 19 working hosted routes are in '
        '[the working API reference](WORKING_API_REFERENCE.md); its saved run IDs link to the actual audio and result records.',
        '', ARCHIVE_MARKER, '',
        'The following records describe the original bounded access probes on 15 September. '
        'Their counts, adapter hashes, and account responses are historical; use the table above for current totals.',
        '',
    ]
    DEST.write_text('\n'.join(lines) + '\n' + historical.lstrip('\n'))
    return {'catalog':len(providers), 'active':len(active), 'hosted_audio_routes':len(audio_routes),
            'without_hosted_audio':sorted(without_audio), 'http_attempts':sum(c['attempts'] for c in counts.values()),
            'playable_http_outputs':sum(c['audio'] for c in counts.values()), 'snapshot_sha256':hashlib.sha256(source).hexdigest()}


if __name__ == '__main__':
    print(json.dumps(build(), ensure_ascii=False))
