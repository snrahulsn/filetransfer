"""Read-only catalog/access inventory. Credentials are inspected only at the authorized path."""
import json,sys
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tts_arena.credentials import read_credentials,ALIASES,redact
from tts_arena.registry import catalog
from tts_arena.live_evidence import load_live_runs
ROOT=Path(__file__).resolve().parents[1]

def build():
    credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    runs,issues=load_live_runs(ROOT/'artifacts')
    paths={}
    local=[]
    for path in (ROOT/'artifacts').rglob('result.json'):
        try:record=json.loads(path.read_text())
        except (ValueError,OSError):continue
        if record.get('run_id'):paths[record['run_id']]=str(path.relative_to(ROOT))
        if record.get('evidence_class')=='local_model_execution':local.append((path,record))
    rows=[]
    for item in catalog():
        provider=item['id'];requirements=[]
        for name in item['credentials']:
            value=credentials.get(name)
            valid=bool(value) and not value.startswith(('https://','http://'))
            requirements.append({'variable':name,'present':bool(value),'candidate_key_shape':valid,
                'alias_mapping':ALIASES.get(name),'validation':'presence_only_not_authentication'})
        live=sorted([r for r in runs if r['provider']==provider],key=lambda r:r.get('created_at',''))
        success=[r for r in live if r.get('status')=='success']
        evidence=[paths[r['run_id']] for r in live if r['run_id'] in paths]
        summary=ROOT/'artifacts/access-20260915'/f'{provider}.json'
        account=json.loads(summary.read_text()) if summary.exists() else {}
        if summary.exists():evidence.append(str(summary.relative_to(ROOT)))
        row={'provider':provider,'name':item['name'],'kind':item['kind'],'priority':'normal',
            'credential_requirements':requirements,'credential_routes':[],
            'access_state':'unprovisioned','blockers':[],
            'next_autonomous_action':'Inspect official account or signup flow and current-model eligibility; prepare scoped evaluation access without purchases.',
            'external_dependency':'Vendor account activation or scoped API provisioning if the account does not already exist; self-service availability not yet verified.',
            'vendor_contact':{'request_sent_by_this_audit':False,'reply_status':'not_requested_by_this_audit'},
            'evidence_paths':evidence,'primary_documentation':[s['url'] for s in item['sources']],
            'historical_http_attempts':len(live),'historical_http_audio_successes':len(success),
            'quality_status':'unverified; HTTP success is audio delivery only'}
        missing=[r['variable'] for r in requirements if not r['candidate_key_shape']]
        if provider=='google':
            row['credential_routes']=[{'route':'Cloud Text-to-Speech OAuth','required_variables':['GOOGLE_ACCESS_TOKEN'],'available':bool(credentials.get('GOOGLE_ACCESS_TOKEN'))},
                {'route':'Gemini GenerateContent API key','required_variables':['GOOGLE_API_KEY'],'available':bool(credentials.get('GOOGLE_API_KEY')),'observed_model':'gemini-3.1-flash-tts-preview'}]
            missing=[] if credentials.get('GOOGLE_API_KEY') else missing
        elif requirements:row['credential_routes']=[{'route':'catalog adapter','required_variables':[r['variable'] for r in requirements],'available':not missing}]
        if success:
            row.update(access_state='synthesis_access_confirmed',external_dependency=None,
                next_autonomous_action='Continue bounded current-model feature and language probes using existing access; preserve model/voice scope and rate pacing.')
            row['blockers']=[]
        elif missing:
            row['access_state']='credential_not_available_in_authorized_file'
            row['blockers']=[{'code':'missing_credential','scope':'configured_direct_API_route','exact_reason':'Missing usable credential entries: '+', '.join(missing),
                'limitation':'This does not mean signup or automated account provisioning is impossible.'}]
        elif requirements:
            row['access_state']='credential_present_access_unverified'
            row['next_autonomous_action']='Use authenticated read-only discovery, then one bounded synthesis after exact current model/voice eligibility is confirmed.'
            row['external_dependency']=None
        if provider=='openai':
            row.update(access_state='billing_blocked',next_autonomous_action='Inspect available account/project access for an already-funded authorized route; retain prepared probe without repeated charge attempts.',
                external_dependency='The API organization requires credits, or an already-funded project key must be made available. No purchase is performed by this audit.')
            row['blockers']=[{'code':'credit_balance_exhausted','scope':'existing_key_project','http_status':429,'exact_reason':'Vendor returned insufficient_quota / credit_balance_exhausted: You have no credits remaining.'}]
            recheck=ROOT/'artifacts/openai-credit-recheck-20260916/summary.json'
            if recheck.exists():
                observed=json.loads(recheck.read_text())
                if (observed.get('provider'),observed.get('request_limit'),observed.get('automatic_retries'),
                    observed.get('status'),observed.get('http_status'),observed.get('audio_bytes')) != (
                    'openai',1,0,'error',429,0):
                    raise ValueError('OpenAI bounded recheck evidence changed')
                result_path=ROOT/observed['result_file']
                result=json.loads(result_path.read_text())
                if (result.get('run_id'),result.get('provider'),result.get('status'),
                    result.get('http_status'),result.get('audio_bytes')) != (
                    observed['run_id'],'openai','error',429,0):
                    raise ValueError('OpenAI recheck summary/result mismatch')
                row['latest_recheck']={k:observed[k] for k in ('model','language','request_limit','automatic_retries','status','http_status','audio_bytes','run_id')}
                row['evidence_paths'] += [str(recheck.relative_to(ROOT)),observed['result_file']]
                row['next_autonomous_action']='One current-model Hindi attempt again returned HTTP 429 and zero audio. Verify funded project entitlement before any further generation attempt.'
        if provider=='elevenlabs':
            row['blockers']=[{'code':'paid_plan_required','scope':'selected Indian library voice only; default and conversational routes succeeded','http_status':402,
                'exact_reason':'Free users cannot use library voices via the API.'}]
            row['next_autonomous_action']='Continue working default/conversational route; inspect existing organization entitlement before requesting paid library voices.'
            row['external_dependency']='Paid-library-voice entitlement only if that restricted voice is retained; not a blocker for working synthesis routes.'
        if provider=='voicemaker':
            row.update(access_state='authenticated_discovery_confirmed_api_billing_blocked',
                next_autonomous_action='Use the saved 1,408-voice catalog to select exact ProPlus Indian voices; repeat one bounded Hindi and Indian-English synthesis only after developer API characters become available.',
                external_dependency='Developer API Pay As You Go recharge or transfer of existing Studio credits; current API character limit is zero.')
            row['blockers']=[{'code':'developer_api_unsubscribed','scope':'direct_API','http_status':400,
                'exact_reason':'Authenticated voice discovery succeeded, but ProPlus Turbo synthesis returned "You are not subscribed". Developer billing shows Pay As You Go with zero API characters; the 200K Starter Studio credits are separate.'}]
            row['evidence_paths']+=['artifacts/access-20260915/voicemaker-discovery.json','artifacts/runs/access-20260915/voicemaker/5507328f2f004d53b452f10c24c5b2c7/result.json','docs/ACCESS_ACTION_ITEMS.md']
            latest=ROOT/'artifacts/voicemaker-credit-recheck-20260915/result.json'
            if latest.exists():
                observed=json.loads(latest.read_text())
                row['latest_credit_recheck']={k:observed.get(k) for k in ('status','http_status','audio_bytes','request_limit','retries')}
                row['evidence_paths'].append(str(latest.relative_to(ROOT)))
                if observed.get('http_status')==400 and observed.get('audio_bytes')==0:
                    row['next_autonomous_action']='Developer API credit or ProPlus entitlement still requires account resolution. One bounded recheck after the reported credit addition returned HTTP400 and no audio; do not retry blindly.'
            account_path=ROOT/'artifacts/access-20260916/voicemaker-developer-account-2301z.json'
            if not account_path.exists():
                account_path=ROOT/'artifacts/access-20260916/voicemaker-developer-account.json'
            if account_path.exists():
                state=json.loads(account_path.read_text())
                quota=state.get('dashboard',{})
                if state.get('provider')!='voicemaker' or state.get('purchase_or_payment_change') is not False or any(quota.get(k)!=0 for k in ('total_character_limit','used_characters','remaining_characters')) or state.get('billing',{}).get('current_plan')!='Pay As You Go':
                    raise ValueError('Current Voicemaker account observation inconsistent')
                row['evidence_paths'].append(str(account_path.relative_to(ROOT)))
                row['current_developer_api_character_limit']=0
                row['current_developer_api_observed_at_utc']=state['observed_at_utc']
                row['next_autonomous_action']='Do not repeat synthesis at zero developer API entitlement. Current signed-in dashboard and billing remain at zero API characters; inspect only after this account state changes.'
        if provider=='gnani':
            recheck=ROOT/'artifacts/access-audits/gnani-rate-recheck.json'
            if recheck.exists():
                check=json.loads(recheck.read_text());row['evidence_paths'].append(str(recheck.relative_to(ROOT)))
                recent=check['attempts'];failed=[a for a in recent if a['status']!='success']
                row['latest_recheck']={'attempts':len(recent),'audio_successes':sum(a['status']=='success' for a in recent)}
                row['blockers']=[{'code':'RATE_LIMITED' if a.get('http_status')==429 else 'latest_request_failed','scope':a['language'],'http_status':a.get('http_status'),'exact_reason':a.get('diagnostics',[])} for a in failed]
                row['next_autonomous_action']='Continue paced bounded evaluation; do not infer concurrency capacity from these isolated successes.' if not failed else 'Inspect documented account rate/reset information and preserve the failure; no further retry in this audit.'
                row['external_dependency']=None if not failed else 'Vendor account rate window or assigned capacity; limit magnitude remains unverified.'
            row['historical_blockers_resolved']=['Original STT-only credential lacked TTS scope; separate TTS-only key subsequently generated Hindi audio.']
        if provider=='fish':
            row['historical_blockers_resolved']=['Original supplied credential returned401 Invalid Token; later authorized evaluation key generated current-model audio.']
            row['next_autonomous_action']='Continue bounded S2.1 Pro Free evaluation and verify promotional/production entitlement separately; do not infer the old invalid token is still blocking.'
        if provider=='fonada':
            row['next_autonomous_action']='Continue Klone V2 Pro HTTP feature/language probes; seek a primary current-model native protocol before any WebSocket implementation.'
            row['blockers']=[{'code':'current_native_protocol_unverified','scope':'Klone V2 Pro native WebSocket only','exact_reason':'Reviewed specification documents HTTP routes but no Klone WebSocket message/cancellation contract; older V1 session is excluded.'}]
            row['external_dependency']='Vendor primary specification only for the requested current-model native WebSocket capability; HTTP access already works.'
            row['evidence_paths'].append('docs/FONADA_SESSION_STATUS.md')
        if provider=='deepgram':
            row['next_autonomous_action']='Verify current Hindi and Indian-English voice eligibility before considering expansion; existing observed output is an American-English comparator.'
        if provider=='resemble':
            resemble_status=ROOT/'artifacts/resemble-access-20260915/status.json'
            if resemble_status.exists():
                observed=json.loads(resemble_status.read_text())
                if observed.get('api_key_saved_private') and observed.get('voice_discovery_http_statuses')==[200,200]:
                    row['access_state']='authenticated_voice_discovery_synthesis_credit_blocked'
                    row['blockers']=[{'code':'insufficient_balance','scope':'Resemble Ultra studio Hindi generation','exact_reason':'One Hindi studio attempt required adding credits; wallet was $0. No audio was generated.'},
                        {'code':'current_model_api_identity_unverified','scope':'Ultra API synthesis','exact_reason':'Discovered Hindi default voices were labelled text_to_speech:not_available by the API; no Ultra API synthesis was attempted.'}]
                    row['next_autonomous_action']='Verify current Ultra API model/voice identity and entitlement with existing authenticated access; retain the prepared synthesis probe until credits exist.'
                    row['external_dependency']='Existing funded balance or authorized credits for audio generation; no purchase or card was added.'
                    row['evidence_paths']+=['artifacts/resemble-access-20260915/status.json','docs/RESEMBLE_ACCESS_STATUS.md']
            billing_path=ROOT/'artifacts/resemble-access-20260916/billing-sanitized.json'
            if billing_path.exists():
                billing=json.loads(billing_path.read_text())
                if billing.get('provider')!='resemble' or billing.get('subscription_http_status')!=200 or billing.get('wallet_http_status')!=200 or billing.get('wallet',{}).get('balance_dollars') not in ('0','0.0') or billing.get('subscription',{}).get('subscription_present') is not False or billing.get('purchase_or_payment_change') is not False:
                    raise ValueError('Current Resemble billing observation inconsistent')
                row['evidence_paths'].append(str(billing_path.relative_to(ROOT)))
                row['current_wallet_dollars']='0.0'
                row['next_autonomous_action']='Do not repeat synthesis at zero authenticated wallet balance and no customer-visible subscription. Retain model/voice entitlement investigation until account balance or entitlement changes.'
                row['external_dependency']='Funded wallet or model-entitled subscription for Resemble synthesis; no purchase was made.'
        if provider=='reverie' and account.get('blocker')=='official_developer_portal_tls_certificate_invalid':
            row['access_state']='signup_blocked_by_official_portal_certificate'
            row['blockers']=[{'code':'expired_tls_certificate','scope':'official RevUp signup portal','exact_reason':'Chrome NET::ERR_CERT_DATE_INVALID and independent HTTPS CERTIFICATE_VERIFY_FAILED: certificate has expired.'}]
            row['next_autonomous_action']='Recheck the official portal after certificate repair or follow a vendor-published secure alternative; no warning bypass.'
            row['external_dependency']='Valid official signup portal TLS certificate or vendor-published secure alternate access route.'
            row['evidence_paths'].append('docs/DUBVERSE_REVERIE_ACCESS_STATUS.md')
        if provider=='speechify' and account.get('successful_syntheses'):
            row['access_state']='english_synthesis_confirmed_hindi_ineligible_current_model'
            row['blockers']=[{'code':'current_model_english_only','scope':'simba-3.2 Hindi and regional-language requirement','exact_reason':'Official current model guide and authenticated model discovery restrict Simba 3.2 to English. No Hindi call or retired-model fallback was made.'}]
            row['next_autonomous_action']='Retain authenticated en-IN Ankit access and neutral/cheerful SSML evidence as an English-only comparator; exclude from Hindi-majority shortlist.'
            row['external_dependency']='Current-model official Hindi support before reconsidering the primary workload; credentials and Indian-English synthesis already work.'
            row['evidence_paths'].append('docs/SPEECHIFY_ACCESS_STATUS.md')
        if provider in {'ai4bharat','coqui','nvidia'}:
            row.update(access_state='deferred_by_deployment_scope',priority='deferred',
                next_autonomous_action='Retain researched adapter and evidence; no local deployment work under the current Kokoro/Maya-only on-prem scope.',
                external_dependency='Scope expansion before provisioning this local/customer-deployed route.')
            row['blockers']=[{'code':'deployment_scope_deferred','scope':'local/customer-deployed adapter','exact_reason':'Current on-prem execution scope is Kokoro and Maya; this route is deferred rather than impossible.'}]
            row['evidence_paths'].append('docs/ACCESS_ACTION_ITEMS.md')
            if provider=='ai4bharat':row['credential_requirement_note']='HF_TOKEN is catalog-listed; complete permitted offline weights do not require sending an API token during inference. Model download/gate entitlement has not been established here.'
            if provider=='nvidia':row['credential_requirement_note']='No static credential is declared by this adapter; an explicit authorized running NIM endpoint and deployed model are required.'
        if provider=='kokoro':
            local_success=[(p,r) for p,r in local if r.get('provider')=='kokoro' and r.get('status')=='success']
            row.update(access_state='local_synthesis_confirmed' if local_success else 'local_runtime_validation_pending',
                next_autonomous_action='Continue authorized local runtime/model verification and preserve measured local evidence; no vendor API signup needed.',external_dependency=None)
            row['blockers']=[];row['evidence_paths'] += [str(p.relative_to(ROOT)) for p,r in local_success]
            row['local_audio_successes']=len(local_success)
        if provider=='maya':
            row.update(access_state='local_veena_synthesis_confirmed_hosted_deferred',priority='last',local_audio_successes=3,
                next_autonomous_action='Qualify the three Veena batch WAVs with independent Hindi, Indian-English and code-mix listening; test streaming/cancellation separately. After other hosted candidates, inspect the completed Maya signup for Calyx API provisioning and exact model mapping.',
                external_dependency='Hosted Calyx API provisioning/model identity still unresolved. Public-weight Veena batch inference needs no further account access.')
            row['blockers']=[{'code':'hosted_key_missing','scope':'current_hosted_API','exact_reason':'MAYA_API_KEY absent in authorized file; completed signup is recorded, but no successful hosted synthesis is present.'}]
            row['evidence_paths']+=['docs/MAYA_LOCAL_IMPLEMENTATION.md','artifacts/runpod/veena-20260915/veena-hi-IN-kavya.json','artifacts/runpod/veena-20260915/veena-en-IN-agastya.json','artifacts/runpod/veena-20260915/veena-hi-en-maitri.json']
        if provider=='navana':
            row.update(access_state='skipped_by_user',priority='skipped',blockers=[],next_autonomous_action='None; preserve skipped state.',external_dependency=None)
        if provider=='azure':
            row.update(access_state='skipped_by_user',priority='skipped',blockers=[],next_autonomous_action='None; preserve skipped state.',external_dependency=None)
        if provider=='amazon' and not success:row['next_autonomous_action']='Check current Generative voice/language relevance before provisioning optional Polly comparator; do not silently use Standard or Neural fallback.'
        if provider=='playht' and not success:
            row['next_autonomous_action']='Verify official service availability and identity before account registration, credential submission or payment; then inspect current model evaluation access.'
            portal_path=ROOT/'artifacts/access-20260916/playht-official-portal.json'
            if portal_path.exists():
                observation=json.loads(portal_path.read_text())
                if observation.get('provider')!='playht' or observation.get('chrome_result')!='DNS_PROBE_FINISHED_NXDOMAIN' or observation.get('official_documentation_http_status')!=200 or observation.get('signup_attempted') is not False:
                    raise ValueError('PlayHT portal observation inconsistent')
                row['access_state']='official_api_portal_dns_unreachable_observed'
                row['blockers'].append({'code':'official_portal_dns','scope':'self_service_api_key_setup','exact_reason':'Official authentication guide loaded, but linked play.ht/studio/api-access failed DNS in signed-in Chrome and local resolver at the observation time. No permanent service-status claim.'})
                row['evidence_paths'].append(str(portal_path.relative_to(ROOT)))
                row['next_autonomous_action']='Check the official portal after DNS repair or verify a vendor-published secure alternate domain; do not substitute an unverified similar-name site.'
                row['external_dependency']='Resolvable official API-access portal or verified vendor-published alternate, then account/API key provisioning.'
        row['evidence_paths']=sorted(set(row['evidence_paths']))
        rows.append(row)
    rows.sort(key=lambda r:({'normal':0,'deferred':1,'last':2,'skipped':3}[r['priority']],r['name']))
    report={'created_at':datetime.now(timezone.utc).isoformat(),'candidate_count':len(rows),'credential_source':'Explicitly authorized Documents/arena_tts/working_api_tokens.env only',
       'credential_values_recorded':False,'scope':'Access blockers, not feature or quality certification. Historical failures do not override later successful authenticated evidence.',
       'missing_key_means':'Not available in the selected file, not proof that signup or autonomous provisioning is impossible.',
       'vendor_requests_sent_by_audit':0,'purchases':0,'inventory_issues':issues,'candidates':rows}
    out=ROOT/'artifacts/access-audits/candidate-access-20260915.json';out.parent.mkdir(exist_ok=True)
    # This file includes a mislabelled public documentation URL among key entries.
    # Non-key URL values are not authentication material and must not break source links.
    from urllib.parse import urlsplit
    secrets={k:v for k,v in credentials.items() if not v.startswith(('https://','http://')) or urlsplit(v).query or urlsplit(v).username}
    out.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n')
    individual=out.parent/'candidates';individual.mkdir(exist_ok=True)
    for row in rows:
        (individual/(row['provider']+'.json')).write_text(redact(json.dumps({'created_at':report['created_at'],**row},ensure_ascii=False,indent=2),secrets)+'\n')
    print(json.dumps({'candidates':len(rows),'states':{s:sum(r['access_state']==s for r in rows) for s in sorted({r['access_state'] for r in rows})},'output':str(out)},indent=2))

if __name__=='__main__':build()
