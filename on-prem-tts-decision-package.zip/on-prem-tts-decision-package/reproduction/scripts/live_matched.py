"""Thirty authorized matched-text requests; no retries, no billing estimates, no rankings."""
import asyncio,copy,hashlib,json,os,sys,wave
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
from tts_arena.registry import build_request,code_digest,digest
from tts_arena.metrics import text_units
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/matched-20260915'
FIXTURES=[{'id':'meeting-hi-01','locale':'hi-IN','stratum':'hindi_devanagari','text':'नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'},
 {'id':'meeting-hinglish-01','locale':'hi-IN','stratum':'hinglish_mixed_script','text':'नमस्ते, आपकी meeting कल दोपहर three बजे है। Please confirm the time.'},
 {'id':'meeting-en-01','locale':'en-IN','stratum':'indian_english','text':'Hello, your meeting is tomorrow at three in the afternoon. Please confirm the time.'}]
MODELS={'cartesia':'sonic-3.6','elevenlabs':'eleven_v3','murf':'falcon-2','smallest':'lightning_v3.1_pro','sarvam':'bulbul:v3','minimax':'speech-2.8-hd','hume':'2','inworld':'inworld-tts-2','rime':'coda','google':'gemini-3.1-flash-tts-preview'}
KEYS={'cartesia':'CARTESIA_API_KEY','elevenlabs':'ELEVENLABS_API_KEY','murf':'MURF_API_KEY','smallest':'SMALLEST_API_KEY','sarvam':'SARVAM_API_KEY','minimax':'MINIMAX_API_KEY','hume':'HUME_API_KEY','inworld':'INWORLD_API_KEY','rime':'RIME_API_KEY','google':'GOOGLE_API_KEY'}
ACCENTS={'cartesia':'Vendor-discovered native en-IN voice; native-listener validation pending.',
 'elevenlabs':'Default Bella voice; Indian English not verified. Indian library voices require paid-plan entitlement; no library substitution attempted.',
 'murf':'Vendor-discovered en-IN preset; native-listener validation pending.',
 'smallest':'Meher Pro voice documented for Indian English/Hindi; native-listener validation pending.',
 'sarvam':'Configured en-IN with Shubh; accent realization not independently verified.',
 'minimax':'Hindi preset cross-language English output; Indian accent not independently verified.',
 'hume':'Automatic language detection, existing preset; Indian accent not verified.',
 'inworld':'Anjali English preset from account discovery; Indian accent not independently verified.',
 'rime':'English adeline comparator; Indian accent not established. Coda voices are language-specific.',
 'google':'Indian English requested through natural-language instructions; no native-accent preset claim.'}

def configurations(provider):
    source=ROOT/'artifacts/access-20260915'/f'{provider}.json';data=json.loads(source.read_text());rows=data.get('runs',data.get('attempts',[]))
    rows=[r for r in rows if r.get('status')=='success' and r.get('config',{}).get('model')==MODELS[provider]]
    if not rows:raise ValueError('No previous successful current-model config: '+provider)
    result=[]
    for fixture in FIXTURES:
        locale=fixture['locale'];wire_locale={'minimax':{'hi-IN':'Hindi','en-IN':'English'},'hume':{'hi-IN':'auto','en-IN':'auto'},'rime':{'hi-IN':'hi-IN','en-IN':'en-US'}}.get(provider,{}).get(locale,locale)
        selected=next((r for r in rows if r['config']['language']==wire_locale),None)
        if selected is None and provider=='elevenlabs':selected=rows[0]
        if selected is None:raise ValueError('No prior config for '+provider+' '+wire_locale)
        cfg=copy.deepcopy(selected['config']);cfg['language']=wire_locale
        if provider=='google':
            cfg['instructions']='Read the following text in an Indian English accent.' if locale=='en-IN' else ('Read the following Hindi and English mixed text naturally.' if fixture['stratum']=='hinglish_mixed_script' else 'Read the following text naturally in Hindi.')
        result.append((fixture,cfg,str(source.relative_to(ROOT)),selected['run_id']))
    return result

async def main():
    if OUT.exists():raise RuntimeError('Matched evidence exists; refusing automatic repeat spend')
    secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    jobs={p:configurations(p) for p in MODELS}
    # Fully validate all payloads and bounds before any paid request.
    for p in MODELS:
        if not secrets.get(KEYS[p]):raise ValueError('Missing credential '+KEYS[p])
        os.environ[KEYS[p]]=secrets[KEYS[p]]
        for fixture,cfg,_,_ in jobs[p]:
            assert len(fixture['text'])<=140
            build_request(p,fixture['text'],cfg)
    OUT.mkdir(parents=True,exist_ok=False)
    corpus={'schema_version':1,'status':'draft_unreviewed_by_native_listeners','provenance':'New synthetic fictional appointment snippets; no personal information','fixtures':FIXTURES}
    (OUT/'corpus.json').write_text(json.dumps(corpus,ensure_ascii=False,indent=2)+'\n')
    manifest={'schema_version':1,'created_date':'2026-09-15','purpose':'Matched exploratory native-listening samples, not provider quality or latency ranking',
      'corpus_sha256':digest(corpus),'code_sha256_before_execution':code_digest(),'requests_limit':30,'per_provider_limit':3,'automatic_retries':0,
      'limits':['One text per stratum and one synthesis per provider/text; no statistical ranking.','Identical transcript within each stratum; model,voice,prompt and native audio rate vary and are recorded.','No production telephony, resampling, loudness normalization, human quality scores or invoice reconciliation.'],
      'samples':[],'providers':{}}
    def save(): (OUT/'manifest.json').write_text(redact(json.dumps(manifest,ensure_ascii=False,indent=2),secrets)+'\n')
    save()
    for provider in MODELS:
        summary={'model':MODELS[provider],'attempts':0,'successful':0,'stopped':False};manifest['providers'][provider]=summary
        errors=[]
        async def hook(response):
            if response.status_code>=400:
                body=(await response.aread())[:5000].decode('utf8','replace')
                errors.append({'http_status':response.status_code,'message':redact(body,secrets)})
        async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
            for fixture,cfg,provenance,prior_id in jobs[provider]:
                spec=build_request(provider,fixture['text'],cfg)
                sample={'id':provider+'-'+fixture['id'],'provider':provider,'model':MODELS[provider],'voice':cfg['voice'],'locale':fixture['locale'],'language':fixture['locale'],'stratum':fixture['stratum'],
                  'text':fixture['text'],'text_sha256':hashlib.sha256(fixture['text'].encode()).hexdigest(),'text_units':text_units(fixture['text']),
                  'config':cfg,'configuration_source':provenance,'prior_successful_run_id':prior_id,'accent_evidence':ACCENTS[provider],
                  'request_body_sha256':digest(spec.body),'instructions_in_request':cfg.get('instructions'),'billing':{'status':'not_reconciled','cost':None},'status':'request_started'}
                manifest['samples'].append(sample);summary['attempts']+=1;save() # Persist before request so a crash cannot silently repeat spend.
                before=len(errors)
                record=await run_one(provider,fixture['text'],cfg,OUT/'runs'/provider,timeout=30,client=client,scenario_id=fixture['id'],evaluation_language=fixture['locale'],stratum=fixture['stratum'])
                folder=OUT/'runs'/provider/record['run_id'];sample.update({k:record.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','provider_request_id','provider_usage','audio_analysis')})
                sample['diagnostics']=errors[before:];sample['run_result']=str((folder/'result.json').relative_to(ROOT));sample['source_record']=str((folder/'result.json').resolve());sample['sample_rate']=spec.sample_rate;sample['encoding']=spec.encoding
                if record.get('audio_file'):
                    original=folder/record['audio_file'];sample['original_audio_file']=str(original.relative_to(ROOT))
                    if record['status']=='success':
                        if original.read_bytes().startswith(b'RIFF'):playable=original
                        elif spec.encoding in ('pcm_s16le','pcm16','pcm','linear16'):
                            playable=folder/'listening.wav'
                            with wave.open(str(playable),'wb') as output:output.setnchannels(spec.channels);output.setsampwidth(2);output.setframerate(spec.sample_rate);output.writeframes(original.read_bytes())
                            sample['listening_derivation']='WAV container only; PCM samples unchanged; no resampling or normalization'
                        else:playable=None
                        if playable:sample['audio_file']=str(playable.resolve());sample['listening_audio_sha256']=hashlib.sha256(playable.read_bytes()).hexdigest()
                if record['status']=='success':summary['successful']+=1
                save();print(provider,fixture['stratum'],record['status'],record.get('http_status'),flush=True)
                if record.get('http_status') in (401,402,403,429) or record['status']!='success':
                    summary['stopped']=True;summary['stop_reason']='request_failed_no_retry';save();break
        os.environ.pop(KEYS[provider],None)
    manifest['completed']=True;manifest['attempts_total']=sum(p['attempts'] for p in manifest['providers'].values());manifest['success_total']=sum(p['successful'] for p in manifest['providers'].values());save()
    print(json.dumps({'attempts':manifest['attempts_total'],'successes':manifest['success_total']}))
if __name__=='__main__':asyncio.run(main())
