"""One authorized Hindi WORD timestamp probe; existing directory forbids replay."""
import asyncio, hashlib, json, os, shutil, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials, redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/inworld-timestamps-20260915'
TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है।'
CONFIG=dict(model='inworld-tts-2',voice='Meher',language='hi-IN',format='WAV',sample_rate=24000,timestamp_type='WORD')
async def main():
    if OUT.exists(): raise RuntimeError('Existing evidence guard; no replay')
    if shutil.disk_usage(ROOT).free<500*1024*1024: raise RuntimeError('Insufficient free space')
    secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    os.environ['INWORLD_API_KEY']=secrets['INWORLD_API_KEY']
    build_request('inworld',TEXT,CONFIG)
    OUT.mkdir()
    summary={'max_requests':1,'attempts':1,'no_retries':True,'text':TEXT,'config':CONFIG,'alignment_accuracy':'unverified','source_hashes':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['tts_arena/adapters/inworld.py','tts_arena/transport.py','tts_arena/runner.py']}}
    def save(): (OUT/'summary.json').write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),secrets)+'\n')
    save()
    async def capture(response):
        raw=await response.aread()
        if len(raw)>4*1024*1024: raise RuntimeError('Bounded response capture exceeded')
        (OUT/'response.json').write_text(redact(raw.decode('utf8','replace'),secrets))
        summary['response_status']=response.status_code
        save()
    async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[capture]}) as client:
        result=await run_one('inworld',TEXT,CONFIG,OUT/'runs',timeout=30,client=client,evaluation_language='hi-IN',scenario_id='word_timestamp_probe',stratum='feature_probe')
    summary['result_file']=str(OUT/'runs'/result['run_id']/'result.json')
    summary['result']={k:result.get(k) for k in ['status','http_status','audio_bytes','duration_seconds','audio_sha256','provider_metadata_errors','error_type']}
    timing=next((x['timestampInfo']['wordAlignment'] for x in result.get('provider_metadata',[]) if 'timestampInfo' in x),None)
    summary['feature_status']='observed_timing_metadata' if timing else 'timing_not_observed'
    if timing:
        summary['timing_counts']={'alignment_entries':len(timing['words']),'phonetic_entries':len(timing.get('phoneticDetails',[])),'phones':sum(len(x['phones']) for x in timing.get('phoneticDetails',[]))}
    summary['complete']=True
    save()
    print(json.dumps({'result':summary['result'],'feature_status':summary['feature_status'],'timing_counts':summary.get('timing_counts')},ensure_ascii=False))
if __name__=='__main__': asyncio.run(main())
