"""One bounded Voicemaker API credit recheck after user reported added credits."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/runs/voicemaker-credit-recheck-20260915'
MANIFEST=ROOT/'artifacts/voicemaker-credit-recheck-20260915/result.json'
CONFIG={'model':'proplus','voice':'proplus-Taksh','language':'en-IN','format':'wav','sample_rate':24000,'pro_engine':'turbo','response_type':'stream'}
TEXT='Hello, your meeting is tomorrow at three in the afternoon. Please confirm the time.'

async def main():
 if OUT.exists() or MANIFEST.exists():raise RuntimeError('Existing credit recheck evidence; no automatic retry')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('VOICEMAKER_API_KEY')
 if not key:raise RuntimeError('No authorized Voicemaker key')
 build_request('voicemaker',TEXT,CONFIG,{'VOICEMAKER_API_KEY':key})
 OUT.mkdir(parents=True);MANIFEST.parent.mkdir(parents=True)
 os.environ['VOICEMAKER_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   run=await run_one('voicemaker',TEXT,CONFIG,OUT,timeout=35,client=client,scenario_id='meeting-en-01',evaluation_language='en-IN',stratum='credit_recheck',min_free_bytes=300*1024*1024)
 finally:os.environ.pop('VOICEMAKER_API_KEY',None)
 report={'provider':'voicemaker','recheck_after_user_reported_credits':True,'request_limit':1,'retries':0,'run_id':run['run_id'],'status':run['status'],'http_status':run.get('http_status'),'error_type':run.get('error_type'),'audio_sha256':run.get('audio_sha256'),'audio_bytes':run.get('audio_bytes')}
 MANIFEST.write_text(redact(json.dumps(report,indent=2)+'\n',{'VOICEMAKER_API_KEY':key}))
 print(json.dumps({k:report[k] for k in ('status','http_status','error_type','audio_bytes')}))

if __name__=='__main__':asyncio.run(main())
