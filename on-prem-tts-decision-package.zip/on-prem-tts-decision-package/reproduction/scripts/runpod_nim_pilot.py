"""One Hindi Magpie NIM live pilot, with immediate Pod and registry cleanup.

This command creates a billable Pod. Run only after NVIDIA account terms are accepted
by the account owner and a personal Catalog key has been stored privately.
"""
import argparse
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.runpod_nim_pod import ROOT, create
from scripts.runpod_nim_guard import cleanup
from tts_arena.credentials import read_credentials
from tts_arena.one_audio_per_locale import assert_missing_audio
from tts_arena.runner import run_one


TEXT = 'आपकी किस्त ₹15,000 है और भुगतान 15 सितंबर को करना है।'
MAX_READY_SECONDS = 55 * 60


def get_json(origin: str, path: str, timeout: int = 15) -> dict:
    request = urllib.request.Request(origin + path, headers={'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                raise RuntimeError(f'NIM {path} returned HTTP {response.status}')
            value = json.loads(response.read(1024 * 1024))
            if not isinstance(value, dict):
                raise RuntimeError(f'NIM {path} returned non-object JSON')
            return value
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'NIM {path} returned HTTP {error.code}') from None


def hindi_voices(discovery: dict) -> list[str]:
    voices = []
    for key, value in discovery.items():
        if not isinstance(key, str) or 'hi-IN' not in key.split(',') or not isinstance(value, dict):
            continue
        voices.extend(voice for voice in value.get('voices', [])
                      if isinstance(voice, str) and voice.startswith('Magpie-Multilingual.HI-IN.'))
    return sorted(set(voices))


def validate_metadata(metadata: dict) -> str:
    profile = metadata.get('selectedModelProfileId')
    model_info = metadata.get('modelInfo')
    if not isinstance(profile, str) or not profile or not isinstance(model_info, list):
        raise RuntimeError('NIM deployment profile or model metadata absent')
    if not any(isinstance(row, dict) and
               'magpie-tts-multilingual' in str(row.get('modelUrl', ''))
               for row in model_info):
        raise RuntimeError('NIM metadata does not identify Magpie Multilingual')
    return profile


def wait_ready(origin: str, max_seconds: int = MAX_READY_SECONDS, get=get_json) -> dict:
    deadline = time.monotonic() + max_seconds
    next_report = time.monotonic() + 45
    while time.monotonic() < deadline:
        try:
            ready = get(origin, '/v1/health/ready')
            if ready.get('status') == 'ready':
                return ready
        except (OSError, RuntimeError, ValueError, json.JSONDecodeError):
            pass
        now = time.monotonic()
        if now >= next_report:
            print(json.dumps({'phase': 'nim_initializing', 'elapsed_seconds':
                              round(max_seconds - (deadline - now))}), flush=True)
            next_report = now + 45
        time.sleep(min(15, max(0, deadline - now)))
    raise TimeoutError('NIM was not ready within the 55-minute startup budget')


async def pilot(credentials_path: Path, output_dir: Path, guard_log: Path,
                *, create_pod=create, get=get_json, delete=cleanup,
                synthesize=run_one, audio_guard=assert_missing_audio) -> dict:
    credentials = read_credentials(credentials_path)
    audio_guard(ROOT, 'nvidia', 'hi-IN')
    account_key = credentials.get('RunPod') or credentials.get('RUNPOD_API_KEY')
    pod = create_pod(credentials, credentials_path, guard_log)
    print(json.dumps({'phase': 'pod_created', 'pod_id': pod['pod_id'],
                      'hourly_usd': pod['hourly_usd']}), flush=True)
    result = None
    failure = None
    try:
        origin = pod['https_origin']
        wait_ready(origin, get=get)
        metadata = get(origin, '/v1/metadata')
        profile = validate_metadata(metadata)
        version = get(origin, '/v1/version')
        discovery = get(origin, '/v1/audio/list_voices')
        voices = hindi_voices(discovery)
        if not voices:
            raise RuntimeError('Deployed NIM returned no Magpie Hindi voice')
        audio_guard(ROOT, 'nvidia', 'hi-IN')
        config = {'endpoint': origin, 'allow_endpoint_override': True,
                  'model': 'magpie-tts-multilingual', 'voice': voices[0],
                  'language': 'hi-IN', 'format': 'wav', 'sample_rate': 22050}
        run = await synthesize('nvidia', TEXT, config, output_dir / 'runs',
                               timeout=120, evaluation_language='hi-IN',
                               stratum='native_script', scenario_id='magpie-one-hindi')
        if run.get('status') != 'success' or not run.get('audio_file'):
            raise RuntimeError(f'NVIDIA Hindi synthesis ended as {run.get("status")}')
        result = {'created_at': datetime.now(timezone.utc).isoformat(),
                  'pod_id': pod['pod_id'], 'hourly_usd': pod['hourly_usd'],
                  'container_image': pod['container_image'], 'profile_id': profile,
                  'model_info': metadata['modelInfo'], 'nim_version': version,
                  'hindi_voices': voices, 'selected_voice': voices[0],
                  'run_id': run['run_id'], 'audio_sha256': run['audio_sha256'],
                  'duration_seconds': run.get('duration_seconds'),
                  'scope': 'one Hindi HTTP WAV and exact deployment discovery; not native quality or billed-cost certification'}
        print(json.dumps({'phase': 'audio_saved', 'run_id': run['run_id'],
                          'audio_sha256': run['audio_sha256']}), flush=True)
    except Exception as error:
        failure = error
    finally:
        deletion = delete(pod['pod_id'], pod['registry_auth_id'], account_key)
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / 'cleanup.json').write_text(json.dumps(deletion, indent=2) + '\n')
        print(json.dumps({'phase': 'cleanup', 'pod_deleted': deletion['pods']['deleted'],
                          'registry_auth_deleted': deletion['containerregistryauth']['deleted']}), flush=True)
        if result is not None:
            result['cleanup'] = {kind: entry['deleted'] for kind, entry in deletion.items()}
            (output_dir / 'pilot.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
        if not deletion['pods']['deleted'] or not deletion['containerregistryauth']['deleted']:
            raise RuntimeError('NIM cleanup did not confirm deletion; inspect cleanup.json immediately') from failure
    if failure:
        raise failure
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--credentials-path', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--guard-log', type=Path, required=True)
    parser.add_argument('--run', action='store_true', help='Create and bill one capped NIM Pod')
    args = parser.parse_args()
    if not args.run:
        raise ValueError('Explicit --run required for this billable pilot')
    print(json.dumps(asyncio.run(pilot(args.credentials_path, args.output_dir, args.guard_log)),
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
