"""One capped Sarvam Bulbul v3 Hindi native-stream session, with no retry."""
import asyncio
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.session_runner import run_session
from tts_arena.sessions import sarvam

OUT = ROOT / 'artifacts/sessions/sarvam-native-20260916'
KEY_FILE = '/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env'
CONFIG = {'model': 'bulbul:v3', 'language': 'hi-IN', 'speaker': 'shubh',
          'format': 'mp3', 'sample_rate': 24000,
          'min_buffer_size': 50, 'max_chunk_length': 150}
PARTS = [
    'नमस्ते। मैं आपकी अगली किस्त की तारीख और राशि की पुष्टि करने के लिए बोल रहा हूँ। ',
    'यदि इनमें कोई गलती है तो कृपया मुझे बीच में रोककर सही जानकारी बताइए।',
]


async def main():
    if OUT.exists():
        raise FileExistsError('Sarvam native trial already attempted; no repeat spend')
    if shutil.disk_usage(ROOT).free < 500 * 1024 * 1024:
        raise RuntimeError('Disk preflight failed')
    offline = {'SARVAM_API_KEY': 'offline-test-key'}
    sarvam.build_session(CONFIG, offline)
    actions = [
        {'type': 'text', 'text': PARTS[0], 'at_ms': 0},
        {'type': 'text', 'text': PARTS[1], 'at_ms': 80},
        {'type': 'flush', 'at_ms': 120},
    ]
    for action in actions:
        sarvam.encode_action(action, CONFIG)
    key = read_credentials(KEY_FILE).get('SARVAM_API_KEY')
    if not key:
        raise RuntimeError('Authorized Sarvam key unavailable')
    OUT.mkdir(parents=True)
    result = await run_session('sarvam', CONFIG, actions, OUT, seconds=12,
                               env={'SARVAM_API_KEY': key})
    print(json.dumps({'status': result['status'],
                      'error_type': result['error_type'],
                      'sent_action_count': result['sent_action_count'],
                      'audio_chunks': sum(e['event_type'] == 'audio_payload_received'
                                          for e in result['events']),
                      'audio_bytes': sum(a['bytes'] for a in result['audio']),
                      'final_observed': any(e['event_type'] == 'provider_event' and
                                            e.get('details', {}).get('type') == 'done'
                                            for e in result['events'])}))


if __name__ == '__main__':
    asyncio.run(main())
