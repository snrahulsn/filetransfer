"""One bounded current-generation session/provider, no automatic retries."""
import asyncio,json,sys,importlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tts_arena.session_runner import run_session
from tts_arena.credentials import read_credentials,redact
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/sessions-access-20260915'
async def main():
 OUT.mkdir(exist_ok=True,parents=True)
 creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 jobs=[('cartesia',{'model':'sonic-3.6','voice':'4459a9a5-69d6-4680-b970-e13dc51845b6','language':'hi-IN','format':'raw','encoding':'pcm_s16le','sample_rate':24000,'max_buffer_delay_ms':200,'add_timestamps':True},[
 {'at_ms':0,'type':'text','context_id':'first','text':'नमस्ते, '},{'at_ms':100,'type':'text','context_id':'first','text':'मैं आपकी मदद कर सकता हूँ। '},{'at_ms':200,'type':'flush','context_id':'first'},{'at_ms':400,'type':'end_input','context_id':'first'},
 {'at_ms':5000,'type':'text','context_id':'second','text':'क्या कल बात करना ठीक रहेगा? '},{'at_ms':5300,'type':'end_input','context_id':'second'},
 {'at_ms':8500,'type':'text','context_id':'cancelled','text':'मैं आपकी जानकारी जाँच रहा हूँ। '},{'at_ms':8600,'type':'text','context_id':'cancelled','text':'कृपया कुछ समय प्रतीक्षा करें। '},{'at_ms':8650,'type':'cancel','context_id':'cancelled'}]),
 ('elevenlabs',{'model':'eleven_v3_conversational','voice':'hpp4J3VqNfWAUOO0d1Us','language':'hi-IN','format':'pcm_24000','contexts':['first','second'],'context_id':'first','sync_alignment':True},[
 {'at_ms':0,'type':'text','context_id':'first','text':'नमस्ते, '},{'at_ms':100,'type':'text','context_id':'first','text':'मैं आपकी मदद कर सकता हूँ। '},{'at_ms':200,'type':'flush','context_id':'first'},{'at_ms':400,'type':'end_input','context_id':'first'},
 {'at_ms':5000,'type':'text','context_id':'second','text':'क्या कल बात करना ठीक रहेगा? '},{'at_ms':5300,'type':'end_input','context_id':'second'}])]
 for provider,config,actions in jobs:
  target=OUT/(provider+'.json')
  if target.exists():raise SystemExit('Refusing repeated live session: '+provider)
  assert sum(len(a.get('text','')) for a in actions)<=300
  module=importlib.import_module('tts_arena.sessions.'+provider);original=module.decode_message;diagnostics=[]
  def observed_decode(raw):
   events=original(raw)
   for e in events:
    if e.get('type')=='error':diagnostics.append(json.loads(redact(json.dumps(e),creds)))
   return events
  module.decode_message=observed_decode
  key='CARTESIA_API_KEY' if provider=='cartesia' else 'ELEVENLABS_API_KEY'
  try:
   r=await asyncio.wait_for(run_session(provider,config,actions,OUT/provider,seconds=15,env={key:creds[key]}),timeout=30)
   r['sanitized_provider_errors']=diagnostics
   target.write_text(redact(json.dumps(r,ensure_ascii=False,indent=2),creds)+'\n')
   print(provider,r['status'],r['error_type'],len(r['audio']),diagnostics,flush=True)
  except asyncio.TimeoutError:
   target.write_text(json.dumps({'provider':provider,'status':'inconclusive','reason':'30 second overall timeout','diagnostics':diagnostics})+'\n')
   print(provider,'overall timeout',flush=True)
  finally:module.decode_message=original
if __name__=='__main__':asyncio.run(main())
