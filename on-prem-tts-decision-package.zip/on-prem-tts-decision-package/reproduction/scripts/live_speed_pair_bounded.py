"""Two current-model Hindi rate pairs, fixed text and voice, max four calls."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/speed-pairs-20260915';RUNS=ROOT/'artifacts/runs/speed-pairs-20260915'
TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
PAIRS={
 'soniox':{'key':'SONIOX_API_KEY','source':'https://soniox.com/docs/api-reference/tts/generate_tts','config':{'model':'tts-rt-v2','voice':'Kavya','language':'hi-IN','format':'wav','sample_rate':24000},'values':[0.8,1.2]},
 'inworld':{'key':'INWORLD_API_KEY','source':'https://docs.inworld.ai/api-reference/ttsAPI/texttospeech/synthesize-speech','config':{'model':'inworld-tts-2','voice':'Meher','language':'hi-IN','format':'WAV','sample_rate':24000},'values':[1.0,1.4]},
}
async def main():
 if OUT.exists() or RUNS.exists():raise RuntimeError('Rate pair already attempted; no repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 for provider,p in PAIRS.items():
  key=secrets.get(p['key']);assert key and len(TEXT)<90
  for speed in p['values']:build_request(provider,TEXT,dict(p['config'],speed=speed),{p['key']:key})
 OUT.mkdir(parents=True);RUNS.mkdir(parents=True)
 report={'reference_text':TEXT,'request_limit':4,'automatic_retries':0,'pairs':{},'native_speed_accuracy':'unverified'}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',secrets))
 save()
 for provider,p in PAIRS.items():
  os.environ[p['key']]=secrets[p['key']]
  pair={'provider':provider,'model':p['config']['model'],'voice':p['config']['voice'],'source':p['source'],'source_accessed':'2026-09-15','status':'in_progress','records':[]};report['pairs'][provider]=pair;save()
  try:
   for index,speed in enumerate(p['values']):
    if index:await asyncio.sleep(2)
    cfg=dict(p['config'],speed=speed);pair['records'].append({'speed':speed,'status':'request_started','config':cfg});save()
    async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
     r=await run_one(provider,TEXT,cfg,RUNS,timeout=35,client=client,scenario_id='speed-'+str(speed),evaluation_language='hi-IN',stratum='speed_pair_bounded',min_free_bytes=300*1024*1024)
    pair['records'][-1].update({k:r.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','audio_sha256','first_audio_ms')});save();print(provider,speed,r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
   rows=pair['records']
   if len(rows)==2 and all(r['status']=='success' and r.get('duration_seconds') for r in rows):
    durations=[r['duration_seconds'] for r in rows];pair['status']='measured_pair';pair['duration_seconds']=durations;pair['ratio']=durations[1]/durations[0];pair['direction']='shorter_at_higher_setting' if durations[1]<durations[0] else 'not_shorter_at_higher_setting'
   else:pair['status']='blocked_no_retry'
   save()
  finally:os.environ.pop(p['key'],None)
 report['complete']=True;save()
if __name__=='__main__':asyncio.run(main())
