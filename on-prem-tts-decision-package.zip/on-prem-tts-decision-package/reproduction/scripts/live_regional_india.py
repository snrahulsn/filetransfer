"""Bounded missing-locale coverage probes. Audio delivery is not language accuracy."""
import asyncio
import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import provider as catalog_provider
from tts_arena.runner import run_one

ROOT=Path(__file__).resolve().parents[1]
TEXT={
 'bn-IN':'নমস্কার, আপনার পেমেন্ট পাওয়া গেছে। ধন্যবাদ।',
 'mr-IN':'नमस्कार, तुमचे पेमेंट मिळाले आहे. धन्यवाद.',
 'te-IN':'నమస్కారం, మీ చెల్లింపు అందింది. ధన్యవాదాలు.',
 'ta-IN':'வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி.',
 'gu-IN':'નમસ્તે, તમારી ચુકવણી મળી ગઈ છે. આભાર.',
 'kn-IN':'ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು.',
 'ml-IN':'നമസ്കാരം, നിങ്ങളുടെ പണം ലഭിച്ചു. നന്ദി.'}
PRO_VOICES={'bn-IN':'rajib','mr-IN':'mrunal','te-IN':'sravani','ta-IN':'malar','gu-IN':'krupa','kn-IN':'spoorthi','ml-IN':'parvathy'}
PROFILES={'sarvam':('bulbul:v3','SARVAM_API_KEY'), 'smallest':('lightning_v3.1_pro','SMALLEST_API_KEY')}

def write_report():
    lines=['# Regional audio delivery coverage','',
        'Draft language probes, 15 September 2026. “Audio returned” means the saved request produced parseable audio. It does not establish spoken language, pronunciation, accent, naturalness or content correctness. No native review has been completed. Urdu is unsupported in these reviewed model subsets and was not sent.','',
        'Prior runs retain their original code and catalog hashes. New probes fill missing target locales, with one documented voice per locale. This is coverage evidence, not a controlled ranking across voices.','']
    for provider in PROFILES:
        path=ROOT/'artifacts/coverage-20260915'/f'{provider}.json'
        if not path.exists():continue
        d=json.loads(path.read_text())
        lines += [f"## {provider} — {d['model']}",'',f"[Coverage JSON]({path})",'',
            '| Locale | Observation | Evidence |','|---|---|---|']
        for locale,state in d['locales'].items():
            ids=([state['run_id']] if state.get('run_id') else state['prior_run_ids'])
            links=[]
            for run_id in ids:
                matches=list((ROOT/'artifacts/runs').rglob(run_id+'/result.json'))
                if matches:
                    run=json.loads(matches[0].read_text());links.append(f'[record]({matches[0]})')
                    if run.get('audio_file'):links.append(f"[audio]({matches[0].parent/run['audio_file']})")
            lines.append(f"| {locale} | {state['observed_status']} | {' · '.join(links) or 'Documented model limitation; no request'} |")
        lines+=['']
    lines+=['The Sarvam Gujarati sample contains a small nonzero clipped-sample fraction recorded in its audio diagnostics. This is a numerical flag for later listening, not a perceptual defect verdict.']
    (ROOT/'docs/REGIONAL_COVERAGE_STATUS.md').write_text('\n'.join(lines)+'\n')

async def main():
    creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    for provider,(model,key) in PROFILES.items():
        path=ROOT/'artifacts/coverage-20260915'/f'{provider}.json'
        path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists():
            print(provider+': existing coverage retained; no automatic rerun');continue
        catalog=catalog_provider(provider)
        prior=json.loads((ROOT/'artifacts/access-20260915'/f'{provider}.json').read_text())
        prior_attempts=[a for a in prior.get('attempts',prior.get('runs',[])) if a.get('config',{}).get('model')==model]
        evidence={'provider':provider,'model':model,'date':'2026-09-15','scope':'Draft-text audio delivery coverage only; linguistic accuracy, accent and naturalness unverified',
                  'max_additional_requests':8,'max_characters_per_request':100,'timeout_seconds':30,'automatic_retries':0,
                  'voice_source':'https://docs.smallest.ai/models/documentation/text-to-speech-lightning/voices-languages' if provider=='smallest' else 'https://docs.sarvam.ai/api-reference/text-to-speech/convert',
                  'text_native_review':'not_reviewed','attempts':[],'locales':{}}
        for locale,claim in catalog['languages'].items():
            matching=[a for a in prior_attempts if a.get('language')==locale]
            successes=[a for a in matching if a.get('status')=='success']
            evidence['locales'][locale]={'documented_status':claim['status'],'observed_status':'audio_returned' if successes else 'unsupported' if claim['status']=='unsupported' else 'not_tested',
                  'linguistic_accuracy':'unverified','prior_run_ids':[a['run_id'] for a in matching],
                  'evidence_origin':'prior_historical_run' if matching else 'catalog_only'}
        def save(): path.write_text(redact(json.dumps(evidence,ensure_ascii=False,indent=2),creds)+'\n')
        save()
        jobs=[locale for locale,state in evidence['locales'].items() if state['documented_status']=='documented' and state['observed_status']=='not_tested' and locale in TEXT]
        assert len(jobs)<=8 and all(len(TEXT[locale])<=100 for locale in jobs)
        if not creds.get(key): evidence['blocker']='credential_missing';save();continue
        os.environ[key]=creds[key]
        errors=[]
        async def hook(response):
            if response.status_code>=400:
                await response.aread()
                errors.append({'http_status':response.status_code,'message':redact(response.text,creds)[:1500]})
        try:
            async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={'response':[hook]}) as client:
                for locale in jobs:
                    errors.clear()
                    config={'model':model,'voice':'shubh' if provider=='sarvam' else PRO_VOICES[locale], 'language':locale,'format':'wav','sample_rate':24000}
                    record=await run_one(provider,TEXT[locale],config,ROOT/'artifacts/runs/regional-20260915'/provider,timeout=30,client=client,scenario_id='regional-coverage-'+locale,stratum='draft_regional_audio_delivery')
                    returned=record['status']=='success' and record.get('audio_bytes',0)>0
                    attempt={k:record.get(k) for k in ['run_id','status','http_status','error_type','language','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms','audio_analysis','code_sha256','vendor_spec_sha256']}
                    attempt.update(config=config,observed_status='audio_returned' if returned else 'failed',linguistic_accuracy='unverified',diagnostics=errors.copy())
                    evidence['attempts'].append(attempt)
                    evidence['locales'][locale].update(observed_status=attempt['observed_status'],run_id=record['run_id'],evidence_origin='new_live_run')
                    save();print(provider+' '+locale+': '+attempt['observed_status']+' HTTP '+str(record.get('http_status')),flush=True)
                    if record.get('http_status') in (401,402,403,429) or any(any(term in e['message'].lower() for term in ('credit','quota','payment','balance','rate limit')) for e in errors):
                        evidence['blocker']='account_or_rate_failure';save();break
        finally:
            os.environ.pop(key,None)
        evidence['new_audio_returned']=sum(a['observed_status']=='audio_returned' for a in evidence['attempts'])
        evidence['locale_status_counts']={status:sum(v['observed_status']==status for v in evidence['locales'].values()) for status in ('audio_returned','failed','unsupported','not_tested')}
        save()
    write_report()

if __name__=='__main__': asyncio.run(main())
