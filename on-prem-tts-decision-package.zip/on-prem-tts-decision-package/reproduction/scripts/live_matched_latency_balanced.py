"""Balanced, no-retry Hindi PCM first-playable trial from one measured client egress."""
import argparse
import asyncio
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from live_matched_latency_bounded import PLANS,TEXT
from tts_arena.credentials import read_credentials
from tts_arena.registry import build_request,code_digest
from tts_arena.runner import run_one

OUT=ROOT/'artifacts/latency-balanced-20260915-v2'
REPETITIONS=12
ORDER=[['cartesia','elevenlabs'] if i%2==0 else ['elevenlabs','cartesia'] for i in range(REPETITIONS)]

async def egress_country(client):
 response=await client.get('https://www.cloudflare.com/cdn-cgi/trace')
 response.raise_for_status()
 countries=[line[4:] for line in response.text.splitlines() if line.startswith('loc=')]
 if len(countries)!=1 or len(countries[0])!=2 or not countries[0].isalpha():
  raise ValueError('Client egress country not established')
 return countries[0]

def preflight(credentials):
 for provider,entry in PLANS.items():
  key=credentials.get(entry['credential'])
  if not key:raise ValueError(entry['credential']+' unavailable')
  spec=build_request(provider,TEXT,entry['config'],{entry['credential']:key})
  if spec.sample_rate!=24000 or spec.encoding!='pcm_s16le' or spec.response_mode!='binary':
   raise ValueError(provider+' route must be binary 24 kHz PCM16')
 return {'schema':'balanced_hindi_first_playable_pcm_v2','created_at':datetime.now(timezone.utc).isoformat(),
  'source_code_sha256':code_digest(),'text_sha256':hashlib.sha256(TEXT.encode()).hexdigest(),
  'transcript':TEXT,'language':'hi-IN','audio_condition':'binary provider-native mono PCM16 at 24 kHz; no resampling',
  'metric':'client request start to first complete playable PCM frame',
  'client_policy':'one macOS host, no proxy, fresh TCP/TLS per request, sequential 0.7 second pacing',
  'provider_serving_region':'vendor route as deployed; not user-pinned or independently disclosed',
  'country_probe':'Cloudflare trace loc, HTTP GET with trust_env=False before and after vendor requests',
  'client_egress_country_start':None,'client_egress_country_end':None,
  'provider_orders':ORDER,'repetitions_per_provider':REPETITIONS,'max_vendor_requests':24,'automatic_retries':0,
  'providers':{p:{'config':v['config'],'attempts':0,'successes':0} for p,v in PLANS.items()},
  'attempts_total':0,'results':[],'status':'planned','cross_vendor_scope':'configured routes from observed India egress at this traffic level',
  'quality_certification':False,'cost_reconciled':False,'capacity_test':False}

async def live():
 if OUT.exists():raise RuntimeError('Balanced latency evidence already exists; no repeat spend')
 if shutil.disk_usage(ROOT).free<300*1024*1024:raise OSError('Evidence disk floor not met')
 credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 manifest=preflight(credentials)
 limits=httpx.Limits(max_connections=1,max_keepalive_connections=0)
 async with httpx.AsyncClient(timeout=10,limits=limits,trust_env=False,follow_redirects=False) as client:
  manifest['client_egress_country_start']=await egress_country(client)
 if manifest['client_egress_country_start']!='IN':
  raise RuntimeError('Current India egress condition absent; no vendor requests')
 OUT.mkdir(parents=True,exist_ok=False)
 def save():
  temporary=OUT/'manifest.json.partial'
  temporary.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
  os.replace(temporary,OUT/'manifest.json')
 save()
 for entry in PLANS.values():os.environ[entry['credential']]=credentials[entry['credential']]
 try:
  async with httpx.AsyncClient(timeout=30,limits=limits,trust_env=False,follow_redirects=False) as client:
   manifest['status']='running';save()
   for ordinal,order in enumerate(ORDER,1):
    for provider in order:
     entry=PLANS[provider]
     manifest['attempts_total']+=1;manifest['providers'][provider]['attempts']+=1;save()
     result=await run_one(provider,TEXT,entry['config'],OUT/'runs'/provider,timeout=30,client=client,
      scenario_id=f'balanced-hindi-{ordinal:02d}',evaluation_language='hi-IN',stratum='balanced_hindi_first_playable_pcm',min_free_bytes=300*1024*1024)
     row={k:result.get(k) for k in ('run_id','status','http_status','error_type','first_byte_ms','first_payload_ms','first_audio_ms','elapsed_ms','audio_sha256','audio_bytes','duration_seconds')}
     row.update(provider=provider,ordinal=ordinal,order_position=order.index(provider)+1,
      model=entry['config']['model'],voice=entry['config']['voice'],config=entry['config'],text_sha256=manifest['text_sha256'],
      source_result=str((OUT/'runs'/provider/result['run_id']/'result.json').relative_to(ROOT)))
     manifest['results'].append(row);save()
     if result['status']!='success' or result.get('http_status')!=200 or not result.get('first_audio_ms') or result.get('audio_bytes',0)<=0:
      manifest['status']='stopped_on_first_vendor_failure';save();return manifest
     manifest['providers'][provider]['successes']+=1;save()
     await asyncio.sleep(.7)
   manifest['client_egress_country_end']=await egress_country(client)
   manifest['status']='complete' if manifest['client_egress_country_end']==manifest['client_egress_country_start'] else 'egress_country_changed'
   save()
 finally:
  for entry in PLANS.values():os.environ.pop(entry['credential'],None)
 return manifest

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--live',action='store_true');args=parser.parse_args()
 credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 if args.live:
  observed=asyncio.run(live())
  print(json.dumps({'status':observed['status'],'vendor_requests':observed['attempts_total'],
   'successful':{p:v['successes'] for p,v in observed['providers'].items()},
   'egress_country_start':observed['client_egress_country_start'],'egress_country_end':observed['client_egress_country_end']}))
 else:
  planned=preflight(credentials)
  print(json.dumps({'status':'preflight_passed','max_vendor_requests':planned['max_vendor_requests'],
   'balanced_orders':len(planned['provider_orders'])}))
