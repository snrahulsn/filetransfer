"""Bounded ten-locale Soniox tts-rt-v2 REST synthesis, no retries or fallback."""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request,code_digest
from tts_arena.runner import run_one

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"artifacts/runs/soniox-20260915-bounded-floor"
MANIFEST=ROOT/"artifacts/access-20260915/soniox-live-bounded-floor.json"
PREVIOUS=[ROOT/"artifacts/runs/soniox-20260915",ROOT/"artifacts/runs/soniox-20260915-disk-resume"]
DISK_FLOOR_BYTES=300*1024*1024
CREDENTIALS="/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env"
VOICE="Kavya"
CASES=[
 ("hi-IN","meeting-hi-01","नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।"),
 ("en-IN","meeting-en-01","Hello, your meeting is tomorrow at three in the afternoon. Please confirm the time."),
 ("bn-IN","payment-bn-01","নমস্কার, আপনার পেমেন্ট পাওয়া গেছে। ধন্যবাদ।"),
 ("mr-IN","payment-mr-01","नमस्कार, तुमचे पेमेंट मिळाले आहे. धन्यवाद."),
 ("te-IN","payment-te-01","నమస్కారం, మీ చెల్లింపు అందింది. ధన్యవాదాలు."),
 ("ta-IN","payment-ta-01","வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி."),
 ("gu-IN","payment-gu-01","નમસ્તે, તમારી ચુકવણી મળી ગઈ છે. આભાર."),
 ("ur-IN","installment-ur-01","آپ کی قسط کی رقم ₹15,000 ہے۔"),
 ("kn-IN","payment-kn-01","ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು."),
 ("ml-IN","payment-ml-01","നമസ്കാരം, നിങ്ങളുടെ പണം ലഭിച്ചു. നന്ദി."),
]


async def main():
    if OUT.exists() or MANIFEST.exists():raise RuntimeError("Existing Soniox spend/evidence; no automatic repeat")
    prior=[path for folder in PREVIOUS for path in folder.glob("*/result.json")]
    if len(prior)!=2:raise RuntimeError("Expected two preserved Soniox preflight records")
    for path in prior:
        prior_record=json.loads(path.read_text())
        if prior_record.get("network_attempted") is not False or prior_record.get("error_type")!="InsufficientDiskSpace":
            raise RuntimeError("Prior record may have reached network; refusing new evaluation")
    secrets=read_credentials(CREDENTIALS)
    key=secrets.get("SONIOX_API_KEY")
    if not key:raise ValueError("Soniox key missing from authorized evaluation file")
    configs=[{"model":"tts-rt-v2","voice":VOICE,"language":locale,"format":"wav","sample_rate":24000,"region":"global"} for locale,_,_ in CASES]
    for (_,_,text),config in zip(CASES,configs):build_request("soniox",text,config,{"SONIOX_API_KEY":key})
    OUT.mkdir(parents=True,exist_ok=False)
    MANIFEST.parent.mkdir(parents=True,exist_ok=True)
    report={"provider":"soniox","model":"tts-rt-v2","voice":VOICE,"region":"global",
            "purpose":"Matched-text one-file-per-locale access and listening pilot, not native quality certification",
            "code_sha256":code_digest(),"request_limit":len(CASES),"automatic_retries":0,"samples":[],
            "native_listener_ratings":0,"production_calls":0,"actual_billing_reconciled":False,
            "disk_floor_bytes":DISK_FLOOR_BYTES,
            "previous_preflight_blocked_records":[str(path.relative_to(ROOT)) for path in prior]}
    def save():MANIFEST.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+"\n",secrets))
    save()
    errors=[]
    async def hook(response):
        if response.status_code>=400:
            body=(await response.aread())[:1200].decode(errors="replace")
            errors.append({"http_status":response.status_code,"body":redact(body,secrets)})
    os.environ["SONIOX_API_KEY"]=key
    try:
        async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False,event_hooks={"response":[hook]}) as client:
            for (locale,scenario,text),config in zip(CASES,configs):
                sample={"locale":locale,"scenario_id":scenario,"text":text,"text_sha256":hashlib.sha256(text.encode()).hexdigest(),"config":config,"status":"request_started"}
                report["samples"].append(sample);save()
                before=len(errors)
                run=await run_one("soniox",text,config,OUT,timeout=35,client=client,scenario_id=scenario,evaluation_language=locale,stratum="matched_language_pilot",min_free_bytes=DISK_FLOOR_BYTES)
                sample.update({k:run.get(k) for k in ("run_id","status","http_status","error_type","elapsed_ms","first_audio_ms","duration_seconds","audio_analysis")})
                sample["result_file"]=str((OUT/run["run_id"]/"result.json").relative_to(ROOT))
                sample["diagnostics"]=errors[before:]
                if run.get("audio_file"):
                    path=OUT/run["run_id"]/run["audio_file"]
                    sample["audio_file"]=str(path.relative_to(ROOT))
                    sample["listening_audio_sha256"]=hashlib.sha256(path.read_bytes()).hexdigest()
                save();print(locale,run["status"],run.get("http_status"),run.get("duration_seconds"),flush=True)
                if run["status"]!="success":
                    report["stop_reason"]="first_failure_no_retry_or_fallback";break
                await asyncio.sleep(.5)
    finally:os.environ.pop("SONIOX_API_KEY",None)
    report["successful_syntheses"]=sum(s["status"]=="success" for s in report["samples"])
    report["completed"]=True;save()
    print("successes",report["successful_syntheses"],"attempts",len(report["samples"]))


if __name__=="__main__":asyncio.run(main())
