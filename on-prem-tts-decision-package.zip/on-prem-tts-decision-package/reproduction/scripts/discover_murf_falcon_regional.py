"""Read-only current Falcon 2 voice/locale entitlement discovery."""
import json,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
OUT=ROOT/'artifacts/murf-falcon-discovery-20260915.json'
if OUT.exists():raise RuntimeError('Existing discovery; no repeated account call')
key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('MURF_API_KEY')
if not key:raise RuntimeError('No authorized Murf key')
targets=['bn-IN','mr-IN','te-IN','gu-IN','kn-IN','ml-IN','ur-IN']
r=httpx.get('https://api.murf.ai/v1/speech/voices',params={'model':'falcon-2'},headers={'api-key':key},timeout=20,trust_env=False,follow_redirects=False)
report={'provider':'murf','model':'falcon-2','source':'https://murf.ai/api/docs/api-reference/voices/get-voices','http_status':r.status_code,'targets':targets,'selected':{},'raw_voice_count':0,'credential_saved':False}
if r.status_code==200:
 data=r.json()
 voices=data if isinstance(data,list) else data.get('voices',[]) if isinstance(data,dict) else []
 report['raw_voice_count']=len(voices)
 for locale in targets:
  eligible=[v for v in voices if isinstance(v,dict) and isinstance(v.get('voiceId'),str) and (v.get('locale')==locale or locale in (v.get('supportedLocales') or {}))]
  eligible.sort(key=lambda v:(v.get('locale')!=locale,v['voiceId']))
  if eligible:report['selected'][locale]={'voice_id':eligible[0]['voiceId'],'native_locale':eligible[0].get('locale')==locale,'eligible_voice_count':len(eligible),'supported_locale_listed':True}
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'http_status':report['http_status'],'voice_count':report['raw_voice_count'],'selected':report['selected']}))
