"""Acoustic silence diagnostics only; no semantic alignment or perceptual verdict."""
import array,math,wave,sys
from pathlib import Path

def silence_gaps(path, threshold_dbfs=-40.0, window_ms=10, minimum_gap_ms=80):
    with wave.open(str(path),'rb') as w:
        if w.getsampwidth()!=2 or w.getnchannels()!=1:raise ValueError('16-bit mono WAV required')
        rate=w.getframerate();samples=array.array('h',w.readframes(w.getnframes()))
    if sys.byteorder!='little':samples.byteswap()
    if not -120<=threshold_dbfs<0 or window_ms<=0 or minimum_gap_ms<0:raise ValueError('Invalid diagnostic thresholds')
    step=max(1,round(rate*window_ms/1000));threshold=32768*10**(threshold_dbfs/20);gaps=[];start=None
    for i in range(0,len(samples),step):
        block=samples[i:i+step];quiet=math.sqrt(sum(v*v for v in block)/len(block))<=threshold
        if quiet and start is None:start=i
        if not quiet and start is not None:
            gaps.append((start,i));start=None
    if start is not None:gaps.append((start,len(samples)))
    kept=[{'start_seconds':a/rate,'end_seconds':b/rate,'duration_seconds':(b-a)/rate,'internal':a>0 and b<len(samples)} for a,b in gaps if (b-a)*1000/rate>=minimum_gap_ms]
    internal=[g['duration_seconds'] for g in kept if g['internal']]
    return dict(threshold_dbfs=threshold_dbfs,window_ms=window_ms,minimum_gap_ms=minimum_gap_ms,duration_seconds=len(samples)/rate,gaps=kept,longest_internal_gap_seconds=max(internal,default=0),semantic_alignment='not_performed',scope='Thresholded low-energy audio regions, not word or SSML-position alignment')
