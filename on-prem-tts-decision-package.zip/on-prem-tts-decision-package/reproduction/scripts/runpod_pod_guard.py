"""Independent hard-timeout deletion for a disposable evaluation Pod.

Start detached immediately after Pod creation; deletion is idempotent on HTTP 404.
"""
import argparse
import json
import time
import urllib.error
import urllib.request
from pathlib import Path


def delete_pod(pod_id: str, key: str) -> tuple[int, str]:
    request = urllib.request.Request(
        f"https://rest.runpod.io/v1/pods/{pod_id}",
        method="DELETE",
        headers={
            "Authorization": f"Bearer {key}",
            "User-Agent": "Mozilla/5.0 Chrome/124.0.0.0 Safari/537.36",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return response.status, response.read(512).decode("utf-8", "replace")
    except urllib.error.HTTPError as error:
        return error.code, error.read(512).decode("utf-8", "replace")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pod-id", required=True)
    parser.add_argument("--key-file", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=3600)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args()
    if args.seconds < 60 or args.seconds > 7200:
        raise ValueError("Guard interval must be 60–7200 seconds")
    key = args.key_file.read_text(encoding="utf-8").strip()
    deadline = time.monotonic() + args.seconds
    while time.monotonic() < deadline:
        time.sleep(min(20, deadline - time.monotonic()))
    attempts = []
    for retry in range(5):
        status, body = delete_pod(args.pod_id, key)
        attempts.append({"status": status, "response": body[:200]})
        if status in (204, 404):
            break
        time.sleep(10 * (retry + 1))
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.log.write_text(json.dumps({"pod_id": args.pod_id, "attempts": attempts}), encoding="utf-8")


if __name__ == "__main__":
    main()
