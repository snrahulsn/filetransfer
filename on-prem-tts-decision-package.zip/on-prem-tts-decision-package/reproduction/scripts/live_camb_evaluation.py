"""Three bounded current-model probes using saved authenticated discovery; no retries."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
async def main():
 out=ROOT/'artifacts/access-20260915/camb.json'
 if out.exists(): raise SystemExit('Existing probe preserved; automatic repeat prohibited')
 creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 discovery=json.loads((out.parent/'camb-discovery.json').read_text())
 assert discovery['http_status']==200
 assert any(v['id']==170924 and v['language']==81 for v in discovery['voices'])
 result={'provider':'camb','accessed':'2026-09-15','credential_alias':'CAMB_API_KEY','discovery_path':'artifacts/access-20260915/camb-discovery.json','language_mapping_path':'artifacts/access-20260915/camb-languages.json','selected_voice':{'id':170924,'name':'Aarav Verma','reference_language':'hi-IN'},'attempts':[],'automatic_retries':0,'quality_status':'not_evaluated','scope':'Current mars-instruct instruction acceptance smoke; no emotion effectiveness or Indian accent claim'}
 def save():out.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
 errors=[];headers=[]
 async def hook(r):
  headers.append({k:v for k,v in r.headers.items() if k.lower() in ('content-type','x-credits-required')})
  if r.status_code>=400:
   await r.aread();errors.append({'http_status':r.status_code,'message':redact(r.text,creds)[:1200]})
 save()
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  os.environ['CAMB_API_KEY']=creds['CAMB_API_KEY']
  try:
   for label,lang,text,instruction in [('hi-calm','hi-IN','नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।','Calm, gentle and reassuring.'),('hi-cheerful','hi-IN','नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।','Warm, cheerful and enthusiastic.'),('en-india','en-IN','Hello, we have received your payment. Thank you.','Warm, clear and conversational.')]:
    errors.clear();headers.clear()
    config={'model':'mars-instruct','voice':170924,'language':lang,'format':'wav','user_instructions':instruction}
    rec=await run_one('camb',text,config,ROOT/'artifacts/runs/camb-evaluation-20260915',timeout=30,client=client,scenario_id=label,stratum='draft_access_probe')
    a={k:rec.get(k) for k in ['run_id','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms']};a.update(config=config,diagnostics=list(errors),response_headers=list(headers));result['attempts'].append(a);save();print(label,rec['status'],rec.get('http_status'),flush=True)
    if rec['status']!='success':break
  finally:os.environ.pop('CAMB_API_KEY',None)
 result['successful_syntheses']=sum(a['status']=='success' for a in result['attempts']);result['current_access']='synthesis_confirmed' if result['successful_syntheses'] else 'synthesis_blocked';save()
if __name__=='__main__':asyncio.run(main())
