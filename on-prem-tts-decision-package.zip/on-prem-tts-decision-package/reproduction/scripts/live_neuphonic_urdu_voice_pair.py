"""Discover current Urdu voices and synthesize one short fixture per voice, capped at two."""
import argparse
import asyncio
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.registry import build_request, code_digest
from tts_arena.runner import run_one

OUT = ROOT / 'artifacts/neuphonic-urdu-20260916'
TEXT = 'آپ کی قسط کی رقم ₹15,000 ہے۔'
VOICE_ENDPOINT = 'https://api.neuphonic.com/voices'
DOC = 'https://docs.neuphonic.com/build-group/languages'


def config(voice):
    return {'voice': voice, 'language': 'ur', 'format': 'pcm_linear', 'sample_rate': 24000}


def selected_voices(body):
    if not isinstance(body, dict) or not isinstance(body.get('data'), dict):
        raise ValueError('Neuphonic voice listing has no data object')
    voices = body['data'].get('voices')
    if not isinstance(voices, list) or len(voices) > 500:
        raise ValueError('Neuphonic voice listing size invalid')
    urdu = [v for v in voices if isinstance(v, dict) and v.get('lang_code') == 'ur'
            and v.get('type') == 'Standard' and isinstance(v.get('id'), str)
            and v.get('id') == v.get('voice_id') and type(v.get('default')) is bool]
    if len(urdu) != 2 or sum(v['default'] for v in urdu) != 1 or len({v['id'] for v in urdu}) != 2:
        raise ValueError('Expected one default and one alternate current Urdu Standard voice')
    return len(voices), sorted(urdu, key=lambda v: (not v['default'], v['id']))


async def live():
    if OUT.exists():
        raise RuntimeError('Neuphonic Urdu pair already attempted; no automatic repeat')
    if shutil.disk_usage(ROOT).free < 300 * 1024 * 1024:
        raise OSError('Evidence disk floor not met')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    key = credentials.get('NEUPHONIC_API_KEY')
    if not key:
        raise ValueError('Authorized Neuphonic API key unavailable')
    async with httpx.AsyncClient(timeout=10, trust_env=False, follow_redirects=False) as client:
        response = await client.get(VOICE_ENDPOINT, headers={'x-api-key': key})
    response.raise_for_status()
    count, urdu = selected_voices(response.json())
    for voice in urdu:
        spec = build_request('neuphonic', TEXT, config(voice['id']), {'NEUPHONIC_API_KEY': key})
        if (spec.url != 'https://api.neuphonic.com/sse/speak/ur' or spec.response_mode != 'sse_base64'
            or spec.encoding != 'pcm_s16le' or spec.sample_rate != 24000):
            raise ValueError('Neuphonic Urdu synthesis contract mismatch')
    manifest = {'schema': 'neuphonic_urdu_standard_voice_pair_v1',
                'created_at': datetime.now(timezone.utc).isoformat(),
                'provider': 'neuphonic', 'requested_locale': 'ur-IN',
                'documented_lang_code': 'ur', 'documentation': DOC,
                'voice_list_url': VOICE_ENDPOINT, 'voice_list_http_status': response.status_code,
                'voice_list_sha256': hashlib.sha256(response.content).hexdigest(),
                'voice_count': count, 'selected': [{'voice_id': v['id'], 'default': v['default'],
                                                    'type': v['type'], 'lang_code': v['lang_code']} for v in urdu],
                'text': TEXT, 'text_sha256': hashlib.sha256(TEXT.encode()).hexdigest(),
                'source_code_sha256': code_digest(), 'max_synthesis_requests': 2,
                'automatic_retries': 0, 'attempts': 0, 'results': [], 'status': 'planned',
                'native_quality': 'unreviewed', 'voice_backend_model': 'not_disclosed_by_voice_listing',
                'boundary': 'SSE PCM payload received; exact Urdu correctness and voice quality unreviewed'}
    OUT.mkdir(parents=True, exist_ok=False)
    def save():
        temporary = OUT / 'manifest.json.partial'
        temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        os.replace(temporary, OUT / 'manifest.json')
    save()
    manifest['status'] = 'running'
    save()
    for ordinal, voice in enumerate(urdu, 1):
        manifest['attempts'] += 1
        save()
        try:
            os.environ['NEUPHONIC_API_KEY'] = key
            try:
                async with httpx.AsyncClient(timeout=30, trust_env=False, follow_redirects=False) as client:
                    result = await run_one('neuphonic', TEXT, config(voice['id']), OUT / 'runs',
                                           timeout=30, client=client, evaluation_language='ur-IN',
                                           scenario_id=f"urdu-standard-{ordinal}",
                                           stratum='neuphonic_urdu_voice_pair',
                                           min_free_bytes=300 * 1024 * 1024)
            finally:
                os.environ.pop('NEUPHONIC_API_KEY', None)
            row = {k: result.get(k) for k in ('run_id', 'status', 'http_status', 'error_type',
                   'audio_bytes', 'audio_sha256', 'first_audio_ms', 'duration_seconds')}
            row.update(voice_id=voice['id'], default=voice['default'], ordinal=ordinal,
                       source_result=str((OUT / 'runs' / result['run_id'] / 'result.json').relative_to(ROOT)))
            manifest['results'].append(row)
            if result['status'] != 'success' or result.get('http_status') != 200 or not result.get('audio_bytes', 0) > 0:
                manifest['status'] = 'stopped_on_first_synthesis_failure'
                save()
                return manifest
        except Exception as exc:
            manifest['results'].append({'ordinal': ordinal, 'voice_id': voice['id'],
                                        'status': 'error', 'error_type': type(exc).__name__})
            manifest['status'] = 'stopped_on_first_synthesis_failure'
            save()
            return manifest
        save()
        if ordinal < len(urdu):
            await asyncio.sleep(.7)
    manifest['status'] = 'complete'
    save()
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    if args.live:
        observed = asyncio.run(live())
        print(json.dumps({'status': observed['status'], 'attempts': observed['attempts'],
                          'http_statuses': [r.get('http_status') for r in observed['results']],
                          'audio_bytes': [r.get('audio_bytes') for r in observed['results']]}))
    else:
        key = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('NEUPHONIC_API_KEY')
        if not key:
            raise ValueError('Authorized Neuphonic key unavailable')
        print(json.dumps({'status': 'preflight_passed', 'route': 'https://api.neuphonic.com/sse/speak/ur',
                          'max_synthesis_requests': 2, 'automatic_retries': 0}))
