"""One authorized current-model timestamp stream; no retries."""
import asyncio,json,os,sys,wave
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
async def main():
    out=ROOT/"artifacts/speechify-timestamps-20260915";out.mkdir(exist_ok=True)
    with (out/"started").open("x") as f:f.write("One bounded authorized synthesis; never retry automatically.\n")
    credentials=read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env")
    wire=bytearray();headers={}
    class Capture(httpx.AsyncByteStream):
        def __init__(self,original):self.original=original
        async def __aiter__(self):
            async for chunk in self.original:
                if len(wire)+len(chunk)>2000000:raise ValueError("Probe wire bound exceeded")
                wire.extend(chunk);yield chunk
        async def aclose(self):await self.original.aclose()
    async def hook(response):
        headers.update({k:v for k,v in response.headers.items() if k.lower() in {"content-type","speechify-audio-content-type","speechify-request-id"}})
        response.stream=Capture(response.stream)
    os.environ["SPEECHIFY_API_KEY"]=credentials["SPEECHIFY_API_KEY"]
    try:
        async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={"response":[hook]}) as client:
            config={"model":"simba-3.2","voice":"ankit","language":"en-IN","format":"pcm_16000","api_version":"2026-09-15","mode":"stream_with_timestamps"}
            record=await run_one("speechify","Hello, your appointment is confirmed. Thank you.",config,out/"runs",timeout=30,client=client,scenario_id="speechify-current-timestamps",stratum="draft_feature_probe")
        (out/"wire.sse").write_text(redact(wire.decode("utf-8"),credentials))
        summary={"provider":"speechify","model":"simba-3.2","run_id":record["run_id"],"status":record["status"],"http_status":record.get("http_status"),"response_headers":headers,"timing_metadata":record.get("provider_metadata"),"usage":record.get("provider_usage"),"alignment_accuracy":"unverified","scope":"One English timestamp transport probe, not native linguistic or alignment certification","automatic_retries":0}
        (out/"summary.json").write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),credentials)+"\n")
        if record["status"]=="success":
            folder=out/"runs"/record["run_id"]
            with wave.open(str(out/"listen.wav"),"wb") as wav:wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(16000);wav.writeframes((folder/record["audio_file"]).read_bytes())
        print(json.dumps({k:record.get(k) for k in ("run_id","status","http_status","audio_bytes","duration_seconds","error_type")}))
    finally:os.environ.pop("SPEECHIFY_API_KEY",None)
if __name__=="__main__":asyncio.run(main())
