"""Export an allowlisted, credential-free evidence snapshot for the private UI."""
import hashlib
import io
import sys
import json
from pathlib import Path
import sys
import wave
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from tts_arena.registry import catalog, code_digest
from tts_arena.live_evidence import load_live_runs, summarize_live_runs
from tts_arena.transcript_quality import evaluate_transcripts
from tts_arena.deepgram_flux_evidence import verify as verify_deepgram_flux_interrupt
from tts_arena.matched_latency_evidence import verify as verify_matched_latency
from tts_arena.fish_timestamp_evidence import verify as verify_fish_timestamps
from tts_arena.fish_transport_latency_evidence import verify as verify_fish_transport_latency
from tts_arena.sarvam_transport_latency_evidence import verify as verify_sarvam_transport_latency
from tts_arena.neuphonic_urdu_evidence import verify as verify_neuphonic_urdu
from tts_arena.murf_native_evidence import verify as verify_murf_native
from tts_arena.murf_clear_evidence import verify as verify_murf_clear
from tts_arena.murf_locale_style_evidence import verify as verify_murf_locale_styles
from tts_arena.streaming_wav import repair_header as repair_streaming_wav_header
from tts_arena.public_audio_integrity import verify as verify_public_audio
from tts_arena.codemix_asr_evidence import verify as verify_codemix_asr
from tts_arena.regional_asr_evidence import verify as verify_regional_asr
from tts_arena.current_revision_api_evidence import verify as verify_current_revision_api
from tts_arena.soniox_playout_evidence import verify as verify_soniox_playout
from tts_arena.sarvam_native_evidence import verify as verify_sarvam_native
from tts_arena.sarvam_playout_evidence import verify as verify_sarvam_playout, wav_from_pcm as sarvam_pcm_wav
from tts_arena.g711 import mulaw_to_wav
from tts_arena.cartesia_telephony_evidence import verify_cartesia_telephony
from tts_arena.elevenlabs_telephony_evidence import verify as verify_elevenlabs_telephony
from tts_arena.neuphonic_speed_evidence import verify as verify_neuphonic_speed
from tts_arena.language_review_evidence import verify as verify_language_review
from tts_arena.soniox_speed_evidence import verify_four_setting_sweep as verify_soniox_speed
from tts_arena.voicemaker_studio_evidence import verify as verify_voicemaker_studio, verify_regional as verify_voicemaker_regional
from tts_arena.maya2_studio_evidence import verify as verify_maya2_studio, verify_usage as verify_maya2_studio_usage

def export(destination=ROOT/'ui/public/evidence'):
 destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 (destination/'audio').mkdir(exist_ok=True)
 # Publish the exact-run modeled minute-cost table as a separate downloadable
 # evidence object. It is deliberately kept separate from authoritative rate
 # rows and is labelled non-billed in the source artifact.
 modeled_rates=ROOT/'artifacts/list-rate-minute-model-20260916/model.json'
 if modeled_rates.exists():
  (destination/'list-rate-minute-model.json').write_bytes(modeled_rates.read_bytes())
 studio_usage=json.loads((ROOT/'artifacts/voicemaker-studio-20260916/studio-usage-after.json').read_text())
 if studio_usage['used_studio_credits_after_eight_clips']!=1024 or studio_usage['observed_increment_for_seven_regional_clips']!=812 or studio_usage['developer_api_character_entitlement']!=0:
  raise ValueError('Voicemaker Studio allowance observation changed')
 (destination/'voicemaker-studio-usage.json').write_text(json.dumps(studio_usage,indent=2)+'\n')
 providers=catalog();runs,issues=load_live_runs(ROOT/'artifacts')
 local_runs=[]
 if issues: raise ValueError(issues)
 paths={}
 for p in (ROOT/'artifacts').rglob('result.json'):
  d=json.loads(p.read_text())
  if d.get('evidence_class') in {'live_http','local_model_execution'}: paths[d['run_id']]=p
  if d.get('evidence_class')=='local_model_execution': local_runs.append(d)
 matched=json.loads((ROOT/'artifacts/matched-20260915/manifest.json').read_text())
 matched_ids={s['run_id'] for s in matched['samples'] if s.get('run_id')}
 public_runs=[]
 for r in sorted(runs+local_runs,key=lambda r:r.get('created_at',''),reverse=True):
  fields=('run_id','provider','language','stratum','scenario_id','created_at','status','http_status','error_type','text','first_audio_ms','first_byte_ms','elapsed_ms','duration_seconds','realtime_factor','audio_analysis','code_sha256','vendor_spec_sha256','first_audio_boundary')
  row={k:r.get(k) for k in fields}
  row['evidence_class']=r.get('evidence_class')
  if r.get('evidence_class')=='local_model_execution':
   row['local_runtime']={k:v for k,v in r.get('local_runtime',{}).items() if k in {'sample_rate','encoding','model_revision','dependency_versions','initialization_seconds','synthesis_seconds','streaming'}}
  row['config']={k:v for k,v in r.get('config',{}).items() if k in {'model','voice','language','format','encoding','sample_rate','device','model_revision','api_version','mode','user_instructions','speaking_rate','speed','pace','rate','emotion','instructions','instruction','delivery_mode','style','instruct','volume','voice_settings'}}
  row['matched']=r['run_id'] in matched_ids
  row['audio_url']=None
  if r.get('status')=='success' and r.get('audio_file'):
   source=(paths[r['run_id']].parent/r['audio_file']).resolve()
   if not source.is_relative_to(ROOT/'artifacts'): raise ValueError('Audio outside evidence root')
   raw=source.read_bytes()
   if hashlib.sha256(raw).hexdigest()!=r['audio_sha256']: raise ValueError('Audio hash mismatch')
   contract=r.get('request_contract',{})
   header_audit=None
   if raw[:4]==b'RIFF' and raw[8:12]==b'WAVE':
    wav,header_audit=repair_streaming_wav_header(raw)
   elif contract.get('encoding')=='pcm_s16le' and contract.get('sample_rate') and len(raw)%2==0:
    out=io.BytesIO()
    with wave.open(out,'wb') as w:
     w.setnchannels(r.get('audio_analysis',{}).get('channels',1));w.setsampwidth(2);w.setframerate(contract['sample_rate']);w.writeframes(raw)
    wav=out.getvalue()
   elif contract.get('encoding')=='mulaw' and contract.get('sample_rate')==8000:
    wav=mulaw_to_wav(raw)
    row['listening_derivation']='G.711 mu-law decoded to PCM16 WAV at original 8 kHz; no resampling'
    row['duration_seconds']=len(raw)/8000
    row['audio_analysis']={'analysis_status':'derived_g711_duration','sample_rate':8000,'channels':1,'duration_seconds':len(raw)/8000}
   else: wav=None
   if wav:
    repaired=bool(header_audit and header_audit['header_repaired'])
    name=r['run_id']+('-standard.wav' if repaired else '.wav')
    if repaired:
     legacy_name=r['run_id']+'.wav'
     (destination/'audio'/legacy_name).write_bytes(raw)
     row['raw_listening_audio_url']='/evidence/audio/'+legacy_name
     row['raw_listening_audio_sha256']=hashlib.sha256(raw).hexdigest()
     row['audio_header_repair']={k:header_audit[k] for k in ('sample_rate','pcm_bytes','duration_seconds','original_riff_size','original_data_size','data_offset')}
     if r.get('duration_seconds') is not None and abs(header_audit['duration_seconds']-r['duration_seconds'])>0.05:
      raise ValueError('Streaming WAV duration disagrees with saved live analysis')
    (destination/'audio'/name).write_bytes(wav)
    row['audio_url']='/evidence/audio/'+name;row['listening_audio_sha256']=hashlib.sha256(wav).hexdigest()
  public_runs.append(row)
 cartesia_telephony=verify_cartesia_telephony(ROOT/'artifacts/cartesia-telephony-20260916')
 cartesia_public=next((r for r in public_runs if r['run_id']==cartesia_telephony['run_id']),None)
 if not cartesia_public or cartesia_public.get('listening_audio_sha256')!=cartesia_telephony['listening_wav_sha256']:
  raise ValueError('Cartesia G.711 run lacks its verified published listening WAV')
 elevenlabs_telephony=verify_elevenlabs_telephony(ROOT/'artifacts/elevenlabs-telephony-20260916')
 elevenlabs_public=next((r for r in public_runs if r['run_id']==elevenlabs_telephony['run_id']),None)
 if not elevenlabs_public or elevenlabs_public.get('listening_audio_sha256')!=elevenlabs_telephony['listening_wav_sha256']:
  raise ValueError('ElevenLabs G.711 run lacks its verified published listening WAV')
 neuphonic_speed=verify_neuphonic_speed(ROOT/'artifacts/neuphonic-speed-20260916')
 for clip in neuphonic_speed['clips']:
  public=next((r for r in public_runs if r['run_id']==clip['run_id']),None)
  if not public or not public.get('audio_url') or public.get('duration_seconds')!=clip['duration_seconds']:
   raise ValueError('Neuphonic speed pair lacks exactly matched published audio')
  wav=(destination.parent/public['audio_url'].lstrip('/')).read_bytes()
  with wave.open(io.BytesIO(wav),'rb') as decoded:
   if (decoded.getnchannels(),decoded.getsampwidth(),decoded.getframerate(),decoded.getnframes()*2)!=(1,2,24000,clip['audio_bytes']):
    raise ValueError('Neuphonic speed published PCM shape mismatch')
   if hashlib.sha256(decoded.readframes(decoded.getnframes())).hexdigest()!=clip['audio_sha256']:
    raise ValueError('Neuphonic speed published PCM differs from raw source')
  if hashlib.sha256(wav).hexdigest()!=public['listening_audio_sha256']:
   raise ValueError('Neuphonic speed published WAV hash mismatch')
 (destination/'neuphonic-speed-audit.json').write_text(json.dumps(neuphonic_speed,ensure_ascii=False,indent=2)+'\n')
 soniox_speed=verify_soniox_speed(ROOT)
 for clip in soniox_speed['sweep_clips']:
  public=next((r for r in public_runs if r['run_id']==clip['run_id']),None)
  if (not public or not public.get('audio_url') or
      public.get('listening_audio_sha256')!=clip['playable_wav_sha256']):
   raise ValueError('Soniox speed pair lacks verified playable site audio')
 (destination/'soniox-speed-audit.json').write_text(json.dumps(soniox_speed,ensure_ascii=False,indent=2)+'\n')
 latency_exploratory=verify_matched_latency(ROOT/'artifacts/latency-matched-20260915-v1')
 latency_audit=verify_matched_latency(ROOT/'artifacts/latency-balanced-20260915-v2')
 fish_transport_latency_audit=verify_fish_transport_latency(ROOT/'artifacts/fish-transport-latency-20260916')
 sarvam_transport_latency_audit=verify_sarvam_transport_latency(ROOT/'artifacts/sarvam-transport-latency-20260916-v2')
 neuphonic_urdu_audit=verify_neuphonic_urdu(ROOT/'artifacts/neuphonic-urdu-20260916')
 neuphonic_published={r['run_id'] for r in public_runs if r['provider']=='neuphonic' and r['language']=='ur-IN' and r.get('audio_url')}
 if neuphonic_published!={r['run_id'] for r in neuphonic_urdu_audit['results']}:
  raise ValueError('Neuphonic two-voice Urdu audit lacks exactly matched published audio')
 latency_manifests=[json.loads((ROOT/f'artifacts/{folder}/manifest.json').read_text()) for folder in
                    ('latency-matched-20260915-v1','latency-balanced-20260915-v2')]
 latency_ids={r['run_id'] for manifest in latency_manifests for r in manifest['results']}
 published={r['run_id'] for r in public_runs if r.get('audio_url')}
 if not latency_ids<=published:raise ValueError('Repeated latency sample lacks published audio')
 (destination/'latency-matched-audit.json').write_text(json.dumps(latency_audit,ensure_ascii=False,indent=2)+'\n')
 (destination/'latency-exploratory-audit.json').write_text(json.dumps(latency_exploratory,ensure_ascii=False,indent=2)+'\n')
 (destination/'fish-transport-latency-audit.json').write_text(json.dumps(fish_transport_latency_audit,ensure_ascii=False,indent=2)+'\n')
 (destination/'sarvam-transport-latency-audit.json').write_text(json.dumps(sarvam_transport_latency_audit,ensure_ascii=False,indent=2)+'\n')
 (destination/'neuphonic-urdu-audit.json').write_text(json.dumps(neuphonic_urdu_audit,ensure_ascii=False,indent=2)+'\n')
 # Catalog excludes credential variable lists; claims retain their exact scope and primary sources.
 provider_fields=('id','name','kind','models','model_language_scope','integration_status','integration_notes','assessment_status','evaluation_scope','languages','features','sources','pricing')
 release=json.loads((ROOT/'artifacts/verification/release-status.json').read_text())
 native_sessions=[]
 for saved in release.get('separate_evidence_inventory',{}).get('native_session_evidence',[]):
  source=(ROOT/saved['result_path']).resolve()
  if not source.is_relative_to(ROOT/'artifacts'): raise ValueError('Session outside evidence root')
  native=json.loads(source.read_text())
  contexts=[]
  for audio in native.get('audio',[]):
   context=audio['context_id'];events=native.get('events',[])
   payload=[e['elapsed_ms'] for e in events if e.get('event_type')=='audio_payload_received' and e.get('context_id')==context]
   cancel=[e['elapsed_ms'] for e in events if e.get('event_type')=='action_sent' and e.get('action_type')=='cancel' and e.get('context_id')==context]
   contexts.append({'context':context,'first_payload_ms':min(payload) if payload else None,'cancel_sent_ms':cancel[0] if cancel else None,'last_payload_after_cancel_ms':max(payload)-cancel[0] if cancel and payload and max(payload)>=cancel[0] else None})
  native_sessions.append({**saved,'contexts':contexts,'sent_actions':sorted(set(a['type'] for a in native.get('actions',[])[:native.get('sent_action_count',0)]))})
 # Explicitly allowlist qualification summaries; raw manifests contain local paths.
 def read(relative): return json.loads((ROOT/relative).read_text())
 flagship=read('artifacts/dubverse-flagship-20260915/summary.json')
 remaining=read('artifacts/dubverse-flagship-remaining-20260915/summary.json')
 singles=[read(f'artifacts/dubverse-flagship-single-{locale}-20260915/summary.json') for locale in ('ta-IN','kn-IN','ml-IN')]
 planned=[('en-IN',1194),('bn-IN',1220),('te-IN',1222),('ta-IN',1224),('kn-IN',1226),('ml-IN',1228)]
 attempted=[*flagship['results'],*remaining['results'],*singles]
 if flagship['provider']!='dubverse' or remaining['provider']!='dubverse' or flagship['automatic_retries']!=0 or remaining['automatic_retries']!=0 or any(s['automatic_retries']!=0 for s in singles) or len(attempted)!=len(planned):
  raise ValueError('Dubverse flagship attempt inventory inconsistent')
 lookup={r['run_id']:r for r in public_runs}
 dubverse_flagship_audit=[]
 for (locale,voice),saved in zip(planned,attempted):
  run=lookup.get(saved['run_id'])
  if not run or saved['locale']!=locale or saved['voice']!=voice or run['provider']!='dubverse' or run['language']!=locale or run['text']!=saved['text'] or run['config'].get('model')!='candy.two' or run['config'].get('voice')!=voice or run['status']!=saved['status'] or run.get('http_status')!=saved.get('http_status'):
   raise ValueError('Dubverse flagship run/voice/locale mismatch')
  if saved['status']=='success' and not run.get('audio_url'):raise ValueError('Dubverse flagship successful audio missing')
  if saved['status']!='success' and run.get('audio_url'):raise ValueError('Dubverse flagship failed request gained audio')
  dubverse_flagship_audit.append({'provider':'dubverse','model':'candy.two','locale':locale,'voice':voice,
   'status':saved['status'],'http_status':saved.get('http_status'),'error_type':saved.get('error_type'),
   'audio_url':run.get('audio_url'),'run_id':saved['run_id'],
   'speaker_source':'https://docs.dubverse.ai/speakers/candy-two-speakers'})
 clone=read('artifacts/clone-audit-20260915/report.json')
 clone=[{**{k:r.get(k) for k in ('provider','model','clone_status','enrollment_prerequisites','cross_language_scope','plan_or_account_gate','controls','live_clone_test')},'source_url':(r.get('source') or {}).get('url')} for r in clone['records']]
 emotion=read('artifacts/feature-pairs-20260915/emotion-audit.json')
 emotion_rows=[{k:m.get(k) for k in ('provider','model','control_kind','request_surface','model_boundary','live_evidence','other_controls','emotional_accuracy')} for m in emotion['models']]
 murf_locale_style_audit=verify_murf_locale_styles(ROOT)
 (destination/'murf-locale-style-audit.json').write_text(json.dumps(murf_locale_style_audit,ensure_ascii=False,indent=2)+'\n')
 for m in emotion_rows:
  if m['provider']=='murf':
   m['model_boundary']='Authenticated Falcon 2 voice listing: each voice for all nine requested supported locales has one style; Urdu has no voice. No listed within-voice emotion/style contrast for this Indic set.'
   m['live_evidence']='Read-only model-filtered catalog returned 136 voices and locale-specific style sets; no style-pair synthesis was justified.'
  if m['provider']=='elevenlabs': m['live_evidence']='Hindi curious / excited tags: both returned audio; perceived emotion unverified.'
  if m['provider']=='inworld': m['live_evidence']='Hindi calm / angry instructions: both returned audio. Exact instruction and delivery_mode implemented for TTS-2.'
  if m['provider']=='google': m['live_evidence']='Hindi calm / cheerful prompt pair: both returned audio; perceived emotion unverified.'
  if m['provider']=='fish': m['live_evidence']='Hindi [calm] / [angry] pair returned audio using s2.1-pro-free and the same reference voice; perceived emotion and spoken cue leakage remain unverified.'
 if not any(m['provider']=='google' for m in emotion_rows):
  emotion_rows.append(dict(provider='google',model='gemini-3.1-flash-tts-preview',control_kind='natural_language_prompt',request_surface='instructions',model_boundary='Prompt steering; no numeric emotion control.',live_evidence='Hindi calm / cheerful pair returned audio.',other_controls='Perceptual compliance requires qualified listening.',emotional_accuracy='unverified'))
 emotion_rows.append(dict(provider='camb',model='mars-instruct',control_kind='natural_language_prompt',request_surface='user_instructions',model_boundary='Use exact instruct model; discovered Hindi reference voice.',live_evidence='Hindi calm / cheerful instructions returned audio. Indian English audio uses cross-language Hindi reference; accent unverified.',other_controls='No universal emotion accuracy claim.',emotional_accuracy='unverified'))
 emotion_rows.append(dict(provider='speechify',model='simba-3.2',control_kind='SSML emotion',request_surface='input SSML',model_boundary='English only; live catalog Ankit en-IN.',live_evidence='Neutral / cheerful English pair returned audio.',other_controls='Hindi and regional languages excluded for this current model.',emotional_accuracy='unverified'))
 soniox_controls=json.loads((ROOT/'artifacts/soniox-controls-20260915/manifest.json').read_text())
 if [s['status'] for s in soniox_controls['samples']]!=['success']*3:raise ValueError('Soniox controls incomplete')
 emotion_rows.append(dict(provider='soniox',model='tts-rt-v2',control_kind='inline audio tags',request_surface='text prefix [calm] / [excited]',model_boundary='One built-in Kavya voice, global route, Hindi only for this control pair.',live_evidence='Both Hindi tag variants returned HTTP200 WAV. Separate Hindi-English code-mix request also returned WAV.',other_controls='Native listening needed for emotion, cue leakage and code-mix pronunciation.',emotional_accuracy='unverified'))
 qualification=read('artifacts/local-20260915/kokoro/qualification-summary.json')
 qualification={k:qualification[k] for k in ('attempted_generations','saved_audio_files','storage_failed_after_generation','checks','initialization_seconds','process_peak_rss_bytes','resource_scope','recovery_low_n_groups')}
 access=read('artifacts/access-audits/candidate-access-20260915.json')
 access_rows=[]
 for candidate in access['candidates']:
  item={k:candidate.get(k) for k in ('provider','access_state','next_autonomous_action','external_dependency')}
  if candidate['provider']=='openai':
   check=candidate.get('latest_recheck')
   run=next((r for r in public_runs if check and r['run_id']==check['run_id']),None)
   if (not check or not run or (run['provider'],run['status'],run['http_status'],run['audio_url']) !=
       ('openai','error',429,None) or check['request_limit']!=1 or check['automatic_retries']!=0):
    raise ValueError('OpenAI access recheck not bound to one public HTTP 429 run')
   item['latest_recheck']={k:check[k] for k in ('model','language','run_id','http_status','audio_bytes','request_limit','automatic_retries')}
  access_rows.append(item)
 access=access_rows
 prerequisites=read('artifacts/feature-pairs-20260915/pronunciation-timestamp-prerequisites.json')
 prerequisites=[{k:c.get(k) for k in ('provider','models','pronunciation','timestamps')} for c in prerequisites['providers']]
 for c in prerequisites:
  if c['provider']=='sarvam': c['pronunciation']['notes']='dict_id implemented. Creation returned HTTP400: dictionary limit exceeded. Ten existing dictionaries inspected read-only; none matched the benign test fixture. No deletion or synthesis.'
 timestamps=read('artifacts/speechify-timestamps-20260915/summary.json')
 # Update the existing provider row: historical prerequisites must not contradict later observations.
 for c in prerequisites:
  if c['provider']=='speechify':
   c['models']=['simba-3.2']
   c['timestamps']={'prerequisite_class':'implemented_discrepancy_observed','notes':'Timestamp stream implemented. Seven word marks returned. PCM and final mark imply4720ms; completion reports3146ms. Alignment qualification withheld.'}
  if c['provider']=='inworld':
   observed=read('artifacts/inworld-timestamps-20260915/summary.json')
   if observed['feature_status']!='observed_timing_metadata': raise ValueError('Inworld timing evidence inconsistent')
   c['models']=['inworld-tts-2']
   c['timestamps']={'prerequisite_class':'implemented_observed_alignment_unverified','notes':'WORD and CHARACTER request controls implemented. One Hindi WORD request returned17 alignment entries (including spaces/punctuation) and45 phonemes with3.8seconds audio. Timing and phoneme accuracy remain unverified.'}
  if c['provider']=='smallest':
   observed=read('artifacts/sessions-access-20260915/smallest-recovery.json')
   if observed['timestamp_presence']!='observed' or observed['word_count']!=len(observed['word_marks']): raise ValueError('Smallest timestamp evidence inconsistent')
   c['models']=[observed['config']['model']]
   c['timestamps']={'prerequisite_class':'implemented_observed_alignment_unverified','notes':f"Native WebSocket word_timestamps returned{observed['word_count']} Hindi word marks for lightning_v3.1_pro / Meher. HTTP/SSE do not establish this capability. Word-to-audio alignment remains unverified."}
 jobs=read('artifacts/jobs-20260915/execution-evidence.json')
 jobs=[{k:j.get(k) for k in ('kind','status','elapsed_seconds','offline_test_count')} for j in jobs['jobs']]
 pause=read('artifacts/inworld-pause-20260915/summary.json')
 usage=read('artifacts/elevenlabs-usage-20260915/history-reconciliation.json')
 if usage['provider']!='elevenlabs' or usage['money_cost_verified'] is not False: raise ValueError('Usage reconciliation scope inconsistent')
 usage={k:usage.get(k) for k in ('provider','history_rows_seen','matched_count','tracked_run_count','matched_error_run_count','matched_counter_delta_total','money_cost_verified','has_more','duplicate_history_request_id_count')}
 subscription=read('artifacts/elevenlabs-usage-20260915/subscription-sanitized.json')
 if subscription.get('provider')!='elevenlabs' or subscription.get('money_cost_verified') is not False or subscription.get('request_count')!=1 or subscription.get('automatic_retries')!=0:
  raise ValueError('Subscription account check scope inconsistent')
 if type(subscription.get('character_count')) is not int or type(subscription.get('character_limit')) is not int or subscription['character_count']>subscription['character_limit']:
  raise ValueError('Subscription quota counters inconsistent')
 subscription_audit={k:subscription.get(k) for k in ('provider','tier','status','billing_period','currency','character_count','character_limit','has_open_invoices','current_overage','money_cost_verified','observed_at')}
 subscription_audit['remaining_included_credits']=subscription['character_limit']-subscription['character_count']
 playout=read('artifacts/cartesia-playout-20260915-v2/result.json')
 bridge=read('artifacts/cartesia-playout-20260915-v2/cartesia-bridge.json')
 post=bridge['provider_payload_after_cancel']
 if playout['status']!='observed' or playout['production_telephony_verified'] is not False or bridge['boundary']!='software_PCM_playout_bridge_not_production_telephony':raise ValueError('Cartesia playout scope inconsistent')
 if post['path']:
  raw=(ROOT/'artifacts/cartesia-playout-20260915-v2'/post['path']).read_bytes()
  if len(raw)!=post['bytes'] or hashlib.sha256(raw).hexdigest()!=post['sha256']:raise ValueError('Cartesia post-cancel audio integrity failure')
 playout_audit={'provider':'cartesia','model':bridge['model'],'caller_fixture_label':bridge['caller_fixture_label'],
  'status':playout['status'],'boundary':bridge['boundary'],'active_at_onset':playout['metrics']['active_at_onset'],
  'software_stop_latency_ms':playout['metrics']['stop_latency_ms'],'software_stale_audio_ms':playout['metrics']['stale_audio_ms'],
  'timing_resolution_ms':playout['metrics']['timing_resolution_ms'],'timing_accuracy_ms':playout['metrics']['timing_accuracy_ms'],
  'native_cancel_sent':bridge['native_cancel_sent'],'provider_payload_after_cancel_bytes':post['bytes'],
  'provider_payload_after_cancel_duration_ms':post['bytes']*1000/(playout['sample_rate']*2),
  'provider_payload_after_cancel_played':post['played_locally'],'production_telephony_verified':False}
 soniox_playout_audit=verify_soniox_playout(ROOT/'artifacts/soniox-playout-20260916')
 sarvam_native_audit=verify_sarvam_native(ROOT/'artifacts/sessions/sarvam-native-20260916')
 sarvam_playout_audit=verify_sarvam_playout(ROOT/'artifacts/sarvam-playout-20260916')
 pilot_root=ROOT/'artifacts/indic-asr-pilot-20260915'
 pilot=read('artifacts/indic-asr-pilot-20260915/result-summary.json')
 pilot_manifest=read('artifacts/indic-asr-pilot-20260915/manifest.json')
 if pilot['schema']!='indic_asr_pilot_summary_v1' or pilot['engine']!='sarvam.saaras:v3.verbatim' or pilot['native_reviewed_references']!=0:
  raise ValueError('ASR pilot scope inconsistent')
 if pilot['pilot_manifest_sha256']!=hashlib.sha256((pilot_root/'manifest.json').read_bytes()).hexdigest():
  raise ValueError('ASR pilot manifest hash mismatch')
 if pilot_manifest['planned_requests']!=24 or pilot['records']!=24 or pilot['locales']!=10:
  raise ValueError('ASR pilot counts inconsistent')
 asr_folders=[ROOT/'artifacts/indic-asr-smoke-20260915',ROOT/'artifacts/indic-asr-verbatim-20260915']
 if any(json.loads((folder/'status.json').read_text())['status']!='complete' for folder in asr_folders):
  raise ValueError('ASR pilot source run incomplete')
 observations=sum([json.loads((folder/'observations.json').read_text()) for folder in asr_folders],[])
 responses=sum([json.loads((folder/'private_sanitized_responses.json').read_text()) for folder in asr_folders],[])
 if len(observations)!=24 or len(responses)!=24 or {r['reference_id'] for r in observations}!={r['reference_id'] for r in pilot_manifest['items']}:
  raise ValueError('ASR pilot selected identities inconsistent')
 refs=read('artifacts/transcript-references-20260915/references.json')
 diagnostics=evaluate_transcripts(observations,refs,{})
 if len(diagnostics['observations'])!=24 or diagnostics['rejected'] or any(r['reference_native_reviewed'] for r in diagnostics['observations']):
  raise ValueError('ASR pilot scored observations inconsistent')
 detected={r['reference_id']:r['sanitized_response']['language_code'] for r in responses}
 transcript_rows=[]
 transcript_record_rows=[]
 for saved in pilot['by_language']:
  language=saved['language']
  rows=[r for r in diagnostics['observations'] if r['language']==language]
  if len(rows)!=saved['recordings'] or saved['detected_other_locale']!=sum(detected[r['reference_id']] not in (None,language) for r in rows):
   raise ValueError('ASR pilot locale or detection mismatch')
  for metric in ('wer','cer'):
   raw=saved[metric+'_raw_micro']
   if raw['edit_distance']!=sum(r[metric]['distance'] for r in rows) or raw['draft_reference_units']!=sum(r[metric]['reference_units'] for r in rows):
    raise ValueError('ASR pilot edit totals inconsistent')
  transcript_rows.append({k:saved[k] for k in ('language','recordings','providers','detected_matching_locale','detected_other_locale','detected_unknown','wer_raw_micro','cer_raw_micro')})
 for scored in diagnostics['observations']:
  run=lookup.get(scored['run_id'])
  if not run or not run.get('audio_url') or run['provider']!=scored['provider'] or run['language']!=scored['language'] or run['config'].get('model')!=scored['model'] or scored['audio_sha256'] not in {run['listening_audio_sha256'],run.get('raw_listening_audio_sha256')}:
   raise ValueError('ASR diagnostic lacks exact published audio identity')
  legacy_input=scored['audio_sha256']==run.get('raw_listening_audio_sha256')
  if legacy_input and not run.get('audio_header_repair'):
   raise ValueError('Historical ASR input differs without a sample-identical header repair')
  locale=detected.get(scored['reference_id'])
  transcript_record_rows.append({'run_id':scored['run_id'],'provider':scored['provider'],'model':scored['model'],
   'requested_language':scored['language'],'detected_language':locale,'audio_url':run['audio_url'],
   'asr_input_audio_sha256':scored['audio_sha256'],'asr_input_streaming_header':legacy_input,
   'wer_raw':scored['wer']['rate'],'cer_raw':scored['cer']['rate'],
   'reference_native_reviewed':False,'quality_certified':False})
 if len(transcript_record_rows)!=pilot['records'] or len({r['run_id'] for r in transcript_record_rows})!=pilot['records']:
  raise ValueError('ASR per-record diagnostic count inconsistent')
 transcript_audit={'engine':pilot['engine'],'records':24,'locales':10,'native_reviewed_references':0,
  'human_ratings':0,'by_language':transcript_rows,'by_record':sorted(transcript_record_rows,key=lambda r:(r['provider'],r['requested_language'],r['run_id'])),
  'boundary':'ASR against unreviewed draft synthesis text; no naturalness, accent, or TTS quality certification'}
 cross=read('artifacts/indic-asr-pilot-20260915/urdu-crosscheck.json')
 if cross['schema']!='urdu_cross_asr_v1' or cross['engine']!='elevenlabs.scribe_v2.auto' or cross['records']!=2 or cross['native_reviewed_references']!=0:
  raise ValueError('Urdu cross-ASR scope inconsistent')
 cross_folders=[ROOT/'artifacts/scribe-v2-urdu-smoke-20260915',ROOT/'artifacts/scribe-v2-urdu-google-20260915']
 cross_observations=sum([json.loads((folder/'observations.json').read_text()) for folder in cross_folders],[])
 cross_responses=sum([json.loads((folder/'private_sanitized_responses.json').read_text()) for folder in cross_folders],[])
 if len(cross_observations)!=2 or len(cross_responses)!=2 or any(json.loads((folder/'status.json').read_text())['status']!='complete' for folder in cross_folders):
  raise ValueError('Urdu cross-ASR source incomplete')
 cross_scored=evaluate_transcripts(cross_observations,refs,{})
 if len(cross_scored['observations'])!=2 or cross_scored['rejected']:
  raise ValueError('Urdu cross-ASR identities inconsistent')
 cross_lookup={r['reference_id']:r for r in cross_observations}
 response_lookup={r['reference_id']:r['sanitized_response'] for r in cross_responses}
 cross_rows=[]
 for row in cross['results']:
  matching=cross_lookup.get(next((rid for rid,obs in cross_lookup.items() if obs['provider']==row['provider']),None))
  if not matching or matching['model']!=row['recorded_model'] or matching['language']!=row['requested_locale'] or matching['audio_sha256']!=row['audio_sha256']:
   raise ValueError('Urdu cross-ASR record identity mismatch')
  response=response_lookup[matching['reference_id']]
  if response['language_code']!=row['detected_iso639_3'] or response['language_probability']!=row['reported_language_probability']:
   raise ValueError('Urdu cross-ASR detector mismatch')
  cross_rows.append({k:row[k] for k in ('provider','recorded_model','requested_locale','detected_iso639_3','reported_language_probability')})
 if sorted(r['provider'] for r in cross_rows)!=['elevenlabs','google']:
  raise ValueError('Urdu cross-ASR provider set inconsistent')
 cross_audit={'engine':cross['engine'],'records':2,'native_reviewed_references':0,'human_ratings':0,
  'results':cross_rows,'boundary':'Second ASR engine only; native Urdu listening and spoken-reference review pending'}
 maya_local_runs=[]
 maya_root=ROOT/'artifacts/runpod/veena-20260915'
 for stem,language,voice in [('veena-hi-IN-kavya','hi-IN','kavya'),('veena-en-IN-agastya','en-IN','agastya'),('veena-hi-en-maitri','hi-en','maitri')]:
  record=json.loads((maya_root/(stem+'.json')).read_text(encoding='utf-8'))
  raw=(maya_root/(stem+'.wav')).read_bytes()
  if record.get('model')!='maya-research/Veena' or record.get('model_revision')!='8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f' or record.get('codec_revision')!='d73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec' or record.get('language')!=language or record.get('voice')!=voice or record.get('audio_bytes')!=len(raw)-44 or record.get('token_stats',{}).get('terminal_token') not in (128258,128262):
   raise ValueError('Pinned Maya Veena smoke metadata inconsistent')
  with wave.open(io.BytesIO(raw),'rb') as stream:
   if stream.getnchannels()!=1 or stream.getsampwidth()!=2 or stream.getframerate()!=24000 or stream.getnframes()*2!=record['audio_bytes']:
    raise ValueError('Maya Veena smoke WAV contract inconsistent')
   duration=stream.getnframes()/stream.getframerate()
  name=stem+'.wav';(destination/'audio'/name).write_bytes(raw)
  maya_local_runs.append({'model':record['model'],'model_revision':record['model_revision'],'language':language,'voice':voice,'text':record['text'],'audio_url':'/evidence/audio/'+name,'audio_sha256':hashlib.sha256(raw).hexdigest(),'sample_rate':24000,'duration_seconds':duration,'initialization_seconds':record['initialization_seconds'],'synthesis_seconds':record['synthesis_seconds'],'hardware':'NVIDIA GeForce RTX 4090','precision':'float16','streaming':False,'quality_certified':False})
 maya_asr=json.loads((maya_root/'asr-diagnostics.json').read_text(encoding='utf-8'))
 if maya_asr.get('schema')!='veena_asr_smoke_v1' or len(maya_asr.get('observations',[]))!=3:raise ValueError('Maya Veena ASR inventory inconsistent')
 asr_lookup={o['audio_sha256']:o for o in maya_asr['observations']}
 if len(asr_lookup)!=3:raise ValueError('Maya Veena ASR identities duplicated')
 for row in maya_local_runs:
  observation=asr_lookup.get(row['audio_sha256'])
  if not observation or observation['model']!=row['model'] or observation['requested_language']!=row['language'] or observation['draft_input_text']!=row['text'] or observation['native_reviewed'] is not False or observation['quality_certified'] is not False:
   raise ValueError('Maya Veena ASR observation identity inconsistent')
  row.update({'asr_engine':observation['asr_engine'],'asr_detected_language':observation['detected_language'],'asr_transcript':observation['asr_transcript']})
 maya1_root=ROOT/'artifacts/runpod/maya1-20260915'
 maya1=json.loads((maya1_root/'maya1-en-IN.json').read_text(encoding='utf-8'))
 maya1_audio=(maya1_root/'maya1-en-IN.wav').read_bytes()
 maya1_lifecycle=json.loads((maya1_root/'operation.json').read_text(encoding='utf-8'))
 if (maya1.get('evidence_class')!='local_model_execution' or maya1.get('status')!='success' or maya1.get('model')!='maya-research/maya1'
     or maya1.get('model_revision')!='21c682a0afef8c13a89b2512733c8bf5f0c52eb7' or maya1.get('codec_revision')!='d73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec'
     or maya1.get('language')!='en-IN' or maya1.get('token_stats',{}).get('terminal_token')!=128258
     or hashlib.sha256(maya1_audio).hexdigest()!=maya1.get('audio_sha256') or maya1_lifecycle.get('post_delete_pod_inventory_count')!=0):
  raise ValueError('Maya1 pinned batch provenance inconsistent')
 with wave.open(str(maya1_root/'maya1-en-IN.wav'),'rb') as stream:
  if (stream.getnchannels(),stream.getsampwidth(),stream.getframerate())!=(1,2,24000) or stream.getnframes()*2!=maya1['audio_bytes']:
   raise ValueError('Maya1 output WAV contract inconsistent')
  maya1_duration=stream.getnframes()/stream.getframerate()
 (destination/'audio'/'maya1-en-IN.wav').write_bytes(maya1_audio)
 maya_local_runs.append({'model':maya1['model'],'model_revision':maya1['model_revision'],'language':'en-IN','voice':maya1['description'],'voice_control_kind':'description','text':maya1['text'],'audio_url':'/evidence/audio/maya1-en-IN.wav','audio_sha256':maya1['audio_sha256'],'sample_rate':24000,'duration_seconds':maya1_duration,'initialization_seconds':maya1['initialization_seconds'],'synthesis_seconds':maya1['synthesis_seconds'],'hardware':'NVIDIA GeForce RTX 4090','precision':'float16','streaming':False,'quality_certified':False})
 soniox_cancel=read('artifacts/soniox-cancel-20260915-v2/result.json')
 if soniox_cancel['status']!='observed_cancelled' or soniox_cancel['production_telephony_verified'] is not False or soniox_cancel['audio_bytes_before_cancel']<=0:
  raise ValueError('Soniox native cancellation evidence inconsistent')
 soniox_cancel={k:soniox_cancel.get(k) for k in ('provider','model','voice','language','status','first_audio_ms','synthetic_caller_onset_ms','local_playout_stop_ms','cancel_sent_ms','terminated_ms','native_cancel_ack_ms','audio_bytes_before_cancel','audio_bytes_after_cancel','post_cancel_played_locally','production_telephony_verified','errors')}
 soniox_marks=read('artifacts/soniox-timestamps-20260915/result.json')
 if soniox_marks['status']!='observed_character_marks' or not soniox_marks['mark_array_lengths_consistent'] or soniox_marks['returned_characters_text']!=soniox_marks['requested_text']:
  raise ValueError('Soniox character timestamp evidence inconsistent')
 soniox_marks={k:soniox_marks.get(k) for k in ('provider','model','status','frames','audio_bytes','timestamp_frames','characters','mark_array_lengths_consistent','terminal_observed','word_timestamps_claimed','character_alignment_accuracy')}
 # Feature observations are explicit live evidence, separate from catalog claims.
 observations=[]
 def observe(provider,feature,model,language,level,detail,run_ids=(),boundary='',source=None):
  if not any(p['id']==provider for p in providers):raise ValueError('Feature observation provider missing')
  if feature not in next(p for p in providers if p['id']==provider)['features']:raise ValueError('Feature observation missing from catalog')
  lookup={r['run_id']:r for r in public_runs}
  if any(rid not in lookup for rid in run_ids):raise ValueError('Feature observation run ID missing')
  observations.append({'provider':provider,'feature':feature,'model':model,'language':language,'level':level,'detail':detail,'run_ids':list(run_ids),'boundary':boundary,'source':source})
 pairs=read('artifacts/feature-pairs-20260915/summary.json')
 for pair_id,provider,feature in [('cartesia_speed','cartesia','speed'),('sarvam_speed','sarvam','speed'),('minimax_emotion','minimax','emotion')]:
  pair=pairs['pairs'][pair_id];records=pair['records'];outcome=pair['outcome']
  if len(records)!=2 or any(r['status']!='success' for r in records) or outcome['request_acceptance']!='accepted':raise ValueError('Feature-pair outcome inconsistent')
  ids=[r['run_id'] for r in records];model=records[0]['config']['model']
  if feature=='speed':
   detail=f"Same Hindi text and voice, control {outcome['requested_values'][0]}→{outcome['requested_values'][1]}, audio duration {outcome['durations_seconds'][0]:.2f}→{outcome['durations_seconds'][1]:.2f} s."
   observe(provider,feature,model,'hi-IN','measured_output',detail,ids,'One paired request; no native pace rating or load qualification',f'artifacts/feature-pairs-20260915/runs/{pair_id}')
  else:
   detail=f"Hindi calm/angry control values both accepted; two distinct WAV/PCM outputs saved."
   observe(provider,feature,model,'hi-IN','request_accepted',detail,ids,'Emotion correctness and cue fidelity require qualified blind listening',f'artifacts/feature-pairs-20260915/runs/{pair_id}')
 observe('soniox','speed','tts-rt-v2','hi-IN','measured_output',
  'Same Hindi text and Kavya voice across four settings 0.8/0.85/1.15/1.2; saved WAV duration decreases at each higher setting.',
  [clip['run_id'] for clip in soniox_speed['sweep_clips']],
  'Four distinct settings in two bounded pairs; no same-setting repeats, native intelligibility or load qualification',
  'artifacts/soniox-speed-20260916/summary.json')
 pause=read('artifacts/inworld-pause-20260915/summary.json')
 if pause['outcome']['direction']!='longer_with_break' or len(pause['records'])!=2 or any(r['status']!='success' for r in pause['records']):raise ValueError('Inworld pause observation inconsistent')
 observe('inworld','ssml','inworld-tts-2','hi-IN','measured_output',f"Break-tag pair: longest internal low-energy gap {pause['outcome']['longest_internal_gap_seconds'][0]:.2f}→{pause['outcome']['longest_internal_gap_seconds'][1]:.2f} s.",[r['run_id'] for r in pause['records']],'Low-energy gap diagnostic only; spoken position and SSML conformance unverified','artifacts/inworld-pause-20260915/summary.json')
 inworld_marks=read('artifacts/inworld-timestamps-20260915/summary.json')
 if inworld_marks['feature_status']!='observed_timing_metadata' or inworld_marks['result']['status']!='success':raise ValueError('Inworld timing observation inconsistent')
 observe('inworld','word_timestamps','inworld-tts-2','hi-IN','metadata_observed',f"Vendor response returned {inworld_marks['timing_counts']['alignment_entries']} alignment entries and {inworld_marks['timing_counts']['phones']} phones.",[Path(inworld_marks['result_file']).parent.name],'Alignment accuracy unverified','artifacts/inworld-timestamps-20260915/summary.json')
 smallest_marks=read('artifacts/sessions-access-20260915/smallest-recovery.json')
 if smallest_marks['timestamp_presence']!='observed' or smallest_marks['word_count']<=0:raise ValueError('Smallest timing observation inconsistent')
 observe('smallest','word_timestamps','lightning_v3.1_pro','hi-IN','metadata_observed',f"WebSocket returned {smallest_marks['word_count']} Hindi word marks.",(),'Alignment accuracy unverified','artifacts/sessions-access-20260915/smallest-recovery.json')
 speech_marks=timestamps['verification']
 if speech_marks['word_marks']<=0:raise ValueError('Speechify timing observation inconsistent')
 observe('speechify','word_timestamps','simba-3.2','en-IN','metadata_observed',f"Returned {speech_marks['word_marks']} English word marks; final duration {speech_marks['vendor_done_duration_ms']} ms conflicts with measured PCM {speech_marks['measured_pcm_duration_ms']} ms.",[timestamps['run_id']],'Alignment qualification withheld due to duration mismatch','artifacts/speechify-timestamps-20260915/summary.json')
 if soniox_marks['status']!='observed_character_marks':raise ValueError('Soniox mark status inconsistent')
 # Character marks do not satisfy the word-timestamps property.
 observe('soniox','word_timestamps','tts-rt-v2','hi-IN','partial_metadata',f"Observed {soniox_marks['characters']} character marks, not native word marks.",(),'Word timestamp support remains unverified','artifacts/soniox-timestamps-20260915/result.json')
 if soniox_cancel['status']!='observed_cancelled':raise ValueError('Soniox cancel status inconsistent')
 observe('soniox','cancel','tts-rt-v2','hi-IN','measured_output',f"Native terminal acknowledgement {soniox_cancel['native_cancel_ack_ms']:.0f} ms; {soniox_cancel['audio_bytes_after_cancel']} post-cancel bytes discarded locally.",(),'Synthetic onset; caller detection and production telephony unverified','artifacts/soniox-cancel-20260915-v2/result.json')
 multiplex=read('artifacts/soniox-multiplex-20260915/result.json')
 streams=multiplex['streams']
 if multiplex['status']!='complete' or multiplex['provider']!='soniox' or multiplex['model']!='tts-rt-v2' or multiplex['requests_limit']!=2 or multiplex['automatic_retries']!=0 or len(streams)!=2 or multiplex['production_telephony_verified'] is not False:
  raise ValueError('Soniox multiplex result scope inconsistent')
 if [s['audio_format'] for s in streams]!=['pcm_s16le','pcm_mulaw'] or [s['sample_rate'] for s in streams]!=[24000,8000] or len(streams[0]['text_parts'])!=2 or len(streams[1]['text_parts'])!=1:
  raise ValueError('Soniox multiplex request shape inconsistent')
 for item in streams:
  if item['status']!='success' or not item['audio_end_observed'] or not item['terminated_observed'] or item['audio_chunks']<2 or item['error_types'] or item['language']!='hi-IN' or item['wire_language']!='hi':
   raise ValueError('Soniox stream lifecycle incomplete')
  raw=(ROOT/'artifacts/soniox-multiplex-20260915'/(item['audio_format']+'.raw')).read_bytes()
  wav=(ROOT/'artifacts/soniox-multiplex-20260915'/item['audio_file']).read_bytes()
  if len(raw)!=item['audio_bytes'] or hashlib.sha256(raw).hexdigest()!=item['raw_sha256'] or hashlib.sha256(wav).hexdigest()!=item['audio_sha256']:
   raise ValueError('Soniox stream audio hash mismatch')
  if item['audio_format']=='pcm_mulaw':
   if wav!=mulaw_to_wav(raw):raise ValueError('Soniox mu-law WAV derivation mismatch')
  else:
   with wave.open(io.BytesIO(wav),'rb') as decoded:
    if decoded.getnchannels()!=1 or decoded.getsampwidth()!=2 or decoded.getframerate()!=24000 or decoded.readframes(decoded.getnframes())!=raw:
     raise ValueError('Soniox PCM WAV derivation mismatch')
 if streams[0]['audio_before_final_text'] is not False:raise ValueError('Soniox pre-final audio claim changed')
 native_audio_runs=[]
 studio=verify_voicemaker_studio(ROOT/'artifacts/voicemaker-studio-20260916')
 studio_wav=ROOT/'artifacts/voicemaker-studio-20260916/hi-IN-proplus-ravi-decoded.wav'
 studio_name='voicemaker-studio-proplus-ravi-hi-IN.wav'
 (destination/'audio'/studio_name).write_bytes(studio_wav.read_bytes())
 studio_audio_runs=[{'provider':'voicemaker','model':studio['model'],
  'language':studio['requested_language'],'voice':studio['voice'],'text':studio['text'],
  'audio_url':'/evidence/audio/'+studio_name,'audio_sha256':studio['decoded_wav_sha256'],
  'source_mp3_sha256':studio['source_mp3_sha256'],
  'sample_rate':studio['decoded_sample_rate'],'duration_seconds':studio['decoded_duration_seconds'],
  'created_at':studio['created_at'],'route':'Signed-in Studio download',
  'boundary':studio['ui_boundary'],'api_access_state':studio['api_access_state'],
  'billing':studio['billing'],'quality':studio['quality']}]
 for regional_clip in verify_voicemaker_regional(ROOT/'artifacts/voicemaker-studio-20260916', ROOT/'corpus/seed.jsonl'):
  regional_name='voicemaker-studio-proplus-ravi-'+regional_clip['locale']+'.wav'
  regional_wav=ROOT/'artifacts/voicemaker-studio-20260916'/regional_clip['decoded_wav']
  (destination/'audio'/regional_name).write_bytes(regional_wav.read_bytes())
  studio_audio_runs.append({'provider':'voicemaker','model':regional_clip['model'],
   'language':regional_clip['locale'],'voice':regional_clip['voice'],
   'text':regional_clip['text'],'text_id':regional_clip['text_id'],
   'audio_url':'/evidence/audio/'+regional_name,
   'audio_sha256':regional_clip['decoded_wav_sha256'],
   'source_mp3_sha256':regional_clip['source_mp3_sha256'],
   'sample_rate':regional_clip['decoded_sample_rate'],
   'duration_seconds':regional_clip['decoded_duration_seconds'],
   'created_at':regional_clip['created_at'],'route':'Signed-in Studio download',
   'boundary':regional_clip['boundary'],
   'api_access_state':studio['api_access_state'],
   'billing':'Starter plan included Studio credits; per-clip deduction not account-reconciled.',
   'quality':regional_clip['quality']})
 maya_studio_usage=verify_maya2_studio_usage(ROOT/'artifacts/maya2-studio-20260916')
 (destination/'maya2-studio-usage.json').write_text(json.dumps(maya_studio_usage, ensure_ascii=False, indent=2)+'\n')
 for clip in verify_maya2_studio(ROOT/'artifacts/maya2-studio-20260916', ROOT/'corpus/seed.jsonl'):
  public_name='maya2-native-ananya-'+clip['locale']+'.wav'
  source=ROOT/'artifacts/maya2-studio-20260916'/clip['wav']
  (destination/'audio'/public_name).write_bytes(source.read_bytes())
  studio_audio_runs.append({'provider':'maya','model':'Maya 2 Native','language':clip['locale'],
   'voice':'Ananya','text':clip['text'],'text_id':clip['text_id'],
   'audio_url':'/evidence/audio/'+public_name,'audio_sha256':clip['wav_sha256'],
   'sample_rate':clip['sample_rate'],'duration_seconds':clip['duration_seconds'],
   'created_at':clip['created_at'],'route':'Signed-in Maya Studio download',
   'boundary':'Signed-in Studio delivery only; no hosted developer API, streaming, native quality, latency, or production claim.',
   'api_access_state':'Developer API key management disabled; coming soon.',
   'billing':'203 free credits used across seven Studio requests; account aggregate is not per-clip or invoice reconciliation.',
   'quality':'Draft corpus request; no native listener or native-reference review.'})
 sarvam_native_name='sarvam-bulbul-v3-native-hi-IN.wav'
 sarvam_wav=next((ROOT/'artifacts/sessions/sarvam-native-20260916').glob('*/decoded.wav')).read_bytes()
 if hashlib.sha256(sarvam_wav).hexdigest()!=sarvam_native_audit['wav_sha256']:
  raise ValueError('Sarvam native playable WAV differs from verified MP3 decode')
 (destination/'audio'/sarvam_native_name).write_bytes(sarvam_wav)
 native_audio_runs.append({'provider':'sarvam','model':'bulbul:v3','language':'hi-IN','voice':'shubh',
  'text':'Two staged Hindi fragments, then flush','audio_format':'mp3_decoded_to_pcm16',
  'sample_rate':24000,'audio_url':'/evidence/audio/'+sarvam_native_name,
  'audio_sha256':sarvam_native_audit['wav_sha256'],
  'duration_seconds':sarvam_native_audit['duration_seconds'],
  'first_audio_ms':sarvam_native_audit['first_received_audio_after_first_text_ms'],
  'audio_before_final_text':False,'boundary':sarvam_native_audit['boundary']})
 for label,name in [('old','sarvam-interrupted-old-hi-IN.wav'),
                    ('recovery','sarvam-interruption-recovery-hi-IN.wav')]:
  source=ROOT/'artifacts/sarvam-playout-20260916'/(
   'old_before_close.raw' if label=='old' else 'recovery.raw')
  wav=sarvam_pcm_wav(source.read_bytes())
  sha=hashlib.sha256(wav).hexdigest()
  if sha!=sarvam_playout_audit[label+'_wav_sha256'] or len(wav)!=sarvam_playout_audit[label+'_wav_bytes']:
   raise ValueError('Sarvam receiver playable WAV differs from independent audit')
  (destination/'audio'/name).write_bytes(wav)
  native_audio_runs.append({'provider':'sarvam','model':'bulbul:v3','language':'hi-IN','voice':'shubh',
   'text':'Interrupted old Hindi response' if label=='old' else 'Recovery after synthetic caller',
   'audio_format':'mp3_decoded_to_pcm16','sample_rate':24000,
   'audio_url':'/evidence/audio/'+name,'audio_sha256':sha,
   'duration_seconds':(len(wav)-44)/48000,'first_audio_ms':None,
   'audio_before_final_text':False,
   'boundary':'native_websocket_'+sarvam_playout_audit['boundary'],
   'production_telephony_verified':False})
 for clip in sarvam_transport_latency_audit['clips']:
  route=clip['route'];ordinal=clip['ordinal']
  name=f'sarvam-transport-{route}-{ordinal:02d}-hi-IN.wav'
  wav=(ROOT/clip['source_wav']).read_bytes()
  if hashlib.sha256(wav).hexdigest()!=clip['wav_sha256']:
   raise ValueError('Sarvam transport playable file changed after verification')
  (destination/'audio'/name).write_bytes(wav)
  native_audio_runs.append({'provider':'sarvam','model':'bulbul:v3','language':'hi-IN','voice':'shubh',
   'text':'नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।',
   'audio_format':'mp3_decoded_to_pcm16','sample_rate':24000,
   'audio_url':'/evidence/audio/'+name,'audio_sha256':clip['wav_sha256'],
   'duration_seconds':clip['duration_seconds'],'first_audio_ms':clip['first_audio_ms'],
   'audio_before_final_text':False,'boundary':'client_request_or_connect_to_first_received_mp3_bytes',
   'transport_latency_route':route,'transport_latency_ordinal':ordinal})
 sarvam_source='artifacts/sessions/sarvam-native-20260916'
 observe('sarvam','text_input_streaming','bulbul:v3','hi-IN','request_accepted',
  'Two staged Hindi text messages completed one native WebSocket turn.',(),
  'Audio arrived after the second text and flush; incremental synthesis before final text unproven',sarvam_source)
 observe('sarvam','flush','bulbul:v3','hi-IN','request_accepted',
  'One native flush message was sent; 25 MP3 chunks and final event followed.',(),
  'Flush acceptance observed; causal effect requires a no-flush control',sarvam_source)
 observe('sarvam','audio_streaming','bulbul:v3','hi-IN','payload_observed',
  '25 native MP3 payloads formed a verified 24 kHz mono playable WAV.',(),
  'WebSocket payload receipt only; no receiver playout, production load or native quality',sarvam_source)
 observe('sarvam','cancel','bulbul:v3','hi-IN','measured_output',
  f"Synthetic receiver stopped old audio in {sarvam_playout_audit['software_stop_latency_ms']:.0f} ms; client closed old TTS socket, discarded {sarvam_playout_audit['old_mp3_after_clear_discarded_bytes']} late MP3 bytes and recovered on a new socket.",(),
  'Client-side local clear and socket close; no in-band server cancel, VAD or phone test',
  'artifacts/sarvam-playout-20260916')
 murf_native_audit,murf_native_wav=verify_murf_native(ROOT)
 murf_native_name='murf-falcon-2-native-hi-IN.wav'
 (destination/'audio'/murf_native_name).write_bytes(murf_native_wav)
 murf_native_audit['audio_url']='/evidence/audio/'+murf_native_name
 (destination/'murf-native-audit.json').write_text(json.dumps(murf_native_audit,ensure_ascii=False,indent=2)+'\n')
 murf_manifest=read('artifacts/murf-native-20260916/manifest.json')
 native_audio_runs.append({'provider':'murf','model':'falcon-2','language':'hi-IN',
  'voice':murf_native_audit['voice'],'text':murf_manifest['text'],
  'audio_format':'WAV','sample_rate':24000,'audio_url':murf_native_audit['audio_url'],
  'audio_sha256':murf_native_audit['playable_wav_sha256'],
  'duration_seconds':murf_native_audit['duration_seconds'],
  'first_audio_ms':murf_native_audit['first_payload_ms'],
  'audio_before_final_text':False,'boundary':murf_native_audit['boundary'],
  'audio_payloads':murf_native_audit['audio_payloads']})
 observe('murf','audio_streaming','falcon-2','hi-IN','payload_observed',
  f"Native Falcon 2 WebSocket returned {murf_native_audit['audio_payloads']} WAV/PCM audio payloads and a context-tagged final event.",(),
  'One complete text input; input chunking, clear, native quality and receiver playout not exercised',
  'artifacts/murf-native-20260916/manifest.json')
 murf_clear_audit,murf_clear_wavs=verify_murf_clear(ROOT)
 clear_control=read('artifacts/murf-clear-recovery-20260916/manifest.json')
 for clip in murf_clear_audit['clips']:
  name='murf-clear-'+clip['id']+'-hi-IN.wav'
  (destination/'audio'/name).write_bytes(murf_clear_wavs[clip['id']])
  clip['audio_url']='/evidence/audio/'+name
  native_audio_runs.append({'provider':'murf','model':'falcon-2','language':'hi-IN',
   'voice':'hi-IN-khyati','text':clear_control['old_text'] if clip['context_id']=='old-turn' else clear_control['new_text'],
   'audio_format':'WAV','sample_rate':24000,'audio_url':clip['audio_url'],
   'audio_sha256':clip['playable_wav_sha256'],'duration_seconds':clip['duration_seconds'],
   'first_audio_ms':None,'audio_before_final_text':clip['partial'],
   'audio_payloads':clip['audio_payloads'],'partial':clip['partial'],
   'boundary':'Murf native clear/recovery '+clip['id']+'; '+murf_clear_audit['boundary']})
 (destination/'murf-clear-audit.json').write_text(json.dumps(murf_clear_audit,ensure_ascii=False,indent=2)+'\n')
 observe('murf','cancel','falcon-2','hi-IN','request_accepted',
  'Context-scoped clear was sent after first old audio; no later old payload arrived and new context finalized on the same socket.',(),
  'One adaptive session; clear response is not an explicit ACK and causal interruption or phone barge-in is not certified',
  'artifacts/murf-adaptive-clear-20260916/manifest.json')
 observe('murf','connection_reuse','falcon-2','hi-IN','measured_output',
  'Old and new Hindi contexts both returned audio on one WebSocket; new context finalized after clear.',(),
  'One socket, two short turns; sustained reuse and load unmeasured',
  'artifacts/murf-adaptive-clear-20260916/manifest.json')
 fish_timing=verify_fish_timestamps(ROOT/'artifacts/fish-timestamp-ws-20260916')
 if not fish_timing['first_audio_before_second_text'] or fish_timing['timestamp_frames']<1 or fish_timing['word_segments']<1:
  raise ValueError('Fish native staged-timing observation incomplete')
 fish_pcm=fish_timing['raw_audio_file'].read_bytes()
 fish_wav_buffer=io.BytesIO()
 with wave.open(fish_wav_buffer,'wb') as decoded:
  decoded.setnchannels(1);decoded.setsampwidth(2);decoded.setframerate(24000);decoded.writeframes(fish_pcm)
 fish_wav=fish_wav_buffer.getvalue();fish_wav_name='fish-s2.1-pro-free-timestamp-hi-IN.wav'
 (destination/'audio'/fish_wav_name).write_bytes(fish_wav)
 fish_text=' '.join(a['text'].strip() for a in read('artifacts/fish-timestamp-ws-20260916/summary.json')['actions'] if a['type']=='text')
 native_audio_runs.append({'provider':'fish','model':'s2.1-pro-free','language':'hi-IN',
  'voice':'9a9cf47702da476aa4629e2506d4a857','text':fish_text,
  'audio_format':'pcm_s16le','sample_rate':24000,
  'audio_url':'/evidence/audio/'+fish_wav_name,'audio_sha256':hashlib.sha256(fish_wav).hexdigest(),
  'duration_seconds':fish_timing['pcm_duration_seconds'],'first_audio_ms':None,
  'audio_before_final_text':True,'boundary':'Native Fish timestamp WebSocket PCM received before second text; no playout or perceptual alignment check',
  'timestamp_frames':fish_timing['timestamp_frames'],'word_segments':fish_timing['word_segments'],
  'alignment_accuracy':'unverified'})
 fish_transport_manifest=read('artifacts/fish-transport-latency-20260916/manifest.json')
 transport_rest_ids={r['run_id'] for r in fish_transport_manifest['results'] if r['route']=='rest'}
 if len(transport_rest_ids)!=12 or not transport_rest_ids<={r['run_id'] for r in public_runs if r.get('audio_url')}:
  raise ValueError('Fish transport REST audio not published from raw HTTP results')
 for item in fish_transport_manifest['results']:
  if item['route']!='websocket':continue
  source=(ROOT/item['source_result']).resolve()
  if not source.is_relative_to(ROOT/'artifacts/fish-transport-latency-20260916/websocket'):
   raise ValueError('Fish WebSocket transport sample escaped evidence root')
  sample=json.loads(source.read_text());wav=(source.parent/sample['playable_file']).read_bytes()
  name=f"fish-transport-websocket-hi-IN-{item['ordinal']:02d}.wav"
  (destination/'audio'/name).write_bytes(wav)
  native_audio_runs.append({'provider':'fish','model':'s2.1-pro-free','language':'hi-IN',
   'voice':sample['voice'],'text':fish_transport_manifest['transcript'],
   'audio_format':'pcm_s16le','sample_rate':24000,
   'audio_url':'/evidence/audio/'+name,'audio_sha256':hashlib.sha256(wav).hexdigest(),
   'duration_seconds':sample['duration_seconds'],'first_audio_ms':sample['first_audio_ms'],
   'audio_before_final_text':False,
   'boundary':'Fresh TCP/TLS WebSocket start to first received PCM; no phone playout or load qualification',
   'transport_latency_ordinal':item['ordinal']})
 fish_source='artifacts/fish-timestamp-ws-20260916/summary.json'
 observe('fish','word_timestamps','s2.1-pro-free','hi-IN','metadata_observed',
  f"Native with-timestamp WebSocket returned {fish_timing['word_segments']} word segments in {fish_timing['timestamp_frames']} cumulative timing snapshots.",(),
  'Timing payload and PCM are hash-verified; spoken word/audio alignment accuracy unverified',fish_source)
 observe('fish','text_input_streaming','s2.1-pro-free','hi-IN','payload_observed',
  'Two staged Hindi text fragments were sent on one native socket; PCM arrived before the second fragment.',(),
  'One short session; token cadence and load unmeasured',fish_source)
 observe('fish','flush','s2.1-pro-free','hi-IN','request_accepted',
  'Two Flush messages were sent during staged Hindi input and the session returned PCM and Finish.',(),
  'Flush causal effect is not established without a matched no-flush control',fish_source)
 for item in streams:
  name='soniox-native-'+item['audio_format']+'.wav'
  wav=(ROOT/'artifacts/soniox-multiplex-20260915'/item['audio_file']).read_bytes()
  (destination/'audio'/name).write_bytes(wav)
  native_audio_runs.append({'provider':'soniox','model':'tts-rt-v2','language':'hi-IN','voice':'Kavya',
   'text':' '.join(item['text_parts']),'audio_format':item['audio_format'],'sample_rate':item['sample_rate'],
   'audio_url':'/evidence/audio/'+name,'audio_sha256':item['audio_sha256'],
   'duration_seconds':item['duration_seconds'],'first_audio_ms':item['first_audio_ms'],
   'audio_before_final_text':item['audio_before_final_text'],'boundary':multiplex['boundary']})
 recovery_name='soniox-cancel-recovery-hi-IN.wav'
 recovery_wav=(ROOT/'artifacts/soniox-playout-20260916/recovery.wav').read_bytes()
 if hashlib.sha256(recovery_wav).hexdigest()!=soniox_playout_audit['recovery_wav_sha256']:
  raise ValueError('Soniox recovered WAV differs from independently audited capture')
 (destination/'audio'/recovery_name).write_bytes(recovery_wav)
 native_audio_runs.append({'provider':'soniox','model':'tts-rt-v2','language':'hi-IN','voice':'Kavya',
  'text':'Recovery after synthetic caller interruption','audio_format':'pcm_s16le','sample_rate':24000,
  'audio_url':'/evidence/audio/'+recovery_name,
  'audio_sha256':soniox_playout_audit['recovery_wav_sha256'],
  'duration_seconds':(len(recovery_wav)-44)/48000,'first_audio_ms':None,
  'audio_before_final_text':False,
  'boundary':'native_websocket_'+soniox_playout_audit['boundary'],
  'production_telephony_verified':False})
 multiplex_source='artifacts/soniox-multiplex-20260915/result.json'
 observe('soniox','text_input_streaming','tts-rt-v2','hi-IN','request_accepted','Two separate Hindi text chunks completed one stream with playable PCM.',(),
  'Chunk acceptance only; this run received no audio before the final text chunk',multiplex_source)
 observe('soniox','connection_reuse','tts-rt-v2','hi-IN','measured_output','Two sequential text-bearing streams terminated with audio on one WebSocket connection.',(),
  'One socket; longevity, concurrent multiplexing and reconnect untested',multiplex_source)
 observe('soniox','audio_streaming','tts-rt-v2','hi-IN','payload_observed',f"Native WebSocket returned {streams[0]['audio_chunks']} PCM chunks for the first Hindi stream.",(),
  'Payload chunks only; receiver playout cadence and load unverified',multiplex_source)
 observe('soniox','telephony_formats','tts-rt-v2','hi-IN','payload_observed',f"Second stream returned {streams[1]['audio_bytes']} native 8 kHz G.711 mu-law bytes.",(),
  'Codec delivery only; SIP/RTP/handset playout unverified',multiplex_source)
 concurrent=read('artifacts/soniox-concurrency-20260915/result.json')
 turns=concurrent['streams']
 if concurrent['status']!='complete' or concurrent['provider']!='soniox' or concurrent['model']!='tts-rt-v2' or concurrent['requests_limit']!=2 or concurrent['automatic_retries']!=0 or concurrent['connection_count']!=1 or len(turns)!=2 or concurrent['production_telephony_verified'] is not False:
  raise ValueError('Soniox bounded concurrency report inconsistent')
 if len({t['stream_id'] for t in turns})!=2 or not all(t['status']=='success' and t['audio_end_observed'] and t['terminated_observed'] and t['other_stream_active_at_first_audio'] and not t['error_types'] and t['audio_chunks']>1 and t['first_audio_ms']>concurrent['both_streams_submitted_ms'] for t in turns):
  raise ValueError('Soniox active concurrent delivery not established')
 for index,item in enumerate(turns,1):
  wav=(ROOT/'artifacts/soniox-concurrency-20260915'/item['audio_file']).read_bytes()
  if hashlib.sha256(wav).hexdigest()!=item['audio_sha256']:raise ValueError('Soniox concurrent WAV hash mismatch')
  with wave.open(io.BytesIO(wav),'rb') as decoded:
   if decoded.getnchannels()!=1 or decoded.getsampwidth()!=2 or decoded.getframerate()!=24000 or decoded.getnframes()*2!=item['audio_bytes']:
    raise ValueError('Soniox concurrent PCM shape mismatch')
  name=f'soniox-concurrent-stream-{index}.wav'
  (destination/'audio'/name).write_bytes(wav)
  native_audio_runs.append({'provider':'soniox','model':'tts-rt-v2','language':'hi-IN','voice':'Kavya',
   'text':item['text'],'audio_format':'pcm_s16le','sample_rate':24000,
   'audio_url':'/evidence/audio/'+name,'audio_sha256':item['audio_sha256'],
   'duration_seconds':item['duration_seconds'],'first_audio_ms':item['first_audio_ms'],
   'audio_before_final_text':False,'boundary':concurrent['boundary']})
 observe('soniox','concurrency_limits','tts-rt-v2','hi-IN','measured_output','Two simultaneous Hindi streams both returned PCM while the other stream remained active.',(),
  'One socket and two streams only; account maximum, sustained load and p95 capacity unverified','artifacts/soniox-concurrency-20260915/result.json')
 flux_interrupt=verify_deepgram_flux_interrupt(ROOT/'artifacts/deepgram-flux-interrupt-20260915-v3')
 flux_raw=read('artifacts/deepgram-flux-interrupt-20260915-v3/result.json')
 for name,text in [('old_received',flux_raw['first_text']),
                   ('old_played',flux_raw['first_text']),
                   ('recovery',flux_raw['recovery_text'])]:
  saved=flux_interrupt['files'][name];source=ROOT/'artifacts/deepgram-flux-interrupt-20260915-v3'/(name+'.wav')
  public_name='deepgram-flux-'+name+'.wav';(destination/'audio'/public_name).write_bytes(source.read_bytes())
  native_audio_runs.append({'provider':'deepgram','model':'flux-priya-en','language':'en-IN','voice':'Priya',
   'text':text,'audio_format':'pcm_s16le','sample_rate':24000,
   'audio_url':'/evidence/audio/'+public_name,'audio_sha256':saved['sha256'],
   'duration_seconds':saved['duration_ms']/1000,'first_audio_ms':None,
   'audio_before_final_text':name!='recovery',
   'boundary':('Old turn PCM received; only first 160 ms played to software receiver before synthetic caller onset.' if name=='old_received' else
               'Exact first 160 ms played to software receiver; later old PCM discarded.' if name=='old_played' else
               'Recovery turn on same Flux WebSocket after SpeechInterrupted; native accent unscored.')})
 flux_source=flux_interrupt['source_result']
 flux_boundary='One synthetic software receiver, deterministic caller onset without VAD, no SIP/RTP/handset; Connected model_name was short voice name priya rather than requested flux-priya-en.'
 observe('deepgram','audio_streaming','flux-priya-en','en-IN','payload_observed',
  'Flux v2 WebSocket returned raw PCM for the first turn before any Flush.',(),flux_boundary,flux_source)
 observe('deepgram','cancel','flux-priya-en','en-IN','measured_output',
  f"Local playout stopped after {flux_interrupt['played_audio_ms']} ms; SpeechInterrupted echoed offset and split text; native ACK {flux_interrupt['native_interrupt_ack_ms']:.1f} ms; {flux_interrupt['old_received_not_played_bytes_discarded']} old PCM bytes not played.",(),flux_boundary,flux_source)
 observe('deepgram','flush','flux-priya-en','en-IN','metadata_observed',
  'Recovery turn received Flushed then SpeechMetadata after client Flush.',(),flux_boundary,flux_source)
 observe('deepgram','connection_reuse','flux-priya-en','en-IN','measured_output',
  'Interrupted first turn and completed recovery turn on one WebSocket connection.',(),flux_boundary+' One connection and two turns only.',flux_source)
 if playout_audit['status']!='observed' or playout_audit['software_stop_latency_ms'] is None:raise ValueError('Cartesia playout status inconsistent')
 observe('cartesia','cancel','sonic-3.6','hi-IN','measured_output',f"Software playout stopped in {playout_audit['software_stop_latency_ms']:.1f} ms; provider sent {playout_audit['provider_payload_after_cancel_bytes']} post-cancel bytes, discarded.",(),'Synthetic tone, software playout only; production receiver unverified','artifacts/cartesia-playout-20260915-v2/result.json')
 for session in native_sessions:
  if session['status']!='observed' or not session.get('audio_integrity_verified'):continue
  if session['provider']=='fonada' and session['model']=='fonada-v1':continue
  observe(session['provider'],'audio_streaming',session.get('model') or 'model not recorded','hi-IN','payload_observed',f"WebSocket session received audio payload in {session['audio_contexts']} context(s).",(),'Payload receipt; steady-state playout and concurrency unverified',session['result_path'])
 # Link the already-saved two-context live sessions to each control they actually
 # exercised.  Require the preserved event sequence as well as the release
 # inventory's hash-verified audio; an action listed in a fixture is insufficient.
 for provider in ('cartesia','elevenlabs'):
  session=next((s for s in native_sessions if s['provider']==provider and s['result_path'].startswith('artifacts/sessions-access-20260915/')),None)
  if not session or session['status']!='observed' or not session['audio_integrity_verified'] or session['audio_contexts']<2:
   raise ValueError('Two-context live session integrity missing: '+provider)
  saved=read(session['result_path']);events=saved['events'];source=session['result_path']
  if saved['status']!='observed' or saved['config']['model']!=session['model'] or saved['config']['language']!='hi-IN':
   raise ValueError('Two-context model or locale mismatch: '+provider)
  first=next((c for c in session['contexts'] if c['context']=='first'),None)
  second=next((c for c in session['contexts'] if c['context']=='second'),None)
  if not first or not second or first['first_payload_ms'] is None or second['first_payload_ms'] is None:
   raise ValueError('Second context did not deliver audio: '+provider)
  sent=lambda kind,context:[e for e in events if e.get('event_type')=='action_sent' and e.get('action_type')==kind and e.get('context_id')==context and e.get('message_count',0)>0]
  if len(sent('text','first'))!=2 or len(sent('text','second'))!=1 or not sent('end_input','first') or not sent('end_input','second'):
   raise ValueError('Incremental text actions not observed: '+provider)
  model=session['model']
  observe(provider,'connection_reuse',model,'hi-IN','measured_output','Two text-bearing contexts returned audio on one native WebSocket connection.',(),'One socket and two contexts; reconnect, longevity and concurrent capacity untested',source)
  observe(provider,'text_input_streaming',model,'hi-IN','request_accepted','Two separate Hindi text chunks were sent within the first context and audio was returned.',(),'Chunk acceptance only; audio-before-final-text and sustained incremental generation unverified',source)
  flush=sent('flush','first')
  if len(flush)!=1:raise ValueError('Flush control not sent: '+provider)
  terminal_types={'cartesia':{'flush_done'},'elevenlabs':{'turn_done'}}[provider]
  terminal=[e for e in events if e.get('event_type')=='provider_event' and e.get('details',{}).get('type') in terminal_types and e.get('context_id','first')=='first']
  if not terminal:raise ValueError('Flush/turn terminal event missing: '+provider)
  observe(provider,'flush',model,'hi-IN','metadata_observed',
   'Flush command and flush_done event observed.' if provider=='cartesia' else 'Flush action sent; turn-final event observed after close_context.',(),
   'One mixed flush/end-input schedule; independent flush causality unverified',source)
  if provider=='cartesia':
   marks=[e for e in events if e.get('event_type')=='provider_event' and e.get('details',{}).get('type')=='timestamps' and e.get('details',{}).get('metadata',{}).get('word_timestamps',{}).get('words')]
   if not marks:raise ValueError('Cartesia word timestamp payload missing')
   observe('cartesia','word_timestamps',model,'hi-IN','metadata_observed',f'{len(marks)} native word-timestamp payloads returned.',(),
    'Presence only; word-to-PCM alignment accuracy unverified',source)
 dictionary=read('artifacts/sarvam-dictionary-20260915/summary.json')
 if dictionary['creation']['http_status']==400:
  observe('sarvam','pronunciation_dictionary','bulbul:v3','hi-IN','account_blocked','Dictionary creation returned HTTP 400: limit exceeded. No entry or synthesis accuracy test ran.',(),'Account prerequisite blocked this feature test','artifacts/sarvam-dictionary-20260915/summary.json')
 fonada_feature=read('artifacts/fonada-feature-20260915/summary.json')
 speed_records=fonada_feature['records'][:2]
 if fonada_feature['speed_effect']['direction']!='shorter_at_higher_setting' or len(speed_records)!=2 or any(r['status']!='success' or not r['duration_seconds'] for r in speed_records):raise ValueError('Fonada speed result inconsistent')
 speed=fonada_feature['speed_effect']
 observe('fonada','speed','klone-v2-pro','hi-IN','measured_output',f"Same Hindi text and share_id: speed 1.0→1.4, duration {speed['baseline_seconds']:.2f}→{speed['higher_speed_seconds']:.2f} s ({speed['duration_ratio']:.3f} ratio).",[r['run_id'] for r in speed_records],'One pair; native pace/intelligibility unverified','artifacts/fonada-feature-20260915/summary.json')
 tele=next((r for r in fonada_feature['records'] if r['scenario']=='telephony-mulaw'),None)
 if fonada_feature['telephony_delivery']!='observed_raw_mulaw' or not tele or tele['status']!='success' or not tele['headerless_audio'] or tele['response_headers'][0]['x-output-codec']!='mulaw':raise ValueError('Fonada mu-law result inconsistent')
 observe('fonada','telephony_formats','klone-v2-pro','hi-IN','payload_observed',f"Returned {tele['raw_payload_bytes']} headerless mu-law bytes with X-Output-Codec: mulaw and audio/basic at documented 8 kHz.",[tele['run_id']],'One format request only; SIP/RTP playout and telephony receiver untested','artifacts/fonada-feature-20260915/summary.json')
 observe('cartesia','telephony_formats','sonic-3.6','hi-IN','payload_observed',
  f"HTTP 200 returned {cartesia_telephony['raw_payload_bytes']} headerless bytes requested as 8 kHz G.711 mu-law; the decoded original-rate PCM WAV is non-silent.",
  [cartesia_telephony['run_id']],cartesia_telephony['boundary'],'artifacts/cartesia-telephony-20260916/summary.json')
 observe('elevenlabs','telephony_formats','eleven_v3','hi-IN','payload_observed',
  f"HTTP 200 returned {elevenlabs_telephony['raw_payload_bytes']} native headerless 8 kHz G.711 mu-law bytes; independently decoded original-rate WAV is non-silent.",
  [elevenlabs_telephony['run_id']],elevenlabs_telephony['boundary'],elevenlabs_telephony['source'])
 observe('neuphonic','speed','voice-selected hosted model; revision not returned','hi-IN','request_accepted',
  f"Two same-text Priya Hindi requests accepted documented speed buckets 0.7 and 1.5 and returned {neuphonic_speed['clips'][0]['duration_seconds']:.2f} s and {neuphonic_speed['clips'][1]['duration_seconds']:.2f} s PCM.",
  [clip['run_id'] for clip in neuphonic_speed['clips']],
  'One pair differed by 2.2%; no replicated pace effect or exact backend model revision.',
  'artifacts/neuphonic-speed-20260916/summary.json')
 speed_batch=read('artifacts/speed-pairs-20260915/summary.json')
 for provider in ('inworld',):
  pair=speed_batch['pairs'][provider]
  if pair['status']!='measured_pair' or len(pair['records'])!=2 or any(r['status']!='success' for r in pair['records']):raise ValueError('Rate-pair evidence inconsistent: '+provider)
  a,b=pair['duration_seconds'];values=[r['speed'] for r in pair['records']]
  observe(provider,'speed',pair['model'],'hi-IN','measured_output',f"Same Hindi text and voice: rate {values[0]}→{values[1]}, duration {a:.2f}→{b:.2f} s ({pair['ratio']:.3f} ratio).",[r['run_id'] for r in pair['records']],'One pair; native intelligibility and repeatability unverified','artifacts/speed-pairs-20260915/summary.json')
 inworld_steering=read('artifacts/inworld-steering-20260915/summary.json')
 steering_records=inworld_steering['records']
 if (not inworld_steering.get('complete') or inworld_steering.get('emotional_accuracy')!='unverified'
     or len(steering_records)!=2 or any(r.get('status')!='success' or r.get('provider')!='inworld' for r in steering_records)
     or len({r['text'] for r in steering_records})!=1
     or len({r['config'].get('model') for r in steering_records})!=1
     or len({r['config'].get('voice') for r in steering_records})!=1
     or {r['config'].get('instruction') for r in steering_records}!={'Speak calmly and gently.','Speak angrily and forcefully.'}):
  raise ValueError('Inworld emotion-control evidence inconsistent')
 steering_ids=[r['run_id'] for r in steering_records]
 if any(not next((p for p in public_runs if p['run_id']==run_id and p.get('audio_url')),None) for run_id in steering_ids):
  raise ValueError('Inworld emotion control lacks published playable audio')
 observe('inworld','emotion','inworld-tts-2','hi-IN','request_accepted',
  'Same Hindi text and voice: calm and angry instruction requests both returned saved WAV audio.',steering_ids,
  'Request acceptance only; perceived emotion accuracy and spoken cue leakage remain unverified.',
  'artifacts/inworld-steering-20260915/summary.json')
 # Additional saved request pairs with current-model controls and fixed voices.
 for provider,scenario_a,scenario_b,model,language in [
  ('camb','hi-calm','hi-cheerful','mars-instruct','hi-IN'),
  ('fish','fish-hindi-calm','fish-hindi-angry','s2.1-pro-free','hi-IN'),
  ('soniox','soniox-hindi-calm','soniox-hindi-excited','tts-rt-v2','hi-IN'),
  ('speechify','current-neutral','current-cheerful','simba-3.2','en-IN')]:
  selected=[next((r for r in public_runs if r['provider']==provider and r['scenario_id']==name and r.get('audio_url')),None) for name in (scenario_a,scenario_b)]
  if any(r is None for r in selected):raise ValueError('Saved control pair missing: '+provider)
  if any(r['config'].get('model')!=model for r in selected):raise ValueError('Saved control model mismatch: '+provider)
  # Keep the exact result records attached to the observation.  This is
  # request acceptance evidence only; it must not be promoted to a quality
  # or native-language claim.
  source_path='artifacts/runs/access-20260915/'+provider+'/'+selected[0]['run_id']+'/result.json'
  if not (ROOT/source_path).exists():
   source_path='artifacts/runs/'+provider+'/'+selected[0]['run_id']+'/result.json'
  observe(provider,'emotion',model,language,'request_accepted','Two different emotion/style requests returned saved audio. Perceived delivery has not been scored.',[r['run_id'] for r in selected],'Request acceptance only; native emotion accuracy and cue leakage unverified',source_path)
 speech_ssml=next((r for r in public_runs if r['provider']=='speechify' and r['scenario_id']=='current-cheerful' and r.get('audio_url')),None)
 if not speech_ssml or speech_ssml['config'].get('model')!='simba-3.2' or speech_ssml['config'].get('mode')!='stream' or speech_ssml['language']!='en-IN' or '<speechify:style emotion="cheerful">' not in speech_ssml['text'] or not speech_ssml.get('first_audio_ms'):
  raise ValueError('Speechify current-model SSML stream evidence inconsistent')
 speech_source='artifacts/runs/access-20260915/speechify/'+speech_ssml['run_id']+'/result.json'
 if read(speech_source)['status']!='success':raise ValueError('Speechify original result not successful')
 observe('speechify','ssml','simba-3.2','en-IN','request_accepted','Vendor emotion SSML was sent unchanged and returned 16 kHz PCM audio.',[speech_ssml['run_id']],'SSML acceptance only; perceived emotion and general SSML conformance unverified',speech_source)
 observe('speechify','audio_streaming','simba-3.2','en-IN','payload_observed',f"HTTP stream returned PCM with first received audio at {speech_ssml['first_audio_ms']:.0f} ms.",[speech_ssml['run_id']],'One stream request; chunk cadence, continuous playout and load unverified',speech_source)
 # Existing output-control trials returned audio but do not establish perceived emotion.
 for audit in emotion_rows:
  provider=next((p for p in providers if p['id']==audit['provider']),None)
  if provider is None or audit['provider'] in {'minimax','camb','fish','soniox','speechify'}:continue
  controls=[r for r in public_runs if r['provider']==audit['provider'] and r.get('audio_url') and (r.get('stratum','').startswith('emotion_') or r.get('scenario_id','').startswith('emotion-'))]
  if len(controls)<2:continue
  chosen=controls[:2]
  if len({r['language'] for r in chosen})!=1 or len({r['config'].get('model') for r in chosen})!=1:continue
  source_path='artifacts/runs/access-20260915/'+audit['provider']+'/'+chosen[0]['run_id']+'/result.json'
  if not (ROOT/source_path).exists():
   source_path='artifacts/runs/'+audit['provider']+'/'+chosen[0]['run_id']+'/result.json'
  observe(audit['provider'],'emotion',chosen[0]['config'].get('model','model not recorded'),chosen[0]['language'],'request_accepted',f"Two saved emotion-control requests returned audio; {audit['live_evidence']}",[r['run_id'] for r in chosen],'Perceived emotion accuracy and spoken cue leakage unverified',source_path)
 data={'generated_at'  :datetime.now(timezone.utc).isoformat(),'evidence_date':datetime.now(ZoneInfo('Asia/Kolkata')).date().isoformat(),'code_sha256':code_digest(),
  'providers':[{k:p.get(k) for k in provider_fields} for p in providers], 'runs':[r for r in public_runs if r['evidence_class']=='live_http'],
  'local_runs':[r for r in public_runs if r['evidence_class']=='local_model_execution'],'maya_local_runs':maya_local_runs,
  'studio_audio_runs':studio_audio_runs,
  'summary':summarize_live_runs(runs,code_digest(),providers),
  'verification':{k:release.get(k) for k in ['offline_tests','offline_tests_passed','source_snapshots','native_listener_ratings','production_calls','vendor_certifications','code_sha256']},
  'limitations':['Historical requests use different texts, voices and native sample rates; they are not a fair latency ranking.','Matched set fixes text within each stratum; voices and generation settings still differ.','No native listener scores, production calls or reconciled costs have been completed. Local batch inference is separate from streaming and production performance.'],
  'native_sessions':native_sessions,'native_audio_runs':native_audio_runs,'sarvam_native_audit':sarvam_native_audit,'sarvam_playout_audit':sarvam_playout_audit,'soniox_speed_audit':soniox_speed,'neuphonic_speed_audit':neuphonic_speed,'murf_native_audit':murf_native_audit,'murf_clear_audit':murf_clear_audit,'murf_locale_style_audit':murf_locale_style_audit,'fish_timestamp_audit':{k:v for k,v in fish_timing.items() if k!='raw_audio_file'},'fish_transport_latency_audit':fish_transport_latency_audit,'neuphonic_urdu_audit':neuphonic_urdu_audit,'deepgram_flux_interrupt_audit':flux_interrupt,'matched_latency_audit':latency_audit,'latency_exploratory_audit':latency_exploratory,'dubverse_flagship_audit':dubverse_flagship_audit,'feature_observations':observations,'soniox_cancel':soniox_cancel,'soniox_playout_audit':soniox_playout_audit,'soniox_marks':soniox_marks,'clone_audit':clone,'emotion_audit':emotion_rows,'access_audit':access,'usage_audit':usage,'subscription_audit':subscription_audit,'playout_audit':playout_audit,'transcript_audit':transcript_audit,'cross_asr_audit':cross_audit,'local_qualification':qualification,'feature_prerequisites':prerequisites,'offline_jobs':jobs,'timestamp_test':{k:timestamps[k] for k in ('provider','model','run_id','timing_metadata','verification','alignment_accuracy')},'pause_test':{'outcome':pause['outcome'],'parameters':pause['diagnostic_parameters']}}
 data['sarvam_transport_latency_audit']=sarvam_transport_latency_audit
 data['cartesia_telephony_audit']=cartesia_telephony
 data['language_review_audit']=verify_language_review(ROOT)
 (destination/'snapshot.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 if destination.resolve()==(ROOT/'ui/public/evidence').resolve():
  (destination/'soniox-playout-audit.json').write_text(json.dumps(soniox_playout_audit,ensure_ascii=False,indent=2)+'\n')
  (destination/'sarvam-native-audit.json').write_text(json.dumps(sarvam_native_audit,ensure_ascii=False,indent=2)+'\n')
  (destination/'cartesia-telephony-audit.json').write_text(json.dumps(cartesia_telephony,ensure_ascii=False,indent=2)+'\n')
  (destination/'language-review-audit.json').write_text(json.dumps(data['language_review_audit'],ensure_ascii=False,indent=2)+'\n')
  (destination/'sarvam-playout-audit.json').write_text(json.dumps(sarvam_playout_audit,ensure_ascii=False,indent=2)+'\n')
  integrity=verify_public_audio(ROOT)
  (destination/'audio-integrity-audit.json').write_text(json.dumps(integrity,ensure_ascii=False,indent=2)+'\n')
  codemix=verify_codemix_asr(ROOT)
  data['codemix_asr_audit']=codemix
  regional=verify_regional_asr(ROOT)
  data['regional_asr_audit']=regional
  current_status=ROOT/'artifacts/current-revision-api-20260916/status.json'
  if current_status.exists() and read('artifacts/current-revision-api-20260916/status.json')['status']=='complete':
   current_api=verify_current_revision_api(ROOT)
   data['current_revision_api_audit']=current_api
   (destination/'current-revision-api-audit.json').write_text(json.dumps(current_api,ensure_ascii=False,indent=2)+'\n')
  (destination/'snapshot.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
  (destination/'codemix-asr-audit.json').write_text(json.dumps(codemix,ensure_ascii=False,indent=2)+'\n')
  (destination/'regional-asr-audit.json').write_text(json.dumps(regional,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'providers':len(providers),'http_attempts':len(runs),'local_attempts':len(local_runs),'playable_audio':sum(bool(r['audio_url']) for r in public_runs),'matched':sum(r['matched'] for r in public_runs)}))
 return data
if __name__=='__main__': export()
