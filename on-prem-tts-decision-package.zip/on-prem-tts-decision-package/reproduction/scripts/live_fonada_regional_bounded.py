"""One Klone V2 Pro regional pass on authenticated target codes; no retries."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/runs/fonada-regional-20260915'
MANIFEST=ROOT/'artifacts/fonada-regional-20260915/manifest.json'
PROMPTS=[('bn-IN','নমস্কার, আপনার পেমেন্ট পাওয়া গেছে। ধন্যবাদ।'),('mr-IN','नमस्कार, तुमचे पेमेंट मिळाले आहे. धन्यवाद।'),('te-IN','నమస్కారం, మీ చెల్లింపు అందింది. ధన్యవాదాలు.'),('gu-IN','નમસ્તે, તમારી ચુકવણી મળી ગઈ છે. આભાર.'),('kn-IN','ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು.'),('ml-IN','നമസ്കാരം, നിങ്ങളുടെ പണം ലഭിച്ചു. നന്ദി.'),('ur-IN','آپ کی قسط کی رقم ₹15,000 ہے۔')]
BASE={'model':'klone-v2-pro','voice':'4J4SEQ1X','format':'wav'}

async def main():
 if OUT.exists() or MANIFEST.exists():raise RuntimeError('Existing Fonada regional batch; no repeat')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('FONADA_API_KEY')
 if not key:raise RuntimeError('No authorized Fonada key')
 for locale,text in PROMPTS:build_request('fonada',text,{**BASE,'language':locale},{'FONADA_API_KEY':key})
 OUT.mkdir(parents=True);MANIFEST.parent.mkdir(parents=True)
 report={'provider':'fonada','model':'klone-v2-pro','share_id':'4J4SEQ1X','request_limit':7,'retries':0,'target_codes_source':'authenticated /v1/voice-clone/languages 2026-09-15','native_language_quality':'unverified','voice_cross_language_quality':'unverified','samples':[]}
 def save():MANIFEST.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'FONADA_API_KEY':key}))
 save();os.environ['FONADA_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   for locale,text in PROMPTS:
    r=await run_one('fonada',text,{**BASE,'language':locale},OUT,timeout=35,client=client,scenario_id='payment-'+locale,evaluation_language=locale,stratum='regional_delivery_bounded',min_free_bytes=300*1024*1024)
    report['samples'].append({k:r.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms')});report['samples'][-1]['locale']=locale;save()
    print(locale,r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
    await asyncio.sleep(.5)
 finally:os.environ.pop('FONADA_API_KEY',None)
 report['completed']=True;save()

if __name__=='__main__':asyncio.run(main())
