"""Bounded Sarvam Saaras v3 REST transcript observations for saved TTS audio.

Dry preflight is the default. Live requests require --live and an exact request cap.
This is lexical diagnostic evidence, never native review or perceptual certification.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import urllib.error
import urllib.request
import uuid
import wave

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
PACKAGE = ROOT / 'artifacts/transcript-references-20260915'
SNAPSHOT = ROOT / 'ui/public/evidence/snapshot.json'
AUDIO_ROOT = (ROOT / 'ui/public/evidence/audio').resolve()
CREDENTIALS = Path('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
ENDPOINT = 'https://api.sarvam.ai/speech-to-text'
MODEL = 'saaras:v3'
MAX_ITEMS = 24
MAX_AUDIO_BYTES = 25_000_000  # local conservative transport bound, not a vendor claim
SHA = re.compile(r'[0-9a-f]{64}\Z')
ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:@/+\-]*\Z')


def _json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def _index(rows, field):
    if not isinstance(rows, list):
        raise ValueError('Package records must be lists')
    result = {}
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get(field), str) or row[field] in result:
            raise ValueError(f'Invalid or duplicate {field}')
        result[row[field]] = row
    return result


def selected_ids(reference_id=None, manifest=None):
    if (reference_id is None) == (manifest is None):
        raise ValueError('Specify exactly one of --reference-id or --manifest')
    if reference_id is not None:
        ids = [reference_id]
    else:
        document = _json(Path(manifest))
        if not isinstance(document, dict) or document.get('schema') != 'indic_asr_pilot_v1':
            raise ValueError('Unsupported pilot manifest schema')
        refs_bytes = (PACKAGE / 'references.json').read_bytes()
        if document.get('source_references_sha256') != hashlib.sha256(refs_bytes).hexdigest():
            raise ValueError('Pilot manifest reference-file hash mismatch')
        items = document.get('items')
        if not isinstance(items, list):
            raise ValueError('Pilot manifest items must be a list')
        ids = [item.get('reference_id') if isinstance(item, dict) else None for item in items]
        refs = _index(json.loads(refs_bytes), 'reference_id')
        for item in items:
            if not isinstance(item, dict) or item.get('reference_id') not in refs:
                raise ValueError('Pilot manifest item lacks a known reference')
            ref = refs[item['reference_id']]
            if any(item.get(k) != ref[k] for k in ('provider', 'model', 'language', 'audio_sha256')):
                raise ValueError('Pilot manifest item/reference identity mismatch')
            if item.get('draft_text_sha256') != hashlib.sha256(ref['text'].encode('utf-8')).hexdigest():
                raise ValueError('Pilot manifest draft-text hash mismatch')
        if document.get('planned_requests') != len(ids):
            raise ValueError('Pilot manifest planned-request count mismatch')
    if not isinstance(ids, list) or not 1 <= len(ids) <= MAX_ITEMS:
        raise ValueError('Selection requires 1 to 24 reference_ids')
    if any(not isinstance(x, str) or not ID.fullmatch(x) for x in ids) or len(set(ids)) != len(ids):
        raise ValueError('Invalid or duplicate reference_id in selection')
    return ids


def preflight(ids, mode, max_requests):
    if mode not in ('verbatim', 'codemix'):
        raise ValueError('Mode must be verbatim or codemix')
    if type(max_requests) is not int or not 1 <= max_requests <= MAX_ITEMS or len(ids) > max_requests:
        raise ValueError('Selection exceeds explicit --max-requests cap')
    refs = _index(_json(PACKAGE / 'references.json'), 'reference_id')
    provenance = _index(_json(PACKAGE / 'provenance.json'), 'reference_id')
    runs = _index(_json(SNAPSHOT)['runs'], 'run_id')
    planned = []
    for rid in ids:
        if rid not in refs or rid not in provenance or rid not in runs:
            raise ValueError('Selected reference is absent from reference, provenance, or saved run')
        ref, prov, run = refs[rid], provenance[rid], runs[rid]
        if ref.get('run_id') != rid or run.get('run_id') != rid or run.get('status') != 'success':
            raise ValueError('Reference/run identity mismatch')
        if any(ref.get(k) != run.get(k) for k in ('provider', 'language')) or ref.get('model') != run.get('config', {}).get('model'):
            raise ValueError('Reference/run provider, model, or language mismatch')
        if ref.get('text') != run.get('text') or ref.get('native_reviewed') is not False:
            raise ValueError('Draft reference text or review status differs from saved run')
        expected = ref.get('audio_sha256')
        if not isinstance(expected, str) or not SHA.fullmatch(expected) or expected != run.get('listening_audio_sha256'):
            raise ValueError('Reference/run audio hash mismatch')
        audio = Path(prov.get('audio_file', '')).resolve()
        expected_audio = (ROOT / 'ui/public' / run.get('audio_url', '').lstrip('/')).resolve()
        if not audio.is_relative_to(AUDIO_ROOT) or audio != expected_audio or not audio.is_file() or audio.suffix.lower() != '.wav':
            raise ValueError('Unsafe or missing saved WAV audio')
        data = audio.read_bytes()
        if not 0 < len(data) <= MAX_AUDIO_BYTES or hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('Saved audio size or content hash mismatch')
        try:
            with wave.open(str(audio), 'rb') as wav:
                duration = wav.getnframes() / wav.getframerate()
                if wav.getcomptype() != 'NONE' or wav.getsampwidth() not in (1, 2, 3, 4):
                    raise ValueError('Saved WAV encoding is not supported by this diagnostic')
        except (wave.Error, ZeroDivisionError) as exc:
            raise ValueError('Invalid WAV media') from exc
        if not 0 < duration <= 30:
            raise ValueError('REST audio must be at most 30 seconds')
        planned.append((ref, audio, data, duration))
    return planned


def read_key():
    # Only this exact authorized file is read; never print values or include them in output.
    from tts_arena.credentials import read_credentials
    key = read_credentials(str(CREDENTIALS)).get('SARVAM_API_KEY')
    if not isinstance(key, str) or not key.strip():
        raise ValueError('SARVAM_API_KEY unavailable in authorized credential file')
    return key


def _multipart(data, filename, mode):
    boundary = 'arena-' + uuid.uuid4().hex
    chunks = []
    for name, value in (('model', MODEL), ('mode', mode), ('language_code', 'unknown')):
        chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode())
    chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\nContent-Type: audio/wav\r\n\r\n').encode())
    chunks.extend((data, b'\r\n', f'--{boundary}--\r\n'.encode()))
    return boundary, b''.join(chunks)


def request_one(data, filename, mode, key, opener=None):
    boundary, body = _multipart(data, filename, mode)
    request = urllib.request.Request(ENDPOINT, data=body, method='POST', headers={
        'api-subscription-key': key, 'Content-Type': f'multipart/form-data; boundary={boundary}',
        'Accept': 'application/json'})
    try:
        response = (opener or urllib.request.urlopen)(request, timeout=45)
        with response:
            raw = response.read(1_000_001)
            if len(raw) > 1_000_000:
                raise ValueError('ASR response exceeds local size bound')
            result = json.loads(raw)
    except urllib.error.HTTPError as exc:
        # Vendor error bodies may echo uploaded or prompt data; do not expose them.
        raise ValueError(f'ASR HTTP status {exc.code}') from None
    except urllib.error.URLError:
        raise ValueError('ASR transport failure') from None
    if not isinstance(result, dict) or not isinstance(result.get('transcript'), str):
        raise ValueError('ASR response lacks a string transcript')
    # Whitelist fields only. Vendor additions and echoed request content are discarded.
    request_id, language_code = result.get('request_id'), result.get('language_code')
    if request_id is not None and (not isinstance(request_id, str) or len(request_id) > 128 or not ID.fullmatch(request_id)):
        raise ValueError('ASR response has invalid request ID')
    if language_code is not None and (not isinstance(language_code, str) or len(language_code) > 20 or not ID.fullmatch(language_code)):
        raise ValueError('ASR response has invalid language code')
    return {'request_id': request_id, 'transcript': result['transcript'], 'language_code': language_code}


def _checkpoint(destination, observations, private, status):
    """Atomically replace private snapshots after each billable success or failure."""
    for filename, value in (('private_sanitized_responses.json', private),
                            ('observations.json', observations), ('status.json', status)):
        target = destination / filename
        temporary = destination / ('.' + filename + '.' + uuid.uuid4().hex)
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as file:
                json.dump(value, file, ensure_ascii=False, indent=2)
                file.write('\n')
                file.flush()
                os.fsync(file.fileno())
            os.replace(temporary, target)
        finally:
            if temporary.exists():
                temporary.unlink()
    directory_fd = os.open(destination, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def run(ids, mode, max_requests, output, live=False, opener=None, key=None):
    planned = preflight(ids, mode, max_requests)
    if not live:
        return {'status': 'preflight_passed', 'reference_ids': ids, 'requests': 0,
                'planned_requests': len(planned), 'model': MODEL, 'mode': mode,
                'rest_duration_cap_seconds': 30, 'certification': False}
    destination = Path(output)
    if destination.exists():
        raise ValueError('Output exists; use a new directory to preserve prior evidence')
    credential = key if key is not None else read_key()
    destination.mkdir(parents=True, mode=0o700)
    os.chmod(destination, 0o700)
    observations, private = [], []
    _checkpoint(destination, observations, private, {'status': 'in_progress',
                'completed_requests': 0, 'planned_requests': len(planned),
                'certification': False})
    for ref, audio, data, duration in planned:
        try:
            result = request_one(data, audio.name, mode, credential, opener=opener)
        except (ValueError, json.JSONDecodeError) as exc:
            _checkpoint(destination, observations, private, {'status': 'partial_failure',
                        'completed_requests': len(observations), 'planned_requests': len(planned),
                        'failed_reference_id': ref['reference_id'],
                        'error': str(exc), 'certification': False,
                        'resume_policy': 'no_automatic_retry_or_resume'})
            raise
        rid = ref['reference_id']
        observations.append({
            'observation_id': f'sarvam_saaras_v3_{mode}_{rid}', 'reference_id': rid,
            **{k: ref[k] for k in ('run_id', 'provider', 'model', 'language', 'audio_sha256')},
            'source': 'asr', 'transcriber_id': f'sarvam.saaras:v3.{mode}',
            'text': result['transcript']})
        private.append({'reference_id': rid, 'sanitized_response': result,
                        'mode': mode, 'audio_duration_seconds': duration})
        _checkpoint(destination, observations, private, {'status': 'in_progress',
                    'completed_requests': len(observations), 'planned_requests': len(planned),
                    'certification': False})
    _checkpoint(destination, observations, private, {'status': 'complete',
                'completed_requests': len(observations), 'planned_requests': len(planned),
                'certification': False})
    return {'status': 'transcript_observations_written', 'requests': len(observations),
            'observations_file': str((destination / 'observations.json').resolve()),
            'private_responses_file': str((destination / 'private_sanitized_responses.json').resolve()),
            'model': MODEL, 'mode': mode, 'certification': False,
            'limitation': 'ASR lexical diagnostics only; draft references are not native-reviewed.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--reference-id')
    choice.add_argument('--manifest', help='JSON object with reference_ids array (1-24)')
    parser.add_argument('--mode', choices=('verbatim', 'codemix'), default='verbatim')
    parser.add_argument('--max-requests', type=int, required=True)
    parser.add_argument('--output', default=str(ROOT / 'artifacts/sarvam-saaras-v3-asr-smoke'))
    parser.add_argument('--live', action='store_true', help='Explicitly send selected audio to Sarvam')
    args = parser.parse_args(argv)
    try:
        result = run(selected_ids(args.reference_id, args.manifest), args.mode,
                     args.max_requests, args.output, live=args.live)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as exc:
        # Fixed local error labels; no vendor body, credential, reference, or transcript.
        print(f'{type(exc).__name__}: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
