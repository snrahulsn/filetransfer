"""Convenience entrypoint: preparation only; lifecycle remains an explicit operator step."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tts_arena.worker_service import main
if __name__=='__main__':raise SystemExit(main(['prepare',*sys.argv[1:]]))
