"""One-pass Fish S2.1 missing-Indic-language audio delivery probe; no quality claim."""
import asyncio
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials, redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT = ROOT / 'artifacts/fish-indic-remaining-20260916'
RUNS = ROOT / 'artifacts/runs/fish-indic-remaining-20260916'
LOCALES = ('bn-IN', 'mr-IN', 'te-IN', 'gu-IN', 'ur-IN', 'kn-IN', 'ml-IN')
CONFIG = {'model': 's2.1-pro-free', 'voice': '9a9cf47702da476aa4629e2506d4a857',
          'language': 'auto', 'format': 'pcm', 'sample_rate': 24000}
SOURCE = 'https://fish.audio/blog/s2-1-pro-free-api/?articleLocale=en'


def fixtures():
    rows = [json.loads(line) for line in (ROOT / 'corpus/seed.jsonl').read_text().splitlines()]
    selected = {}
    for locale in LOCALES:
        matches = [row for row in rows if row['language'] == locale and row['category'] == 'amount_date']
        if len(matches) != 1 or matches[0]['native_review'] != 'pending':
            raise ValueError(f'Expected one unreviewed amount/date fixture for {locale}')
        selected[locale] = matches[0]
    return selected


async def main():
    if OUT.exists() or RUNS.exists():
        raise RuntimeError('Fish missing-Indic batch already prepared; no automatic repeat')
    if shutil.disk_usage(ROOT).free < 500 * 1024 * 1024:
        raise RuntimeError('Insufficient free storage for bounded audio evidence')
    secret = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    key = secret.get('FISH_API_KEY')
    if not key:
        raise RuntimeError('Authorized Fish key unavailable')
    rows = fixtures()
    for locale, row in rows.items():
        if len(row['text']) > 100:
            raise ValueError(f'Fixture too long: {locale}')
        build_request('fish', row['text'], CONFIG, {'FISH_API_KEY': key})
    OUT.mkdir(parents=True)
    RUNS.mkdir(parents=True)
    report = {'provider': 'fish', 'model': CONFIG['model'], 'voice': CONFIG['voice'],
              'created_at': datetime.now(timezone.utc).isoformat(), 'source': SOURCE,
              'source_accessed': '2026-09-16', 'max_requests': len(LOCALES),
              'automatic_retries': 0, 'request_language_mode': 'auto',
              'scope': 'Requested-locale playable output only; native language correctness, accent and commercial entitlement unverified.',
              'native_review': 'pending', 'records': []}

    def save():
        (OUT / 'summary.json').write_text(redact(json.dumps(report, ensure_ascii=False, indent=2), secret) + '\n')

    save()
    os.environ['FISH_API_KEY'] = key
    try:
        async with httpx.AsyncClient(timeout=35, trust_env=False, follow_redirects=False) as client:
            for index, locale in enumerate(LOCALES):
                if index:
                    await asyncio.sleep(3)
                row = rows[locale]
                attempt = {'locale': locale, 'fixture_id': row['id'], 'text': row['text'],
                           'config': CONFIG, 'status': 'request_started'}
                report['records'].append(attempt)
                save()
                result = await run_one('fish', row['text'], CONFIG, RUNS, timeout=35,
                                       client=client, scenario_id=row['id'],
                                       evaluation_language=locale,
                                       stratum='missing_indic_audio_bounded',
                                       min_free_bytes=300 * 1024 * 1024)
                attempt.update({k: result.get(k) for k in ('run_id', 'status', 'http_status',
                    'error_type', 'audio_bytes', 'audio_sha256', 'duration_seconds', 'first_audio_ms')})
                save()
                print(locale, result['status'], result.get('http_status'), flush=True)
                if result['status'] != 'success':
                    report['stopped_after_failure'] = locale
                    break
    finally:
        os.environ.pop('FISH_API_KEY', None)
    report['complete'] = True
    report['audio_successes'] = sum(r['status'] == 'success' for r in report['records'])
    save()


if __name__ == '__main__':
    asyncio.run(main())
