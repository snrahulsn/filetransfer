"""Retain one downloaded Studio clip per exact regional locale with source hashes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import wave

from tts_arena.one_audio_per_locale import assert_missing_audio


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'artifacts/voicemaker-studio-20260916'
REGIONAL = {'bn-IN', 'mr-IN', 'te-IN', 'ta-IN', 'gu-IN', 'kn-IN', 'ml-IN'}


def seed(locale: str) -> dict:
    for line in (ROOT / 'corpus/seed.jsonl').read_text().splitlines():
        row = json.loads(line)
        if row.get('language') == locale and row.get('stratum') == 'native_script':
            return row
    raise ValueError('No native-script seed for locale')


def ingest(download: Path, locale: str, *, root=ROOT, out=OUT) -> dict:
    if locale not in REGIONAL:
        raise ValueError('Only exact regional Studio selectors are eligible')
    download = Path(download).resolve()
    if (not download.is_file() or download.parent != Path('/Users/rahulnatarajan/Downloads')
        or not download.name.endswith('-voicemaker.in-speech.mp3')
        or not 1000 <= download.stat().st_size <= 2_000_000):
        raise ValueError('Downloaded Voicemaker Studio MP3 is not eligible')
    out.mkdir(parents=True, exist_ok=True)
    manifest_path = out / 'regional-manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {'schema_version': 1, 'clips': []}
    if any(row['locale'] == locale for row in manifest['clips']):
        raise ValueError('Regional Studio locale already retained')
    assert_missing_audio(root, 'voicemaker', locale)
    source = out / f'{locale}-proplus-ravi.mp3'
    decoded = out / f'{locale}-proplus-ravi-decoded.wav'
    if source.exists() or decoded.exists():
        raise ValueError('Regional Studio source already exists')
    shutil.copy2(download, source)
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(source),
                    '-ar', '48000', '-ac', '1', '-c:a', 'pcm_s16le', str(decoded)],
                   check=True, capture_output=True, timeout=20)
    with wave.open(str(decoded), 'rb') as wav:
        shape = (wav.getframerate(), wav.getnchannels(), wav.getsampwidth(), wav.getnframes())
    if shape[0:3] != (48000, 1, 2) or not 1 <= shape[3] / shape[0] <= 30:
        source.unlink(missing_ok=True)
        decoded.unlink(missing_ok=True)
        raise ValueError('Downloaded Studio audio is not bounded mono 48 kHz PCM')
    text = seed(locale)
    clip = {'locale': locale, 'text_id': text['id'], 'text': text['text'],
            'model': 'proplus', 'visible_subengine': 'Expressive',
            'voice': 'Ravi - Customer Care Styled (M) / Multilingual',
            'language_selector': locale, 'created_at': datetime.fromtimestamp(download.stat().st_mtime, timezone.utc).isoformat(),
            'source_mp3': source.name, 'source_mp3_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'source_mp3_bytes': source.stat().st_size, 'decoded_wav': decoded.name,
            'decoded_wav_sha256': hashlib.sha256(decoded.read_bytes()).hexdigest(),
            'decoded_sample_rate': shape[0], 'decoded_channels': shape[1],
            'decoded_sample_width_bytes': shape[2], 'decoded_frames': shape[3],
            'decoded_duration_seconds': shape[3] / shape[0],
            'boundary': 'Signed-in Voicemaker Studio one-conversion download; API route is billing-blocked.',
            'quality': 'Native language and Ravi voice accuracy not yet rated.'}
    manifest['clips'].append(clip)
    temporary = manifest_path.with_suffix('.partial')
    temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(manifest_path)
    return clip


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--download', type=Path, required=True)
    parser.add_argument('--locale', required=True)
    args = parser.parse_args()
    clip = ingest(args.download, args.locale)
    print(json.dumps({'locale': clip['locale'], 'wav_sha256': clip['decoded_wav_sha256'],
                      'duration_seconds': clip['decoded_duration_seconds']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
