"""Package every eligible plain-text saved clip for blinded Indic listening."""
import hashlib
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tts_arena.quality import prepare_study
from tts_arena.language_review import write_page

LOCALES = {'en-IN', 'hi-IN', 'bn-IN', 'mr-IN', 'te-IN', 'ta-IN', 'gu-IN', 'ur-IN', 'kn-IN', 'ml-IN'}
EXCLUDED = {'skipped_by_user', 'deferred_by_deployment_scope'}


def build():
    snapshot_path = ROOT / 'ui/public/evidence/snapshot.json'
    snapshot = json.loads(snapshot_path.read_text())
    active = {row['provider'] for row in snapshot['access_audit'] if row['access_state'] not in EXCLUDED}
    audio_root = (ROOT / 'ui/public/evidence/audio').resolve()
    items, seen = [], set()

    def add(provider, model, language, text, url, sha, source_id, stratum, config):
        if provider not in active or language not in LOCALES or not isinstance(text, str) or not text.strip():
            return
        if any(char in text for char in '<>[]'):
            return
        if not isinstance(model, str) or not model.strip():
            if provider != 'neuphonic':
                raise ValueError('Language-review exact model missing')
            model = 'implicit API model; not returned by vendor'
        if not isinstance(sha, str) or len(sha) != 64:
            raise ValueError('Language-review source hash missing')
        if not isinstance(url, str) or not url.startswith('/evidence/audio/') or not url.endswith('.wav'):
            raise ValueError('Language-review source must be a published WAV')
        path = (ROOT / 'ui/public' / url.lstrip('/')).resolve()
        if not path.is_relative_to(audio_root) or not path.is_file():
            raise ValueError('Language-review audio path unsafe or missing')
        if hashlib.sha256(path.read_bytes()).hexdigest() != sha:
            raise ValueError('Language-review source WAV hash mismatch')
        if source_id in seen:
            raise ValueError('Duplicate source identity in review package')
        seen.add(source_id)
        items.append({'id': source_id, 'audio_file': str(path), 'language': language, 'text': text,
                      'provider': provider, 'model': model, 'config': config, 'source_audio_sha256': sha,
                      'source_audio_url': url, 'source_record_id': source_id, 'sample_stratum': stratum,
                      'scope': 'blinded_language_review; draft text; qualification required'})

    for row in [*snapshot['runs'], *snapshot['local_runs']]:
        if row.get('audio_url'):
            add(row['provider'], row.get('config', {}).get('model'), row['language'], row.get('text'),
                row['audio_url'], row.get('listening_audio_sha256'), row['run_id'],
                row.get('stratum') or 'saved_synthesis', row.get('config', {}))
    for row in snapshot['maya_local_runs']:
        if row.get('audio_url'):
            source_id = 'maya:' + row['model'] + ':' + row['audio_sha256']
            add('maya', row['model'], row['language'], row['text'], row['audio_url'],
                row['audio_sha256'], source_id, 'local_batch', {'voice': row['voice'], 'sample_rate': row['sample_rate']})
    for row in snapshot.get('studio_audio_runs', []):
        if row.get('audio_url'):
            source_id = 'studio:' + row['provider'] + ':' + row['language'] + ':' + row['audio_sha256']
            add(row['provider'], row['model'], row['language'], row['text'], row['audio_url'],
                row['audio_sha256'], source_id, 'studio_browser', {'voice': row['voice'], 'route': row['route']})
    if not items:
        raise ValueError('No eligible saved language audio')
    cells = {(item['provider'], item['language']) for item in items}
    source_digest = hashlib.sha256('\n'.join(sorted(item['id'] + ':' + item['source_audio_sha256'] for item in items)).encode()).hexdigest()
    study_id = 'indic-language-' + source_digest[:12]
    public = ROOT / 'artifacts/listening' / study_id / 'public'
    if public.exists():
        raise ValueError('Identical review package exists; preserve anonymous mapping')
    systems = sorted({(item['provider'], item['model']) for item in items})
    random.Random(72617).shuffle(systems)
    codes = {system: 'System ' + str(index + 1).zfill(2) for index, system in enumerate(systems)}
    prepare_study(items, public, seed=72617)
    private = public.parent / 'public-private-key.json'
    mapping = json.loads(private.read_text())
    if len(mapping) != len(items):
        raise ValueError('Review private mapping lost source items')
    for token, item in mapping.items():
        copied = public / (token + '.wav')
        if hashlib.sha256(copied.read_bytes()).hexdigest() != item['source_audio_sha256']:
            raise ValueError('Blinded audio copy differs from verified source')
    outcome = write_page(public, {token: codes[(item['provider'], item['model'])] for token, item in mapping.items()},
                         {token: item['sample_stratum'] for token, item in mapping.items()}, study_id)
    if outcome['items'] != len(items):
        raise ValueError('Review page omitted items')
    status = {'schema': 'indic_language_review_package_v1', 'study_id': study_id,
              'source_snapshot_sha256': hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),
              'source_inventory_sha256': source_digest, 'items': len(items), 'vendor_locale_cells': len(cells),
              'anonymous_systems': len(systems), 'requested_locales': sorted({item['language'] for item in items}),
              'ratings_created': 0, 'native_reviewed_references': 0,
              'copied_wav_hashes_verified': len(items), 'public_directory': str(public),
              'private_mapping': str(private),
              'boundary': 'Plain-text saved audio; prompts/voices/settings differ. No qualified listener ratings or native-reviewed references are created.'}
    (public.parent / 'package-status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: status[k] for k in ('study_id', 'items', 'vendor_locale_cells',
                                           'anonymous_systems', 'copied_wav_hashes_verified')}, indent=2))
    return status


if __name__ == '__main__':
    build()
