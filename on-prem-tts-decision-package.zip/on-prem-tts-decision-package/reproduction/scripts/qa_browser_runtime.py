"""Read-only Chrome DevTools check for the local benchmark page."""

import asyncio
import json
import time
import urllib.request

import websockets


async def main() -> None:
    targets = json.load(urllib.request.urlopen("http://127.0.0.1:9223/json/list"))
    page = next(target for target in targets if target["type"] == "page")
    async with websockets.connect(page["webSocketDebuggerUrl"], max_size=10_000_000) as ws:
        for ident, method, params in [
            (1, "Page.enable", {}),
            (2, "Runtime.enable", {}),
            (3, "Log.enable", {}),
            (4, "Page.navigate", {"url": "http://127.0.0.1:3100/"}),
        ]:
            await ws.send(json.dumps({"id": ident, "method": method, "params": params}))
        deadline = time.monotonic() + 8
        exceptions = []
        while time.monotonic() < deadline:
            try:
                message = json.loads(await asyncio.wait_for(ws.recv(), timeout=1))
            except asyncio.TimeoutError:
                continue
            method = message.get("method")
            if method == "Runtime.exceptionThrown":
                details = message["params"]["exceptionDetails"]
                exceptions.append(details.get("text", ""))
                print("EXCEPTION", details.get("text"), details.get("exception", {}).get("description", "")[:1200])
            elif method == "Runtime.consoleAPICalled" and message["params"]["type"] in ("error", "warning"):
                print("CONSOLE", message["params"]["type"], [arg.get("value", arg.get("description", "")[:1200]) for arg in message["params"]["args"]])
        expression = "({title:document.title,root:document.querySelector('#root')?.textContent?.slice(0,150),rows:document.querySelectorAll('table tr').length,mayaVeena:document.body.innerText.includes('maya-research/Veena'),qwenInstruct:document.body.innerText.includes('qwen3-tts-instruct-flash-2026-01-26')})"
        await ws.send(json.dumps({"id": 5, "method": "Runtime.evaluate", "params": {"expression": expression, "returnByValue": True}}))
        while True:
            message = json.loads(await ws.recv())
            if message.get("id") == 5:
                values = message["result"]["result"]["value"]
                print(json.dumps(values, ensure_ascii=False))
                assert not exceptions, f"Browser exceptions: {exceptions}"
                assert values["rows"] >= 100 and values["root"].startswith("Skip to comparison"), "Comparison page did not render"
                assert values["mayaVeena"] and values["qwenInstruct"], "Exact model rows are missing"
                break


if __name__ == "__main__":
    asyncio.run(main())
