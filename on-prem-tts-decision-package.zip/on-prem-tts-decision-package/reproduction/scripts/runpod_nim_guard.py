"""Detached hard-stop cleanup for a Magpie NIM Pod and its temporary NGC registry auth."""
import argparse
import json
import time
import urllib.error
import urllib.request
from pathlib import Path

from tts_arena.credentials import read_credentials


def delete_resource(kind: str, resource_id: str, key: str) -> int:
    if kind not in {'pods', 'containerregistryauth'} or not resource_id:
        raise ValueError('Invalid disposable Runpod resource')
    request = urllib.request.Request(
        f'https://rest.runpod.io/v1/{kind}/{resource_id}', method='DELETE',
        headers={'Authorization': f'Bearer {key}', 'Accept': 'application/json',
                 'User-Agent': 'Mozilla/5.0 Chrome/124.0.0.0 Safari/537.36'},
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return response.status
    except urllib.error.HTTPError as error:
        return error.code


def cleanup(pod_id: str, registry_auth_id: str, key: str, delete=delete_resource) -> dict:
    results = {}
    for kind, resource_id in (('pods', pod_id), ('containerregistryauth', registry_auth_id)):
        attempts = []
        for retry in range(5):
            try:
                status = delete(kind, resource_id, key)
            except Exception:
                status = None
            attempts.append(status)
            if status in (204, 404):
                break
            time.sleep(2 * (retry + 1))
        results[kind] = {'resource_id': resource_id, 'statuses': attempts,
                         'deleted': attempts[-1] in (204, 404)}
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pod-id', required=True)
    parser.add_argument('--registry-auth-id', required=True)
    parser.add_argument('--credentials-path', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=3600)
    parser.add_argument('--log', type=Path, required=True)
    args = parser.parse_args()
    if not 300 <= args.seconds <= 3600:
        raise ValueError('Guard interval must be 5–60 minutes')
    credentials = read_credentials(args.credentials_path)
    key = credentials.get('RunPod') or credentials.get('RUNPOD_API_KEY')
    if not key:
        raise ValueError('Runpod key not available for cleanup')
    deadline = time.monotonic() + args.seconds
    while time.monotonic() < deadline:
        time.sleep(min(20, deadline - time.monotonic()))
    result = cleanup(args.pod_id, args.registry_auth_id, key)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.log.write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
