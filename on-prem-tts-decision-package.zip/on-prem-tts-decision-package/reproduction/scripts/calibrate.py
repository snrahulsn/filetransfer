"""Create inspectable local WebSocket evidence for a stopping and a never-stopping bot."""
import asyncio
import base64
import json
from pathlib import Path
import sys
from websockets.asyncio.server import serve

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from tts_arena.audio import TimelineRecorder,pcm_from_samples
from tts_arena.replay import replay


async def trial(root,mode):
    async def bot(ws):
        await ws.recv()
        stop=asyncio.Event()
        async def send():
            while not stop.is_set():
                await ws.send(json.dumps({"type":"audio","response_id":"calibration-response","audio":base64.b64encode(pcm_from_samples([1000]*160)).decode()}))
                await asyncio.sleep(.02)
        task=asyncio.create_task(send())
        try:
            async for raw in ws:
                if mode=="correct_stop" and json.loads(raw)["type"]=="caller_audio" and not stop.is_set():
                    stop.set()
                    await ws.send('{"type":"clear","response_id":"calibration-response"}')
                    await ws.send('{"type":"response_end","response_id":"calibration-response"}')
        finally:
            task.cancel();await asyncio.gather(task,return_exceptions=True)
    async with serve(bot,"127.0.0.1",0) as host:
        endpoint=f"ws://127.0.0.1:{host.sockets[0].getsockname()[1]}"
        return await replay(endpoint,root/"tone-fixture.wav",root/mode,onset_offset_ms=120,observation_seconds=.8,stop_threshold_ms=200,allow_local=True)


async def main():
    root=ROOT/"artifacts/calibration"
    root.mkdir(parents=True,exist_ok=False)
    audio=TimelineRecorder(8000);audio.write_at(0,pcm_from_samples([2000]*800))
    (root/"tone-fixture.wav").write_bytes(audio.wav())
    results={mode:await trial(root,mode) for mode in ("correct_stop","never_stops")}
    bad=results["never_stops"]["metrics"]
    assert bad["right_censored"] and bad["stop_latency_ms"] is None and bad["missed_interruption"],bad
    summary={"evidence_class":"local_synthetic_tone_calibration_not_vendor_or_native_speech", "results":{k:v["metrics"] for k,v in results.items()}}
    (root/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary,indent=2))

asyncio.run(main())
