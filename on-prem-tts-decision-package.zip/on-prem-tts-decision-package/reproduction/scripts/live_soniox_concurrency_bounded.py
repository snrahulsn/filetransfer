"""One no-retry two-stream Soniox concurrency probe on a single WebSocket."""
import asyncio
import base64
import hashlib
import json
import shutil
import sys
import time
from datetime import datetime,timezone
from pathlib import Path
from uuid import uuid4

import websockets

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from scripts.live_soniox_multiplex_bounded import pcm_wav

OUT=ROOT/"artifacts/soniox-concurrency-20260915"
TEXTS=("आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।",
       "नमस्ते, मैं आपकी मदद कर सकता हूँ। कृपया अपना प्रश्न बताइए।")

async def main():
    if OUT.exists():raise RuntimeError("Probe already attempted; refusing repeated spend")
    if sum(map(len,TEXTS))>150 or shutil.disk_usage(ROOT).free<300*1024*1024:
        raise ValueError("Bounded text or disk preflight failed")
    key=read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env").get("SONIOX_API_KEY")
    if not key:raise RuntimeError("Authorized Soniox key absent")
    OUT.mkdir(parents=True)
    report={"schema_version":1,"provider":"soniox","model":"tts-rt-v2","voice":"Kavya",
            "created_at":datetime.now(timezone.utc).isoformat(),
            "documentation":"https://soniox.com/docs/api-reference/tts/websocket-api",
            "requests_limit":2,"automatic_retries":0,"connection_count":1,
            "boundary":"two_native_websocket_streams_not_account_capacity",
            "production_telephony_verified":False,"streams":[],"status":"started"}
    save=lambda:(OUT/"result.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    save()
    origin=time.perf_counter()
    elapsed=lambda:round((time.perf_counter()-origin)*1000,2)
    ids=["arena-concurrent-"+uuid4().hex for _ in TEXTS]
    rows={sid:{"stream_id":sid,"text":text,"language":"hi-IN","wire_language":"hi",
               "audio_format":"pcm_s16le","sample_rate":24000,"status":"started",
               "config_sent_ms":None,"text_sent_ms":None,"first_audio_ms":None,
               "audio_end_observed":False,"terminated_observed":False,"audio_chunks":0,
               "audio_bytes":0,"error_types":[]}
          for sid,text in zip(ids,TEXTS)}
    report["streams"]=list(rows.values());save()
    chunks={sid:[] for sid in ids}
    try:
        async with websockets.connect("wss://tts-rt.soniox.com/tts-websocket",
                                      open_timeout=10,close_timeout=5,max_size=2*1024*1024) as ws:
            for sid in ids:
                await ws.send(json.dumps({"api_key":key,"model":"tts-rt-v2","language":"hi",
                                          "voice":"Kavya","audio_format":"pcm_s16le",
                                          "sample_rate":24000,"stream_id":sid}))
                rows[sid]["config_sent_ms"]=elapsed()
                await ws.send(json.dumps({"text":rows[sid]["text"],"text_end":True,"stream_id":sid}))
                rows[sid]["text_sent_ms"]=elapsed()
            report["both_streams_submitted_ms"]=elapsed();save()
            deadline=time.perf_counter()+25
            while not all(r["terminated_observed"] for r in rows.values()) and time.perf_counter()<deadline:
                frame=json.loads(await asyncio.wait_for(ws.recv(),max(0.1,deadline-time.perf_counter())))
                sid=frame.get("stream_id")
                if sid not in rows:raise ValueError("Unrecognized stream ID")
                row=rows[sid]
                if frame.get("error_type"):
                    row["error_types"].append({"type":frame["error_type"],"code":frame.get("error_code")})
                if frame.get("audio"):
                    audio=base64.b64decode(frame["audio"],validate=True)
                    if len(audio)%2:raise ValueError("Invalid PCM16 payload")
                    chunks[sid].append(audio)
                    row["audio_chunks"]+=1;row["audio_bytes"]+=len(audio)
                    if row["first_audio_ms"] is None:
                        row["first_audio_ms"]=elapsed()
                        row["other_stream_active_at_first_audio"]=not rows[next(x for x in ids if x!=sid)]["terminated_observed"]
                if frame.get("audio_end") is True:row["audio_end_observed"]=True
                if frame.get("terminated") is True:row["terminated_observed"]=True
            for index,sid in enumerate(ids,1):
                row=rows[sid];raw=b"".join(chunks[sid])
                if raw:
                    filename=f"stream-{index}.wav"
                    wav=pcm_wav(raw)
                    (OUT/filename).write_bytes(wav)
                    row["audio_file"]=filename;row["audio_sha256"]=hashlib.sha256(wav).hexdigest()
                    row["duration_seconds"]=len(raw)/48000
                row["status"]="success" if raw and row["audio_end_observed"] and row["terminated_observed"] and not row["error_types"] else "incomplete"
            report["status"]="complete" if all(r["status"]=="success" for r in rows.values()) else "incomplete"
    except Exception as exc:
        report["status"]="failed";report["error_type"]=type(exc).__name__
    save()
    print(json.dumps({"status":report["status"],"streams":[{k:r.get(k) for k in
          ("status","audio_chunks","audio_bytes","other_stream_active_at_first_audio",
           "audio_end_observed","terminated_observed","error_types")} for r in report["streams"]]}))

if __name__=="__main__":asyncio.run(main())
