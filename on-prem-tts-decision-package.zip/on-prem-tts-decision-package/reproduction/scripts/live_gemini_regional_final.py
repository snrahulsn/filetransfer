"""Two explicit recovery calls after actual observed Gemini rate-window pause."""
import asyncio,json
from datetime import datetime,timezone,timedelta
import live_regional_global as batch

async def main():
    rows,_=batch.load_live_runs(batch.ROOT/'artifacts')
    prior=[r for r in rows if r.get('provider')=='google']
    last=max(prior,key=lambda r:r['created_at'])
    finished=datetime.fromisoformat(last['created_at'])+timedelta(milliseconds=last.get('elapsed_ms',0))
    waited=max(0,(datetime.now(timezone.utc)-finished).total_seconds())
    if waited<60:await asyncio.sleep(60-waited)
    corpus=[json.loads(line) for line in (batch.ROOT/'corpus/seed.jsonl').read_text().splitlines()]
    urdu=next(item['text'] for item in corpus if item['id']=='ur-IN-amount_date-001')
    batch.TEXT={'mr-IN':batch.TEXT['mr-IN'],'ur-IN':urdu};batch.NAMES['ur-IN']='Urdu'
    batch.PROVIDERS={'google':batch.PROVIDERS['google']}
    batch.OUT=batch.ROOT/'artifacts/gemini-regional-final-20260915'
    batch.REPORT=batch.ROOT/'docs/GEMINI_REGIONAL_FINAL_STATUS.md'
    batch.REQUEST_LIMIT=2;batch.PER_PROVIDER_LIMIT=2;batch.TIMEOUT=60;batch.INTER_REQUEST_SECONDS=60
    batch.EXPLICIT_RECOVERY={'google':{
        'mr-IN':'One explicit recovery of prior30s transport timeout, now60s timeout, after provider pause; old evidence preserved.',
        'ur-IN':'One explicit recovery after recorded429 rate-window retryDelay55s; at least60s from previous completed Gemini request; old evidence preserved.'}}
    await batch.main()
    path=batch.OUT/'coverage.json';d=json.loads(path.read_text());d['preceding_google_run_id']=last['run_id'];d['seconds_since_preceding_google_completion_at_start']=waited
    d['reference_text_source']='Existing Marathi TEXT and corpus/seed.jsonl ur-IN-amount_date-001; native review pending'
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)

if __name__=='__main__':asyncio.run(main())
