"""Single read-only discovery; refuses repeat. No synthesis on failed discovery."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=ROOT/'artifacts/access-20260915/neuphonic-discovery.json'
 if p.exists():raise SystemExit('Discovery evidence already exists; no automatic auth retry')
 c=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 r=httpx.get('https://api.neuphonic.com/voices',headers={'X-API-KEY':c['NEUPHONIC_API_KEY']},timeout=30,trust_env=False)
 j=r.json();v=j.get('data',{}).get('voices',[])
 safe=[{k:x.get(k) for k in ('id','voice_id','name','lang_code','language','tags','model','model_name')} for x in v]
 out={'url':str(r.url),'accessed':'2026-09-15','http_status':r.status_code,'voices':safe,'diagnostic':redact(r.text,c)[:500] if r.status_code!=200 else None}
 p.write_text(json.dumps(out,ensure_ascii=False,indent=2));print('Discovery HTTP',r.status_code)
if __name__=='__main__':main()
