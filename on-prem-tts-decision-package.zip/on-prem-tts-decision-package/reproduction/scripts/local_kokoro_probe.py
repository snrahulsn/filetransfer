"""Bounded offline Kokoro smoke probes; no provider keys or network required."""
import argparse
import asyncio
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from tts_arena.runner import run_one
p=argparse.ArgumentParser();p.add_argument('language',choices=['hi-IN','en-US']);p.add_argument('--hinglish',action='store_true');a=p.parse_args()
config=json.loads((ROOT/'artifacts/local-20260915/kokoro'/f'{a.language}.json').read_text())
text='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।' if a.language=='hi-IN' else 'Hello, your meeting is tomorrow at three in the afternoon. Please confirm the time.'
if a.hinglish:text='नमस्ते, आपकी meeting कल दोपहर three बजे है। Please confirm the time.'
r=asyncio.run(run_one('kokoro',text,config,ROOT/'artifacts/local-20260915/kokoro/runs',evaluation_language=a.language,stratum='hinglish_mixed_script' if a.hinglish else 'local_smoke'))
print(json.dumps({k:r.get(k) for k in ['run_id','evidence_class','status','error_type','duration_seconds','first_audio_ms','elapsed_ms','audio_analysis','local_runtime']},ensure_ascii=False,indent=2))
raise SystemExit(0 if r['status']=='success' else 1)
