"""Nine no-retry Saaras v3 codemix observations on one matched Hindi-English TTS text."""
import argparse
import hashlib
import json
import os
import sys
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.sarvam_saaras_v3_asr import _checkpoint, read_key, request_one
from tts_arena.transcript_quality import evaluate_transcripts

OUT = ROOT / 'artifacts/indic-codemix-matched-20260916'
REFERENCES = ROOT / 'artifacts/transcript-references-20260915/references.json'
SNAPSHOT = ROOT / 'ui/public/evidence/snapshot.json'
TEXT = 'नमस्ते, आपकी meeting कल दोपहर three बजे है। Please confirm the time.'
PROVIDERS = ('cartesia', 'elevenlabs', 'google', 'hume', 'inworld', 'minimax',
             'murf', 'rime', 'smallest')


def preflight():
    refs_raw = REFERENCES.read_bytes()
    refs = json.loads(refs_raw)
    snapshot = json.loads(SNAPSHOT.read_text())
    runs = {r['run_id']: r for r in snapshot['runs']}
    selected = [r for r in refs if r['language'] == 'hi-IN' and r['text'] == TEXT and
                r['provider'] in PROVIDERS]
    if len(selected) != len(PROVIDERS) or {r['provider'] for r in selected} != set(PROVIDERS):
        raise ValueError('Matched code-switching reference set changed')
    prior = set()
    for name in ('indic-asr-smoke-20260915', 'indic-asr-verbatim-20260915'):
        prior |= {o['reference_id'] for o in json.loads((ROOT / 'artifacts' / name / 'observations.json').read_text())}
    if any(r['reference_id'] in prior for r in selected):
        raise ValueError('Matched code-switching reference was already submitted to Saaras')
    planned = []
    canonical_refs = []
    for ref in sorted(selected, key=lambda r: PROVIDERS.index(r['provider'])):
        run = runs.get(ref['run_id'])
        if not run or run['status'] != 'success' or run['provider'] != ref['provider'] or (
            run['language'], run['config'].get('model'), run['text']) != (
            'hi-IN', ref['model'], TEXT):
            raise ValueError('Matched run/model/text identity changed')
        url = run.get('audio_url')
        if not url or not url.startswith('/evidence/audio/') or not url.endswith('.wav'):
            raise ValueError('Matched canonical audio URL missing')
        file = (ROOT / 'ui/public' / url.lstrip('/')).resolve()
        if not file.is_relative_to(ROOT / 'ui/public/evidence/audio'):
            raise ValueError('Matched canonical audio escaped public evidence')
        raw = file.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if sha != run['listening_audio_sha256'] or len(raw) > 2_000_000:
            raise ValueError('Matched canonical audio hash/size changed')
        with wave.open(str(file), 'rb') as media:
            duration = media.getnframes() / media.getframerate()
            if media.getnchannels() != 1 or media.getsampwidth() != 2 or not 0 < duration <= 12:
                raise ValueError('Matched canonical WAV is not bounded mono PCM16')
        if abs(duration - run['duration_seconds']) > .05:
            raise ValueError('Matched WAV duration differs from saved run')
        canonical = dict(ref, audio_sha256=sha, native_reviewed=False)
        canonical_refs.append(canonical)
        planned.append((canonical, file, raw, duration))
    seconds = sum(item[3] for item in planned)
    if len(planned) != 9 or seconds > 55:
        raise ValueError('Matched Saaras request/duration cap exceeded')
    plan = {'schema': 'indic_matched_codemix_asr_v1', 'asr_model': 'saaras:v3',
            'asr_mode': 'codemix', 'language_code': 'unknown', 'requests_limit': 9,
            'audio_seconds_limit': 55, 'planned_audio_seconds': round(seconds, 3),
            'text_sha256': hashlib.sha256(TEXT.encode()).hexdigest(),
            'source_references_sha256': hashlib.sha256(refs_raw).hexdigest(),
            'snapshot_code_sha256': snapshot['code_sha256'], 'retries': 0,
            'items': [{'reference_id': ref['reference_id'], 'provider': ref['provider'],
                       'model': ref['model'], 'audio_sha256': ref['audio_sha256'],
                       'audio_url': '/evidence/audio/' + file.name,
                       'duration_seconds': round(duration, 3)}
                      for ref, file, _, duration in planned]}
    return plan, canonical_refs, planned


def live_run():
    plan, refs, planned = preflight()
    if OUT.exists():
        raise RuntimeError('Matched code-switching ASR already attempted; no repeat')
    key = read_key()
    OUT.mkdir(parents=True, mode=0o700)
    os.chmod(OUT, 0o700)
    (OUT / 'attempt.started').write_text('Nine matched audio requests maximum; no retries.\n')
    (OUT / 'plan.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'canonical_references.json').write_text(json.dumps(refs, ensure_ascii=False, indent=2) + '\n')
    observations, private = [], []
    _checkpoint(OUT, observations, private, {'status': 'in_progress', 'completed_requests': 0,
                                             'planned_requests': 9, 'certification': False})
    for ref, file, raw, duration in planned:
        try:
            response = request_one(raw, file.name, 'codemix', key)
        except Exception as exc:
            _checkpoint(OUT, observations, private, {'status': 'partial_failure',
                'completed_requests': len(observations), 'planned_requests': 9,
                'failed_provider': ref['provider'], 'error_type': type(exc).__name__,
                'certification': False, 'resume_policy': 'no_automatic_retry'})
            raise
        observations.append({'observation_id': 'saaras_v3_codemix_matched_' + ref['reference_id'],
                             'reference_id': ref['reference_id'],
                             **{k: ref[k] for k in ('run_id', 'provider', 'model', 'language', 'audio_sha256')},
                             'source': 'asr', 'transcriber_id': 'sarvam.saaras:v3.codemix',
                             'text': response['transcript']})
        private.append({'reference_id': ref['reference_id'], 'sanitized_response': response,
                        'audio_duration_seconds': duration})
        _checkpoint(OUT, observations, private, {'status': 'in_progress',
            'completed_requests': len(observations), 'planned_requests': 9,
            'certification': False})
    _checkpoint(OUT, observations, private, {'status': 'complete', 'completed_requests': 9,
                                             'planned_requests': 9, 'certification': False})
    scores = evaluate_transcripts(observations, refs, {})
    if scores['rejected'] or len(scores['observations']) != 9:
        raise ValueError('Matched ASR observations failed scoring identity check')
    detected = {row['reference_id']: row['sanitized_response']['language_code'] for row in private}
    summary = {'schema': 'indic_matched_codemix_asr_summary_v1',
               'engine': 'sarvam.saaras:v3.codemix', 'status': 'complete',
               'planned_requests': 9, 'completed_requests': 9,
               'plan_sha256': hashlib.sha256((OUT / 'plan.json').read_bytes()).hexdigest(),
               'native_reviewed_references': 0, 'human_ratings': 0,
               'results': [{'provider': score['provider'], 'model': score['model'],
                            'language': score['language'], 'reference_id': score['reference_id'],
                            'audio_sha256': score['audio_sha256'],
                            'detected_language': detected[score['reference_id']],
                            'wer_raw': score['wer']['rate'], 'cer_raw': score['cer']['rate'],
                            'word_edit_distance': score['wer']['distance'],
                            'draft_word_units': score['wer']['reference_units']}
                           for score in scores['observations']],
               'boundary': 'One matched code-switched synthesis input; ASR lexical diagnostics against unreviewed draft text, not native quality or language certification'}
    (OUT / 'result-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return {'status': 'complete', 'completed_requests': 9,
            'detected_languages': {r['provider']: r['detected_language'] for r in summary['results']}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    result = live_run() if args.live else {'status': 'preflight_passed', 'plan': preflight()[0]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
