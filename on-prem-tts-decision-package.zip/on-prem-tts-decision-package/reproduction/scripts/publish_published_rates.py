"""Publish a complete, sanitized official-rate grid for working hosted routes."""
import json
import math
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'artifacts/pricing-current-20260916/rates.json'
REFERENCE = ROOT / 'ui/public/evidence/working-api-reference.json'
DEST = ROOT / 'ui/public/evidence/published-rates.json'
ADDITIONAL_ACTIVE = {'amazon','kokoro','maya','openai','playht','qwen','resemble','reverie','voicemaker'}


def publish() -> dict:
    data = json.loads(SOURCE.read_text())
    working = {route['provider']: route for route in json.loads(REFERENCE.read_text())['routes']}
    if data.get('schema_version') != 1 or not isinstance(data.get('rates'), list):
        raise ValueError('Unsupported published-rate schema')
    rows = data['rates']
    expected = set(working) | ADDITIONAL_ACTIVE
    if len(rows) != len(expected) or {row.get('provider') for row in rows} != expected:
        raise ValueError('Published-rate rows must exactly cover the 19 working routes and nine active non-working vendors')
    catalogs = {provider: json.loads((ROOT / 'catalog' / f'{provider}.json').read_text()) for provider in ADDITIONAL_ACTIVE}
    for row in rows:
        provider = row['provider']
        if not isinstance(row.get('model_scope'), str) or not row['model_scope'].strip():
            raise ValueError('Exact working model scope missing: ' + provider)
        expected_models = working[provider]['working_models'] if provider in working else catalogs[provider]['models']
        if not any(model in row['model_scope'] for model in expected_models):
            raise ValueError('Pricing model does not match catalog/working route: ' + provider)
        if row.get('pricing_url'):
            url = urlparse(row['pricing_url'])
            if url.scheme != 'https' or not url.hostname:
                raise ValueError('Pricing evidence must use an HTTPS vendor page: ' + provider)
        elif row.get('published_rate') is not None:
            raise ValueError('Published rate lacks direct source URL: ' + provider)
        if row.get('confidence') not in {'high', 'medium', 'low'}:
            raise ValueError('Rate source confidence invalid: ' + provider)
        for field in ('normalized_per_1k_chars', 'normalized_per_generated_minute'):
            value = row.get(field)
            if value is not None and (type(value) not in (int,float) or not math.isfinite(value) or value < 0):
                raise ValueError('Invalid normalized rate: ' + provider + '/' + field)
        if row.get('published_rate') is None and any(row.get(field) is not None for field in ('normalized_per_1k_chars', 'normalized_per_generated_minute')):
            raise ValueError('Normalized rate without applicable published price: ' + provider)
    DEST.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    return {'providers':len(rows), 'applicable_public_rates':sum(r.get('published_rate') is not None for r in rows),
            'no_applicable_public_rate':sum(r.get('published_rate') is None for r in rows)}


if __name__ == '__main__':
    print(json.dumps(publish()))
