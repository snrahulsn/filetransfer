"""One guarded Hindi Meher Pro WebSocket request; retain original response frames."""
import asyncio,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from websockets.asyncio.client import connect
from tts_arena.credentials import read_credentials,redact
from tts_arena.session_runner import run_session
from tts_arena.sessions import smallest
CONFIG=dict(model='lightning_v3.1_pro',voice='meher',language='hi-IN',format='pcm',sample_rate=44100,word_timestamps=True)
async def main():
 root=Path(__file__).resolve().parents[1];folder=root/'artifacts/sessions-access-20260915';guard=folder/'smallest.started';target=folder/'smallest.json'
 if guard.exists() or target.exists():raise RuntimeError('Already attempted; no retries')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');env={'SMALLEST_API_KEY':secrets['SMALLEST_API_KEY']};actions=[dict(type='text',at_ms=0,text='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है।')]
 smallest.build_session(CONFIG,env);smallest.encode_action(actions[0],CONFIG)
 guard.write_text('One timestamp request authorized; no retries.\n');frames=[]
 rawlog=folder/'smallest-raw-frames.jsonl'
 class Socket:
  def __init__(self,ws):self.ws=ws
  async def send(self,data):return await self.ws.send(data)
  def __aiter__(self):return self
  async def __anext__(self):
   raw=await self.ws.__aiter__().__anext__();safe=redact(raw,secrets) if isinstance(raw,str) else '<unexpected binary frame>';frames.append(safe)
   with rawlog.open('a') as stream:stream.write(json.dumps(safe,ensure_ascii=False)+'\n');stream.flush()
   return raw
 class Capture:
  def __init__(self,*a,**kw):self.cm=connect(*a,**kw)
  async def __aenter__(self):return Socket(await self.cm.__aenter__())
  async def __aexit__(self,*args):return await self.cm.__aexit__(*args)
 report=await run_session('smallest',CONFIG,actions,folder/'smallest',seconds=30,connector=Capture,env=env)
 rawfile=folder/'smallest-raw-frames.json';rawfile.write_text(json.dumps(frames,ensure_ascii=False,indent=2)+'\n');report['raw_frames_file']=str(rawfile);marks=[]
 for frame in frames:
  try:
   obj=json.loads(frame)
   if obj.get('status')=='word_timestamp':marks.append(obj['data'])
  except (ValueError,TypeError,KeyError):pass
 report['word_marks']=marks;report['evaluation_language']='hi-IN';report['alignment_accuracy']='unverified';report['word_count']=len(marks);report['timestamp_presence']='observed' if marks else 'not_observed';target.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n');print(json.dumps({'status':report['status'],'error_type':report['error_type'],'word_count':len(marks),'frames':len(frames)}))
if __name__=='__main__':asyncio.run(main())
