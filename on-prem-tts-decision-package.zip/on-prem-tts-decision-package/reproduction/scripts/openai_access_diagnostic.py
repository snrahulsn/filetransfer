"""One authorized request distinguishes quota exhaustion from transient rate limits."""
import asyncio,json,os
from pathlib import Path
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
async def main():
    root=Path(__file__).resolve().parents[1];summary_path=root/'artifacts/access-20260915/openai.json'
    summary=json.loads(summary_path.read_text())
    if any(r.get('diagnostic')=='429_classification' for r in summary['runs']):raise RuntimeError('Diagnostic already executed; no retry')
    if len(summary['runs'])>=6:raise RuntimeError('Request limit reached')
    credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    os.environ['OPENAI_API_KEY']=credentials['OPENAI_API_KEY']
    diagnostics=[]
    async def hook(response):
        if response.status_code>=400:
            data=(await response.aread())[:4096].decode('utf8','replace')
            item={'http_status':response.status_code,'message':redact(data,credentials),'request_id':response.headers.get('x-request-id')}
            try:
                error=json.loads(data).get('error',{})
                item['error_code']=error.get('code');item['error_type']=error.get('type')
            except (ValueError,AttributeError):pass
            diagnostics.append(item)
    config={'model':'gpt-4o-mini-tts','voice':'coral','language':'hi-IN','format':'pcm'}
    async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
        r=await run_one('openai','नमस्ते, मैं आपकी क्या मदद कर सकती हूँ?',config,root/'artifacts/runs/access-20260915/openai',timeout=30,scenario_id='quota-diagnostic-hi',client=client,stratum='smoke_only')
    item={k:r.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','language')}
    item.update(diagnostic='429_classification',config=config,diagnostics=diagnostics)
    summary['runs'].append(item)
    codes={d.get('error_code') for d in diagnostics}
    summary['access_diagnosis']='credit_balance_exhausted' if 'credit_balance_exhausted' in codes else ('insufficient_quota' if 'insufficient_quota' in codes else 'see_diagnostic')
    summary['automatic_retries']=0
    summary_path.write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),credentials)+'\n')
    print(json.dumps({'provider':'openai','status':r['status'],'http_status':r.get('http_status'),'diagnosis':summary['access_diagnosis']}))
if __name__=='__main__':asyncio.run(main())
