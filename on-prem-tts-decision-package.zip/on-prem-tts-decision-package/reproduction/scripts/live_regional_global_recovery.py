"""Explicitly authorized post-storage-pause batch; no automatic retries."""
import asyncio,json
import live_regional_global as batch

async def main():
    first=json.loads((batch.OUT/'coverage.json').read_text())
    if not first.get('completed'):raise RuntimeError('Previous bounded batch must complete first')
    corpus=[json.loads(line) for line in (batch.ROOT/'corpus/seed.jsonl').read_text().splitlines()]
    urdu=next(item for item in corpus if item['id']=='ur-IN-amount_date-001')
    batch.TEXT={**batch.TEXT,'ur-IN':urdu['text']};batch.NAMES['ur-IN']='Urdu'
    batch.OUT=batch.ROOT/'artifacts/regional-global-recovery-20260915'
    batch.REPORT=batch.ROOT/'docs/REGIONAL_GLOBAL_RECOVERY_STATUS.md'
    batch.REQUEST_LIMIT=14;batch.PER_PROVIDER_LIMIT=8;batch.TIMEOUT=60
    batch.EXPLICIT_RECOVERY={'elevenlabs':{'bn-IN':'Root authorized one storage-recovery resynthesis after original HTTP200 audio failed to persist during disk exhaustion. Original OSError record retained.'}}
    await batch.main()
    path=batch.OUT/'coverage.json';result=json.loads(path.read_text())
    result['reference_text_source']='scripts/live_regional_india.py existing regional TEXT; Urdu corpus/seed.jsonl ur-IN-amount_date-001 (native review pending)'
    result['previous_batch']='artifacts/regional-global-20260915/coverage.json'
    temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');temporary.replace(path)
    text=batch.REPORT.read_text().replace('Urdu on both providers and Eleven Malayalam remain outside this batch, not unsupported.','Remaining documented locales were selected; original Gemini Marathi timeout is not retried. One Eleven Bengali recovery request is explicitly authorized after storage repair; this is not an automatic retry.')
    text=text.replace('../artifacts/regional-global-20260915/coverage.json','../artifacts/regional-global-recovery-20260915/coverage.json').replace('No duplicate locale requests were sent.','One explicit Eleven Bengali storage-recovery resynthesis was authorized.')
    batch.REPORT.write_text(text)

if __name__=='__main__':asyncio.run(main())
