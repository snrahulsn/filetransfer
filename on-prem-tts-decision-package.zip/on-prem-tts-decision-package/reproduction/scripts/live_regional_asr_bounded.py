"""No-retry Saaras v3 diagnostic pass over sixteen previously untested saved TTS cells."""
import argparse
import hashlib
import json
import os
import sys
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.sarvam_saaras_v3_asr import _checkpoint, read_key, request_one
from tts_arena.transcript_quality import evaluate_transcripts

OUT = ROOT / 'artifacts/indic-regional-asr-20260916'
REFERENCES = ROOT / 'artifacts/transcript-references-20260915/references.json'
SNAPSHOT = ROOT / 'ui/public/evidence/snapshot.json'
PAIRS = [("smallest", lang) for lang in ('bn-IN', 'mr-IN', 'te-IN', 'gu-IN', 'kn-IN', 'ml-IN')]
PAIRS += [(provider, 'ta-IN') for provider in ('gnani', 'fonada', 'fish', 'inworld', 'minimax', 'murf')]
PAIRS += [('camb', 'hi-IN'), ('dubverse', 'hi-IN'), ('hume', 'hi-IN'), ('speechify', 'en-IN')]
PINNED_PREFIX = {('camb', 'hi-IN'): '20bdeab8', ('hume', 'hi-IN'): 'd4f17632',
                 ('speechify', 'en-IN'): '0d4f2527'}


def preflight():
    refs_raw = REFERENCES.read_bytes()
    refs = json.loads(refs_raw)
    snapshot = json.loads(SNAPSHOT.read_text())
    runs = {run['run_id']: run for run in snapshot['runs']}
    prior = set()
    for name in ('indic-asr-smoke-20260915', 'indic-asr-verbatim-20260915',
                 'indic-codemix-matched-20260916'):
        prior.update(row['reference_id'] for row in json.loads(
            (ROOT / 'artifacts' / name / 'observations.json').read_text()))
    planned, canonical = [], []
    for provider, language in PAIRS:
        choices = [ref for ref in refs if (ref['provider'], ref['language']) == (provider, language)
                   and ref['reference_id'] not in prior]
        prefix = PINNED_PREFIX.get((provider, language))
        if prefix:
            choices = [ref for ref in choices if ref['reference_id'].startswith(prefix)]
        if len(choices) != 1:
            raise ValueError('Expected exactly one new pinned reference: ' + provider + '/' + language)
        ref = choices[0]
        run = runs.get(ref['run_id'])
        if not run or run['status'] != 'success' or (
            run['provider'], run['language'], run['config'].get('model'), run['text']) != (
            provider, language, ref['model'], ref['text']):
            raise ValueError('Regional ASR run/model/text identity changed')
        url = run.get('audio_url')
        if not url or not url.startswith('/evidence/audio/') or not url.endswith('.wav'):
            raise ValueError('Regional ASR public WAV missing')
        file = (ROOT / 'ui/public' / url.lstrip('/')).resolve()
        if not file.is_relative_to(ROOT / 'ui/public/evidence/audio'):
            raise ValueError('Regional ASR audio escaped evidence folder')
        raw = file.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if sha != run['listening_audio_sha256'] or len(raw) > 2_000_000:
            raise ValueError('Regional ASR public WAV hash/size changed')
        with wave.open(str(file), 'rb') as media:
            duration = media.getnframes() / media.getframerate()
            if media.getnchannels() != 1 or media.getsampwidth() != 2 or not 0 < duration <= 12:
                raise ValueError('Regional ASR WAV format/duration invalid')
        if abs(duration - run['duration_seconds']) > .05:
            raise ValueError('Regional ASR WAV duration differs from saved result')
        pinned = dict(ref, audio_sha256=sha, native_reviewed=False)
        canonical.append(pinned)
        planned.append((pinned, file, raw, duration))
    seconds = sum(row[3] for row in planned)
    if len(planned) != 16 or seconds > 80 or len({(r[0]['provider'], r[0]['language']) for r in planned}) != 16:
        raise ValueError('Regional ASR request/audio cap or cell uniqueness failed')
    plan = {'schema': 'indic_regional_asr_v1', 'asr_model': 'saaras:v3',
            'asr_mode': 'verbatim', 'language_code': 'unknown', 'requests_limit': 16,
            'audio_seconds_limit': 80, 'planned_audio_seconds': round(seconds, 3),
            'automatic_retries': 0, 'source_references_sha256': hashlib.sha256(refs_raw).hexdigest(),
            'snapshot_code_sha256': snapshot['code_sha256'],
            'items': [{'reference_id': ref['reference_id'], 'run_id': ref['run_id'],
                       'provider': ref['provider'], 'model': ref['model'], 'language': ref['language'],
                       'audio_sha256': ref['audio_sha256'], 'audio_url': '/evidence/audio/' + file.name,
                       'duration_seconds': round(duration, 3)}
                      for ref, file, _, duration in planned]}
    return plan, canonical, planned


def live_run():
    plan, refs, planned = preflight()
    if OUT.exists():
        raise RuntimeError('Regional ASR batch was already attempted; no repeat')
    key = read_key()
    OUT.mkdir(parents=True, mode=0o700)
    os.chmod(OUT, 0o700)
    (OUT / 'attempt.started').write_text('Sixteen saved audio requests maximum; no retries.\n')
    (OUT / 'plan.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'canonical_references.json').write_text(json.dumps(refs, ensure_ascii=False, indent=2) + '\n')
    observations, private = [], []
    _checkpoint(OUT, observations, private, {'status': 'in_progress', 'completed_requests': 0,
                                            'planned_requests': 16, 'certification': False})
    for ref, file, raw, duration in planned:
        try:
            response = request_one(raw, file.name, 'verbatim', key)
        except Exception as exc:
            _checkpoint(OUT, observations, private, {'status': 'partial_failure',
                'completed_requests': len(observations), 'planned_requests': 16,
                'failed_provider': ref['provider'], 'failed_language': ref['language'],
                'error_type': type(exc).__name__, 'certification': False,
                'resume_policy': 'no_automatic_retry'})
            raise
        observations.append({'observation_id': 'saaras_v3_regional_' + ref['reference_id'],
                             'reference_id': ref['reference_id'],
                             **{k: ref[k] for k in ('run_id', 'provider', 'model', 'language', 'audio_sha256')},
                             'source': 'asr', 'transcriber_id': 'sarvam.saaras:v3.verbatim',
                             'text': response['transcript']})
        private.append({'reference_id': ref['reference_id'], 'sanitized_response': response,
                        'audio_duration_seconds': duration})
        _checkpoint(OUT, observations, private, {'status': 'in_progress',
            'completed_requests': len(observations), 'planned_requests': 16, 'certification': False})
    _checkpoint(OUT, observations, private, {'status': 'complete', 'completed_requests': 16,
                                             'planned_requests': 16, 'certification': False})
    scores = evaluate_transcripts(observations, refs, {})
    if scores['rejected'] or len(scores['observations']) != 16:
        raise ValueError('Regional ASR observations failed scoring identity check')
    detected = {row['reference_id']: row['sanitized_response']['language_code'] for row in private}
    summary = {'schema': 'indic_regional_asr_summary_v1', 'engine': 'sarvam.saaras:v3.verbatim',
               'status': 'complete', 'planned_requests': 16, 'completed_requests': 16,
               'plan_sha256': hashlib.sha256((OUT / 'plan.json').read_bytes()).hexdigest(),
               'native_reviewed_references': 0, 'human_ratings': 0,
               'results': [{'provider': score['provider'], 'model': score['model'],
                            'language': score['language'], 'reference_id': score['reference_id'],
                            'audio_sha256': score['audio_sha256'],
                            'detected_language': detected[score['reference_id']],
                            'wer_raw': score['wer']['rate'], 'cer_raw': score['cer']['rate'],
                            'word_edit_distance': score['wer']['distance'],
                            'draft_word_units': score['wer']['reference_units']}
                           for score in scores['observations']],
               'boundary': 'Different prompts/voices/models across cells; ASR lexical diagnostics against unreviewed synthesis text, not a vendor ranking or native quality score'}
    (OUT / 'result-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return {'status': 'complete', 'completed_requests': 16,
            'provider_language_cells': [(r['provider'], r['language']) for r in summary['results']]}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    result = live_run() if args.live else {'status': 'preflight_passed', 'plan': preflight()[0]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
