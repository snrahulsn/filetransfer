"""Read-only access and spend preflight for the deferred NVIDIA Magpie NIM Pod."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.runpod_eval_pod import api
from tts_arena.credentials import read_credentials


MODEL = 'magpie-tts-multilingual'
IMAGE = 'nvcr.io/nim/nvidia/magpie-tts-multilingual:1.10.0'
GPU = 'NVIDIA L40S'


def inspect(credentials: dict, pod_api=api) -> dict:
    runpod_key = credentials.get('RunPod') or credentials.get('RUNPOD_API_KEY')
    ngc_key = credentials.get('NGC_API_KEY') or credentials.get('NVIDIA_NGC_API_KEY')
    if not runpod_key:
        return {'runpod_access': False, 'active_pods': None, 'ngc_catalog_key_present': bool(ngc_key),
                'can_launch': False, 'blocker': 'No Runpod API credential'}
    status, pods = pod_api('GET', runpod_key)
    if status != 200 or not isinstance(pods, list):
        raise RuntimeError('Runpod Pod inventory could not be verified')
    blocker = ('An account Pod is already active' if pods else
               'No NVIDIA NGC Catalog key' if not ngc_key else None)
    return {'runpod_access': True, 'active_pods': len(pods),
            'ngc_catalog_key_present': bool(ngc_key), 'can_launch': blocker is None,
            'blocker': blocker, 'planned_model': MODEL, 'container_image': IMAGE,
            'planned_gpu': GPU, 'profile': 'batch_size=8', 'guard_seconds': 3600,
            'max_accepted_hourly_usd': 1.5, 'calls_planned': ['GET /v1/health/ready',
            'GET /v1/metadata', 'GET /v1/audio/list_voices', 'one Hindi POST /v1/audio/synthesize']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--credentials-path', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(inspect(read_credentials(args.credentials_path)), indent=2))


if __name__ == '__main__':
    main()
