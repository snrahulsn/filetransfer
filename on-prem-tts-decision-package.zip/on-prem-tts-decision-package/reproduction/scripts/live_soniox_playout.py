"""One paid Soniox Hindi cancel/recovery playout run; no retries or phone calls."""
import asyncio
import io
import json
import math
import shutil
import sys
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.soniox_playout import preflight, replay_soniox

OUT = ROOT / 'artifacts/soniox-playout-20260916'
KEY_FILE = '/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env'
OLD = 'नमस्ते। आपकी अगली किस्त जल्द देय है। मैं भुगतान की तारीख और राशि दोहरा रहा हूँ। अगर जानकारी गलत है तो मुझे बीच में रोककर सही विवरण बताइए।'
RECOVERY = 'जी, मैंने आपकी बात सुन ली है। कृपया सही तारीख बताइए।'


def caller_fixture():
    raw = bytearray()
    for sample in range(2400):
        value = int(2400 * math.sin(2 * math.pi * 440 * sample / 24000))
        raw.extend(value.to_bytes(2, 'little', signed=True))
    output = io.BytesIO()
    with wave.open(output, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(24000)
        wav.writeframes(raw)
    return output.getvalue()


async def main():
    if OUT.exists():
        raise FileExistsError('Run already attempted; no repeat spend')
    if shutil.disk_usage(ROOT).free < 300 * 1024 * 1024:
        raise RuntimeError('Disk preflight failed')
    caller = caller_fixture()
    preflight(caller, OLD, RECOVERY, {'SONIOX_API_KEY': 'offline-preflight'}, 8)
    key = read_credentials(KEY_FILE).get('SONIOX_API_KEY')
    if not key:
        raise RuntimeError('Soniox key unavailable')
    fixture = ROOT / 'artifacts/calibration/soniox-caller-tone-24000.wav'
    fixture.parent.mkdir(parents=True, exist_ok=True)
    if fixture.exists() and fixture.read_bytes() != caller:
        raise RuntimeError('Existing caller fixture differs')
    fixture.write_bytes(caller)
    result = await replay_soniox(fixture, OUT, OLD, RECOVERY,
                                  {'SONIOX_API_KEY': key}, onset_offset_ms=150,
                                  observation_seconds=8, stop_threshold_ms=500)
    bridge = result['soniox_bridge']
    print(json.dumps({'receiver_status': result['status'],
                      'bridge_status': bridge['status'],
                      'receiver_error_type': result['error_type'],
                      'bridge_error_type': bridge['error_type'],
                      'native_cancel': bridge['native_cancel_sent'],
                      'old_terminated': bridge['old_terminated'],
                      'new_terminated': bridge['new_terminated'],
                      'metrics': result.get('metrics'),
                      'audio_artifacts': sorted(bridge['artifacts'])}))


if __name__ == '__main__':
    asyncio.run(main())
