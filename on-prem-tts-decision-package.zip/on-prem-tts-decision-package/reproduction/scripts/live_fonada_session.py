"""One bounded V1 WS protocol probe; never attributes V1 evidence to Klone V2 Pro."""
import asyncio
import hashlib
import json
from pathlib import Path
import sys
import time
import wave
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from websockets.asyncio.client import connect
from tts_arena.credentials import read_credentials,redact
from tts_arena.session_runner import run_session
from tts_arena.audio import inspect_audio

ROOT=Path(__file__).resolve().parents[1]

async def main():
    output=ROOT/'artifacts/fonada-session-20260915';output.mkdir(exist_ok=False)
    creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    controls=[];binary_frames=[];sent=[];origin=time.perf_counter()
    class TappedSocket:
        def __init__(self,ws):self.ws=ws
        async def send(self,message):
            data=json.loads(message);sent.append({'fields':sorted(data),'credential_field_present':'api_key' in data,'text_characters':len(data.get('text',''))})
            await self.ws.send(message)
        def __aiter__(self):return self.messages()
        async def messages(self):
            async for message in self.ws:
                elapsed=(time.perf_counter()-origin)*1000
                if isinstance(message,bytes):binary_frames.append({'elapsed_ms':elapsed,'bytes':len(message),'sha256':hashlib.sha256(message).hexdigest()})
                else:
                    # Preserve exact provider control diagnostics after redaction, without logging outgoing credentials.
                    controls.append({'elapsed_ms':elapsed,'frame':redact(message,creds)})
                yield message
    class Connector:
        def __init__(self,url,**kwargs):
            kwargs['open_timeout']=3;kwargs['close_timeout']=1
            self.manager=connect(url,**kwargs)
        async def __aenter__(self):return TappedSocket(await self.manager.__aenter__())
        async def __aexit__(self,*args):return await self.manager.__aexit__(*args)
    config={'model':'fonada-v1','protocol_profile':'sdk-2.2.3','voice':'Dhruv','language':'hi-IN',
            'format':'pcm_s16le','sample_rate':24000,'initial_text':'नमस्ते, आपका भुगतान प्राप्त हो गया है।'}
    record=await run_session('fonada',config,[],output/'runs',seconds=10,connector=Connector,env={'FONADA_API_KEY':creds['FONADA_API_KEY']})
    done=any(e.get('event_type')=='provider_event' and e.get('details',{}).get('type')=='done' for e in record['events'])
    audio_checks=[]
    for item in record['audio']:
        source=Path(record['result_file']).parent/item['path'];data=source.read_bytes()
        analysis=inspect_audio(data,record['encoding'],record['sample_rate'],1)
        codec_match=not data.startswith((b'RIFF',b'ID3',b'OggS')) and len(data)%2==0
        preview=source.with_suffix('.wav')
        if codec_match:
            with wave.open(str(preview),'wb') as out:
                out.setnchannels(1);out.setsampwidth(2);out.setframerate(24000);out.writeframes(data)
        audio_checks.append({'source':str(source),'preview':str(preview) if codec_match else None,'raw_pcm_contract_consistent':codec_match,'analysis':analysis})
    result={'provider':'fonada','model':'fonada-v1','protocol_profile':'sdk-2.2.3','session_result':record['result_file'],
        'status':record['status'],'error_type':record['error_type'],'elapsed_seconds':time.perf_counter()-origin,
        'sent_requests':len(sent),'request_shapes':sent,'control_frames':controls,'binary_frames':binary_frames,
        'terminal_completion_observed':done,'audio_checks':audio_checks,
        'outcome':'audio_and_terminal_observed' if done and audio_checks and record['status']!='error' else 'protocol_or_access_error' if record['status']=='error' else 'inconclusive',
        'scope':'One V1 transport probe. Not KloneV2Pro streaming, native cancellation, barge-in, language quality or latency qualification.',
        'automatic_retries':0,'credentials_recorded':False}
    (output/'summary.json').write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
    print(json.dumps({k:result[k] for k in ['status','error_type','outcome','sent_requests','terminal_completion_observed','elapsed_seconds']},indent=2))

if __name__=='__main__':
    raise SystemExit('Historical V1 comparator script retained for audit only. Further execution is disabled under the cutting-edge-only model scope.')
