"""One small dictionary creation, two short matched syntheses, no retries."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=Path(__file__).resolve().parents[1]/'artifacts/sarvam-dictionary-20260915'
DICTIONARY={'pronunciations':{'hi-IN':{'B2B':'B to B','NAIC':'N A I C'}}}
TEXT='कृपया NAIC विवरण देखें और B2B पोर्टल पर आगे बढ़ें।'
BASE=dict(model='bulbul:v3',voice='shubh',language='hi-IN',format='wav',sample_rate=24000)
CREATE_URL='https://api.sarvam.ai/text-to-speech/pronunciation-dictionary'
def upload_payload(dictionary):
 if set(dictionary)!={'pronunciations'} or not isinstance(dictionary['pronunciations'],dict):raise ValueError('pronunciations object required')
 count=0
 for locale,entries in dictionary['pronunciations'].items():
  if locale not in 'hi-IN en-IN bn-IN mr-IN te-IN ta-IN gu-IN kn-IN ml-IN pa-IN'.split():raise ValueError('Unreviewed language')
  if not isinstance(entries,dict) or not entries:raise ValueError('Nonempty mappings required')
  for word,replacement in entries.items():
   if not isinstance(word,str) or not word or not isinstance(replacement,str) or not replacement:raise ValueError('Nonempty string replacement pairs required')
  count+=len(entries)
 if not 1<=count<=100:raise ValueError('1–100 entries required')
 data=json.dumps(dictionary,ensure_ascii=False).encode('utf8')
 if len(data)>1_000_000:raise ValueError('File exceeds conservative 1MB limit')
 return {'file':('tts-arena-evaluation.json',data,'application/json')}
async def main():
 if OUT.exists():raise RuntimeError('Existing evidence guard; no repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');os.environ['SARVAM_API_KEY']=secrets['SARVAM_API_KEY'];files=upload_payload(DICTIONARY);build_request('sarvam',TEXT,BASE)
 OUT.mkdir(exist_ok=False);(OUT/'dictionary.json').write_bytes(files['file'][1]);report={'max_creations':1,'max_syntheses':2,'no_retries':True,'creation_attempted':False,'attempts':0,'records':[],'pronunciation_accuracy':'unverified','billing':'existing account access only; no purchase or inferred cost'}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n')
 save()
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False) as client:
  report['creation_attempted']=True;save()
  try:
   r=await client.post(CREATE_URL,headers={'api-subscription-key':secrets['SARVAM_API_KEY']},files=files)
   report['creation']={'http_status':r.status_code,'response':redact(r.text[:3000],secrets)};save()
   if r.status_code!=200:return
   dictionary_id=r.json().get('dictionary_id')
   if not isinstance(dictionary_id,str) or not dictionary_id:raise ValueError('Missing dictionary_id')
   report['dictionary_id']=dictionary_id;save()
   for config in [BASE,dict(BASE,dict_id=dictionary_id)]:
    report['attempts']+=1;save()
    result=await run_one('sarvam',TEXT,config,OUT/'runs',timeout=30,client=client,evaluation_language='hi-IN',scenario_id='sarvam_dictionary_pair',stratum='paired_control')
    record={k:result.get(k) for k in ['run_id','provider','text','config','status','http_status','duration_seconds','audio_sha256','audio_bytes','error_type']};record['result_file']=str(OUT/'runs'/result['run_id']/'result.json');report['records'].append(record);save();print(result['status'],result.get('http_status'),flush=True)
    if result['status']!='success':return
   report['request_acceptance']='accepted';report['audio_changed']=report['records'][0]['audio_sha256']!=report['records'][1]['audio_sha256'];report['pronunciation_accuracy']='unverified; replacement correctness and speech require native listener/transcript verification';save()
  except Exception as exc:report['error_type']=type(exc).__name__;save()
if __name__=='__main__':asyncio.run(main())
