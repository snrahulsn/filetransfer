"""Measure the batch-worker termination fallback for Qwen3-TTS barge-in."""
from __future__ import annotations

import argparse
import json
import signal
import subprocess
import sys
import time
from pathlib import Path


def gpu_memory_mib() -> int:
    result = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=used_memory", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, check=False,
    )
    values = [int(x.strip()) for x in result.stdout.splitlines() if x.strip().isdigit()]
    return sum(values)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--reference-text", required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--interrupt-after-ms", type=int, default=500)
    args = parser.parse_args()
    ready = args.result.with_suffix(".ready.json")
    ready.unlink(missing_ok=True)
    log = args.result.with_suffix(".worker.log")
    with log.open("wb") as output:
        process = subprocess.Popen([
            sys.executable, str(args.worker), "--reference", str(args.reference),
            "--reference-text", args.reference_text, "--ready", str(ready),
        ], stdout=output, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 180
        while not ready.is_file() and process.poll() is None and time.monotonic() < deadline:
            time.sleep(0.05)
        if not ready.is_file():
            process.kill()
            raise RuntimeError("worker failed to become synthesis-ready")
        memory_before = gpu_memory_mib()
        time.sleep(args.interrupt_after_ms / 1000)
        cancel_started = time.perf_counter()
        process.send_signal(signal.SIGTERM)
        try:
            return_code = process.wait(timeout=10)
            forced_kill = False
        except subprocess.TimeoutExpired:
            process.kill()
            return_code = process.wait(timeout=10)
            forced_kill = True
        termination_seconds = time.perf_counter() - cancel_started
    time.sleep(1)
    result = {
        "model": "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
        "native_per_request_cancel": False,
        "playable_incremental_audio": False,
        "fallback": "dedicated process termination and batch-result discard",
        "interrupt_after_synthesis_ready_ms": args.interrupt_after_ms,
        "worker_termination_seconds": termination_seconds,
        "forced_kill_required": forced_kill,
        "worker_return_code": return_code,
        "gpu_process_memory_before_cancel_mib": memory_before,
        "gpu_process_memory_one_second_after_cancel_mib": gpu_memory_mib(),
        "completed_audio_emitted": False,
        "scope": "TTS worker lifecycle only; playback stop and ASR/VAD are application responsibilities",
    }
    args.result.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
