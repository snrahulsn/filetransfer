"""One capped, no-retry synthesis request for every current documented hosted route."""
import asyncio
import hashlib
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlparse, parse_qsl

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials, redact
from tts_arena.registry import build_request, code_digest, digest
from tts_arena.runner import run_one

REFERENCE = ROOT / 'ui/public/evidence/working-api-reference.json'
SNAPSHOT = ROOT / 'ui/public/evidence/snapshot.json'
OUT = ROOT / 'artifacts/current-revision-api-20260916'
RUNS = ROOT / 'artifacts/runs/current-revision-api-20260916'
AUTHORIZED_CREDENTIALS = '/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env'
EXPECTED = {'camb', 'cartesia', 'deepgram', 'dubverse', 'elevenlabs', 'fish',
            'fonada', 'gnani', 'google', 'hume', 'inworld', 'minimax', 'murf',
            'neuphonic', 'rime', 'sarvam', 'smallest', 'soniox', 'speechify'}


def preflight(secrets=None):
    source = REFERENCE.read_bytes()
    reference = json.loads(source)
    snapshot = json.loads(SNAPSHOT.read_text())
    if reference['hosted_working_api_count'] != 19 or (
        {r['provider'] for r in reference['routes']} != EXPECTED or
        snapshot['code_sha256'] != code_digest() or
        reference['generated_from_snapshot'] != snapshot['generated_at']):
        raise ValueError('Current reference/source/version scope changed')
    if secrets is None:
        secrets = read_credentials(AUTHORIZED_CREDENTIALS)
    jobs = []
    for route in reference['routes']:
        provider = route['provider']
        text = route['example_text']
        config = route['example_config']
        if not isinstance(text, str) or not 0 < len(text) <= 100:
            raise ValueError('Saved bounded synthesis text missing: ' + provider)
        env = {key: secrets[key] for key in route['credential_environment_names'] if secrets.get(key)}
        if not env:
            raise ValueError('Authorized evaluation credential unavailable: ' + provider)
        spec = build_request(provider, text, config, env)
        actual = urlparse(spec.url)
        expected = urlparse(route['endpoint'])
        actual_body = hashlib.sha256(spec.body).hexdigest() if isinstance(spec.body, bytes) else digest(spec.body)
        def mask_query_value(value):
            for secret in env.values():
                value = value.replace(secret, 'synthetic-test-credential')
            return value
        actual_query = sorted((key, mask_query_value(value))
                              for key, value in parse_qsl(actual.query))
        expected_query = sorted(parse_qsl(expected.query))
        if ((spec.method, spec.response_mode, spec.encoding, spec.sample_rate, actual_body,
             set(spec.headers), actual.scheme, actual.hostname, actual.path,
             actual_query) !=
            (route['method'], route['response_mode'], route['encoding'], route['sample_rate'],
             route['request_body_sha256'], set(route['all_header_names']),
             expected.scheme, expected.hostname, expected.path,
             expected_query)):
            raise ValueError('Actual credential request differs from saved/current contract: ' + provider)
        jobs.append({'provider': provider, 'text': text, 'config': config,
                     'credential_names': sorted(env), 'method': spec.method,
                     'endpoint_host': actual.hostname, 'endpoint_path': actual.path,
                     'body_sha256': actual_body, 'source_run_id': route['example_run_id']})
    if len(jobs) != 19 or len({job['provider'] for job in jobs}) != 19:
        raise ValueError('Current revision live request cap or provider uniqueness failed')
    return {'schema': 'current_revision_api_plan_v1', 'source_reference_sha256': hashlib.sha256(source).hexdigest(),
            'snapshot_code_sha256': snapshot['code_sha256'], 'request_limit': 19,
            'planned_requests': 19, 'automatic_retries': 0, 'timeout_seconds_per_request': 35,
            'minimum_spacing_seconds': 1.5,
            'scope': 'One saved short prompt/model/config per hosted route; no load, cost or native quality claim',
            'jobs': jobs}, secrets


async def live_run():
    if OUT.exists() or RUNS.exists():
        raise RuntimeError('Current-revision API batch already attempted; no repeat')
    plan, secrets = preflight()
    OUT.mkdir(parents=True, mode=0o700)
    RUNS.mkdir(parents=True)
    os.chmod(OUT, 0o700)
    (OUT / 'attempt.started').write_text('Nineteen one-shot hosted requests maximum; no retries.\n')
    (OUT / 'plan.json').write_text(redact(json.dumps(plan, ensure_ascii=False, indent=2) + '\n', secrets))
    (OUT / 'reference-attempt.json').write_bytes(REFERENCE.read_bytes())
    report = {'schema': 'current_revision_api_status_v1',
              'source_code_sha256': plan['snapshot_code_sha256'],
              'planned_requests': 19, 'completed_requests': 0, 'automatic_retries': 0,
              'status': 'in_progress', 'results': []}

    def save():
        (OUT / 'status.json').write_text(redact(json.dumps(report, ensure_ascii=False, indent=2) + '\n', secrets))

    save()
    for index, job in enumerate(plan['jobs']):
        if index:
            await asyncio.sleep(1.5)
        provider = job['provider']
        env = {key: secrets[key] for key in job['credential_names']}
        os.environ.update(env)
        row = {'provider': provider, 'source_run_id': job['source_run_id'],
               'status': 'request_started'}
        report['results'].append(row)
        save()
        try:
            async with httpx.AsyncClient(timeout=35, trust_env=False, follow_redirects=False) as client:
                result = await run_one(provider, job['text'], job['config'], RUNS,
                                       timeout=35, client=client,
                                       scenario_id='current-revision-one-shot',
                                       evaluation_language=job['config'].get('language', 'unverified'),
                                       stratum='current_revision_api_verification',
                                       min_free_bytes=300 * 1024 * 1024)
            row.update({key: result.get(key) for key in
                        ('run_id', 'status', 'http_status', 'error_type', 'duration_seconds',
                         'first_audio_ms', 'audio_sha256')})
            report['completed_requests'] += 1
            save()
            print(provider, result['status'], result.get('http_status'), flush=True)
        except Exception as exc:
            row.update(status='execution_interrupted', error_type=type(exc).__name__)
            report.update(status='partial_failure', failed_provider=provider,
                          resume_policy='no_automatic_retry')
            save()
            raise
        finally:
            for key in env:
                os.environ.pop(key, None)
    report['status'] = 'complete'
    save()
    return {'status': 'complete', 'completed_requests': report['completed_requests'],
            'audio_successes': sum(row['status'] == 'success' for row in report['results'])}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    result = asyncio.run(live_run()) if args.live else {
        'status': 'preflight_passed', 'planned_requests': preflight()[0]['planned_requests']}
    print(json.dumps(result))
