"""Six exact-current Gnani voice/locale probes, paced at 60 seconds, no retries."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/runs/gnani-regional-20260915'
MANIFEST=ROOT/'artifacts/gnani-regional-20260915/manifest.json'
PROMPTS=[('bn-IN','Kirra','নমস্কার, আপনার পেমেন্ট পাওয়া গেছে। ধন্যবাদ।'),('mr-IN','Zahira','नमस्कार, तुमचे पेमेंट मिळाले आहे. धन्यवाद।'),('te-IN','Suhana','నమస్కారం, మీ చెల్లింపు అందింది. ధన్యవాదాలు.'),('gu-IN','Falak','નમસ્તે, તમારી ચુકવણી મળી ગઈ છે. આભાર.'),('kn-IN','Saanvi','ನಮಸ್ಕಾರ, ನಿಮ್ಮ ಪಾವತಿ ಸ್ವೀಕರಿಸಲಾಗಿದೆ. ಧನ್ಯವಾದಗಳು.'),('ml-IN','Reshma','നമസ്കാരം, നിങ്ങളുടെ പണം ലഭിച്ചു. നന്ദി.')]

async def main():
 if OUT.exists() or MANIFEST.exists():raise RuntimeError('Existing Gnani regional batch; no repeat')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('GNANI_API_KEY_ID')
 if not key:raise RuntimeError('No authorized Gnani key')
 configs=[{'model':'timbre-v2.5','voice':voice,'language':locale,'format':'wav','sample_rate':24000} for locale,voice,_ in PROMPTS]
 for (_,_,text),config in zip(PROMPTS,configs):build_request('gnani',text,config,{'GNANI_API_KEY_ID':key})
 OUT.mkdir(parents=True);MANIFEST.parent.mkdir(parents=True)
 report={'provider':'gnani','model':'timbre-v2.5','request_limit':6,'retries':0,'inter_request_seconds':60,'exact_locale_voice':True,'native_quality':'unverified','samples':[]}
 def save():MANIFEST.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'GNANI_API_KEY_ID':key}))
 save();os.environ['GNANI_API_KEY_ID']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   for i,((locale,voice,text),config) in enumerate(zip(PROMPTS,configs)):
    r=await run_one('gnani',text,config,OUT,timeout=35,client=client,scenario_id='payment-'+locale,evaluation_language=locale,stratum='regional_delivery_paced',min_free_bytes=300*1024*1024)
    report['samples'].append({k:r.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','first_audio_ms')});report['samples'][-1].update(locale=locale,voice=voice);save()
    print(locale,voice,r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
    if i+1<len(PROMPTS):await asyncio.sleep(60)
 finally:os.environ.pop('GNANI_API_KEY_ID',None)
 report['completed']=True;save()

if __name__=='__main__':asyncio.run(main())
