"""One current-model Hindi speech attempt; stop on account-level quota failure."""
import asyncio
import json
import os
import sys
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tts_arena.credentials import read_credentials, redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT = ROOT / 'artifacts/openai-credit-recheck-20260916'
TEXT = 'नमस्ते, आपकी बैठक कल तीन बजे है। कृपया पुष्टि करें।'
CONFIG = {'model': 'gpt-4o-mini-tts-2025-12-15', 'voice': 'coral',
          'language': 'hi-IN', 'format': 'pcm'}


async def main():
    if OUT.exists():
        raise RuntimeError('Existing OpenAI attempt; no automatic repeat')
    key = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('OPENAI_API_KEY')
    if not key:
        raise RuntimeError('Authorized OpenAI key unavailable')
    spec = build_request('openai', TEXT, CONFIG, {'OPENAI_API_KEY': key})
    if spec.method != 'POST' or spec.url != 'https://api.openai.com/v1/audio/speech' or spec.encoding != 'pcm_s16le':
        raise ValueError('OpenAI current speech contract mismatch')
    OUT.mkdir(parents=True, mode=0o700)
    report = {'provider': 'openai', 'model': CONFIG['model'], 'language': 'hi-IN',
              'request_limit': 1, 'automatic_retries': 0, 'attempted': True,
              'status': 'in_progress', 'result_file': None,
              'vendor_contract': 'https://developers.openai.com/api/reference/cli/resources/audio/subresources/speech/methods/create',
              'native_language_quality': 'unverified', 'account_billed_cost': 'unverified'}

    def save():
        (OUT / 'summary.json').write_text(redact(json.dumps(report, ensure_ascii=False, indent=2) + '\n',
                                               {'OPENAI_API_KEY': key}))

    save()
    os.environ['OPENAI_API_KEY'] = key
    try:
        async with httpx.AsyncClient(timeout=35, trust_env=False, follow_redirects=False) as client:
            result = await run_one('openai', TEXT, CONFIG, OUT / 'runs', timeout=35, client=client,
                                   scenario_id='meeting-hi-01', evaluation_language='hi-IN',
                                   stratum='credit_recheck', min_free_bytes=300 * 1024 * 1024)
    finally:
        os.environ.pop('OPENAI_API_KEY', None)
    report.update({k: result.get(k) for k in ('run_id', 'status', 'http_status', 'error_type',
                                             'audio_bytes', 'audio_sha256', 'duration_seconds')})
    report['result_file'] = str((OUT / 'runs' / result['run_id'] / 'result.json').relative_to(ROOT))
    save()
    print(json.dumps({k: report.get(k) for k in ('status', 'http_status', 'error_type', 'audio_bytes')},
                     ensure_ascii=False))


if __name__ == '__main__':
    asyncio.run(main())
