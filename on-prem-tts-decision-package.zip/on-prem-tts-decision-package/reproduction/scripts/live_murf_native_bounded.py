"""One no-retry Hindi Falcon 2 native WebSocket request; private key never saved."""
import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.session_runner import run_session
from tts_arena.sessions import murf

FOLDER = ROOT / 'artifacts/murf-native-20260916'
GUARD = FOLDER / 'attempt.started'
MANIFEST = FOLDER / 'manifest.json'
CONFIG = {'model': 'falcon-2', 'voice': 'hi-IN-khyati', 'language': 'hi-IN',
          'format': 'WAV', 'sample_rate': 24000, 'region': 'global', 'context_id': 'hindi-turn-1'}
TEXT = 'नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
ACTIONS = [{'at_ms': 0, 'type': 'text', 'context_id': 'hindi-turn-1', 'text': TEXT, 'end': True}]


async def main():
    if GUARD.exists() or MANIFEST.exists():
        raise RuntimeError('Bounded Murf native attempt already started; no retry')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    secret = credentials.get('MURF_API_KEY')
    if not secret:
        raise RuntimeError('Authorized Murf API key missing')
    env = {'MURF_API_KEY': secret}
    spec = murf.build_session(CONFIG, env)
    if len(ACTIONS) != 1 or spec.sample_rate != 24000 or len(TEXT) > 150:
        raise RuntimeError('Unreviewed live request scope')
    murf.encode_action(ACTIONS[0], CONFIG)
    FOLDER.mkdir(parents=True, exist_ok=True)
    GUARD.write_text('One live attempt, no automatic retry.\n')
    report = await run_session('murf', CONFIG, ACTIONS, FOLDER / 'sessions', seconds=14, env=env)
    audit = {'provider': 'murf', 'model': 'falcon-2', 'language': 'hi-IN',
             'transport': 'native_websocket', 'documented_endpoint':
             'wss://global.api.murf.ai/v1/speech/stream-input',
             'key_location': 'api-key URL query; URL and key withheld from artifacts',
             'retries': 0, 'request_limit': 1, 'text': TEXT, 'voice': CONFIG['voice'],
             'result_path': str(Path(report['result_file']).relative_to(ROOT)),
             'status': report['status'], 'error_type': report['error_type'],
             'sent_action_count': report['sent_action_count'],
             'audio_streams': len(report['audio']),
             'audio_payload_events': sum(e['event_type'] == 'audio_payload_received' for e in report['events']),
             'terminal_events': sum(e['event_type'] == 'provider_event' and
                                    e.get('details', {}).get('type') == 'done' for e in report['events']),
             'source': ['https://murf.ai/api/docs/text-to-speech/web-sockets',
                        'https://murf.ai/api/docs/text-to-speech/web-sockets/context-id'],
             'quality_certified': False, 'production_barge_in_certified': False}
    MANIFEST.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: audit[k] for k in ('provider', 'language', 'status', 'error_type',
                                          'sent_action_count', 'audio_streams',
                                          'audio_payload_events', 'terminal_events')}))


if __name__ == '__main__':
    asyncio.run(main())
