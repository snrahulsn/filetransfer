"""No-retry follow-up for four untouched candy.two speaker IDs after a 404."""
import asyncio
import json
import os
import sys
from datetime import datetime,timezone
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.live_dubverse_flagship_bounded import CASES
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT=ROOT/'artifacts/runs/dubverse-flagship-remaining-20260915'
SUMMARY=ROOT/'artifacts/dubverse-flagship-remaining-20260915/summary.json'

async def main():
 if OUT.exists() or SUMMARY.exists():raise RuntimeError('Remaining speaker pass already attempted; no repeat spend')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('DUBVERSE_API_KEY')
 if not key:raise RuntimeError('Authorized Dubverse key absent')
 plans=[]
 for locale,voice,text in CASES[2:]:
  config={'model':'candy.two','voice':voice,'language':locale,'format':'wav','audio_streaming':False}
  spec=build_request('dubverse',text,config,{'DUBVERSE_API_KEY':key})
  if len(text)>90 or 'sample_rate' in spec.body['config']:raise ValueError('Current model preflight failed')
  plans.append((locale,config,text))
 OUT.mkdir(parents=True);SUMMARY.parent.mkdir(parents=True)
 report={'provider':'dubverse','model':'candy.two','created_at':datetime.now(timezone.utc).isoformat(),
  'reason':'Bengali 1220 returned 404; four untouched speaker IDs checked once each',
  'request_limit':len(plans),'automatic_retries':0,'results':[]}
 def save():SUMMARY.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'DUBVERSE_API_KEY':key}))
 save();os.environ['DUBVERSE_API_KEY']=key
 diagnostics=[]
 async def hook(response):
  if response.status_code>=400:
   body=(await response.aread())[:1000].decode('utf8','replace')
   diagnostics.append({'http_status':response.status_code,'body_excerpt':redact(body,{'DUBVERSE_API_KEY':key})})
 try:
  async with httpx.AsyncClient(timeout=45,trust_env=False,follow_redirects=False,
                               event_hooks={'response':[hook]}) as client:
   for index,(locale,config,text) in enumerate(plans):
    if index:await asyncio.sleep(2)
    row={'locale':locale,'voice':config['voice'],'text':text,'status':'request_started'}
    report['results'].append(row);save()
    before=len(diagnostics)
    result=await run_one('dubverse',text,config,OUT,timeout=45,client=client,
     scenario_id='dubverse-flagship-remaining-'+locale,evaluation_language=locale,
     stratum='matched_neo_candy_model_output',min_free_bytes=300*1024*1024)
    row.update({k:result.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes',
                                         'audio_sha256','duration_seconds','first_audio_ms')})
    row['diagnostics']=diagnostics[before:];save()
    print(locale,result['status'],result.get('http_status'),flush=True)
    if result.get('http_status') in (401,402,403,429) or result['error_type']=='TimeoutError':
     report['stopped_after_account_or_transport_error']=True;save();break
 finally:os.environ.pop('DUBVERSE_API_KEY',None)
 report['completed']=True;report['successes']=sum(r['status']=='success' for r in report['results']);save()
 print(json.dumps({'attempts':len(report['results']),'successes':report['successes']}))

if __name__=='__main__':asyncio.run(main())
