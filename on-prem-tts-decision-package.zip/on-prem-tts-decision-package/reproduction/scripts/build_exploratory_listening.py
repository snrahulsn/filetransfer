"""Package actual successful PCM recordings, preserving their speech bytes."""
import hashlib
import json
from pathlib import Path
import random
import sys
import tempfile
import wave
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tts_arena.quality import prepare_study
from tts_arena.listening import write_listening_page
from tts_arena.live_evidence import load_live_runs

ROOT=Path(__file__).resolve().parents[1]

def build(manifest_path=None):
    runs,issues=load_live_runs(ROOT/'artifacts/runs')
    records={json.loads(p.read_text()).get('run_id'):p for p in (ROOT/'artifacts/runs').rglob('result.json')}
    selected=[r for r in runs if r['status']=='success' and r.get('audio_analysis',{}).get('analysis_status')=='measured_pcm' and r.get('audio_file')]
    matched={}
    if manifest_path:
        manifest=json.loads(Path(manifest_path).read_text())
        matched={s['run_id']:s for s in manifest['samples']}
        selected=[]
        for run_id,sample in matched.items():
            source=Path(sample['source_record'])
            r=json.loads(source.read_text())
            if r['run_id']!=run_id or r.get('evidence_class')!='live_http':raise ValueError('Manifest run identity/evidence mismatch')
            records[run_id]=source
            if r['status']=='success' and r.get('audio_analysis',{}).get('analysis_status')=='measured_pcm' and r.get('audio_file'):selected.append(r)
        texts={}
        for r in selected:
            sample=matched[r['run_id']]
            if sample['text']!=r['text']: raise ValueError('Manifest text differs from saved run')
            key=(sample['language'],sample['stratum'])
            if key in texts and texts[key]!=r['text']: raise ValueError('Unmatched text within requested matched stratum')
            texts[key]=r['text']
    if not selected: raise ValueError('No eligible audio recordings')
    token=hashlib.sha256(':'.join(sorted(r['run_id'] for r in selected)).encode()).hexdigest()[:12]
    destination=ROOT/'artifacts/listening'/(('matched-' if manifest_path else 'exploratory-')+token)/'public'
    if destination.exists(): raise SystemExit('This exact recording inventory is already packaged; preserve its private mapping')
    groups=sorted({(r['provider'],r['config']['model']) for r in selected})
    random.Random(4817).shuffle(groups)
    group_codes={pair:'System '+str(n+1).zfill(2) for n,pair in enumerate(groups)}
    with tempfile.TemporaryDirectory() as temp:
        items=[]
        for r in selected:
            source_record=records[r['run_id']];source=source_record.parent/r['audio_file'];analysis=r['audio_analysis']
            if source.suffix=='.wav':
                with wave.open(str(source),'rb') as original:
                    if original.getsampwidth()!=2: raise ValueError('Only reviewed PCM16 supported')
                    frames=original.readframes(original.getnframes())
            else:frames=source.read_bytes()
            clean=Path(temp)/(r['run_id']+'.wav')
            with wave.open(str(clean),'wb') as output:
                output.setnchannels(analysis['channels']);output.setsampwidth(2);output.setframerate(analysis['sample_rate']);output.writeframes(frames)
            items.append({'id':r['run_id'],'audio_file':str(clean),'language':r['language'],'text':r['text'],
                'provider':r['provider'],'model':r['config']['model'],'config':r['config'],
                'anonymous_model_group':group_codes[(r['provider'],r['config']['model'])],
                'source_record':str(source_record),'source_audio':str(source),'source_pcm_sha256':hashlib.sha256(frames).hexdigest(),
                'code_sha256':r['code_sha256'],'vendor_spec_sha256':r['vendor_spec_sha256'],
                'sample_stratum':matched[r['run_id']]['stratum'] if manifest_path else r.get('stratum','unspecified'),
                'scope':'exploratory_matched_text; no certified ranking' if manifest_path else 'exploratory_unmatched; no fair-ranking claim'})
        prepare_study(items,destination,seed=4817)
        key_path=destination.parent/(destination.name+'-private-key.json')
        mapping=json.loads(key_path.read_text())
        # Temporary staging paths must not remain as provenance references.
        for item in mapping.values():item['audio_file']=item['source_audio']
        key_path.write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
        outcome=write_listening_page(destination,{k:v['anonymous_model_group'] for k,v in mapping.items()},matched_text=bool(manifest_path),
            sample_strata={k:v['sample_stratum'] for k,v in mapping.items()} if manifest_path else None)
    outcome.update(public_directory=str(destination),private_key=str(key_path),inventory_issues=issues,
        scope='Exploratory matched-text recordings. No ratings generated. Host only the public directory.' if manifest_path else 'Exploratory unmatched recordings. No ratings generated. Host only the public directory.')
    (destination.parent/'package-status.json').write_text(json.dumps(outcome,indent=2)+'\n')
    print(json.dumps(outcome,indent=2))
    return outcome

if __name__=='__main__':build(sys.argv[1] if len(sys.argv)>1 else None)
