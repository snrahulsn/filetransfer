"""Bounded tests after explicitly authorized TTS-scope credential creation."""
import asyncio,json,os,sys,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
async def main():
 out=ROOT/'artifacts/access-20260915/gnani-tts-key.json'
 if out.exists():raise SystemExit('Existing TTS-key probe retained; refusing automatic repeat')
 c=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');key=c.get('GNANI_API_KEY_ID')
 if not key:raise SystemExit('Canonical GNANI_API_KEY_ID unavailable')
 if c.get('Gnani')==key:raise SystemExit('Canonical credential still matches older alias; no auth retry')
 result={'provider':'gnani','credential_alias':'GNANI_API_KEY_ID','credential_scope':'TTS only, explicitly created by user-authorized browser action','accessed':'2026-09-15','previous_STT_key_untouched':True,'scope':'Current Timbre2.5 access tests; no native quality or billing certification','attempts':[],'automatic_retries':0}
 def save():out.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),c)+'\n')
 errors=[]
 async def hook(response):
  if response.status_code>=400:
   await response.aread();errors.append({'http_status':response.status_code,'message':redact(response.text,c)[:1500]})
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  # Public vendor voice discovery, not an invented authenticated voice endpoint.
  u='https://docs.gnani.ai/api/TTS/available-voices.md';r=await client.get(u)
  selected=[('hi-IN','Bhavna','नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।'),('en-IN','Kaveri','Hello, we have received your payment. Thank you.'),('ta-IN','Asmita','வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி.')]
  result['discovery']={'url':u,'http_status':r.status_code,'kind':'official_documented_voice_catalog','sha256':hashlib.sha256(r.content).hexdigest(),'selected':[{'language':l,'voice':v} for l,v,t in selected]};save()
  if r.status_code!=200 or any(v not in r.text or l not in r.text for l,v,t in selected):result['blocker']='documented_voice_discovery_failed';save();return
  os.environ['GNANI_API_KEY_ID']=key
  try:
   for lang,voice,text in selected:
    assert len(text)<=140
    errors.clear();config={'model':'timbre-v2.5','voice':voice,'language':lang,'format':'wav','sample_rate':24000}
    rec=await run_one('gnani',text,config,ROOT/'artifacts/runs/gnani-tts-key-20260915',timeout=30,client=client,scenario_id='tts-scope-access-'+lang,stratum='draft_access_probe')
    a={k:rec.get(k) for k in ['run_id','status','http_status','error_type','language','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms']};a.update(config=config,diagnostics=list(errors));result['attempts'].append(a);save();print('gnani',lang,rec['status'],'HTTP',rec.get('http_status'),flush=True)
    if rec['status']!='success':result['blocker']='synthesis_failed';break
  finally:os.environ.pop('GNANI_API_KEY_ID',None)
 result['successful_syntheses']=sum(a['status']=='success' for a in result['attempts']);result['native_quality']='not_evaluated';save()
 summary=ROOT/'artifacts/access-20260915/gnani.json';old=json.loads(summary.read_text());old.setdefault('attempts',[]).extend(result['attempts']);old['credential_scope_update']='New canonical TTS-only key tested; prior STT-scope failure retained';old['required_action']='Native quality and broader feature/load/billing evaluation pending' if result['successful_syntheses'] else 'Current TTS credential still blocked; see latest probe';old['latest_probe']='artifacts/access-20260915/gnani-tts-key.json';old['successful_syntheses']=sum(a['status']=='success' for a in old['attempts']);old['current_access']='synthesis_confirmed' if result['successful_syntheses'] else 'blocked';summary.write_text(redact(json.dumps(old,ensure_ascii=False,indent=2),c)+'\n')
if __name__=='__main__':asyncio.run(main())
