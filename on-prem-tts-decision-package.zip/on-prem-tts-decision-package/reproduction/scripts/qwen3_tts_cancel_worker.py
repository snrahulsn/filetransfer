"""Worker used by the Qwen process-cancellation probe.

The released qwen-tts wrapper does not expose playable audio chunks or a
per-request cancellation method. A production fallback is therefore to isolate
generation in a worker process, stop playout immediately, terminate the worker,
and discard any batch result. This worker emits a readiness marker only after
the model and reference prompt are loaded.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import torch
from qwen_tts import Qwen3TTSModel


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--reference-text", required=True)
    parser.add_argument("--ready", type=Path, required=True)
    args = parser.parse_args()
    model = Qwen3TTSModel.from_pretrained(
        "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
        device_map="cuda:0",
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    )
    prompt = model.create_voice_clone_prompt(
        ref_audio=str(args.reference), ref_text=args.reference_text,
        x_vector_only_mode=False,
    )
    args.ready.write_text(json.dumps({
        "pid": os.getpid(), "ready_monotonic_ns": time.monotonic_ns()
    }) + "\n", encoding="utf-8")
    model.generate_voice_clone(
        text=("Please hold while I check your account details. " * 50).strip(),
        language="English",
        voice_clone_prompt=prompt,
        non_streaming_mode=True,
        max_new_tokens=2048,
    )


if __name__ == "__main__":
    main()
