"""Publish the reviewed recent-feedback triage without local paths or analyst internals."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/feedback-20260915/triage.json"
OUTPUT = ROOT / "ui/public/evidence/recent-feedback.json"

def build():
    source = json.loads(SOURCE.read_text())
    allowed = {"provider_id", "name", "catalog_models", "quality_triage", "quality_evidence", "model_mapping_gap", "source_ids", "severe_current_hindi_complaint_consensus"}
    entries = [{key: row[key] for key in allowed} for row in source["entries"]]
    sources = {key: {field: value[field] for field in ("title", "url", "date_and_limit")} for key, value in source["sources"].items()}
    payload = {
        "schema_version": 1,
        "reviewed_at": source["reviewed_at"],
        "recent_window_start": source["recent_window_start"],
        "scope": source["scope"],
        "decision": source["decision"],
        "method": "Primary-agent source review plus an independent Grok critique of the saved evidence packet. Exact model mapping is retained; isolated user reports are not consensus.",
        "entries": entries,
        "sources": sources,
    }
    encoded = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if "/Users/" in encoded or "working_api_tokens" in encoded:
        raise ValueError("Feedback export contains a local path or credential-file reference")
    if len(entries) != 32 or len({row["provider_id"] for row in entries}) != 32:
        raise ValueError("Feedback export provider inventory changed")
    OUTPUT.write_text(encoded)
    print(json.dumps({"entries": len(entries), "sources": len(sources)}))
    return payload

if __name__ == "__main__":
    build()
