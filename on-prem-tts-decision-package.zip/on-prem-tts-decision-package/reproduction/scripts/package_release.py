"""Run the final gates, then bind catalog report and attestations to the same source hash."""
import json
import hashlib
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from tts_arena.registry import catalog,validate,code_digest
from tts_arena.certification import self_test,attest
from tts_arena.reporting import build_report
from tts_arena.live_evidence import load_live_runs,summarize_live_runs
from tts_arena.evidence_inventory import inventory
from tts_arena.language_review_evidence import verify as verify_language_review

items=catalog()
errors={p['id']:validate(p) for p in items if validate(p)}
if errors: raise SystemExit(json.dumps(errors))
tests=self_test(ROOT/'artifacts/verification')
if not tests['passed']: raise SystemExit('Tests failed; inspect artifacts/verification/tests.txt')
report=build_report(ROOT/'artifacts/report',tests)
assert report['offline_evidence_current']
live_runs,live_issues=load_live_runs(ROOT/'artifacts')
live=summarize_live_runs(live_runs,code_digest(),items)
attestations=[attest(p['id'],tests,live_runs) for p in items]
(ROOT/'artifacts/verification/attestations.json').write_text(json.dumps(attestations,indent=2)+'\n')
evidence_inventory=inventory(ROOT)
if evidence_inventory['issues']: raise SystemExit(json.dumps(evidence_inventory['issues']))
emotion_public=ROOT/'artifacts/emotion-study-20260915-v4/public'
emotion_qa=json.loads((ROOT/'artifacts/emotion-ui-qa-20260915/verification.json').read_text())
emotion_page_current=hashlib.sha256((emotion_public/'index.html').read_bytes()).hexdigest()==emotion_qa['page_sha256']
transcript_preparation=json.loads((ROOT/'artifacts/transcript-references-20260915/status.json').read_text())
indic_pilot=json.loads((ROOT/'artifacts/indic-asr-pilot-20260915/result-summary.json').read_text())
urdu_cross=json.loads((ROOT/'artifacts/indic-asr-pilot-20260915/urdu-crosscheck.json').read_text())
veena_operation=json.loads((ROOT/'artifacts/runpod/veena-20260915/operation.json').read_text())
veena_asr=json.loads((ROOT/'artifacts/runpod/veena-20260915/asr-diagnostics.json').read_text())
if veena_operation['actual_delete_http_status']!=204 or veena_operation['post_delete_pod_inventory_count']!=0 or len(veena_asr['observations'])!=3:
    raise SystemExit('Veena smoke lifecycle or ASR inventory inconsistent')
if indic_pilot['records']!=24 or indic_pilot['locales']!=10 or urdu_cross['records']!=2:
    raise SystemExit('ASR pilot evidence count inconsistent')
language_tooling={
    'indic_full_review':{'package_audit':verify_language_review(ROOT),
                         'rating_dimensions':['naturalness','accent','intelligibility','text_fidelity'],
                         'offline_ingestion':'scripts/ingest_language_review.py',
                         'qualification_gate':'independent native-language roster and audio-bound reviewed reference',
                         'native_ratings':0,'vendor_certifications':0,
                         'documentation':'docs/LISTENING_STUDY_STATUS.md'},
    'emotion':{'samples':len(json.loads((emotion_public/'items.json').read_text())),
               'interface':'offline_blinded_staged_ratings',
               'browser_qa_matches_page':emotion_page_current,
               'documentation':'docs/EMOTION_QUALIFICATION.md',
               'native_ratings':0},
    'transcripts':{'draft_references':transcript_preparation['references'],
                   'native_reviewed_references':transcript_preparation['native_reviewed_references'],
                   'observations_created':indic_pilot['records']+urdu_cross['records'],
                   'asr_pilot_recordings':indic_pilot['records'],
                   'asr_pilot_locales':indic_pilot['locales'],
                   'urdu_second_engine_recordings':urdu_cross['records'],
                   'scoring':'NFC-only WER/CER; exact model/locale, human/ASR and ASR engine separated',
                   'documentation':'docs/INDIC_ASR_PILOT_STATUS.md'}}
status={"code_sha256":code_digest(),"candidates":len(items),"companies":report['companies'],"open_models":report['open_models'],
        "scoped_request_or_local_adapters":sum(p['integration_status']=='implemented' for p in items),
        "blocked_candidates":[p['id'] for p in items if p['integration_status']=='blocked' and p.get('assessment_status')!='user_skipped'],
        "user_skipped_candidates":[p['id'] for p in items if p.get('assessment_status')=='user_skipped'],
        "native_session_plugins":sorted(p.stem for p in (ROOT/'tts_arena/sessions').glob('*.py') if not p.stem.startswith('_')),"source_snapshots":evidence_inventory["verified_source_captures"],
        "separate_evidence_inventory":evidence_inventory,
        "evidence_documents":{"http_access":"docs/LIVE_ACCESS_STATUS.md","native_sessions":"docs/LIVE_SESSION_STATUS.md","browser_access":"docs/BROWSER_ACCESS_STATUS.md","regional_coverage":"docs/REGIONAL_COVERAGE_STATUS.md","listening_preparation":"docs/LISTENING_STUDY_STATUS.md"},
        "offline_tests":tests['tests_run'],"offline_tests_passed":tests['passed'],"skipped":tests['skipped'],
        "live_vendor_runs":live['historical_attempts'],"live_vendor_successes":live['historical_successes'],
        "live_evidence":live,"live_evidence_inventory_issues":live_issues,
        "native_listener_ratings":0,"production_calls":0,"vendor_certifications":0,
        "language_evaluation_tooling":language_tooling,
        "maya_veena_cuda_smoke":{"model":"maya-research/Veena","batch_audio_files":3,"asr_diagnostics":3,"production_qualification":False,"pod_deleted":True,"documentation":"docs/MAYA_LOCAL_IMPLEMENTATION.md"},
        "prompt_onboarding":"real isolated GPT-5.5 Inworld reconstruction passed discovery/catalog and492 outer tests; initial default-model CLI failure preserved; protection guard added afterward; arbitrary new vendors unqualified",
        "draft_corpus_items":sum(1 for line in (ROOT/'corpus/seed.jsonl').read_text().splitlines() if line.strip()),
        "prerequisites":['Remaining vendor credentials and account/model/voice permissions; see docs/LIVE_ACCESS_STATUS.md','Navana skipped by user; TTS API specification/access needed before resuming','Pinned local model files and optional runtimes','Production bot/telephony bridge and invariant manifests','Consented native recordings and qualified reviewers','Target traffic/load/SLA and billing exports'],
        "remaining_engineering":['Additional vendor-native streaming/SDK protocols and unimplemented controls','Production codec/carrier capture integration','Automated language alignment/entity evaluation validated by native labels','Crossed item/listener analysis, balanced-study design and hosted study integration','Broader fault-injection and production workload distributions','End-to-end prompt onboarding qualification']}
(ROOT/'artifacts/verification/release-status.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps({"code_sha256":status["code_sha256"],"candidates":status["candidates"],"offline_tests":status["offline_tests"],"skipped":status["skipped"],"source_snapshots":status["source_snapshots"],"inventory_issues":len(status["separate_evidence_inventory"]["issues"])},indent=2))
