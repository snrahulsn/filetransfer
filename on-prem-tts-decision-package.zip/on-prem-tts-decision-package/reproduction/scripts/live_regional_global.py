"""At most twelve authorized current-model regional delivery probes; no retries."""
import asyncio,json,os,sys,wave,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from scripts.live_regional_india import TEXT
from tts_arena.credentials import read_credentials,redact
from tts_arena.live_evidence import load_live_runs
from tts_arena.registry import build_request,digest
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/regional-global-20260915'
REPORT=ROOT/'docs/REGIONAL_GLOBAL_COVERAGE_STATUS.md'
REQUEST_LIMIT=12
PER_PROVIDER_LIMIT=6
TIMEOUT=30
INTER_REQUEST_SECONDS=1
EXPLICIT_RECOVERY={}
PROVIDERS={'google':('gemini-3.1-flash-tts-preview','GOOGLE_API_KEY','https://ai.google.dev/gemini-api/docs/speech-generation'),
           'elevenlabs':('eleven_v3','ELEVENLABS_API_KEY','https://elevenlabs.io/docs/overview/models')}
NAMES={'bn-IN':'Bengali','mr-IN':'Marathi','te-IN':'Telugu','ta-IN':'Tamil','gu-IN':'Gujarati','kn-IN':'Kannada','ml-IN':'Malayalam'}
LOCALES=['en-IN','hi-IN',*TEXT,'ur-IN']

async def main():
    def disk_preflight():
        if shutil.disk_usage(ROOT).free<500*1024*1024:raise RuntimeError('At least500MiB free required before a live request')
    disk_preflight()
    if OUT.exists():raise RuntimeError('Bounded batch already started; no automatic repeat')
    rows,issues=load_live_runs(ROOT/'artifacts')
    credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    evidence={'scope':'Draft regional audio delivery; language correctness, naturalness and native accent unknown',
              'created_date':'2026-09-15','max_requests':REQUEST_LIMIT,'automatic_retries':0,'native_reviews':0,'timeout_seconds':TIMEOUT,'minimum_free_disk_bytes':500*1024*1024,'explicit_recovery_authorizations':EXPLICIT_RECOVERY,
              'reference_text_source':'scripts/live_regional_india.py TEXT; existing synthetic unreviewed fixtures',
              'prior_inventory_issues':issues,'providers':{},'attempts':[]}
    jobs=[]
    for provider,(model,key,source) in PROVIDERS.items():
        prior=[r for r in rows if r.get('provider')==provider and r.get('config',{}).get('model')==model]
        working=[r for r in prior if r.get('status')=='success']
        if not working:raise ValueError('No known successful current-model configuration')
        states={locale:{'support':'documented_base_language_not_regional_accent','status':'audio_returned' if any(r.get('language')==locale for r in working) else 'failed' if any(r.get('language')==locale for r in prior) else 'not_tested',
                        'prior_run_ids':[r['run_id'] for r in prior if r.get('language')==locale],'linguistic_accuracy':'unverified'} for locale in LOCALES}
        selected=[locale for locale in TEXT if not states[locale]['prior_run_ids'] or (locale in EXPLICIT_RECOVERY.get(provider,{}) and states[locale]['status']!='audio_returned')][:PER_PROVIDER_LIMIT]
        evidence['providers'][provider]={'model':model,'source':source,'source_accessed':'2026-09-15','locales':states,'selected_locales':selected,'stopped_on_error':False}
        for locale in selected:
            config=dict(working[0]['config']);config['language']=locale
            if provider=='google':config['instructions']='Read the following text naturally in '+NAMES[locale]+'.'
            text=TEXT[locale];assert len(text)<=100
            # Validate every exact planned request before sending any of this batch.
            os.environ[key]=credentials[key]
            try:spec=build_request(provider,text,config)
            finally:os.environ.pop(key,None)
            jobs.append((provider,locale,text,config,digest(spec.body),working[0]['run_id']))
        for locale,state in states.items():
            if state['status']=='not_tested' and locale not in selected:
                state['reason']='Not selected within twelve-request batch or lacks an existing regional draft snippet; not an unsupported-language finding.'
    assert len(jobs)<=REQUEST_LIMIT
    OUT.mkdir(exist_ok=False)
    def save():
        temporary=OUT/'coverage.json.tmp'
        with temporary.open('w') as output:
            output.write(redact(json.dumps(evidence,ensure_ascii=False,indent=2),credentials)+'\n');output.flush();os.fsync(output.fileno())
        os.replace(temporary,OUT/'coverage.json')
    save()
    for provider,(_,key,_) in PROVIDERS.items():
        errors=[]
        async def hook(response):
            if response.status_code>=400:
                await response.aread();errors.append({'http_status':response.status_code,'message':redact(response.text,credentials)[:1500]})
        os.environ[key]=credentials[key]
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
                for _,locale,text,config,body_hash,prior_id in [j for j in jobs if j[0]==provider]:
                    disk_preflight()
                    attempt={'provider':provider,'locale':locale,'text':text,'config':config,'request_body_sha256':body_hash,'prior_config_run_id':prior_id,'status':'request_started','explicit_recovery_reason':EXPLICIT_RECOVERY.get(provider,{}).get(locale)}
                    evidence['attempts'].append(attempt);save();errors.clear()
                    record=await run_one(provider,text,config,OUT/'runs'/provider,timeout=TIMEOUT,client=client,scenario_id='regional-'+locale,evaluation_language=locale,stratum='draft_regional_audio_delivery')
                    attempt.update({k:record.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','duration_seconds','audio_sha256','first_audio_ms','audio_analysis')})
                    attempt['diagnostics']=errors.copy();attempt['linguistic_accuracy']='unverified'
                    state=evidence['providers'][provider]['locales'][locale]
                    state.update(status='audio_returned' if record['status']=='success' else 'failed',run_id=record['run_id'])
                    folder=OUT/'runs'/provider/record['run_id'];attempt['record']=str((folder/'result.json').relative_to(ROOT))
                    if record['status']=='success':
                        data=(folder/record['audio_file']).read_bytes();audio=folder/'listen.wav'
                        with wave.open(str(audio),'wb') as wav:wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(24000);wav.writeframes(data)
                        attempt['listening_audio']=str(audio.relative_to(ROOT))
                    save();print(provider+' '+locale+' '+record['status']+' HTTP '+str(record.get('http_status')),flush=True)
                    if record['status']!='success':evidence['providers'][provider]['stopped_on_error']=True;save();break
                    await asyncio.sleep(INTER_REQUEST_SECONDS)
        finally:os.environ.pop(key,None)
    evidence['completed']=True;evidence['requests_sent']=len(evidence['attempts']);evidence['audio_returned']=sum(a['status']=='success' for a in evidence['attempts']);save()
    lines=['# Gemini 3.1 and Eleven v3 regional delivery','',
           'One bounded batch, 2026-09-15. Existing Hindi/English and Gemini Tamil evidence was retained; no duplicate locale requests were sent. Texts are existing synthetic draft snippets without native review. Audio delivery does not establish language correctness, accent or naturalness. No legacy model or alternate voice fallback was used.','',
           f"Requests: {evidence['requests_sent']}; audio returned: {evidence['audio_returned']}. No retries.",'',
           '| Provider | Locale | State | Audio |','|---|---|---|---|']
    for provider,detail in evidence['providers'].items():
        for locale,state in detail['locales'].items():
            attempt=next((a for a in evidence['attempts'] if a['provider']==provider and a['locale']==locale),{})
            link='[Listen](../'+attempt['listening_audio']+')' if attempt.get('listening_audio') else 'Prior evidence' if state['prior_run_ids'] else 'Not sent'
            lines.append(f"| {provider} | {locale} | {state['status']} | {link} |")
    lines+=['','Google uses automatic language detection plus an explicit language instruction with Kore. Eleven v3 uses the established Bella preset and base-language enforcement; neither voice configuration is independently native-accent qualified. Urdu on both providers and Eleven Malayalam remain outside this batch, not unsupported.',
            '', '[Complete coverage and exact run references](../artifacts/regional-global-20260915/coverage.json). Prior hashes remain unchanged.',
            '', 'Primary sources accessed 2026-09-15: [Gemini TTS language list](https://ai.google.dev/gemini-api/docs/speech-generation), [Eleven v3 model languages](https://elevenlabs.io/docs/overview/models).']
    REPORT.write_text('\n'.join(lines)+'\n')

if __name__=='__main__':asyncio.run(main())
