"""Add requested-text WebVTT cues for the decision book's saved audio.

The cue explicitly labels the text as unverified; no word alignment is claimed.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "ui/public"
SNAPSHOT = json.loads((PUBLIC / "evidence/snapshot.json").read_text())
CAPTIONS = PUBLIC / "evidence/captions"
CAPTIONS.mkdir(parents=True, exist_ok=True)


def timestamp(seconds: float) -> str:
    millis = int(max(seconds, 0.1) * 1000)
    return f"{millis // 3_600_000:02d}:{millis // 60_000 % 60:02d}:{millis // 1000 % 60:02d}.{millis % 1000:03d}"


rows = [*SNAPSHOT["runs"], *SNAPSHOT["local_runs"], *SNAPSHOT["maya_local_runs"], *SNAPSHOT["native_audio_runs"], *SNAPSHOT.get("studio_audio_runs", [])]
seen: dict[str, tuple[str, float]] = {}
for row in rows:
    url = row.get("audio_url")
    if not url:
        continue
    if not url.startswith("/evidence/audio/") or not url.endswith(".wav"):
        raise ValueError(f"Unexpected public audio URL: {url}")
    text = " ".join(str(row.get("text", "")).split())
    if not text:
        raise ValueError(f"Missing requested text for {url}")
    duration = float(row["duration_seconds"])
    if url in seen and seen[url][0] != text:
        raise ValueError(f"Conflicting requested texts for {url}")
    seen[url] = (text, duration)

for url, (text, duration) in seen.items():
    audio = PUBLIC / url.lstrip("/")
    if not audio.exists():
        raise FileNotFoundError(audio)
    dest = CAPTIONS / (audio.stem + ".vtt")
    dest.write_text(
        f"WEBVTT\n\n00:00:00.000 --> {timestamp(duration)}\n"
        f"Requested text (unverified transcript): {text}\n",
        encoding="utf-8",
    )

print(f"{len(seen)} requested-text caption files")
