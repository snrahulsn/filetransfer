"""Bounded read-only account subscription check; do not infer per-run cost."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials

URL = 'https://api.elevenlabs.io/v1/user/subscription'
CREDENTIALS = Path('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
OUTPUT = ROOT / 'artifacts/elevenlabs-usage-20260915/subscription-sanitized.json'
SOURCE = 'https://elevenlabs.io/docs/api-reference/user/subscription/get'


def sanitize(payload):
    if not isinstance(payload, dict):
        raise ValueError('Subscription response must be an object')
    integer_fields = ('character_count', 'character_limit', 'next_character_count_reset_unix')
    result = {}
    for field in integer_fields:
        value = payload.get(field)
        if value is not None and (type(value) is not int or value < 0):
            raise ValueError(f'Invalid {field}')
        result[field] = value
    for field in ('tier', 'status', 'currency', 'billing_period', 'character_refresh_period'):
        value = payload.get(field)
        if value is not None and (not isinstance(value, str) or len(value) > 80):
            raise ValueError(f'Invalid {field}')
        result[field] = value
    for field in ('can_extend_character_limit', 'has_open_invoices'):
        value = payload.get(field)
        if value is not None and type(value) is not bool:
            raise ValueError(f'Invalid {field}')
        result[field] = value
    overage = payload.get('current_overage')
    if overage is not None:
        if not isinstance(overage, dict):
            raise ValueError('Invalid current_overage')
        try:
            amount = Decimal(str(overage.get('amount')))
        except (InvalidOperation, TypeError):
            raise ValueError('Invalid current_overage amount') from None
        currency = overage.get('currency')
        if not amount.is_finite() or amount < 0 or not isinstance(currency, str) or len(currency) > 12:
            raise ValueError('Invalid current_overage amount/currency')
        result['current_overage'] = {'amount': str(amount), 'currency': currency}
    else:
        result['current_overage'] = None
    result.update(provider='elevenlabs', source=SOURCE, endpoint=URL,
                  money_cost_verified=False,
                  limitation='Account aggregate subscription state; no request-level invoice allocation or generated-minute price.')
    return result


def fetch(key, opener=urlopen):
    request = Request(URL, headers={'xi-api-key': key, 'Accept': 'application/json'})
    try:
        with opener(request, timeout=20) as response:
            if response.status != 200:
                raise ValueError(f'Subscription HTTP status {response.status}')
            raw = response.read(1_000_001)
    except HTTPError as error:
        raise ValueError(f'Subscription HTTP status {error.code}') from None
    except URLError:
        raise ValueError('Subscription transport failure') from None
    if len(raw) > 1_000_000:
        raise ValueError('Subscription response too large')
    return sanitize(json.loads(raw))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    if not args.live:
        print(json.dumps({'status': 'preflight', 'endpoint': URL, 'requests': 0,
                          'request_cap': 1, 'automatic_retries': 0, 'money_cost_verified': False}))
        return
    if OUTPUT.exists():
        raise SystemExit('Output exists; do not repeat the account request')
    key = read_credentials(str(CREDENTIALS)).get('ELEVENLABS_API_KEY')
    if not key:
        raise SystemExit('ElevenLabs credential unavailable')
    result = fetch(key)
    result['observed_at'] = datetime.now(timezone.utc).isoformat()
    result['request_count'] = 1
    result['automatic_retries'] = 0
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'saved_sanitized_subscription', 'billing_period': result['billing_period'],
                      'has_open_invoices': result['has_open_invoices'], 'money_cost_verified': False,
                      'request_count': 1}))


if __name__ == '__main__':
    main()
