"""No-retry, capped Hindi Bulbul v3 HTTP-stream versus WebSocket MP3 trial."""
import asyncio
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import wave
from datetime import datetime, timezone
from pathlib import Path

import httpx
from websockets.asyncio.client import connect

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from live_matched_latency_balanced import egress_country
from live_matched_latency_bounded import TEXT
from tts_arena.credentials import read_credentials
from tts_arena.sessions import sarvam

OUT = ROOT / 'artifacts/sarvam-transport-latency-20260916-v2'
ROUNDS = 12
ORDER = [('http_stream', 'websocket') if i % 2 == 0 else ('websocket', 'http_stream') for i in range(ROUNDS)]
CONFIG = {'model': 'bulbul:v3', 'language': 'hi-IN', 'speaker': 'shubh',
          'format': 'mp3', 'sample_rate': 24000, 'pace': 1.0, 'temperature': 0.6}
REST_URL = 'https://api.sarvam.ai/text-to-speech/stream'
MAX_CHARACTERS = 3000
MAX_LIST_RUPEES = 10.0


def preflight(key):
    spec = sarvam.build_session(CONFIG, {'SARVAM_API_KEY': key})
    text_message = sarvam.encode_action({'type': 'text', 'text': TEXT}, CONFIG)
    if spec.encoding != 'mp3' or spec.sample_rate != 24000 or len(text_message) != 1:
        raise ValueError('WebSocket audio or text contract mismatch')
    if len(TEXT) * 2 * ROUNDS > MAX_CHARACTERS or len(TEXT) * 2 * ROUNDS * 30 / 10000 > MAX_LIST_RUPEES:
        raise ValueError('Text/list-rate trial cap exceeded')
    body = {'text': TEXT, 'model': CONFIG['model'], 'language_code': CONFIG['language'],
            'speaker': CONFIG['speaker'], 'pace': CONFIG['pace'],
            'temperature': CONFIG['temperature'], 'speech_sample_rate': 24000,
            'output_audio_codec': 'mp3', 'output_audio_bitrate': '128k',
            'enable_preprocessing': False, 'enable_cached_responses': False}
    return body, spec


def persist_audio(directory, audio):
    if not audio or len(audio) > 2_000_000:
        raise ValueError('Bounded nonempty MP3 audio required')
    directory.mkdir(parents=True, exist_ok=False)
    original = directory / 'audio.mp3'
    original.write_bytes(audio)
    wav = directory / 'audio.wav'
    completed = subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                                '-i', str(original), '-ac', '1', '-ar', '24000',
                                '-c:a', 'pcm_s16le', str(wav)],
                               capture_output=True, timeout=15, check=True)
    with wave.open(str(wav), 'rb') as reader:
        if reader.getnchannels() != 1 or reader.getsampwidth() != 2 or reader.getframerate() != 24000 or reader.getnframes() < 2400:
            raise ValueError('Decoded audio is not playable mono 24 kHz PCM16')
        duration = reader.getnframes() / 24000
    return {'mp3_bytes': len(audio), 'mp3_sha256': hashlib.sha256(audio).hexdigest(),
            'wav_sha256': hashlib.sha256(wav.read_bytes()).hexdigest(),
            'duration_seconds': duration,
            'mp3_path': str(original.relative_to(ROOT)), 'wav_path': str(wav.relative_to(ROOT))}


async def http_attempt(key, body, directory):
    started = time.perf_counter_ns()
    first = None
    chunks = []
    limits = httpx.Limits(max_connections=1, max_keepalive_connections=0)
    async with httpx.AsyncClient(timeout=httpx.Timeout(20, connect=8), limits=limits,
                                 trust_env=False, follow_redirects=False) as client:
        async with client.stream('POST', REST_URL,
                                 headers={'api-subscription-key': key, 'Accept': 'audio/mpeg'},
                                 json=body) as response:
            status = response.status_code
            if status != 200:
                return {'status': 'vendor_error', 'http_status': status}
            if 'audio/mpeg' not in response.headers.get('content-type', ''):
                raise ValueError('HTTP stream content type is not MP3')
            async with asyncio.timeout(18):
                async for chunk in response.aiter_raw():
                    if chunk:
                        if first is None:
                            first = (time.perf_counter_ns() - started) / 1e6
                        chunks.append(chunk)
                        if sum(map(len, chunks)) > 2_000_000:
                            raise ValueError('MP3 stream exceeded byte cap')
    if first is None:
        raise ValueError('HTTP stream yielded no MP3 bytes')
    return {'status': 'success', 'http_status': 200, 'first_audio_ms': first,
            'received_chunk_bytes': [len(c) for c in chunks],
            **persist_audio(directory, b''.join(chunks))}


async def websocket_attempt(key, spec, directory):
    started = time.perf_counter_ns()
    first = None
    chunks = []
    terminal = False
    async with connect(spec.url, additional_headers=spec.headers, proxy=None,
                       open_timeout=8, max_size=2_000_000) as ws:
        for message in [*spec.initial_messages,
                        *sarvam.encode_action({'type': 'text', 'text': TEXT}, CONFIG),
                        *sarvam.encode_action({'type': 'flush'}, CONFIG)]:
            await ws.send(json.dumps(message, ensure_ascii=False))
        async with asyncio.timeout(18):
            async for raw in ws:
                for event in sarvam.decode_message(raw):
                    if event['type'] == 'audio':
                        if first is None:
                            first = (time.perf_counter_ns() - started) / 1e6
                        chunks.append(event['audio'])
                        if sum(map(len, chunks)) > 2_000_000:
                            raise ValueError('MP3 stream exceeded byte cap')
                    elif event['type'] == 'done':
                        terminal = True
                        break
                    elif event['type'] == 'error':
                        return {'status': 'vendor_error', 'provider_code': event['metadata']['provider_code']}
                if terminal:
                    break
    if first is None or not terminal:
        raise ValueError('WebSocket lacked MP3 or final event')
    return {'status': 'success', 'first_audio_ms': first,
            'received_chunk_bytes': [len(c) for c in chunks], 'terminal_observed': True,
            **persist_audio(directory, b''.join(chunks))}


async def live():
    if OUT.exists():
        raise FileExistsError('Sarvam transport trial already attempted; no repeat spend')
    if shutil.disk_usage(ROOT).free < 300 * 1024 * 1024:
        raise OSError('Evidence disk floor not met')
    key = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('SARVAM_API_KEY')
    if not key:
        raise ValueError('Working Sarvam key unavailable')
    body, spec = preflight(key)
    async with httpx.AsyncClient(timeout=10, trust_env=False) as probe:
        start_country = await egress_country(probe)
    if start_country != 'IN':
        raise ValueError('India egress requirement absent before vendor requests')
    OUT.mkdir(parents=True, exist_ok=False)
    manifest = {'schema': 'sarvam_bulbul_v3_mp3_balanced_transport_v1',
                'created_at': datetime.now(timezone.utc).isoformat(),
                'provider': 'sarvam', 'model': 'bulbul:v3', 'language': 'hi-IN',
                'voice': 'shubh', 'text': TEXT, 'text_sha256': hashlib.sha256(TEXT.encode()).hexdigest(),
                'rest_request': {k: v for k, v in body.items() if k != 'text'},
                'websocket_config': spec.initial_messages[0], 'order': ORDER,
                'repetitions_per_route': ROUNDS, 'max_vendor_requests': 24,
                'max_text_characters': MAX_CHARACTERS,
                'published_list_rate_rupees_per_10000_characters': 30,
                'published_rate_trial_cap_rupees': MAX_LIST_RUPEES,
                'account_specific_cost_verified': False,
                'automatic_retries': 0, 'attempts_total': 0, 'successful': {'http_stream': 0, 'websocket': 0},
                'client_egress_country_start': start_country, 'client_egress_country_end': None,
                'client_policy': 'one host; no proxy; fresh TCP/TLS each attempt; sequential 0.7s pacing',
                'latency_boundary': 'fresh request/connect start to first received MP3 bytes',
                'serving_region': 'not independently pinned', 'status': 'running', 'results': []}
    def save():
        temporary = OUT / 'manifest.json.partial'
        temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        os.replace(temporary, OUT / 'manifest.json')
    save()
    for ordinal, routes in enumerate(ORDER, 1):
        for route in routes:
            manifest['attempts_total'] += 1
            save()
            try:
                directory = OUT / route / f'{ordinal:02d}'
                result = (await http_attempt(key, body, directory) if route == 'http_stream'
                          else await websocket_attempt(key, spec, directory))
                row = {'route': route, 'ordinal': ordinal, **result}
                manifest['results'].append(row)
                if result['status'] != 'success':
                    manifest['status'] = 'stopped_on_first_vendor_failure'
                    save()
                    return manifest
                manifest['successful'][route] += 1
                save()
            except Exception as exc:
                manifest['results'].append({'route': route, 'ordinal': ordinal,
                                            'status': 'error', 'error_type': type(exc).__name__,
                                            'error_detail': str(exc)[:160]})
                manifest['status'] = 'stopped_on_first_vendor_failure'
                save()
                return manifest
            await asyncio.sleep(.7)
    async with httpx.AsyncClient(timeout=10, trust_env=False) as probe:
        manifest['client_egress_country_end'] = await egress_country(probe)
    manifest['status'] = ('complete' if manifest['client_egress_country_end'] == start_country
                          else 'egress_country_changed')
    save()
    return manifest


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    credential = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('SARVAM_API_KEY')
    if args.live:
        observed = asyncio.run(live())
        print(json.dumps({'status': observed['status'], 'attempts': observed['attempts_total'],
                          'successful': observed['successful'], 'egress_start': observed['client_egress_country_start'],
                          'egress_end': observed['client_egress_country_end']}))
    else:
        body, spec = preflight(credential)
        print(json.dumps({'status': 'preflight_passed', 'routes': ['http_stream', 'websocket'],
                          'requests_cap': 24, 'characters_cap': MAX_CHARACTERS,
                          'estimated_list_rupees': round(len(TEXT) * 24 * 30 / 10000, 2)}))
