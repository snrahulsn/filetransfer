"""Two explicitly requested Pro comparison probes; retains standard evidence."""
import asyncio
import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials, redact
from tts_arena.runner import run_one

async def main():
    root=Path(__file__).resolve().parents[1]
    path=root/'artifacts/access-20260915/smallest.json'
    result=json.loads(path.read_text())
    if len(result['attempts'])!=3:
        raise SystemExit('Requires exactly three existing standard attempts; refusing repeated paid runs')
    creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    os.environ['SMALLEST_API_KEY']=creds['SMALLEST_API_KEY']
    for attempt in result['attempts']:
        attempt['selection_scope']='standard_model_comparison_only; not lifelike shortlist qualification'
    diagnostics=[]
    async def hook(response):
        if response.status_code>=400:
            await response.aread()
            diagnostics.append({'http_status':response.status_code,'message':redact(response.text,creds)[:1500]})
    async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={'response':[hook]}) as client:
        response=await client.get('https://api.smallest.ai/waves/v1/lightning-v3.1/get_voices',headers={'Authorization':'Bearer '+creds['SMALLEST_API_KEY']})
        response.raise_for_status()
        voices=response.json()['voices']
        # Official voice pairing source names meher as an Indian Pro voice.
        selected=[v for v in voices if v.get('voiceId')=='meher']
        result['pro_discovery']={'http_status':response.status_code,'voice_metadata':selected,
          'source':'https://docs.smallest.ai/models/documentation/text-to-speech-lightning/voices-languages',
          'voice_selection':'meher explicitly documented for lightning_v3.1_pro Indian English/Hindi; live catalog presence recorded separately'}
        for language,text in [('hi-IN','नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।'),('en-IN','Hello, we have received your payment. Thank you.')]:
            config={'model':'lightning_v3.1_pro','voice':'meher','language':language,'format':'wav','sample_rate':24000}
            diagnostics.clear()
            record=await run_one('smallest',text,config,root/'artifacts/runs/access-20260915/smallest',timeout=30,client=client,scenario_id='access-smoke-pro-'+language,stratum='draft_access_probe_pro')
            attempt={k:record.get(k) for k in ['run_id','status','http_status','error_type','language','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms','audio_analysis']}
            attempt.update(config=config,selection_scope='Pro access sample; lifelike quality not yet evaluated')
            if diagnostics: attempt['diagnostics']=diagnostics.copy()
            result['attempts'].append(attempt)
            result['successful_syntheses']=sum(a['status']=='success' for a in result['attempts'])
            path.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
            print(language+': '+record['status']+' HTTP '+str(record.get('http_status')),flush=True)
            if record['status']!='success': break
    os.environ.pop('SMALLEST_API_KEY',None)

if __name__=='__main__': asyncio.run(main())
