"""Run the pinned community Hindi LoRA on the official Qwen3-TTS Base model.

The publisher's documented wrapper-level PEFT call is incompatible with the
official Qwen wrapper. This runner applies PEFT to the underlying Transformers
model, preserves the Base model type, and uses Auto language selection because
Hindi is absent from the official release's language allow-list.
"""
from __future__ import annotations

import argparse
import json
import platform
import time
from pathlib import Path

import soundfile as sf
import torch
from huggingface_hub import hf_hub_download, snapshot_download
from peft import PeftModel
from qwen_tts import Qwen3TTSModel


BASE_ID = "Qwen/Qwen3-TTS-12Hz-1.7B-Base"
ADAPTER_ID = "aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned"
ADAPTER_REVISION = "b84766274af71506758ccf45a9965bd1d934297b"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gender", choices=("female", "male"), default="female")
    parser.add_argument("--text", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--max-new-tokens", type=int, default=2048)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    combo = f"hindi_{args.gender}"

    adapter_root = snapshot_download(
        ADAPTER_ID,
        revision=ADAPTER_REVISION,
        allow_patterns=[f"adapters/{combo}/*"],
    )
    adapter_path = str(Path(adapter_root) / "adapters" / combo)
    ref_audio = hf_hub_download(
        ADAPTER_ID, f"adapters/{combo}/ref.wav", revision=ADAPTER_REVISION
    )
    ref_text_path = hf_hub_download(
        ADAPTER_ID, f"adapters/{combo}/ref.txt", revision=ADAPTER_REVISION
    )
    ref_text = Path(ref_text_path).read_text(encoding="utf-8").strip()

    torch.cuda.reset_peak_memory_stats()
    load_started = time.perf_counter()
    model = Qwen3TTSModel.from_pretrained(
        BASE_ID,
        device_map="cuda:0",
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    )
    # Qwen3TTSModel is an inference wrapper, not a PEFT PreTrainedModel.
    model.model = PeftModel.from_pretrained(model.model, adapter_path)
    load_seconds = time.perf_counter() - load_started
    memory_after_load = torch.cuda.memory_allocated() / 1024**3

    torch.cuda.synchronize()
    synth_started = time.perf_counter()
    wavs, sample_rate = model.generate_voice_clone(
        text=args.text,
        language="Auto",
        ref_audio=ref_audio,
        ref_text=ref_text,
        non_streaming_mode=True,
        max_new_tokens=args.max_new_tokens,
    )
    torch.cuda.synchronize()
    synthesis_seconds = time.perf_counter() - synth_started
    peak_memory_gib = torch.cuda.max_memory_allocated() / 1024**3
    sf.write(args.output, wavs[0], sample_rate)
    audio, sample_rate = sf.read(args.output)
    duration_seconds = len(audio) / sample_rate

    metadata = {
        "base_model": BASE_ID,
        "adapter": ADAPTER_ID,
        "adapter_revision": ADAPTER_REVISION,
        "adapter_combo": combo,
        "language_argument": "Auto",
        "target_locale": "hi-IN",
        "target_text": args.text,
        "reference_text": ref_text,
        "reference_audio_source": f"{ADAPTER_ID}/adapters/{combo}/ref.wav",
        "output_filename": args.output.name,
        "sample_rate_hz": sample_rate,
        "duration_seconds": duration_seconds,
        "model_load_seconds": load_seconds,
        "synthesis_seconds": synthesis_seconds,
        "realtime_factor": synthesis_seconds / duration_seconds,
        "gpu_memory_after_load_gib": memory_after_load,
        "gpu_peak_memory_gib": peak_memory_gib,
        "streaming_requested": False,
        "streaming_measured": False,
        "barge_in_measured": False,
        "publisher_quickstart_used_unchanged": False,
        "publisher_quickstart_correction": "PEFT adapter applied to Qwen3TTSModel.model; official Base config retained",
        "torch_version": torch.__version__,
        "cuda_device": torch.cuda.get_device_name(0),
        "python": platform.python_version(),
    }
    args.metadata.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(metadata, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
