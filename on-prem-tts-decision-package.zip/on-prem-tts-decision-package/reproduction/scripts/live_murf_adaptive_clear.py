"""One no-retry Murf clear immediately after first old-context audio payload."""
import asyncio
import hashlib
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from websockets.asyncio.client import connect

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.sessions import murf

FOLDER = ROOT / 'artifacts/murf-adaptive-clear-20260916'
GUARD = FOLDER / 'attempt.started'
MANIFEST = FOLDER / 'manifest.json'
CONFIG = {'model': 'falcon-2', 'voice': 'hi-IN-khyati', 'language': 'hi-IN',
          'format': 'WAV', 'sample_rate': 24000, 'region': 'global', 'context_id': 'old-turn'}
OLD = 'नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
NEW = 'ठीक है, नई बैठक शुक्रवार को चार बजे रख दी गई है।'
OLD_ACTION = {'type': 'text', 'context_id': 'old-turn', 'text': OLD, 'end': False}
CLEAR_ACTION = {'type': 'cancel', 'context_id': 'old-turn'}
NEW_ACTION = {'type': 'text', 'context_id': 'new-turn', 'text': NEW, 'end': True}


async def main():
    if GUARD.exists() or MANIFEST.exists():
        raise RuntimeError('Adaptive clear already attempted; no retry')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    secret = credentials.get('MURF_API_KEY')
    if not secret:
        raise RuntimeError('Authorized Murf key missing')
    spec = murf.build_session(CONFIG, {'MURF_API_KEY': secret})
    if len(OLD) + len(NEW) >= 150 or spec.sample_rate != 24000:
        raise RuntimeError('Adaptive test scope changed')
    for action in (OLD_ACTION, CLEAR_ACTION, NEW_ACTION):
        murf.encode_action(action, CONFIG)
    FOLDER.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(FOLDER).free < 500 * 1024 * 1024:
        raise OSError('500 MiB capture reserve required')
    GUARD.write_text('One socket, two Hindi texts, one clear after first old audio, zero retries.\n')
    frames = FOLDER / 'frames.jsonl'
    events = []
    audio = {'old-turn': bytearray(), 'new-turn': bytearray()}
    payload_counts = {'old-turn': 0, 'new-turn': 0}
    final_counts = {'old-turn': 0, 'new-turn': 0}
    sent_clear = False
    got_new_final_at = None
    error_type = None
    origin = None
    def elapsed_ms():
        return round((time.perf_counter_ns() - origin) / 1_000_000, 3)
    def event(kind, **fields):
        events.append({'kind': kind, 'elapsed_ms': elapsed_ms(), **fields})
    try:
        async with connect(spec.url, additional_headers={}, max_size=2_000_000, open_timeout=10) as socket:
            origin = time.perf_counter_ns()
            event('connected')
            for message in spec.initial_messages:
                await socket.send(json.dumps(message, ensure_ascii=False))
            event('voice_config_sent')
            await socket.send(json.dumps(murf.encode_action(OLD_ACTION, CONFIG)[0], ensure_ascii=False))
            event('old_text_sent', context_id='old-turn')
            deadline = time.perf_counter() + 12
            total_wire_bytes = 0
            with frames.open('w') as journal:
                while time.perf_counter() < deadline:
                    if got_new_final_at is not None and elapsed_ms() - got_new_final_at > 800:
                        break
                    try:
                        raw = await asyncio.wait_for(socket.recv(), timeout=min(1, deadline - time.perf_counter()))
                    except asyncio.TimeoutError:
                        continue
                    if not isinstance(raw, str):
                        raise ValueError('Murf must return JSON text frames')
                    total_wire_bytes += len(raw.encode())
                    if total_wire_bytes > 32_000_000:
                        raise ValueError('Bounded Murf wire cap exceeded')
                    journal.write(json.dumps({'elapsed_ms': elapsed_ms(), 'payload': raw}, ensure_ascii=False) + '\n')
                    journal.flush()
                    for decoded in murf.decode_message(raw):
                        kind = decoded['type']
                        context = decoded.get('context_id')
                        if kind == 'error':
                            raise ValueError('Murf WebSocket error event')
                        if kind == 'audio':
                            if context not in audio:
                                raise ValueError('Unexpected Murf context on audio')
                            payload_counts[context] += 1
                            audio[context].extend(decoded['audio'])
                            event('audio_received', context_id=context, byte_count=len(decoded['audio']),
                                  cumulative_bytes=len(audio[context]))
                            if context == 'old-turn' and not sent_clear:
                                await socket.send(json.dumps(murf.encode_action(CLEAR_ACTION, CONFIG)[0]))
                                event('clear_sent', context_id='old-turn')
                                sent_clear = True
                                await socket.send(json.dumps(murf.encode_action(NEW_ACTION, CONFIG)[0], ensure_ascii=False))
                                event('new_text_sent', context_id='new-turn')
                        elif kind == 'done':
                            if context not in final_counts:
                                raise ValueError('Unexpected Murf context on final')
                            final_counts[context] += 1
                            event('final_received', context_id=context)
                            if context == 'new-turn':
                                got_new_final_at = elapsed_ms()
                        else:
                            event('metadata_received', context_id=context)
    except Exception as exc:
        error_type = type(exc).__name__
    files = {}
    for context, buffer in audio.items():
        if buffer:
            name = context + '.audio'
            (FOLDER / name).write_bytes(buffer)
            files[context] = {'file': name, 'bytes': len(buffer),
                              'sha256': hashlib.sha256(buffer).hexdigest()}
    clear = next((e['elapsed_ms'] for e in events if e['kind'] == 'clear_sent'), None)
    old_after = [e for e in events if e['kind'] == 'audio_received' and
                 e['context_id'] == 'old-turn' and clear is not None and e['elapsed_ms'] > clear]
    status = ('observed_new_final' if error_type is None and sent_clear and
              payload_counts['new-turn'] and final_counts['new-turn'] == 1 else
              'error' if error_type else 'inconclusive')
    result = {'provider': 'murf', 'model': 'falcon-2', 'language': 'hi-IN',
              'created_at': datetime.now(timezone.utc).isoformat(),
              'status': status, 'error_type': error_type, 'socket_limit': 1,
              'text_request_limit': 2, 'clear_request_limit': 1, 'retries': 0,
              'voice': CONFIG['voice'], 'old_text': OLD, 'new_text': NEW,
              'config': CONFIG, 'actions': [OLD_ACTION, CLEAR_ACTION, NEW_ACTION],
              'key_saved': False, 'frames_file': frames.name, 'events': events,
              'audio': files, 'payload_counts': payload_counts, 'final_counts': final_counts,
              'clear_sent_ms': clear, 'old_payloads_after_clear': len(old_after),
              'old_bytes_after_clear': sum(e['byte_count'] for e in old_after),
              'boundary': 'adaptive synthetic clear after first old-context received payload; no caller VAD or handset playout',
              'source': 'https://murf.ai/api/docs/text-to-speech/web-sockets/context-id'}
    MANIFEST.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'error_type', 'payload_counts',
                                           'final_counts', 'clear_sent_ms',
                                           'old_payloads_after_clear',
                                           'old_bytes_after_clear')}, ensure_ascii=False))


if __name__ == '__main__':
    asyncio.run(main())
