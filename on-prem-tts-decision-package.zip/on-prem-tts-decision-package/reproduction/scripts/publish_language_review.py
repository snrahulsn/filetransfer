"""Publish only the anonymous, hash-checked review page and WAVs to the site."""
import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
POINTER = ROOT / 'artifacts/listening/current-language-study.json'
STUDY_ID = json.loads(POINTER.read_text())['study_id'] if POINTER.exists() else 'indic-language-02c80dcdde9f'


def publish(study_id=STUDY_ID, make_current=False):
    source = ROOT / 'artifacts/listening' / study_id / 'public'
    status_path = source.parent / 'package-status.json'
    status = json.loads(status_path.read_text())
    if status['study_id'] != study_id or status['ratings_created'] != 0:
        raise ValueError('Review package status or rating boundary changed')
    items = json.loads((source / 'items.json').read_text())
    mapping = json.loads((source.parent / 'public-private-key.json').read_text())
    if len(items) != status['items'] or len(mapping) != len(items):
        raise ValueError('Review item inventory differs from private mapping')
    allowed = {'index.html', 'items.json'} | {item['audio_file'] for item in items}
    actual = {entry.name for entry in source.iterdir()}
    if actual != allowed or any(entry.is_symlink() or not entry.is_file() for entry in source.iterdir()):
        raise ValueError('Public review directory contains unapproved files')
    for item in items:
        token = item['item_id']
        if item['audio_file'] != token + '.wav' or token not in mapping:
            raise ValueError('Anonymous review file/identity mismatch')
        if hashlib.sha256((source / item['audio_file']).read_bytes()).hexdigest() != mapping[token]['source_audio_sha256']:
            raise ValueError('Anonymous review WAV differs from source audio')
    dest = ROOT / 'ui/public/review' / study_id
    if dest.exists():
        if {entry.name for entry in dest.iterdir()} != allowed:
            raise ValueError('Published review inventory changed')
        if any((source / name).read_bytes() != (dest / name).read_bytes() for name in allowed):
            raise ValueError('Published review bytes changed')
    else:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, dest, symlinks=False)
    audit = {'schema': 'indic_language_review_publish_v1', 'study_id': study_id,
             'public_review_url': '/review/' + study_id + '/index.html',
             'items': status['items'], 'vendor_locale_cells': status['vendor_locale_cells'],
             'requested_locales': status['requested_locales'], 'published_audio_hashes_verified': len(items),
             'ratings_created': 0, 'native_reviewed_references': 0,
             'public_items_sha256': hashlib.sha256((dest / 'items.json').read_bytes()).hexdigest(),
             'public_page_sha256': hashlib.sha256((dest / 'index.html').read_bytes()).hexdigest(),
             'private_mapping_published': False,
             'boundary': 'Anonymous saved WAVs and blank local reviewer form; no native quality result is inferred.'}
    (source.parent / 'publish-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
    if make_current:
        # The full snapshot changes when non-audio evidence or release metadata
        # is refreshed. The verifier below compares every packaged source ID and
        # WAV hash against the current eligible audio inventory instead.
        previous_pointer = POINTER.read_bytes() if POINTER.exists() else None
        POINTER.write_text(json.dumps({'schema': 'current_indic_language_review_v1',
                                       'study_id': study_id,
                                       'source_inventory_sha256': status['source_inventory_sha256']}, indent=2) + '\n')
        from tts_arena.language_review_evidence import verify
        try:
            verify(ROOT)
        except Exception:
            if previous_pointer is None:
                POINTER.unlink()
            else:
                POINTER.write_bytes(previous_pointer)
            raise
    print(json.dumps({k: audit[k] for k in ('study_id', 'items', 'vendor_locale_cells',
                                          'published_audio_hashes_verified')}, indent=2))
    return audit


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('study_id', nargs='?', default=STUDY_ID)
    parser.add_argument('--current', action='store_true', help='Select this current-snapshot package after verification')
    args = parser.parse_args()
    publish(args.study_id, args.current)
