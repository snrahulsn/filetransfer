"""Build a non-mutating locale ledger for the hosted group-C instruction."""
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROVIDERS = ("deepgram", "hume", "inworld", "murf", "neuphonic", "rime", "speechify")
snapshot = json.loads((ROOT / "ui/public/evidence/snapshot.json").read_text())
playable = {(row["provider"], row.get("language")) for row in snapshot["runs"]
            if row.get("provider") in PROVIDERS and row.get("status") == "success" and row.get("audio_url")}
playable |= {(row["provider"], row.get("language")) for row in snapshot.get("native_audio_runs", [])
             if row.get("provider") in PROVIDERS}
rows = []
for provider in PROVIDERS:
    catalog = json.loads((ROOT / "catalog" / f"{provider}.json").read_text())
    for language, claim in catalog["languages"].items():
        if (provider, language) in playable:
            state, reason = "successful_existing", "Playable audio already exists; no synthesis permitted."
        elif claim.get("status") in {"unsupported", "not_supported"}:
            state, reason = "officially_excluded", "Catalog records explicit official exclusion."
        elif provider == "inworld" and language == "ur-IN":
            state, reason = "blocked", "A prior bounded ur-IN request already returned HTTP 400; another request would be a retry and is outside this run."
        elif provider == "speechify" and language != "en-IN":
            state, reason = "blocked", "Saved authenticated voice discovery establishes the selected voice only for en-IN; no exact voice-locale pairing is available to send without substitution."
        elif claim.get("status") == "documented":
            state, reason = "eligible_missing", "Documented locale has no exact playable snapshot/native run; requires exact current adapter config and spend eligibility before one call."
        else:
            state, reason = "blocked", "No exact live evidence or explicit official exclusion; absence is not a No conclusion."
        rows.append({"provider": provider, "locale": language, "catalog_status": claim.get("status"), "state": state, "reason": reason, "run_id": None})
out = {"observed_at": datetime.now(timezone.utc).isoformat(), "scope": "Group C preflight only; no synthesis was sent by this ledger.", "call_budget": 12, "calls_used": 0, "rows": rows}
target = ROOT / "artifacts" / "hosted-group-c-20260916"
target.mkdir(exist_ok=True)
(target / "progress-manifest-final.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
