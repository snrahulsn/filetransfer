"""Three bounded Gemini3.1TTS smoke fixtures, never retries or legacy-model fallback."""
import asyncio,json,os
from pathlib import Path
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
async def main():
 root=Path(__file__).resolve().parents[1];path=root/'artifacts/access-20260915/google.json'
 if path.exists():raise RuntimeError('Evidence exists; no automatic repeat spend')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');os.environ['GOOGLE_API_KEY']=secrets['GOOGLE_API_KEY']
 summary={'provider':'google','model':'gemini-3.1-flash-tts-preview','protocol':'GenerateContent compatibility API','discovery_status':200,'automatic_retries':0,'runs':[],'native_quality':'not_evaluated'}
 diagnostics=[]
 async def hook(response):
  if response.status_code>=400:diagnostics.append({'http_status':response.status_code,'message':redact((await response.aread())[:6000].decode('utf8','replace'),secrets)})
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  for locale,text,instructions in [('hi-IN','नमस्ते, आपका भुगतान मिल गया है।','Read the following text naturally in Hindi.'),('en-IN','Hello, your payment has been received.','Read the following text in an Indian English accent.'),('ta-IN','வணக்கம், உங்கள் பணம் கிடைத்தது.','Read the following text naturally in Tamil.')]:
   cfg={'model':'gemini-3.1-flash-tts-preview','voice':'Kore','language':locale,'language_mode':'auto','format':'pcm_s16le','instructions':instructions}
   before=len(diagnostics)
   r=await run_one('google',text,cfg,root/'artifacts/runs/access-20260915/google',timeout=30,scenario_id='gemini-smoke-'+locale,client=client,stratum='smoke_only')
   item={k:r.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','audio_bytes')};item.update(config=cfg,diagnostics=diagnostics[before:]);summary['runs'].append(item)
   path.write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),secrets)+'\n')
   if r.get('http_status') in (401,402,403,429):break
 print(json.dumps({'provider':'google','runs':[{'language':r['config']['language'],'status':r['status'],'http_status':r['http_status']} for r in summary['runs']]}))
if __name__=='__main__':asyncio.run(main())
