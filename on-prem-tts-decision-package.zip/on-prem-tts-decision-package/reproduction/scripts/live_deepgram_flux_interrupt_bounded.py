"""One bounded Flux TTS synthetic software-playout interruption and recovery trial."""
import asyncio
import hashlib
import io
import json
import math
import shutil
import sys
import time
import wave
from datetime import datetime,timezone
from pathlib import Path

from websockets.asyncio.client import connect

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.registry import code_digest

OUT=ROOT/'artifacts/deepgram-flux-interrupt-20260915-v3'
MODEL='flux-priya-en'
RATE=24000
FIRST='Your next payment is due on Friday. I can explain the amount and available payment methods before you decide what to do.'
RECOVERY='I heard you. What would you like to change?'
FRAME_MS=20
PLAY_MS=160
FLOOR=300*1024*1024

def wav(pcm):
 if not pcm or len(pcm)%2:raise ValueError('Complete nonempty PCM16 required')
 stream=io.BytesIO()
 with wave.open(stream,'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(pcm)
 return stream.getvalue()

def caller_fixture():
 # A deterministic 120 ms tone labels caller onset; no microphone or ASR is implied.
 import array
 values=array.array('h',(int(2500*math.sin(2*math.pi*880*i/RATE)) for i in range(RATE*120//1000)))
 return wav(values.tobytes())

async def probe():
 if OUT.exists():raise RuntimeError('Flux interruption probe already attempted; no repeat spend')
 if shutil.disk_usage(ROOT).free<FLOOR:raise RuntimeError('Disk evidence floor not met')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('DEEPGRAM_API_KEY')
 if not key:raise RuntimeError('Authorized Deepgram key absent')
 OUT.mkdir(parents=True)
 fixture=caller_fixture();(OUT/'caller_fixture.wav').write_bytes(fixture)
 origin=time.perf_counter_ns();now=lambda:round((time.perf_counter_ns()-origin)/1e6,2)
 report={'schema':'deepgram_flux_software_interrupt_v1','provider':'deepgram','model':MODEL,'created_at':datetime.now(timezone.utc).isoformat(),
  'source_client':'https://developers.deepgram.com/docs/flux-tts/client-messages',
  'source_server':'https://developers.deepgram.com/docs/flux-tts/server-messages',
  'request_limit':1,'automatic_retries':0,'network_attempted':False,
  'boundary':'synthetic_caller_fixture_and_software_PCM_playout_not_SIP_RTP_or_handset',
  'production_telephony_verified':False,'caller_detection':'deterministic_fixture_schedule_not_VAD',
  'caller_fixture_sha256':hashlib.sha256(fixture).hexdigest(),'caller_fixture_duration_ms':120,
  'sample_rate':RATE,'encoding':'pcm_s16le','first_text':FIRST,'recovery_text':RECOVERY,
  'playout_frame_ms':FRAME_MS,'planned_playout_ms':PLAY_MS,'events':[],'status':'not_started'}
 def event(kind,**details):report['events'].append({'t_ms':now(),'kind':kind,**details})
 def save():
  (OUT/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 save()
 old=bytearray();recovered=bytearray();old_played=bytearray()
 connected=asyncio.Event();old_audio_ready=asyncio.Event();interrupted=asyncio.Event();recovery_done=asyncio.Event();session_done=asyncio.Event()
 phase='pre_turn';stopped=False;error=None
 try:
  url=f'wss://api.deepgram.com/v2/speak?model={MODEL}&encoding=linear16&sample_rate={RATE}'
  async with connect(url,additional_headers={'Authorization':'Token '+key},open_timeout=10,close_timeout=5,max_size=2_000_000) as ws:
   report['network_attempted']=True;event('websocket_connected')
   async def receive():
    nonlocal phase,error
    raw_total=0
    async for raw in ws:
     raw_total+=len(raw.encode() if isinstance(raw,str) else raw)
     if raw_total>16_000_000:raise ValueError('Native frame capture exceeds 16 MB')
     if isinstance(raw,bytes):
      if len(raw)%2:raise ValueError('Odd PCM16 frame')
      if phase=='first':
       old.extend(raw)
       event('old_pcm_received',bytes=len(raw),cumulative_bytes=len(old),discarded=stopped)
       if len(old)>=RATE*2*PLAY_MS//1000:old_audio_ready.set()
      elif phase=='recovery':
       recovered.extend(raw);event('recovery_pcm_received',bytes=len(raw),cumulative_bytes=len(recovered))
      else:raise ValueError('Audio outside a provider-marked turn')
      continue
     frame=json.loads(raw)
     if not isinstance(frame,dict) or not isinstance(frame.get('type'),str):raise ValueError('Malformed native JSON control frame')
     kind=frame['type']
     event('native_control_received',type=kind)
     if kind=='Connected':
      if connected.is_set():raise ValueError('Duplicate Connected')
      report['native_connected_model_name']=frame.get('model_name')
      report['native_connected_model_match']=frame.get('model_name')==MODEL
      report['model_version']=frame.get('model_version');connected.set();event('native_connected',resolved_model_name=frame.get('model_name'))
     elif kind=='SpeechStarted':
      if phase not in {'pre_turn','await_recovery'}:raise ValueError('Unexpected SpeechStarted ordering')
      phase='first' if phase=='pre_turn' else 'recovery';event('speech_started',turn=phase,speech_id=frame.get('speech_id'))
     elif kind=='SpeechInterrupted':
      if phase!='first' or not stopped:raise ValueError('SpeechInterrupted without local stop')
      report['speech_interrupted']={k:frame.get(k) for k in ('audio_played_ms','text_spoken','text_remaining')}
      report['speech_interrupted']['speech_id']=frame.get('metadata',{}).get('speech_id')
      phase='await_recovery';interrupted.set();event('speech_interrupted',audio_played_ms=frame.get('audio_played_ms'))
     elif kind=='SpeechMetadata':
      if phase!='recovery':raise ValueError('Unexpected SpeechMetadata')
      report['recovery_metadata']={k:frame.get(k) for k in ('speech_id','audio_duration_ms','billable_character_count')}
      phase='after_recovery';recovery_done.set();event('recovery_complete')
     elif kind=='SessionMetadata':
      report['session_metadata']={k:frame.get(k) for k in ('total_audio_duration_ms','total_input_character_count','total_billable_character_count')}
      session_done.set();event('session_complete')
     elif kind in {'Warning','Error','ConfigureFailure'}:
      event('provider_notice',type=kind,code=frame.get('code'))
      report.setdefault('provider_notices',[]).append({'type':kind,'code':frame.get('code')})
      if kind=='Error' or (kind=='Warning' and frame.get('code') in {'NO_AUDIO_GENERATED','INVALID_INTERRUPT_OFFSET','INTERRUPT_IN_PROGRESS'}):
       error=kind+':'+str(frame.get('code'));interrupted.set();recovery_done.set()
     else:event('provider_control',type=kind)
   task=asyncio.create_task(receive())
   def reader_done(done):
    if not done.cancelled() and done.exception():report['reader_exception_type']=type(done.exception()).__name__
   task.add_done_callback(reader_done)
   try:
    await ws.send(json.dumps({'type':'Speak','text':FIRST}));event('first_speak_sent')
    await asyncio.wait_for(connected.wait(),5)
    await asyncio.wait_for(old_audio_ready.wait(),15)
    # Consume the first 160 ms from received PCM in 20 ms software receiver frames.
    for i in range(PLAY_MS//FRAME_MS):
     start=i*FRAME_MS*RATE*2//1000;end=(i+1)*FRAME_MS*RATE*2//1000
     old_played.extend(old[start:end]);await asyncio.sleep(FRAME_MS/1000)
     event('software_frame_played',frame=i+1,played_ms=(i+1)*FRAME_MS)
    report['synthetic_caller_onset_ms']=now();event('caller_fixture_onset',fixture_sha256=report['caller_fixture_sha256'])
    stopped=True;report['local_playout_stop_ms']=now();event('local_playout_cleared',queued_old_bytes=max(0,len(old)-len(old_played)))
    await ws.send(json.dumps({'type':'Interrupt','playback_offset':{'type':'time_ms','value':PLAY_MS}}))
    report['interrupt_sent_ms']=now();event('interrupt_sent',absolute_session_playback_offset_ms=PLAY_MS)
    await asyncio.wait_for(interrupted.wait(),10)
    if error:raise RuntimeError(error)
    if report.get('speech_interrupted',{}).get('audio_played_ms')!=PLAY_MS:raise ValueError('Provider did not echo software playback offset')
    if not all(isinstance(report['speech_interrupted'].get(k),str) for k in ('text_spoken','text_remaining')):
     raise ValueError('Provider did not return spoken/remaining text split')
    await ws.send(json.dumps({'type':'Speak','text':RECOVERY}));event('recovery_speak_sent')
    await ws.send(json.dumps({'type':'Flush'}));event('recovery_flush_sent')
    await asyncio.wait_for(recovery_done.wait(),10)
    if error:raise RuntimeError(error)
    await ws.send(json.dumps({'type':'Close'}));event('close_sent')
    await asyncio.wait_for(session_done.wait(),5)
    if not recovered:raise ValueError('Recovery turn produced no PCM')
    if len(old_played)!=RATE*2*PLAY_MS//1000:raise ValueError('Software playout length mismatch')
    report['status']='observed_interruption_and_recovery' if report.get('native_connected_model_match') else 'inconclusive_model_identity'
   finally:
    task.cancel();await asyncio.gather(task,return_exceptions=True)
 except Exception as exc:
  report['status']='failed';report['exception_type']=type(exc).__name__
 for name,pcm in (('old_received',old),('old_played',old_played),('recovery',recovered)):
  if pcm:
   blob=wav(bytes(pcm));(OUT/(name+'.wav')).write_bytes(blob)
   report[name+'_wav']={'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'duration_ms':round(len(pcm)*1000/(RATE*2),2)}
 report['old_received_not_played_bytes_discarded']=max(0,len(old)-len(old_played)) if stopped else 0
 report['recovery_old_pcm_played_bytes']=0 if stopped else None
 report['native_interrupt_ack_ms']=round(report['events'][next(i for i,e in enumerate(report['events']) if e['kind']=='speech_interrupted')]['t_ms']-report['interrupt_sent_ms'],2) if any(e['kind']=='speech_interrupted' for e in report['events']) else None
 report['code_sha256']=code_digest();save()
 print(json.dumps({k:report.get(k) for k in ('status','exception_type','old_received_wav','old_played_wav','recovery_wav','native_interrupt_ack_ms','old_received_not_played_bytes_discarded')}))

if __name__=='__main__':asyncio.run(probe())
