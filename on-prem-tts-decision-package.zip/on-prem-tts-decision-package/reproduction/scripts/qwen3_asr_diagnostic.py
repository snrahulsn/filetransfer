"""One bounded Scribe-v2 lexical diagnostic for each saved Qwen evaluation WAV."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from elevenlabs_scribe_v2_urdu_asr import read_key, request_one
from tts_arena.transcript_quality import evaluate_transcripts


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/runpod/qwen3-tts-20260916"
OUTPUT = SOURCE / "asr-diagnostic.json"
ROWS = (
    ("qwen_base_en_in", "qwen3-base-en-IN.wav", "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
     "en-IN", "Your instalment is fifteen thousand rupees, payable on fifteen September."),
    ("qwen_lora_hi_in", "qwen3-hindi-lora-hi-IN.wav",
     "aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned", "hi-IN",
     "आपकी किस्त पंद्रह हजार रुपये है, जो पंद्रह सितंबर को देय है।"),
)


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError("Qwen ASR diagnostic already exists; no automatic repeat")
    key = read_key()
    references, observations, responses = [], [], []
    for run_id, filename, model, language, text in ROWS:
        path = SOURCE / filename
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        reference_id = run_id + "_reference"
        identity = {"run_id": run_id, "provider": "qwen", "model": model,
                    "language": language, "audio_sha256": digest}
        response = request_one(data, filename, key)
        references.append({"reference_id": reference_id, **identity, "text": text,
                           "native_reviewed": False})
        observations.append({"observation_id": run_id + "_scribe_v2",
                             "reference_id": reference_id, **identity, "source": "asr",
                             "transcriber_id": "elevenlabs.scribe_v2.auto",
                             "text": response["text"]})
        responses.append({"run_id": run_id, "detected_language_code": response["language_code"],
                          "detected_language_probability": response["language_probability"],
                          "transcript": response["text"]})
    scored = evaluate_transcripts(observations, references, {})
    payload = {"engine": "elevenlabs.scribe_v2.auto", "requests": len(ROWS),
               "responses": responses, "scores": scored,
               "scope": "ASR lexical diagnostic; not accent, naturalness, or native-language certification"}
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "requests": len(ROWS),
                      "groups": scored["groups"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
