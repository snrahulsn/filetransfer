"""One authorized Hindi API access call using documented flagship candy.two."""
import asyncio,json,os,shutil,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
from tts_arena.registry import build_request
ROOT=Path(__file__).resolve().parents[1]
async def main():
    out=ROOT/"artifacts/dubverse-access-20260915";out.mkdir(exist_ok=False)
    assert shutil.disk_usage(ROOT).free>=500*1024*1024
    credentials=read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env")
    os.environ["DUBVERSE_API_KEY"]=credentials["DUBVERSE_API_KEY"]
    errors=[]
    async def hook(response):
        if response.status_code>=400:
            await response.aread();errors.append({"http_status":response.status_code,"message":redact(response.text,credentials)[:2000]})
    try:
        config={"model":"candy.two","voice":1190,"language":"hi-IN","format":"wav","audio_streaming":False}
        text="नमस्ते, आपका भुगतान प्राप्त हो गया है। धन्यवाद।"
        build_request("dubverse",text,config)
        (out/"started").write_text("Exactly one authorized access request; no retries.\n")
        async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={"response":[hook]}) as client:
            record=await run_one("dubverse",text,config,out/"runs",timeout=30,client=client,scenario_id="current-flagship-hindi-access",stratum="draft_access_probe")
        result={"provider":"dubverse","model":"candy.two","credential_present":True,"checked_at":"2026-09-15","automatic_retries":0,"scope":"One Hindi access probe; current docs label candy.two flagship; exact deployment revision and native quality unverified","sources":["https://docs.dubverse.ai/models/overview","https://docs.dubverse.ai/speakers/overview","https://docs.dubverse.ai/first-call"],"signup":{"method":"Authorized Google SSO","account_trial_days":2,"displayed_studio_credits":25,"API_entitlement":"Determined by actual probe, not inferred from studio credits"},"runs":[{k:record.get(k) for k in ("run_id","status","http_status","error_type","audio_bytes","duration_seconds","audio_analysis")}],"diagnostics":errors}
        result["runs"][0]["config"]=config
        result["successful_syntheses"]=int(record["status"]=="success")
        if record["status"]!="success":result["blocker"]="synthesis_failed"
        (ROOT/"artifacts/access-20260915/dubverse.json").write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),credentials)+"\n")
        print(json.dumps({k:record.get(k) for k in ("run_id","status","http_status","error_type","audio_bytes","duration_seconds")}))
    finally:os.environ.pop("DUBVERSE_API_KEY",None)
if __name__=="__main__":asyncio.run(main())
