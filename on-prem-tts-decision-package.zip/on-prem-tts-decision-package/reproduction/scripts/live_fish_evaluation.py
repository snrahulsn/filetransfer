"""Three short current-model probes with the newly authorized evaluation key."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
async def main():
 root=Path(__file__).resolve().parents[1];path=root/'artifacts/access-20260915/fish.json';summary=json.loads(path.read_text())
 if any(r.get('credential_generation')=='authorized_evaluation_key' for r in summary['runs']):raise RuntimeError('Evaluation-key probes already executed; refusing repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');os.environ['FISH_API_KEY']=secrets['FISH_API_KEY']
 errors=[]
 async def hook(response):
  if response.status_code>=400:errors.append({'http_status':response.status_code,'message':redact((await response.aread())[:5000].decode('utf8','replace'),secrets)})
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  for locale,text in [('hi-IN','नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'),('en-IN','Hello, your meeting is tomorrow at three in the afternoon. Please confirm the time.'),('ta-IN','வணக்கம், உங்கள் கூட்டம் நாளை பிற்பகல் மூன்று மணிக்கு உள்ளது.')]:
   config={'model':'s2.1-pro-free','voice':'9a9cf47702da476aa4629e2506d4a857','language':'auto','format':'pcm','sample_rate':24000}
   before=len(errors)
   r=await run_one('fish',text,config,root/'artifacts/runs/access-20260915/fish',timeout=30,client=client,evaluation_language=locale,scenario_id='evaluation-key-'+locale,stratum='evaluation_key_smoke')
   item={k:r.get(k) for k in ['run_id','language','config','status','error_type','audio_bytes','duration_seconds','first_audio_ms','http_status']};item.update(credential_generation='authorized_evaluation_key',diagnostics=errors[before:]);summary['runs'].append(item)
   summary['status']='synthesis_access_confirmed' if any(x['status']=='success' for x in summary['runs']) else 'synthesis_blocked'
   summary['latest_credential_scope']='User-approved evaluation key under canonical FISH_API_KEY; original failed run retained; no key value saved.'
   summary['model_selection']='Current s2.1-pro-free promotional API; no model fallback. Vendor promotion ends2026-11-30, FairUse/noSLA restrictions; not permanent production pricing.'
   summary['voice_selection']='Hannah publicvoice9a9cf47702da476aa4629e2506d4a857 confirmed in signed-in vendor Playground and officialexample. Accent and languagequality not evaluated.'
   summary['automatic_retries']=0;summary['errors'].extend(errors[before:]);path.write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),secrets)+'\n')
   print('fish',locale,r['status'],r.get('http_status'),flush=True)
   if r['status']!='success':break
 os.environ.pop('FISH_API_KEY',None)
if __name__=='__main__':asyncio.run(main())
