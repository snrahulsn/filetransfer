"""Build the decision report for the three self-hosted TTS vendors."""
import json
import shutil
import wave
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "ui/public/evidence"
NVIDIA = ROOT / "artifacts/runpod/nvidia-magpie-1.10.0-l40s-20260916"
NVIDIA_HOSTED = ROOT / "artifacts/on-prem-candidates/nvidia-build-magpie"
QWEN = ROOT / "artifacts/runpod/qwen3-tts-20260916"


def wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as handle:
        if handle.getnchannels() != 1 or handle.getsampwidth() != 2:
            raise ValueError(f"On-prem WAV must be mono PCM16: {path}")
        return handle.getnframes() / handle.getframerate()


def clip(language, voice, audio_url, duration, *, text, init=None, synth=None):
    return {
        "language": language,
        "voice": voice,
        "audio_url": audio_url,
        "duration_seconds": duration,
        "text": text,
        "initialization_seconds": init,
        "synthesis_seconds": synth,
    }


def build():
    snapshot = json.loads((PUBLIC / "snapshot.json").read_text())
    kokoro = []
    seen = set()
    for row in snapshot["local_runs"]:
        if row["provider"] != "kokoro" or row["language"] in seen:
            continue
        seen.add(row["language"])
        kokoro.append(clip(row["language"], row["config"].get("voice", "not recorded"),
                           row["audio_url"], row["duration_seconds"], text=row["text"],
                           init=row.get("local_runtime", {}).get("initialization_seconds"),
                           synth=row.get("local_runtime", {}).get("synthesis_seconds")))
    if {row["language"] for row in kokoro} != {"hi-IN", "en-US"}:
        raise ValueError("Kokoro decision clips changed")

    maya_rows = []
    for stem, language, voice in (("veena-hi-IN-kavya", "hi-IN", "kavya"),
                                  ("veena-en-IN-agastya", "en-IN", "agastya"),
                                  ("veena-hi-en-maitri", "hi-en", "maitri")):
        record = json.loads((ROOT / "artifacts/runpod/veena-20260915" / f"{stem}.json").read_text())
        maya_rows.append(clip(language, voice, f"/evidence/audio/{stem}.wav",
                              wav_duration(ROOT / "artifacts/runpod/veena-20260915" / f"{stem}.wav"),
                              text=record["text"], init=record["initialization_seconds"],
                              synth=record["synthesis_seconds"]))
    maya1 = json.loads((ROOT / "artifacts/runpod/maya1-20260915/maya1-en-IN.json").read_text())
    maya1_row = clip("en-IN", maya1["description"], "/evidence/audio/maya1-en-IN.wav",
                     wav_duration(ROOT / "artifacts/runpod/maya1-20260915/maya1-en-IN.wav"),
                     text=maya1["text"], init=maya1["initialization_seconds"],
                     synth=maya1["synthesis_seconds"])

    cleanup = json.loads((NVIDIA / "cleanup.json").read_text())
    if not cleanup["pods"]["deleted"] or not cleanup["containerregistryauth"]["deleted"]:
        raise ValueError("NVIDIA cleanup is not complete")

    hosted_nvidia = json.loads((NVIDIA_HOSTED / "nvidia-magpie--hi-IN.json").read_text())
    hosted_audio = NVIDIA_HOSTED / hosted_nvidia["audio_file"]
    public_nvidia_audio = PUBLIC / "audio/nvidia-magpie--hi-IN.wav"
    shutil.copy2(hosted_audio, public_nvidia_audio)
    (PUBLIC / "captions/nvidia-magpie--hi-IN.vtt").write_text(
        "WEBVTT\n\n00:00:00.000 --> 00:00:30.000\n" + hosted_nvidia["text"] + "\n",
        encoding="utf-8",
    )
    nvidia_recording = clip(
        "hi-IN", hosted_nvidia["voice"], "/evidence/audio/nvidia-magpie--hi-IN.wav",
        hosted_nvidia["duration_seconds"], text=hosted_nvidia["text"],
        synth=hosted_nvidia["wall_seconds_including_discovery"],
    )

    qwen_base = json.loads((QWEN / "qwen3-base-en-IN.json").read_text())
    qwen_hindi = json.loads((QWEN / "qwen3-hindi-lora-hi-IN.json").read_text())
    qwen_cancel = json.loads((QWEN / "qwen3-cancellation.json").read_text())
    qwen_asr = json.loads((QWEN / "asr-diagnostic.json").read_text())
    qwen_acoustic = json.loads((QWEN / "acoustic-diagnostic.json").read_text())
    qwen_recordings = []
    for source_name, public_name, metadata, voice in (
        ("qwen3-base-en-IN.wav", "qwen3-base-en-IN.wav", qwen_base,
         "Voice clone from the saved Maya1 Indian-English-request reference"),
        ("qwen3-hindi-lora-hi-IN.wav", "qwen3-hindi-lora-hi-IN.wav", qwen_hindi,
         "Aguken Hindi female LoRA; failed bounded lexical qualification"),
    ):
        source = QWEN / source_name
        shutil.copy2(source, PUBLIC / "audio" / public_name)
        text = metadata["target_text"]
        (PUBLIC / "captions" / public_name.replace(".wav", ".vtt")).write_text(
            "WEBVTT\n\n00:00:00.000 --> 00:01:00.000\n" + text + "\n", encoding="utf-8")
        qwen_recordings.append(clip(
            metadata["target_locale"], voice, f"/evidence/audio/{public_name}",
            wav_duration(source), text=text,
            init=metadata.get("model_load_seconds"), synth=metadata.get("synthesis_seconds"),
        ))

    vendors = [
        {"id": "kokoro", "name": "Kokoro", "status": "audio_complete", "deployment": "Local CPU batch",
         "models": [{"model": "hexgrad/Kokoro-82M", "revision": "Pinned artifacts; hashes retained in run records",
                     "hardware": "Apple Silicon CPU", "recordings": kokoro}],
         "languages": ["hi-IN", "en-US"], "cost_basis": "Self-hosted compute",
         "license": {"model": "Apache License 2.0", "runtime": "Kokoro/Misaki dependency licenses apply separately",
                     "commercial_use": "Permitted by the published model license",
                     "deployment": "Self-hosting and modification permitted; retain the Apache license, notices and modification notices when redistributing covered material.",
                     "sources": ["https://huggingface.co/hexgrad/Kokoro-82M", "https://www.apache.org/licenses/LICENSE-2.0"]},
         "result": "Hindi and US English batch synthesis observed; Indian English is not an eligible exact-locale result."},
        {"id": "maya", "name": "Maya Research", "status": "audio_complete", "deployment": "Self-hosted GPU batch",
         "models": [
             {"model": "maya-research/Veena", "revision": "8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f",
              "hardware": "Runpod RTX 4090", "recordings": maya_rows},
             {"model": "maya-research/maya1", "revision": "21c682a0afef8c13a89b2512733c8bf5f0c52eb7",
              "hardware": "Runpod RTX 4090", "recordings": [maya1_row]},
         ], "languages": ["hi-IN", "en-IN", "hi-en"], "cost_basis": "$0.74/hour observed Runpod creation rate",
         "license": {"model": "Apache License 2.0 for both published checkpoints", "runtime": "Transformers, PyTorch and SNAC dependency licenses apply separately",
                     "commercial_use": "Permitted by the published checkpoint licenses",
                     "deployment": "Self-hosting and modification permitted; retain the Apache license, notices and modification notices when redistributing covered material.",
                     "sources": ["https://huggingface.co/maya-research/Veena", "https://huggingface.co/maya-research/maya1", "https://www.apache.org/licenses/LICENSE-2.0"]},
         "result": "Veena produced Hindi, Indian-English-request and mixed-text audio; Maya1 produced its English accent-control sample."},
        {"id": "nvidia", "name": "NVIDIA Speech NIM", "status": "hosted_audio_local_deployment_failed", "deployment": "Hosted Build API verified; self-hosted NIM attempted",
         "models": [{"model": "magpie-tts-multilingual", "revision": "hosted Build function plus nvcr.io/nim/nvidia/magpie-tts-multilingual:1.10.0",
                     "hardware": "NVIDIA hosted API; Runpod L40S self-hosted attempt", "recordings": [nvidia_recording]}],
         "languages": ["hi-IN"], "cost_basis": "Hosted trial endpoint; self-hosted L40S observed at $1.09/hour and stopped after 29.5 minutes",
         "license": {"model": "Build model card: NVIDIA Open Model License; NGC listing: NVIDIA Community Model License", "runtime": "NVIDIA Software License Agreement plus Product-Specific Terms for NVIDIA AI Products",
                     "commercial_use": "The current model card states commercial use is supported. The developer-program NIM entitlement is limited to internal evaluation, development and testing; production NIM deployment requires the applicable NVIDIA production entitlement unless a stated Community Product exception applies.",
                     "deployment": "The Runpod pilot was an evaluation deployment. NVIDIA licenses the NIM runtime separately from the model. The Build model card and NGC catalog use different model-license labels, so production review must bind the chosen image digest/tag to its accompanying terms.",
                     "sources": ["https://build.nvidia.com/nvidia/magpie-tts-multilingual/modelcard", "https://catalog.ngc.nvidia.com/orgs/nim/nvidia/containers/magpie-tts-multilingual/latest", "https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-software-license-agreement/", "https://www.nvidia.com/en-us/agreements/enterprise-software/product-specific-terms-for-ai-products/", "https://docs.nvidia.com/ai-enterprise/planning-resource/licensing-guide/latest/licensing.html"]},
         "result": "The hosted NVIDIA Build endpoint returned a valid Hindi WAV after live voice discovery in 1.62 seconds. The exact 1.10.0 self-hosted container did not become ready on Runpod L40S after 29.5 minutes; no local synthesis request was sent, and the Pod plus temporary registry credential were deleted."},
        {"id": "qwen", "name": "Qwen3-TTS", "status": "english_pass_hindi_lora_failed", "deployment": "Self-hosted GPU batch",
         "models": [
             {"model": "Qwen/Qwen3-TTS-12Hz-1.7B-Base", "revision": qwen_base["qwen_repository_head_at_run"],
              "hardware": "Runpod RTX 4090, BF16, SDPA", "recordings": [qwen_recordings[0]]},
             {"model": "aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned",
              "revision": qwen_hindi["adapter_revision"],
              "hardware": "Runpod RTX 4090, BF16, SDPA; corrected underlying-model PEFT load", "recordings": [qwen_recordings[1]]},
         ], "languages": ["en-IN clone fixture", "hi-IN failed qualification"],
         "cost_basis": "$0.74/hour observed Runpod creation rate; Pod deleted after the bounded run",
         "license": {"model": "Apache License 2.0 for the official model and community adapter; Rasa training data CC-BY-4.0",
                     "runtime": "qwen-tts, PEFT, PyTorch and Transformers dependency licenses apply separately",
                     "commercial_use": "The published model and adapter terms permit commercial use; preserve Apache notices and Rasa attribution.",
                     "deployment": "Self-hosting is permitted. Archive the exact adapter, dataset and dependency notices before production.",
                     "sources": ["https://github.com/QwenLM/Qwen3-TTS", "https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-Base", "https://huggingface.co/aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned", "https://huggingface.co/datasets/ai4bharat/Rasa"]},
         "result": ("The official Base model produced a 4.56 s Indian-English clone fixture in 10.47 s (RTF 2.30); "
                    "Scribe recovered every amount/date entity despite a raw NFC WER of 0.60 from number formatting and spelling. "
                    "The Hindi LoRA hit the 512-token cap, returned 40.88 s for a short sentence, had RTF 3.05, and produced an empty Scribe transcript (WER/CER 1.00), so it failed. "
                    f"The released API has no playable chunk stream or request cancel; isolated-worker SIGTERM completed in {qwen_cancel['worker_termination_seconds']:.3f} s and released GPU process memory. "
                    f"Hindi output peak was {qwen_acoustic['qwen3-hindi-lora-hi-IN.wav']['peak_dbfs']:.1f} dBFS with non-zero clipping.")},
    ]
    report = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "vendor_count": len(vendors),
        "model_count": sum(len(vendor["models"]) for vendor in vendors),
        "audio_complete_vendor_count": sum(
            any(model["recordings"] for model in vendor["models"]) for vendor in vendors
        ),
        "recording_count": sum(len(model["recordings"]) for vendor in vendors for model in vendor["models"]),
        "vendors": vendors,
        "nvidia_lifecycle": {"pod_deleted": cleanup["pods"]["deleted"],
                             "registry_auth_deleted": cleanup["containerregistryauth"]["deleted"],
                             "hourly_usd": 1.09, "ready": False,
                             "synthesis_requests": 0, "startup_cap_seconds": 3300,
                             "observed_startup_seconds": 1772,
                             "hosted_build_ready": True,
                             "hosted_build_synthesis_requests": 1,
                             "hosted_build_wall_seconds": hosted_nvidia["wall_seconds_including_discovery"]},
    }
    if report["recording_count"] != 9:
        raise ValueError("On-prem decision recording count changed")
    (PUBLIC / "on-prem-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    lines = ["# On-prem TTS report", "",
             f"{report['vendor_count']} vendors evaluated, {report['audio_complete_vendor_count']} with saved audio, {report['model_count']} exact model families and {report['recording_count']} verified decision recordings.", "",
             "| Vendor | Status | Deployment | Exact models | Measured languages | License | Compute basis |",
             "|---|---|---|---|---|---|---|"]
    for vendor in vendors:
        lines.append(f"| {vendor['name']} | {vendor['status'].replace('_', ' ')} | {vendor['deployment']} | {', '.join(m['model'] for m in vendor['models'])} | {', '.join(vendor['languages']) or 'None'} | {vendor['license']['model']} | {vendor['cost_basis']} |")
    for vendor in vendors:
        lines += ["", f"## {vendor['name']}", "", vendor["result"], "", "### License", "",
                  f"Model: **{vendor['license']['model']}**. Runtime: {vendor['license']['runtime']}.", "",
                  vendor['license']['commercial_use'], "", vendor['license']['deployment'], "",
                  "Sources: " + ", ".join(f"[{index + 1}]({url})" for index, url in enumerate(vendor['license']['sources'])) + ".", ""]
        for model in vendor["models"]:
            lines += [f"### {model['model']}", "", f"Revision: `{model['revision']}`. Hardware: {model['hardware']}.", ""]
            for row in model["recordings"]:
                lines.append(f"- {row['language']} · {row['voice']} · {row['duration_seconds']:.2f} s · [audio](../ui/public{row['audio_url']})")
    (ROOT / "docs/ON_PREM_REPORT.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({key: report[key] for key in ("vendor_count", "model_count", "recording_count")}))
    return report


if __name__ == "__main__":
    build()
