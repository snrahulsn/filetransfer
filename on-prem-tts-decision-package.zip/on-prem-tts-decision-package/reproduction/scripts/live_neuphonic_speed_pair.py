"""One bounded Neuphonic Hindi speed observation: two calls, no retries."""
import asyncio
import json
import os
import sys
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tts_arena.credentials import read_credentials, redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT = ROOT / "artifacts/neuphonic-speed-20260916"
RUNS = OUT / "runs"
TEXT = "नमस्ते, आपकी बैठक कल दोपहर तीन बजे है।"
VOICE = "8a8d385c-21b6-4a61-8927-f14a0ee2856b"  # Priya; observed Hindi voice
CONFIG = {"voice": VOICE, "language": "hi", "format": "pcm_linear", "sample_rate": 24000}
SPEEDS = (0.7, 1.5)


async def main():
    if OUT.exists():
        raise RuntimeError("Neuphonic speed pair already staged; no automatic repeat")
    secrets = read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env")
    key = secrets.get("NEUPHONIC_API_KEY")
    if not key:
        raise RuntimeError("NEUPHONIC_API_KEY unavailable in approved credential source")
    if len(TEXT) >= 90:
        raise RuntimeError("Bounded prompt limit exceeded")
    for speed in SPEEDS:
        build_request("neuphonic", TEXT, {**CONFIG, "speed": speed}, {"NEUPHONIC_API_KEY": key})
    OUT.mkdir(parents=True)
    report = {
        "schema": "neuphonic_speed_pair_v1",
        "provider": "neuphonic",
        "voice": VOICE,
        "voice_name": "Priya",
        "backend_model_identity": "not_exposed; voice_id selects hosted backend",
        "language": "hi-IN",
        "reference_text": TEXT,
        "request_limit": 2,
        "automatic_retries": 0,
        "speed_values": list(SPEEDS),
        "records": [],
        "native_speed_accuracy": "unverified",
        "billing": "not_reconciled",
    }

    def save():
        (OUT / "summary.json").write_text(redact(json.dumps(report, ensure_ascii=False, indent=2), secrets) + "\n")

    save()
    os.environ["NEUPHONIC_API_KEY"] = key
    try:
        async with httpx.AsyncClient(timeout=35, trust_env=False, follow_redirects=False) as client:
            for speed in SPEEDS:
                config = {**CONFIG, "speed": speed}
                row = {"speed": speed, "config": config, "status": "request_started"}
                report["records"].append(row)
                save()
                result = await run_one(
                    "neuphonic", TEXT, config, RUNS, timeout=35, client=client,
                    scenario_id=f"hindi-speed-{speed}", evaluation_language="hi-IN",
                    stratum="speed_paired_control", min_free_bytes=300 * 1024 * 1024,
                )
                row.update({key: result.get(key) for key in (
                    "run_id", "status", "http_status", "error_type", "duration_seconds",
                    "audio_sha256", "first_audio_ms", "elapsed_ms",
                )})
                save()
    finally:
        os.environ.pop("NEUPHONIC_API_KEY", None)
    if len(report["records"]) == 2 and all(r.get("status") == "success" and r.get("duration_seconds") for r in report["records"]):
        slow, fast = report["records"]
        report["status"] = "measured_pair"
        report["duration_seconds"] = [slow["duration_seconds"], fast["duration_seconds"]]
        report["duration_ratio_high_over_low"] = fast["duration_seconds"] / slow["duration_seconds"]
        report["direction_observation"] = "shorter_at_higher_setting" if fast["duration_seconds"] < slow["duration_seconds"] else "not_shorter_at_higher_setting"
    else:
        report["status"] = "inconclusive"
    report["completed"] = True
    save()


if __name__ == "__main__":
    asyncio.run(main())
