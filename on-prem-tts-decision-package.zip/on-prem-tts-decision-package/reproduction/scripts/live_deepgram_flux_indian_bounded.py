"""Three short, no-retry Indian-accent Flux TTS v2 batch samples."""
import asyncio
import json
import os
import sys
from datetime import datetime,timezone
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OUT=ROOT/'artifacts/runs/deepgram-flux-indian-20260915'
SUMMARY=ROOT/'artifacts/deepgram-flux-indian-20260915/summary.json'
MODELS=('flux-meena-en','flux-naveen-en','flux-priya-en')
TEXT='Your meeting is tomorrow afternoon.'

async def main():
 if OUT.exists() or SUMMARY.exists():raise RuntimeError('Flux voice trial already attempted; no repeat spend')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('DEEPGRAM_API_KEY')
 if not key:raise RuntimeError('Authorized Deepgram key absent')
 plans=[]
 for model in MODELS:
  config={'model':model,'voice':model,'language':'en-IN','format':'linear16','sample_rate':24000}
  spec=build_request('deepgram',TEXT,config,{'DEEPGRAM_API_KEY':key})
  if len(TEXT)>60 or spec.method!='POST' or not spec.url.startswith('https://api.deepgram.com/v2/speak?') or spec.response_mode!='binary':
   raise ValueError('Flux v2 batch preflight failed')
  plans.append((model,config))
 OUT.mkdir(parents=True);SUMMARY.parent.mkdir(parents=True)
 report={'provider':'deepgram','family':'Flux TTS v2 batch','created_at':datetime.now(timezone.utc).isoformat(),
  'request_limit':len(plans),'automatic_retries':0,'prompt':TEXT,'native_accent_quality':'unverified',
  'streaming_or_barge_in':'not_tested','results':[]}
 def save():SUMMARY.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'DEEPGRAM_API_KEY':key}))
 save();os.environ['DEEPGRAM_API_KEY']=key
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False) as client:
   for model,config in plans:
    row={'model':model,'locale':'en-IN','status':'request_started'};report['results'].append(row);save()
    result=await run_one('deepgram',TEXT,config,OUT,timeout=35,client=client,
     scenario_id='deepgram-flux-indian-'+model,evaluation_language='en-IN',
     stratum='matched_indian_accent_voice_output',min_free_bytes=300*1024*1024)
    row.update({k:result.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','audio_sha256','duration_seconds','first_audio_ms')})
    save();print(model,result['status'],result.get('http_status'),flush=True)
    if result['status']!='success':report['stopped_after_failure']=True;save();break
 finally:os.environ.pop('DEEPGRAM_API_KEY',None)
 report['completed']=True;report['successes']=sum(r['status']=='success' for r in report['results']);save()
 print(json.dumps({'attempts':len(report['results']),'successes':report['successes']}))

if __name__=='__main__':asyncio.run(main())
