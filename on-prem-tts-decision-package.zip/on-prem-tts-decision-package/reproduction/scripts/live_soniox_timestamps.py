"""Bounded one-stream Soniox character timestamp contract probe, no phone call."""
import asyncio,base64,hashlib,json,shutil,sys,time
from pathlib import Path
from uuid import uuid4
import websockets

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
OUT=ROOT/'artifacts/soniox-timestamps-20260915'
TEXT='नमस्ते, आपका भुगतान प्राप्त हो गया है।'

async def main():
 if OUT.exists():raise RuntimeError('Existing timestamp evidence; no repeated spend')
 if shutil.disk_usage(ROOT).free<300*1024*1024:raise RuntimeError('Disk evidence floor')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('SONIOX_API_KEY')
 if not key:raise RuntimeError('No authorized key')
 sid='marks-'+uuid4().hex;start=time.perf_counter()
 report={'schema':'soniox_character_marks_v1','provider':'soniox','model':'tts-rt-v2','voice':'Kavya','language':'hi-IN','source':'https://soniox.com/docs/api-reference/tts/websocket-api','requested_text':TEXT,'return_timestamps':True,'word_timestamps_claimed':False,'character_alignment_accuracy':'unverified','frames':0,'audio_bytes':0,'characters':0,'mark_array_lengths_consistent':True,'terminal_observed':False,'errors':[],'status':'not_started'}
 OUT.mkdir(parents=True);audio=[];chars=[]
 try:
  async with websockets.connect('wss://tts-rt.soniox.com/tts-websocket',open_timeout=10,close_timeout=5,max_size=2*1024*1024) as ws:
   await ws.send(json.dumps({'api_key':key,'model':'tts-rt-v2','language':'hi','voice':'Kavya','audio_format':'pcm_s16le','sample_rate':24000,'return_timestamps':True,'stream_id':sid}))
   await ws.send(json.dumps({'text':TEXT,'text_end':True,'stream_id':sid}))
   deadline=time.perf_counter()+25
   while time.perf_counter()<deadline:
    f=json.loads(await asyncio.wait_for(ws.recv(),timeout=max(.1,deadline-time.perf_counter())))
    if f.get('stream_id')!=sid:raise ValueError('Unexpected stream id')
    if f.get('error_type'):report['errors'].append({'type':f['error_type'],'code':f.get('error_code')})
    if f.get('audio'):
     raw=base64.b64decode(f['audio'],validate=True)
     if len(raw)%2:raise ValueError('Invalid PCM sample width')
     audio.append(raw);report['frames']+=1;report['audio_bytes']+=len(raw)
     marks=f.get('timestamps')
     if marks:
      c=marks.get('characters',[]);s=marks.get('character_start_times_seconds',[]);e=marks.get('character_end_times_seconds',[])
      report['mark_array_lengths_consistent']&=len(c)==len(s)==len(e)
      chars.extend(c);report['characters']+=len(c)
     report['timestamp_frames']=report.get('timestamp_frames',0)+bool(marks)
    if f.get('terminated') is True:report['terminal_observed']=True;break
   report['status']='observed_character_marks' if report['terminal_observed'] and report['characters']>0 and report['mark_array_lengths_consistent'] and not report['errors'] else 'incomplete'
 except Exception as ex:report['status']='failed';report['exception_type']=type(ex).__name__
 raw=b''.join(audio)
 if raw:(OUT/'audio.pcm').write_bytes(raw);report['audio_sha256']=hashlib.sha256(raw).hexdigest()
 report['returned_characters_text']=''.join(chars);report['elapsed_ms']=round((time.perf_counter()-start)*1000,2)
 (OUT/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:report.get(k) for k in ('status','frames','audio_bytes','timestamp_frames','characters','mark_array_lengths_consistent','terminal_observed','errors')}))

if __name__=='__main__':asyncio.run(main())
