"""Bounded, explicitly authorized account smoke tests; no automatic retries or rankings."""
import asyncio,json,os,sys
from pathlib import Path
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/access-20260915'
CREDENTIALS=Path('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
TEXTS={'hi-IN':'नमस्ते, आपका भुगतान मिल गया है। क्या मैं आपकी और मदद कर सकती हूँ?', 'en-IN':'Hello, your payment has been received. How else may I help you?', 'en-US':'Hello, your payment has been received. How else may I help you?', 'ta-IN':'வணக்கம், உங்கள் பணம் கிடைத்தது. மேலும் உதவி தேவையா?'}
async def main(provider):
    secrets=read_credentials(CREDENTIALS)
    keyname={'elevenlabs':'ELEVENLABS_API_KEY','cartesia':'CARTESIA_API_KEY','deepgram':'DEEPGRAM_API_KEY','rime':'RIME_API_KEY'}[provider]
    summary={'provider':provider,'scope':'Bounded live account and synthesis smoke test, not language quality or procurement benchmark','auth':'unverified','balance':'not_queried','native_quality':'not_evaluated','discovery':[], 'runs':[],'automatic_retries':0}
    path=OUT/(provider+'.json');OUT.mkdir(parents=True,exist_ok=True)
    if path.exists(): raise RuntimeError('Existing evidence: refusing accidental repeat spend')
    if not secrets.get(keyname): summary['auth']='missing';path.write_text(json.dumps(summary,indent=2));return
    os.environ[keyname]=secrets[keyname]
    errors=[]
    async def response_hook(response):
        if response.status_code>=400:
            body=(await response.aread())[:4096].decode('utf-8','replace')
            errors.append({'http_status':response.status_code,'message':redact(body,secrets)})
    async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[response_hook]}) as client:
        async def get(url,headers,params=None):
            r=await client.get(url,headers=headers,params=params)
            summary['discovery'].append({'url':url,'http_status':r.status_code})
            if r.status_code==200 and headers: summary['auth']='authenticated_read_succeeded'
            return r.json() if r.status_code==200 else {}
        jobs=[]
        if provider=='cartesia':
            h={'Authorization':'Bearer '+secrets[keyname],'Cartesia-Version':'2026-08-14'}
            for locale in ('hi-IN','en-IN','ta-IN'):
                d=await get('https://api.cartesia.ai/voices',h,{'limit':5,'language':locale})
                voices=[x for x in d.get('data',[]) if any(a.get('locale')==locale and a.get('is_native') for a in x.get('accents',[]))]
                if not voices: continue
                v=voices[0];summary['discovery'][-1]['selected_voice']={k:v[k] for k in ('id','name','accents')}
                jobs.append({'model':'sonic-3.6','voice':v['id'],'language':locale,'format':'raw','encoding':'pcm_s16le','sample_rate':24000})
        elif provider=='elevenlabs':
            h={'xi-api-key':secrets[keyname]}
            for locale,query in [('hi-IN',{'language':'hi'}),('en-IN',{'language':'en','accent':'indian'})]:
                d=await get('https://api.elevenlabs.io/v2/voices',h,{'page_size':20,**query})
                voices=d.get('voices',[])
                if not voices: continue
                v=voices[0];summary['discovery'][-1]['selected_voice']={k:v[k] for k in ('voice_id','name','labels')}
                jobs.append({'model':'eleven_v3','voice':v['voice_id'],'language':locale,'format':'pcm_24000'})
        elif provider=='deepgram':
            d=await get('https://api.deepgram.com/v1/models',{'Authorization':'Token '+secrets[keyname]})
            matches=[x for x in d.get('tts',[]) if x.get('canonical_name')=='aura-2-thalia-en']
            summary['discovery'][-1]['selected_model']=matches
            summary['language_scope']='English US comparator; no Hindi or Indian accent qualification'
            if matches: jobs=[{'model':'aura-2-thalia-en','voice':'aura-2-thalia-en','language':'en-US','format':'linear16','sample_rate':24000}]
        else:
            d=await get('https://users.rime.ai/data/voices/all-v2.json',{})
            for locale,code in [('hi-IN','hin'),('en-US','eng')]:
                voices=d.get('coda',{}).get(code,[])
                if voices:
                    voice=voices[0];summary['discovery'].append({'model':'coda','language':locale,'selected_voice':voice,'catalog_language_code':code})
                    jobs.append({'model':'coda','voice':voice,'language':locale,'format':'pcm_s16le','sample_rate':24000})
            summary['language_scope']='Hindi Coda cloud catalog; English comparator accent not qualified. On-prem coverage differs.'
        for config in jobs[:6]:
            locale=config['language'];text=TEXTS[locale];assert len(text)<180
            before=len(errors)
            r=await run_one(provider,text,config,ROOT/'artifacts/runs/access-20260915'/provider,timeout=30,scenario_id='account-smoke-'+locale,client=client,stratum='smoke_only')
            item={k:r.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','audio_bytes','provider_request_id')}
            item['config']=config;item['errors']=errors[before:];summary['runs'].append(item)
            if r.get('status')=='success': summary['auth']='synthesis_succeeded'
            path.write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),secrets)+'\n')
            if r.get('http_status') in (401,402,403,429): break
    summary['diagnostics']=errors
    if any(e['http_status']==401 for e in errors):summary['auth']='rejected_401'
    if any(e['http_status']==402 for e in errors):summary['balance']='payment_required_402'
    path.write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),secrets)+'\n')
    print(json.dumps({'provider':provider,'auth':summary['auth'],'runs':[{'status':r['status'],'http_status':r['http_status'],'locale':r['config']['language']} for r in summary['runs']]}))
async def eleven_default_probe():
    """Distinct default-voice entitlement diagnostic, not a failed-request retry."""
    secrets=read_credentials(CREDENTIALS);key='ELEVENLABS_API_KEY';os.environ[key]=secrets[key]
    path=OUT/'elevenlabs.json';summary=json.loads(path.read_text())
    if any(r.get('diagnostic')=='default_voice_entitlement' for r in summary['runs']):raise RuntimeError('Diagnostic already executed')
    errors=[]
    async def hook(response):
        if response.status_code>=400: errors.append({'http_status':response.status_code,'message':redact((await response.aread())[:4096].decode('utf8','replace'),secrets)})
    async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
        resp=await client.get('https://api.elevenlabs.io/v2/voices',params={'page_size':100,'voice_type':'default'},headers={'xi-api-key':secrets[key]})
        if resp.status_code!=200:raise RuntimeError('Default catalog unavailable')
        voice=resp.json()['voices'][0]
        summary['discovery'].append({'url':'https://api.elevenlabs.io/v2/voices?voice_type=default','http_status':200,'selected_voice':{k:voice[k] for k in ('voice_id','name','category')}})
        config={'model':'eleven_v3','voice':voice['voice_id'],'language':'hi-IN','format':'pcm_24000'}
        r=await run_one('elevenlabs',TEXTS['hi-IN'],config,ROOT/'artifacts/runs/access-20260915/elevenlabs',timeout=30,scenario_id='default-voice-entitlement-hi',client=client,stratum='smoke_only')
        item={k:r.get(k) for k in ('run_id','status','http_status','error_type','duration_seconds','audio_bytes','provider_request_id')};item.update(config=config,errors=errors,diagnostic='default_voice_entitlement')
        summary['runs'].append(item);summary['diagnostics'].extend(errors)
        summary['voice_entitlement']='Indian library voice requires paid plan; default voice tested separately'
        summary['balance']='not_queried; initial402 was library-voice paid-plan restriction'
        if r['status']=='success':summary['auth']='synthesis_succeeded_default_voice'
        path.write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),secrets)+'\n')
        print(json.dumps({'provider':'elevenlabs','diagnostic':'default_voice_entitlement','status':r['status'],'http_status':r.get('http_status')}))
if __name__=='__main__': asyncio.run(eleven_default_probe() if sys.argv[1]=='eleven-default-diagnostic' else main(sys.argv[1]))
