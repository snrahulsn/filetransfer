"""Publish an explicit measurement denominator from the current evidence snapshot."""
import json
import hashlib
import sys
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.deepgram_flux_evidence import verify as verify_deepgram_flux_interrupt
from tts_arena.matched_latency_evidence import verify as verify_matched_latency
from tts_arena.fish_transport_latency_evidence import verify as verify_fish_transport_latency
from tts_arena.sarvam_transport_latency_evidence import verify as verify_sarvam_transport_latency
from tts_arena.neuphonic_urdu_evidence import verify as verify_neuphonic_urdu
from tts_arena.murf_native_evidence import verify as verify_murf_native
from tts_arena.public_audio_integrity import verify as verify_public_audio
from tts_arena.codemix_asr_evidence import verify as verify_codemix_asr
from tts_arena.regional_asr_evidence import verify as verify_regional_asr
from tts_arena.current_revision_api_evidence import verify as verify_current_revision_api
from tts_arena.soniox_playout_evidence import verify as verify_soniox_playout
from tts_arena.sarvam_native_evidence import verify as verify_sarvam_native
from tts_arena.sarvam_playout_evidence import verify as verify_sarvam_playout
from tts_arena.soniox_speed_evidence import verify_four_setting_sweep as verify_soniox_speed
SNAPSHOT=ROOT/'ui/public/evidence/snapshot.json'
API=ROOT/'ui/public/evidence/working-api-reference.json'
OUTPUT=ROOT/'ui/public/evidence/progress-ledger.json'
DOC=ROOT/'docs/MEASUREMENT_PROGRESS.md'
LOCALES=('en-IN','hi-IN','bn-IN','mr-IN','te-IN','ta-IN','gu-IN','ur-IN','kn-IN','ml-IN')
LIVE_LEVELS={'measured_output','metadata_observed','payload_observed','request_accepted'}
EXCLUDED_STATES={'skipped_by_user','deferred_by_deployment_scope'}

def build():
 snapshot=json.loads(SNAPSHOT.read_text());api=json.loads(API.read_text())
 access={row['provider']:row['access_state'] for row in snapshot['access_audit']}
 providers={p['id']:p for p in snapshot['providers']}
 if set(access)!=set(providers):raise ValueError('Access audit/provider set mismatch')
 active={pid for pid in providers if access[pid] not in EXCLUDED_STATES}
 excluded=sorted(set(providers)-active)
 features={f for pid in active for f in providers[pid]['features']}
 if len(features)!=17 or any(set(providers[pid]['features'])!=features for pid in active):raise ValueError('Feature grid differs by provider')
 eligible_locales={(pid,locale) for pid in active for locale in LOCALES if providers[pid]['languages'][locale]['status']!='unsupported'}
 eligible_features={(pid,feature) for pid in active for feature in features if providers[pid]['features'][feature]['status']!='unsupported'}
 run_ids={r['run_id'] for r in snapshot['runs']}|{r.get('run_id') for r in snapshot['native_sessions']}
 audio=set()
 for r in [*snapshot['runs'],*snapshot['local_runs']]:
  if r.get('audio_url') and r['provider'] in active and r['language'] in LOCALES:audio.add((r['provider'],r['language']))
 for r in snapshot['maya_local_runs']:
  if r.get('audio_url') and 'maya' in active and r['language'] in LOCALES:audio.add(('maya',r['language']))
 for r in snapshot['studio_audio_runs']:
  if r.get('audio_url') and r['provider'] in active and r['language'] in LOCALES:
   audio.add((r['provider'],r['language']))
 live=set()
 for o in snapshot['feature_observations']:
  if o['provider'] not in active or o['level'] not in LIVE_LEVELS:continue
  source=(ROOT/o['source']).resolve() if o.get('source') else None
  valid_source=bool(source and source.is_relative_to(ROOT/'artifacts') and source.exists())
  if o['feature'] not in features or not (set(o.get('run_ids',[]))<=run_ids and (o.get('run_ids') or valid_source)):
   raise ValueError('Live control observation lacks saved run or artifact evidence')
  live.add((o['provider'],o['feature']))
 route_ids={r['provider'] for r in api['routes']}|{r['provider'] for r in api['local_models']}
 if not route_ids<=active or len(route_ids)!=len(api['routes'])+len(api['local_models']):raise ValueError('Working route scope mismatch')
 if any(not r['request_contract_matches_current_adapter'] for r in api['routes']):raise ValueError('Current request comparison failed')
 published_integrity=json.loads((ROOT/'ui/public/evidence/audio-integrity-audit.json').read_text())
 if published_integrity!=verify_public_audio(ROOT):
  raise ValueError('Published audio inventory differs from independently decoded WAVs')
 published_codemix=json.loads((ROOT/'ui/public/evidence/codemix-asr-audit.json').read_text())
 if snapshot.get('codemix_asr_audit')!=published_codemix or published_codemix!=verify_codemix_asr(ROOT):
  raise ValueError('Matched code-switch ASR scores differ from source WAVs and observations')
 published_regional=json.loads((ROOT/'ui/public/evidence/regional-asr-audit.json').read_text())
 if snapshot.get('regional_asr_audit')!=published_regional or published_regional!=verify_regional_asr(ROOT):
  raise ValueError('Regional ASR scores differ from source WAVs and observations')
 if snapshot.get('current_revision_api_audit'):
  published_current=json.loads((ROOT/'ui/public/evidence/current-revision-api-audit.json').read_text())
  if snapshot['current_revision_api_audit']!=published_current or published_current!=verify_current_revision_api(ROOT):
   raise ValueError('Current-revision API statuses differ from saved requests and WAVs')
 if not audio<=eligible_locales or not live<=eligible_features:raise ValueError('Saved output contradicts catalog unsupported status')
 speed_audit=verify_soniox_speed(ROOT)
 published_speed=json.loads((ROOT/'ui/public/evidence/soniox-speed-audit.json').read_text())
 if snapshot.get('soniox_speed_audit')!=speed_audit or published_speed!=speed_audit or ('soniox','speed') not in live:
  raise ValueError('Soniox speed source, public audit or feature cell differs')
 for clip in speed_audit['sweep_clips']:
  public=next((r for r in snapshot['runs'] if r['run_id']==clip['run_id']),None)
  if not public or public.get('listening_audio_sha256')!=clip['playable_wav_sha256'] or not public.get('audio_url'):
   raise ValueError('Soniox speed clip lacks verified site audio')
 sarvam_native=verify_sarvam_native(ROOT/'artifacts/sessions/sarvam-native-20260916')
 sarvam_published=json.loads((ROOT/'ui/public/evidence/sarvam-native-audit.json').read_text())
 sarvam_public=next((r for r in snapshot['native_audio_runs']
  if r.get('audio_url')=='/evidence/audio/sarvam-bulbul-v3-native-hi-IN.wav'),None)
 if (snapshot.get('sarvam_native_audit')!=sarvam_native or sarvam_published!=sarvam_native or
     not sarvam_public or sarvam_public['audio_sha256']!=sarvam_native['wav_sha256'] or
     not {('sarvam','audio_streaming'),('sarvam','text_input_streaming'),('sarvam','flush')}<=live):
  raise ValueError('Sarvam native feature/audio measurement differs from saved MP3 frames')
 neuphonic_urdu=verify_neuphonic_urdu(ROOT/'artifacts/neuphonic-urdu-20260916')
 if snapshot.get('neuphonic_urdu_audit')!=neuphonic_urdu or ('neuphonic','ur-IN') not in audio:
  raise ValueError('Neuphonic Urdu public output differs from verified two-voice evidence')
 murf_native,murf_wav=verify_murf_native(ROOT)
 from tts_arena.murf_locale_style_evidence import verify as verify_murf_locale_styles
 if snapshot.get('murf_locale_style_audit')!=verify_murf_locale_styles(ROOT):
  raise ValueError('Murf model/locale style eligibility differs from saved voice catalog')
 murf_public=next((r for r in snapshot['native_audio_runs'] if r['provider']=='murf' and r['model']=='falcon-2' and r['language']=='hi-IN'),None)
 if (snapshot.get('murf_native_audit')!=dict(murf_native,audio_url='/evidence/audio/murf-falcon-2-native-hi-IN.wav')
     or not murf_public or murf_public['audio_sha256']!=murf_native['playable_wav_sha256']
     or ('murf','audio_streaming') not in live or 'murf' not in active):
  raise ValueError('Murf native audio/control evidence differs from public measurement cell')
 from tts_arena.murf_clear_evidence import verify as verify_murf_clear
 clear_audit,clear_wavs=verify_murf_clear(ROOT)
 for clip in clear_audit['clips']:
  clip['audio_url']='/evidence/audio/murf-clear-'+clip['id']+'-hi-IN.wav'
 if snapshot.get('murf_clear_audit')!=clear_audit or not {'cancel','connection_reuse'}<= {f for p,f in live if p=='murf'}:
  raise ValueError('Murf clear/recovery audit differs from public feature cells')
 for clip in clear_audit['clips']:
  public=next((r for r in snapshot['native_audio_runs'] if r.get('audio_url')==clip['audio_url']),None)
  if not public or public['audio_sha256']!=clip['playable_wav_sha256'] or hashlib.sha256(clear_wavs[clip['id']]).hexdigest()!=public['audio_sha256']:
   raise ValueError('Murf clear/recovery playable audio mismatch')
 flux_barge=verify_deepgram_flux_interrupt(ROOT/'artifacts/deepgram-flux-interrupt-20260915-v3')
 public_barge=snapshot.get('deepgram_flux_interrupt_audit')
 if not public_barge or any(public_barge.get(k)!=flux_barge[k] for k in ('provider','model','status','played_audio_ms','native_interrupt_ack_ms','old_received_not_played_bytes_discarded','caller_fixture_sha256')):
  raise ValueError('Flux public barge-in audit does not match verified raw evidence')
 if flux_barge['provider'] not in active:raise ValueError('Flux barge-in result outside active scope')
 barge_cells={flux_barge['provider']}
 soniox_barge=verify_soniox_playout(ROOT/'artifacts/soniox-playout-20260916')
 published_soniox=json.loads((ROOT/'ui/public/evidence/soniox-playout-audit.json').read_text())
 soniox_public_audio=next((r for r in snapshot['native_audio_runs']
  if r.get('audio_url')=='/evidence/audio/soniox-cancel-recovery-hi-IN.wav'),None)
 if (snapshot.get('soniox_playout_audit')!=soniox_barge or
     published_soniox!=soniox_barge or not soniox_public_audio or
     soniox_public_audio['audio_sha256']!=soniox_barge['recovery_wav_sha256'] or
     'soniox' not in active):
  raise ValueError('Soniox barge-in source, public audit or recovery WAV differs')
 barge_cells.add('soniox')
 sarvam_barge=verify_sarvam_playout(ROOT/'artifacts/sarvam-playout-20260916')
 sarvam_public_audit=json.loads((ROOT/'ui/public/evidence/sarvam-playout-audit.json').read_text())
 sarvam_old=next((r for r in snapshot['native_audio_runs'] if
  r.get('audio_url')=='/evidence/audio/sarvam-interrupted-old-hi-IN.wav'),None)
 sarvam_recovery=next((r for r in snapshot['native_audio_runs'] if
  r.get('audio_url')=='/evidence/audio/sarvam-interruption-recovery-hi-IN.wav'),None)
 if (snapshot.get('sarvam_playout_audit')!=sarvam_barge or
     sarvam_public_audit!=sarvam_barge or not sarvam_old or not sarvam_recovery or
     sarvam_old['audio_sha256']!=sarvam_barge['old_wav_sha256'] or
     sarvam_recovery['audio_sha256']!=sarvam_barge['recovery_wav_sha256'] or
     ('sarvam','cancel') not in live or 'sarvam' not in active):
  raise ValueError('Sarvam close/recovery source, public audit, feature or WAV differs')
 barge_cells.add('sarvam')
 balanced_latency=verify_matched_latency(ROOT/'artifacts/latency-balanced-20260915-v2')
 if snapshot.get('matched_latency_audit')!=balanced_latency or not balanced_latency['matched_route_comparison_qualified'] or balanced_latency['client_egress_country']!='IN':
  raise ValueError('Balanced first-audio public audit does not match verified India-egress raw evidence')
 latency_manifest=json.loads((ROOT/'artifacts/latency-balanced-20260915-v2/manifest.json').read_text())
 latency_runs={r['run_id']:r for r in snapshot['runs'] if r.get('audio_url')}
 if any(r['run_id'] not in latency_runs or latency_runs[r['run_id']]['provider']!=r['provider'] or latency_runs[r['run_id']]['language']!='hi-IN' for r in latency_manifest['results']):
  raise ValueError('Balanced latency run lacks published model/locale audio')
 latency_cells={(pid,'hi-IN') for pid in balanced_latency['groups']}
 fish_latency=verify_fish_transport_latency(ROOT/'artifacts/fish-transport-latency-20260916')
 if snapshot.get('fish_transport_latency_audit')!=fish_latency or not fish_latency['qualified_route_comparison'] or fish_latency['client_egress_country']!='IN':
  raise ValueError('Fish transport latency public audit differs from raw evidence')
 fish_manifest=json.loads((ROOT/'artifacts/fish-transport-latency-20260916/manifest.json').read_text())
 if any(r['run_id'] not in latency_runs or latency_runs[r['run_id']]['provider']!='fish' or latency_runs[r['run_id']]['language']!='hi-IN' for r in fish_manifest['results'] if r['route']=='rest'):
  raise ValueError('Fish transport REST trial lacks published Hindi PCM audio')
 fish_native={r['audio_url'] for r in snapshot['native_audio_runs'] if r['provider']=='fish' and r.get('transport_latency_ordinal')}
 if len(fish_native)!=12 or any(not (ROOT/'ui/public'/url.lstrip('/')).is_file() for url in fish_native):
  raise ValueError('Fish transport WebSocket trial lacks 12 published audio files')
 latency_cells.add(('fish','hi-IN'))
 sarvam_latency=verify_sarvam_transport_latency(ROOT/'artifacts/sarvam-transport-latency-20260916-v2')
 sarvam_published=json.loads((ROOT/'ui/public/evidence/sarvam-transport-latency-audit.json').read_text())
 if (snapshot.get('sarvam_transport_latency_audit')!=sarvam_latency or
     sarvam_published!=sarvam_latency or not sarvam_latency['qualified_route_comparison'] or
     sarvam_latency['client_egress_country']!='IN'):
  raise ValueError('Sarvam balanced MP3 route audit differs from saved evidence')
 sarvam_files={r['audio_url']:r['audio_sha256'] for r in snapshot['native_audio_runs']
  if r['provider']=='sarvam' and r.get('transport_latency_ordinal')}
 if len(sarvam_files)!=24 or any(
  sarvam_files.get('/evidence/audio/sarvam-transport-'+c['route']+'-'+f"{c['ordinal']:02d}"+'-hi-IN.wav')!=c['wav_sha256']
  for c in sarvam_latency['clips']):
  raise ValueError('Sarvam MP3 route trial lacks 24 verified public WAVs')
 latency_cells.add(('sarvam','hi-IN'))
 if not latency_cells<=eligible_locales:raise ValueError('Balanced latency result outside eligible locale scope')
 count=len(active);locale_cells=len(eligible_locales);feature_cells=len(eligible_features)
 categories=[
  {'id':'working_synthesis_route','label':'Working synthesis route','denominator':count,'completed':len(route_ids),'gate':'Saved playable output plus current request construction for hosted routes; saved batch output for local models.'},
  {'id':'playable_locale_audio','label':'Playable vendor-locale audio','denominator':locale_cells,'completed':len(audio),'gate':'At least one hash-verified playable file requested for that exact locale. Catalog cells marked unsupported are excluded; delivery is not language correctness.'},
  {'id':'live_feature_probe','label':'Live feature-control probe','denominator':feature_cells,'completed':len(live),'gate':'Saved run supports an observed request, payload, metadata or output for the vendor-feature cell. Catalog cells marked unsupported are excluded; this is a narrow observation.'},
  {'id':'native_language_correctness','label':'Native language correctness','denominator':locale_cells,'completed':0,'gate':'Native-reviewed text/entity references and qualified judgments for the vendor-locale cell.'},
  {'id':'native_naturalness_accent','label':'Native naturalness and accent','denominator':locale_cells,'completed':0,'gate':'Qualified blinded native-listener score for the vendor-locale cell.'},
  {'id':'matched_first_audio_latency','label':'Matched first-audio latency','denominator':locale_cells,'completed':len(latency_cells),'gate':'Pinned Hindi prompt, balanced route order, India client egress before and after, 12 requests per route with p50/p95 intervals. Cartesia/ElevenLabs and Fish use native 24 kHz PCM16; Sarvam uses native 24 kHz MP3 in a separate same-model HTTP-stream-versus-WebSocket study. No cross-study or production-load ranking.'},
  {'id':'verified_cost','label':'Verified generated-minute cost','denominator':count,'completed':0,'gate':'Account-specific invoice or usage reconciliation, including local infrastructure utilization where applicable.'},
  {'id':'barge_in','label':'Barge-in end-to-end','denominator':count,'completed':len(barge_cells),'gate':'Labelled synthetic caller onset through audio removal and recovery on the software receiver timeline; production VAD and SIP/RTP/handset remain separate.'},
 ]
 if snapshot['verification']['native_listener_ratings'] or snapshot['verification']['production_calls'] or snapshot['transcript_audit']['native_reviewed_references']:
  raise ValueError('Qualification evidence exists; revise zero-completion gates before publishing')
 for row in categories:row['completion_percent']=round(100*row['completed']/row['denominator'],1)
 total=sum(r['denominator'] for r in categories);done=sum(r['completed'] for r in categories)
 data={'schema_version':1,'generated_at':datetime.now(timezone.utc).isoformat(),'snapshot_code_sha256':snapshot['code_sha256'],'catalog_candidates':len(providers),'active_candidates':count,'excluded_candidates':excluded,'locales':list(LOCALES),'features':sorted(features),'catalog_unsupported_locale_cells':count*len(LOCALES)-locale_cells,'catalog_unsupported_feature_cells':count*len(features)-feature_cells,'categories':categories,'overall':{'completed':done,'denominator':total,'remaining':total-done,'completion_percent':round(100*done/total,1)},'counting_rule':'Each row is one scoped vendor, eligible vendor-locale or eligible vendor-feature cell. Catalog cells marked unsupported are excluded from audio/feature/quality/latency targets but stay visible in the comparison. Delivery and narrow API probes count only in their own rows; they do not satisfy listening, fair latency, cost or barge-in gates.'}
 OUTPUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 lines=['# Measurement progress','',f"Current scoped grid: **{done} / {total} points ({data['overall']['completion_percent']:.1f}%)**. This has {count} active candidates across {len(LOCALES)} locales and {len(features)} feature controls. The catalog also retains {len(excluded)} excluded entries: {', '.join(excluded)}.",'','| Measurement | Completed | Needed | Completion | Passing rule |','|---|---:|---:|---:|---|']
 for r in categories:lines.append(f"| {r['label']} | {r['completed']} | {r['denominator']} | {r['completion_percent']:.1f}% | {r['gate']} |")
 lines+=['',data['counting_rule'],'',f"Source snapshot hash: `{snapshot['code_sha256']}`. Machine-readable ledger: `ui/public/evidence/progress-ledger.json`. The ledger is regenerated after any new evidence export; new candidates enter the denominator automatically unless their access state is explicitly skipped or deferred.",'']
 DOC.write_text('\n'.join(lines))
 print(json.dumps({'completed':done,'denominator':total,'percent':data['overall']['completion_percent'],'audio_cells':len(audio),'feature_cells':len(live),'active':count}))
 return data

if __name__=='__main__':build()
