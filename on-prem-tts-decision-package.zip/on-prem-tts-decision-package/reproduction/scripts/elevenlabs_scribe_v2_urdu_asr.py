"""Two-recording ElevenLabs Scribe v2 cross-ASR diagnostic; offline by default."""
import argparse
import json
import math
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from sarvam_saaras_v3_asr import preflight as saved_audio_preflight, _checkpoint
from tts_arena.credentials import read_credentials

REFERENCE_IDS = (
    '337d23980ea44196b15e450a55d97120',  # ElevenLabs TTS, Urdu-labeled
    '5bd80ef7506a40ec8a553e73973784a9',  # Google TTS, Urdu-labeled
)
PROVIDERS = ('elevenlabs', 'google')
MODEL = 'scribe_v2'
ENGINE_ID = 'elevenlabs.scribe_v2.auto'
ENDPOINT = 'https://api.elevenlabs.io/v1/speech-to-text'
CREDENTIALS = Path('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')


def preflight(reference_id=None):
    if reference_id is not None and reference_id not in REFERENCE_IDS:
        raise ValueError('Only the two pinned Urdu reference IDs are allowed')
    selected = (reference_id,) if reference_id is not None else REFERENCE_IDS
    # The shared saved-audio checks bind exact reference/run/provenance/WAV hashes
    # and reject audio over 30 seconds before this runner reads a credential.
    planned = saved_audio_preflight(list(selected), 'verbatim', len(selected))
    if tuple(row[0]['reference_id'] for row in planned) != selected:
        raise ValueError('Urdu cross-ASR selection changed')
    expected_providers = {rid: provider for rid, provider in zip(REFERENCE_IDS, PROVIDERS)}
    for ref, _audio, _data, duration in planned:
        provider = expected_providers[ref['reference_id']]
        if ref['provider'] != provider or ref['language'] != 'ur-IN' or duration < 0.1:
            raise ValueError('Cross-ASR source identity or minimum duration mismatch')
    return planned


def read_key():
    key = read_credentials(str(CREDENTIALS)).get('ELEVENLABS_API_KEY')
    if not isinstance(key, str) or not key.strip():
        raise ValueError('ELEVENLABS_API_KEY unavailable in authorized credential file')
    return key


def _multipart(data, filename):
    boundary = 'arena-' + uuid.uuid4().hex
    chunks = []
    # Omit language_code: official docs specify automatic prediction when null.
    # Disable event tags and timestamps so text remains a plain lexical observation.
    for name, value in (('model_id', MODEL), ('tag_audio_events', 'false'),
                        ('timestamps_granularity', 'none'), ('use_multi_channel', 'false'),
                        ('webhook', 'false')):
        chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode())
    chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\nContent-Type: audio/wav\r\n\r\n').encode())
    chunks.extend((data, b'\r\n', f'--{boundary}--\r\n'.encode()))
    return boundary, b''.join(chunks)


def request_one(data, filename, key, opener=None):
    boundary, body = _multipart(data, filename)
    request = urllib.request.Request(ENDPOINT, data=body, method='POST', headers={
        'xi-api-key': key, 'Content-Type': f'multipart/form-data; boundary={boundary}',
        'Accept': 'application/json'})
    try:
        response = (opener or urllib.request.urlopen)(request, timeout=60)
        with response:
            raw = response.read(1_000_001)
            if len(raw) > 1_000_000:
                raise ValueError('Scribe response exceeds local size bound')
            result = json.loads(raw)
    except urllib.error.HTTPError as exc:
        # The vendor error body can echo supplied media or content.
        raise ValueError(f'Scribe HTTP status {exc.code}') from None
    except urllib.error.URLError:
        raise ValueError('Scribe transport failure') from None
    if not isinstance(result, dict) or not isinstance(result.get('text'), str):
        raise ValueError('Scribe response lacks a string text field')
    detected = result.get('language_code')
    if not isinstance(detected, str) or not detected or len(detected) > 20 or not detected.replace('-', '').isalpha():
        raise ValueError('Scribe response lacks a valid detected language code')
    probability = result.get('language_probability')
    if probability is not None and (type(probability) not in (int, float) or
                                    not math.isfinite(probability) or not 0 <= probability <= 1):
        raise ValueError('Scribe response has invalid language probability')
    # Whitelist only; words, entities, and vendor-added echoed fields are discarded.
    return {'text': result['text'], 'language_code': detected,
            'language_probability': probability}


def run(output, live=False, opener=None, key=None, reference_id=None):
    planned = preflight(reference_id)
    count = len(planned)
    if not live:
        return {'status': 'preflight_passed', 'reference_ids': [row[0]['reference_id'] for row in planned],
                'requests': 0, 'planned_requests': count, 'model': MODEL,
                'language_code_parameter': 'omitted_for_auto_detection',
                'certification': False}
    destination = Path(output)
    if destination.exists():
        raise ValueError('Output exists; prior evidence must be preserved')
    credential = key if key is not None else read_key()
    destination.mkdir(parents=True, mode=0o700)
    os.chmod(destination, 0o700)
    observations, private = [], []
    _checkpoint(destination, observations, private, {'status': 'in_progress',
                'completed_requests': 0, 'planned_requests': count, 'certification': False})
    for ref, audio, data, duration in planned:
        try:
            response = request_one(data, audio.name, credential, opener=opener)
        except ValueError as exc:
            _checkpoint(destination, observations, private, {'status': 'partial_failure',
                        'completed_requests': len(observations), 'planned_requests': count,
                        'failed_reference_id': ref['reference_id'], 'error': str(exc),
                        'resume_policy': 'no_automatic_retry_or_resume', 'certification': False})
            raise
        rid = ref['reference_id']
        observations.append({'observation_id': f'elevenlabs_scribe_v2_auto_{rid}',
                             'reference_id': rid,
                             **{k: ref[k] for k in ('run_id', 'provider', 'model', 'language', 'audio_sha256')},
                             'source': 'asr', 'transcriber_id': ENGINE_ID,
                             'text': response['text'],
                             'detected_language_code': response['language_code'],
                             'detected_language_probability': response['language_probability']})
        private.append({'reference_id': rid, 'sanitized_response': response,
                        'audio_duration_seconds': duration,
                        'requested_language_code': None})
        _checkpoint(destination, observations, private, {'status': 'in_progress',
                    'completed_requests': len(observations), 'planned_requests': count,
                    'certification': False})
    _checkpoint(destination, observations, private, {'status': 'complete',
                'completed_requests': count, 'planned_requests': count, 'certification': False})
    return {'status': 'transcript_observations_written', 'requests': count,
            'observations_file': str((destination / 'observations.json').resolve()),
            'private_responses_file': str((destination / 'private_sanitized_responses.json').resolve()),
            'model': MODEL, 'certification': False,
            'limitation': 'Cross-ASR is diagnostic; Urdu-labeled draft references are not native-reviewed.'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    parser.add_argument('--reference-id', choices=REFERENCE_IDS,
                        help='Select one pinned recording for a one-request smoke; omit for both')
    parser.add_argument('--live', action='store_true', help='Explicitly send the two pinned WAVs')
    args = parser.parse_args(argv)
    try:
        print(json.dumps(run(args.output, live=args.live, reference_id=args.reference_id), ensure_ascii=False, indent=2))
        return 0
    except (ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as exc:
        print(f'{type(exc).__name__}: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
