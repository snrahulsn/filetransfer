"""Offline validation and aggregation of genuine Indic language review exports."""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.language_review_ingest import evaluate_files
POINTER = ROOT / 'artifacts/listening/current-language-study.json'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    current_id = json.loads(POINTER.read_text())['study_id'] if POINTER.exists() else 'indic-language-02c80dcdde9f'
    parser.add_argument('--study', type=Path, default=ROOT / 'artifacts/listening' / current_id)
    parser.add_argument('--ratings', type=Path, nargs='+', required=True)
    parser.add_argument('--roster', type=Path, required=True)
    parser.add_argument('--references', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve().is_relative_to((ROOT / 'ui/public').resolve()):
        parser.error('Review evidence with reviewer IDs must remain outside the public website')
    result = evaluate_files(args.study, args.ratings, args.roster, args.references)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('submitted_ratings', 'accepted_ratings',
                                                   'pending_qualification', 'pending_reference',
                                                   'vendor_certifications')}, indent=2))


if __name__ == '__main__':
    main()
