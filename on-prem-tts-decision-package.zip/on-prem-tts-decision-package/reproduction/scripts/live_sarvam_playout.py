"""One capped Bulbul v3 close/reconnect software-receiver run, zero retries."""
import asyncio
import json
import shutil
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.sarvam_playout import preflight,replay_sarvam

OUT=ROOT/'artifacts/sarvam-playout-20260916'
CALLER=ROOT/'artifacts/calibration/soniox-caller-tone-24000.wav'
KEY_FILE='/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env'
OLD=('नमस्ते। मैं आपकी अगली किस्त की तारीख और राशि बताने के लिए बोल रहा हूँ। '
     'हमारे रिकॉर्ड में भुगतान की तारीख सत्रह सितंबर है और कुल राशि पाँच हजार रुपये है। '
     'अगर यह जानकारी गलत है, तो अभी बीच में बोलकर मुझे रोकें और सही तारीख तथा राशि बताइए। '
     'मैं पूरी जानकारी दोहराकर पुष्टि कर दूँगा।')
RECOVERY='जी, मैंने आपकी बात सुन ली है। कृपया सही तारीख बताइए।'


async def main():
    if OUT.exists():raise FileExistsError('Existing paid Sarvam playout run; no retry')
    if shutil.disk_usage(ROOT).free<500*1024*1024:raise RuntimeError('Disk preflight failed')
    preflight(CALLER,OLD,RECOVERY,{'SARVAM_API_KEY':'offline-test'},12)
    key=read_credentials(KEY_FILE).get('SARVAM_API_KEY')
    if not key:raise RuntimeError('Authorized Sarvam key unavailable')
    result=await replay_sarvam(CALLER,OUT,OLD,RECOVERY,{'SARVAM_API_KEY':key},
                               observation_seconds=12,onset_offset_ms=120,
                               stop_threshold_ms=500)
    bridge=result['sarvam_bridge']
    print(json.dumps({'receiver_status':result['status'],
                      'bridge_status':bridge['status'],
                      'error_type':bridge['error_type'],
                      'old_final_before_clear':bridge['old_final_before_clear'],
                      'old_socket_closed':bridge['old_vendor_socket_closed'],
                      'recovery_socket_connected':bridge['recovery_socket_connected'],
                      'recovery_final':bridge['recovery_final'],
                      'metrics':result.get('metrics'),
                      'artifacts':sorted(bridge['artifacts'])}))


if __name__=='__main__':asyncio.run(main())
