"""One bounded Cartesia Sonic 3.6 software-playout probe; no retries.

Its default caller is a synthetic calibration tone, never native speech, VAD,
or production-telephony evidence.
"""
import argparse
import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.cartesia_playout import preflight, replay_cartesia
from tts_arena.credentials import read_credentials


DEFAULT_CREDENTIALS = Path("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Bounded local PCM-playout bridge; not a production telephony probe."
    )
    parser.add_argument("--caller", type=Path, default=ROOT / "artifacts/calibration/tone-fixture.wav")
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts/cartesia-playout-20260915")
    parser.add_argument("--credentials", type=Path, default=DEFAULT_CREDENTIALS)
    parser.add_argument("--seconds", type=float, default=3.0)
    args = parser.parse_args(argv)
    config = {
        "model": "sonic-3.6",
        "voice": "4459a9a5-69d6-4680-b970-e13dc51845b6",
        "language": "hi-IN",
        "format": "raw",
        "encoding": "pcm_s16le",
        "sample_rate": 8000,
        "context_id": "cartesia-playout-20260915",
        "max_buffer_delay_ms": 0,
    }
    text = (
        "नमस्ते, मैं आपकी सहायता कर रहा हूँ। कृपया अपनी बात बताइए ताकि मैं सही "
        "जानकारी दे सकूँ।"
    )
    if args.output.exists():
        raise RuntimeError("Output guard: this bounded probe has already been started")
    # Validate config and caller before opening the authorized credential file.
    preflight(config, text, {"CARTESIA_API_KEY": "offline-validation"}, args.caller, 8000, args.seconds)
    credentials = read_credentials(args.credentials)
    if not credentials.get("CARTESIA_API_KEY"):
        raise ValueError("CARTESIA_API_KEY is missing from the explicitly selected credential file")
    result = asyncio.run(
        replay_cartesia(
            args.caller,
            args.output,
            config,
            text,
            {"CARTESIA_API_KEY": credentials["CARTESIA_API_KEY"]},
            sample_rate=8000,
            onset_offset_ms=250,
            observation_seconds=args.seconds,
            stop_threshold_ms=500,
            caller_fixture_label=(
                "synthetic_tone_calibration_fixture; not native speech, VAD, or "
                "production_telephony evidence"
            ),
        )
    )
    print(
        {
            "status": result["status"],
            "result": str(args.output / "result.json"),
            "bridge": str(args.output / "cartesia-bridge.json"),
            "scope": "synthetic tone + software PCM playout only; not native speech, VAD, or production telephony",
        }
    )


if __name__ == "__main__":
    main()
