"""Bounded current-model Speechify discovery; no unsupported-language fallback."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
async def main():
    path=ROOT/"artifacts/access-20260915/speechify.json"
    with path.with_suffix(".started").open("x") as f:f.write("Authorized one bounded discovery and synthesis sequence; no automatic rerun.\n")
    creds=read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env")
    key=creds["SPEECHIFY_API_KEY"]
    result={"provider":"speechify","model":"simba-3.2","checked_at":"2026-09-15","credential_present":True,"discovery":[],"runs":[],"automatic_retries":0,"scope":"Current-model access only; no native quality certification","language_restriction":"Official Simba 3.2 is English-only; Hindi and regional requests not sent; no retired-model fallback","sources":["https://docs.speechify.ai/build/guides/concepts/models","https://docs.speechify.ai/build/api-reference/v1/voices/get","https://docs.speechify.ai/tts/guides/emotion-control"]}
    def save():path.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+"\n")
    save()
    errors=[]
    async def hook(response):
        if response.status_code>=400:
            await response.aread();errors.append({"http_status":response.status_code,"message":redact(response.text,creds)[:1500]})
    headers={"Authorization":"Bearer "+key,"Speechify-Version":"2026-09-15"}
    async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={"response":[hook]}) as client:
        voices=[]
        for route in ("/v1/audio/models","/v1/voices?model=simba-3.2&locale=en-IN&type=shared&limit=200"):
            response=await client.get("https://api.speechify.ai"+route,headers=headers)
            entry={"url":"https://api.speechify.ai"+route,"http_status":response.status_code,"request_api_version":"2026-09-15"}
            if response.status_code==200:
                payload=response.json();entry["response"]=payload
                if "/voices" in route:voices=payload.get("voices",[]) if isinstance(payload,dict) else payload
            else:entry["diagnostics"]=errors.copy()
            result["discovery"].append(entry);save()
            print("Speechify discovery HTTP "+str(response.status_code),flush=True)
            if response.status_code>=400:result["blocker"]="discovery_failed";save();return
        matching=[v for v in voices if v.get("locale","").lower()=="en-in" and any(m.get("name")=="simba-3.2" for m in v.get("models",[]))]
        result["indian_english_catalog_matches"]=len(matching)
        if not matching:
            result["blocker"]="no_verified_current_model_indian_english_voice_in_filtered_catalog"
            result["successful_syntheses"]=0;save();return
        voice=matching[0];result["selected_voice"]={k:voice.get(k) for k in ("id","display_name","locale","models")};save()
        os.environ["SPEECHIFY_API_KEY"]=key
        try:
            for label,text in [("access","Hello, we have received your payment. Thank you."),("neutral","Your appointment is confirmed. We look forward to speaking with you."),("cheerful","<speak><speechify:style emotion=\"cheerful\">Your appointment is confirmed. We look forward to speaking with you.</speechify:style></speak>")]:
                assert len(text)<=180
                config={"model":"simba-3.2","voice":voice["id"],"language":"en-IN","format":"pcm_16000","api_version":"2026-09-15","mode":"stream"}
                errors.clear()
                record=await run_one("speechify",text,config,ROOT/"artifacts/runs/access-20260915/speechify",timeout=30,client=client,scenario_id="current-"+label,stratum="draft_access_probe")
                attempt={k:record.get(k) for k in ["run_id","status","http_status","error_type","language","audio_bytes","duration_seconds","first_audio_ms","elapsed_ms","audio_analysis"]}
                attempt.update(config=config,diagnostics=errors.copy(),label=label,linguistic_accuracy="unverified",emotion_perception="unverified")
                result["runs"].append(attempt);save();print("Speechify "+label+" "+record["status"]+" HTTP "+str(record.get("http_status")),flush=True)
                if record["status"]!="success":result["blocker"]="synthesis_failed";save();break
            result["successful_syntheses"]=sum(r["status"]=="success" for r in result["runs"]);save()
        finally:os.environ.pop("SPEECHIFY_API_KEY",None)
if __name__=="__main__":asyncio.run(main())
