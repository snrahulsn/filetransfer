"""Build a credential-free reference from saved HTTP success and current dry request contracts."""
import hashlib,json,os,sys,re
from datetime import datetime
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.registry import build_request,catalog,digest
from tts_arena.fish_timestamp_evidence import verify as verify_fish_timestamps
from tts_arena.neuphonic_urdu_evidence import verify as verify_neuphonic_urdu
from tts_arena.murf_native_evidence import verify as verify_murf_native
from tts_arena.current_revision_api_evidence import verify as verify_current_revision_api
from tts_arena.soniox_playout_evidence import verify as verify_soniox_playout
from tts_arena.sarvam_native_evidence import verify as verify_sarvam_native
from tts_arena.sarvam_playout_evidence import verify as verify_sarvam_playout
from tts_arena.sessions import murf as murf_socket
SNAPSHOT=ROOT/'ui/public/evidence/snapshot.json'
OUT=ROOT/'ui/public/evidence/working-api-reference.json'
DOC=ROOT/'docs/WORKING_API_REFERENCE.md'
PLACEHOLDER='synthetic-test-credential'

def raw_index():
 index={}
 for path in (ROOT/'artifacts').rglob('result.json'):
  try:r=json.loads(path.read_text())
  except (ValueError,OSError):continue
  if r.get('evidence_class')!='live_http' or not r.get('run_id'):continue
  if r['run_id'] in index:raise ValueError('Duplicate live HTTP run ID')
  index[r['run_id']]=(r,path)
 return index

def build():
 snapshot=json.loads(SNAPSHOT.read_text());raw=raw_index();providers={p['id']:p for p in catalog()}
 current_audit=snapshot.get('current_revision_api_audit')
 if current_audit and current_audit!=verify_current_revision_api(ROOT):
  raise ValueError('Current-revision API reference differs from verified live runs')
 current_results={r['provider']:r for r in current_audit['results']} if current_audit else {}
 neuphonic_urdu=verify_neuphonic_urdu(ROOT/'artifacts/neuphonic-urdu-20260916')
 if snapshot.get('neuphonic_urdu_audit')!=neuphonic_urdu:
  raise ValueError('Working API Neuphonic voice discovery differs from raw Urdu evidence')
 credential_env={name:PLACEHOLDER for p in providers.values() for name in p.get('credentials',[])}
 credential_env.update(GNANI_API_KEY=PLACEHOLDER,GNANI_TTS_API_KEY=PLACEHOLDER,GOOGLE_API_KEY=PLACEHOLDER,GOOGLE_ACCESS_TOKEN=PLACEHOLDER)
 rows=[];issues=[]
 success=defaultdict(list)
 for row in snapshot['runs']:
  if row['status']=='success' and row.get('audio_url'):success[row['provider']].append(row)
 for provider_id in sorted(success):
  p=providers[provider_id];candidate=[]
  for public in success[provider_id]:
   if public['run_id'] not in raw:raise ValueError('Public success lacks raw result')
   original,path=raw[public['run_id']]
   if original['status']!='success' or original['provider']!=provider_id or original['config']!=public['config']:
    # Config snapshot intentionally allowlists fields; dropped private fields can differ.
    if original['status']!='success' or original['provider']!=provider_id or any(original['config'].get(k)!=v for k,v in public['config'].items()):raise ValueError('Public/raw run identity mismatch')
   audio=(path.parent/original.get('audio_file','')).resolve()
   if not audio.is_relative_to(ROOT/'artifacts') or not audio.is_file() or hashlib.sha256(audio.read_bytes()).hexdigest()!=original.get('audio_sha256'):raise ValueError('Saved audio provenance mismatch')
   candidate.append((public,original,path))
  # A route is currently constructible only if the present adapter accepts a saved working configuration.
  current=None;previous_errors=[]
  for public,original,path in sorted(candidate,key=lambda x:x[0]['created_at'],reverse=True):
   try:spec=build_request(provider_id,original['text'],original['config'],credential_env)
   except Exception as exc:
    previous_errors.append({'run_id':original['run_id'],'error_type':type(exc).__name__});continue
   contract=original.get('request_contract',{});host=urlparse(spec.url).hostname
   body_hash=hashlib.sha256(spec.body).hexdigest() if isinstance(spec.body,bytes) else digest(spec.body)
   if (contract.get('url_host')!=host or contract.get('method')!=spec.method or contract.get('response_mode')!=spec.response_mode
       or contract.get('body_sha256')!=body_hash or set(contract.get('headers',[]))!=set(spec.headers)
       or contract.get('encoding')!=spec.encoding or contract.get('sample_rate')!=spec.sample_rate):
    previous_errors.append({'run_id':original['run_id'],'error_type':'current_contract_drift'});continue
   current=(public,original,path,spec);break
  if current is None:
   issues.append({'provider':provider_id,'reason':'No saved success can be reconstructed with current adapter contract','previous_attempts':previous_errors[:4]});continue
  public,original,path,spec=current
  cutoff=datetime.fromisoformat('2026-09-15T15:00:00+00:00')
  fresh=[x for x in candidate if datetime.fromisoformat(x[0]['created_at'])>=cutoff]
  formats=sorted({str(x[1]['config'].get('format','not recorded')) for x in candidate})
  models=sorted({str(x[1]['config'].get('model','implicit model')) for x in candidate})
  locales=sorted({x[0]['language'] for x in candidate})
  source_ids=['s3','s2','s1'] if provider_id=='soniox' else ['gemini_tts','gemini_model','gemini_languages'] if provider_id=='google' and 'gemini' in models[0] else ['s2','p1'] if provider_id=='fonada' and 'klone-v2-pro' in models else ['timestamps_current','models','lang'] if provider_id=='speechify' and original['config'].get('mode')=='stream_with_timestamps' else []
  relevant=[x for x in p.get('sources',[]) if x['id'] in source_ids] if source_ids else p.get('sources',[])[:3]
  if not relevant:raise ValueError('Model-specific primary source missing: '+provider_id)
  def field_paths(value,prefix=''):
   if isinstance(value,dict):return [path for key,item in value.items() for path in field_paths(item,prefix+'.'+key if prefix else key)]
   if isinstance(value,list):return [path for item in value[:1] for path in field_paths(item,prefix+'[]')]
   return [prefix]
  body_fields=field_paths(spec.body) if isinstance(spec.body,(dict,list)) else sorted(set(re.findall(r'Content-Disposition: form-data; name="([^"]+)"',spec.body.decode('utf-8','replace')))) if isinstance(spec.body,bytes) else ['text body' if isinstance(spec.body,str) else 'none']
  auth_headers=[name for name in spec.headers if re.search(r'authorization|api[-_]?key|subscription[-_]?key',name,re.I)]
  auth_scheme='Bearer' if any(spec.headers[name].startswith('Bearer ') for name in auth_headers) else 'Basic' if any(spec.headers[name].startswith('Basic ') for name in auth_headers) else 'Header key'
  route={'provider':provider_id,'name':p['name'],'deployment':'hosted_api','method':spec.method,'endpoint':spec.url,'authentication_headers':auth_headers,'authentication_scheme':auth_scheme,'all_header_names':sorted(spec.headers),'credential_environment_names':(['GOOGLE_API_KEY'] if provider_id=='google' and 'gemini' in models[0] else p.get('credentials',[])),'request_body_fields':body_fields,'request_body_sha256':body_hash,'response_mode':spec.response_mode,'audio_path':spec.audio_path,'sample_rate':spec.sample_rate,'encoding':spec.encoding,'working_models':models,'saved_audio_locales':locales,'saved_formats':formats,'historical_audio_successes':len(candidate),'fresh_audio_successes_since_1500_utc':len(fresh),'fresh_live_verified':bool(fresh),'example_config':original['config'],'example_text':original['text'],'example_run_id':original['run_id'],'example_created_at':original['created_at'],'example_http_status':original.get('http_status'),'example_audio_sha256':original['audio_sha256'],'example_audio_url':public['audio_url'],'request_contract_matches_current_adapter':True,'vendor_sources':[{'title':x['title'],'url':x['url'],'accessed':x['accessed']} for x in relevant],'qualification_scope':'Saved audio and current request construction; native quality, entitlement at scale, billing and production reliability assessed separately'}
  current=current_results.get(provider_id)
  route['current_revision_live_verified']=bool(current and current['status']=='success' and current_audit['same_global_revision'])
  route['current_adapter_live_verified']=bool(current and current['status']=='success' and current_audit['current_request_contracts_match'])
  route['current_revision_run_id']=current['run_id'] if current else None
  route['current_revision_audio_url']=current['audio_url'] if current else None
  if provider_id=='neuphonic':
   selected=[]
   for voice in neuphonic_urdu['results']:
    matched=next((row for row in candidate if row[1]['run_id']==voice['run_id']),None)
    if not matched or matched[0]['language']!='ur-IN' or not matched[0].get('audio_url'):
     raise ValueError('Neuphonic Urdu API reference lacks a matched working audio run')
    selected.append({'voice_id':voice['voice_id'],'default':voice['default'],
                     'run_id':voice['run_id'],'audio_url':matched[0]['audio_url']})
   route['voice_discovery']={'method':'GET','endpoint':'https://api.neuphonic.com/voices',
    'authentication_headers':['X-API-KEY'],'credential_environment_names':['NEUPHONIC_API_KEY'],
    'observed_http_status':200,'compatible_urdu_standard_voices':2,
    'lang_code':'ur','working_voice_samples':selected,
    'source':'https://github.com/neuphonic/pyneuphonic/blob/main/pyneuphonic/_voices.py'}
  rows.append(route)
 if len(rows)!=len(success):raise ValueError(f'Working API count mismatch: {len(rows)} vs {len(success)}; issues={issues}')
 local=[]
 for provider_id in ('kokoro','maya'):
  p=providers[provider_id]
  samples=snapshot['local_runs'] if provider_id=='kokoro' else snapshot['maya_local_runs']
  if provider_id=='kokoro':samples=[r for r in samples if r['provider']=='kokoro' and r.get('audio_url')]
  if not samples:raise ValueError('Local provider lacks saved output: '+provider_id)
  local.append({'provider':provider_id,'name':p['name'],'deployment':'on_prem','working_models':sorted({str(r.get('model') or r.get('config',{}).get('model')) for r in samples}),'saved_audio_locales':sorted({r['language'] for r in samples}),'historical_audio_successes':len(samples),'api_endpoint':None,'boundary':'Batch local output; native low-latency streaming and interruption not established by these runs','source':p['sources'][0]['url']})
 fish_timing=verify_fish_timestamps(ROOT/'artifacts/fish-timestamp-ws-20260916')
 fish_native=next((r for r in snapshot['native_audio_runs'] if r['provider']=='fish' and r['model']=='s2.1-pro-free' and r.get('timestamp_frames')==fish_timing['timestamp_frames']),None)
 if not fish_native or fish_native['audio_url']!='/evidence/audio/fish-s2.1-pro-free-timestamp-hi-IN.wav' or fish_native['word_segments']!=fish_timing['word_segments']:
  raise ValueError('Fish native API audio/timing does not match public snapshot')
 native_routes=[{'provider':'fish','name':'Fish S2.1 Pro Free with timestamps','deployment':'hosted_native_websocket',
   'endpoint':'wss://api.fish.audio/v1/tts/live/with-timestamp','method':'WebSocket GET upgrade',
   'wire_encoding':'MessagePack binary','authentication_headers':['Authorization','model'],
   'authentication_scheme':'Bearer plus exact model header','credential_environment_names':['FISH_API_KEY'],
   'model':'s2.1-pro-free','request_format':'PCM16 at 24000 Hz; start request with text empty, then text/flush/stop events',
   'response_events':['audio with alignment/chunk_seq/chunk_audio_offset_sec','finish(reason=stop)'],
   'saved_audio_locale':'hi-IN','example_config':json.loads((ROOT/'artifacts/fish-timestamp-ws-20260916/summary.json').read_text())['config'],
   'example_audio_url':fish_native['audio_url'],'example_audio_sha256':fish_native['audio_sha256'],
   'timestamp_frames':fish_timing['timestamp_frames'],'word_segments':fish_timing['word_segments'],
   'request_contract_matches_current_adapter':True,'raw_capture_verified':True,
   'vendor_source':'https://docs.fish.audio/api-reference/openapi.json',
   'qualification_scope':'One hash-verified native timing/audio session; word-to-audio accuracy, Flush causality, native quality and production load unverified'}]
 soniox_audit=verify_soniox_playout(ROOT/'artifacts/soniox-playout-20260916')
 soniox_public=next((r for r in snapshot['native_audio_runs'] if
  r.get('audio_url')=='/evidence/audio/soniox-cancel-recovery-hi-IN.wav'),None)
 if snapshot.get('soniox_playout_audit')!=soniox_audit or not soniox_public or soniox_public['audio_sha256']!=soniox_audit['recovery_wav_sha256']:
  raise ValueError('Soniox native working route lacks verified recovery WAV')
 native_routes.append({'provider':'soniox','name':'Soniox TTS real-time cancel/recovery',
  'deployment':'hosted_native_websocket','endpoint':'wss://tts-rt.soniox.com/tts-websocket',
  'method':'WebSocket GET upgrade','wire_encoding':'JSON controls with base64 PCM16 responses',
  'authentication_headers':[],'authentication_scheme':'api_key in initial stream config',
  'credential_environment_names':['SONIOX_API_KEY'],'model':'tts-rt-v2',
  'request_format':'language hi; Kavya; pcm_s16le 24000 Hz; unique stream_id, text_end, old cancel, new stream recovery',
  'response_events':['audio','audio_end','terminated'],
  'saved_audio_locale':'hi-IN','example_config':{'model':'tts-rt-v2','voice':'Kavya',
   'language':'hi','audio_format':'pcm_s16le','sample_rate':24000},
  'example_audio_url':soniox_public['audio_url'],
  'example_audio_sha256':soniox_public['audio_sha256'],
  'request_contract_matches_current_adapter':True,'raw_capture_verified':True,
  'vendor_source':'https://soniox.com/docs/api-reference/tts/websocket-api',
  'qualification_scope':'One software receiver synthetic caller interruption and same-socket recovery; VAD, SIP/RTP, handset and production load unverified'})
 sarvam_audit=verify_sarvam_native(ROOT/'artifacts/sessions/sarvam-native-20260916')
 sarvam_playout=verify_sarvam_playout(ROOT/'artifacts/sarvam-playout-20260916')
 sarvam_public=next((r for r in snapshot['native_audio_runs'] if
  r.get('audio_url')=='/evidence/audio/sarvam-bulbul-v3-native-hi-IN.wav'),None)
 if snapshot.get('sarvam_native_audit')!=sarvam_audit or not sarvam_public or sarvam_public['audio_sha256']!=sarvam_audit['wav_sha256']:
  raise ValueError('Sarvam native working route lacks verified Hindi decoded WAV')
 if snapshot.get('sarvam_playout_audit')!=sarvam_playout:
  raise ValueError('Sarvam close/reconnect route lacks verified playout audit')
 native_routes.append({'provider':'sarvam','name':'Sarvam Bulbul v3 input stream',
  'deployment':'hosted_native_websocket',
  'endpoint':'wss://api.sarvam.ai/text-to-speech/ws?model=bulbul%3Av3&send_completion_event=true',
  'method':'WebSocket GET upgrade','wire_encoding':'JSON controls with base64 MP3 response',
  'authentication_headers':['Api-Subscription-Key'],
  'authentication_scheme':'Subscription key header',
  'credential_environment_names':['SARVAM_API_KEY'],'model':'bulbul:v3',
  'request_format':'config first: hi-IN, shubh, speech_sample_rate 24000, output_audio_codec mp3; text fragments, flush',
  'response_events':['audio(content_type,audio)','event(final)','error'],
  'saved_audio_locale':'hi-IN','example_config':{'model':'bulbul:v3','language':'hi-IN',
   'speaker':'shubh','format':'mp3','sample_rate':24000},
  'example_audio_url':sarvam_public['audio_url'],
  'example_audio_sha256':sarvam_public['audio_sha256'],
  'request_contract_matches_current_adapter':True,'raw_capture_verified':True,
  'vendor_source':'https://docs.sarvam.ai/api-reference/text-to-speech/stream',
  'interruption_mechanism':'local clear, close old TTS socket, reconnect new socket',
  'in_band_cancel_supported':False,
  'synthetic_software_stop_latency_ms':sarvam_playout['software_stop_latency_ms'],
  'synthetic_recovery_from_onset_ms':sarvam_playout['recovery_from_caller_onset_ms'],
  'qualification_scope':'One 25-payload Hindi MP3 stream with final and one separate synthetic software receiver interruption/recovery; no in-band cancel, phone or load qualification'})
 murf_audit,murf_wav=verify_murf_native(ROOT)
 from tts_arena.murf_locale_style_evidence import verify as verify_murf_locale_styles
 murf_styles=verify_murf_locale_styles(ROOT)
 if snapshot.get('murf_locale_style_audit')!=murf_styles:
  raise ValueError('Murf style eligibility differs from authenticated raw voice catalog')
 from tts_arena.murf_clear_evidence import verify as verify_murf_clear
 murf_clear,murf_clear_wavs=verify_murf_clear(ROOT)
 for clip in murf_clear['clips']:
  clip['audio_url']='/evidence/audio/murf-clear-'+clip['id']+'-hi-IN.wav'
 if snapshot.get('murf_clear_audit')!=murf_clear or len(murf_clear_wavs)!=4:
  raise ValueError('Murf clear audit lacks verified public clips')
 murf_public=next((r for r in snapshot['native_audio_runs'] if r['provider']=='murf' and r['model']=='falcon-2' and r['language']=='hi-IN'),None)
 if (snapshot.get('murf_native_audit')!=dict(murf_audit,audio_url='/evidence/audio/murf-falcon-2-native-hi-IN.wav')
     or not murf_public or murf_public['audio_sha256']!=murf_audit['playable_wav_sha256']
     or murf_public['audio_url']!='/evidence/audio/murf-falcon-2-native-hi-IN.wav'):
  raise ValueError('Murf native working route lacks verified public audio')
 murf_config={'model':'falcon-2','voice':'hi-IN-khyati','language':'hi-IN','format':'WAV',
              'sample_rate':24000,'region':'global','context_id':'hindi-turn-1'}
 murf_spec=murf_socket.build_session(murf_config,{'MURF_API_KEY':PLACEHOLDER})
 parsed=urlparse(murf_spec.url)
 if parsed.netloc!='global.api.murf.ai' or parsed.path!='/v1/speech/stream-input' or murf_spec.initial_messages!=[
  {'voice_config':{'voiceId':'hi-IN-khyati','locale':'hi-IN'}}]:
  raise ValueError('Current Murf native adapter contract differs from live capture')
 native_routes.append({'provider':'murf','name':'Murf Falcon 2 native WebSocket','deployment':'hosted_native_websocket',
  'endpoint':'wss://global.api.murf.ai/v1/speech/stream-input','method':'WebSocket GET upgrade',
  'wire_encoding':'JSON text input; base64 WAV/PCM audio','authentication_headers':[],
  'authentication_scheme':'api-key in WebSocket URL query; key omitted from reference',
  'credential_environment_names':['MURF_API_KEY'],'model':'falcon-2',
  'request_format':'24 kHz mono WAV; voice_config then context_id/text/end',
  'response_events':['audio(base64) with context_id','final=true with context_id'],
  'saved_audio_locale':'hi-IN','example_config':murf_config,
  'example_audio_url':murf_public['audio_url'],'example_audio_sha256':murf_public['audio_sha256'],
  'audio_payloads':murf_audit['audio_payloads'],'first_payload_ms':murf_audit['first_payload_ms'],
  'clear_recovery':{'message':murf_clear['clear_message'],'adaptive_clear_sent_ms':murf_clear['adaptive_clear_sent_ms'],
    'old_payloads_after_clear':murf_clear['adaptive_old_payloads_after_clear'],
    'new_final_events':murf_clear['adaptive_new_final_events'],
    'clips':[{'id':c['id'],'audio_url':c['audio_url'],'partial':c['partial'],'duration_seconds':c['duration_seconds']} for c in murf_clear['clips']],
    'scope':murf_clear['boundary']},
  'locale_style_eligibility':murf_styles['locales'],
  'cancel_semantics':murf_audit['cancel_scope'],'request_contract_matches_current_adapter':True,
  'raw_capture_verified':True,'vendor_source':'https://murf.ai/api/docs/text-to-speech/web-sockets',
  'qualification_scope':'One bounded Hindi native synthesis and two bounded same-socket clear/recovery captures; wire and audio verified. Clear causality, naturalness, cost and production playout not qualified.'})
 suite=json.loads((ROOT/'artifacts/current-api-suite-20260915/summary.json').read_text())
 attempts={r['provider']:r for r in suite['results']}
 for route in rows:
  latest=attempts.get(route['provider'])
  route['latest_bounded_check']={'status':latest['status'],'http_status':latest.get('http_status'),'error_type':latest.get('error_type')} if latest else None
 data={'schema_version':1,'generated_from_snapshot':snapshot['generated_at'],'hosted_working_api_count':len(rows),'hosted_fresh_live_count':sum(r['fresh_live_verified'] for r in rows),'hosted_current_revision_live_count':sum(r['current_revision_live_verified'] for r in rows),'hosted_current_adapter_live_count':sum(r['current_adapter_live_verified'] for r in rows),'native_working_api_count':len(native_routes),'local_working_model_count':len(local),'routes':rows,'native_routes':native_routes,'local_models':local,'issues':issues}
 OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 lines=['# Working TTS API reference','','Generated from saved successful audio and a dry build of each route with the current adapter. Credentials are listed by environment name only.','',f"Hosted routes with saved audio: {len(rows)}; fresh live successes since 15:00 UTC on 15 September: {sum(r['fresh_live_verified'] for r in rows)}; one-shot live successes with current request contract: {sum(r['current_adapter_live_verified'] for r in rows)}; same-global-revision successes: {sum(r['current_revision_live_verified'] for r in rows)}. Local batch models: {len(local)}. Public snapshot: {snapshot['generated_at']}.",'','The dry request check reproduces each saved success\'s method, host, response mode, full body hash, header-name set, encoding and sample rate. A separate one-shot live pass binds requests and returned WAVs to its observed source hash. The present adapter reconstructs each saved method, host, body hash, headers and audio format; global export hash changes from unrelated site edits are shown separately. This is not a production capacity or billed-cost test.','', '| Provider | Model(s) with saved audio | Method and endpoint | Auth env | Audio locales | Saved formats | Evidence |','|---|---|---|---|---|---|---|']
 for r in rows:
  lines.append('| '+' | '.join([r['name'],', '.join(r['working_models']),r['method']+' '+r['endpoint'],', '.join(r['credential_environment_names']),', '.join(r['saved_audio_locales']),', '.join(r['saved_formats']),str(r['historical_audio_successes'])+' files; '+('live HTTP 200; current adapter matched' if r['current_adapter_live_verified'] else 'fresh historical HTTP 200' if r['fresh_live_verified'] else 'historical audio only')+'; `'+r['example_run_id'][:8]+'`'])+' |')
 lines += ['','## Request configurations','']
 for r in rows:
  lines += ['### '+r['name'],'',f"Current dry contract: `{r['method']} {r['endpoint']}`; response `{r['response_mode']}` / `{r['encoding']}`"+(f"; audio path `{r['audio_path']}`" if r['audio_path'] else '')+'.',f"Saved live result: HTTP {r['example_http_status']} on {r['example_created_at']}; run `{r['example_run_id']}`; [play audio]({r['example_audio_url']}).",f"One-shot live check against present adapter: {'HTTP 200 and contract match' if r['current_adapter_live_verified'] else 'not completed or non-success'}"+(f"; run `{r['current_revision_run_id']}`; [play audio]({r['current_revision_audio_url']})" if r['current_adapter_live_verified'] else '')+'.','', 'Authentication: '+r['authentication_scheme']+' in '+', '.join('`'+x+'`' for x in r['authentication_headers'])+'; credential environment '+', '.join('`'+x+'`' for x in r['credential_environment_names'])+'.', '', 'Request body fields: '+', '.join('`'+x+'`' for x in r['request_body_fields'])+'.', '', 'Example config for the current adapter:','', '```json',json.dumps(r['example_config'],ensure_ascii=False,indent=2),'```','', 'Primary API specifications: '+', '.join(f"[{x['title']}]({x['url']}) (checked {x['accessed']})" for x in r['vendor_sources'])+'.','']
  if r['provider']=='neuphonic':
   voices=r['voice_discovery']['working_voice_samples']
   lines += ['Voice compatibility was checked by authenticated `GET https://api.neuphonic.com/voices` with `X-API-KEY: $NEUPHONIC_API_KEY` (HTTP 200). Its current response had two Urdu Standard voices. Use `language="ur"` and the matching `voice` ID with `POST https://api.neuphonic.com/sse/speak/ur`: default `'+voices[0]['voice_id']+'` ([audio]('+voices[0]['audio_url']+')) or alternate `'+voices[1]['voice_id']+'` ([audio]('+voices[1]['audio_url']+')). [Exact voice selection and limits](NEUPHONIC_URDU_RESULTS.md).','']
 lines += ['## Local models','']
 for r in local:
  lines += [f"- **{r['name']}**: {', '.join(r['working_models'])}; {r['historical_audio_successes']} saved batch WAVs; locales {', '.join(r['saved_audio_locales'])}. [Model/deployment source]({r['source']})."]
 lines += ['','## Working native WebSocket routes','','**Fish S2.1 Pro Free with timestamps**: `wss://api.fish.audio/v1/tts/live/with-timestamp`. Upgrade with `Authorization: Bearer $FISH_API_KEY` and the exact `model: s2.1-pro-free` header. Send MessagePack binary `start` with an empty `text` request, then `text`, `flush` and `stop` events. Audio frames carry raw PCM bytes and cumulative per-chunk alignment snapshots; `finish(reason=stop)` terminates the session. One bounded Hindi session returned 267,352 PCM bytes and 19 word segments in four snapshots. [Play saved audio](/evidence/audio/fish-s2.1-pro-free-timestamp-hi-IN.wav); [raw capture and limits](vendors/fish.md). Word alignment accuracy and production playout remain unqualified. A separate [balanced REST-versus-WebSocket Hindi PCM trial](FISH_TRANSPORT_LATENCY_RESULTS.md) gives 12 successful requests per route with verified first-audio p50/p95 and every saved recording.','','**Murf Falcon 2 input stream**: `wss://global.api.murf.ai/v1/speech/stream-input`. Upgrade with URL query `api-key=$MURF_API_KEY&model=falcon-2&sample_rate=24000&channel_type=MONO&format=WAV`; keep the resulting URL private. Send JSON `voice_config` with `voiceId=hi-IN-khyati`, `locale=hi-IN`, then `context_id=hindi-turn-1`, Hindi `text`, and `end=true`. The saved live response carried 23 context-tagged base64 WAV/PCM audio payloads and one `final=true`; first client-received payload was 112.5 ms after socket connection in this one request. [Play verified audio](/evidence/audio/murf-falcon-2-native-hi-IN.wav); [capture, wire verifier and limits](MURF_NATIVE_RESULTS.md). The documented `clear=true` cancels pending synthesis; audio already generating may continue, so a voice bot must stop and discard playout locally on barge-in.','']
 lines += ['','**Falcon 2 style eligibility for the requested locales**: an authenticated model-filtered voice listing returned 136 voices. For en-IN, hi-IN, bn-IN, mr-IN, te-IN, ta-IN, gu-IN, kn-IN and ml-IN, every eligible voice listed exactly one locale-specific style; ur-IN had no eligible voice. The style request field exists, but the current catalog offers no within-voice style contrast for this ten-locale set. [Language-level counts and raw-catalog audit](MURF_STYLE_ELIGIBILITY.md). This is catalog eligibility, not perceptual emotion testing.','']
 lines += ['','**Murf clear and recovery**: One late-clear control and one adaptive clear immediately after the first old audio payload were wire- and audio-verified. In the adaptive run, old-context audio had one 169 ms payload before clear=true, zero after it, and the new Hindi context returned audio and final=true on the same socket. The late-clear control had 28 old payloads before clear and no old final, so its status remains inconclusive for interruption. [Four labelled audio clips and limits](MURF_CLEAR_RESULTS.md). This is a synthetic client observation, not an end-to-end caller barge-in qualification.','']
 lines += ['**Soniox TTS real-time cancel/recovery**: `wss://tts-rt.soniox.com/tts-websocket`; initial JSON stream config carries `$SONIOX_API_KEY`, `model=tts-rt-v2`, `language=hi`, `voice=Kavya`, `audio_format=pcm_s16le`, `sample_rate=24000` and unique `stream_id`. Send text with `text_end=true`, locally clear old playout and send `cancel=true` for that stream, then start a new unique stream ID with recovery text on the same socket. Base64 PCM `audio`, `audio_end` and `terminated` are routed by stream ID. One bounded synthetic software receiver run recorded 10.25 ms to stop old audio and 529.7 ms to first audible recovery; 12,288 post-cancel PCM bytes were discarded locally. [Play verified recovery](/evidence/audio/soniox-cancel-recovery-hi-IN.wav); [raw capture and limits](SONIOX_PLAYOUT_RESULTS.md). No VAD, SIP/RTP or handset qualification.','']
 lines += ['**Sarvam Bulbul v3 input stream**: `wss://api.sarvam.ai/text-to-speech/ws?model=bulbul%3Av3&send_completion_event=true`; upgrade with `Api-Subscription-Key: $SARVAM_API_KEY`. Send `config` first with `language_code=hi-IN`, `speaker=shubh`, `speech_sample_rate=24000` and `output_audio_codec=mp3`; then send `text` fragments and `flush`. The first bounded session returned 25 base64 MP3 payloads and `event_type=final`; the original MP3 independently decoded to a playable 24 kHz mono WAV. First client-received audio was 211.5 ms after the first text action in that request. [Play verified stream](/evidence/audio/sarvam-bulbul-v3-native-hi-IN.wav); [wire audit](SARVAM_NATIVE_RESULTS.md). The [vendor streaming guide](https://docs.sarvam.ai/api/api-guides-tutorials/text-to-speech/streaming-api/web-socket) says there is no server-side cancel/clear. A separate synthetic software receiver run cleared local old playout in 20 ms, closed the old socket, then played recovery 659.8 ms after caller onset on a new socket. [Play interrupted old output](/evidence/audio/sarvam-interrupted-old-hi-IN.wav) and [recovery](/evidence/audio/sarvam-interruption-recovery-hi-IN.wav); [event and metric audit](SARVAM_PLAYOUT_RESULTS.md). VAD, SIP/RTP, handset and production load are unqualified.','']
 lines += ['','## Using a route','','Supply the named API key in the environment and the example config to `tts_arena.registry.build_request`; the adapter validates the model-specific fields. `tts_arena.runner.run_one` records a bounded live HTTP attempt and retains response/audio hashes. Do not transfer controls between models or substitute an untested locale. The companion JSON is available at `ui/public/evidence/working-api-reference.json`.','']
 DOC.write_text('\n'.join(lines))
 print(json.dumps({'hosted_working_api_count':len(rows),'hosted_fresh_live_count':sum(r['fresh_live_verified'] for r in rows),'hosted_current_revision_live_count':sum(r['current_revision_live_verified'] for r in rows),'hosted_current_adapter_live_count':sum(r['current_adapter_live_verified'] for r in rows),'local_working_model_count':len(local),'issues':len(issues),'examples_with_current_dry_contract':sum(r['request_contract_matches_current_adapter'] for r in rows),'fresh_live_count':sum(r['fresh_live_verified'] for r in rows)}))
 return data
if __name__=='__main__':build()
