"""Derive inventory-only failure record; preserve source exactly, invent no capture data."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 source=ROOT/'artifacts/sessions-access-20260915/smallest.json'
 raw=source.read_bytes();original=json.loads(raw)
 assert original['status']=='failed' and original['failure_stage']=='runner_audio_persistence' and original['attempts']==1
 output={k:original[k] for k in ('provider','status','error_type','failure_stage','errno','reason','config','audio_artifact_valid','raw_response_frames_persisted')}
 output.update(evidence_class='native_websocket_session',record_kind='derived_failure_observation',provenance={'source_file':str(source.relative_to(ROOT)),'source_sha256':hashlib.sha256(raw).hexdigest(),'derivation':'Inventory normalization of one original live-session storage failure. No original timestamp, run ID, events or valid audio were recoverable; none are fabricated.'})
 destination=ROOT/'artifacts/sessions-access-20260915/smallest/original-storage-failure-derived/result.json';destination.parent.mkdir(parents=True,exist_ok=True)
 data=json.dumps(output,ensure_ascii=False,indent=2)+'\n'
 if destination.exists():
  if destination.read_text()!=data:raise ValueError('Existing derived record differs; preserve it for review')
 else:destination.write_text(data)
 print(str(destination.relative_to(ROOT)))
if __name__=='__main__':main()
