"""One authorized English recheck, then Tamil only after successful audio delivery."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]

async def main():
    out=ROOT/'artifacts/access-audits';out.mkdir(exist_ok=True)
    guard=out/'gnani-rate-recheck.started'
    with guard.open('x') as file:file.write('One bounded recheck authorized; do not repeat automatically.\n')
    creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    result={'provider':'gnani','model':'timbre-v2.5','scope':'Authorized post-rate-limit access recheck; no quality or load qualification',
            'attempts':[],'automatic_retries':0,'inter_request_pacing_seconds':60,'pacing_note':'Conservative probe pacing, not a verified account rate limit',
            'prior_evidence':'artifacts/access-20260915/gnani-tts-key.json'}
    path=out/'gnani-rate-recheck.json'
    def save():path.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
    errors=[]
    async def hook(response):
        if response.status_code>=400:
            await response.aread();errors.append({'http_status':response.status_code,'message':redact(response.text,creds)[:1500],
                'retry_after':response.headers.get('retry-after')})
    os.environ['GNANI_API_KEY_ID']=creds['GNANI_API_KEY_ID']
    try:
        async with httpx.AsyncClient(timeout=30,follow_redirects=False,trust_env=False,event_hooks={'response':[hook]}) as client:
            for index,(language,voice,text) in enumerate([('en-IN','Kaveri','Hello, we have received your payment. Thank you.'),('ta-IN','Asmita','வணக்கம், உங்கள் கட்டணம் பெறப்பட்டது. நன்றி.')]):
                if index:await asyncio.sleep(60)
                errors.clear()
                config={'model':'timbre-v2.5','voice':voice,'language':language,'format':'wav','sample_rate':24000}
                record=await run_one('gnani',text,config,ROOT/'artifacts/runs/gnani-recheck-20260915',timeout=30,client=client,scenario_id='rate-recheck-'+language,stratum='draft_access_probe')
                attempt={k:record.get(k) for k in ['run_id','status','http_status','error_type','language','audio_bytes','duration_seconds','first_audio_ms','elapsed_ms','audio_analysis']}
                attempt.update(config=config,diagnostics=errors.copy(),linguistic_accuracy='unverified')
                result['attempts'].append(attempt);save();print('Gnani '+language+' '+record['status']+' HTTP '+str(record.get('http_status')),flush=True)
                if record['status']!='success':break
        result['successful_syntheses']=sum(a['status']=='success' for a in result['attempts']);save()
    finally:os.environ.pop('GNANI_API_KEY_ID',None)

if __name__=='__main__':asyncio.run(main())
