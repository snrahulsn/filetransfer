"""One no-retry Soniox v2 session: split Hindi text, reuse, and 8 kHz G.711.

This probes the documented native WebSocket lifecycle, not telephone playout.
The API key is kept in memory and no raw wire configuration is saved.
"""
import asyncio
import base64
import hashlib
import io
import json
import shutil
import sys
import time
import wave
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

import websockets

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from scripts.export_ui_data import mulaw_to_wav

OUT=ROOT/"artifacts/soniox-multiplex-20260915"
URL="wss://tts-rt.soniox.com/tts-websocket"
FIRST=("नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। ","कृपया समय की पुष्टि करें।")
SECOND="आपकी अगली किस्त पंद्रह सितंबर को देय है।"

def pcm_wav(raw):
    if not raw or len(raw)%2:raise ValueError("Nonempty PCM16 frames required")
    output=io.BytesIO()
    with wave.open(output,"wb") as stream:
        stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(24000);stream.writeframes(raw)
    return output.getvalue()

async def main():
    if OUT.exists():raise RuntimeError("Probe already attempted; no repeated spend")
    if shutil.disk_usage(ROOT).free<300*1024*1024:raise RuntimeError("Insufficient free disk")
    key=read_credentials("/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env").get("SONIOX_API_KEY")
    if not key:raise RuntimeError("Authorized Soniox key absent")
    if sum(map(len,FIRST))+len(SECOND)>150:raise ValueError("Text cap exceeded")
    OUT.mkdir(parents=True)
    report={"schema_version":1,"provider":"soniox","model":"tts-rt-v2","voice":"Kavya",
            "created_at":datetime.now(timezone.utc).isoformat(),"source":URL,
            "documentation":"https://soniox.com/docs/api-reference/tts/websocket-api",
            "requests_limit":2,"automatic_retries":0,"boundary":"native_websocket_payload_not_receiver_playout",
            "native_language_quality":"unverified","production_telephony_verified":False,
            "streams":[],"status":"started"}
    save=lambda: (OUT/"result.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    save()
    origin=time.perf_counter()
    elapsed=lambda:round((time.perf_counter()-origin)*1000,2)
    async def run_stream(ws,text_parts,audio_format,sample_rate,split):
        sid="arena-"+uuid4().hex
        row={"stream_id":sid,"language":"hi-IN","wire_language":"hi",
             "audio_format":audio_format,"sample_rate":sample_rate,"text_parts":list(text_parts),
             "first_text_sent_ms":None,"final_text_sent_ms":None,"first_audio_ms":None,
             "audio_end_observed":False,"terminated_observed":False,"audio_chunks":0,
             "audio_bytes":0,"error_types":[],"status":"started"}
        report["streams"].append(row);save()
        await ws.send(json.dumps({"api_key":key,"model":"tts-rt-v2","language":"hi","voice":"Kavya",
                                  "audio_format":audio_format,"sample_rate":sample_rate,"stream_id":sid}))
        row["config_sent_ms"]=elapsed()
        await ws.send(json.dumps({"text":text_parts[0],"text_end":not split,"stream_id":sid}))
        row["first_text_sent_ms"]=elapsed()
        if not split:row["final_text_sent_ms"]=row["first_text_sent_ms"]
        chunks=[]
        async def receive(timeout):
            message=json.loads(await asyncio.wait_for(ws.recv(),timeout))
            if message.get("stream_id")!=sid:raise ValueError("Unexpected stream_id")
            if message.get("error_type"):
                row["error_types"].append({"type":message["error_type"],"code":message.get("error_code")})
            if message.get("audio"):
                raw=base64.b64decode(message["audio"],validate=True)
                if audio_format=="pcm_s16le" and len(raw)%2:raise ValueError("Invalid PCM16 chunk")
                chunks.append(raw)
                row["audio_chunks"]+=1;row["audio_bytes"]+=len(raw)
                if row["first_audio_ms"] is None:row["first_audio_ms"]=elapsed()
            if message.get("audio_end") is True:row["audio_end_observed"]=True
            if message.get("terminated") is True:row["terminated_observed"]=True
        if split:
            try:await receive(0.35)
            except asyncio.TimeoutError:pass
            await ws.send(json.dumps({"text":text_parts[1],"text_end":True,"stream_id":sid}))
            row["final_text_sent_ms"]=elapsed()
        deadline=time.perf_counter()+20
        while not row["terminated_observed"] and time.perf_counter()<deadline:
            await receive(max(0.1,deadline-time.perf_counter()))
        raw=b"".join(chunks)
        if raw:
            (OUT/(audio_format+".raw")).write_bytes(raw)
            row["raw_sha256"]=hashlib.sha256(raw).hexdigest()
            wav=pcm_wav(raw) if audio_format=="pcm_s16le" else mulaw_to_wav(raw)
            filename=audio_format+".wav"
            (OUT/filename).write_bytes(wav)
            row["audio_file"]=filename;row["audio_sha256"]=hashlib.sha256(wav).hexdigest()
            row["duration_seconds"]=len(raw)/(sample_rate*(2 if audio_format=="pcm_s16le" else 1))
        row["audio_before_final_text"]=bool(row["first_audio_ms"] is not None and row["first_audio_ms"]<row["final_text_sent_ms"])
        row["status"]="success" if raw and row["audio_end_observed"] and row["terminated_observed"] and not row["error_types"] else "incomplete"
        save()
        return row
    try:
        async with websockets.connect(URL,open_timeout=10,close_timeout=5,max_size=2*1024*1024) as ws:
            first=await run_stream(ws,FIRST,"pcm_s16le",24000,True)
            if first["status"]=="success":
                await run_stream(ws,(SECOND,),"pcm_mulaw",8000,False)
        report["status"]="complete" if len(report["streams"])==2 and all(r["status"]=="success" for r in report["streams"]) else "incomplete"
    except Exception as exc:
        report["status"]="failed";report["error_type"]=type(exc).__name__
    save()
    print(json.dumps({"status":report["status"],"streams":[{k:r.get(k) for k in
          ("audio_format","status","audio_chunks","audio_bytes","audio_before_final_text","audio_end_observed","terminated_observed","error_types")} for r in report["streams"]]}))

if __name__=="__main__":asyncio.run(main())
