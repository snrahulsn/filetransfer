"""One read-only Falcon 2 catalog capture for all ten requested locales."""
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials

OUT = ROOT / 'artifacts/murf-locale-style-discovery-20260916'
URL = 'https://api.murf.ai/v1/speech/voices?model=falcon-2'
LOCALES = ('en-IN', 'hi-IN', 'bn-IN', 'mr-IN', 'te-IN', 'ta-IN', 'gu-IN',
           'kn-IN', 'ml-IN', 'ur-IN')


def main():
    corrected = False
    if OUT.exists():
        if (OUT / 'report.json').exists() or (OUT / 'voices.json').exists() or (OUT / 'attempt.corrected').exists():
            raise RuntimeError('Locale-wide voice catalog already captured or corrected once; no repeat')
        if not (OUT / 'attempt.started').exists():
            raise RuntimeError('Existing catalog directory has no known failed attempt')
        corrected = True
    secret = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('MURF_API_KEY')
    if not secret:
        raise ValueError('Authorized Murf key unavailable')
    OUT.mkdir(parents=True, exist_ok=corrected)
    if corrected:
        (OUT / 'attempt.corrected').write_text('One controlled second read-only GET after optional-field validator error; no synthesis.\n')
    else:
        (OUT / 'attempt.started').write_text('One authenticated read-only GET; no synthesis and no retry.\n')
    with httpx.Client(timeout=12, follow_redirects=False) as client:
        response = client.get(URL, headers={'api-key': secret})
    if response.status_code != 200 or len(response.content) > 2_000_000:
        (OUT / 'status.json').write_text(json.dumps({'http_status': response.status_code,
                                                     'response_bytes': len(response.content)}) + '\n')
        raise ValueError('Murf Falcon 2 catalog response unavailable or too large')
    voices = response.json()
    if not isinstance(voices, list) or len(voices) > 300:
        raise ValueError('Murf Falcon 2 voice catalog schema changed')
    # The API returns voice metadata only. No authorization header or URL with key is saved.
    raw = response.content
    (OUT / 'voices.json').write_bytes(raw)
    for voice in voices:
        if not isinstance(voice, dict) or not isinstance(voice.get('voiceId'), str) or not isinstance(voice.get('supportedLocales') or {}, dict):
            raise ValueError('Murf voice entry schema changed')
    rows = {}
    for locale in LOCALES:
        choices = []
        for voice in voices:
            locale_info = (voice.get('supportedLocales') or {}).get(locale)
            if locale_info is None:
                continue
            styles = locale_info.get('availableStyles') or []
            if not isinstance(styles, list) or any(not isinstance(style, str) for style in styles):
                raise ValueError('Murf style list schema changed')
            choices.append({'voiceId': voice['voiceId'], 'styles': styles})
        rows[locale] = {'voice_count': len(choices),
                        'multi_style_voice_count': sum(len(c['styles']) > 1 for c in choices),
                        'distinct_styles': sorted({style for c in choices for style in c['styles']}),
                        'voices': choices}
    report = {'provider': 'murf', 'model': 'falcon-2', 'endpoint': URL,
              'observed_at': datetime.now(timezone.utc).isoformat(),
              'http_status': 200, 'raw_response_sha256': hashlib.sha256(raw).hexdigest(),
              'voice_count': len(voices), 'requested_locales': list(LOCALES),
              'locale_styles': rows, 'synthesis_requests': 0, 'retries': 0,
              'catalog_get_requests': 2 if corrected else 1,
              'source': 'https://murf.ai/api/docs/api-reference/voices/get-voices'}
    (OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'http_status': 200, 'voice_count': len(voices),
                      'locale_voice_counts': {locale: row['voice_count'] for locale, row in rows.items()},
                      'locale_multi_style_counts': {locale: row['multi_style_voice_count'] for locale, row in rows.items()}}))


if __name__ == '__main__':
    main()
