"""One native Fish S2.1 timestamp WebSocket session; keep raw frames and audio."""
import asyncio
import hashlib
import json
import sys
from pathlib import Path

from websockets.asyncio.client import connect

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials, redact
from tts_arena.session_runner import run_session
from tts_arena.sessions import fish

OUT = ROOT / 'artifacts/fish-timestamp-ws-20260916'
CONFIG = {'model': 's2.1-pro-free', 'voice': '9a9cf47702da476aa4629e2506d4a857',
          'language': 'auto', 'format': 'pcm', 'sample_rate': 24000,
          'chunk_length': 100, 'latency': 'normal', 'timestamp_mode': True}
ACTIONS = [{'at_ms': 0, 'type': 'text', 'text': 'नमस्ते, आपकी बैठक कल है।'},
           {'at_ms': 500, 'type': 'flush'},
           {'at_ms': 6000, 'type': 'text', 'text': ' कृपया दोपहर तीन बजे का समय पक्का करें।'},
           {'at_ms': 6500, 'type': 'flush'},
           {'at_ms': 12000, 'type': 'end_input'}]
SOURCE = 'https://docs.fish.audio/api-reference/openapi.json#/v1/tts/live/with-timestamp'


def timing_summary(report):
    marks = [e['details']['metadata'] for e in report['events']
             if e['event_type'] == 'provider_event'
             and e.get('details', {}).get('type') == 'timestamps']
    latest = {}
    previous_seq = previous_offset = -1
    for mark in marks:
        seq, offset = mark['chunk_seq'], mark['chunk_audio_offset_sec']
        if seq < previous_seq or offset < previous_offset:
            raise ValueError('Fish timing chunk identity decreased')
        previous_seq, previous_offset = seq, offset
        latest[seq] = mark
    global_segments = []
    for seq, mark in sorted(latest.items()):
        for segment in mark['alignment']['segments']:
            global_segments.append({'chunk_seq': seq, 'text': segment['text'],
                'start_sec': round(mark['chunk_audio_offset_sec'] + segment['start'], 4),
                'end_sec': round(mark['chunk_audio_offset_sec'] + segment['end'], 4)})
    return {'timestamp_frames': len(marks), 'text_chunks_with_alignment': len(latest),
            'word_segments_in_latest_snapshots': len(global_segments),
            'global_segments': global_segments, 'alignment_accuracy': 'unverified'}


async def main():
    if OUT.exists():
        raise RuntimeError('Fish timestamp session already attempted; no automatic repeat')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    key = credentials.get('FISH_API_KEY')
    if not key:
        raise RuntimeError('Authorized Fish key unavailable')
    spec = fish.build_session(CONFIG, {'FISH_API_KEY': key})
    if spec.url != 'wss://api.fish.audio/v1/tts/live/with-timestamp':
        raise ValueError('Timestamp endpoint mismatch')
    if sum(len(a.get('text', '')) for a in ACTIONS) > 120:
        raise ValueError('Bounded text exceeded')
    for action in ACTIONS:
        fish.encode_message(fish.encode_action(action, CONFIG)[0])
    OUT.mkdir(parents=True)
    (OUT / 'attempt.started').write_text('One authorized native WebSocket session, no retry.\n')
    diagnostics = []

    class ObservedConnect:
        def __init__(self, url, **kwargs):
            self.connection = connect(url, **kwargs)

        async def __aenter__(self):
            try:
                return await self.connection.__aenter__()
            except Exception as exc:
                response = getattr(exc, 'response', None)
                if response is not None:
                    diagnostics.append({'http_status': getattr(response, 'status_code', None),
                        'message': redact(getattr(response, 'body', b'').decode('utf8', 'replace'), credentials)[:2000]})
                raise

        async def __aexit__(self, *args):
            return await self.connection.__aexit__(*args)

    report = await run_session('fish', CONFIG, ACTIONS, OUT / 'session', seconds=18,
                               env={'FISH_API_KEY': key}, connector=ObservedConnect)
    try:
        timing = timing_summary(report)
    except ValueError as exc:
        timing = {'verification_error': type(exc).__name__, 'timestamp_frames': 0,
                  'alignment_accuracy': 'unverified'}
    audio = report['audio']
    if audio:
        raw = Path(report['result_file']).parent / audio[0]['path']
        if hashlib.sha256(raw.read_bytes()).hexdigest() != audio[0]['sha256']:
            raise ValueError('Fish WebSocket audio hash mismatch')
    summary = {'provider': 'fish', 'model': CONFIG['model'], 'requested_locale': 'hi-IN',
               'config': CONFIG, 'actions': ACTIONS, 'source': SOURCE,
               'source_accessed': '2026-09-16', 'request_limit': 1,
               'automatic_retries': 0, 'status': report['status'],
               'error_type': report['error_type'], 'diagnostics': diagnostics,
               'audio_payload_events': sum(e['event_type'] == 'audio_payload_received' for e in report['events']),
               'audio_bytes': sum(a['bytes'] for a in audio),
               'terminal_observed': any(e['event_type'] == 'provider_event' and
                   e.get('details', {}).get('type') == 'done' for e in report['events']),
               'timing': timing, 'raw_session_result': str(Path(report['result_file']).relative_to(ROOT)),
               'boundary': 'WebSocket payload received, not played; word alignment accuracy unverified',
               'native_quality': 'unreviewed'}
    (OUT / 'summary.json').write_text(redact(json.dumps(summary, ensure_ascii=False, indent=2), credentials) + '\n')
    print(json.dumps({k: summary[k] for k in ('status', 'error_type', 'audio_payload_events',
        'audio_bytes', 'terminal_observed')}, ensure_ascii=False), flush=True)
    print(json.dumps({k: timing.get(k) for k in ('timestamp_frames', 'text_chunks_with_alignment',
        'word_segments_in_latest_snapshots')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
