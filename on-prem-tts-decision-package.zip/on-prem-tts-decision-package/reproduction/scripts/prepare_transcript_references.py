"""Prepare draft references from verified saved audio; never create transcriptions."""
import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent


def prepare(destination):
    destination=Path(destination)
    if destination.exists():
        raise ValueError('Destination exists; preserve earlier annotation packages')
    snapshot_path=ROOT/'ui/public/evidence/snapshot.json'
    snapshot=json.loads(snapshot_path.read_text())
    references=[]; excluded=[]; provenance=[]; seen=set()
    audio_root=(ROOT/'ui/public/evidence/audio').resolve()
    for row in snapshot['runs']:
        if row.get('status')!='success' or not row.get('audio_url'):
            continue
        run_id=row['run_id']
        if run_id in seen:raise ValueError('Duplicate run identity')
        seen.add(run_id)
        text=row.get('text')
        if not isinstance(text,str) or not text.strip() or any(c in text for c in '<>[]'):
            excluded.append({'run_id':run_id,'reason':'empty_or_control_syntax_requires_manual_spoken_reference'})
            continue
        audio=(ROOT/'ui/public'/row['audio_url'].lstrip('/')).resolve()
        if not audio.is_relative_to(audio_root) or not audio.is_file():raise ValueError('Unsafe or missing audio')
        sha=hashlib.sha256(audio.read_bytes()).hexdigest()
        if sha!=row['listening_audio_sha256']:raise ValueError('Audio content hash mismatch')
        model=row.get('config',{}).get('model')
        if not isinstance(model,str) or not model.strip():
            excluded.append({'run_id':run_id,'reason':'exact_model_not_retained'})
            continue
        references.append({'reference_id':run_id,'run_id':run_id,'provider':row['provider'],'model':model,'language':row['language'],'audio_sha256':sha,'text':text,'native_reviewed':False})
        provenance.append({'reference_id':run_id,'audio_file':str(audio),'source_code_sha256':row.get('code_sha256'),'vendor_spec_sha256':row.get('vendor_spec_sha256')})
    destination.mkdir(parents=True)
    for name,data in [('references.json',references),('provenance.json',provenance),('excluded.json',excluded)]:
        (destination/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    status={'references':len(references),'excluded':len(excluded),'languages':sorted({r['language'] for r in references}),'source_snapshot_sha256':hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),'transcriptions_created':0,'native_reviewed_references':0,'scope':'Draft synthesis-input references. Spoken expansions, pronunciation and semantic equivalence require native review. No transcription or quality result is inferred.'}
    (destination/'status.json').write_text(json.dumps(status,indent=2)+'\n')
    return status

if __name__=='__main__':
    print(json.dumps(prepare(sys.argv[1]),indent=2))
