"""One no-retry request for an untouched candy.two regional speaker."""
import argparse
import asyncio
import json
import os
import sys
from datetime import datetime,timezone
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.live_dubverse_flagship_bounded import CASES
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

OPTIONS={locale:(voice,text) for locale,voice,text in CASES[3:]}

async def main(locale):
 voice,text=OPTIONS[locale]
 parent=ROOT/f'artifacts/runs/dubverse-flagship-single-{locale}-20260915'
 summary=ROOT/f'artifacts/dubverse-flagship-single-{locale}-20260915/summary.json'
 if parent.exists() or summary.exists():raise RuntimeError('Speaker already attempted; no repeated spend')
 key=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('DUBVERSE_API_KEY')
 if not key:raise RuntimeError('Authorized Dubverse key absent')
 config={'model':'candy.two','voice':voice,'language':locale,'format':'wav','audio_streaming':False}
 spec=build_request('dubverse',text,config,{'DUBVERSE_API_KEY':key})
 if len(text)>90 or 'sample_rate' in spec.body['config']:raise ValueError('Request preflight failed')
 parent.mkdir(parents=True);summary.parent.mkdir(parents=True)
 report={'provider':'dubverse','model':'candy.two','created_at':datetime.now(timezone.utc).isoformat(),
  'request_limit':1,'automatic_retries':0,'locale':locale,'voice':voice,'text':text,'status':'request_started'}
 def save():summary.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'DUBVERSE_API_KEY':key}))
 save();os.environ['DUBVERSE_API_KEY']=key
 diagnostics=[]
 async def hook(response):
  if response.status_code>=400:
   body=(await response.aread())[:1000].decode('utf8','replace')
   diagnostics.append({'http_status':response.status_code,'body_excerpt':redact(body,{'DUBVERSE_API_KEY':key})})
 try:
  async with httpx.AsyncClient(timeout=35,trust_env=False,follow_redirects=False,
                               event_hooks={'response':[hook]}) as client:
   result=await run_one('dubverse',text,config,parent,timeout=35,client=client,
    scenario_id='dubverse-flagship-single-'+locale,evaluation_language=locale,
    stratum='matched_neo_candy_model_output',min_free_bytes=300*1024*1024)
  report.update({k:result.get(k) for k in ('run_id','status','http_status','error_type',
   'audio_bytes','audio_sha256','duration_seconds','first_audio_ms')})
  report['diagnostics']=diagnostics
 finally:os.environ.pop('DUBVERSE_API_KEY',None)
 report['completed']=True;save()
 print(json.dumps({k:report.get(k) for k in ('locale','status','http_status','error_type','audio_bytes','diagnostics')},ensure_ascii=False))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('locale',choices=sorted(OPTIONS))
 asyncio.run(main(parser.parse_args().locale))
