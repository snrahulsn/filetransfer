"""At most12 short CPU generations, retaining one model; no downloads or credentials."""
import os
os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
import hashlib,json,platform,resource,signal,sys,time,wave
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.adapters._local_runtime import hashes,pcm16,versions
from tts_arena.audio import inspect_audio
from tts_arena.kokoro_qualification import summarize
from tts_arena.registry import code_digest
RECOVERY=sys.argv[1:]==['--remaining-after-disk-failure']
if sys.argv[1:] and not RECOVERY:raise SystemExit('Unknown arguments')
OUT=ROOT/'artifacts/local-20260915/kokoro'/('qualification-recovery' if RECOVERY else 'qualification')

def usage():
 r=resource.getrusage(resource.RUSAGE_SELF)
 return {'process_cpu_seconds':r.ru_utime+r.ru_stime,'process_peak_rss_bytes':int(r.ru_maxrss*(1 if sys.platform=='darwin' else 1024)),'peak_scope':'process lifetime high-water mark, not per-request increment'}

def main():
 # mkdir is the durable cross-interruption guard: never rerun a partly started batch automatically.
 if RECOVERY:
  prior=json.loads((OUT.parent/'qualification/result.json').read_text())
  if len(prior['records'])!=3:raise SystemExit('Recovery budget expects exactly3 prior attempts; inspect manually')
 OUT.mkdir(exist_ok=False)
 start=time.perf_counter();records=[]
 result={'evidence_class':'local_retained_model_qualification','device':'cpu','torch_threads':2,'max_generations':9 if RECOVERY else 12,'prior_attempts':3 if RECOVERY else 0,'status':'initializing','records':records,'native_quality':'not_evaluated','created_date':'2026-09-15','host':platform.platform(),'python':sys.version,'pid':os.getpid(),'downloads_allowed':False,'wall_deadline_seconds':900,'per_generation_deadline_seconds':90,'source_hash':code_digest()}
 def save():
  result['summary']=summarize(records)
  temp=OUT/'result.json.tmp';temp.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');temp.replace(OUT/'result.json')
 save()
 try:
  import torch
  from kokoro import KModel,KPipeline
  import shutil,spacy
  from misaki.espeak import EspeakFallback
  if not shutil.which('espeak-ng') or not spacy.util.is_package('en_core_web_sm'):raise RuntimeError('Required preinstalled offline espeak/spacy assets unavailable')
  EspeakFallback(british=False)
  torch.set_num_threads(2);torch.set_num_interop_threads(1)
  configs={lang:json.loads((ROOT/'artifacts/local-20260915/kokoro'/f'{lang}.json').read_text()) for lang in ['hi-IN','en-US']}
  hi=configs['hi-IN'];en=configs['en-US']
  if any(c['device']!='cpu' or c['allow_model_download'] is not False for c in configs.values()):raise ValueError('Only explicit offlineCPU profile allowed')
  if (hi['weights_path'],hi['config_path'],hi['model_revision'])!=(en['weights_path'],en['config_path'],en['model_revision']):raise ValueError('Retained model profiles must share exactweights/config/revision')
  files=[hi['weights_path'],hi['config_path'],hi['voice_path'],en['voice_path']]
  result['artifact_sha256']=hashes(files);result['model_revision']=hi['model_revision'];result['dependency_versions']=versions(['torch','kokoro','misaki','spacy','en-core-web-sm'])
  imported=time.perf_counter();model=KModel(repo_id=hi['model'],config=hi['config_path'],model=hi['weights_path']).to('cpu').eval();loaded=time.perf_counter()
  pipelines={lang:KPipeline(lang_code='h' if lang=='hi-IN' else 'a',repo_id=c['model'],model=model,device='cpu') for lang,c in configs.items()}
  initialized=time.perf_counter();result.update(import_and_prerequisite_seconds=imported-start,model_load_seconds=loaded-imported,pipeline_initialization_seconds=initialized-loaded,total_initialization_seconds=initialized-start,initialization_resource=usage(),status='running');save()
  cases=[('hindi','hi-IN','नमस्ते, आपकी बैठक कल दोपहर तीन बजे है।'),('english','en-US','Hello, your meeting is tomorrow at three.'),('hinglish','hi-IN','नमस्ते, आपकी meeting कल three बजे है।')]
  def timeout(signum,frame):raise TimeoutError('Bounded local generation exceeded90seconds')
  signal.signal(signal.SIGALRM,timeout)
  plan=[(r,s,c) for r,s in enumerate([1.0,1.0,.8,1.2]) for c in cases]
  if RECOVERY:plan=[(0,1.,cases[0]),(1,1.,cases[0]),(2,.8,cases[0]),(3,1.2,cases[0]),(0,1.,cases[1]),(2,.8,cases[1]),(3,1.2,cases[1]),(0,1.,cases[2]),(1,1.,cases[2])]
  result['planned_generations']=len(plan);save()
  for repetition,speed,(stratum,language,text) in plan:
   if shutil.disk_usage(OUT).free<20_000_000:raise OSError('Below20MB free; stopped before another generation')
   if time.perf_counter()-start>900:raise TimeoutError('Total qualification wall budget exceeded')
   cfg=configs[language];index=len(records);r={'index':index,'stratum':stratum,'language':language,'voice':cfg['voice'],'text':text,'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'speed':speed,'repetition_index':repetition,'model_state':'retained_same_instance','status':'started'};records.append(r);save()
   before=usage();beg=time.perf_counter();first=None;chunks=[]
   signal.alarm(90)
   try:
    with torch.inference_mode():
     for emitted in pipelines[language](text,voice=cfg['voice_path'],speed=speed):
      b=pcm16(emitted.audio if hasattr(emitted,'audio') else emitted[2])
      if first is None:first=time.perf_counter()-beg
      chunks.append(b)
    wall=time.perf_counter()-beg;raw=b''.join(chunks)
    analysis=inspect_audio(raw,'pcm_s16le',24000,1);duration=analysis['duration_seconds']
    filename=f'{index:02d}-{stratum}-speed-{speed}.wav'
    with wave.open(str(OUT/filename),'wb') as f:f.setnchannels(1);f.setsampwidth(2);f.setframerate(24000);f.writeframes(raw)
    after=usage();r.update(status='success',synthesis_wall_seconds=wall,process_cpu_seconds=after['process_cpu_seconds']-before['process_cpu_seconds'],first_pipeline_chunk_seconds=first,pipeline_chunks=len(chunks),duration_seconds=duration,realtime_factor=wall/duration,audio_sha256=hashlib.sha256(raw).hexdigest(),audio_file=filename,audio_analysis=analysis,resource_after=after)
    print(stratum,speed,'success',round(wall,3),'s',round(duration,3),'audio s',flush=True)
   except Exception as e:r.update(status='error',error_type=type(e).__name__,error=str(e)[:400]);raise
   finally:signal.alarm(0);save()
  result['status']='completed';result['total_wall_seconds']=time.perf_counter()-start;result['final_resource']=usage();save()
 except Exception as e:
  result.update(status='failed',error_type=type(e).__name__,error=str(e)[:400],total_wall_seconds=time.perf_counter()-start);save();raise
if __name__=='__main__':main()
