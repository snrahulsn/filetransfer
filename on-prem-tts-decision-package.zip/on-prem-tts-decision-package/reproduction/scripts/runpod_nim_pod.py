"""Create one capped Magpie Speech NIM Pod from the private NGC image, with cleanup."""
import argparse
import json
import subprocess
import sys
import urllib.error
import urllib.request
import uuid
from pathlib import Path

from scripts.nvidia_nim_preflight import GPU, IMAGE, inspect
from scripts.runpod_eval_pod import api as pod_api
from scripts.runpod_nim_guard import cleanup
from tts_arena.credentials import read_credentials
from tts_arena.one_audio_per_locale import assert_missing_audio


ROOT = Path(__file__).resolve().parents[1]


def registry_api(method: str, key: str, auth_id: str = '', payload: dict | None = None):
    body = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(
        'https://rest.runpod.io/v1/containerregistryauth' + ('/' + auth_id if auth_id else ''),
        data=body, method=method,
        headers={'Authorization': f'Bearer {key}', 'Accept': 'application/json',
                 'Content-Type': 'application/json',
                 'User-Agent': 'Mozilla/5.0 Chrome/124.0.0.0 Safari/537.36'},
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read()
            return response.status, json.loads(data) if data else None
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'Runpod registry auth HTTP {error.code}') from None


def start_guard(pod_id: str, auth_id: str, credentials_path: Path, log_file: Path):
    guard = Path(__file__).with_name('runpod_nim_guard.py')
    subprocess.Popen(
        [sys.executable, str(guard), '--pod-id', pod_id, '--registry-auth-id', auth_id,
         '--credentials-path', str(credentials_path), '--seconds', '3600', '--log', str(log_file)],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def recover_registry_auth_id(registry, runpod_key: str, auth_name: str) -> str | None:
    """Reconcile a registry create response without exposing its stored password."""
    status, current = registry('GET', runpod_key)
    if status != 200 or not isinstance(current, list):
        return None
    matches = [entry for entry in current if isinstance(entry, dict)
               and entry.get('name') == auth_name and entry.get('id')]
    return matches[0]['id'] if len(matches) == 1 else None


def create(credentials: dict, credentials_path: Path, guard_log: Path,
           *, pods=pod_api, registry=registry_api, guard=start_guard,
           cleanup_fn=cleanup, audio_guard=assert_missing_audio):
    readiness = inspect(credentials, pods)
    if not readiness['can_launch']:
        raise ValueError(readiness['blocker'])
    audio_guard(ROOT, 'nvidia', 'hi-IN')
    runpod_key = credentials.get('RunPod') or credentials.get('RUNPOD_API_KEY')
    ngc_key = credentials.get('NGC_API_KEY') or credentials.get('NVIDIA_NGC_API_KEY')
    unique = uuid.uuid4().hex[:12]
    pod_name = 'tts-arena-nim-magpie-' + unique
    auth_name = 'tts-arena-ngc-catalog-' + unique
    try:
        status, auth = registry('POST', runpod_key, payload={
            'name': auth_name, 'username': '$oauthtoken', 'password': ngc_key,
        })
    except Exception:
        status, auth = None, None
    auth_id = auth.get('id') if status in (200, 201) and isinstance(auth, dict) else None
    if not auth_id:
        auth_id = recover_registry_auth_id(registry, runpod_key, auth_name)
    if not auth_id:
        raise RuntimeError('Runpod temporary registry credential was not identified; '
                           'reconcile the named auth before retrying')
    pod_id = None
    try:
        payload = {
            'name': pod_name, 'cloudType': 'SECURE', 'computeType': 'GPU',
            'gpuCount': 1, 'gpuTypeIds': [GPU], 'imageName': IMAGE,
            'containerRegistryAuthId': auth_id, 'containerDiskInGb': 150,
            'volumeInGb': 20, 'volumeMountPath': '/workspace',
            'ports': ['9000/http', '50051/tcp'], 'interruptible': False,
            'minRAMPerGPU': 32, 'minVCPUPerGPU': 8,
            'env': {'NGC_API_KEY': ngc_key, 'NIM_HTTP_API_PORT': '9000',
                    'NIM_GRPC_API_PORT': '50051',
                    'NIM_TAGS_SELECTOR': 'name=magpie-tts-multilingual,batch_size=8'},
        }
        try:
            status, pod = pods('POST', runpod_key, payload=payload)
        except Exception:
            status, current = pods('GET', runpod_key)
            matches = [p for p in current if p.get('name') == pod_name]
            if len(matches) != 1:
                raise RuntimeError('Pod create response uncertain; reconcile Runpod inventory') from None
            pod = matches[0]
        if status not in (200, 201) or not isinstance(pod, dict) or not pod.get('id'):
            _, current = pods('GET', runpod_key)
            matches = [p for p in current if p.get('name') == pod_name]
            if len(matches) != 1:
                raise RuntimeError('Runpod NIM Pod creation outcome could not be identified')
            pod = matches[0]
        pod_id = pod['id']
        hourly = float(pod.get('adjustedCostPerHr') or pod.get('costPerHr') or 0)
        if not 0 < hourly <= 1.5:
            raise RuntimeError('NIM Pod exceeded $1.50/hour cap or price was unavailable')
        guard(pod_id, auth_id, credentials_path, guard_log)
        return {'pod_id': pod_id, 'registry_auth_id': auth_id, 'name': pod_name,
                'hourly_usd': hourly, 'guard_seconds': 3600,
                'https_origin': f'https://{pod_id}-9000.proxy.runpod.net',
                'container_image': IMAGE, 'profile': 'batch_size=8'}
    except Exception:
        if pod_id:
            cleanup_fn(pod_id, auth_id, runpod_key)
        else:
            try:
                registry('DELETE', runpod_key, auth_id)
            except Exception:
                pass
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--credentials-path', type=Path, required=True)
    parser.add_argument('--guard-log', type=Path, required=True)
    parser.add_argument('--create', action='store_true', help='Create one billable capped Pod')
    args = parser.parse_args()
    credentials = read_credentials(args.credentials_path)
    result = create(credentials, args.credentials_path, args.guard_log) if args.create else inspect(credentials)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
