"""Export observed lexical word marks; no independent reference is manufactured."""
import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent


def prepare(destination):
    destination=Path(destination)
    if destination.exists():raise ValueError('Preserve existing preparation')
    summary_path=ROOT/'artifacts/inworld-timestamps-20260915/summary.json'
    summary=json.loads(summary_path.read_text())
    result_path=Path(summary['result_file'])
    result=json.loads(result_path.read_text())
    audio=ROOT/'ui/public/evidence/audio'/('d28d1d4492f4462390d3d051a6db23bd.wav')
    sha=hashlib.sha256(audio.read_bytes()).hexdigest()
    if sha!=summary['result']['audio_sha256']:raise ValueError('Audio hash mismatch')
    metadata=[m for m in result['provider_metadata'] if 'timestampInfo' in m]
    if len(metadata)!=1:raise ValueError('Ambiguous metadata')
    marks=metadata[0]['timestampInfo']['wordAlignment']
    if len({len(marks[k]) for k in ['words','wordStartTimeSeconds','wordEndTimeSeconds']})!=1:raise ValueError('Unequal timing arrays')
    words=[];excluded=[];mapping=[]
    for i,(text,start,end) in enumerate(zip(marks['words'],marks['wordStartTimeSeconds'],marks['wordEndTimeSeconds'])):
        mark={'text':text,'start':start,'end':end}
        if not any(c.isalnum() for c in text):
            excluded.append({'source_index':i,**mark,'reason':'no_letter_or_number'})
            continue
        mapping.append({'output_index':len(words),'source_index':i})
        words.append(mark)
    observation={'run_id':result['run_id'],'provider':'inworld','model':summary['config']['model'],'language':summary['config']['language'],'audio_sha256':sha,'time_unit':'seconds','time_origin':'synthesis_start','words':words}
    provenance={'source_result':str(result_path),'source_result_sha256':hashlib.sha256(result_path.read_bytes()).hexdigest(),'audio_file':str(audio),'source_entries':len(marks['words']),'lexical_entries':len(words),'excluded':excluded,'mapping':mapping,'filter':'Explicit letter/number-presence filter; punctuation/space/empty marks retained in exclusions. Text and times otherwise unchanged.','independent_reference_created':False,'alignment_accuracy':'not_measured'}
    destination.mkdir(parents=True)
    for name,data in [('observed.json',observation),('provenance.json',provenance)]:
        (destination/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    return {'lexical_entries':len(words),'excluded_entries':len(excluded),'independent_reference_created':False}

if __name__=='__main__':print(json.dumps(prepare(sys.argv[1])))
