"""One bounded Hindi 8 kHz G.711 mu-law Cartesia output probe."""

import asyncio
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tts_arena.audio import inspect_audio
from tts_arena.credentials import read_credentials
from tts_arena.registry import build_request
from tts_arena.runner import run_one
from tts_arena.g711 import mulaw_to_wav

OUT = ROOT / 'artifacts/cartesia-telephony-20260916'
TEXT = 'नमस्ते, आपकी बैठक कल तीन बजे है। कृपया पुष्टि करें।'
CONFIG = {
    'model': 'sonic-3.6',
    'voice': '4459a9a5-69d6-4680-b970-e13dc51845b6',
    'language': 'hi-IN',
    'format': 'raw',
    'encoding': 'pcm_mulaw',
    'sample_rate': 8000,
}
SOURCE = 'https://docs.cartesia.ai/integrations/twilio'


async def main() -> None:
    if OUT.exists():
        raise RuntimeError('Cartesia telephony probe already prepared or attempted; no automatic repeat')
    assert len(TEXT) < 90
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    token = credentials.get('CARTESIA_API_KEY')
    if not token:
        raise RuntimeError('Authorized Cartesia key unavailable')
    spec = build_request('cartesia', TEXT, CONFIG, {'CARTESIA_API_KEY': token})
    assert spec.encoding == 'mulaw' and spec.sample_rate == 8000
    OUT.mkdir(parents=True, exist_ok=False)
    summary = {
        'provider': 'cartesia', 'model': CONFIG['model'], 'language': 'hi-IN',
        'voice': CONFIG['voice'], 'requested_text': TEXT, 'config': CONFIG,
        'source': SOURCE, 'source_accessed': '2026-09-16',
        'max_requests': 1, 'automatic_retries': 0,
        'estimated_max_characters': len(TEXT),
        'status': 'request_started',
        'boundary': 'Direct TTS byte output only; SIP/RTP receiver, handset and production playout untested.',
    }
    path = OUT / 'summary.json'
    def save() -> None:
        path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    save()
    os.environ['CARTESIA_API_KEY'] = token
    try:
        result = await run_one('cartesia', TEXT, CONFIG, OUT / 'runs', timeout=35,
                               scenario_id='cartesia-8khz-mulaw', evaluation_language='hi-IN',
                               stratum='telephony_format_bounded', min_free_bytes=300*1024*1024)
    finally:
        os.environ.pop('CARTESIA_API_KEY', None)
    summary.update({k: result.get(k) for k in ('run_id', 'status', 'http_status', 'error_type',
                                                'content_type', 'audio_bytes', 'audio_sha256')})
    summary['result_path'] = str((OUT / 'runs' / result['run_id'] / 'result.json').relative_to(ROOT))
    if result['status'] == 'success':
        folder = OUT / 'runs' / result['run_id']
        raw = (folder / result['audio_file']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != result['audio_sha256'] or len(raw) < 800 or raw.startswith((b'RIFF', b'ID3', b'{')):
            raise ValueError('Returned payload is not a plausible headerless G.711 stream')
        wav = mulaw_to_wav(raw)
        analysis = inspect_audio(wav)
        if analysis['sample_rate'] != 8000 or analysis['rms'] < 10:
            raise ValueError('Decoded G.711 payload is silent or has the wrong rate')
        (folder / 'listen.wav').write_bytes(wav)
        summary.update(raw_payload_bytes=len(raw), raw_payload_sha256=hashlib.sha256(raw).hexdigest(),
                       listening_wav_sha256=hashlib.sha256(wav).hexdigest(),
                       decoded_duration_seconds=len(raw)/8000, decoded_pcm_rms=analysis['rms'],
                       telephony_delivery='observed_decodable_8khz_mulaw')
    else:
        summary['telephony_delivery'] = 'not_confirmed'
    save()
    print(json.dumps({k: summary.get(k) for k in ('status','http_status','telephony_delivery','raw_payload_bytes')}))


if __name__ == '__main__':
    asyncio.run(main())
