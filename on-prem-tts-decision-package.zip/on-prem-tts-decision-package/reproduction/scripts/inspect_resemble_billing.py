"""Two bounded read-only Resemble billing reads; no synthesis or purchase."""
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sys
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials

BASE = 'https://app.resemble.ai/billing/api/v1'
OUT = ROOT / 'artifacts/resemble-access-20260916/billing-sanitized.json'
CREDENTIALS = '/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env'
SOURCE = 'https://docs.resemble.ai/getting-started/authentication'


def amount(value, label):
    try:
        decimal = Decimal(str(value))
    except (InvalidOperation, TypeError):
        raise ValueError(f'Invalid {label}') from None
    if not decimal.is_finite() or decimal < 0:
        raise ValueError(f'Invalid {label}')
    return str(decimal)


def sanitize_wallet(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get('wallet'), dict):
        raise ValueError('Billing wallet response lacks wallet')
    wallet = payload['wallet']
    fields = ('balance_dollars', 'cash_balance_dollars', 'promotional_balance_dollars',
              'lifetime_loaded_dollars', 'lifetime_consumed_dollars')
    result = {field: amount(wallet.get(field), field) for field in fields}
    if type(wallet.get('low_balance')) is not bool:
        raise ValueError('Wallet low_balance must be boolean')
    result['low_balance'] = wallet['low_balance']
    if Decimal(result['cash_balance_dollars']) + Decimal(result['promotional_balance_dollars']) != Decimal(result['balance_dollars']):
        raise ValueError('Wallet total differs from cash plus promotional balances')
    return result


def sanitize_subscription(payload):
    if not isinstance(payload, dict) or 'subscription' not in payload:
        raise ValueError('Billing subscription response lacks subscription')
    row = payload['subscription']
    if row is None:
        return {'subscription_present': False}
    if not isinstance(row, dict):
        raise ValueError('Invalid subscription')
    plan = row.get('plan')
    if not isinstance(plan, dict):
        raise ValueError('Subscription lacks plan')
    for field, value in [('status', row.get('status')), ('plan_type', plan.get('plan_type')),
                         ('billing_interval', plan.get('billing_interval'))]:
        if value is not None and (not isinstance(value, str) or len(value) > 80):
            raise ValueError(f'Invalid {field}')
    return {'subscription_present': True, 'status': row.get('status'),
            'plan_type': plan.get('plan_type'), 'billing_interval': plan.get('billing_interval'),
            'base_fee_dollars': amount(plan.get('base_fee_dollars'), 'base_fee_dollars'),
            'included_dollar_balance_dollars': amount(plan.get('included_dollar_balance_dollars'), 'included_dollar_balance_dollars')}


def get(path, key, opener=urlopen):
    request = Request(BASE + path, headers={'Authorization': 'Bearer ' + key,
                                            'Accept': 'application/json'})
    try:
        with opener(request, timeout=20) as response:
            if response.status != 200:
                return {'http_status': response.status, 'status': 'non_200'}
            raw = response.read(500_001)
    except HTTPError as error:
        return {'http_status': error.code, 'status': 'non_200'}
    except URLError:
        return {'http_status': None, 'status': 'transport_error'}
    if len(raw) > 500_000:
        raise ValueError('Resemble billing response too large')
    return {'http_status': 200, 'status': 'success', 'body': json.loads(raw)}


def inspect(key, opener=urlopen):
    subscription = get('/subscription', key, opener)
    wallet = get('/wallet', key, opener)
    result = {'provider': 'resemble', 'observed_at': datetime.now(timezone.utc).isoformat(),
              'source': SOURCE, 'request_count': 2, 'automatic_retries': 0,
              'synthesis_requests': 0, 'purchase_or_payment_change': False,
              'money_cost_verified': False,
              'subscription_http_status': subscription['http_status'],
              'wallet_http_status': wallet['http_status']}
    if subscription['status'] == 'success':
        result['subscription'] = sanitize_subscription(subscription['body'])
    if wallet['status'] == 'success':
        result['wallet'] = sanitize_wallet(wallet['body'])
    result['conclusion'] = ('Account billing state only; no per-generation dollar reconciliation. '
                            'A positive balance does not prove that a chosen voice/model is synthesis-entitled.')
    return result


def main():
    if OUT.exists():
        raise SystemExit('Saved billing observation exists; no automatic repeat')
    key = read_credentials(CREDENTIALS).get('RESEMBLE_API_KEY')
    if not key:
        raise SystemExit('Resemble credential unavailable')
    result = inspect(key)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'subscription_http_status': result['subscription_http_status'],
                      'wallet_http_status': result['wallet_http_status'],
                      'subscription_present': result.get('subscription', {}).get('subscription_present'),
                      'wallet_balance_dollars': result.get('wallet', {}).get('balance_dollars'),
                      'money_cost_verified': False, 'request_count': 2}))


if __name__ == '__main__':
    main()
