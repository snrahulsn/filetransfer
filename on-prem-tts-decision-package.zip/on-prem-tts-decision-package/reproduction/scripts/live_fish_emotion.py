"""Two explicit current-model Hindi bracket-cue probes; no automatic retries."""
import asyncio,json,os,shutil,sys,wave,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/fish-emotion-20260915'

async def main():
    if OUT.exists():raise RuntimeError('Feature batch exists; no repeated calls')
    assert shutil.disk_usage(ROOT).free>=500*1024*1024
    creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    prior=json.loads((ROOT/'artifacts/access-20260915/fish.json').read_text())
    selected=next(r for r in prior['runs'] if r.get('status')=='success' and r.get('language')=='hi-IN' and r['config']['model']=='s2.1-pro-free')
    config=dict(selected['config']);text='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
    os.environ['FISH_API_KEY']=creds['FISH_API_KEY']
    try:
        jobs=[(cue,'['+cue+'] '+text) for cue in ('calm','angry')]
        requests=[build_request('fish',t,config) for _,t in jobs]
        assert all(len(t)<=140 for _,t in jobs)
        OUT.mkdir(exist_ok=False)
        result={'provider':'fish','model':'s2.1-pro-free','language':'hi-IN','native_accuracy':'unverified','emotion_perception':'unverified','automatic_retries':0,
                'scope':'Two matched-transcript cue acceptance/audio delivery samples; stochastic waveform differences do not establish perceived emotion.',
                'transcript':text,'config':config,'prior_hindi_success':selected['run_id'],
                'sources':['https://docs.fish.audio/developer-guide/models-pricing/models-overview.md','https://fish.audio/developers/'],
                'attempts':[]}
        def save():
            tmp=OUT/'summary.json.tmp';tmp.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n');tmp.replace(OUT/'summary.json')
        save();errors=[]
        async def hook(response):
            if response.status_code>=400:
                await response.aread();errors.append({'http_status':response.status_code,'message':redact(response.text,creds)[:1500]})
        async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
            for (cue,prompt),spec in zip(jobs,requests):
                assert shutil.disk_usage(ROOT).free>=500*1024*1024
                item={'cue':cue,'request_body':spec.body,'request_model_header':spec.headers['model'],'status':'request_started'}
                result['attempts'].append(item);save();errors.clear()
                record=await run_one('fish',prompt,config,OUT/'runs',timeout=30,client=client,scenario_id='fish-hindi-'+cue,evaluation_language='hi-IN',stratum='draft_emotion_cue_contrast')
                item.update({k:record.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','audio_sha256','duration_seconds','audio_analysis','content_type')})
                item['diagnostics']=errors.copy();folder=OUT/'runs'/record['run_id'];item['record']=str((folder/'result.json').relative_to(ROOT))
                if record['status']=='success':
                    data=(folder/record['audio_file']).read_bytes();assert hashlib.sha256(data).hexdigest()==record['audio_sha256']
                    item['raw_audio_file']=str((folder/record['audio_file']).relative_to(ROOT))
                    with wave.open(str(folder/'listen.wav'),'wb') as wav:wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(24000);wav.writeframes(data)
                    item['listening_audio']=str((folder/'listen.wav').relative_to(ROOT))
                save();print('Fish '+cue+' '+record['status']+' HTTP '+str(record.get('http_status')),flush=True)
                if record['status']!='success':break
                await asyncio.sleep(1)
        result['completed']=True;result['audio_returned']=sum(a['status']=='success' for a in result['attempts']);save()
    finally:os.environ.pop('FISH_API_KEY',None)

if __name__=='__main__':asyncio.run(main())
