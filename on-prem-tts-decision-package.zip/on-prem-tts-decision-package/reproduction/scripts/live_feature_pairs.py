"""Bounded matched speed and emotion controls; no ratings or certification."""
import asyncio,copy,json,math,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request,digest
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/feature-pairs-20260915'
SPEED_TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें और दस मिनट पहले पहुँचें।'
EMOTION_TEXT='मैंने आपकी बात सुन ली है। अब हम आगे की योजना पर बात करेंगे।'
PAIRS={
 'cartesia_speed':{'provider':'cartesia','feature':'speed','field':'speed','values':[1.0,1.4],'text':SPEED_TEXT,'config':{'model':'sonic-3.6','voice':'4459a9a5-69d6-4680-b970-e13dc51845b6','language':'hi-IN','format':'raw','encoding':'pcm_s16le','sample_rate':24000}},
 'sarvam_speed':{'provider':'sarvam','feature':'speed','field':'pace','values':[1.0,1.4],'text':SPEED_TEXT,'config':{'model':'bulbul:v3','voice':'shubh','language':'hi-IN','format':'wav','sample_rate':24000}},
 'minimax_emotion':{'provider':'minimax','feature':'emotion','field':'emotion','values':['calm','angry'],'text':EMOTION_TEXT,'config':{'model':'speech-2.8-hd','voice':'hindi_female_2_v1','language':'Hindi','format':'pcm','sample_rate':24000}}}
KEYS={'cartesia':'CARTESIA_API_KEY','sarvam':'SARVAM_API_KEY','minimax':'MINIMAX_API_KEY'}
def validate_pair(records,field):
 if len(records)!=2:raise ValueError('Exactly two records required')
 a,b=records
 if a['text']!=b['text'] or a['provider']!=b['provider']:raise ValueError('Pair transcript/provider mismatch')
 ca,cb=copy.deepcopy(a['config']),copy.deepcopy(b['config']);va=ca.pop(field);vb=cb.pop(field)
 if ca!=cb or va==vb:raise ValueError('Only the intended control may differ')
 return va,vb

def outcome(records,field,feature):
 va,vb=validate_pair(records,field)
 result={'feature':feature,'requested_values':[va,vb],'request_acceptance':'accepted' if all(r.get('status')=='success' for r in records) else 'not_confirmed','pronunciation':'unverified','emotional_accuracy':'unverified','native_listener_review':'pending','certification':'not_certified'}
 if result['request_acceptance']!='accepted':return result
 durations=[r.get('duration_seconds') for r in records]
 if any(type(x) not in (int,float) or not math.isfinite(x) or x<=0 for x in durations):raise ValueError('Valid measured durations required')
 ratio=durations[1]/durations[0];result.update(durations_seconds=durations,duration_ratio=ratio,audio_changed=records[0].get('audio_sha256')!=records[1].get('audio_sha256'))
 if feature=='speed':result.update(direction_observation='shorter_at_higher_setting' if ratio<1 else 'not_shorter_at_higher_setting',ideal_inverse_multiplier_reference=va/vb,strict_multiplier_conformance='not_claimed; generative guidance and one pair')
 else:result['behavioral_effect']='audio waveform contrast measured; emotion correctness requires qualified listening'
 return result
async def main():
 if OUT.exists():raise RuntimeError('Feature-pair evidence exists; no automatic repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 for pair in PAIRS.values():
  p=pair['provider'];os.environ[KEYS[p]]=secrets[KEYS[p]];assert len(pair['text'])<140
  for value in pair['values']:build_request(p,pair['text'],dict(pair['config'],**{pair['field']:value}))
 OUT.mkdir(parents=True,exist_ok=False);(OUT/'plan.json').write_text(json.dumps({'pairs':PAIRS,'max_syntheses':6,'no_retries':True,'analysis':'direction and duration ratio; no perceptual/emotion pass claim'},ensure_ascii=False,indent=2)+'\n')
 report={'pairs':{},'attempts':0,'scope':'Three paired exploratory controls; not procurement ranking or vendor certification'}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n')
 for pair_id,pair in PAIRS.items():
  records=[];errors=[];report['pairs'][pair_id]={'records':records,'status':'in_progress'};save()
  async def hook(response):
   if response.status_code>=400:errors.append({'http_status':response.status_code,'message':redact((await response.aread())[:4000].decode('utf8','replace'),secrets)})
  async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
   for value in pair['values']:
    cfg=dict(pair['config'],**{pair['field']:value});report['attempts']+=1;save()
    r=await run_one(pair['provider'],pair['text'],cfg,OUT/'runs'/pair_id,timeout=30,client=client,evaluation_language='hi-IN',scenario_id=pair_id,stratum='paired_control')
    record={k:r.get(k) for k in ['run_id','provider','text','config','status','http_status','duration_seconds','audio_sha256','audio_bytes','audio_analysis','error_type']};record['result_file']=str(OUT/'runs'/pair_id/r['run_id']/'result.json');records.append(record);save();print(pair_id,value,r['status'],r.get('http_status'),flush=True)
    if r['status']!='success':break
  report['pairs'][pair_id].update(status='complete' if len(records)==2 else 'blocked_no_retry',diagnostics=errors,outcome=outcome(records,pair['field'],pair['feature']) if len(records)==2 else {'request_acceptance':'not_confirmed','native_listener_review':'pending'});save()
 report['complete']=True;save()
if __name__=='__main__':asyncio.run(main())
