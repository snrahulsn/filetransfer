"""One bounded Hindi synthesis through NVIDIA's hosted Build Magpie endpoint."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time
import wave

import httpx

from tts_arena.credentials import read_credentials


ORIGIN = "https://877104f7-e885-42b9-8de8-f6e4c6303969.invocation.api.nvcf.nvidia.com"
TEXT = "आपकी किस्त पंद्रह हज़ार रुपये है और भुगतान पंद्रह सितंबर को करना है।"
VOICE = "Magpie-Multilingual.HI-IN.Sofia"


def run(credentials: Path, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    wav_path = output / "nvidia-magpie--hi-IN.wav"
    json_path = output / "nvidia-magpie--hi-IN.json"
    if wav_path.exists() or json_path.exists():
        raise FileExistsError("Refusing a second NVIDIA hi-IN output")
    values = read_credentials(credentials)
    key = values.get("NVIDIA_NGC_API_KEY") or values.get("NGC_API_KEY")
    if not key:
        raise ValueError("NVIDIA key unavailable")
    started = time.perf_counter()
    with httpx.Client(timeout=120, follow_redirects=False, trust_env=False) as client:
        discovery = client.get(ORIGIN + "/v1/audio/list_voices",
                               headers={"Authorization": "Bearer " + key})
        discovery.raise_for_status()
        inventory = discovery.json()
        voices = sorted({voice for group in inventory.values() if isinstance(group, dict)
                         for voice in group.get("voices", []) if isinstance(voice, str)})
        if VOICE not in voices:
            raise RuntimeError("Selected Hindi voice absent from live hosted inventory")
        response = client.post(
            ORIGIN + "/v1/audio/synthesize",
            headers={"Authorization": "Bearer " + key},
            data={"text": TEXT, "language": "hi-IN", "voice": VOICE,
                  "encoding": "LINEAR_PCM", "sample_rate_hz": "22050"},
        )
        response.raise_for_status()
    raw = response.content
    if len(raw) < 4096 or not raw.startswith(b"RIFF"):
        raise RuntimeError("Hosted Magpie returned no valid WAV")
    wav_path.write_bytes(raw)
    with wave.open(str(wav_path), "rb") as stream:
        if stream.getnchannels() != 1 or stream.getsampwidth() != 2:
            raise ValueError("Hosted Magpie WAV is not mono PCM16")
        sample_rate = stream.getframerate()
        duration = stream.getnframes() / sample_rate
    live_locales = sorted({locale for key_name in inventory for locale in key_name.split(",")})
    result = {
        "provider": "NVIDIA Build hosted NIM API",
        "model": "magpie-tts-multilingual",
        "function_id": "877104f7-e885-42b9-8de8-f6e4c6303969",
        "route": "hosted_nvidia_build_api",
        "self_hosted_execution": False,
        "language": "hi-IN",
        "voice": VOICE,
        "text": TEXT,
        "audio_file": wav_path.name,
        "audio_bytes": len(raw),
        "audio_sha256": hashlib.sha256(raw).hexdigest(),
        "sample_rate": sample_rate,
        "duration_seconds": duration,
        "wall_seconds_including_discovery": time.perf_counter() - started,
        "live_locales": live_locales,
        "hindi_voice_count": len([voice for voice in voices if ".HI-IN." in voice]),
        "quality_certification": "pending_blind_native_review",
        "scope": "hosted exact-model functional output; not self-hosted cold-start or throughput proof",
    }
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--credentials", type=Path, required=True)
    parser.add_argument("--output", type=Path,
                        default=Path("artifacts/on-prem-candidates/nvidia-build-magpie"))
    args = parser.parse_args()
    result = run(args.credentials, args.output)
    print(json.dumps({key: result[key] for key in
                      ("language", "voice", "duration_seconds", "wall_seconds_including_discovery",
                       "hindi_voice_count", "live_locales")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
