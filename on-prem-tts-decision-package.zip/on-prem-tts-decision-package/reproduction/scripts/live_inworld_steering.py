"""Exactly two authorized Hindi instructions, synchronous TTS-2; guarded against repeats."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one
from scripts.live_feature_pairs import outcome
OUT=Path(__file__).resolve().parents[1]/'artifacts/inworld-steering-20260915'
TEXT='मैंने आपकी बात सुन ली है। अब हम आगे की योजना पर बात करेंगे।'
BASE=dict(model='inworld-tts-2',voice='Meher',language='hi-IN',format='WAV',sample_rate=24000,delivery_mode='BALANCED')
INSTRUCTIONS=['Speak calmly and gently.','Speak angrily and forcefully.']
async def main():
 if OUT.exists():raise RuntimeError('Evidence guard exists; no repeats')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');os.environ['INWORLD_API_KEY']=secrets['INWORLD_API_KEY']
 for instruction in INSTRUCTIONS:build_request('inworld',TEXT,dict(BASE,instruction=instruction))
 OUT.mkdir(exist_ok=False);report={'max_requests':2,'attempts':0,'no_retries':True,'text':TEXT,'base_config':BASE,'instructions':INSTRUCTIONS,'records':[],'diagnostics':[],'emotional_accuracy':'unverified'}
 def save():(OUT/'summary.json').write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n')
 save()
 async def hook(response):
  if response.status_code>=400:report['diagnostics'].append({'http_status':response.status_code,'message':redact((await response.aread())[:3000].decode('utf8','replace'),secrets)})
 async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[hook]}) as client:
  for instruction in INSTRUCTIONS:
   report['attempts']+=1;save()
   r=await run_one('inworld',TEXT,dict(BASE,instruction=instruction),OUT/'runs',timeout=30,client=client,evaluation_language='hi-IN',scenario_id='inworld_instruction_pair',stratum='paired_control')
   record={k:r.get(k) for k in ['run_id','provider','text','config','status','http_status','duration_seconds','audio_sha256','audio_bytes','error_type','provider_usage']};record['result_file']=str(OUT/'runs'/r['run_id']/'result.json');report['records'].append(record);save();print(r['status'],r.get('http_status'),flush=True)
   if r['status']!='success':break
 if len(report['records'])==2:report['outcome']=outcome(report['records'],'instruction','emotion')
 report['complete']=True;save()
if __name__=='__main__':asyncio.run(main())
