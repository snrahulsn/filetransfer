"""Bounded, explicitly authorized live access smoke tests; never a quality benchmark."""
import asyncio,json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from tts_arena.runner import run_one
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/access-20260915'
TEXT={'hi-IN':'नमस्ते, मैं आपकी सहायता के लिए यहाँ हूँ। क्या आप कल दोपहर बात कर सकते हैं?', 'en-IN':'Hello, I am here to help you. Would tomorrow afternoon be a convenient time to call?', 'ta-IN':'வணக்கம், உங்களுக்கு உதவ நான் இங்கே இருக்கிறேன். நாளை பேசலாமா?'}
KEYS={'minimax':'MINIMAX_API_KEY','fish':'FISH_API_KEY','hume':'HUME_API_KEY','inworld':'INWORLD_API_KEY'}
CONFIGS={
 'minimax': [('hi-IN',{'model':'speech-2.8-hd','voice':'hindi_female_2_v1','language':'Hindi','format':'pcm','sample_rate':24000}),('en-IN',{'model':'speech-2.8-hd','voice':'hindi_female_2_v1','language':'English','format':'pcm','sample_rate':24000}),('ta-IN',{'model':'speech-2.8-hd','voice':'hindi_female_2_v1','language':'Tamil','format':'pcm','sample_rate':24000})],
 'fish':[(loc,{'model':'s2.1-pro','voice':'9a9cf47702da476aa4629e2506d4a857','language':'auto','format':'pcm','sample_rate':24000}) for loc in TEXT],
 'hume':[(loc,{'model':'2','voice':'1fe215ab-513c-4fc8-9233-fa64b65073ab','language':'auto','format':'pcm'}) for loc in ['hi-IN','en-IN']],
 'inworld':[(loc,{'model':'inworld-tts-2','voice':'Meher' if loc!='en-IN' else 'Anjali','language':loc,'format':'PCM','sample_rate':24000}) for loc in TEXT]
}
async def main(selected):
 creds=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 for p in selected:
  target=OUT/(p+'.json')
  if target.exists():raise SystemExit('Existing summary: refusing accidental repeat for '+p)
  key=KEYS[p];os.environ[key]=creds[key]; errors=[]; runs=[]
  async def response_hook(response):
   if response.status_code>=400 or ('application/json' in response.headers.get('content-type','') and p=='minimax'):
    await response.aread()
    try:
     d=response.json()
     if p=='minimax' and response.status_code<400:
      d=d.get('base_resp',{})
      if d.get('status_code',0)==0:return
     errors.append({'http_status':response.status_code,'message':redact(json.dumps(d,ensure_ascii=False),creds)[:1500]})
    except Exception:errors.append({'http_status':response.status_code,'message':'Non-JSON error body omitted'})
  try:
   async with httpx.AsyncClient(timeout=30,trust_env=False,follow_redirects=False,event_hooks={'response':[response_hook]}) as client:
    for loc,config in CONFIGS[p]:
     r=await run_one(p,TEXT[loc],config,ROOT/'artifacts/runs/access-20260915'/p,timeout=30,client=client,evaluation_language=loc,scenario_id='access-smoke-'+loc,stratum='access_smoke')
     runs.append({k:r.get(k) for k in ['run_id','language','config','status','error_type','audio_bytes','duration_seconds','first_audio_ms','http_status']})
     print(p,loc,r['status'],r.get('audio_bytes'),flush=True)
     if r['status']!='success':break
  finally:os.environ.pop(key,None)
  result={'provider':p,'checked_at':'2026-09-15','credential_alias':key,'status':'synthesis_access_confirmed' if any(r['status']=='success' for r in runs) else 'synthesis_blocked','runs':runs,'errors':errors,'naturalness':'not_evaluated','accent_quality':'not_evaluated','billing':'not_reconciled','model_selection':'Current generation only; no legacy fallback','voice_selection':'Discovered preset ID; Fish documented quickstart example. Cross-language output does not validate accent or correctness.'}
  target.write_text(redact(json.dumps(result,ensure_ascii=False,indent=2),creds)+'\n')
if __name__=='__main__':asyncio.run(main(sys.argv[1:] or list(CONFIGS)))
