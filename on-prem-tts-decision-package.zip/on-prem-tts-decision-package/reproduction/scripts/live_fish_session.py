"""One authorized S2.1-Pro-Free native session, with staged flush observation."""
import asyncio,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from websockets.asyncio.client import connect
from tts_arena.credentials import read_credentials,redact
from tts_arena.session_runner import run_session
from tts_arena.sessions import fish
async def main():
 root=Path(__file__).resolve().parents[1];folder=root/'artifacts/sessions-access-20260915';guard=folder/'fish.started';target=folder/'fish.json'
 folder.mkdir(parents=True,exist_ok=True)
 if guard.exists() or target.exists():raise RuntimeError('Fish session already attempted; no retry')
 secrets=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 config={'model':'s2.1-pro-free','voice':'9a9cf47702da476aa4629e2506d4a857','language':'auto','format':'pcm','sample_rate':24000,'chunk_length':100,'latency':'normal'}
 actions=[{'at_ms':0,'type':'text','text':'नमस्ते, आपकी बैठक कल है।'},{'at_ms':500,'type':'flush'},{'at_ms':6000,'type':'text','text':' कृपया दोपहर तीन बजे का समय पक्का करें।'},{'at_ms':6500,'type':'flush'},{'at_ms':12000,'type':'end_input'}]
 assert sum(len(a.get('text','')) for a in actions)<140
 # Validate advertised free model/header and all actions before consuming the one-attempt guard.
 fish.build_session(config,{'FISH_API_KEY':secrets['FISH_API_KEY']})
 for action in actions:fish.encode_message(fish.encode_action(action,config)[0])
 guard.write_text('One authorized native session attempted; no automatic retries.\n')
 diagnostics=[]
 class ObservedConnect:
  def __init__(self,url,**kwargs):self.connection=connect(url,**kwargs)
  async def __aenter__(self):
   try:return await self.connection.__aenter__()
   except Exception as exc:
    response=getattr(exc,'response',None)
    if response is not None:diagnostics.append({'http_status':getattr(response,'status_code',None),'message':redact(getattr(response,'body',b'').decode('utf8','replace'),secrets)[:3000]})
    raise
  async def __aexit__(self,*args):return await self.connection.__aexit__(*args)
 report=await run_session('fish',config,actions,folder/'fish',seconds=18,env={'FISH_API_KEY':secrets['FISH_API_KEY']},connector=ObservedConnect)
 report['sanitized_account_diagnostics']=diagnostics;report['evaluation_language']='hi-IN';report['naturalness']='not_evaluated';report['cancel_claim']='unsupported; stop drains audio; no cancellation request made'
 audio=[e for e in report['events'] if e['event_type']=='audio_payload_received']
 text=[e for e in report['events'] if e['event_type']=='action_sent' and e['action_type']=='text']
 flush=[e for e in report['events'] if e['event_type']=='action_sent' and e['action_type']=='flush']
 report['observations']={'audio_payload_events':len(audio),'audio_before_final_text':bool(audio and len(text)==2 and audio[0]['elapsed_ms']<text[-1]['elapsed_ms']),
  'audio_after_first_flush_before_next_text':bool(audio and len(text)==2 and flush and any(flush[0]['elapsed_ms']<=e['elapsed_ms']<text[1]['elapsed_ms'] for e in audio)),
  'boundary':'received payload; no handset playout','same_socket_multiple_requests':'not_tested; chunks belong to one synthesis session',
  'flush_causality':'timing observation only; no paired no-flush control'}
 target.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),secrets)+'\n')
 print(json.dumps({'provider':'fish','model':config['model'],'status':report['status'],'error_type':report['error_type'],'audio_streams':len(report['audio']),'observations':report['observations'],'diagnostics':diagnostics}))
if __name__=='__main__':asyncio.run(main())
