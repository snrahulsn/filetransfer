"""Read-only, bounded ElevenLabs TTS history reconciliation; never retain account text/audio."""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.live_evidence import load_live_runs


def sanitize_history(history, runs):
    by_request={}
    for row in history:
        request_id=row.get('request_id')
        if request_id:
            by_request.setdefault(request_id,[]).append(row)
    matched=[];unmatched=[]
    for run in runs:
        request_id=run.get('provider_request_id')
        rows=by_request.get(request_id)
        if not rows:
            unmatched.append({'run_id':run['run_id'],'reason':'no_matching_history_request_id' if request_id else 'run_has_no_request_id'})
            continue
        if len(rows)!=1:
            unmatched.append({'run_id':run['run_id'],'reason':'multiple_history_items_share_request_id','history_item_count':len(rows)})
            continue
        row=rows[0]
        model=row.get('model_id');voice=row.get('voice_id')
        if model!=run['config'].get('model') or (voice is not None and voice!=run['config'].get('voice')):
            unmatched.append({'run_id':run['run_id'],'reason':'request_id_match_but_model_or_voice_differs',
                'run_model_id':run['config'].get('model'),'history_model_id':model,
                'run_voice_id':run['config'].get('voice'),'history_voice_id':voice,
                'model_matches':model==run['config'].get('model'),'voice_matches':voice==run['config'].get('voice')})
            continue
        before=row.get('character_count_change_from');after=row.get('character_count_change_to')
        delta=after-before if type(before) is int and type(after) is int and after>=before else None
        matched.append({'run_id':run['run_id'],'request_id':request_id,'run_status':run['status'],
            'date_unix':row.get('date_unix'),'model_id':model,'voice_id':voice,
            'voice_identity':'matched' if voice==run['config'].get('voice') else 'not_in_history',
            'character_count_counter_delta':delta,'counter_interpretation':'history_field_difference_not_invoice_currency'})
    return {'provider':'elevenlabs','boundary':'authenticated_generation_history_not_invoice',
        'matched':matched,'unmatched_runs':unmatched,'matched_count':len(matched),
        'duplicate_history_request_id_count':sum(len(v)>1 for v in by_request.values()),
        'matched_counter_delta_total':sum(x['character_count_counter_delta'] for x in matched if x['character_count_counter_delta'] is not None),
        'matched_error_run_count':sum(x['run_status']!='success' for x in matched),
        'tracked_run_count':len(runs),'money_cost_verified':False,
        'history_fields_retained':['request_id','date_unix','model_id','voice_id','character_count_counter_delta'],
        'history_fields_excluded':['text','settings','voice_name','history_item_id','audio']}


def main():
    credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    key=credentials.get('ELEVENLABS_API_KEY')
    if not key:raise SystemExit('ElevenLabs credential unavailable')
    runs,issues=load_live_runs(ROOT/'artifacts')
    if issues:raise SystemExit('Live evidence inventory issues')
    runs=[r for r in runs if r['provider']=='elevenlabs']
    # A single scoped history page is read-only. The date excludes unrelated old account generations.
    query=urlencode({'page_size':100,'date_after_unix':int(datetime(2026,9,14,tzinfo=timezone.utc).timestamp()),'source':'TTS'})
    req=Request('https://api.elevenlabs.io/v1/history?'+query,headers={'xi-api-key':key,'Accept':'application/json'})
    with urlopen(req,timeout=20) as response:
        if response.status!=200:raise SystemExit('Unexpected history HTTP status')
        body=response.read(2_000_001)
        if len(body)>2_000_000:raise SystemExit('History page exceeded 2MB')
    data=json.loads(body)
    if not isinstance(data.get('history'),list):raise SystemExit('Malformed history response')
    result=sanitize_history(data['history'],runs)
    result.update({'created_at':datetime.now(timezone.utc).isoformat(),'http_status':200,
        'history_rows_seen':len(data['history']),'has_more':data.get('has_more'),
        'history_scope':'TTS since 2026-09-14 UTC; one page only',
        'primary_spec':'https://elevenlabs.io/docs/api-reference/history/list'})
    out=ROOT/'artifacts/elevenlabs-usage-20260915/history-reconciliation.json'
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'http_status':200,'history_rows_seen':result['history_rows_seen'],
        'matched':result['matched_count'],'tracked':result['tracked_run_count'],
        'has_more':result['has_more'],'money_cost_verified':False}))


if __name__=='__main__':main()
