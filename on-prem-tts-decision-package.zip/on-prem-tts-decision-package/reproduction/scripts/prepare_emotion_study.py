"""Prepare local blinded emotion identification using saved, hash-verified WAVs."""
from pathlib import Path
import hashlib
import html
import json
import re
import sys
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
from tts_arena.quality import prepare_study
from tts_arena.emotion_listening import write_emotion_listening_page


def prepare(destination):
    snapshot=json.loads((ROOT/'ui/public/evidence/snapshot.json').read_text())
    expected={}
    manifest=json.loads((ROOT/'artifacts/emotion-pairs-20260915/manifest.json').read_text())
    for sample in manifest['samples']:
        if sample['status']=='success': expected[sample['run_id']]=sample['condition']
    pairs=json.loads((ROOT/'artifacts/feature-pairs-20260915/summary.json').read_text())['pairs']['minimax_emotion']['records']
    for row in pairs: expected[row['run_id']]=row['config']['emotion']
    steering=json.loads((ROOT/'artifacts/inworld-steering-20260915/summary.json').read_text())
    for row in steering['records']:
        instruction=row['config']['instruction'].lower()
        expected[row['run_id']]='angry' if 'angry' in instruction else 'calm'
    for row in snapshot['runs']:
        if row['provider']=='speechify' and row['scenario_id'] in ('current-neutral','current-cheerful'):
            expected[row['run_id']]=row['scenario_id'].removeprefix('current-')
        if row['provider']=='camb' and row['scenario_id'] in ('hi-calm','hi-cheerful'):
            expected[row['run_id']]=row['scenario_id'].removeprefix('hi-')
    fish=json.loads((ROOT/'artifacts/fish-emotion-20260915/summary.json').read_text())
    for row in fish['attempts']:
        if row['status']=='success':expected[row['run_id']]=row['cue']
    items=[]
    for row in snapshot['runs']:
        if row['run_id'] not in expected: continue
        audio=(ROOT/'ui/public'/row['audio_url'].lstrip('/')).resolve()
        if not audio.is_relative_to(ROOT/'ui/public/evidence/audio'):raise ValueError('Audio path outside export')
        if hashlib.sha256(audio.read_bytes()).hexdigest()!=row['listening_audio_sha256']:raise ValueError('Audio hash mismatch')
        text=html.unescape(re.sub(r'<[^>]+>|\[[^\]]+\]', '', row['text'])).strip()
        items.append(dict(id=row['run_id'],audio_file=str(audio),language=row['language'],text=text,provider=row['provider'],model=row['config']['model'],target_emotion=expected[row['run_id']]))
    if len(items)!=len(expected):raise ValueError('Missing emotion audio')
    result=prepare_study(items,destination,seed=20260915)
    (Path(destination)/'instructions.json').write_text(json.dumps({'task':'Listen without seeing vendor, model, requested emotion or control syntax. Identify perceived emotion first, then rate naturalness and text fidelity from1to5.','perceived_options':['neutral','calm','cheerful','angry','curious','excited','sad','fearful','disgusted','surprised','unclear','other'],'qualification':'Screened native-language reviewers only. No generated or staff-unqualified ratings.','limitations':'Exploratory few-text study with unequal targets. Not a fair vendor ranking. Repeat with balanced texts, targets and reviewers before selection.'},indent=2))
    result["listening_interface"]=write_emotion_listening_page(destination)
    print(json.dumps(result))
if __name__=='__main__':prepare(Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'artifacts/emotion-study-20260915/public')
