"""Pinned English Maya1 batch inference inside an already-guarded disposable GPU Pod."""
import hashlib,json,os,time,wave
from pathlib import Path

from huggingface_hub import snapshot_download
from tts_arena.adapters.maya_local import CODEC,PROFILES,synthesize_local,verify_snapshot

MODEL='maya-research/maya1'
LANGUAGE='en-IN'
DESCRIPTION='Indian English male, conversational, warm baritone, clear diction and natural call-centre pacing'
TEXT='Hello. Your meeting is tomorrow afternoon. Please confirm the time.'

def provision(model_id):
 profile=PROFILES[model_id]
 return snapshot_download(repo_id=model_id,revision=profile['revision'],allow_patterns=sorted(profile['files']),max_workers=2,local_files_only=False)

def main():
 output_dir=Path(os.environ.get('ARENA_OUTPUT_DIR','/workspace/arena-output'))
 if (output_dir/'maya1-en-IN.wav').exists():raise RuntimeError('Maya1 smoke already has an output; no overwrite')
 output_dir.mkdir(parents=True,exist_ok=True)
 started=time.time()
 model_path=provision(MODEL);codec_path=provision(CODEC)
 verify_snapshot(model_path,PROFILES[MODEL]);verify_snapshot(codec_path,PROFILES[CODEC])
 config={'model':MODEL,'model_revision':PROFILES[MODEL]['revision'],'model_path':model_path,'codec_revision':PROFILES[CODEC]['revision'],'codec_path':codec_path,'device':'cuda','dtype':'float16','format':'pcm_s16le','language':LANGUAGE,'description':DESCRIPTION,'max_new_tokens':1024,'temperature':0.4,'top_p':0.9,'repetition_penalty':1.1,'seed':42,'memory_budget_gib':20}
 result=synthesize_local(TEXT,config)
 audio=result.pop('audio')
 wav=output_dir/'maya1-en-IN.wav'
 with wave.open(str(wav),'wb') as stream:
  stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(result['sample_rate']);stream.writeframes(audio)
 result.update({'evidence_class':'local_model_execution','status':'success','certification':'batch_inference_observed_quality_not_certified','model':MODEL,'language':LANGUAGE,'description':DESCRIPTION,'text':TEXT,'audio_file':wav.name,'audio_bytes':len(audio),'audio_sha256':hashlib.sha256(wav.read_bytes()).hexdigest(),'wall_seconds_including_provisioning':time.time()-started})
 (output_dir/'maya1-en-IN.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'model':MODEL,'status':'success','wav_bytes':wav.stat().st_size,'wall_seconds':round(result['wall_seconds_including_provisioning'],1)}),flush=True)

if __name__=='__main__':main()
