"""One native context, second text gated on observed first audio; no retries."""
import asyncio,json,sys,time,wave,hashlib,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from websockets.asyncio.client import connect
from tts_arena.session_runner import run_session
from tts_arena.credentials import read_credentials,redact
from tts_arena.sessions.cartesia import encode_action,build_session
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/cartesia-incremental-20260915'

class PacedSocket:
    def __init__(self,socket,last_text,delay=.05):
        self.socket=socket;self.last_text=last_text;self.first_audio=asyncio.Event();self.delay=delay
    async def send(self,payload):
        if json.loads(payload).get('transcript')==self.last_text:
            await asyncio.wait_for(self.first_audio.wait(),timeout=10)
            await asyncio.sleep(self.delay)
        await self.socket.send(payload)
    async def __aiter__(self):
        async for raw in self.socket:
            yield raw  # The runner journals/decodes this frame before the gate opens.
            value=json.loads(raw)
            if value.get('type')=='chunk' and value.get('data'):self.first_audio.set()

async def main():
    if OUT.exists():raise RuntimeError('This one-session probe already started')
    if shutil.disk_usage(ROOT).free<500*1024*1024:raise OSError('500MiB free required')
    credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    config={'model':'sonic-3.6','voice':'4459a9a5-69d6-4680-b970-e13dc51845b6','language':'hi-IN','format':'raw','encoding':'pcm_s16le','sample_rate':24000,'max_buffer_delay_ms':0,'add_timestamps':True}
    first='नमस्ते, आपकी बैठक कल दोपहर तीन बजे निर्धारित है। कृपया अपना नाम और बैठक का समय ध्यान से जाँच लें। मैं आपकी जानकारी समझा रहा हूँ ताकि आपको आगे की प्रक्रिया में कोई कठिनाई न हो। '
    last='अगर यह समय ठीक है, तो कृपया अपनी सहमति बताइए। धन्यवाद।'
    actions=[{'at_ms':0,'type':'text','context_id':'paced-hindi','text':first},
             {'at_ms':100,'type':'text','context_id':'paced-hindi','text':last},
             {'at_ms':101,'type':'end_input','context_id':'paced-hindi'}]
    assert len(first+last)<=300
    build_session(config,{'CARTESIA_API_KEY':credentials['CARTESIA_API_KEY']})
    messages=[m for action in actions for m in encode_action(action,config)]
    OUT.mkdir(exist_ok=False)
    plan={'provider':'cartesia','model':'sonic-3.6','language':'hi-IN','config':config,'actions':actions,'exact_messages':messages,
          'schedule':'First text at0ms; final text no earlier than100ms and50ms after the first audio frame has been journaled; end_input immediately afterward. At_ms values are lower bounds; actual sends recorded in events.',
          'bounds':{'characters':len(first+last),'session_seconds':20,'overall_seconds':30,'automatic_retries':0},
          'scope':'Incremental input ordering only; no flush causality, barge-in, continuous generation or perceptual quality claim',
          'sources':['https://docs.cartesia.ai/use-the-api/tts-websocket/contexts','https://docs.cartesia.ai/build-with-cartesia/capability-guides/stream-inputs-using-continuations']}
    (OUT/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    class Connector:
        def __init__(self,url,**kwargs):self.context=connect(url,**kwargs)
        async def __aenter__(self):return PacedSocket(await self.context.__aenter__(),last)
        async def __aexit__(self,*args):return await self.context.__aexit__(*args)
    try:
        result=await asyncio.wait_for(run_session('cartesia',config,actions,OUT/'runs',seconds=20,connector=Connector,env={'CARTESIA_API_KEY':credentials['CARTESIA_API_KEY']}),timeout=30)
        audio=[e for e in result['events'] if e['event_type']=='audio_payload_received']
        sent=[e for e in result['events'] if e['event_type']=='action_sent' and e['action_type']=='text']
        done=[e for e in result['events'] if e['event_type']=='provider_event' and e.get('details',{}).get('type')=='done']
        good=(result['status']=='observed' and len(sent)==2 and bool(audio) and audio[0]['sequence']<sent[1]['sequence'] and bool(done)
              and all(e['context_id']=='paced-hindi' for e in audio) and done[-1]['details'].get('context_id')=='paced-hindi')
        summary={'provider':'cartesia','model':'sonic-3.6','result_file':result['result_file'],'qualification':'observed_first_audio_before_final_text_same_context' if good else 'inconclusive',
                 'first_audio_ms':audio[0]['elapsed_ms'] if audio else None,'final_text_sent_ms':sent[1]['elapsed_ms'] if len(sent)>1 else None,
                 'done_events':len(done),'session_status':result['status'],'error_type':result['error_type'],'scope':plan['scope']}
        if result.get('audio'):
            folder=Path(result['result_file']).parent;raw=folder/result['audio'][0]['path'];data=raw.read_bytes()
            assert hashlib.sha256(data).hexdigest()==result['audio'][0]['sha256']
            with wave.open(str(OUT/'listen.wav'),'wb') as wav:wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(24000);wav.writeframes(data)
            summary.update(audio_bytes=len(data),audio_seconds=len(data)/48000)
    except asyncio.TimeoutError:
        summary={'provider':'cartesia','model':'sonic-3.6','qualification':'inconclusive','reason':'30-second overall bound; partial journals retained; no retry'}
    (OUT/'summary.json').write_text(redact(json.dumps(summary,ensure_ascii=False,indent=2),credentials)+'\n')
    print(json.dumps(summary))

if __name__=='__main__':asyncio.run(main())
