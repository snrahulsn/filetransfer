"""Bounded Qwen3-TTS Base voice-cloning evaluation for a disposable GPU host.

No credentials are required by this runner. Model weights are public. The caller
must supply a reference WAV and its exact transcript.
"""
from __future__ import annotations

import argparse
import json
import platform
import subprocess
import time
from pathlib import Path

import soundfile as sf
import torch
from qwen_tts import Qwen3TTSModel


MODEL_ID = "Qwen/Qwen3-TTS-12Hz-1.7B-Base"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--reference-text", required=True)
    parser.add_argument("--text", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--max-new-tokens", type=int, default=2048)
    args = parser.parse_args()

    if not args.reference.is_file():
        raise FileNotFoundError(args.reference)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.parent.mkdir(parents=True, exist_ok=True)

    load_started = time.perf_counter()
    model = Qwen3TTSModel.from_pretrained(
        MODEL_ID,
        device_map="cuda:0",
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    )
    load_seconds = time.perf_counter() - load_started

    torch.cuda.synchronize()
    synth_started = time.perf_counter()
    wavs, sample_rate = model.generate_voice_clone(
        text=args.text,
        language="English",
        ref_audio=str(args.reference),
        ref_text=args.reference_text,
        non_streaming_mode=True,
        max_new_tokens=args.max_new_tokens,
    )
    torch.cuda.synchronize()
    synthesis_seconds = time.perf_counter() - synth_started
    sf.write(args.output, wavs[0], sample_rate)
    audio, sample_rate = sf.read(args.output)
    duration_seconds = len(audio) / sample_rate

    try:
        revision = subprocess.check_output(
            ["git", "ls-remote", "https://github.com/QwenLM/Qwen3-TTS.git", "HEAD"],
            text=True,
            timeout=30,
        ).split()[0]
    except Exception:
        revision = None
    metadata = {
        "model": MODEL_ID,
        "model_type": "Base voice clone",
        "language_argument": "English",
        "target_locale": "en-IN",
        "target_text": args.text,
        "reference_text": args.reference_text,
        "reference_audio_filename": args.reference.name,
        "reference_scope": "synthetic Indian-English reference; functional clone test, not native accent certification",
        "output_filename": args.output.name,
        "sample_rate_hz": sample_rate,
        "duration_seconds": duration_seconds,
        "model_load_seconds": load_seconds,
        "synthesis_seconds": synthesis_seconds,
        "realtime_factor": synthesis_seconds / duration_seconds,
        "streaming_requested": False,
        "streaming_measured": False,
        "barge_in_measured": False,
        "torch_version": torch.__version__,
        "cuda_device": torch.cuda.get_device_name(0),
        "python": platform.python_version(),
        "qwen_repository_head_at_run": revision,
    }
    args.metadata.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
