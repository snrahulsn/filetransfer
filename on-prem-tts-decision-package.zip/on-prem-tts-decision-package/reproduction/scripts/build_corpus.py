"""Reproducible draft fixtures. These are NOT native-reviewed evaluation ground truth."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
sentences={
 "en-IN":["Your instalment is ₹15,000, payable on 15 September.","Please read the digits separately: 0 7 1 9 4 2.","The delivery address is Flat 12, M G Road, Bengaluru.","Your UPI payment is pending. Please check the OTP.","No, I said fifty thousand, not fifteen thousand.","Yes, please continue."],
 "hi-IN":["आपकी किस्त ₹15,000 है और भुगतान 15 सितंबर को करना है।","अंकों को अलग-अलग पढ़ें: 0 7 1 9 4 2।","पता है: फ्लैट 12, एम जी रोड, बेंगलुरु।","आपका UPI भुगतान लंबित है। कृपया OTP जाँचें।","नहीं, मैंने पचास हज़ार कहा था, पंद्रह हज़ार नहीं।","हाँ, आप आगे बोलिए।"],
 "bn-IN":["আপনার কিস্তির পরিমাণ ₹15,000।","সংখ্যাগুলি আলাদা করে পড়ুন: 0 7 1 9 4 2।","ঠিকানা: ফ্ল্যাট 12, এম জি রোড, কলকাতা।","আপনার UPI পেমেন্ট বাকি আছে।","না, আমি পঞ্চাশ হাজার বলেছি।","হ্যাঁ, বলুন।"],
 "mr-IN":["तुमच्या हप्त्याची रक्कम ₹15,000 आहे.","हे अंक वेगवेगळे वाचा: 0 7 1 9 4 2.","पत्ता: फ्लॅट 12, एम जी रोड, पुणे.","तुमचे UPI पेमेंट प्रलंबित आहे.","नाही, मी पन्नास हजार म्हटले होते.","हो, पुढे बोला."],
 "te-IN":["మీ వాయిదా మొత్తం ₹15,000.","అంకెలను విడివిడిగా చదవండి: 0 7 1 9 4 2.","చిరునామా: ఫ్లాట్ 12, ఎం జీ రోడ్, హైదరాబాద్.","మీ UPI చెల్లింపు పెండింగ్‌లో ఉంది.","కాదు, నేను యాభై వేలు అన్నాను.","అవును, చెప్పండి."],
 "ta-IN":["உங்கள் தவணைத் தொகை ₹15,000.","எண்களைத் தனித்தனியாகப் படிக்கவும்: 0 7 1 9 4 2.","முகவரி: பிளாட் 12, எம் ஜி சாலை, சென்னை.","உங்கள் UPI கட்டணம் நிலுவையில் உள்ளது.","இல்லை, நான் ஐம்பதாயிரம் என்றேன்.","ஆம், சொல்லுங்கள்."],
 "gu-IN":["તમારા હપ્તાની રકમ ₹15,000 છે.","આ અંકો અલગ અલગ વાંચો: 0 7 1 9 4 2.","સરનામું: ફ્લેટ 12, એમ જી રોડ, અમદાવાદ.","તમારું UPI પેમેન્ટ બાકી છે.","ના, મેં પચાસ હજાર કહ્યું હતું.","હા, આગળ બોલો."],
 "ur-IN":["آپ کی قسط کی رقم ₹15,000 ہے۔","یہ ہندسے الگ الگ پڑھیں: 0 7 1 9 4 2۔","پتہ: فلیٹ 12، ایم جی روڈ، حیدرآباد۔","آپ کی UPI ادائیگی باقی ہے۔","نہیں، میں نے پچاس ہزار کہا تھا۔","جی، بات جاری رکھیں۔"],
 "kn-IN":["ನಿಮ್ಮ ಕಂತಿನ ಮೊತ್ತ ₹15,000.","ಅಂಕೆಗಳನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ಓದಿ: 0 7 1 9 4 2.","ವಿಳಾಸ: ಫ್ಲಾಟ್ 12, ಎಂ ಜಿ ರಸ್ತೆ, ಬೆಂಗಳೂರು.","ನಿಮ್ಮ UPI ಪಾವತಿ ಬಾಕಿ ಇದೆ.","ಇಲ್ಲ, ನಾನು ಐವತ್ತು ಸಾವಿರ ಎಂದೆ.","ಹೌದು, ಮುಂದುವರಿಸಿ."],
 "ml-IN":["നിങ്ങളുടെ തവണത്തുക ₹15,000 ആണ്.","അക്കങ്ങൾ വേർതിരിച്ച് വായിക്കുക: 0 7 1 9 4 2.","വിലാസം: ഫ്ലാറ്റ് 12, എം ജി റോഡ്, കൊച്ചി.","നിങ്ങളുടെ UPI പേയ്മെന്റ് തീർപ്പായിട്ടില്ല.","അല്ല, ഞാൻ അമ്പതിനായിരം എന്നാണ് പറഞ്ഞത്.","അതെ, തുടരൂ."]}
categories=["amount_date","digits","address","code_switch","correction","acknowledgement"]
rows=[]
for locale,texts in sentences.items():
    for i,text in enumerate(texts):
        row={"id":f"{locale}-{categories[i]}-001","language":locale,"stratum":"native_script" if locale!="en-IN" else "indian_english",
             "category":categories[i],"domain":"payments_delivery","text":text,"native_review":"pending",
             "provenance":"synthetic_engineering_draft","expected_entities":[],"caller_audio":None}
        if i==0: row["expected_entities"]=[{"type":"amount","value":"15000","currency":"INR"}]
        if i==1: row["expected_entities"]=[{"type":"digit_sequence","value":"071942"}]
        if i==4: row.update(expected_entities=[{"type":"corrected_amount","value":"50000"}],expected_interrupt=True)
        if i==5: row["expected_interrupt"]=False
        rows.append(row)
for stratum,texts in {
 "romanized_hindi":["Aapki kist pandrah hazaar rupaye hai.","Nahin, maine pachaas hazaar kaha tha.","Haan, aap aage boliye.","Mera pata flat baarah, MG Road, Bengaluru hai."],
 "hinglish":["Meri EMI fifteen thousand hai, payment kal karunga.","Nahin, amount fifty thousand hai, fifteen thousand nahin.","Haan, please continue.","OTP ke digits individually boliye: zero seven one nine four two."]}.items():
    for i,text in enumerate(texts):
        rows.append({"id":f"hi-IN-{stratum}-{i+1:03}","language":"hi-IN","stratum":stratum,"category":["amount","correction","acknowledgement","digits_address"][i],"text":text,"native_review":"pending","provenance":"synthetic_engineering_draft","expected_entities":[],"caller_audio":None})
target=ROOT/"corpus";target.mkdir(exist_ok=True)
(target/"seed.jsonl").write_text("\n".join(json.dumps(r,ensure_ascii=False) for r in rows)+"\n")
(target/"README.md").write_text(f"# Draft language fixtures\n\n{len(rows)} engineering fixtures across ten locales, plus explicit Hindi script strata. All are **pending native review**. They are not a statistically powered corpus, a set of recorded native callers, or validated pronunciation ground truth. Fictional example addresses are used.\n\nReview text, pronunciations, entity labels and contextual interruption intent before using scores for provider selection. Add consented native recordings and specify accent, recording conditions and speech-onset sample. Run scripts/build_corpus.py to reproduce this draft.\n")
print(f"Wrote {len(rows)} draft fixtures; zero native-reviewed recordings.")
