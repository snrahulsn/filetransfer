"""One short, no-retry synthesis request for each supported Dubverse locale gap."""
import asyncio,json,os,sys
from datetime import datetime,timezone
from pathlib import Path
import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials,redact
from tts_arena.registry import build_request
from tts_arena.runner import run_one

RUNS=ROOT/'artifacts/runs/dubverse-locale-gap-20260915'
SUMMARY=ROOT/'artifacts/dubverse-locale-gap-20260915/summary.json'
CASES=[
 ('en-IN',184,'Your meeting is tomorrow afternoon.'),
 ('bn-IN',199,'আপনার সভা আগামীকাল দুপুরে।'),
 ('mr-IN',190,'तुमची बैठक उद्या दुपारी आहे.'),
 ('te-IN',196,'మీ సమావేశం రేపు మధ్యాహ్నం ఉంది.'),
 ('ta-IN',194,'உங்கள் கூட்டம் நாளை மதியம் உள்ளது.'),
 ('gu-IN',193,'તમારી બેઠક આવતી કાલે બપોરે છે.'),
 ('kn-IN',200,'ನಿಮ್ಮ ಸಭೆ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಇದೆ.'),
 ('ml-IN',188,'നിങ്ങളുടെ യോഗം നാളെ ഉച്ചയ്ക്കാണ്.'),
]

async def main():
 if RUNS.exists() or SUMMARY.exists():raise RuntimeError('Dubverse locale pass already attempted; no automatic repeat')
 secret=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('DUBVERSE_API_KEY')
 if not secret:raise RuntimeError('Authorized Dubverse key absent')
 plans=[]
 for locale,voice,text in CASES:
  config={'model':'neo.one','voice':voice,'language':locale,'format':'wav','sample_rate':22050}
  spec=build_request('dubverse',text,config,{'DUBVERSE_API_KEY':secret})
  if len(text)>90 or spec.url!='https://audio.dubverse.ai/api/tts':raise ValueError('Bounded request condition failed')
  plans.append((locale,config,text))
 RUNS.mkdir(parents=True);SUMMARY.parent.mkdir(parents=True)
 report={'provider':'dubverse','created_at':datetime.now(timezone.utc).isoformat(),'request_cap':len(CASES),'planned':len(plans),'automatic_retries':0,'scope':'One short fictional text and fixed neo.one voice per locale; audio delivery only, without native quality inference','results':[]}
 def save():SUMMARY.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2)+'\n',{'DUBVERSE_API_KEY':secret}))
 save();os.environ['DUBVERSE_API_KEY']=secret
 try:
  for index,(locale,config,text) in enumerate(plans):
   if index:await asyncio.sleep(2)
   row={'locale':locale,'model':config['model'],'voice':config['voice'],'status':'request_started'}
   report['results'].append(row);save()
   async with httpx.AsyncClient(timeout=45,trust_env=False,follow_redirects=False) as client:
    result=await run_one('dubverse',text,config,RUNS,timeout=45,client=client,scenario_id='dubverse-locale-gap',evaluation_language=locale,stratum='regional_audio_delivery',min_free_bytes=300*1024*1024)
   row.update({k:result.get(k) for k in ('run_id','status','http_status','error_type','audio_bytes','audio_sha256','duration_seconds')});save()
   print(locale,result['status'],result.get('http_status'),flush=True)
 finally:os.environ.pop('DUBVERSE_API_KEY',None)
 report['complete']=True;save()

if __name__=='__main__':asyncio.run(main())
