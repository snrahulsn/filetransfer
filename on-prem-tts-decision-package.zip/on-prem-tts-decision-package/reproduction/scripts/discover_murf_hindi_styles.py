"""One authenticated, read-only Falcon 2 voice catalog check for Hindi style eligibility."""
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials

OUT = ROOT / 'artifacts/murf-hindi-style-discovery-20260916'
ENDPOINT = 'https://api.murf.ai/v1/speech/voices?model=falcon-2'


def main():
    if OUT.exists():
        raise RuntimeError('Voice discovery already attempted; no automatic repeat')
    secret = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env').get('MURF_API_KEY')
    if not secret:
        raise ValueError('Authorized Murf API key unavailable')
    OUT.mkdir(parents=True)
    (OUT / 'attempt.started').write_text('One read-only GET; zero synthesis; no retries.\n')
    try:
        with httpx.Client(timeout=12, follow_redirects=False) as client:
            response = client.get(ENDPOINT, headers={'api-key': secret})
        raw = response.content
        if len(raw) > 2_000_000:
            raise ValueError('Murf voice listing exceeds bounded capture size')
        payload = response.json() if response.status_code == 200 else None
        if payload is not None and (not isinstance(payload, list) or len(payload) > 300):
            raise ValueError('Murf voice listing schema changed')
        rows = []
        for voice in payload or []:
            locales = voice.get('supportedLocales') or {}
            if not isinstance(locales, dict):
                raise ValueError('Murf supportedLocales schema changed')
            hi = locales.get('hi-IN')
            if hi is None:
                continue
            styles = hi.get('availableStyles') or []
            if not isinstance(styles, list) or any(not isinstance(x, str) for x in styles):
                raise ValueError('Murf Hindi availableStyles schema changed')
            rows.append({'voiceId': voice.get('voiceId'), 'locale': voice.get('locale'),
                         'displayName': voice.get('displayName'), 'hindi_styles': styles,
                         'supported_locale_detail': hi.get('detail')})
        report = {'provider': 'murf', 'model': 'falcon-2', 'endpoint': ENDPOINT,
                  'observed_at': datetime.now(timezone.utc).isoformat(),
                  'http_status': response.status_code, 'raw_response_sha256': hashlib.sha256(raw).hexdigest(),
                  'voice_count': len(payload or []), 'hindi_voice_count': len(rows),
                  'hindi_styles': rows, 'synthesis_requests': 0, 'retries': 0,
                  'source': 'https://murf.ai/api/docs/api-reference/voices/get-voices'}
        (OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps({'http_status': report['http_status'], 'voice_count': report['voice_count'],
                          'hindi_voice_count': report['hindi_voice_count'],
                          'voices_with_multiple_hindi_styles': sum(len(v['hindi_styles']) > 1 for v in rows)}))
    except Exception as exc:
        (OUT / 'error.json').write_text(json.dumps({'error_type': type(exc).__name__,
                                                    'synthesis_requests': 0, 'retries': 0}) + '\n')
        raise


if __name__ == '__main__':
    main()
