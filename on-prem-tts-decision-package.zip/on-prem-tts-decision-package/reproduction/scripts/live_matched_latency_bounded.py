"""Bounded repeated Hindi first-playable-PCM observations for two current routes."""
import argparse
import asyncio
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.registry import build_request, code_digest
from tts_arena.runner import run_one

OUT=ROOT/'artifacts/latency-matched-20260915-v1'
TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
PLANS={
 'cartesia':{'credential':'CARTESIA_API_KEY','config':{'model':'sonic-3.6','voice':'4459a9a5-69d6-4680-b970-e13dc51845b6','language':'hi-IN','format':'raw','encoding':'pcm_s16le','sample_rate':24000}},
 'elevenlabs':{'credential':'ELEVENLABS_API_KEY','config':{'model':'eleven_v3','voice':'hpp4J3VqNfWAUOO0d1Us','language':'hi-IN','format':'pcm_24000'}}
}
REPETITIONS=8

def plan(credentials):
 for provider,entry in PLANS.items():
  key=credentials.get(entry['credential'])
  if not key:raise ValueError(entry['credential']+' unavailable')
  spec=build_request(provider,TEXT,entry['config'],{entry['credential']:key})
  if spec.sample_rate!=24000 or spec.encoding not in {'pcm_s16le','pcm_24000'} or spec.response_mode!='binary':
   raise ValueError(provider+' route is not 24 kHz binary PCM16')
 return {'schema':'matched_hindi_first_playable_pcm_v1','created_at':datetime.now(timezone.utc).isoformat(),
  'source_code_sha256':code_digest(),'text_sha256':hashlib.sha256(TEXT.encode()).hexdigest(),
  'language':'hi-IN','client_policy':'one macOS host; trust_env false; no proxy; fresh TCP/TLS per request; sequential alternating provider order',
  'server_region':'not_observed','region_qualification':'client location and vendor serving region not independently verified',
  'audio_condition':'provider-native output PCM16 24 kHz, raw or decoded from binary PCM; no resampling',
  'latency_clock':'run_one request start to first complete playable PCM frame on client; includes network and transport',
  'repetitions_per_provider':REPETITIONS,'max_requests':REPETITIONS*len(PLANS),'automatic_retries':0,
  'pause_between_requests_seconds':0.7,'provider_order':list(PLANS),
  'transcript':TEXT,'providers':{p:{'config':v['config'],'attempts':0,'successes':0,'stopped':False} for p,v in PLANS.items()},
  'attempts_total':0,'results':[],'status':'planned','quality_certification':False,'cost_reconciled':False}

async def run_live():
 if OUT.exists():raise RuntimeError('Existing latency trial; no repeat spending')
 if shutil.disk_usage(ROOT).free<300*1024*1024:raise OSError('Evidence disk floor not met')
 credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 manifest=plan(credentials)
 OUT.mkdir(parents=True,exist_ok=False)
 def save():
  temporary=OUT/'manifest.json.partial'
  temporary.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
  os.replace(temporary,OUT/'manifest.json')
 save()
 for provider,entry in PLANS.items():os.environ[entry['credential']]=credentials[entry['credential']]
 try:
  limits=httpx.Limits(max_connections=1,max_keepalive_connections=0)
  async with httpx.AsyncClient(timeout=30,limits=limits,trust_env=False,follow_redirects=False) as client:
   manifest['status']='running';save()
   for ordinal in range(REPETITIONS):
    for provider,entry in PLANS.items():
     if manifest['providers'][provider]['stopped']:continue
     manifest['attempts_total']+=1;manifest['providers'][provider]['attempts']+=1;save()
     result=await run_one(provider,TEXT,entry['config'],OUT/'runs'/provider,timeout=30,client=client,
      scenario_id=f'hindi-latency-{ordinal+1:02d}',evaluation_language='hi-IN',stratum='matched_first_playable_pcm',min_free_bytes=300*1024*1024)
     row={k:result.get(k) for k in ('run_id','status','http_status','error_type','first_byte_ms','first_payload_ms','first_audio_ms','elapsed_ms','audio_sha256','audio_bytes','duration_seconds')}
     row.update(provider=provider,ordinal=ordinal+1,model=entry['config']['model'],voice=entry['config']['voice'],
      config=entry['config'],text_sha256=manifest['text_sha256'],source_result=str((OUT/'runs'/provider/result['run_id']/'result.json').relative_to(ROOT)))
     manifest['results'].append(row)
     if result['status']=='success' and result.get('first_audio_ms') is not None and result.get('audio_bytes',0)>0:
      manifest['providers'][provider]['successes']+=1
     else:
      manifest['providers'][provider]['stopped']=True
     save()
     if manifest['providers'][provider]['stopped']:
      manifest['status']='stopped_on_failure';save();return manifest
     await asyncio.sleep(.7)
   manifest['status']='complete';save()
 finally:
  for entry in PLANS.values():os.environ.pop(entry['credential'],None)
 return manifest

if __name__=='__main__':
 parser=argparse.ArgumentParser()
 parser.add_argument('--live',action='store_true')
 args=parser.parse_args()
 credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 if args.live:
  observed=asyncio.run(run_live())
  print(json.dumps({'status':observed['status'],'attempts':observed['attempts_total'],
   'successes':{p:v['successes'] for p,v in observed['providers'].items()}}))
 else:
  planned=plan(credentials)
  print(json.dumps({'status':'preflight_passed','max_requests':planned['max_requests'],
   'providers':list(planned['providers']),'audio_condition':planned['audio_condition']}))
