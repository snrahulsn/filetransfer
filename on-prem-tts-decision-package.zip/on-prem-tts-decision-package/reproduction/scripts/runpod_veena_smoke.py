"""One pinned Veena Hindi inference on an ephemeral Runpod CUDA Pod.

Run only in a disposable GPU Pod. This script neither provisions nor deletes Pods.
"""
import argparse
import json
import os
import time
import wave
from pathlib import Path

from huggingface_hub import snapshot_download
from tts_arena.adapters.maya_local import CODEC, PROFILES, synthesize_local, verify_snapshot


def provision(model_id: str) -> str:
    profile = PROFILES[model_id]
    return snapshot_download(
        repo_id=model_id,
        revision=profile["revision"],
        allow_patterns=sorted(profile["files"]),
        max_workers=2,
        local_files_only=False,
    )


CASES = {
    "hi": ("hi-IN", "kavya", "नमस्ते। आपकी कॉल के लिए धन्यवाद।"),
    "en": ("en-IN", "agastya", "Hello. Thank you for calling. How may I help?"),
    "mixed": ("hi-en", "maitri", "नमस्ते। आपका order तैयार है।"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=sorted(CASES), default="hi")
    args = parser.parse_args()
    language, voice, text = CASES[args.case]
    output_dir = Path(os.environ.get("ARENA_OUTPUT_DIR", "/workspace/arena-output"))
    output_dir.mkdir(parents=True, exist_ok=True)
    started = time.time()
    model_id = "maya-research/Veena"
    model_path = provision(model_id)
    codec_path = provision(CODEC)
    verify_snapshot(model_path, PROFILES[model_id])
    verify_snapshot(codec_path, PROFILES[CODEC])
    config = {
        "model": model_id,
        "model_revision": PROFILES[model_id]["revision"],
        "model_path": model_path,
        "codec_revision": PROFILES[CODEC]["revision"],
        "codec_path": codec_path,
        "device": "cuda",
        "dtype": "float16",
        "format": "pcm_s16le",
        "language": language,
        "voice": voice,
        "max_new_tokens": 256,
        "temperature": 0.4,
        "top_p": 0.9,
        "repetition_penalty": 1.05,
        "seed": 42,
        "memory_budget_gib": 20,
    }
    result = synthesize_local(text, config)
    audio = result.pop("audio")
    result["certification"] = "live_inference_observed_quality_not_certified"
    stem = f"veena-{language}-{voice}"
    wav_path = output_dir / (stem + ".wav")
    with wave.open(str(wav_path), "wb") as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(result["sample_rate"])
        stream.writeframes(audio)
    result.update({
        "model": model_id,
        "language": language,
        "voice": voice,
        "text": text,
        "audio_file": wav_path.name,
        "audio_bytes": len(audio),
        "wall_seconds_including_provisioning": time.time() - started,
    })
    (output_dir / (stem + ".json")).write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
