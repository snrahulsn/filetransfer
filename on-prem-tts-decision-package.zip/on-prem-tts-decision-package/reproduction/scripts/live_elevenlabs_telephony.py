"""One bounded Hindi G.711 output request on the current Eleven v3 route."""
import asyncio
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.runner import run_one

OUT = ROOT / 'artifacts/elevenlabs-telephony-20260916'
TEXT = 'नमस्ते, आपकी सहायता के लिए मैं अभी उपलब्ध हूँ।'
CONFIG = {'model': 'eleven_v3', 'voice': 'hpp4J3VqNfWAUOO0d1Us',
          'language': 'hi-IN', 'format': 'ulaw_8000'}

async def main():
    if OUT.exists():
        raise RuntimeError('Evidence directory already exists; refusing a duplicate billed request')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    if not credentials.get('ELEVENLABS_API_KEY'):
        raise ValueError('ElevenLabs credential unavailable')
    os.environ['ELEVENLABS_API_KEY'] = credentials['ELEVENLABS_API_KEY']
    try:
        result = await run_one('elevenlabs', TEXT, CONFIG, OUT / 'runs', timeout=30,
                               scenario_id='hindi-v3-native-mulaw-8000',
                               evaluation_language='hi-IN', stratum='single_feature_probe')
    finally:
        os.environ.pop('ELEVENLABS_API_KEY', None)
    manifest = {'schema': 'elevenlabs_telephony_single_v1', 'provider': 'elevenlabs',
                'model': CONFIG['model'], 'language': CONFIG['language'],
                'format': CONFIG['format'], 'config': CONFIG, 'text': TEXT,
                'max_requests': 1, 'automatic_retries': 0,
                'vendor_spec_url': 'https://elevenlabs.io/docs/api-reference/text-to-speech/stream',
                'source_result': str((OUT / 'runs' / result['run_id'] / 'result.json').relative_to(ROOT)),
                'run_id': result['run_id'], 'status': result['status'],
                'http_status': result.get('http_status'),
                'quality_certification': False, 'production_telephony_verified': False}
    OUT.mkdir(exist_ok=True)
    (OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: manifest[k] for k in ('run_id', 'status', 'http_status')}, ensure_ascii=False))

if __name__ == '__main__':
    asyncio.run(main())
