"""Capped, balanced Fish REST versus timestamp WebSocket Hindi PCM trial."""
import argparse
import asyncio
import base64
import hashlib
import json
import os
import shutil
import sys
import time
import wave
from datetime import datetime, timezone
from pathlib import Path

import httpx
import msgpack
from websockets.asyncio.client import connect

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from live_matched_latency_bounded import TEXT
from live_matched_latency_balanced import egress_country
from tts_arena.credentials import read_credentials
from tts_arena.registry import build_request, code_digest
from tts_arena.runner import run_one
from tts_arena.sessions import fish

OUT = ROOT / 'artifacts/fish-transport-latency-20260916'
ROUNDS = 12
ROUTES = ('rest', 'websocket')
ORDER = [list(ROUTES) if i % 2 == 0 else list(reversed(ROUTES)) for i in range(ROUNDS)]
CONFIG = {'model': 's2.1-pro-free', 'voice': '9a9cf47702da476aa4629e2506d4a857',
          'language': 'auto', 'format': 'pcm', 'sample_rate': 24000,
          'chunk_length': 100, 'latency': 'normal'}


def preflight(credentials):
    env = {'FISH_API_KEY': credentials.get('FISH_API_KEY', '')}
    rest = build_request('fish', TEXT, CONFIG, env)
    socket = fish.build_session({**CONFIG, 'timestamp_mode': True}, env)
    if (rest.sample_rate != socket.sample_rate or rest.sample_rate != 24000
        or rest.encoding != socket.encoding or rest.encoding != 'pcm_s16le'
        or rest.url != 'https://api.fish.audio/v1/tts'
        or socket.url != 'wss://api.fish.audio/v1/tts/live/with-timestamp'):
        raise ValueError('Fish route/audio contract mismatch')
    return {'schema': 'fish_balanced_rest_vs_timestamp_websocket_pcm_v1',
            'created_at': datetime.now(timezone.utc).isoformat(),
            'source_code_sha256': code_digest(), 'transcript': TEXT,
            'text_sha256': hashlib.sha256(TEXT.encode()).hexdigest(),
            'language': 'hi-IN', 'config': CONFIG, 'order': ORDER,
            'repetitions_per_route': ROUNDS, 'max_vendor_requests': 2 * ROUNDS,
            'automatic_retries': 0, 'attempts_total': 0, 'results': [],
            'successful': {'rest': 0, 'websocket': 0}, 'status': 'planned',
            'audio_condition': 'provider-native mono PCM16 at 24 kHz; no resampling',
            'latency_boundary': 'client request/connect start to first complete received PCM frame',
            'client_policy': 'one macOS host; no proxy; fresh TCP/TLS per route request; sequential 0.7-second pacing',
            'client_egress_country_start': None, 'client_egress_country_end': None,
            'country_probe': 'Cloudflare trace loc with trust_env=False before and after',
            'provider_serving_region': 'Fish deployed route; not independently pinned',
            'quality_certification': False, 'cost_reconciled': False,
            'production_playout_verified': False}


async def socket_request(key, ordinal):
    directory = OUT / 'websocket' / f'{ordinal:02d}'
    directory.mkdir(parents=True, exist_ok=False)
    spec = fish.build_session({**CONFIG, 'timestamp_mode': True}, {'FISH_API_KEY': key})
    started = time.perf_counter_ns()
    audio = bytearray()
    first_audio_ms = None
    terminal = False
    frame_rows = []
    sent = []
    async with connect(spec.url, additional_headers=spec.headers, proxy=None,
                       open_timeout=8, max_size=2_000_000) as ws:
        for message in [*spec.initial_messages, {'event': 'text', 'text': TEXT},
                        {'event': 'flush'}, {'event': 'stop'}]:
            await ws.send(fish.encode_message(message))
            sent.append({'event': message['event'], 'elapsed_ms': (time.perf_counter_ns() - started) / 1e6})
        async with asyncio.timeout(14):
            async for raw in ws:
                if not isinstance(raw, bytes):
                    raise ValueError('Fish WebSocket unexpectedly returned a text frame')
                elapsed = (time.perf_counter_ns() - started) / 1e6
                frame_rows.append({'type': 'binary', 'elapsed_ms': elapsed,
                                   'base64': base64.b64encode(raw).decode()})
                packet = msgpack.unpackb(raw, raw=False, strict_map_key=True)
                decoded = fish.decode_message(raw)
                if packet.get('event') == 'audio':
                    for event in decoded:
                        if event['type'] == 'audio' and event['audio']:
                            if first_audio_ms is None:
                                first_audio_ms = elapsed
                            audio.extend(event['audio'])
                elif packet.get('event') == 'finish':
                    if packet.get('reason') != 'stop':
                        raise ValueError('Fish WebSocket did not finish after Stop')
                    terminal = True
                    break
    (directory / 'frames.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in frame_rows))
    if not terminal or first_audio_ms is None or len(audio) < 2 or len(audio) % 2:
        raise ValueError('Fish WebSocket returned no completed playable PCM')
    pcm = directory / 'audio.pcm'
    pcm.write_bytes(audio)
    wav = directory / 'audio.wav'
    with wave.open(str(wav), 'wb') as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(24000)
        stream.writeframes(audio)
    result = {'schema': 'fish_timestamp_websocket_latency_result_v1',
              'provider': 'fish', 'route': 'websocket', 'ordinal': ordinal,
              'model': CONFIG['model'], 'voice': CONFIG['voice'],
              'config': {**CONFIG, 'timestamp_mode': True}, 'text_sha256': hashlib.sha256(TEXT.encode()).hexdigest(),
              'source_code_sha256': code_digest(), 'request_start_boundary': 'before TCP/TLS WebSocket connect',
              'first_audio_boundary': 'first complete PCM16 byte pair in received MessagePack audio frame',
              'first_audio_ms': first_audio_ms, 'sent': sent,
              'terminal_observed': terminal, 'frames': len(frame_rows),
              'audio_bytes': len(audio), 'audio_sha256': hashlib.sha256(audio).hexdigest(),
              'sample_rate': 24000, 'encoding': 'pcm_s16le',
              'duration_seconds': len(audio) / 48000, 'audio_file': 'audio.pcm',
              'playable_file': 'audio.wav', 'status': 'success'}
    (directory / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return result, directory / 'result.json'


async def live():
    if OUT.exists():
        raise RuntimeError('Fish transport trial already attempted; no automatic repeat')
    if shutil.disk_usage(ROOT).free < 300 * 1024 * 1024:
        raise OSError('Evidence disk floor not met')
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    manifest = preflight(credentials)
    key = credentials['FISH_API_KEY']
    limits = httpx.Limits(max_connections=1, max_keepalive_connections=0)
    async with httpx.AsyncClient(timeout=10, limits=limits, trust_env=False) as client:
        manifest['client_egress_country_start'] = await egress_country(client)
    if manifest['client_egress_country_start'] != 'IN':
        raise RuntimeError('India client egress absent; no vendor requests')
    OUT.mkdir(parents=True, exist_ok=False)
    def save():
        temporary = OUT / 'manifest.json.partial'
        temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        os.replace(temporary, OUT / 'manifest.json')
    save()
    manifest['status'] = 'running'
    save()
    for ordinal, routes in enumerate(ORDER, 1):
        for route in routes:
            manifest['attempts_total'] += 1
            save()
            try:
                if route == 'websocket':
                    result, path = await socket_request(key, ordinal)
                    row = {'route': route, 'ordinal': ordinal, 'first_audio_ms': result['first_audio_ms'],
                           'audio_bytes': result['audio_bytes'], 'audio_sha256': result['audio_sha256'],
                           'source_result': str(path.relative_to(ROOT)), 'status': result['status']}
                else:
                    async with httpx.AsyncClient(timeout=30, limits=limits, trust_env=False,
                                                 follow_redirects=False) as client:
                        os.environ['FISH_API_KEY'] = key
                        try:
                            result = await run_one('fish', TEXT, CONFIG, OUT / 'rest', timeout=30,
                                                   client=client, scenario_id=f'fish-transport-{ordinal:02d}',
                                                   evaluation_language='hi-IN', stratum='fish_balanced_transport_latency',
                                                   min_free_bytes=300 * 1024 * 1024)
                        finally:
                            os.environ.pop('FISH_API_KEY', None)
                    path = OUT / 'rest' / result['run_id'] / 'result.json'
                    row = {k: result.get(k) for k in ('status', 'http_status', 'error_type', 'first_audio_ms',
                           'audio_bytes', 'audio_sha256', 'run_id')}
                    row.update(route=route, ordinal=ordinal, source_result=str(path.relative_to(ROOT)))
                manifest['results'].append(row)
                if row['status'] != 'success' or row.get('first_audio_ms') is None or row.get('audio_bytes', 0) < 2:
                    manifest['status'] = 'stopped_on_first_vendor_failure'
                    save()
                    return manifest
                manifest['successful'][route] += 1
                save()
            except Exception as exc:
                manifest['results'].append({'route': route, 'ordinal': ordinal, 'status': 'error',
                                            'error_type': type(exc).__name__})
                manifest['status'] = 'stopped_on_first_vendor_failure'
                save()
                return manifest
            await asyncio.sleep(.7)
    async with httpx.AsyncClient(timeout=10, limits=limits, trust_env=False) as client:
        manifest['client_egress_country_end'] = await egress_country(client)
    manifest['status'] = ('complete' if manifest['client_egress_country_end'] == 'IN'
                          else 'egress_country_changed')
    save()
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    credentials = read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
    if args.live:
        observed = asyncio.run(live())
        print(json.dumps({'status': observed['status'], 'attempts': observed['attempts_total'],
                          'successful': observed['successful'], 'egress_start': observed['client_egress_country_start'],
                          'egress_end': observed['client_egress_country_end']}))
    else:
        planned = preflight(credentials)
        print(json.dumps({'status': 'preflight_passed', 'max_vendor_requests': planned['max_vendor_requests'],
                          'routes': list(ROUTES), 'encoding': planned['audio_condition']}))
