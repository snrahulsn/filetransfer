"""Calculate transport-level acoustic diagnostics for the two Qwen WAVs."""
from __future__ import annotations

import array
import json
import math
import wave
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/runpod/qwen3-tts-20260916"


def measure(path: Path) -> dict:
    with wave.open(str(path)) as wav:
        channels, width, rate, frames = (wav.getnchannels(), wav.getsampwidth(),
                                          wav.getframerate(), wav.getnframes())
        raw = wav.readframes(frames)
    if width != 2:
        raise ValueError("Expected PCM16 WAV")
    samples = array.array("h")
    samples.frombytes(raw)
    mono = [sum(samples[i:i + channels]) / (32768 * channels)
            for i in range(0, len(samples), channels)]
    rms = math.sqrt(sum(value * value for value in mono) / len(mono))
    peak = max(abs(value) for value in mono)
    frame_size = max(1, int(rate * 0.02))
    windows = [mono[i:i + frame_size] for i in range(0, len(mono), frame_size)]
    frame_rms = [math.sqrt(sum(value * value for value in frame) / len(frame))
                 for frame in windows]
    return {
        "channels": channels, "sample_width_bytes": width, "sample_rate_hz": rate,
        "duration_seconds": frames / rate,
        "rms_dbfs": 20 * math.log10(max(rms, 1e-12)),
        "peak_dbfs": 20 * math.log10(max(peak, 1e-12)),
        "silence_frame_fraction_below_minus_50_dbfs":
            sum(value < 10 ** (-50 / 20) for value in frame_rms) / len(frame_rms),
        "clipped_sample_fraction": sum(abs(value) >= 0.999 for value in mono) / len(mono),
    }


def main() -> None:
    payload = {path.name: measure(path) for path in sorted(SOURCE.glob("*.wav"))}
    output = SOURCE / "acoustic-diagnostic.json"
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
