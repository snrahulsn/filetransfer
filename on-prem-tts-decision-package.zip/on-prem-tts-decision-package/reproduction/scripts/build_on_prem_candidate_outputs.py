"""Publish the bounded Indic Parler candidate outputs for report and UI review."""
from __future__ import annotations

import json
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "artifacts/on-prem-candidates/indic-parler"
PUBLIC_AUDIO = ROOT / "ui/public/evidence/audio"
PUBLIC_JSON = ROOT / "ui/public/evidence/on-prem-candidates.json"
DOC = ROOT / "docs/ON_PREM_CANDIDATE_OUTPUTS.md"


def build() -> dict:
    suite = json.loads((SOURCE / "suite.json").read_text())
    if suite["recording_count"] != 12 or len(set(suite["languages"])) != 12:
        raise ValueError("Indic Parler suite must contain one output for each of 12 locales")
    rows = []
    for record in suite["records"]:
        source = SOURCE / record["audio_file"]
        if not source.is_file() or source.stat().st_size != record["audio_bytes"]:
            raise ValueError(f"Missing or changed candidate audio: {source}")
        target = PUBLIC_AUDIO / source.name
        shutil.copy2(source, target)
        caption = ROOT / "ui/public/evidence/captions" / source.with_suffix(".vtt").name
        caption.write_text("WEBVTT\n\n00:00:00.000 --> 00:00:30.000\n" +
                           record["text"] + "\n", encoding="utf-8")
        rows.append({
            "language": record["language"], "text": record["text"],
            "description": record["description"], "support_note": record["support_note"],
            "duration_seconds": record["duration_seconds"],
            "audio_url": "/evidence/audio/" + target.name,
            "caption_url": "/evidence/captions/" + caption.name,
            "audio_sha256": record["audio_sha256"],
        })
    report = {
        "schema_version": 1,
        "model": "ai4bharat/indic-parler-tts",
        "route": "AI4Bharat official Hugging Face Space",
        "self_hosted_execution": False,
        "checkpoint_license": "Apache-2.0",
        "parameter_count": "0.938B F32",
        "stored_artifact_size": "3.75 GB",
        "streaming": "ParlerTTSStreamer library support; not measured in these official-Space batch calls",
        "indian_english": "Explicit publisher claim and saved en-IN review clip",
        "emotion_style": "Caption control for emotion, expressivity, pitch, speaking rate, reverberation, noise and quality",
        "voice_cloning": "No arbitrary reference-audio cloning interface",
        "recording_count": len(rows),
        "recordings": rows,
    }
    PUBLIC_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    lines = [
        "# Indic Parler-TTS candidate outputs", "",
        "Exact model: `ai4bharat/indic-parler-tts`. These clips were generated through AI4Bharat's official Hugging Face Space. They prove exact-model output availability, not our own self-hosted deployment. The checkpoint is gated; the unattended account flow reached CAPTCHA.", "",
        "Checkpoint license: **Apache-2.0**. Size: **0.938B F32 / 3.75 GB stored**. Publisher hardware minimum: **not stated**. Public examples support CUDA or CPU. ParlerTTS exposes incremental waveform streaming through `ParlerTTSStreamer`, but these 12 calls were batch and do not measure first-audio, cancellation, VRAM or concurrency.", "",
        "The model explicitly claims Indian-English accents, 20 official Indic languages, 69 voices, and caption control for emotion, rate, pitch, expressivity, reverberation, noise and quality. It does not expose arbitrary reference-audio voice cloning. Punjabi is unofficial.", "",
        "| Language | Support | Duration | Audio |", "|---|---|---:|---|",
    ]
    for row in rows:
        lines.append(f"| {row['language']} | {row['support_note']} | {row['duration_seconds']:.2f} s | [play/download](../ui/public{row['audio_url']}) |")
    lines += ["", "Use native reviewers to score naturalness, pronunciation, accent fit, intelligibility and entity fidelity. Do not treat publisher native-speaker scores as independent certification.", ""]
    DOC.write_text("\n".join(lines))
    return report


if __name__ == "__main__":
    result = build()
    print(json.dumps({"model": result["model"], "recording_count": result["recording_count"]}))
