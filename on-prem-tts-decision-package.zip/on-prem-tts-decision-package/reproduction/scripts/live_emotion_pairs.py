"""Four bounded, matched-content emotion-direction requests; no emotion accuracy claim."""
import asyncio,copy,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from tts_arena.credentials import read_credentials
from tts_arena.live_evidence import load_live_runs
from tts_arena.registry import build_request
from tts_arena.runner import run_one
OUT=ROOT/'artifacts/emotion-pairs-20260915'
TEXT='नमस्ते, आपकी बैठक कल दोपहर तीन बजे है। कृपया समय की पुष्टि करें।'
PROFILES={
 'elevenlabs':{'model':'eleven_v3','key':'ELEVENLABS_API_KEY','source':'https://elevenlabs.io/docs/help-center/product/core-capabilities/text-to-speech/how-do-audio-tags-work-with-eleven-v3-alpha','conditions':[('curious','[curious] '+TEXT,{}),('excited','[excited] '+TEXT,{})]},
 'google':{'model':'gemini-3.1-flash-tts-preview','key':'GOOGLE_API_KEY','source':'https://ai.google.dev/gemini-api/docs/speech-generation','conditions':[('calm',TEXT,{'instructions':'Read only the following Hindi text in a calm, reassuring tone. Do not read these instructions aloud.'}),('cheerful',TEXT,{'instructions':'Read only the following Hindi text in a cheerful, enthusiastic tone. Do not read these instructions aloud.'})]}}
async def main():
 if OUT.exists():raise RuntimeError('Emotion pair requests already prepared or attempted; no automatic repeat')
 credentials=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env')
 runs,issues=load_live_runs(ROOT/'artifacts')
 if issues:raise ValueError('Invalid existing evidence')
 jobs=[]
 for provider,profile in PROFILES.items():
  os.environ[profile['key']]=credentials[profile['key']]
  candidates=[r for r in runs if r['provider']==provider and r['status']=='success' and r['language']=='hi-IN' and r['config'].get('model')==profile['model']]
  config=copy.deepcopy(sorted(candidates,key=lambda r:r['created_at'])[-1]['config'])
  for name,text,controls in profile['conditions']:
   cfg={**config,**controls};build_request(provider,text,cfg);jobs.append((provider,name,text,cfg,profile['source']))
 OUT.mkdir(parents=True,exist_ok=False)
 manifest={'request_limit':4,'automatic_retries':0,'feature':'emotion','reference_text':TEXT,'scope':'Matched spoken content and fixed voice per provider; requested direction differs. Audio acceptance is not emotion accuracy.','samples':[]}
 def save():(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 blocked=set();save()
 for provider,name,text,cfg,source in jobs:
  if provider in blocked:continue
  row={'provider':provider,'condition':name,'model':cfg['model'],'config':cfg,'source':source,'source_accessed':'2026-09-15','language':'hi-IN','requested_text':text,'status':'request_started','emotion_accuracy':'requires_qualified_blind_listening'}
  manifest['samples'].append(row);save()
  r=await run_one(provider,text,cfg,OUT/'runs'/provider,timeout=35,scenario_id='emotion-'+name,evaluation_language='hi-IN',stratum='emotion_'+name)
  row.update({k:r.get(k) for k in ['run_id','status','http_status','error_type','duration_seconds','audio_sha256','audio_analysis']});row['result_path']=str((OUT/'runs'/provider/r['run_id']/'result.json').relative_to(ROOT))
  if r['status']!='success':blocked.add(provider)
  save();print(json.dumps({k:row[k] for k in ['provider','condition','status','http_status','duration_seconds']},ensure_ascii=False),flush=True)
if __name__=='__main__':asyncio.run(main())
