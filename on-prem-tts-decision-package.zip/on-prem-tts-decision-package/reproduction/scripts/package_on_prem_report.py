"""Create a credential-free, reproducible on-prem TTS decision package."""
from __future__ import annotations

import hashlib
import io
import json
import re
import shutil
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "ui/public/evidence/on-prem-report.json"
PACKAGE = ROOT / "artifacts/on-prem-report"
ZIP_PATH = ROOT / "artifacts/on-prem-tts-decision-package.zip"

# Explicit allowlist. Credential files and private blind identities are never candidates.
REPRODUCTION_FILES = (
    "IMPLEMENTATION_CONTRACT.md", "docs/SPECIFICATION.md", "pyproject.toml", "uv.lock",
    "scripts/build_on_prem_candidate_outputs.py", "scripts/build_on_prem_report.py",
    "scripts/local_kokoro_probe.py", "scripts/nvidia_build_magpie_hindi.py",
    "scripts/nvidia_nim_preflight.py", "scripts/official_indic_parler_suite.py",
    "scripts/package_on_prem_blind_review.py", "scripts/package_on_prem_report.py",
    "scripts/qualify_kokoro_local.py", "scripts/runpod_eval_pod.py",
    "scripts/runpod_maya1_smoke.py", "scripts/runpod_nim_guard.py",
    "scripts/runpod_nim_pilot.py", "scripts/runpod_nim_pod.py",
    "scripts/runpod_pod_guard.py", "scripts/runpod_veena_smoke.py",
    "tests/test_kokoro.py", "tests/test_kokoro_qualification.py",
    "tests/test_local_models.py", "tests/test_maya.py", "tests/test_maya_local.py",
    "tests/test_maya_session.py", "tests/test_nvidia.py",
    "tests/test_nvidia_nim_preflight.py", "tests/test_on_prem_blind_review.py",
    "tests/test_on_prem_report.py", "tests/test_on_prem_package.py", "tests/test_qwen.py",
    "tests/test_runpod_nim_pilot.py", "tests/test_runpod_nim_pod.py",
)
CATALOG_FILES = tuple(f"catalog/{name}.json" for name in ("ai4bharat", "kokoro", "maya", "nvidia", "qwen"))
FORBIDDEN_PATH_PARTS = (
    "private-key", "private_key", "working_api_tokens", "credentials.env", ".env",
    "id_rsa", "id_ed25519",
)

# High-confidence forms. The generic rule requires a secret field name and long literal.
SECRET_PATTERNS = (
    ("NVIDIA API key", re.compile(r"\bnvapi-[A-Za-z0-9_-]{20,}")),
    ("Runpod API key", re.compile(r"\brpa_[A-Za-z0-9]{20,}")),
    ("OpenAI API key", re.compile(r"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}")),
    ("Hugging Face token", re.compile(r"\bhf_[A-Za-z0-9]{20,}")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_-]{30,}")),
    ("AWS access key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("private key material", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("literal bearer credential", re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{16,}")),
    ("literal assigned secret", re.compile(
        r"(?i)(?:api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret|"
        r"secret[_-]?key|password)\s*[=:]\s*[\"']?"
        r"(?!\[?REDACTED\]?|PLACEHOLDER|synthetic-test-credential|example|none|null)"
        r"[A-Za-z0-9._~+/=-]{16,}")),
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _path_is_forbidden(name: str) -> bool:
    lowered = name.lower()
    parts = PurePosixPath(lowered).parts
    return (any(marker in lowered for marker in FORBIDDEN_PATH_PARTS)
            or any(part.endswith((".pem", ".p12", ".pfx")) for part in parts)
            or ".ssh" in parts)


def _text_if_decodable(data: bytes) -> str | None:
    if b"\x00" in data[:8192]:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def scan_bytes(name: str, data: bytes, *, depth: int = 0) -> list[str]:
    """Return secret findings, including members of nested ZIPs, without values."""
    findings = []
    if _path_is_forbidden(name):
        findings.append(f"forbidden path: {name}")
    if depth < 3 and zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as nested:
            for member in nested.infolist():
                if member.is_dir():
                    continue
                if member.file_size > 100 * 1024 * 1024:
                    findings.append(f"oversized nested member not scanned: {name}!{member.filename}")
                    continue
                findings.extend(scan_bytes(f"{name}!{member.filename}", nested.read(member), depth=depth + 1))
        return findings
    text = _text_if_decodable(data)
    if text is None:
        return findings
    for label, pattern in SECRET_PATTERNS:
        if pattern.search(text):
            findings.append(f"{label}: {name}")
    return findings


def assert_no_secrets(root: Path) -> None:
    findings = []
    for path in sorted(root.rglob("*")):
        if path.is_file():
            findings.extend(scan_bytes(str(path.relative_to(root)), path.read_bytes()))
    if findings:
        raise ValueError("Credential scan failed:\n" + "\n".join(sorted(set(findings))))


def _copy(relative: str, destination: Path) -> None:
    source = ROOT / relative
    if not source.is_file():
        raise FileNotFoundError(f"Required package input is missing: {relative}")
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def _copy_reproduction_code() -> list[str]:
    copied = set()
    destination = PACKAGE / "reproduction"
    candidates = [ROOT / item for item in REPRODUCTION_FILES + CATALOG_FILES]
    candidates += list((ROOT / "tts_arena").rglob("*.py"))
    candidates += list((ROOT / "scripts").glob("*.py"))
    for source in sorted(set(candidates)):
        if source.is_file() and "__pycache__" not in source.parts:
            relative = str(source.relative_to(ROOT))
            _copy(relative, destination)
            copied.add(relative)
    return sorted(copied)


def _write_reproduction_readme(copied: list[str]) -> None:
    (PACKAGE / "reproduction/README.md").write_text(
        "# Reproduction code\n\n"
        "This directory contains the repository code used to generate, validate, and package the "
        "on-prem evidence. No credential file, private blind-review key, SSH key, or secret value is "
        "included. Live scripts require the operator to pass a private credential path at runtime.\n\n"
        "The tests establish their named offline or bounded-live contract only. They do not certify "
        "native-language quality, production load, billing, or universal vendor correctness.\n\n"
        "```bash\nuv sync --frozen\n"
        "uv run python -m unittest tests.test_on_prem_report tests.test_on_prem_blind_review "
        "tests.test_nvidia_nim_preflight tests.test_runpod_nim_pilot tests.test_runpod_nim_pod\n"
        "```\n\n"
        f"Included repository files: {len(copied)}. Verify with `../SHA256SUMS`.\n",
        encoding="utf-8")


def build() -> Path:
    report = json.loads(REPORT.read_text(encoding="utf-8"))
    if PACKAGE.exists():
        shutil.rmtree(PACKAGE)
    (PACKAGE / "audio").mkdir(parents=True)
    (PACKAGE / "captions").mkdir()
    (PACKAGE / "candidate-audio/indic-parler").mkdir(parents=True)
    documentation = (
        "ON_PREM_HANDOFF.md", "ON_PREM_DECISION_PACK.md", "ON_PREM_REPORT.md",
        "ON_PREM_LANGUAGE_FEATURE_AUDIT.md", "ON_PREM_CANDIDATE_OUTPUTS.md",
        "OTHER_ON_PREM_OPTIONS.md", "KOKORO_LOCAL_QUALIFICATION.md",
        "MAYA_LOCAL_IMPLEMENTATION.md",
    )
    for name in documentation:
        shutil.copy2(ROOT / "docs" / name, PACKAGE / name)
    shutil.copy2(REPORT, PACKAGE / "on-prem-report.json")
    shutil.copy2(ROOT / "artifacts/on-prem-language-feature-audit-20260916.json",
                 PACKAGE / "on-prem-language-feature-audit-20260916.json")
    shutil.copy2(ROOT / "artifacts/other-on-prem-options-20260916.json",
                 PACKAGE / "other-on-prem-options.json")
    shutil.copy2(ROOT / "artifacts/on-prem-blind-review.zip", PACKAGE / "on-prem-blind-review.zip")
    shutil.copy2(ROOT / "artifacts/runpod/nvidia-magpie-1.10.0-l40s-20260916/cleanup.json",
                 PACKAGE / "nvidia-cleanup.json")
    qwen_destination = PACKAGE / "qwen-evidence"
    qwen_destination.mkdir()
    for name in ("qwen3-base-en-IN.json", "qwen3-hindi-lora-hi-IN.json",
                 "qwen3-cancellation.json", "asr-diagnostic.json", "acoustic-diagnostic.json"):
        shutil.copy2(ROOT / "artifacts/runpod/qwen3-tts-20260916" / name,
                     qwen_destination / name)
    indic_source = ROOT / "artifacts/on-prem-candidates/indic-parler"
    for path in sorted(indic_source.glob("*")):
        if path.is_file():
            shutil.copy2(path, PACKAGE / "candidate-audio/indic-parler" / path.name)

    recordings = []
    for vendor in report["vendors"]:
        for model in vendor["models"]:
            for clip in model["recordings"]:
                audio = ROOT / "ui/public" / clip["audio_url"].lstrip("/")
                name = f"{vendor['id']}--{model['model'].split('/')[-1]}--{clip['language']}.wav"
                target = PACKAGE / "audio" / name
                shutil.copy2(audio, target)
                caption = audio.parent.parent / "captions" / (audio.stem + ".vtt")
                caption_target = PACKAGE / "captions" / name.replace(".wav", ".vtt")
                shutil.copy2(caption, caption_target)
                recordings.append({
                    "vendor": vendor["name"], "model": model["model"],
                    "language": clip["language"], "voice": clip["voice"],
                    "audio": f"audio/{name}", "audio_sha256": sha256(target),
                    "caption": f"captions/{caption_target.name}",
                    "duration_seconds": clip["duration_seconds"],
                })
    if (len(recordings) != report["recording_count"]
            or len({(row["model"], row["language"]) for row in recordings}) != len(recordings)):
        raise ValueError("Package recording inventory changed")

    copied_code = _copy_reproduction_code()
    _write_reproduction_readme(copied_code)
    assert_no_secrets(PACKAGE)

    payload_files = sorted(path for path in PACKAGE.rglob("*")
                           if path.is_file() and path.name not in {"manifest.json", "SHA256SUMS"})
    file_inventory = [{"path": str(path.relative_to(PACKAGE)), "bytes": path.stat().st_size,
                       "sha256": sha256(path)} for path in payload_files]
    manifest = {
        "schema": "on_prem_tts_decision_package_v2",
        "vendor_count": report["vendor_count"],
        "audio_complete_vendor_count": report["audio_complete_vendor_count"],
        "model_count": report["model_count"], "recording_count": len(recordings),
        "reproduction_file_count": len(copied_code),
        "credential_files_included": 0, "private_blind_keys_included": 0,
        "recordings": recordings, "files": file_inventory,
    }
    manifest_path = PACKAGE / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    checksum_files = payload_files + [manifest_path]
    (PACKAGE / "SHA256SUMS").write_text(
        "".join(f"{sha256(path)}  {path.relative_to(PACKAGE)}\n" for path in checksum_files),
        encoding="utf-8")
    assert_no_secrets(PACKAGE)

    ZIP_PATH.unlink(missing_ok=True)
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(PACKAGE.rglob("*")):
            if path.is_file():
                archive.write(path, Path("on-prem-tts-decision-package") / path.relative_to(PACKAGE))
    findings = scan_bytes(ZIP_PATH.name, ZIP_PATH.read_bytes())
    if findings:
        ZIP_PATH.unlink(missing_ok=True)
        raise ValueError("Final archive credential scan failed:\n" + "\n".join(findings))
    print(json.dumps({"package": str(PACKAGE), "zip": str(ZIP_PATH),
                      "recordings": len(recordings), "reproduction_files": len(copied_code),
                      "credential_scan": "passed", "zip_sha256": sha256(ZIP_PATH)}))
    return ZIP_PATH


if __name__ == "__main__":
    build()
