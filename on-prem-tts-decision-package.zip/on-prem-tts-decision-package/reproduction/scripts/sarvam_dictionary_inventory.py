"""Read-only inventory; retain only generic evaluation-compatible matches, never private contents."""
import json,re,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import httpx
from tts_arena.credentials import read_credentials,redact
from scripts.live_sarvam_dictionary import OUT,CREATE_URL
SAFE={'B2B':{'B to B','बी टू बी'},'NAIC':{'N A I C','एन ए आई सी'},'EMI':{'ई एम आई','E M I'},'KYC':{'के वाई सी','K Y C'}}
def main():
 p=OUT/'inventory.json'
 if p.exists():raise RuntimeError('Inventory already captured')
 s=read_credentials('/Users/rahulnatarajan/Documents/arena_tts/working_api_tokens.env');report={'read_only':True,'inspected':0,'eligible':[]}
 with httpx.Client(timeout=30,trust_env=False,headers={'api-subscription-key':s['SARVAM_API_KEY']}) as c:
  r=c.get(CREATE_URL);report['list_status']=r.status_code
  if r.status_code==200:
   data=r.json();report['dictionary_count']=data.get('dictionary_count')
   for ident in data.get('dictionaries',[])[:10]:
    if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',ident):continue
    r=c.get(CREATE_URL+'/'+ident);report['inspected']+=1
    if r.status_code!=200:report['get_failure_status']=r.status_code;break
    contents=r.json();entries=contents.get('pronunciations',{}).get('hi-IN',{})
    matches={k:v for k,v in entries.items() if k in SAFE and v in SAFE[k]}
    if matches:report['eligible'].append({'dictionary_id':ident,'safe_matches':matches,'content_sha256':hashlib.sha256(r.content).hexdigest(),'unrelated_contents_retained':False})
  else:report['error']=redact(r.text[:1000],s)
 p.write_text(redact(json.dumps(report,ensure_ascii=False,indent=2),s)+'\n');print('status',report['list_status'],'inspected',report['inspected'],'eligible',len(report['eligible']))
if __name__=='__main__':main()
