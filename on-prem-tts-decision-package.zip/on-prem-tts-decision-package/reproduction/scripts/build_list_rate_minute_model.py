"""Create a sample-dependent list-rate model from saved live results."""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tts_arena.cost_model import per_sample_minute_rate
rates={r['provider']:r for r in json.loads((ROOT/'artifacts/pricing-current-20260916/rates.json').read_text())['rates']}
snap=json.loads((ROOT/'ui/public/evidence/snapshot.json').read_text())
direct=[]
for provider in ('murf','soniox'):
 r=rates[provider]
 direct.append({'provider':provider,'model_scope':r['model_scope'],'currency':r['currency'],'list_rate_per_generated_minute':r['normalized_per_generated_minute'],'pricing_url':r['pricing_url'],'classification':'direct_list_rate_not_billed_cost'})
samples=[]; excluded=[]
for row in snap['runs']:
 if row.get('status')!='success' or not row.get('duration_seconds') or not row.get('text'): continue
 p=row['provider']; rate=rates.get(p)
 if not rate: continue
 value=rate.get('normalized_per_1k_chars')
 # Scope matching is conservative: normalized rate must exist and saved config model must be named by the rate scope.
 model=(row.get('config') or {}).get('model')
 if value is None or not model or model not in rate.get('model_scope',''):
  continue
 samples.append({'provider':p,'run_id':row['run_id'],'model':model,'language':row.get('language'),'currency':rate['currency'],'source_rate_per_1k_characters':value,'text_codepoints':len(row['text']),'duration_seconds':row['duration_seconds'],'modeled_list_rate_per_generated_minute':per_sample_minute_rate(value,len(row['text']),row['duration_seconds']),'pricing_url':rate['pricing_url'],'classification':'sample_dependent_list_rate_model_not_billed_cost'})
for p,r in rates.items():
 if p not in {x['provider'] for x in direct} and r.get('normalized_per_1k_chars') is None:
  excluded.append({'provider':p,'reason':'No single exact-model currency-per-character rate suitable for a per-sample conversion.'})
out={'generated_at':datetime.now(timezone.utc).isoformat(),'scope':'Published list-rate model only. No invoice, account spend, character-metering reconciliation, or universal vendor ranking is asserted.','direct_generated_minute_rates':direct,'sample_dependent_models':samples,'non_comparable':excluded}
target=ROOT/'artifacts/list-rate-minute-model-20260916';target.mkdir(exist_ok=True)
(target/'model.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
