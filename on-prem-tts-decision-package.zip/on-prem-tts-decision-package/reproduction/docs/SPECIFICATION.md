# TTS Arena measurement and conformance specification

The system compares candidate TTS implementations for Indian English, Hindi, and eight configurable regional languages. Every result has three independent dimensions: what the vendor documents, what the adapter implements, and what an observed test verifies. None may substitute for another.

The catalog now contains 33 candidates (the original 30 plus Voicemaker, Maya Research and Soniox), including explicitly identified open models. This is an assessment universe, not a claim that 33 independent companies all satisfy the language requirements. Initial regional locales are Bengali, Marathi, Telugu, Tamil, Gujarati, Urdu, Kannada and Malayalam. Traffic weights and the final regional set remain configurable business inputs; no census ranking or precise traffic distribution is assumed.

## Experimental invariants

A component comparison fixes text content and, for incremental protocols, the timing and boundaries of supplied chunks. A conversation comparison fixes STT, LLM, turn detection, text chunker, deployment region, codec and telephony transport. The `assert_tts_only` validator rejects missing or changed non-TTS fields. Runs must retain model/voice configuration, code and vendor catalog hashes, scenario IDs, clock boundary, audio and events.

Do not compare a provider's native 24 kHz WAV against another's 8 kHz telephone output as if they were the same condition. Native output and telephone-transcoded output are separate experiments. Transcoding quality needs its own verified implementation and test vectors; automatic resampling is intentionally absent from the current runner.

## Required measurements

| Metric | Definition and denominator | Current implementation / evidence boundary |
|---|---|---|
| First response byte | Request start to first nonempty response body bytes | HTTP monotonic timestamps, including network; headers do not qualify |
| First encoded audio payload | Request start to first extracted audio payload bytes | Binary, JSON base64/hex or SSE decode; may still be compressed audio or a WAV header |
| First playable PCM frame | Request start to first complete PCM frame available | PCM16 and PCM WAV parser; null for formats not decoded. This is not handset audio |
| Completion latency | Request start to fully received response | All attempts retain elapsed time, including errors/cancellation |
| Real-time factor | Completion seconds / generated audio seconds | Only when duration can be determined from supported PCM; not call duration |
| Chunk gaps | Timestamp difference between nonempty audio events | Raw events retained; distinguish wire chunks from decoded audio chunks |
| Failure rate | Failed/blocked attempts / scheduled attempts | All attempts retained; no silent retries |
| Queue delay | Actual slot acquisition minus scheduled arrival | Open-loop constant-rate load schedule, bounded concurrency |
| Percentiles | Linear interpolation over stated valid observations | p50/p90/p95/p99 with sample count; success latency explicitly labelled success-only |
| Barge-in stop delay | Caller onset to final audible sample of the interrupted response | Receiver sample timeline; replacement response excluded; censoring recorded |
| False interruption | Cancellation during a labelled non-interrupting caller event | Contextual fixture label required; word alone is not a label |
| Missed interruption | Eligible overlap fails the configured stop deadline | Trials without active bot speech at onset are ineligible, not automatic passes |
| Stale audio | Observed old-response speech after cancellation | Audio duration and timing separate; cancellation ACK alone cannot establish success |
| Recovery | Caller end to new response start; next response must incorporate correction | Caller end events retained; correction correctness requires supplied labelled/verified judgment |
| Timing uncertainty | Calibration error plus frame/scheduler/network measurement limitations | Sample resolution reported separately; physical/production accuracy remains unverified |
| Intelligibility | Native transcription and reference entities; WER/CER diagnostic | NFC-only word/codepoint distance implemented. ASR errors are not automatically TTS errors |
| Entity accuracy | Correct names, dates, amounts, addresses, digits and code-switch boundaries | Reference annotation and qualified listening required |
| Naturalness / accent | Blinded native-listener ratings and pairwise preference | Study packaging, qualification filtering and listener-cluster intervals implemented; no collected ratings |
| Audio defects | Clipping, amplitude, silence, corruption, truncation | PCM level diagnostics and parsing implemented; these are not perceptual MOS |
| Speaker consistency | Identity preserved across text, language and requested styles | Requires controlled speaker/listener evidence; no automatic identity certification |
| Cost | Actual billed amount per generated/played minute and per successful outcome | Request-ID invoice reconciliation implemented; absent bills remain unreconciled |
| Text billing units | Raw codepoints, UTF-8 bytes, UTF-16 units, normalized counts | Explicitly measured; no assumption that any one count is the vendor's billing basis |

The default 500 ms stop threshold and feature-check tolerances are engineering examples, not asserted business SLAs. Freeze thresholds before scoring a production experiment. Extremely small samples must not support p99 procurement claims even though a numerical percentile can be calculated.

## Feature conformance

Each vendor dossier identifies its supported request subset. A field's presence in a request is only request conformance. Behavioral checks live in `tts_arena/conformance.py` and distinguish passed, failed, unsupported and inconclusive.

1. Incremental text input: audio must arrive before final text is supplied on a deliberately long, paced fixture. Sending the entire text in one HTTP body cannot establish this.
2. Audio streaming: observe multiple nonempty audio events before response completion. Measure first bytes and first playable frame independently.
3. Flush: hold input open with pending text, flush, then observe released audio without ending input.
4. Cancellation: capture cancel sent/acknowledged, last old-response audio, queue tail and subsequent request behavior. HTTP task abort is labelled client abort, never vendor cancellation.
5. Connection reuse: identify the same transport session across successful requests, including after cancellation. New connections do not pass.
6. Timestamps: compare word boundaries with independently verified alignment. Return maximum and distribution of timing errors, omissions and mismatched words.
7. Pronunciation dictionaries: matched fixtures with/without the override, native-reviewed target pronunciation, preserved surrounding words.
8. SSML: verify supported markup parsing, escapes, pauses, pronunciation and prosody; unsupported tags must not be silently accepted by the harness.
9. Speed: compare duration ratio to requested speed on identical text; reject NaN, infinities, booleans and out-of-range settings. Native listeners still check intelligibility.
10. Emotion: blinded language-qualified review of requested expression and content preservation; an API accepting emotion text is insufficient.
11. Cloning: consented enrollment assets, model/version, intelligibility and identity evidence, with separate cross-language comparisons. Private enrollment access is not assumed.
12. Format: validate actual audio metadata/decoder against declared sample rate, channels, bit depth and codec; validate telephone path separately.
13. Limits/errors: boundary lengths, invalid voices/models/languages, malformed controls, authorization failure, 429, 5xx, connection loss and timeout. Record request IDs and partial audio.
14. Reproducibility: repeated fixed-seed and unseeded trials where supported; a model alias does not guarantee immutable weights.
15. Operational terms: region, retention, training use, rate limits, licensing and commercial rights need exact current vendor evidence, not audio tests alone.

Generic conformance checks consume explicit observations; they do not manufacture those observations. Native WebSocket codecs are implemented for ElevenLabs and Cartesia, Fonada's documented one-shot audio-streaming profile, Maya Calyx v2, and Voicemaker's single-request streaming subset. Their cancellation semantics are scoped in `docs/sessions/`: closing a context or cancelling queued text may leave already-generated audio playing. Physical telephony capture, enrollment, other native streaming clients and independent forced alignment are not universally implemented. Each missing adapter behavior remains a visible extension gate.

## Language corpus and native evaluation

The seed corpus is a draft engineering dataset, not a validated native benchmark. Every item carries locale, script, domain, category, expected entities, review state and provenance. Hindi in Devanagari, Romanized Hindi and Hinglish remain separate strata. A single score averaging all three is not sufficient.

Coverage must include regional names/addresses, rupee amounts, Indian number groupings, dates, digit sequences, abbreviations, acronyms, punctuation, long-form stability and code switching. Recorded caller fixtures additionally cover regional accents, corrections, acknowledgement, hesitation, silence, background speakers and repeated interruptions. Actual native caller recordings have not been supplied; synthetic tones are used only for measurement calibration.

Listening studies must qualify participants for the tested language/accent, randomize presentation, hide provider identity, screen listening conditions and use held-out calibration items. Store reviewer qualifications and exclusion reasons. The current scorer clusters naturalness by listener; it does not implement a crossed listener/item mixed-effects model. Report that limitation and use additional analysis before fine provider rankings.

ITU-T P.808 provides relevant guidance for crowdsourced listening-study design and reporting; this implementation does not claim P.808 certification.[1] ETSI's synthesized-speech assessment report explains why objective speech-quality measures need scope checks for synthetic speech.[2] Therefore waveform diagnostics, ASR transcript similarity and a generative judge must not be labelled human MOS.

## Architecture and plugin boundary

`catalog/<id>.json` stores sourced model/language/feature facts. `tts_arena/adapters/<id>.py` constructs exact requests and rejects unsupported config. Filesystem discovery avoids provider switches in the runner. Standard HTTP supports binary, JSON base64/hex, SSE base64/hex and explicitly allowlisted audio download URLs. Credentials are loaded from named environment variables; they are not persisted in run metadata.

The replay probe uses a documented PCM WebSocket contract in `docs/REPLAY_PROTOCOL.md`. A production bot needs a bridge that preserves its STT/LLM/turn-taking pipeline. This custom probe is not itself a Twilio, SIP, LiveKit or PSTN integration. Its local tests establish software behavior only.

`onboard "Add vendor …" --execute` invokes the installed coding agent with a repository-specific workflow, then validates the catalog and reruns tests. Without `--execute`, it stages a reviewable task. This supplies one-prompt engineering automation; an unknown/private vendor still requires its actual spec, access and credentials. Generated code does not automatically qualify for live or production use.

## Correctness and release gates

Offline tests include known sample positions, preserved silence, truncated PCM/SSE, bytewise Unicode, WAV headers before audio, real local HTTP chunk timing, 429/empty/error responses, bounded cancellation and a local WebSocket caller exchange. Mutation examples deliberately ignore controls, keep stale audio, change non-TTS settings or omit failures. A passing suite establishes the assertions exercised at its code hash, not all possible behavior.

Every attestation binds to code and catalog hashes and lists the exact contract-test scope. Live evidence, model-specific feature coverage, independent spec review, language-qualified evaluation, production receiver tests, load and invoices are separate gates. No blanket “perfectly implemented” badge is generated. A failed or unobserved gate cannot be converted into a success by a documentation claim.

## Sources

1. ITU-T. [P.808 (06/2021), Subjective evaluation of speech quality with a crowdsourcing approach](https://www.itu.int/rec/dologin_pub.asp?id=T-REC-P.808-202106-I%21%21PDF-E&lang=e&type=items).
2. ETSI. [TR 102 948 V1.2.1, Quality Assessment of Synthesized Speech](https://www.etsi.org/deliver/etsi_TR/102900_102999/102948/01.02.01_60/tr_102948v010201p.pdf).
3. Microsoft. [Lower speech synthesis latency](https://learn.microsoft.com/en-us/azure/ai-services/speech-service/how-to-lower-speech-synthesis-latency). Distinguishes service, network, client first-byte and completion measurements.
4. Individual vendor specifications and access dates: `catalog/*.json` and `docs/vendors/*.md`.

## Deployment evaluation scope — user decision, 15 September 2026

On-prem evaluation is limited to Kokoro and Maya Research. All other candidates remain in the hosted API evaluation scope; previously catalogued local-only models are retained as research entries but are deferred from execution. Navana remains skipped. This decision does not assert that other vendors lack self-hosted products.

Kokoro: evaluate the pinned Kokoro-82M weights and exact runtime/voice configuration on local infrastructure. Maya: evaluate publicly available Maya 1 and Veena separately; Maya 2 Native/Global/Flash remain hosted candidates, and their enterprise on-prem availability is unverified. Do not substitute Veena results for Maya 2 results or count model variants as additional companies.

For each on-prem model, retain weight revision/hash, license, runtime/dependency versions, hardware and precision. Apply the same language corpus, quality assessment, output-codec conditions and interruption measurements used for hosted candidates. Additionally measure model load time, cold/warm first playable audio, queue delay, p50/p95/p99 latency at stated load, sustainable concurrency, RAM/VRAM use, failures, cancellation compute release, and total infrastructure/license/operations cost per generated minute at stated utilization. Verify network egress and offline operation before claiming air-gapped compatibility. These are required evaluation checks, not completed measurements.

Maya deployment sources checked 15 September 2026: https://www.mayaresearch.ai/ ; https://huggingface.co/maya-research/maya1 ; https://huggingface.co/maya-research/Veena . Kokoro source: https://huggingface.co/hexgrad/Kokoro-82M .
