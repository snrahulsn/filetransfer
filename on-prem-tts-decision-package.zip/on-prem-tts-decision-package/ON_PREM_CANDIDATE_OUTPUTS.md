# Indic Parler-TTS candidate outputs

Exact model: `ai4bharat/indic-parler-tts`. These clips were generated through AI4Bharat's official Hugging Face Space. They prove exact-model output availability, not our own self-hosted deployment. The checkpoint is gated; the unattended account flow reached CAPTCHA.

Checkpoint license: **Apache-2.0**. Size: **0.938B F32 / 3.75 GB stored**. Publisher hardware minimum: **not stated**. Public examples support CUDA or CPU. ParlerTTS exposes incremental waveform streaming through `ParlerTTSStreamer`, but these 12 calls were batch and do not measure first-audio, cancellation, VRAM or concurrency.

The model explicitly claims Indian-English accents, 20 official Indic languages, 69 voices, and caption control for emotion, rate, pitch, expressivity, reverberation, noise and quality. It does not expose arbitrary reference-audio voice cloning. Punjabi is unofficial.

| Language | Support | Duration | Audio |
|---|---|---:|---|
| en-IN | official Indian-English claim; recommended English voice | 5.03 s | [play/download](../ui/public/evidence/audio/indic-parler--en-IN.mp3) |
| hi-IN | official; recommended Hindi voice | 5.11 s | [play/download](../ui/public/evidence/audio/indic-parler--hi-IN.mp3) |
| bn-IN | official; recommended Bengali voice | 3.44 s | [play/download](../ui/public/evidence/audio/indic-parler--bn-IN.mp3) |
| mr-IN | official; recommended Marathi voice | 3.62 s | [play/download](../ui/public/evidence/audio/indic-parler--mr-IN.mp3) |
| te-IN | official; recommended Telugu voice | 3.30 s | [play/download](../ui/public/evidence/audio/indic-parler--te-IN.mp3) |
| ta-IN | official; recommended Tamil voice | 2.51 s | [play/download](../ui/public/evidence/audio/indic-parler--ta-IN.mp3) |
| gu-IN | official; recommended Gujarati voice | 4.34 s | [play/download](../ui/public/evidence/audio/indic-parler--gu-IN.mp3) |
| kn-IN | official; recommended Kannada voice | 3.13 s | [play/download](../ui/public/evidence/audio/indic-parler--kn-IN.mp3) |
| ml-IN | official; recommended Malayalam voice | 2.77 s | [play/download](../ui/public/evidence/audio/indic-parler--ml-IN.mp3) |
| ur-IN | official language; no recommended Urdu voice is listed in the card table | 3.30 s | [play/download](../ui/public/evidence/audio/indic-parler--ur-IN.mp3) |
| or-IN | official; recommended Odia voice | 3.49 s | [play/download](../ui/public/evidence/audio/indic-parler--or-IN.mp3) |
| pa-IN | publisher labels Punjabi support unofficial; named voice is listed | 3.80 s | [play/download](../ui/public/evidence/audio/indic-parler--pa-IN.mp3) |

Use native reviewers to score naturalness, pronunciation, accent fit, intelligibility and entity fidelity. Do not treat publisher native-speaker scores as independent certification.
