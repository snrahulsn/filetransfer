# Exact on-prem language, feature and license audit

Reviewed 16 September 2026. The machine-readable record is [on-prem-language-feature-audit-20260916.json](../artifacts/on-prem-language-feature-audit-20260916.json).

The result for the requested Indian-language set is narrow: **Kokoro, Veena and Magpie document Hindi; Maya1 is English-only; none documents Tamil; none documents an `en-IN` locale.** Veena and Maya1 can generate English, but their pinned cards do not establish Indian-English accent support. NVIDIA can mix a `HI-IN` voice with English text to produce accented speech, but that is not an `en-IN` locale or an Indian-English quality result.

`Yes` means explicit exact-model documentation, not a native-listener or live-production certification. `No` is used only when an exhaustive inventory or explicit model limit excludes the language/feature. `Unknown` preserves missing evidence.

## Languages

| Exact model | hi-IN | en-IN | bn-IN | mr-IN | te-IN | ta-IN | gu-IN | kn-IN | ml-IN | ur-IN | or-IN | pa-IN |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Kokoro `f3ff357…` | Yes | No | No | No | No | No | No | No | No | No | No | No |
| Veena `8b770f9…` | Yes | Unknown | No | No | No | No | No | No | No | No | No | No |
| Maya1 `21c682a…` | No | Unknown | No | No | No | No | No | No | No | No | No | No |
| Magpie Multilingual `1.10.0` | Yes | No | No | No | No | **No** | No | No | No | No | No | No |

Kokoro's pinned voice inventory has Hindi and American/British English, with no Indian-English voice. Veena explicitly limits the checkpoint to Hindi and English with code-mixing and lists Tamil, Telugu, Bengali and Marathi as future work. Maya1 explicitly says English-only with multi-accent support, but its examples name American, British and Middle Eastern accents rather than Indian English. NVIDIA 26.07 exhaustively lists `en-US`, `es-US`, `fr-FR`, `de-DE`, `zh-CN`, `vi-VN`, `it-IT`, `hi-IN`, `ja-JP`, `ko-KR`, `ar-XA` and `pt-BR` for Magpie Multilingual.

## Features

| Feature | Kokoro | Veena | Maya1 | Magpie 1.10.0 |
|---|---:|---:|---:|---:|
| Incremental text input | Unknown | No | Unknown | Yes |
| Streaming audio | Yes, local segments | No | Yes | Yes |
| Flush | Unknown | No | Unknown | Yes |
| Cancellation guarantee | Unknown | Unknown | Unknown | Unknown |
| Connection reuse across requests | Unknown | Unknown | Unknown | Unknown |
| Word timestamps | Unknown | Unknown | Unknown | Yes |
| Pronunciation dictionary/control | Yes, inline phonemes | Unknown | Unknown | Yes |
| SSML | Unknown | Unknown | Unknown | Yes, subset |
| Speed/pacing control | Yes | Unknown | Yes, qualitative | Unknown |
| Emotion control | Unknown | No, roadmap | Yes | Yes, but not for current Hindi voices |
| Voice cloning | Unknown | No | No | **No; separate Zeroshot model** |
| Cross-language voice | Unknown | Unknown | No, English-only | Yes |
| Native telephony formats | Unknown | No, 24 kHz SNAC | No, 24 kHz SNAC | No, LINEAR_PCM only |
| Caller seed | Unknown | Unknown | Unknown | Unknown |
| Published concurrency limit | Unknown | Unknown | Unknown | Unknown |
| Self-hosted residency control | Yes | Yes | Yes | Yes |
| Retention policy | Unknown | Unknown | Unknown | Unknown |

Kokoro's generator yields complete generated segments; that is not incremental input or a network cancellation protocol. Veena's pinned card places streaming and emotion/prosody controls in its future roadmap. Maya1 documents streaming audio, natural-language pacing and inline emotion tags, but does not document flush/cancel semantics or built-in voice enrollment. Magpie 1.10.0 documents word-level text streaming, streaming audio, flush controls, word timestamps, dictionaries, an SSML subset and cross-language voices. Its current `HI-IN` voice list has default voices only, so the model-wide emotion feature does not establish Hindi emotion control.

## NVIDIA Tamil correction

The claimed Tamil support is a product-scope mix-up. In NVIDIA's release notes, the sentence that mentions Bengali (`bn-IN`) and Tamil (`ta-IN`) appears under **Release 26.02.0 → ASR NIM** and applies to **Parakeet 1.1b RNNT Multilingual**, an automatic speech-recognition model. It is not under TTS and does not mention Magpie.

For **Release 26.07.0 → TTS NIM**, NVIDIA maps `magpie-tts-multilingual` to container tag `1.10.0` and says the model expanded to 12 languages by adding Korean, Arabic and Portuguese. The exact 26.07 TTS matrix contains Hindi but no Tamil. Therefore `ta-IN` is **No for Magpie TTS Multilingual 1.10.0** on current primary evidence. The mutable `latest` tag was not resolved to an image digest, so it must not be assumed identical to `1.10.0` without registry inspection.

## Source conflicts and license scope

- NVIDIA's current Model Card++ says the model is under the **NVIDIA Open Model License Agreement**, while the Build experience surface and the previously captured NGC listing use Community-license wording. The NIM container is separately governed by the **NVIDIA Software License Agreement** and **Product-Specific Terms for NVIDIA AI Products**. Production review must bind the pulled image digest/tag to its accompanying terms.
- NVIDIA's Model Card++ mentions optional reference audio, but current 26.07 API documentation says `audio_prompt` requires the separate **Magpie TTS Zeroshot** model, and the release notes direct voice cloning to that container. Voice cloning is therefore No for the exact Multilingual container.
- Veena's broad “Indian Languages” heading does not override its exact Hindi-and-English limitation and future-language roadmap.
- Maya1's “multi-accent English” claim does not identify Indian English. The saved `en-IN`-labelled local WAV proves generation for that prompt, not the requested accent.
- Kokoro's pinned README metadata says `en`, while the detailed pinned release inventory includes Hindi voices. The detailed inventory is used for language eligibility.

## Exact primary sources

- Kokoro pinned [model card](https://huggingface.co/hexgrad/Kokoro-82M/blob/f3ff3571791e39611d31c381e3a41a3af07b4987/README.md) and [voice inventory](https://huggingface.co/hexgrad/Kokoro-82M/blob/f3ff3571791e39611d31c381e3a41a3af07b4987/VOICES.md).
- Veena pinned [model card](https://huggingface.co/maya-research/Veena/blob/8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f/README.md).
- Maya1 pinned [model card](https://huggingface.co/maya-research/maya1/blob/21c682a0afef8c13a89b2512733c8bf5f0c52eb7/README.md).
- NVIDIA Speech NIM 26.07 [release notes](https://docs.nvidia.com/nim/speech/26.07.0/about/release-notes.html), [TTS support matrix](https://docs.nvidia.com/nim/speech/26.07.0/reference/support-matrix/tts.html), [customization matrix](https://docs.nvidia.com/nim/speech/26.07.0/tts/customization.html), [voices](https://docs.nvidia.com/nim/speech/26.07.0/tts/voices.html), [HTTP API](https://docs.nvidia.com/nim/speech/26.07.0/reference/api-references/tts/http-tts.html), [realtime API](https://docs.nvidia.com/nim/speech/26.07.0/reference/api-references/tts/realtime-tts.html), and current [Model Card++](https://build.nvidia.com/nvidia/magpie-tts-multilingual/modelcard).

All sources were accessed 16 September 2026. Local Kokoro, Veena and Maya1 audio evidence remains separate from language/accent qualification. The NVIDIA container did not become ready during the bounded deployment attempt, so no NVIDIA synthesis or live feature behavior was observed.
