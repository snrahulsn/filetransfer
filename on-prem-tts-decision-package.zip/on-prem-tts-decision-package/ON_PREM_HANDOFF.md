# On-prem TTS evidence handoff

Evidence cutoff: 16 September 2026.

## Start here

1. `ON_PREM_DECISION_PACK.md` — decision table, model results, language support, features, infra and licenses.
2. `ON_PREM_LANGUAGE_FEATURE_AUDIT.md` — 12-language by 17-feature evidence grid.
3. `ON_PREM_REPORT.md` — executed model and recording inventory.
4. `ON_PREM_CANDIDATE_OUTPUTS.md` — 12 Indic Parler exact-model outputs.
5. `OTHER_ON_PREM_OPTIONS.md` — deeper comparison and recent negative feedback for additional models.
6. `on-prem-blind-review.zip` — anonymous listening pack. The identity key is intentionally excluded.
7. `reproduction/` — runners, adapters, session/stream code, metric calculators and tests.

## Executed audio

- Core report: 4 vendors, 6 exact model families, 9 WAV recordings.
- Indic Parler candidate: 12 additional MP3 recordings covering one requested output per locale.
- NVIDIA: hosted exact-model Hindi output succeeded; self-hosted NIM did not become ready within the bounded pilot.
- Qwen official Base: Indian-English clone fixture succeeded; 4.56 s audio, 10.47 s synthesis, RTF 2.30.
- Qwen community Hindi LoRA: failed; 40.88 s cap-hit output for a short sentence, RTF 3.05, empty Scribe transcript, WER/CER 1.00.

## Metrics included

Language/locale claims, executed synthesis, exact model revision, model load time, synthesis time, audio duration, real-time factor, sample rate/channel/PCM format, silence fraction, clipping, ASR WER/CER, entity recovery, streaming output availability, incremental text, flush, timestamps, cancellation/barge-in mechanism, cancellation latency, GPU-memory release, cloning, style/emotion control, pronunciation controls, telephony format, license, data residency, infra, storage, observed hourly GPU cost and recent implementation feedback.

Native naturalness, accent fit and emotion perception are intentionally left to the supplied blind listening pack. They cannot be derived from transport or ASR metrics.

## Security and integrity

The package is built from an explicit artifact set, then recursively scanned for API-key formats, bearer credentials, assigned secrets and private-key material. Credential files, SSH keys and the private blind identity key are excluded. `manifest.json` inventories every packaged file; `SHA256SUMS` verifies each payload.
