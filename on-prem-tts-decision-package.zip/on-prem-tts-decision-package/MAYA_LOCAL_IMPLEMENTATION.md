# Maya local implementation — 15 September 2026

**Implemented and executed batch inference profiles for the public Maya1 and Veena checkpoints on separate disposable Runpod RTX 4090 Pods.** The [Maya1 GPU result](MAYA1_RUNPOD_RESULTS.md) and Veena results are separate model observations. This work does not reproduce hosted Maya2 Native, Maya2 Global, Maya2 Flash or Calyx. No new provider/catalog entry was created.

## Live Veena CUDA smoke, 15 September 2026

The pinned Veena and SNAC files were provisioned on an ephemeral Runpod PyTorch 2.8/CUDA 12.8 Pod. Exact selected files passed the adapter's size and hash checks before inference. One batch WAV each was retained for Devanagari Hindi (`kavya`), Indian English request (`agastya`) and Hindi-English code-mix (`maitri`) in `artifacts/runpod/veena-20260915/`. They are mono 24 kHz PCM16 with durations 2.219 s, 2.816 s and 2.048 s, respectively. The output metadata retains initialization, synthesis and exact checkpoint/dependency revisions. The initial Hindi metadata carried the adapter's older `not_live_verified` label; the actual command exited successfully and produced a checked WAV, so that label describes the pre-smoke qualification state, not a failed inference. The later two JSONs use `live_inference_observed_quality_not_certified`.

The official [Veena checkpoint card](https://huggingface.co/maya-research/Veena) limits that public checkpoint to Hindi and English with code-mix. The official [Maya1 card](https://huggingface.co/maya-research/maya1) identifies English with multiple accents, not Hindi. The catalog and exact-model language table now distinguish those two local checkpoints from hosted Calyx's broader Indian-language roster. This prevents a vendor-wide language claim from making the public checkpoints appear eligible for Bengali, Marathi, Telugu, Tamil, Gujarati, Kannada or Malayalam. The English files do not certify an Indian accent.

The Pod's API creation response was $0.74/hour, its console rounded to $0.75/hour, and it was deleted with HTTP 204 after the files were copied. A subsequent Pod inventory returned `[]`. A detached one-hour guard was started immediately after Pod creation as a second deletion path. This is a short functional smoke, not a throughput or cost benchmark. Speech correctness, Indian accent, naturalness, code-mix fidelity, streaming first-audio latency, interruption and concurrent-load results remain unmeasured.

Three bounded Saaras v3 ASR calls were made on the retained WAVs and saved in `artifacts/runpod/veena-20260915/asr-diagnostics.json`. The Hindi sample was labeled `hi-IN` and transcribed the drafted words without punctuation. The English request was labeled `en-IN`, but the transcript was written in Devanagari transliteration. The code-mixed sample was labeled `hi-IN` and included the English word `order`. ASR is a lexical check, not a native pronunciation or accent rating; no language-mode quality score is derived from these three clips.

Files: `tts_arena/adapters/maya_local.py` and `tests/test_maya_local.py`. The parent orchestrator owns runtime provisioning, disk/memory checks, integration dispatch and live execution.

## Model scope and immutable revisions

| Profile | Revision | Actual parameter count in Hub metadata | Language scope |
|---|---|---:|---|
| [maya-research/maya1](https://huggingface.co/maya-research/maya1/tree/21c682a0afef8c13a89b2512733c8bf5f0c52eb7) | `21c682a0afef8c13a89b2512733c8bf5f0c52eb7` | 3,300,928,512 | English only; requested Indian accent is not proven |
| [maya-research/Veena](https://huggingface.co/maya-research/Veena/tree/8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f) | `8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f` | 3,783,054,336 | Hindi, English and code-mixed text; four fixed speakers |

Veena’s card calls it 3B, but the current serialized parameter metadata reports 3,783,054,336. Its sample code names a stale `maya-research/veena-tts` repository; this implementation pins the actual `maya-research/Veena` repository. Maya1 currently reports 3,300,928,512 parameters. This distinction changes memory planning.

## Provisioning allowlist and exact Runpod download

Download only these paths from the corresponding immutable revision using Hugging Face snapshot allowlists. The Veena/SNAC and Maya1/SNAC allowlists were downloaded on separate guarded Runpod Pods. Do not clone all repository history, download alternate quantizations, or execute repository Python scripts. Runtime code verifies every selected artifact against its immutable SHA-256 (LFS objects) or Git-blob SHA-1 (metadata/tokenizers), including exact byte lengths, before importing/loading the inference runtime. Hash validation prevents a revision label from being substituted for actual file identity.

### `maya-research/maya1`

Revision: `21c682a0afef8c13a89b2512733c8bf5f0c52eb7`. [Exact file listing](https://huggingface.co/maya-research/maya1/tree/21c682a0afef8c13a89b2512733c8bf5f0c52eb7).

| File | Bytes | Hash algorithm | Expected hash |
|---|---:|---|---|
| `chat_template.jinja` | 3,827 | git_blob_sha1 | `1bad6a0f648dccdbec523ca79ba90fbcfc806af0` |
| `config.json` | 860 | git_blob_sha1 | `40c05c8013f3658cfee0c0ad296c9d983a6918c5` |
| `generation_config.json` | 228 | git_blob_sha1 | `776c9340606cb019dc334afac1f2d740d66fcc8a` |
| `model-00001-of-00002.safetensors` | 4,991,160,848 | sha256 | `f1dae409f70c5beb92916662c6bc389b9b235ac8aa5edd19a4dcb87e37a73074` |
| `model-00002-of-00002.safetensors` | 1,610,725,592 | sha256 | `df22e9a90c1bea262250982640b119e6020474736991da482cb6ed56dd23d045` |
| `model.safetensors.index.json` | 20,955 | git_blob_sha1 | `9e16ad6538a683f3b12ec741a656d3a17898ef63` |
| `special_tokens_map.json` | 3,333 | git_blob_sha1 | `c16e4b73418778a6d7e1b07e85b58027fa148f93` |
| `tokenizer.json` | 22,853,258 | sha256 | `6c5e5b1d89b7e3738e5a5a4f93c326d8f3292ea83f9c560b8dbb6d66fb851973` |
| `tokenizer_config.json` | 5,407,227 | git_blob_sha1 | `510237684b49036844dd3f9a8858fbd28cebcba4` |

Total selected bytes: 6,630,176,128.

### `maya-research/Veena`

Revision: `8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f`. [Exact file listing](https://huggingface.co/maya-research/Veena/tree/8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f).

| File | Bytes | Hash algorithm | Expected hash |
|---|---:|---|---|
| `chat_template.jinja` | 3,827 | git_blob_sha1 | `1bad6a0f648dccdbec523ca79ba90fbcfc806af0` |
| `config.json` | 839 | git_blob_sha1 | `f2b83304bbe5bed2a641859ca8f1c6d24002c938` |
| `generation_config.json` | 180 | git_blob_sha1 | `27a9e4c5a8b7c8e0394f0e31149ae19d4822dcd3` |
| `model-00001-of-00002.safetensors` | 4,991,105,552 | sha256 | `8c5ebde2fe9cb1f46ed0880c5bcf4f906f8dffe82acbbd59082cc68c1167e266` |
| `model-00002-of-00002.safetensors` | 2,575,032,728 | sha256 | `11a48e332797d11470fd71f4ddc28929ee912b7ce567d58542021436a843d9fc` |
| `model.safetensors.index.json` | 20,977 | git_blob_sha1 | `185a9ce91decb34327cabfecdee81cd6cfb0df16` |
| `special_tokens_map.json` | 697 | git_blob_sha1 | `6f180fad1e27a8bb8f87e4162de0713792d2d00d` |
| `tokenizer.json` | 22,851,621 | sha256 | `c88f202c5216ed6485367f5a606093d54f9a89ef3c654001ccc10026fcd276f2` |
| `tokenizer_config.json` | 5,405,560 | git_blob_sha1 | `c2a0026b9e5630b0d75221ed36bf24c339f00ed8` |

Total selected bytes: 7,594,421,981.

### `hubertsiuzdak/snac_24khz`

Revision: `d73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec`. [Exact file listing](https://huggingface.co/hubertsiuzdak/snac_24khz/tree/d73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec).

| File | Bytes | Hash algorithm | Expected hash |
|---|---:|---|---|
| `config.json` | 300 | git_blob_sha1 | `a9e7ef62bf7e1eb94d2713721029837aacab3b55` |
| `pytorch_model.bin` | 79,488,254 | sha256 | `4b8164cc6606bfa627f1a784734c1e539891518f1191ed9194fe1e3b9b4bff40` |

Total selected bytes: 79,488,554.

## Runtime and macOS ARM64 compatibility

Use a separate Python 3.11/3.12 environment to limit dependency conflicts. Required packages: PyTorch, Transformers, Accelerate (explicit device_map loading), safetensors, SNAC and its numpy/einops/huggingface-hub dependencies. The model configs declare Transformers 4.57.1 (Maya1) and 4.52.4 (Veena); start with **Transformers 4.57.1** for this implementation rather than silently moving to major version 5. SNAC’s current published package is **1.2.1**. Installed combinations still require actual import/inference verification; no compatibility claim is certified by these offline tests.

PyPI metadata observed 15 September: latest torch2.14.0, transformers5.17.0 and accelerate1.15.0 require Python>=3.10. This is an availability observation, not a tested dependency lock. The root should freeze actual resolved wheel versions after successful clean-environment imports.

The transformer device is explicit `mps`, `cpu` or `cuda`; dtype is explicit float16, bfloat16 or float32. The codec runs on CPU in float32. CUDA availability and free VRAM are checked before model loading; no CPU fallback is allowed. MPS availability is checked; `PYTORCH_ENABLE_MPS_FALLBACK=1` is rejected to avoid silently mixing inference devices. MPS model operations, half-precision numerical stability and performance remain untested. macOS ARM64 is not CUDA: the vendor’s vLLM and bitsandbytes4-bit examples are outside this implementation. No claim that those packages cannot ever support Metal is made.

The official [PyTorch MPS guide](https://docs.pytorch.org/docs/stable/notes/mps.html) describes the backend. [Hugging Face Apple Silicon documentation](https://huggingface.co/docs/transformers/perf_train_special) notes unified memory and incomplete operation coverage. [SNAC source](https://github.com/hubertsiuzdak/snac/blob/main/snac/snac.py) provides local from_config construction and decode. This adapter uses local construction plus `torch.load(..., weights_only=True, map_location="cpu")`, not a Hub fallback. Transformers uses `local_files_only=True`, `trust_remote_code=False`, safetensors-only weights, SDPA and explicit device_map.

## Memory and disk: 16 GiB is a constraint, not a qualification

- Maya1 BF16/FP16 parameter storage is about6.15GiB; Veena about7.05GiB. Float32 doubles this before any codec, activation, cache or loading buffers.
- The planning gate reserves3GiB beyond parameter bytes and caps the explicit model-worker budget at12GiB on the16GiB host. This is a conservative admission heuristic, **not measured peak memory or a memory limiter**. The operating system and other apps share the same physical RAM.
- Only one model worker should be loaded at a time. The parent must monitor actual RSS/unified memory and terminate on pressure. A subprocess boundary is recommended to release allocator caches reliably.
- Leave at least10GiB disk free for one model plus codec and download/runtime overhead; both public models need roughly14GB of checkpoint bytes alone, so20GiB+ free is a more useful provisioning target for both. Do not infer peak disk use from compressed network size.
- The macOS host still lacks disk headroom for Maya weights. The live Veena download and execution occurred only on the disposable Runpod GPU Pod, which was deleted after artifact capture.

## What the adapter actually does

Maya1 receives the vendor’s special-token sequence around `<description="..."> text`; emotion tags in text are retained. Veena receives its `<spk_kavya>`, `<spk_agastya>`, `<spk_maitri>` or `<spk_vinaya>` conditioning and different special-token sequence. No language code is sent to the model: the selected locale is an annotation, with the model-specific documented language set enforced before loading.

Generation uses explicit sampling controls and seed, a caller-specified28–2048 maximum new-token budget, and a conservative combined input/output context ceiling of2048. The sampler uses the correct model-specific EOS IDs; Maya1’s28-token minimum follows its example, while Veena receives no artificial minimum. Both use KV caching explicitly for this local measurement profile, even though Maya1’s checkpoint config defaults use_cache=false.

Audio tokens are de-interleaved into SNAC’s1:2:4 hierarchical levels. Veena validates each slot’s codebook offset; Maya1 follows its documented modulo mapping. An absent terminal marker or incomplete7-token frame causes failure rather than silently returning truncated speech. Non-audio tokens before the terminator are counted. Maya1 trims the initial2048 samples when present, matching its example; Veena is not trimmed. Output is mono24kHz PCM16. No resampling or telephony codec conversion occurs.

This is batch generation. Streaming, real-time first-audio latency, model cancellation, cloning, SSML, pronunciation dictionaries, quantized runtimes and commercial-hosted parity are not implemented. Runtime metadata reports exact artifact identities, dependency versions, model/codec revisions, device/dtype, initialization/synthesis duration, terminal/frame statistics and trimming. It does not claim perceptual quality.

## Example configuration (paths must be provisioned separately)

```json
{
  "model": "maya-research/Veena",
  "model_revision": "8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f",
  "model_path": "/absolute/provisioned/veena",
  "codec_revision": "d73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec",
  "codec_path": "/absolute/provisioned/snac_24khz",
  "language": "hi-IN", "voice": "kavya",
  "device": "mps", "dtype": "float16", "format": "pcm_s16le",
  "max_new_tokens": 512, "temperature": 0.4, "top_p": 0.9,
  "repetition_penalty": 1.05, "seed": 42, "memory_budget_gib": 12
}
```

For Maya1, change model/revision, use English locale, replace voice with an explicit description and use the Maya1 snapshot. The parent must dispatch to `synthesize_local` directly or add an explicit provider profile; the shared registry/catalog was intentionally left untouched.

## Verification scope

Eleven offline tests cover exact prompt IDs, literal SNAC hierarchy, premature/truncated output rejection, profile/language/model limits, snapshot integrity, no-download rejection, CPU/MPS/CUDA planning gates, invalid controls, delimiter validation and runtime call wiring that forbids remote loading. The runtime wiring test uses mocks. Runpod execution captured three Veena WAVs and one Maya1 WAV on CUDA; neither run measured perceptual quality, concurrency or sustained memory.
