# On-prem Indic TTS decision pack

Evidence cutoff: **16 September 2026**. This report separates executed inference from publisher documentation. A generated WAV proves that the pinned model ran; it does not prove accent, pronunciation or naturalness until the blind review is scored.

## Decision

| Requirement | Current result | Decision |
|---|---|---|
| Lowest-cost Hindi batch TTS | Kokoro ran on Apple Silicon CPU at about 0.18 synthesis seconds per second of saved audio after warm-up | Keep as the cost baseline |
| Hindi + English/code-mix from one Indian publisher | Veena ran on an RTX 4090 and produced Hindi, English-request and code-mixed WAVs | Keep for listening review; it is batch-only and has four fixed speakers |
| Prompted English accent/emotion | Maya1 ran on an RTX 4090 and produced the requested Indian-English prompt | Keep as an English expressive baseline; the publisher does not certify an `en-IN` locale |
| Production streaming Hindi with word-level input, flush, timestamps, SSML and dictionaries | NVIDIA Magpie Multilingual documents these controls; hosted Hindi WAV verified | Keep as a streaming candidate; require a warm self-hosted latency/load run before purchase |
| Broad Indic coverage with permissive commercial terms | SPRING_F5 and Indic Parler-TTS have the strongest current paper specification | Next models to execute |
| Broad Indic zero-shot cloning | IndicF5 and SPRING_F5 expose reference-conditioned synthesis | Execute after access/license checks; IndicF5 does not cover Urdu or English |
| Qwen Hindi and Indian-English cloning | Official Base Indian-English fixture passed lexical entity recovery; community Hindi LoRA failed the bounded run | Keep the official Base as a batch cloning reference; reject the tested Hindi LoRA revision |

Indic Parler-TTS now has one exact-model output for each of the 12 requested locales through AI4Bharat's official Space. This proves model output availability but is not our self-hosted deployment proof. For a commercial on-prem shortlist, prioritize **Indic Parler-TTS**, then evaluate **SPRING_F5** and conditional **Indic-Speak** only after their Indian-English/license gaps are resolved. Sooktam-2, Dhee-Indic-F5, XTTS-v2 and MMS are restricted to non-commercial use unless separate terms are obtained.

## Exact language support

`Yes` means the exact pinned model explicitly documents the language. An English model that can be prompted for an accent is not counted as an `en-IN` locale.

| Exact model | hi-IN | en-IN | bn-IN | mr-IN | te-IN | ta-IN | gu-IN | kn-IN | ml-IN | ur-IN | or-IN | pa-IN |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Kokoro-82M `f3ff357…` | Yes | No | No | No | No | No | No | No | No | No | No | No |
| Veena `8b770f9…` | Yes | No | No | No | No | No | No | No | No | No | No | No |
| Maya1 `21c682a…` | No | No | No | No | No | No | No | No | No | No | No | No |
| Magpie Multilingual `1.10.0` | Yes | No | No | No | No | **No** | No | No | No | No | No | No |
| Official Qwen3-TTS 1.7B Base `022e286…` | No | No | No | No | No | No | No | No | No | No | No | No |
| Community Aguken Qwen 1.7B Hindi LoRA `b847662…` | Yes | No | No | No | No | No | No | No | No | No | No | No |

Veena supports generic English and Maya1 supports multi-accent English. Neither pinned card identifies an `en-IN` locale, so both are `No` for exact-locale support. Their saved English WAVs remain useful blind-review candidates.

NVIDIA's Tamil statement is about **Parakeet ASR**, not Magpie TTS. The current 26.07 TTS matrix exhaustively lists 12 Magpie locales and contains Hindi but no Tamil. The detailed evidence is in [ON_PREM_LANGUAGE_FEATURE_AUDIT.md](ON_PREM_LANGUAGE_FEATURE_AUDIT.md).

## Feature result by exact model

| Parameter | Kokoro | Veena | Maya1 | Magpie 1.10.0 |
|---|---|---|---|---|
| Self-hosted execution | Passed locally | Passed on Runpod | Passed on Runpod | Failed to become ready on L40S in 29.5 min; resources deleted |
| Batch audio | Passed | Passed | Passed | Passed through hosted NVIDIA Build endpoint |
| Incremental text input | No tested implementation | No | No tested implementation | Yes, documented |
| Streaming playable audio | No; generator returned complete segments | No | Publisher says yes; not measured | Yes, documented |
| Flush control | No | No | No | Yes, documented |
| Word timestamps | No | No | No | Yes, documented |
| Pronunciation control | Inline phonemes | No documented interface | No documented interface | Dictionary + SSML subset |
| Speed/pacing | Numeric speed passed | No documented control | Natural-language pacing | No explicit speed control found |
| Emotion control | No documented control | No; publisher roadmap | Yes, tags/descriptions | Model-wide yes; current Hindi voices have no emotion variants |
| Built-in voice cloning | No | No | No | No; separate restricted Zeroshot NIM |
| Cross-language voice | No evidence | No evidence | No; English-only | Yes, documented |
| Native G.711 / 8 kHz telephony output | No | No; 24 kHz PCM | No; 24 kHz PCM | No; LINEAR_PCM output |
| Barge-in building blocks | Application cancellation not tested | Application cancellation not tested | Application cancellation not tested | Incremental input + flush are documented; application must cancel playout/request |
| Data residency | Deployment controlled | Deployment controlled | Deployment controlled | Deployment controlled |

For a voice bot, barge-in is an orchestration property: detect speech with VAD/ASR, stop local playout immediately, cancel or discard the current TTS stream, and start the new response. A telephone call is not required to verify the TTS portion. The correct test is a streaming request with a timed interruption, measuring stop latency and confirming that no post-cancel frames reach the playout buffer. The current pack does not claim that measurement for any of the four models.

### Qwen streaming and barge-in result

| Parameter | Official open Qwen3-TTS 1.7B Base | Community Aguken Hindi LoRA |
|---|---|---|
| Batch waveform | Yes; official `generate_voice_clone()` returns `List[np.ndarray]` plus sample rate | Same Base-model API |
| Playable incremental audio from released Python API | No | No |
| `non_streaming_mode=False` | Simulates streaming text input; official docstring explicitly says it does not enable true streaming input or generation | Same inherited behavior |
| vLLM online serving | No; official README says offline inference only | No documented community server |
| Flush API | No | No |
| Per-request cancellation API | No | No |
| Voice-bot barge-in | Stop playout immediately and terminate/discard the in-flight batch result; latency must be measured | Same; no stronger claim from the derivative |
| Voice cloning | Yes; `ref_audio` + `ref_text`, or lower-quality x-vector-only mode | Yes; supplied male/female Hindi references plus Base cloning |
| Emotion control | No discrete control in Base clone API | No documented discrete control |

The Qwen architecture paper and marketing describe streaming generation, but the current self-hosted release does not expose it as playable chunks. The exact audited upstream revision is [`022e286`](https://github.com/QwenLM/Qwen3-TTS/tree/022e286b98fbec7e1e916cb940cdf532cd9f488e); the relevant wrapper is [`qwen3_tts_model.py`](https://github.com/QwenLM/Qwen3-TTS/blob/022e286b98fbec7e1e916cb940cdf532cd9f488e/qwen_tts/inference/qwen3_tts_model.py).

## Executed recordings

| Model | Executed language label | Output | Synthesis evidence |
|---|---|---|---|
| Kokoro-82M | Hindi | [WAV](../ui/public/evidence/audio/5a4fe57acf1c491d86a9eda00932077a.wav) | Apple Silicon CPU, warm synthesis/audio ratio about 0.18 |
| Kokoro-82M | US English | [WAV](../ui/public/evidence/audio/a808945fd7d441ea8e980e39d6fefdd3.wav) | Apple Silicon CPU |
| Veena | Hindi | [WAV](../ui/public/evidence/audio/veena-hi-IN-kavya.wav) | RTX 4090, 2.22 s audio |
| Veena | English request | [WAV](../ui/public/evidence/audio/veena-en-IN-agastya.wav) | RTX 4090, 2.82 s audio; accent not certified |
| Veena | Hindi-English mix | [WAV](../ui/public/evidence/audio/veena-hi-en-maitri.wav) | RTX 4090, 2.05 s audio |
| Maya1 | Indian-English prompt | [WAV](../ui/public/evidence/audio/maya1-en-IN.wav) | RTX 4090, 4.86 s audio; accent not certified |
| Magpie Multilingual | Hindi | [WAV](../ui/public/evidence/audio/nvidia-magpie--hi-IN.wav) | Hosted NVIDIA Build exact-model route; 4.46 s audio, 1.62 s request including discovery |
| Qwen3-TTS 1.7B Base | Indian-English clone fixture | [WAV](../ui/public/evidence/audio/qwen3-base-en-IN.wav) | RTX 4090; 4.56 s audio, 10.47 s synthesis, RTF 2.30; all amount/date entities recovered by ASR |
| Aguken Qwen Hindi LoRA | Hindi failure fixture | [WAV](../ui/public/evidence/audio/qwen3-hindi-lora-hi-IN.wav) | RTX 4090; 40.88 s cap-hit output, 124.78 s synthesis, RTF 3.05; empty ASR transcript, WER/CER 1.00 |

Use the shareable [blind review ZIP](../artifacts/on-prem-blind-review.zip) to score the nine recordings without model names. Keep [the private key](../artifacts/on-prem-blind-review/private-key.json) hidden until scores are frozen. Review the 12 Indic Parler outputs in [ON_PREM_CANDIDATE_OUTPUTS.md](ON_PREM_CANDIDATE_OUTPUTS.md).

Score each clip from 1–5 for naturalness, pronunciation, accent fit, intelligibility and entity fidelity. Do not average unmatched prompts into a provider MOS.

## Hardware and system requirements

| Model | Model size / storage | Publisher minimum | Executed configuration | Practical starting point |
|---|---|---|---|---|
| Kokoro-82M | 82M parameters | No minimum published; CPU inference supported by the public package | macOS 15.6.1 ARM64, Python 3.12.12, CPU, two PyTorch threads; peak process RSS 1.77 GiB | Modern 4-core CPU, 4 GiB free RAM per worker; benchmark concurrency on target CPU |
| Veena | 3.783B parameters; selected model files 7.59 GB + 79 MB SNAC | No minimum published | RTX 4090, 23.53 GiB VRAM, FP16 model, CPU SNAC decoder; planned weights+reserve 10.05 GiB | 16 GiB NVIDIA GPU minimum for one worker; 24 GiB gives safer loading/cache headroom; 20 GiB disk for model/runtime |
| Maya1 | 3.301B parameters; selected model files 6.63 GB + 79 MB SNAC | Card states single GPU with 16 GB+ VRAM | RTX 4090, 23.53 GiB VRAM, FP16 model, CPU SNAC decoder; planned weights+reserve 9.15 GiB | 16 GiB NVIDIA GPU minimum, 24 GiB preferred; 20 GiB disk |
| Magpie NIM 1.10.0 | Container + cached model; profile dependent | NVIDIA compute capability 8.0+, 16 GB VRAM, Linux, driver 535+, NVIDIA Docker 23.0.1+ | Hosted Build passed; L40S `batch_size=8` self-hosted cold start failed readiness at 29.5 min | `batch_size=8`: 12.58 GiB GPU + 5.182 GiB host RAM; larger profiles require 41.46/74.74 GiB GPU; keep a worker warm |

The Maya memory values above are admission estimates around actual FP16 weight sizes, not peak measurements. Kokoro's RSS is a measured process-lifetime high-water mark. Magpie values are NVIDIA's current profile reservations.

## Licenses and commercial deployment

| Model | Weights/model license | Runtime/code terms | Commercial conclusion |
|---|---|---|---|
| Kokoro-82M | Apache-2.0 | Kokoro/Misaki and dependencies retain their own notices | Commercial self-hosting is permitted; retain license, notices and modification notices on redistribution |
| Veena | Apache-2.0 | Transformers, PyTorch, SNAC and dependencies apply separately | Commercial self-hosting is permitted under the checkpoint license |
| Maya1 | Apache-2.0 | Transformers, PyTorch, SNAC and dependencies apply separately | Commercial self-hosting is permitted under the checkpoint license |
| Magpie Multilingual | Current Model Card++ says NVIDIA Open Model License; captured NGC/Build surfaces have used Community wording | NIM container is separately under NVIDIA Software License Agreement and AI Product-Specific Terms | Evaluation is allowed under the current developer entitlement; production eligibility must be checked against the pulled tag/digest and NVIDIA entitlement |
| Indic Parler-TTS | Apache-2.0 | Parler/Transformers dependencies | Strong commercial candidate; preserve notices. Dataset provenance should still receive legal review |
| SPRING_F5 | HF repository declares Apache-2.0 | Referenced inference repository has no detected license file | Model is promising; obtain written clarity for the required inference code before product distribution |
| IndicF5 | HF model repository declares MIT | Referenced GitHub package has no license file | Resolve code-license ambiguity before commercial packaging |
| Indic-Speak | Indic Open Model License v1.0 | Custom restrictions, share-alike conditions and hosted-service approval rules | Legal review required before offering it as a hosted product |
| Sooktam-2 | BharatGen non-commercial | Publisher terms | Evaluation only without a separate commercial license |
| Dhee-Indic-F5 | CC-BY-NC-4.0 | Publisher offers separate commercial discussions | Evaluation only under public terms |
| XTTS-v2 | CPML for weights and outputs | MPL-2.0 code | Non-commercial under public model terms |
| Meta MMS-TTS | CC-BY-NC-4.0 checkpoints | MIT fairseq code | Non-commercial under public checkpoint terms |
| Official Qwen3-TTS | Apache-2.0 model and repository | `qwen-tts`, PyTorch, Transformers and dependencies retain their terms | Commercial self-hosting is permitted under Apache-2.0; retain notices |
| Community Aguken Qwen Hindi/Indic LoRAs | Cards declare Apache-2.0; source Rasa dataset is CC-BY-4.0 | PEFT plus the official Qwen runtime | Technically permissive, with attribution/notices; archive exact model and dataset terms before production |

This is an engineering license inventory, not legal advice. Before production, archive the exact license files next to the pinned artifacts and have counsel review custom/NVIDIA terms.

## Can Kokoro learn additional Indian languages through LoRA?

**Not through an official, supported Kokoro LoRA path.** The published Kokoro repository and model card provide inference assets, not a maintained LoRA trainer. Kokoro is derived from StyleTTS2, but the released Kokoro artifact is decoder-only and its upstream training stack is not a drop-in adapter workflow for Kokoro weights.

The technically credible paths are:

1. **Full or partial StyleTTS2 fine-tuning.** Upstream provides `train_finetune.py` and `train_finetune_accelerate.py`. Its example fine-tunes with about one hour/1,000 samples for 50 epochs and reports about four hours on four A100 GPUs. That recipe targets upstream StyleTTS2 checkpoints, not a validated Kokoro conversion.
2. **Custom parameter-efficient adapters.** LoRA could be engineered around compatible linear layers, but module selection, checkpoint conversion, optimizer state, speaker/style retention and export back into the Kokoro runtime all require new implementation and validation. There is no vendor-supported compatibility guarantee.
3. **New-language work beyond adapters.** Add a grapheme-to-phoneme/phonemizer path, normalized text rules, lexicon tests, aligned speech/transcripts, language-balanced training, and regression tests for existing voices. A LoRA alone cannot add reliable phonemization or pronunciation rules.

For this project, extending Kokoro is a research track, not the shortest production route. Execute Indic Parler-TTS, SPRING_F5 and IndicF5 first because their published checkpoints already cover the required scripts. Kokoro remains useful when Hindi plus low CPU cost is sufficient.

## Additional on-prem candidates

| Priority | Model | Requested coverage | Style/cloning | License position | Why it is here |
|---:|---|---|---|---|---|
| 1 | Indic Parler-TTS | Hindi, Bengali, Gujarati, Kannada, Malayalam, Marathi, Odia, Tamil, Telugu, Urdu, English; Punjabi unofficial; Indian-English accents claimed | 69 named voices; descriptive emotion, pitch and rate | Apache-2.0 | Best current combination of breadth, style control and permissive model license |
| 1 | SPRING_F5 | All 11 requested Indic languages + generic English | Reference-conditioned zero-shot voice | Apache-2.0 model; inference-code ambiguity | Broadest permissive F5 candidate |
| 2 | IndicF5 | Hindi, Bengali, Gujarati, Kannada, Malayalam, Marathi, Odia, Punjabi, Tamil, Telugu; no Urdu/English | Reference audio + transcript cloning | MIT model; inference-code ambiguity | Compact 350.7M cloning candidate |
| 2 | Indic-Speak preview-v2 | All requested Indic languages + English | 95 fixed voices; preview emotion/style; no cloning | Custom Indic Open Model License | Strong coverage with significant legal conditions |
| 3 | Sooktam-2 | Full requested set including named Indian English | 3–10 s reference cloning | Non-commercial | Strong evaluation reference, not a public commercial choice |
| 3 | Quipus 0.6 Speech v2 | All requested Indic languages; no English | 44 fixed voices; emotion/streaming on roadmap | MIT metadata | Promising but expanded-language samples and formal metrics are incomplete |
| Baseline | Chatterbox Multilingual V3 | Hindi + generic English | Zero-shot cloning + exaggeration | MIT | Useful Hindi cloning baseline; not broad Indic coverage |
| Baseline | Official Qwen3-TTS 1.7B Base + community Aguken Hindi LoRA | Official generic English cloning; community Hindi | 3-second reference cloning; Hindi male/female LoRA adapters | Apache-2.0 cards; Rasa CC-BY-4.0 | Evaluate Indian-English cloning and Hindi separately; current open runtime is batch-only |
| Baseline | Vakyansh | Nine requested Indic languages + generic English | Fixed voices; speed/noise controls | MIT code/checkpoint repository | Older CPU/GPU fallback |

The full 12-model comparison, exact revisions, hardware disclosures, restrictions, and recent negative feedback are in [OTHER_ON_PREM_OPTIONS.md](OTHER_ON_PREM_OPTIONS.md). Publisher likes/downloads are adoption signals, not quality ratings. A model is not promoted to production based on a model-card claim or repository popularity.

## Reproducible implementation and tests

| Purpose | Code | Evidence |
|---|---|---|
| Kokoro bounded local qualification | [`scripts/qualify_kokoro_local.py`](../scripts/qualify_kokoro_local.py) | [`KOKORO_LOCAL_QUALIFICATION.md`](KOKORO_LOCAL_QUALIFICATION.md) |
| Kokoro result aggregation | [`tts_arena/kokoro_qualification.py`](../tts_arena/kokoro_qualification.py) | `artifacts/local-20260915/kokoro/` |
| Maya1/Veena exact local adapter | [`tts_arena/adapters/maya_local.py`](../tts_arena/adapters/maya_local.py) | [`MAYA_LOCAL_IMPLEMENTATION.md`](MAYA_LOCAL_IMPLEMENTATION.md) |
| Maya adapter tests | [`tests/test_maya_local.py`](../tests/test_maya_local.py) | Exact prompt, token, codec, language and snapshot guards |
| NVIDIA launch/preflight | [`scripts/nvidia_nim_preflight.py`](../scripts/nvidia_nim_preflight.py) and [`scripts/runpod_nim_pod.py`](../scripts/runpod_nim_pod.py) | Exact `1.10.0`, L40S, price/resource/cleanup gates |
| NVIDIA readiness/discovery/synthesis | [`scripts/runpod_nim_pilot.py`](../scripts/runpod_nim_pilot.py) | Health, metadata, version, live voice discovery, one Hindi request, immediate deletion |
| NVIDIA hosted functional check | [`scripts/nvidia_build_magpie_hindi.py`](../scripts/nvidia_build_magpie_hindi.py) | Live inventory + one Hindi WAV through NVIDIA Build |
| Indic Parler official outputs | [`scripts/official_indic_parler_suite.py`](../scripts/official_indic_parler_suite.py) | One output for each requested locale through AI4Bharat's official Space |
| NVIDIA adapter | [`tts_arena/adapters/nvidia.py`](../tts_arena/adapters/nvidia.py) | HTTP WAV decoding and run record |
| Blind package | [`scripts/package_on_prem_blind_review.py`](../scripts/package_on_prem_blind_review.py) | [`on-prem-blind-review.zip`](../artifacts/on-prem-blind-review.zip) |
| Exact language/feature record | [`on-prem-language-feature-audit-20260916.json`](../artifacts/on-prem-language-feature-audit-20260916.json) | 4 models × 12 target locales × 17 feature fields |

Every executed run pins the model revision or container tag, records dependency versions where available, validates mono PCM16 WAV output, and retains hashes. The NVIDIA scripts also cap hourly price and startup time and delete the Pod and temporary registry credential in `finally` plus an independent guard process.

## Remaining gate before a purchase decision

1. Freeze the seven current blind scores and separately score the 12 Indic Parler locale clips.
2. Complete a warm self-hosted Magpie run only if NVIDIA remains a finalist; the hosted functional check passed, while the L40S cold start did not.
3. Replay the saved Indic Parler suite from locally provisioned weights after the gated checkpoint CAPTCHA is completed, then test SPRING_F5 on the same GPU class if Indian-English evidence is supplied.
4. Score the completed Qwen Indian-English fixture. The tested Aguken Hindi LoRA revision failed lexical qualification and should not proceed unless a corrected checkpoint is published.
5. Measure time to first playable audio, real-time factor, peak VRAM/RAM, timed cancellation, sustained concurrency and cost per audio hour. For Qwen, record the current batch-only limitation rather than counting architecture-level streaming as a working server feature.
6. Obtain native listener scores for every production language and legal approval for any non-Apache/MIT or ambiguous code license.
