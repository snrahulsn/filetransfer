"""Create independently verifiable ZIP parts, each below 20 MB."""
from __future__ import annotations
import hashlib, json, pathlib, shutil, zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/"SHARE_EVIDENCE_PACK_FINAL"
LIMIT=19_000_000

def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def collect():
    files=[]
    direct=[ROOT/"BENCHMARK_REPORT.html",ROOT/"BENCHMARK_REPORT.pdf",ROOT/"GIT_SETUP.md",
            ROOT/"execution/final_shutdown_verification.json",ROOT/"execution/metadata_corrections.json"]
    roots=[ROOT/"LISTENING_REVIEW",ROOT/"execution/fresh_current",ROOT/"execution/sources",
           ROOT/"execution/dataset_sources",ROOT/"indic_speech_benchmark_prd_v1",ROOT/"benchmark_runtime"]
    for p in direct:
        if p.is_file(): files.append(p)
    for base in roots:
        if not base.exists(): continue
        for p in base.rglob("*"):
            if not p.is_file() or "__pycache__" in p.parts: continue
            if "grok" in p.name.lower(): continue
            files.append(p)
    files.extend(sorted((ROOT/"execution").glob("lease-*.json")))
    return sorted(set(files))

def main():
    shutil.rmtree(OUT,ignore_errors=True); OUT.mkdir()
    rows=[]; parts=[]; current=[]; current_size=0
    for p in sorted(collect(),key=lambda x:x.stat().st_size,reverse=True):
        n=p.stat().st_size
        if n>=LIMIT: raise SystemExit(f"single file too large: {p} ({n})")
        if current and current_size+n>17_500_000: parts.append(current);current=[];current_size=0
        current.append(p);current_size+=n
    if current: parts.append(current)
    for i,group in enumerate(parts,1):
        name=f"evidence_part_{i:02d}.zip"; target=OUT/name
        with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED,compresslevel=6,strict_timestamps=False) as z:
            for p in group:
                rel=p.relative_to(ROOT).as_posix();z.write(p,rel)
                rows.append({"path":rel,"bytes":p.stat().st_size,"sha256":sha(p),"part":name})
        if target.stat().st_size>=20_000_000: raise SystemExit(f"part exceeds 20MB: {target}")
    manifest={"schema_version":1,"grok_reviews_included":False,"files":sorted(rows,key=lambda r:r["path"]),
              "parts":[{"name":p.name,"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(OUT.glob("*.zip"))]}
    (OUT/"MASTER_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
    (OUT/"README.md").write_text("# Indic speech benchmark evidence pack\n\nExtract every ZIP into the same directory. Open `BENCHMARK_REPORT.html`; use `LISTENING_REVIEW/index.html` for one 1-5 score per clip. Verify each file and ZIP with `MASTER_MANIFEST.json`. Grok reviews are intentionally excluded.\n")
    print(json.dumps({"parts":len(parts),"files":len(rows),"largest_part_bytes":max(p.stat().st_size for p in OUT.glob('*.zip'))},indent=2))

if __name__=="__main__": main()
