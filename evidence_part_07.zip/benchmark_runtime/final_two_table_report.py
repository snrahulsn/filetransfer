"""Build the final one-page, two-table benchmark report from preserved evidence."""
from __future__ import annotations

import hashlib
import html
import json
import pathlib
import statistics
from urllib.parse import quote

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA = ROOT / "execution" / "fresh_current"
OUT = ROOT / "BENCHMARK_REPORT.html"
LANGS = [("hi-IN", "HI"), ("en-IN", "EN-IN"), ("bn-IN", "BN"), ("mr-IN", "MR"),
         ("ta-IN", "TA"), ("te-IN", "TE"), ("gu-IN", "GU"), ("kn-IN", "KN"),
         ("ml-IN", "ML"), ("or-IN", "OR")]
NAMES = {
 "A01":"SraVaani 0.5 Live","A02":"Voxtral Mini 4B Realtime","A03":"SraVaani 1.0","A04":"IndicConformer 600M","A05":"OmniASR CTC 1B","A06":"OmniASR CTC 300M","A07":"Qwen3-ASR 1.7B","A08":"Whisper large-v3-turbo","A09":"Qwen3-ASR 0.6B","A10":"Whisper large-v3","A11":"Shrutam-2","A12":"VibeVoice-ASR","A13":"VibeVoice Streaming 1.5B","A14":"IndicWhisper checkpoints","A15":"MMS ASR 1B All",
 "T01":"Svara-TTS","T02":"Pocket TTS","T03":"Kokoro 82M","T04":"Indic Parler-TTS","T05":"Maya1","T06":"Bodhan Indic-Speak","T07":"Veena","T08":"IndicF5","T09":"Sooktam-2","T10":"Voxtral TTS","T11":"Qwen3-TTS Hindi adapter","T12":"Qwen3-TTS Base","T13":"Chatterbox","T14":"Chatterbox Hindi","T15":"VoxCPM2","T16":"Fish S2 Pro","T17":"XTTS-v2","T18":"MMS-TTS checkpoints","T19":"Qwen3-TTS Indic adapters"}
ASR_STREAM = {"A01","A02","A07","A09","A13"}
TTS_MODE = {
 "T01":("Yes","native_stream"),"T02":("Yes","native_stream"),"T03":("Yes","completed_segment_stream"),
 "T04":("Yes","stream"),"T05":("Yes","native_stream"),"T06":("No","full"),
 "T07":("No","full"),"T08":("No","full"),"T09":("No","full"),
 "T10":("Yes","native_stream"),"T11":("No","full"),"T12":("Yes","native_stream"),
 "T13":("No","full"),"T14":("No","full"),"T15":("Yes","stream"),
 "T16":("Yes","native_stream"),"T17":("Yes","native_stream"),"T18":("No","full"),
 "T19":("No","full")}
LICENCE = {"A11":"BharatGen research","A14":"MIT","T06":"Indic OML v1","T09":"BharatGen research","T16":"Fish Audio research","T17":"Coqui PML 1.0","T18":"CC-BY-NC-4.0"}
OVERRIDE = {"A04":set("hi bn mr ta te gu kn ml or".split()),"A14":set("hi bn mr ta te gu kn ml or".split()),
            "T17":{"en"},"T18":set("hi en bn mr ta te gu kn ml or".split())}

def read_json(path, default=None):
    try: return json.loads(path.read_text())
    except Exception: return default

def read_jsonl(path):
    if not path.is_file(): return []
    rows=[]
    for line in path.read_text().splitlines():
        try: rows.append(json.loads(line))
        except json.JSONDecodeError: pass
    return rows

def href(path): return quote(path.resolve().relative_to(ROOT).as_posix())

def supported(item, locale):
    mid=item["model_id"]; lang=locale[:2]
    if mid in OVERRIDE: return lang in OVERRIDE[mid]
    declared=item.get("declared_languages")
    return None if not isinstance(declared,list) else lang in {str(x).lower() for x in declared}

def repo_url(repo):
    return repo if str(repo).startswith("http") else "https://huggingface.co/"+str(repo)

def evidence(mid, record_file):
    audit=ROOT/"execution"/"sources"/mid/"audit.json"
    links=[]
    if record_file.is_file(): links.append(f'<a href="{href(record_file)}" title="raw records">data</a>')
    if audit.is_file(): links.append(f'<a href="{href(audit)}" title="source audit">src</a>')
    return " ".join(links)

def device(mid):
    vals=[]
    for p in (DATA/mid).glob("environment*.json"):
        d=read_json(p,{}) or {}; v=d.get("gpu") or d.get("hardware") or d.get("device")
        if v: vals.append(str(v).replace("NVIDIA GeForce ","").replace("NVIDIA ",""))
    if not vals: return "GPU"
    v=sorted(set(vals))[-1]
    return {"arm":"CPU"}.get(v,v.replace("RTX 6000 Ada Generation","RTX 6000 Ada").replace("RTX PRO 4000 Blackwell","RTX PRO 4000"))

def licence(item): return LICENCE.get(item["model_id"],str(item.get("license") or "See source"))

def asr_rows(inventory):
    out=[]
    for item in (x for x in inventory if x["model_id"].startswith("A")):
        mid=item["model_id"]; path=DATA/mid/"frozen_records.jsonl"; rows=[r for r in read_jsonl(path) if r.get("ok")]
        cells=[]; all_edits=all_words=0
        for locale,_ in LANGS:
            rs=[r for r in rows if r.get("locale")==locale]
            edits=sum(int(r.get("word_edits",0)) for r in rs); words=sum(int(r.get("reference_words",0)) for r in rs)
            if words:
                val=100*edits/words; all_edits+=edits; all_words+=words
                cells.append(f'<td class="metric" style="--e:{min(val,100):.1f}" title="{len(rs)} frozen clips; {edits}/{words} word edits"><a href="{href(path)}">{val:.1f}</a></td>')
            elif supported(item,locale) is False: cells.append('<td class="na" title="Language is outside the publisher-declared model coverage">N/S</td>')
            else: cells.append('<td class="na" title="No valid benchmark result for this model-language pair">—</td>')
        avg=f"{100*all_edits/all_words:.1f}" if all_words else "—"
        model=f'<a class="model" href="{repo_url(item["repo"])}"><b>{mid}</b> {html.escape(NAMES[mid])}</a><small>{evidence(mid,path)}</small>'
        out.append(f'<tr><td>{model}</td><td><span class="yn">{"Yes" if mid in ASR_STREAM else "No"}</span></td><td>{html.escape(device(mid))}</td><td>{html.escape(licence(item))}</td>{"".join(cells)}<td class="avg">{avg}</td></tr>')
    return "".join(out)

def choose_audio(row, mid):
    f=row.get("file")
    if not f: return None
    candidates=[DATA/f, DATA/mid/pathlib.Path(str(f)).name, ROOT/str(f)]
    for p in candidates:
        if p.is_file():
            if row.get("sha256") and hashlib.sha256(p.read_bytes()).hexdigest()!=row["sha256"]: continue
            return p
    return None

def owner_scores():
    d=read_json(ROOT/"execution"/"listening_ratings_current.json",{}) or {}; scores={}
    for r in d.get("rows",[]):
        s=(r.get("ratings") or {}).get("Overall")
        if type(s) is int and 1<=s<=5: scores.setdefault((r.get("model_id"),r.get("locale"),r.get("mode")),[]).append(s)
    return scores

def blind_samples():
    rows=read_json(ROOT/"LISTENING_REVIEW"/"blind_key.json",[]) or []; result={}
    for r in rows:
        mid=str(r.get("model_id","")); locale=r.get("locale")
        if mid in TTS_MODE and (mid,locale) not in result:
            clip=ROOT/"LISTENING_REVIEW"/"clips"/(str(r["id"])+pathlib.Path(str(r.get("source_file",".flac"))).suffix)
            if clip.is_file() and hashlib.sha256(clip.read_bytes()).hexdigest()==r.get("sha256"):
                result[(mid,locale)]=clip
    return result

def tts_rows(inventory):
    scores=owner_scores(); blind=blind_samples(); out=[]
    for item in (x for x in inventory if x["model_id"].startswith("T")):
        mid=item["model_id"]; stream,mode=TTS_MODE[mid]; path=DATA/mid/"records.jsonl"; raw=[r for r in read_jsonl(path) if r.get("ok")]
        chosen=[r for r in raw if str(r.get("mode"))==mode]
        ttfa=[float(r["ttfa_s"]) for r in chosen if r.get("ttfa_s") is not None]
        rtf=[float(r["rtf"]) for r in chosen if r.get("rtf") is not None]
        cells=[]
        for locale,_ in LANGS:
            rs=[r for r in chosen if r.get("locale")==locale]
            row=rs[0] if rs else None
            if row or blind.get((mid,locale)):
                audio=(choose_audio(row,mid) if row else None) or blind.get((mid,locale)); vals=scores.get((mid,locale,mode),[])
                shown=f"{statistics.mean(vals):.1f}" if vals else "▶"
                title=("Your imported overall score" if vals else "Play exact waveform; enter one 1-5 score in Listening Review")
                cells.append(f'<td class="audio"><a href="{href(audio)}" title="{title}">{shown}</a></td>' if audio else '<td class="na">—</td>')
            elif supported(item,locale) is False: cells.append('<td class="na" title="Language is outside the publisher-declared model coverage">N/S</td>')
            else: cells.append('<td class="na" title="No valid waveform for this model-language pair">—</td>')
        model=f'<a class="model" href="{repo_url(item["repo"])}"><b>{mid}</b> {html.escape(NAMES[mid])}</a><small>{evidence(mid,path)}</small>'
        ttfa_text=f"{statistics.median(ttfa):.2f}s" if ttfa else "—"
        rtf_text=f"{statistics.median(rtf):.2f}" if rtf else "—"
        out.append(f'<tr><td>{model}</td><td><span class="yn">{stream}</span></td><td>{html.escape(device(mid))}</td><td>{html.escape(licence(item))}</td><td>{ttfa_text}</td><td>{rtf_text}</td>{"".join(cells)}</tr>')
    return "".join(out)

CSS='''
*{box-sizing:border-box}body{margin:0;background:#f4f6f2;color:#152019;font:12px/1.25 Inter,system-ui,sans-serif}.page{max-width:1800px;margin:auto;padding:20px}.top{display:flex;align-items:end;justify-content:space-between;margin-bottom:10px}.top h1{font-size:27px;margin:0;letter-spacing:-.035em}.top p{margin:3px 0 0;color:#59655e}.stamp{font:10px ui-monospace;color:#59655e;text-align:right}.panel{background:white;border:1px solid #d8dfd9;border-radius:10px;margin:8px 0;padding:10px;box-shadow:0 5px 18px #22332610}.head{display:flex;align-items:end;justify-content:space-between;margin-bottom:6px}.head h2{font-size:16px;margin:0}.head span{color:#59655e;font-size:10px}table{width:100%;border-collapse:collapse;table-layout:fixed}th{background:#edf1ed;color:#435048;text-transform:uppercase;font-size:8px;letter-spacing:.04em;padding:5px 3px;border:1px solid #d7ddd8}td{border:1px solid #e1e5e2;padding:4px 3px;text-align:center;vertical-align:middle;font-size:9px}th:first-child,td:first-child{text-align:left;width:17%}th:nth-child(2),td:nth-child(2){width:4.2%}th:nth-child(3),td:nth-child(3){width:7%}th:nth-child(4),td:nth-child(4){width:7%}.tts th:nth-child(5),.tts td:nth-child(5),.tts th:nth-child(6),.tts td:nth-child(6){width:4.2%}.model{color:#152019;text-decoration:none;font-weight:600}.model b{font:700 8px ui-monospace;color:#276146;background:#e1eee5;border-radius:3px;padding:2px 3px;margin-right:3px}small{float:right;font-size:7px}small a{color:#486d58}.yn{font-weight:750}.metric{background:color-mix(in srgb,#d8eadc calc(100% - var(--e)*.75%),#efcfc5 calc(var(--e)*.75%));font-weight:750}.metric a,.audio a{color:#152019;text-decoration:none;display:block}.audio{background:#e4eee7;font-weight:800}.na{color:#98a19b;background:#f7f8f7}.avg{font-weight:800;background:#edf2ed}.key{color:#59655e;font-size:9px;margin-top:4px}.key a{color:#285e43}@page{size:A2 landscape;margin:7mm}@media print{body{background:white}.page{max-width:none;padding:0}.panel{box-shadow:none;border-radius:0;margin:2.5mm 0;padding:2mm;break-inside:avoid}.top{margin-bottom:1mm}.top h1{font-size:16pt}.top p,.stamp{font-size:6.5pt}.head{margin-bottom:1mm}.head h2{font-size:10pt}.head span,.key{font-size:6pt}th{font-size:5.5pt;padding:1mm .5mm}td{font-size:6.1pt;padding:.75mm .45mm}.model b{font-size:5.5pt}small{font-size:5pt}}
'''

def main():
    inv=read_json(ROOT/"execution"/"sources"/"inventory_audit.json",[])
    heads=''.join(f'<th>{x}</th>' for _,x in LANGS)
    shutdown=read_json(ROOT/"execution"/"final_shutdown_verification.json",{}) or {}
    ts=shutdown.get("verified_at_utc","2026-09-28")
    doc=f'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>On-prem Indic ASR/TTS benchmark</title><style>{CSS}</style></head><body><main class="page"><header class="top"><div><h1>On-prem Indic speech benchmark</h1><p>Frozen 10-clip ASR micro-WER per supported locale; TTS waveforms ready for one owner score from 1 to 5.</p></div><div class="stamp">15 ASR · 19 TTS · 10 locales<br>RunPod: all {shutdown.get("pod_count",13)} records stopped · verified {html.escape(str(ts))}</div></header><section class="panel"><div class="head"><h2>ASR · word error rate (%)</h2><span>Lower is better · each number links to raw records · N/S = outside declared coverage</span></div><table><thead><tr><th>Model / evidence</th><th>Stream</th><th>Test HW</th><th>Licence</th>{heads}<th>Micro</th></tr></thead><tbody>{asr_rows(inv)}</tbody></table></section><section class="panel"><div class="head"><h2>TTS · listening evidence</h2><span>▶ plays the exact waveform · rating cells populate only from your single 1-5 overall score</span></div><table class="tts"><thead><tr><th>Model / evidence</th><th>Stream</th><th>Test HW</th><th>Licence</th><th>TTFA</th><th>RTF</th>{heads}</tr></thead><tbody>{tts_rows(inv)}</tbody></table><div class="key">Rate clips: <a href="LISTENING_REVIEW/index.html">Listening Review</a> · Reproduce and verify: <a href="benchmark_runtime/">code</a> · Corpus and model provenance: <a href="execution/sources/">sources</a> · WER values are computed from summed word edits / summed reference words; hover cells for n and counts.</div></section></main></body></html>'''
    OUT.write_text(doc)
    print(json.dumps({"output":str(OUT),"tables":doc.count("<table"),"asr_rows":doc.count('<b>A'),"tts_rows":doc.count('<b>T')}))

if __name__=="__main__": main()
