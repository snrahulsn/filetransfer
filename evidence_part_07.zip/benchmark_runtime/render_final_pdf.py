"""Render the report to one A3 landscape PDF with an installed Chrome."""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
CHROME=Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=str(CHROME) if CHROME.exists() else None,headless=True)
    page=browser.new_page(viewport={"width":1587,"height":1123})
    page.goto((ROOT/"BENCHMARK_REPORT.html").as_uri(),wait_until="networkidle")
    page.pdf(path=str(ROOT/"BENCHMARK_REPORT.pdf"),print_background=True,width="16.5in",height="11.7in",
             margin={"top":"0.18in","right":"0.18in","bottom":"0.18in","left":"0.18in"})
    browser.close()
