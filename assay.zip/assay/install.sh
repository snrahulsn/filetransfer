#!/bin/sh
# Installs Assay into this folder. Needs Python 3.11 or newer.
set -e
cd "$(dirname "$0")"
python3 -m venv backend/.venv
backend/.venv/bin/pip install --quiet --upgrade pip
backend/.venv/bin/pip install --quiet -r backend/requirements.txt
[ -f .env ] || cp .env.example .env
echo "Installed. Start with ./run.sh"
