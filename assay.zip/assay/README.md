# Assay

Measures how accurate an AI product's output is, per customer, every day, without ground truth.

It samples what the product returned, asks a cheap model to verify each value against the
evidence (never to redo the work), sends only the doubtful ones to a person, and reports
accuracy with honest error ranges. Products and customers are set up in the UI, not in code.

## Start

```bash
./install.sh
```

```bash
./run.sh
```

Open http://localhost:8000. It starts with a demo platform so every screen works with no
keys and no customer data.

## Read next

| File | For |
|---|---|
| `docs/INSTALL.md` | Requirements, moving to another machine, running as a service, upgrading |
| `docs/CONNECT-A-PLATFORM.md` | What your platform's API must return, adding a product and a customer |
| `docs/HOW-IT-WORKS.md` | The daily loop, every statistic, how verdicts are decided |
| `docs/API.md` | HTTP endpoints and the database tables |

## What is in this folder

```
install.sh  run.sh  .env.example
backend/assay/      the engine and API (Python)
web/dist/           the UI, already built; run.sh serves it
web/source/         UI source, only needed to change the UI
docs/
```
