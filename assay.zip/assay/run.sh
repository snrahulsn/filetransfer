#!/bin/sh
# Starts Assay (UI and API together). Open http://localhost:8000
set -e
cd "$(dirname "$0")"
set -a; [ -f .env ] && . ./.env; set +a
exec backend/.venv/bin/uvicorn assay.api:app --app-dir backend --host "${ASSAY_HOST:-127.0.0.1}" --port "${ASSAY_PORT:-8000}"
