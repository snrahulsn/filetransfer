# How it works

## Three levels

| Level | Holds | Stored in |
|---|---|---|
| Core | sampling, judging, statistics, review, reporting | code, never customer-specific |
| Product | endpoints, output mapping, checks and their instructions | `products` table |
| Customer | item types, fields, which checks apply, sample size, audit rate | `customers` table |

Nothing about a product, customer, document type or field is in the code.

## The daily loop

1. **Sample.** Random items from yesterday, the same number from each item type, so small
   types are measured as precisely as large ones (stratified sampling, equal allocation).
2. **Fetch.** The platform's own output and the evidence behind it.
3. **Judge.** One model call per unit. For each claim: right, wrong or unsure, with a
   confidence and a one-line reason. The model verifies; it never re-extracts.
4. **Route.** Unsure verdicts go to a person. So does a random slice of confident ones
   (the audit rate), which measures the judge itself.
5. **Count.** A person's label replaces the judge's verdict. Claims still undecided are
   left out rather than guessed.

## The numbers

**Accuracy of one check** (one item type × one check): right ÷ decided over the trailing
7 days, with a 95% Wilson score interval. Wilson stays honest for small samples and for
rates near 100%, where the textbook interval collapses.

**Baseline**: the same ratio over the first 20 days in view.

**Has it dropped?** The probability that recent accuracy is below baseline accuracy, from
a Beta posterior on each (normal approximation), treating both as uncertain.

**False alarms.** Dozens of checks are tested every day, so some would look bad by chance.
All probabilities are passed through Benjamini–Hochberg at a 5% false-discovery rate.

| Verdict | Rule |
|---|---|
| Act | survives false-discovery control and the drop is at least 2 points |
| Watch | drop of at least 1 point that either survives, or is at least 95% probable |
| Healthy | everything else |

**Headline accuracy** of a customer or product: each check weighted by how many outputs it
represents per day (volume × item-type share × values per item). Its interval adds the
weighted variances, using Agresti–Coull adjusted rates so a perfect small sample still
carries uncertainty.

**Wrong outputs a day**: outputs per day × (1 − headline accuracy). An estimate of what
reaches the customer, not a count.

**Where it concentrates.** For a flagged check, failures from the last 7 days are grouped
by field and by each item attribute. The grouping with the largest gap between "share of
failures" and "share of volume" is shown, if that gap is at least 25 points and there are
at least 8 failures.

**Sample size.** For a ± margin `m` at 95% confidence, expecting about 95% accuracy:
`n = 1.96² × 0.95 × 0.05 ÷ m²` per item type per week. ±3 points needs 203.

## Limits to know about

- Judge error is measured (sidebar: how often people agreed with it on audits) but not yet
  subtracted from the accuracy figures. If agreement falls, raise the audit rate.
- The cause and suggested action are produced by rule from the slice analysis, not written
  by a model.
- Evidence is images only. Audio or text evidence needs a small addition in
  `backend/assay/judge.py`.
- Verdicts need 14 days of samples per check.
- No login. See `INSTALL.md`.
