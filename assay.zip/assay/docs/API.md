# API and data

Base URL: `http://localhost:8000`. JSON in, JSON out. Interactive docs at `/docs`.

| Method | Path | Does |
|---|---|---|
| GET | `/api/state` | Everything the UI shows: products, customers, metrics, findings, review queue |
| POST | `/api/labels` | `{id, label}` where label is `right`, `wrong` or `unclear` |
| POST | `/api/probe` | `{outputUrl, evidenceUrl, sampleId, authEnv}` → one sample and a drafted mapping |
| POST | `/api/products` | Create a product |
| PATCH | `/api/products/{id}` | `{live}` publish or unpublish |
| POST | `/api/discover` | `{productId, authEnv}` → item types and fields found in recent output |
| POST | `/api/customers` | Create a customer |
| PATCH | `/api/customers/{id}` | `{samplePerDay, auditRate}` |
| POST | `/api/run` | Check yesterday now |
| GET | `/api/evidence/{resultId}/{n}` | An evidence image, fetched server-side with the customer's key |

## Tables (`backend/assay.db`, SQLite)

| Table | One row per |
|---|---|
| `products` | AI product: endpoints, mapping, checks |
| `customers` | Customer of a product: item types, fields, sampling plan |
| `results` | Judged claim: what the platform said, the judge's verdict, the person's label |

## Code map

| File | Role |
|---|---|
| `sources.py` | Reads a platform over HTTP using the mapping; samples; profiles a new customer |
| `judge.py` | The model call: evidence plus claims in, verdicts out |
| `engine.py` | Daily run, metrics, verdict rules, slice analysis, review queue |
| `stats.py` | Wilson interval, drop probability, Benjamini–Hochberg, sample size |
| `demo.py` | Built-in fake platform with known truth |
| `db.py` | Schema and storage helpers |
| `api.py` | HTTP endpoints, scheduler, serves the UI |
