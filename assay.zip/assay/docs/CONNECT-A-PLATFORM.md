# Connect a real platform

Two steps, both in the UI: add the **product** once, then add each **customer**.
Before either, set the judge in `.env` (`ASSAY_JUDGE=bedrock` or `anthropic`) and restart.

## What your platform must expose

Three read-only JSON endpoints. Names and shapes are yours; Assay learns them through the
mapping.

| Endpoint | Placeholder | Returns |
|---|---|---|
| Item list | `{date}` (YYYY-MM-DD) | The IDs processed that day |
| Output | `{id}` | What the product produced for that item |
| Evidence | `{id}` | Links to what the output should be checked against (images today) |

If a key is needed, it is sent as `Authorization: Bearer <key>`. The key is read from the
environment variable you name for that customer.

Example output Assay can read:

```json
{
  "documents": [
    { "type": "Invoice", "tamper": "Not tampered",
      "fields": { "Invoice number": "INV-204", "Total": "1,840.00" } }
  ]
}
```

## The mapping

Paths into the JSON. `[]` means "each element of this list", `.*` means "each key".

| Mapping row | Example | Meaning |
|---|---|---|
| Item IDs | `orders[].id` | Where IDs are in the item-list response |
| One checked thing | `documents[]` | The unit that gets a verdict |
| Its type | `documents[].type` | Used to pick the customer's item type |
| Its values | `documents[].fields.*` | The extracted values to verify |
| Evidence | `images[].url` | Where evidence links are in the evidence response |

"Fetch a sample" in the Add product screen reads one real item and drafts these paths.
Correct any that are wrong. Fill in **Item IDs** by hand; it cannot be guessed from one item.

## Checks

A check is a name plus the exact instruction given to the judge.

- A check marked per-field produces one verdict for every configured field.
- Any other check produces one verdict per unit. If the unit has a key equal to the check's
  ID (for example `tamper`), that value is what gets verified; otherwise the unit's type is.

## Adding a customer

Left side: pick the product. Right side: **Add customer**.

1. Name, daily volume, and the name of the environment variable holding their key.
2. **Test connection** reads yesterday's output and lists the item types and fields found,
   with their share of volume. Switch types and checks on or off.
3. Choose the precision you want (for example ±3 points weekly). Assay computes the daily
   sample from it.
4. Activate.

Verdicts need history. A check shows "collecting" until it has 14 days of samples: the
first days form the baseline, the latest 7 are compared against it.

## Daily routine

- Each morning after `ASSAY_RUN_HOUR`, yesterday is sampled and judged.
- Open a customer, press **Review N items**: these are the values the judge was unsure of,
  plus a small random audit. Keys 1 / 2 / 3 answer right / wrong / can't tell.
- Labels override the judge and count from the next page load.

To run immediately instead of waiting:

```bash
curl -X POST http://localhost:8000/api/run
```

## Cost control

The judge is called once per sampled unit, with every claim for that unit in one request.
Cost is driven by `sampled a day`, not by the platform's volume.
