# Install

## Requirements

- Python 3.11 or newer
- macOS or Linux (Windows: use WSL)
- Nothing else. The UI is prebuilt; Node is needed only to change it.

## Install and run

```bash
./install.sh
```

```bash
./run.sh
```

`install.sh` creates `backend/.venv`, installs three packages (`fastapi`, `uvicorn`,
`anthropic`) and copies `.env.example` to `.env`. `run.sh` serves the UI and the API on
http://localhost:8000.

## Settings

All settings live in `.env`. See the comments in `.env.example`.

| Variable | Default | Meaning |
|---|---|---|
| `ASSAY_DEMO` | `1` | Load the demo platform on first start. `0` for a clean install. |
| `ASSAY_HOST` / `ASSAY_PORT` | `127.0.0.1` / `8000` | Where it listens. |
| `ASSAY_RUN_HOUR` | `6` | Hour after which yesterday is checked. |
| `ASSAY_JUDGE` | unset | `bedrock` or `anthropic`. Required for real platforms. |
| `ASSAY_JUDGE_MODEL` | Claude Haiku 4.5 | Model ID for the judge. |
| `AWS_REGION` | `us-east-1` | Region when `ASSAY_JUDGE=bedrock`. |
| `ASSAY_UNSURE_BELOW` | `0.8` | Confidence below which a person decides. |
| `ASSAY_DB` | `backend/assay.db` | Path of the SQLite database. |

Customer API keys also go in `.env`, one variable each. Only the variable *name* is typed
into the UI, so keys never reach the browser or the database.

## Moving to another machine

Copy this whole folder, then run `./install.sh` there. To keep history, also copy
`backend/assay.db`. Do not copy `backend/.venv`; it is rebuilt.

## Running as a service (Linux)

```ini
# /etc/systemd/system/assay.service
[Unit]
Description=Assay
After=network.target

[Service]
WorkingDirectory=/opt/assay
ExecStart=/opt/assay/run.sh
Restart=always
User=assay

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now assay
```

## Access control

Assay has no login. Keep it on `127.0.0.1` or a private network, or put a reverse proxy
with single sign-on in front of it. Review screens show customer documents.

## Backup

One file: `backend/assay.db`. Copy it while the service is stopped, or use
`sqlite3 backend/assay.db ".backup backup.db"` while it runs.

## Upgrade

Replace `backend/assay/` and `web/dist/` with the new versions, keep `.env` and
`backend/assay.db`, run `./install.sh` again, restart.

## Changing the UI

```bash
cd web/source && npm install && npm run build
```

Then replace `web/dist` with `web/source/dist`. For live development run `npm run dev`
(port 5173, it forwards `/api` to port 8000).

## Removing the demo

Set `ASSAY_DEMO=0`, stop the service, delete `backend/assay.db`, start again.
