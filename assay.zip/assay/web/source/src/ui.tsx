import { Fragment, useLayoutEffect, useRef, useState, type ButtonHTMLAttributes, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Check, CircleCheck, Eye, Sparkles, TriangleAlert } from 'lucide-react'
import { findingPath, sure, type Customer, type Metric, type Point, type Product, type QueueItem, type Rollup, type Status } from './data'
import { num, pct, shortDate } from './lib/stats'
import { useStore } from './store'

export const STATUS = {
  act: { label: 'Act', Icon: TriangleAlert, pill: 'bg-crit-soft text-crit-ink', color: 'var(--color-crit)' },
  watch: { label: 'Watch', Icon: Eye, pill: 'bg-warn-soft text-warn-ink', color: 'var(--color-warn)' },
  healthy: { label: 'Healthy', Icon: CircleCheck, pill: 'bg-good-soft text-good-ink', color: 'var(--color-good)' },
} as const

export function StatusPill({ status }: { status: Status }) {
  const s = STATUS[status]
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${s.pill}`}>
      <s.Icon size={12} strokeWidth={2.5} />
      {s.label}
    </span>
  )
}

export function Card({ className = '', children }: { className?: string; children: ReactNode }) {
  return <div className={`rounded-xl border border-line bg-surface shadow-card ${className}`}>{children}</div>
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' }

export const buttonClass = (variant: ButtonProps['variant'] = 'primary') =>
  `inline-flex h-9 items-center justify-center gap-1.5 rounded-lg px-3.5 text-sm font-medium transition-colors disabled:opacity-40 ${
    {
      primary: 'bg-ink text-white hover:bg-ink/85',
      secondary: 'border border-line-strong bg-surface text-ink hover:bg-sunken',
      ghost: 'text-ink-2 hover:bg-sunken hover:text-ink',
    }[variant]
  }`

export function Button({ variant, className = '', ...props }: ButtonProps) {
  return <button {...props} className={`${buttonClass(variant)} ${className}`} />
}

export function PageHeader({ eyebrow, title, sub, action }: { eyebrow?: ReactNode; title: ReactNode; sub?: ReactNode; action?: ReactNode }) {
  return (
    <header className="mb-7 flex items-end justify-between gap-6">
      <div className="min-w-0">
        {eyebrow && <div className="mb-2 text-xs font-medium text-ink-3">{eyebrow}</div>}
        <h1 className="text-[26px] font-semibold leading-tight tracking-tight">{title}</h1>
        {sub && <p className="mt-1.5 max-w-2xl text-sm text-ink-2">{sub}</p>}
      </div>
      {action}
    </header>
  )
}

export function AgentNote({ children }: { children: ReactNode }) {
  return (
    <div className="flex gap-2.5 rounded-lg bg-accent-soft px-3.5 py-3 text-sm text-ink">
      <Sparkles size={16} className="mt-0.5 shrink-0 text-accent-strong" />
      <div>{children}</div>
    </div>
  )
}

export const inputClass =
  'h-9 w-full rounded-lg border border-line-strong bg-surface px-3 text-sm text-ink placeholder:text-ink-3 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20'

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-ink-2">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-ink-3">{hint}</span>}
    </label>
  )
}

export function Steps({ steps, current }: { steps: string[]; current: number }) {
  return (
    <ol className="mb-6 flex items-center gap-2">
      {steps.map((s, i) => (
        <li key={s} className="flex items-center gap-2">
          <span
            className={`grid h-6 w-6 place-items-center rounded-full text-xs font-semibold ${
              i < current ? 'bg-ink text-white' : i === current ? 'bg-accent text-white' : 'bg-sunken text-ink-3'
            }`}
          >
            {i < current ? <Check size={13} strokeWidth={3} /> : i + 1}
          </span>
          <span className={`text-sm ${i === current ? 'font-semibold text-ink' : 'text-ink-3'}`}>{s}</span>
          {i < steps.length - 1 && <span className="mx-1 h-px w-8 bg-line-strong" />}
        </li>
      ))}
    </ol>
  )
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (on: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={`relative h-5 w-9 rounded-full transition-colors ${on ? 'bg-accent' : 'bg-line-strong'}`}
    >
      <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${on ? 'left-[18px]' : 'left-0.5'}`} />
    </button>
  )
}

/* ---------- charts ---------- */

function paths(days: Point[], x: (i: number) => number, y: (v: number) => number) {
  const pt = (i: number, v: number) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`
  const line = days.map((d, i) => `${i ? 'L' : 'M'}${pt(i, d.p)}`).join('')
  const upper = days.map((d, i) => `${i ? 'L' : 'M'}${pt(i, d.hi)}`).join('')
  const lower = days.map((_, i) => `L${pt(days.length - 1 - i, days[days.length - 1 - i].lo)}`).join('')
  return { line, band: `${upper}${lower}Z` }
}

/** Accuracy with its interval as a dot and whisker; the dark tick is the baseline. */
export function IntervalBar({ p, lo, hi, baseline, status, min = 0.8, width = 140 }: { p: number; lo: number; hi: number; baseline: number; status: Status; min?: number; width?: number }) {
  const x = (v: number) => 5 + ((Math.max(min, v) - min) / (1 - min)) * (width - 10)
  return (
    <svg width={width} height={18} role="img" aria-label={`${pct(p)}, range ${pct(lo)} to ${pct(hi)}, baseline ${pct(baseline)}`}>
      <line x1={5} x2={width - 5} y1={9} y2={9} stroke="var(--color-line)" />
      <line x1={x(lo)} x2={x(hi)} y1={9} y2={9} stroke="var(--color-ink-3)" strokeWidth={3} strokeLinecap="round" opacity={0.45} />
      <line x1={x(baseline)} x2={x(baseline)} y1={3} y2={15} stroke="var(--color-ink)" strokeWidth={1.5} />
      <circle cx={x(p)} cy={9} r={4.5} fill={STATUS[status].color} stroke="var(--color-surface)" strokeWidth={2} />
    </svg>
  )
}

export function Sparkline({ days, baseline, width = 148, height = 40 }: { days: Point[]; baseline: number; width?: number; height?: number }) {
  const min = Math.min(baseline, ...days.map((d) => d.lo))
  const max = Math.max(baseline, ...days.map((d) => d.hi))
  const x = (i: number) => 2 + (i / (days.length - 1)) * (width - 8)
  const y = (v: number) => 4 + (1 - (v - min) / (max - min || 1)) * (height - 8)
  const { line, band } = paths(days, x, y)
  const last = days[days.length - 1]
  return (
    <svg width={width} height={height} role="img" aria-label="30-day accuracy trend">
      <line x1={2} x2={width - 6} y1={y(baseline)} y2={y(baseline)} stroke="var(--color-line-strong)" />
      <path d={band} fill="var(--color-accent)" opacity={0.1} />
      <path d={line} fill="none" stroke="var(--color-accent)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={x(days.length - 1)} cy={y(last.p)} r={4} fill="var(--color-accent)" stroke="var(--color-surface)" strokeWidth={2} />
    </svg>
  )
}

function useWidth<T extends HTMLElement>() {
  const ref = useRef<T>(null)
  const [width, setWidth] = useState(0)
  useLayoutEffect(() => {
    if (!ref.current) return
    const observer = new ResizeObserver(([entry]) => setWidth(entry.contentRect.width))
    observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])
  return [ref, width] as const
}

export function TrendChart({ days, baseline, height = 280 }: { days: (Point & { k?: number; n?: number; dayK?: number; dayN?: number })[]; baseline: number; height?: number }) {
  const [ref, width] = useWidth<HTMLDivElement>()
  const [hover, setHover] = useState<number | null>(null)
  const H = height
  const m = { l: 44, r: 16, t: 20, b: 28 }
  const step = 0.05
  const min = Math.max(0, Math.floor((Math.min(baseline, ...days.map((d) => d.lo)) - 0.005) / step) * step)
  const plotW = Math.max(0, width - m.l - m.r)
  const x = (i: number) => m.l + (i / (days.length - 1)) * plotW
  const y = (v: number) => m.t + (1 - (v - min) / (1 - min)) * (H - m.t - m.b)
  const ticks: number[] = []
  for (let v = min; v <= 1.0001; v += step) ticks.push(Math.round(v * 100) / 100)
  const { line, band } = paths(days, x, y)
  const recentFrom = days.length - 7
  const h = hover === null ? null : days[hover]

  return (
    <div ref={ref} className="relative">
      {width > 0 && (
        <svg width={width} height={H} role="img" aria-label="Accuracy over the last 30 days with 95% interval and baseline">
          <rect x={x(recentFrom)} y={m.t} width={x(days.length - 1) - x(recentFrom)} height={H - m.t - m.b} fill="var(--color-sunken)" />
          <text x={x(recentFrom) + 6} y={H - m.b - 8} fontSize={11} fill="var(--color-ink-3)">
            Last 7 days
          </text>
          {ticks.map((t) => (
            <g key={t}>
              <line x1={m.l} x2={width - m.r} y1={y(t)} y2={y(t)} stroke="var(--color-line)" />
              <text x={m.l - 8} y={y(t) + 4} fontSize={11} textAnchor="end" fill="var(--color-ink-3)" className="num">
                {Math.round(t * 100)}%
              </text>
            </g>
          ))}
          {days.map((d, i) =>
            i % 5 === 4 ? (
              <text key={i} x={x(i)} y={H - 8} fontSize={11} textAnchor="middle" fill="var(--color-ink-3)">
                {shortDate(d.date)}
              </text>
            ) : null,
          )}
          <path d={band} fill="var(--color-accent)" opacity={0.1} />
          <line x1={m.l} x2={width - m.r} y1={y(baseline)} y2={y(baseline)} stroke="var(--color-ink-2)" strokeWidth={1} />
          <text x={width - m.r - 6} y={y(baseline) - 6} fontSize={11} textAnchor="end" fill="var(--color-ink-2)">
            Baseline {pct(baseline)}
          </text>
          <path d={line} fill="none" stroke="var(--color-accent)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
          <circle cx={x(days.length - 1)} cy={y(days[days.length - 1].p)} r={4.5} fill="var(--color-accent)" stroke="var(--color-surface)" strokeWidth={2} />
          {hover !== null && h && (
            <g pointerEvents="none">
              <line x1={x(hover)} x2={x(hover)} y1={m.t} y2={H - m.b} stroke="var(--color-ink-3)" />
              <circle cx={x(hover)} cy={y(h.p)} r={4.5} fill="var(--color-accent)" stroke="var(--color-surface)" strokeWidth={2} />
            </g>
          )}
          <rect
            x={m.l}
            y={m.t}
            width={plotW}
            height={H - m.t - m.b}
            fill="transparent"
            onPointerMove={(e) => {
              const left = e.currentTarget.getBoundingClientRect().left
              const i = Math.round(((e.clientX - left) / plotW) * (days.length - 1))
              setHover(Math.max(0, Math.min(days.length - 1, i)))
            }}
            onPointerLeave={() => setHover(null)}
          />
        </svg>
      )}
      {hover !== null && h && (
        <div
          className="pointer-events-none absolute top-2 z-10 w-48 rounded-lg bg-surface p-3 text-xs shadow-pop"
          style={x(hover) > width - 220 ? { left: x(hover) - 204 } : { left: x(hover) + 12 }}
        >
          <div className="text-ink-3">{shortDate(h.date)}</div>
          <div className="mt-0.5 text-lg font-semibold">{pct(h.p)}</div>
          <div className="num text-ink-2">
            {pct(h.lo)}–{pct(h.hi)} likely range
          </div>
          {h.n !== undefined && (
            <div className="num mt-1.5 border-t border-line pt-1.5 text-ink-2">
              7 days to here: {h.k} of {h.n} right
              <br />
              This day: {h.dayK} of {h.dayN} right
            </div>
          )}
        </div>
      )}
      <p className="mt-1 text-xs text-ink-3">Line is accuracy over the trailing 7 days. Shading is the 95% range around it.</p>
    </div>
  )
}

/* ---------- headline: one number, its trend, what it costs ---------- */

const TONE: Record<Status, string> = { act: 'bg-crit-soft text-crit-ink', watch: 'bg-warn-soft text-warn-ink', healthy: 'bg-sunken text-ink-2' }

/** Change against baseline. Coloured by the statistical verdict, not by the raw difference, so noise never shows red. */
export function Delta({ value, status }: { value: number; status: Status }) {
  const points = value * 100
  return (
    <span className={`num inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-xs font-semibold ${TONE[status]}`}>
      {Math.abs(points) < 0.05 ? '' : points < 0 ? '▼' : '▲'} {Math.abs(points).toFixed(1)} pts
    </span>
  )
}

export function Headline({ roll, status, who }: { roll: Rollup; status: Status; who: string }) {
  const extra = roll.wrongPerDay - roll.wrongPerDayAtBaseline
  return (
    <Card className="grid grid-cols-1 gap-x-8 gap-y-5 p-6 lg:grid-cols-[250px_minmax(0,1fr)]">
      <div>
        <div className="text-xs font-medium text-ink-3">Outputs right, last 7 days</div>
        <div className="mt-1.5 text-[56px] font-semibold leading-none tracking-tight">{pct(roll.p)}</div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-sm text-ink-2">
          <Delta value={roll.p - roll.baseline} status={status} />
          <span className="num">vs baseline {pct(roll.baseline)}</span>
        </div>
        <div className="num mt-1 text-xs text-ink-3">
          likely between {pct(roll.lo)} and {pct(roll.hi)}
        </div>
        <div className="mt-5 border-t border-line pt-4">
          <div className="text-2xl font-semibold tracking-tight">≈ {num(roll.wrongPerDay)}</div>
          <div className="num text-sm text-ink-2">
            wrong outputs reaching {who} a day{extra >= 1 ? `, ${num(extra)} more than at baseline` : ''}
          </div>
          <div className="num mt-0.5 text-xs text-ink-3">of {num(roll.outputsPerDay)} outputs a day</div>
        </div>
      </div>
      <TrendChart days={roll.days} baseline={roll.baseline} height={250} />
    </Card>
  )
}

/* ---------- where it is failing: item types down, checks across ---------- */

const CELL: Record<Status, string> = { healthy: 'bg-good-soft text-good-ink', watch: 'bg-warn text-ink', act: 'bg-crit text-white' }

export function Heat({ customer, product, metrics, large }: { customer: Customer; product: Product; metrics: Metric[]; large?: boolean }) {
  const checks = product.checkTypes.filter((k) => customer.itemTypes.some((t) => t.checks.includes(k.id)))
  const cellSize = large ? 'h-10' : 'h-6'
  return (
    <div
      className={`grid items-center ${large ? 'gap-1.5 text-sm' : 'gap-1 text-[11px]'}`}
      style={{ gridTemplateColumns: `minmax(0, ${large ? 1.6 : 1.3}fr) repeat(${checks.length}, minmax(0, 1fr))` }}
    >
      <span />
      {checks.map((k) => (
        <span key={k.id} className="truncate pb-0.5 text-center text-ink-3">
          {large ? k.name : k.name.split(' ')[0]}
        </span>
      ))}
      {customer.itemTypes.map((t) => (
        <Fragment key={t.id}>
          <span className="truncate pr-2 text-ink-2">
            {t.name}
            {large && <span className="num ml-2 text-xs text-ink-3">{pct(t.share, 0)} of volume</span>}
          </span>
          {checks.map((k) => {
            const m = metrics.find((x) => x.itemType.id === t.id && x.check.id === k.id)
            if (!m) return <span key={k.id} className={`rounded ${cellSize} ${t.checks.includes(k.id) ? 'bg-sunken' : ''}`} />
            const label = `${k.name} on ${t.name}: ${pct(m.p)}, baseline ${pct(m.baseline)}, ${STATUS[m.status].label}`
            const cell = `num grid place-items-center rounded font-medium ${cellSize} ${CELL[m.status]}`
            return large ? (
              <Link key={k.id} to={findingPath(m)} title={label} className={`${cell} transition-transform hover:scale-[1.04]`}>
                {(m.p * 100).toFixed(1)}
              </Link>
            ) : (
              <span key={k.id} title={label} className={cell}>
                {(m.p * 100).toFixed(1)}
              </span>
            )
          })}
        </Fragment>
      ))}
    </div>
  )
}

/* ---------- stand-in for a document image ---------- */

export function DocMock({ item, compact }: { item: QueueItem; compact?: boolean }) {
  const doc = item.doc
  if (doc.images?.length)
    return (
      <div className="space-y-3">
        {doc.images.map((_, i) => (
          // Served through the backend so the customer's API key never reaches the browser.
          <img key={i} src={`/api/evidence/${item.id}/${i}`} alt={`Evidence ${i + 1} for ${item.ref}`} className="w-full rounded-lg border border-line-strong" />
        ))}
      </div>
    )
  return (
    <div className={`rounded-lg border border-line-strong bg-[#fbfaf6] shadow-card ${compact ? 'p-3.5 text-xs' : 'p-7 text-sm'}`}>
      <div className="mb-3 flex items-center justify-between gap-3 border-b border-dashed border-line-strong pb-2.5">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-ink-2">{doc.title}</span>
        <span className="shrink-0 text-[10px] text-ink-3">Demo evidence</span>
      </div>
      <dl className="space-y-1">
        {(doc.rows ?? []).map(([label, value]) => (
          <div key={label} className={`flex gap-3 rounded-md px-2 py-1.5 ${label === doc.highlight ? 'bg-accent-soft ring-1 ring-accent/60' : ''}`}>
            <dt className={`shrink-0 text-ink-3 ${compact ? 'w-24' : 'w-36'}`}>{label}</dt>
            <dd className="min-w-0 break-words font-mono text-ink">{value}</dd>
          </div>
        ))}
      </dl>
      {doc.note && (
        <p className="mt-3 flex items-center gap-1.5 text-xs text-warn-ink">
          <TriangleAlert size={12} /> {doc.note}
        </p>
      )}
    </div>
  )
}

/* ---------- one flagged check, stated as a verdict ---------- */

export function Verdict({ m }: { m: Metric }) {
  const finding = useStore().findings[m.id]
  const unit = m.check.perField ? 'values' : `${m.product.unit}s`
  return (
    <Card className="overflow-hidden">
      <div className="flex items-stretch">
        <div className="w-1 shrink-0" style={{ background: STATUS[m.status].color }} />
        <div className="flex min-w-0 flex-1 items-start gap-6 p-5">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-xs text-ink-3">
              <StatusPill status={m.status} />
              <span>{m.itemType.name}</span>
            </div>
            <h3 className="mt-2.5 text-base font-semibold">
              {m.check.name} on {m.itemType.name}
            </h3>
            <div className="mt-1.5 flex flex-wrap items-baseline gap-x-5 gap-y-1">
              <span className="text-[28px] font-semibold leading-none tracking-tight">{pct(m.p)}</span>
              <span className="num text-sm text-ink-2">
                likely {pct(m.lo)}–{pct(m.hi)}
              </span>
              <span className="num text-sm text-ink-2">baseline {pct(m.baseline)}</span>
              <span className="num text-sm text-ink-2">{sure(m.prob)} sure it is below baseline</span>
            </div>
            <p className="mt-3 text-sm">
              About {num(m.extraErrorsPerDay)} more wrong {unit} reaching the customer each day.
            </p>
            {finding && <p className="mt-1 text-sm text-ink-2">{finding.cause}</p>}
          </div>
          <div className="flex shrink-0 flex-col items-end justify-between gap-4 self-stretch">
            <Sparkline days={m.days} baseline={m.baseline} />
            <Link to={findingPath(m)} className="inline-flex items-center gap-1 text-sm font-medium text-accent-strong hover:underline">
              Open finding <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </div>
    </Card>
  )
}
