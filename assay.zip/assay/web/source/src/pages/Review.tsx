import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, Check, CircleCheck, Minus, X } from 'lucide-react'
import type { Customer, Label, QueueItem } from '../data'
import { pct } from '../lib/stats'
import { useStore } from '../store'
import { Card, DocMock, PageHeader } from '../ui'

const CHOICES: { label: Label; text: string; key: string; Icon: typeof Check; tone: string }[] = [
  { label: 'right', text: 'Platform is right', key: '1', Icon: Check, tone: 'hover:border-good hover:bg-good-soft' },
  { label: 'wrong', text: 'Platform is wrong', key: '2', Icon: X, tone: 'hover:border-crit hover:bg-crit-soft' },
  { label: 'unclear', text: 'Can’t tell from this', key: '3', Icon: Minus, tone: 'hover:border-line-strong hover:bg-sunken' },
]

export default function Review() {
  const { id } = useParams()
  const { customers, queueFor } = useStore()
  const customer = customers.find((c) => c.id === id)
  if (!customer) return <p className="text-ink-2">No such customer.</p>
  const queue = queueFor(customer.id)
  if (!queue.length) return <p className="text-ink-2">Nothing from {customer.name} needs a person today.</p>
  return <Queue key={customer.id} customer={customer} queue={queue} />
}

function Queue({ customer, queue }: { customer: Customer; queue: QueueItem[] }) {
  const { labels, setLabel, metrics } = useStore()
  const [index, setIndex] = useState(() => Math.max(0, queue.findIndex((q) => !labels[q.id])))
  const item = queue[index]
  const metric = metrics.find((m) => m.id === item.metricId)
  const done = queue.filter((q) => labels[q.id]).length

  const choose = (label: Label) => {
    setLabel(item.id, label)
    const open = (i: number) => i !== index && !labels[queue[i].id]
    const after = queue.findIndex((_, i) => i > index && open(i))
    const next = after >= 0 ? after : queue.findIndex((_, i) => open(i))
    if (next >= 0) setIndex(next)
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const choice = CHOICES.find((c) => c.key === e.key)
      if (choice) choose(choice.label)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  return (
    <>
      <Link to={`/customers/${customer.id}`} className="mb-5 inline-flex items-center gap-1 text-sm text-ink-2 hover:text-ink">
        <ArrowLeft size={14} /> {customer.name}
      </Link>
      <PageHeader
        title={done === queue.length ? 'Queue clear.' : `${queue.length - done} items need a person.`}
        sub="Only what the model could not settle, plus a small random audit that measures the model itself."
        action={
          <div className="w-56">
            <div className="num mb-1.5 flex justify-between text-xs text-ink-3">
              <span>Labelled</span>
              <span>
                {done} of {queue.length}
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-line">
              <div className="h-full rounded-full bg-ink transition-all" style={{ width: `${(done / queue.length) * 100}%` }} />
            </div>
          </div>
        }
      />

      <div className="grid grid-cols-1 items-start gap-4 xl:grid-cols-[210px_minmax(0,1fr)_330px]">
        <Card className="overflow-hidden py-1.5">
          {queue.map((q, i) => {
            const label = labels[q.id]
            return (
              <button
                key={q.id}
                onClick={() => setIndex(i)}
                className={`flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-sm ${i === index ? 'bg-sunken' : 'hover:bg-sunken/50'}`}
              >
                <span className="grid h-4 w-4 shrink-0 place-items-center">
                  {label === 'right' && <Check size={14} className="text-good-ink" strokeWidth={3} />}
                  {label === 'wrong' && <X size={14} className="text-crit-ink" strokeWidth={3} />}
                  {label === 'unclear' && <Minus size={14} className="text-ink-3" strokeWidth={3} />}
                  {!label && <span className="h-1.5 w-1.5 rounded-full bg-accent" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className={`block truncate font-medium ${label ? 'text-ink-3' : ''}`}>{q.ref}</span>
                  <span className="block truncate text-xs text-ink-3">{q.field ?? q.claimed}</span>
                </span>
              </button>
            )
          })}
        </Card>

        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between text-xs text-ink-3">
            <span>
              {metric?.customer.name} · {metric?.itemType.name} · <span className="font-medium text-ink-2">{item.ref}</span>
            </span>
            <span>Evidence: {metric?.check.evidence.toLowerCase()}</span>
          </div>
          <DocMock item={item} />
        </Card>

        <Card className="p-5">
          <div className="text-xs font-medium text-ink-3">{metric?.check.name}</div>
          <p className="mt-1 text-sm text-ink-2">{metric?.check.instruction}</p>

          <div className="mt-5 text-xs font-medium text-ink-3">Platform says{item.field ? ` · ${item.field}` : ''}</div>
          <div className="mt-1 break-words font-mono text-lg font-medium">{item.claimed}</div>

          <div className="mt-5 rounded-lg bg-sunken p-3.5">
            <div className="num flex items-center justify-between text-xs">
              <span className="font-medium text-ink-2">Model: {item.judge === 'unsure' ? 'not sure' : `says ${item.judge}`}</span>
              <span className="text-ink-3">{pct(item.confidence, 0)} confident</span>
            </div>
            <p className="mt-1.5 text-sm">{item.reason}</p>
          </div>
          <p className="mt-2.5 text-xs text-ink-3">
            {item.why === 'unsure' ? 'Sent to you because the model was not confident.' : 'Random audit. Your answer measures how often the model itself is wrong.'}
          </p>

          <div className="mt-5 space-y-2">
            {CHOICES.map(({ label, text, key, Icon, tone }) => (
              <button
                key={label}
                onClick={() => choose(label)}
                className={`flex h-10 w-full items-center gap-2.5 rounded-lg border px-3 text-sm font-medium transition-colors ${
                  labels[item.id] === label ? 'border-ink bg-ink text-white' : `border-line-strong bg-surface ${tone}`
                }`}
              >
                <Icon size={15} strokeWidth={2.5} />
                <span className="flex-1 text-left">{text}</span>
                <kbd className={`rounded border px-1.5 font-mono text-[11px] ${labels[item.id] === label ? 'border-white/30' : 'border-line-strong text-ink-3'}`}>{key}</kbd>
              </button>
            ))}
          </div>

          {done === queue.length && (
            <div className="mt-5 flex items-start gap-2 rounded-lg bg-good-soft p-3 text-sm text-good-ink">
              <CircleCheck size={16} className="mt-0.5 shrink-0" />
              <span>
                All labelled. Tonight’s run folds these into the estimates.{' '}
                <Link to={`/customers/${customer.id}`} className="font-medium underline">
                  Back to {customer.name}
                </Link>
              </span>
            </div>
          )}
        </Card>
      </div>
    </>
  )
}
