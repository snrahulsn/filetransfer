import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Check, Loader, Plus, Trash2 } from 'lucide-react'
import type { CheckType } from '../data'
import { api, slug, useStore } from '../store'
import { AgentNote, Button, Card, Field, inputClass, PageHeader, Steps } from '../ui'

/* ---------- onboarding ---------- */

const STEPS = ['Connect', 'What the agent read', 'Checks']

export function NewProduct() {
  const { products, reload } = useStore()
  const [itemsUrl, setItemsUrl] = useState('')
  const [sampleId, setSampleId] = useState('')
  const [authEnv, setAuthEnv] = useState('')
  const [sample, setSample] = useState('')
  const [problem, setProblem] = useState('')
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [unit, setUnit] = useState('item')
  const [blurb, setBlurb] = useState('')
  const [outputUrl, setOutputUrl] = useState('')
  const [evidenceUrl, setEvidenceUrl] = useState('')
  const [fetching, setFetching] = useState<'idle' | 'busy' | 'ok'>('idle')
  const [mapping, setMapping] = useState<Record<string, string>>({
    'One checked thing': 'results[]',
    'Its type': 'results[].type',
    'Its values': 'results[].fields.*',
    Evidence: 'evidence[].url',
  })
  const [checks, setChecks] = useState<CheckType[]>([])

  const id = slug(name)
  const taken = products.some((p) => p.id === id)

  const fetchSample = () => {
    setFetching('busy')
    setProblem('')
    api<{ sample: unknown; mapping: Record<string, string> }>('/probe', { outputUrl, evidenceUrl, sampleId, authEnv })
      .then((found) => {
        setSample(JSON.stringify(found.sample, null, 2).slice(0, 4000))
        setMapping(found.mapping)
        // First draft of the checks; the person edits the wording the judge will be given.
        setChecks([
          { id: 'type', name: 'Type', instruction: `Look at the evidence. Is this ${unit} the type the platform says it is?`, evidence: 'Original' },
          { id: 'values', name: 'Values', instruction: 'Find each value in the evidence. Does it match what the platform returned?', evidence: 'Original', perField: true },
        ])
        setFetching('ok')
      })
      .catch((e: Error) => {
        setProblem(e.message)
        setFetching('idle')
      })
  }
  const patchCheck = (i: number, change: Partial<CheckType>) => setChecks((s) => s.map((k, j) => (j === i ? { ...k, ...change } : k)))
  const publish = () => {
    api('/products', { name, unit, blurb, itemsUrl, outputUrl, evidenceUrl, mapping, checkTypes: checks })
      .then(reload)
      .then(() => navigate(`/products/${id}`))
      .catch((e: Error) => setProblem(e.message))
  }

  return (
    <>
      <Link to="/" className="mb-5 inline-flex items-center gap-1 text-sm text-ink-2 hover:text-ink">
        <ArrowLeft size={14} /> Back
      </Link>
      <PageHeader title="Add product" />
      <Steps steps={STEPS} current={step} />

      <Card className="p-6">
        {step === 0 && (
          <div className="grid max-w-2xl grid-cols-2 gap-5">
            <Field label="Product name" hint={taken ? 'A product with this name already exists.' : undefined}>
              <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Support chatbot" />
            </Field>
            <Field label="One checked thing is called a…" hint="document, call, ticket, reply">
              <input className={inputClass} value={unit} onChange={(e) => setUnit(e.target.value.toLowerCase())} />
            </Field>
            <div className="col-span-2">
              <Field label="What it does">
                <input className={inputClass} value={blurb} onChange={(e) => setBlurb(e.target.value)} placeholder="Answers customer questions from the help centre." />
              </Field>
            </div>
            <div className="col-span-2">
              <Field label="Output endpoint" hint="Returns what the product produced for one item. Use {id} for the item ID.">
                <input className={`${inputClass} font-mono`} value={outputUrl} onChange={(e) => setOutputUrl(e.target.value)} placeholder="https://api.example.com/v1/items/{id}/result" />
              </Field>
            </div>
            <div className="col-span-2">
              <Field label="Evidence endpoint" hint="Returns what the output should be checked against: images, audio, source text.">
                <input className={`${inputClass} font-mono`} value={evidenceUrl} onChange={(e) => setEvidenceUrl(e.target.value)} placeholder="https://api.example.com/v1/items/{id}/source" />
              </Field>
            </div>
            <div className="col-span-2">
              <Field label="Item list endpoint" hint="Returns the IDs processed on one day. Use {date}. The daily sample is drawn from it.">
                <input className={`${inputClass} font-mono`} value={itemsUrl} onChange={(e) => setItemsUrl(e.target.value)} placeholder="https://api.example.com/v1/items?date={date}" />
              </Field>
            </div>
            <Field label="One real item ID to read" hint="Used once, to see what the output looks like.">
              <input className={`${inputClass} font-mono`} value={sampleId} onChange={(e) => setSampleId(e.target.value)} />
            </Field>
            <Field label="Environment variable holding an API key" hint="Leave empty if none is needed.">
              <input className={`${inputClass} font-mono`} value={authEnv} onChange={(e) => setAuthEnv(e.target.value)} placeholder="PLATFORM_API_KEY" />
            </Field>
            <div className="col-span-2 flex items-center gap-3">
              {problem && <span className="order-last text-sm text-crit-ink">{problem}</span>}
              <Button variant="secondary" onClick={fetchSample} disabled={fetching === 'busy' || !outputUrl || !evidenceUrl || !sampleId}>
                {fetching === 'busy' && <Loader size={14} className="animate-spin" />}
                Fetch a sample
              </Button>
              {fetching === 'ok' && (
                <span className="flex items-center gap-1.5 text-sm text-good-ink">
                  <Check size={15} strokeWidth={3} /> Both endpoints answered.
                </span>
              )}
            </div>
          </div>
        )}

        {step === 1 && (
          <>
            <AgentNote>I read one sample and worked out where things live in the output. Correct any path that is wrong.</AgentNote>
            <div className="mt-5 grid grid-cols-2 gap-8">
              <pre className="overflow-x-auto rounded-lg bg-sunken p-4 font-mono text-xs leading-relaxed text-ink-2">{sample}</pre>
              <div className="space-y-4">
                {Object.entries(mapping).map(([label, path]) => (
                  <Field key={label} label={label}>
                    <input className={`${inputClass} font-mono`} value={path} onChange={(e) => setMapping({ ...mapping, [label]: e.target.value })} />
                  </Field>
                ))}
              </div>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <AgentNote>These are the checks I would run on every sampled {unit}. The instruction is what the judge model is asked, word for word.</AgentNote>
            <div className="mt-5 space-y-4">
              {checks.map((k, i) => (
                <div key={i} className="grid grid-cols-[200px_1fr_36px] items-start gap-4">
                  <Field label="Check">
                    <input className={inputClass} value={k.name} onChange={(e) => patchCheck(i, { name: e.target.value })} />
                  </Field>
                  <Field label="Instruction to the judge">
                    <input className={inputClass} value={k.instruction} onChange={(e) => patchCheck(i, { instruction: e.target.value })} />
                  </Field>
                  <button aria-label={`Remove ${k.name}`} onClick={() => setChecks(checks.filter((_, j) => j !== i))} className="mt-[22px] grid h-9 w-9 place-items-center rounded-lg text-ink-3 hover:bg-sunken hover:text-crit-ink">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </div>
            <Button variant="secondary" className="mt-5" onClick={() => setChecks([...checks, { id: '', name: '', instruction: '', evidence: 'Original' }])}>
              <Plus size={15} /> Add check
            </Button>
          </>
        )}
      </Card>

      <div className="mt-5 flex justify-between">
        <Button variant="ghost" onClick={() => setStep(step - 1)} disabled={step === 0}>
          Back
        </Button>
        {step < 2 ? (
          <Button onClick={() => setStep(step + 1)} disabled={step === 0 && (fetching !== 'ok' || !id || taken)}>
            Continue <ArrowRight size={15} />
          </Button>
        ) : (
          <Button onClick={publish} disabled={!checks.length || checks.some((k) => !k.name.trim() || !k.instruction.trim())}>
            Publish
          </Button>
        )}
      </div>
    </>
  )
}
