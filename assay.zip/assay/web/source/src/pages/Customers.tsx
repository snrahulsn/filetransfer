import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Check, Loader } from 'lucide-react'
import { rollup, worst, type ItemType, type Status } from '../data'
import { num, pct, sampleSize } from '../lib/stats'
import { api, slug, useStore } from '../store'
import { AgentNote, Button, buttonClass, Card, Field, Headline, Heat, inputClass, PageHeader, StatusPill, Steps, Toggle, Verdict } from '../ui'

const cap = (s: string) => s[0].toUpperCase() + s.slice(1)
const ORDER: Record<Status, number> = { act: 0, watch: 1, healthy: 2 }

export function CustomerDetail() {
  const { id } = useParams()
  const { customers, products, metrics, labels, queueFor, reload } = useStore()
  const updateCustomer = (id: string, patch: { samplePerDay?: number; auditRate?: number }) => api(`/customers/${id}`, patch, 'PATCH').then(reload)
  const c = customers.find((x) => x.id === id)
  const product = products.find((p) => p.id === c?.productId)
  if (!c || !product) return <p className="text-ink-2">No such customer.</p>

  const own = metrics.filter((m) => m.customer.id === c.id)
  const flagged = own.filter((m) => m.status !== 'healthy').sort((a, b) => ORDER[a.status] - ORDER[b.status] || b.extraErrorsPerDay - a.extraErrorsPerDay)
  const waiting = queueFor(c.id).filter((q) => !labels[q.id]).length
  const roll = rollup(own)
  // 95% margin on a week of samples, split evenly across item types, assuming accuracy near 95%.
  const margin = 1.96 * Math.sqrt((0.95 * 0.05) / Math.max(1, (c.samplePerDay * 7) / c.itemTypes.length))

  return (
    <>
      <Link to={`/products/${product.id}`} className="mb-5 inline-flex items-center gap-1 text-sm text-ink-2 hover:text-ink">
        <ArrowLeft size={14} /> {product.name}
      </Link>
      <PageHeader
        eyebrow={c.useCase}
        title={
          <span className="flex items-center gap-3">
            {c.name}
            {!c.collecting && <StatusPill status={worst(own)} />}
          </span>
        }
        sub={c.collecting ? undefined : flagged.length ? `${flagged.length} of ${own.length} checks are below baseline.` : `All ${own.length} checks are in line with baseline.`}
        action={
          waiting > 0 && (
            <Link to={`/customers/${c.id}/review`} className={buttonClass()}>
              Review {waiting} {waiting === 1 ? 'item' : 'items'} <ArrowRight size={15} />
            </Link>
          )
        }
      />

      {roll && <Headline roll={roll} status={worst(own)} who={c.name} />}

      {flagged.length > 0 && (
        <section className="mt-4 space-y-3">
          {flagged.map((m) => (
            <Verdict key={m.id} m={m} />
          ))}
        </section>
      )}

      <Card className="mt-4 p-5">
        <div className="mb-4 flex items-baseline justify-between">
          <h2 className="text-sm font-semibold">Every check, last 7 days</h2>
          <span className="text-xs text-ink-3">% right · click a cell for its finding</span>
        </div>
        <Heat customer={c} product={product} metrics={own} large />
      </Card>

      <Card className="mt-4 p-5">
        <h2 className="text-sm font-semibold">Sampling plan</h2>
        <div className="mt-4 grid grid-cols-2 items-end gap-5 lg:grid-cols-[180px_180px_1fr]">
          <Field label="Items sampled a day">
            <input type="number" min={5} className={inputClass} value={c.samplePerDay} onChange={(e) => updateCustomer(c.id, { samplePerDay: Math.max(5, +e.target.value || 5) })} />
          </Field>
          <Field label="Random audit, %">
            <input
              type="number"
              min={1}
              max={25}
              className={inputClass}
              value={Math.round(c.auditRate * 100)}
              onChange={(e) => updateCustomer(c.id, { auditRate: Math.min(25, Math.max(1, +e.target.value || 1)) / 100 })}
            />
          </Field>
          <p className="num col-span-2 pb-1.5 text-sm text-ink-2 lg:col-span-1">
            {pct(c.samplePerDay / c.itemsPerDay)} of volume, split evenly across {c.itemTypes.length} {product.unit} types. Weekly accuracy on each type is known to within ±
            {(margin * 100).toFixed(1)} points. Changes apply from the next run.
          </p>
        </div>
      </Card>
    </>
  )
}

/* ---------- onboarding ---------- */

type Draft = ItemType & { on: boolean }

const STEPS = ['Connect', 'What the agent found', 'Sampling plan', 'Activate']

export function NewCustomer() {
  const { products, customers, reload } = useStore()
  const [authEnv, setAuthEnv] = useState('')
  const [problem, setProblem] = useState('')
  const navigate = useNavigate()
  const { productId } = useParams()
  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [useCase, setUseCase] = useState('')
  const [volume, setVolume] = useState(500)
  const [test, setTest] = useState<'idle' | 'busy' | 'ok'>('idle')
  const [types, setTypes] = useState<Draft[]>([])
  const [margin, setMargin] = useState(3)
  const [audit, setAudit] = useState(5)

  const product = products.find((p) => p.id === productId && p.live)
  if (!product) return <p className="text-ink-2">Publish the product before adding customers.</p>

  const chosen = types.filter((t) => t.on)
  const perTypeWeekly = sampleSize(margin / 100)
  const perDay = Math.ceil((perTypeWeekly * chosen.length) / 7)
  const id = slug(name)
  const taken = customers.some((c) => c.id === id)

  const connect = () => {
    setTest('busy')
    setProblem('')
    api<ItemType[]>('/discover', { productId: product.id, authEnv })
      .then((found) => {
        setTypes(found.map((t) => ({ ...t, on: t.checks.length > 0 })))
        setTest('ok')
      })
      .catch((e: Error) => {
        setProblem(e.message)
        setTest('idle')
      })
  }
  const patch = (typeId: string, change: Partial<Draft>) => setTypes((s) => s.map((t) => (t.id === typeId ? { ...t, ...change } : t)))
  const activate = () => {
    api('/customers', { name, productId: product.id, useCase, itemsPerDay: volume, samplePerDay: perDay, auditRate: audit / 100, authEnv, itemTypes: chosen.map(({ on: _on, ...t }) => t) })
      .then(reload)
      .then(() => navigate(`/customers/${id}`))
      .catch((e: Error) => setProblem(e.message))
  }

  return (
    <>
      <Link to={`/products/${product.id}`} className="mb-5 inline-flex items-center gap-1 text-sm text-ink-2 hover:text-ink">
        <ArrowLeft size={14} /> {product.name}
      </Link>
      <PageHeader eyebrow={product.name} title="Add customer" />
      <Steps steps={STEPS} current={step} />

      <Card className="p-6">
        {step === 0 && (
          <div className="grid max-w-2xl grid-cols-2 gap-5">
            <Field label="Customer name" hint={taken ? 'A customer with this name already exists.' : undefined}>
              <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Acme Bank" />
            </Field>
            <Field label="What they use it for">
              <input className={inputClass} value={useCase} onChange={(e) => setUseCase(e.target.value)} placeholder="Vendor invoice processing" />
            </Field>
            <Field label={`${cap(product.unit)}s processed a day`}>
              <input type="number" min={1} className={inputClass} value={volume} onChange={(e) => setVolume(Math.max(1, +e.target.value || 1))} />
            </Field>
            <div className="col-span-2">
              <Field label="Environment variable holding their API key" hint="The key itself stays on the server and is never typed here. Leave empty if the platform needs none.">
                <input className={`${inputClass} font-mono`} value={authEnv} onChange={(e) => setAuthEnv(e.target.value)} placeholder="ACME_API_KEY" autoComplete="off" />
              </Field>
            </div>
            <div className="col-span-2 flex items-center gap-3">
              <Button variant="secondary" onClick={connect} disabled={test === 'busy'}>
                {test === 'busy' && <Loader size={14} className="animate-spin" />}
                Test connection
              </Button>
              {problem && <span className="text-sm text-crit-ink">{problem}</span>}
              {test === 'ok' && (
                <span className="flex items-center gap-1.5 text-sm text-good-ink">
                  <Check size={15} strokeWidth={3} /> Connected. Read recent {product.unit}s.
                </span>
              )}
            </div>
          </div>
        )}

        {step === 1 && (
          <>
            <AgentNote>
              Read recent {product.unit}s and found {types.length} types. The checks I would run are switched on.
              {types.some((t) => !t.fields.length) && ' Unrecognised items are left out: too few to measure reliably.'}
            </AgentNote>
            <table className="mt-5 w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs text-ink-3">
                  <th className="w-12 py-2.5 font-medium">Use</th>
                  <th className="py-2.5 font-medium">{cap(product.unit)} type</th>
                  <th className="py-2.5 text-right font-medium">Share</th>
                  {product.checkTypes.map((k) => (
                    <th key={k.id} className="px-3 py-2.5 text-center font-medium">
                      {k.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {types.map((t) => (
                  <tr key={t.id} className={`border-b border-line last:border-0 ${t.on ? '' : 'opacity-50'}`}>
                    <td className="py-3">
                      <Toggle on={t.on} onChange={(on) => patch(t.id, { on })} label={`Include ${t.name}`} />
                    </td>
                    <td className="py-3">
                      <div className="font-medium">{t.name}</div>
                      <div className="text-xs text-ink-3">{t.fields.join(', ') || 'No fields found'}</div>
                    </td>
                    <td className="num py-3 text-right text-ink-2">{pct(t.share, 0)}</td>
                    {product.checkTypes.map((k) => (
                      <td key={k.id} className="px-3 py-3 text-center">
                        <input
                          type="checkbox"
                          className="h-4 w-4 accent-[var(--color-accent)]"
                          aria-label={`${k.name} on ${t.name}`}
                          disabled={!t.on}
                          checked={t.checks.includes(k.id)}
                          onChange={(e) => patch(t.id, { checks: e.target.checked ? [...t.checks, k.id] : t.checks.filter((x) => x !== k.id) })}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        {step === 2 && (
          <div className="grid grid-cols-2 gap-10">
            <div className="space-y-7">
              <Field label={`How precisely should weekly accuracy be known? ±${margin} points`} hint="Tighter needs more samples. ±3 is enough to catch a drop of a few points within a week.">
                <input type="range" min={1} max={6} step={0.5} value={margin} onChange={(e) => setMargin(+e.target.value)} className="w-full accent-[var(--color-accent)]" />
              </Field>
              <Field label={`Random audit of confident verdicts: ${audit}%`} hint="A person re-checks these so the model’s own error rate is measured, not assumed.">
                <input type="range" min={2} max={15} value={audit} onChange={(e) => setAudit(+e.target.value)} className="w-full accent-[var(--color-accent)]" />
              </Field>
            </div>
            <div className="rounded-xl bg-sunken p-6">
              <div className="text-xs text-ink-3">The plan</div>
              <div className="mt-1 text-[32px] font-semibold leading-none tracking-tight">{num(perDay)} a day</div>
              <ul className="num mt-4 space-y-1.5 text-sm text-ink-2">
                <li>
                  {pct(perDay / volume)} of {num(volume)} {product.unit}s processed
                </li>
                <li>
                  {perTypeWeekly} per type per week, across {chosen.length} types
                </li>
                <li>About {Math.max(1, Math.round((perDay * audit) / 100))} audit items a day for a person, plus whatever the model is unsure of</li>
              </ul>
              {perDay > volume && <p className="mt-3 text-sm text-crit-ink">That is more than the daily volume. Widen the margin.</p>}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="max-w-xl space-y-4">
            <dl className="num space-y-2.5 text-sm">
              <Summary label="Customer" value={`${name} · ${product.name}`} />
              <Summary label={`${cap(product.unit)} types`} value={chosen.map((t) => t.name).join(', ')} />
              <Summary label="Checks" value={`${chosen.reduce((s, t) => s + t.checks.length, 0)} in total`} />
              <Summary label="Sampling" value={`${num(perDay)} a day, ±${margin} points weekly, ${audit}% audit`} />
            </dl>
            <AgentNote>The first 7 days build the baseline. Verdicts start after that, every morning at 06:00.</AgentNote>
          </div>
        )}
      </Card>

      <div className="mt-5 flex justify-between">
        <Button variant="ghost" onClick={() => setStep(step - 1)} disabled={step === 0}>
          Back
        </Button>
        {step < 3 ? (
          <Button
            onClick={() => setStep(step + 1)}
            disabled={(step === 0 && (test !== 'ok' || !id || taken)) || (step === 1 && !chosen.some((t) => t.checks.length)) || (step === 2 && perDay > volume)}
          >
            Continue <ArrowRight size={15} />
          </Button>
        ) : (
          <Button onClick={activate}>Activate</Button>
        )}
      </div>
    </>
  )
}

function Summary({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-4">
      <dt className="w-36 shrink-0 text-ink-3">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  )
}
