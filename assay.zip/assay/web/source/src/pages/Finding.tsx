import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { sure } from '../data'
import { num, pct } from '../lib/stats'
import { useStore } from '../store'
import { AgentNote, Card, DocMock, StatusPill, TrendChart } from '../ui'

export default function Finding() {
  const { customer, itemType, check } = useParams()
  const { metrics, findings, queue } = useStore()
  const m = metrics.find((x) => x.id === `${customer}/${itemType}/${check}`)
  if (!m) return <p className="text-ink-2">No such check.</p>

  const finding = findings[m.id]
  const examples = queue.filter((q) => q.metricId === m.id).slice(0, 4)
  const unit = m.check.perField ? 'values' : `${m.product.unit}s`
  const verdict =
    m.status === 'act'
      ? `Accuracy fell from ${pct(m.baseline)} to ${pct(m.p)}. ${sure(m.prob)} sure the drop is real.`
      : m.status === 'watch'
        ? `Accuracy looks lower, ${pct(m.p)} against ${pct(m.baseline)}, but the evidence is not strong enough yet.`
        : `Holding at ${pct(m.p)}, in line with the ${pct(m.baseline)} baseline.`

  return (
    <>
      <Link to={`/customers/${m.customer.id}`} className="mb-5 inline-flex items-center gap-1 text-sm text-ink-2 hover:text-ink">
        <ArrowLeft size={14} /> {m.customer.name}
      </Link>
      <header className="mb-6 flex items-start justify-between gap-6">
        <div>
          <div className="mb-2 flex items-center gap-2 text-xs text-ink-3">
            <StatusPill status={m.status} />
            <span>
              {m.customer.name} · {m.product.name}
            </span>
          </div>
          <h1 className="text-[26px] font-semibold leading-tight tracking-tight">
            {m.check.name} on {m.itemType.name}
          </h1>
          <p className="mt-1.5 text-[15px] text-ink-2">{verdict}</p>
        </div>
      </header>

      <Card className="p-5">
        <TrendChart days={m.days} baseline={m.baseline} />
      </Card>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="p-5">
          <h2 className="text-sm font-semibold">How sure</h2>
          <dl className="num mt-3 space-y-2.5 text-sm">
            <Row label="Last 7 days" value={`${m.k} of ${m.n} right`} />
            <Row label="Accuracy" value={`${pct(m.p)} (${pct(m.lo)}–${pct(m.hi)})`} />
            <Row label="Baseline, first 20 days" value={`${pct(m.baseline)} of ${num(m.baseN)}`} />
            <Row label="Chance it is below baseline" value={sure(m.prob)} />
            <Row label={`Still stands after testing all ${metrics.length} checks together`} value={m.survivesFdr ? 'Yes' : 'No'} />
          </dl>
          {m.drop > 0 && (
            <p className="mt-4 border-t border-line pt-3 text-sm text-ink-2">
              At current volume that is about {num(m.extraErrorsPerDay)} more wrong {unit} a day.
            </p>
          )}
        </Card>

        <Card className="p-5">
          <h2 className="text-sm font-semibold">Where it concentrates</h2>
          {finding ? (
            <>
              <div className="mt-1 flex items-center gap-4 text-xs text-ink-3">
                <span>By {finding.sliceBy.toLowerCase()}</span>
                <span className="flex items-center gap-1.5">
                  <i className="h-2 w-3 rounded-sm bg-accent" /> failures
                </span>
                <span className="flex items-center gap-1.5">
                  <i className="h-2 w-3 rounded-sm bg-line-strong" /> volume
                </span>
              </div>
              <div className="mt-3 space-y-3.5">
                {finding.slices.map((s) => (
                  <div key={s.label}>
                    <div className="num flex items-baseline justify-between text-sm">
                      <span>{s.label}</span>
                      <span className="text-xs text-ink-3">
                        {pct(s.failShare, 0)} of failures, {pct(s.volShare, 0)} of volume
                      </span>
                    </div>
                    <div className="mt-1.5 space-y-0.5">
                      <div className="h-2 rounded-r-sm bg-accent" style={{ width: pct(s.failShare, 0) }} />
                      <div className="h-2 rounded-r-sm bg-line-strong" style={{ width: pct(s.volShare, 0) }} />
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="mt-3 text-sm text-ink-2">{m.status === 'healthy' ? 'Nothing to look into.' : 'No slice stands out yet. Errors are spread evenly.'}</p>
          )}
        </Card>

        <Card className="p-5">
          <h2 className="text-sm font-semibold">What to do</h2>
          <div className="mt-3">
            {finding ? <AgentNote>{finding.action}</AgentNote> : <p className="text-sm text-ink-2">{m.status === 'healthy' ? 'Nothing. Sampling continues daily.' : 'Keep sampling. A verdict needs a few more days of data.'}</p>}
          </div>
          {finding && <p className="mt-3 text-sm text-ink-2">Why: {finding.cause}</p>}
        </Card>
      </div>

      {examples.length > 0 && (
        <section className="mt-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold">Examples waiting for a person</h2>
            <Link to={`/customers/${m.customer.id}/review`} className="inline-flex items-center gap-1 text-sm font-medium text-accent-strong hover:underline">
              Open review <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {examples.map((q) => (
              <div key={q.id}>
                <DocMock item={q} compact />
                <p className="mt-2 text-xs text-ink-2">
                  <span className="font-medium text-ink">{q.ref}</span> · {q.reason}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}
    </>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="text-ink-2">{label}</dt>
      <dd className="shrink-0 font-medium">{value}</dd>
    </div>
  )
}
