import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ChevronDown, ChevronRight, Plus } from 'lucide-react'
import { rollup, worst, type Customer, type Metric, type Product, type Status } from '../data'
import { num, pct } from '../lib/stats'
import { api, useStore } from '../store'
import { Button, buttonClass, Card, Delta, Headline, Heat, PageHeader, Sparkline, STATUS, StatusPill } from '../ui'

const ORDER: Record<Status, number> = { act: 0, watch: 1, healthy: 2 }

export default function ProductPage() {
  const { productId } = useParams()
  const { products, customers, metrics, labels, queueFor, reload } = useStore()
  const product = products.find((p) => p.id === productId)
  if (!product) return <p className="text-ink-2">No such product.</p>

  const own = customers.filter((c) => c.productId === product.id)
  const of = (c: Customer) => metrics.filter((m) => m.customer.id === c.id)
  const rank = (c: Customer) => (c.collecting ? 3 : ORDER[worst(of(c))])
  const sorted = [...own].sort((a, b) => rank(a) - rank(b))
  const all = metrics.filter((m) => m.product.id === product.id)
  const nAct = all.filter((m) => m.status === 'act').length
  const nWatch = all.filter((m) => m.status === 'watch').length
  const roll = rollup(all)

  return (
    <>
      <PageHeader
        eyebrow="Product"
        title={
          <span className="flex items-center gap-3">
            {product.name}
            <span className={`rounded-full px-2 py-0.5 text-xs font-semibold tracking-normal ${product.live ? 'bg-good-soft text-good-ink' : 'bg-sunken text-ink-2'}`}>{product.live ? 'Live' : 'Draft'}</span>
          </span>
        }
        sub={product.blurb}
        action={
          product.live ? (
            <Link to={`/products/${product.id}/new-customer`} className={buttonClass()}>
              <Plus size={15} /> Add customer
            </Link>
          ) : (
            <Button onClick={() => api(`/products/${product.id}`, { live: true }, 'PATCH').then(reload)}>Publish</Button>
          )
        }
      />

      {roll && (
        <>
          <Headline roll={roll} status={worst(all)} who="customers" />
          <p className="mb-3 mt-7 text-sm">
            <span className="font-semibold">Customers.</span>{' '}
            <span className="text-ink-2">
              {nAct} {nAct === 1 ? 'check needs' : 'checks need'} action, {nWatch} to watch, {all.length - nAct - nWatch} healthy.
            </span>
          </p>
        </>
      )}

      <div className="space-y-3">
        {sorted.map((c) => (
          <CustomerSummary key={c.id} customer={c} product={product} metrics={of(c)} waiting={queueFor(c.id).filter((q) => !labels[q.id]).length} />
        ))}
        {!own.length && (
          <Card className="p-8 text-center text-sm text-ink-2">{product.live ? 'No customers yet. Add the first one.' : 'Publish this product to start adding customers.'}</Card>
        )}
      </div>

      <Setup product={product} startOpen={!own.length} />
    </>
  )
}

function CustomerSummary({ customer: c, product, metrics, waiting }: { customer: Customer; product: Product; metrics: Metric[]; waiting: number }) {
  const roll = rollup(metrics)
  const status = worst(metrics)
  return (
    <Link to={`/customers/${c.id}`} className="group block">
      <Card className="overflow-hidden transition-colors group-hover:border-line-strong">
        <div className="flex items-stretch">
          <div className="w-1 shrink-0" style={{ background: roll ? STATUS[status].color : 'var(--color-line-strong)' }} />
          <div className="grid min-w-0 flex-1 grid-cols-1 items-center gap-x-8 gap-y-5 p-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)]">
            <div className="min-w-0">
              <div className="flex items-center gap-2.5">
                <h3 className="truncate text-[17px] font-semibold tracking-tight">{c.name}</h3>
                {roll ? <StatusPill status={status} /> : <span className="rounded-full bg-sunken px-2 py-0.5 text-xs font-semibold text-ink-2">Collecting baseline</span>}
                <ChevronRight size={18} className="ml-auto shrink-0 text-ink-3 transition-transform group-hover:translate-x-0.5 group-hover:text-ink lg:hidden" />
              </div>
              <div className="truncate text-sm text-ink-3">{c.useCase}</div>
              {roll ? (
                <div className="mt-4 flex items-end justify-between gap-4">
                  <div>
                    <div className="flex items-baseline gap-2.5">
                      <span className="text-[38px] font-semibold leading-none tracking-tight">{pct(roll.p)}</span>
                      <Delta value={roll.p - roll.baseline} status={status} />
                    </div>
                    <div className="num mt-2 text-xs text-ink-2">
                      ≈ {num(roll.wrongPerDay)} wrong of {num(roll.outputsPerDay)} outputs a day
                    </div>
                    <div className="num mt-0.5 text-xs text-ink-3">{waiting ? `${waiting} waiting for a person` : 'Nothing waiting for a person'}</div>
                  </div>
                  <Sparkline days={roll.days} baseline={roll.baseline} width={170} height={64} />
                </div>
              ) : (
                <p className="mt-4 text-sm text-ink-2">First verdicts after 7 days of samples. {num(c.samplePerDay)} sampled a day.</p>
              )}
            </div>
            {roll && <Heat customer={c} product={product} metrics={metrics} />}
          </div>
        </div>
      </Card>
    </Link>
  )
}

function Setup({ product: p, startOpen }: { product: Product; startOpen: boolean }) {
  const [open, setOpen] = useState(startOpen)
  return (
    <section className="mt-8">
      <button onClick={() => setOpen(!open)} className="mb-3 flex items-center gap-1.5 text-sm font-semibold">
        {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        Product setup
        <span className="font-normal text-ink-3">· connection, output mapping, {p.checkTypes.length} checks</span>
      </button>
      {open && (
        <Card className="grid grid-cols-2 gap-8 p-6">
          <div>
            <h3 className="text-xs font-medium text-ink-3">Reads from</h3>
            <dl className="mt-2 space-y-1.5 text-xs">
              <Pair label="Output" value={p.outputUrl} />
              <Pair label="Evidence" value={p.evidenceUrl} />
              {Object.entries(p.mapping).map(([label, path]) => (
                <Pair key={label} label={label} value={path} />
              ))}
            </dl>
          </div>
          <div>
            <h3 className="text-xs font-medium text-ink-3">Checks</h3>
            <ul className="mt-2 space-y-2.5">
              {p.checkTypes.map((k) => (
                <li key={k.id} className="text-sm">
                  <span className="font-medium">{k.name}</span>
                  <span className="text-ink-3"> · {k.evidence.toLowerCase()}</span>
                  <div className="text-ink-2">{k.instruction}</div>
                </li>
              ))}
            </ul>
          </div>
        </Card>
      )}
    </section>
  )
}

function Pair({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-3">
      <dt className="w-28 shrink-0 text-ink-3">{label}</dt>
      <dd className="min-w-0 break-all font-mono text-ink-2">{value}</dd>
    </div>
  )
}
