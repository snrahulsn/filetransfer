import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { assemble, type Label, type QueueItem, type State } from './data'

/** Call the backend. Throws the server's message on failure so screens can show it. */
export async function api<T = unknown>(path: string, body?: unknown, method = body ? 'POST' : 'GET'): Promise<T> {
  const response = await fetch(`/api${path}`, { method, headers: body ? { 'Content-Type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.detail ?? `Request failed (${response.status})`)
  return data as T
}

interface Store extends State {
  labels: Record<string, Label>
  setLabel: (id: string, label: Label) => void
  queueFor: (customerId: string) => QueueItem[]
  reload: () => Promise<void>
}

const StoreContext = createContext<Store | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State | null>(null)
  const [error, setError] = useState('')
  const [labels, setLabels] = useState<Record<string, Label>>({})

  const reload = useCallback(async () => {
    try {
      const fresh = assemble(await api('/state'))
      // Keep this session's queue as first loaded, so labelled items stay visible until the page is reloaded.
      setState((old) => (old ? { ...fresh, queue: old.queue } : fresh))
    } catch (e) {
      setError(String(e instanceof Error ? e.message : e))
    }
  }, [])
  useEffect(() => void reload(), [reload])

  if (!state) return <div className="grid h-full place-items-center text-sm text-ink-2">{error ? `Cannot reach the Assay server: ${error}` : 'Loading…'}</div>

  const store: Store = {
    ...state,
    labels,
    setLabel: (id, label) => {
      setLabels((s) => ({ ...s, [id]: label }))
      void api('/labels', { id, label })
    },
    queueFor: (customerId) => state.queue.filter((q) => q.metricId.startsWith(`${customerId}/`)),
    reload,
  }
  return <StoreContext.Provider value={store}>{children}</StoreContext.Provider>
}

export function useStore() {
  const store = useContext(StoreContext)
  if (!store) throw new Error('useStore must be used inside StoreProvider')
  return store
}

export const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
