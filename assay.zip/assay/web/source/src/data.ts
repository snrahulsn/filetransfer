// Shapes returned by the backend (/api/state) and the few things derived from them in the browser.
import { pct } from './lib/stats'

export type Status = 'act' | 'watch' | 'healthy'
export type Label = 'right' | 'wrong' | 'unclear'

export interface CheckType {
  id: string
  name: string
  instruction: string
  evidence: string
  perField?: boolean
}

export interface Product {
  id: string
  name: string
  live: boolean
  unit: string // what one checked thing is called: document, call, ticket…
  blurb: string
  source: 'http' | 'demo'
  itemsUrl: string
  outputUrl: string
  evidenceUrl: string
  mapping: Record<string, string> // where things live in the platform's output
  checkTypes: CheckType[]
}

export interface ItemType {
  id: string
  name: string
  share: number // share of the customer's volume
  fields: string[]
  checks: string[] // check type ids that apply
}

export interface Customer {
  id: string
  name: string
  productId: string
  useCase: string
  itemsPerDay: number
  samplePerDay: number
  auditRate: number
  authEnv: string
  itemTypes: ItemType[]
  collecting: boolean // onboarded, baseline not built yet
}

export interface Point {
  date: Date
  p: number
  lo: number
  hi: number
}

export interface Day extends Point {
  k: number // right, pooled over the trailing 7 days
  n: number // checked, pooled over the trailing 7 days
  dayK: number
  dayN: number
}

export interface Metric {
  id: string
  customer: Customer
  product: Product
  itemType: ItemType
  check: CheckType
  days: Day[]
  baseline: number
  baseN: number
  k: number
  n: number
  p: number
  lo: number
  hi: number
  drop: number // baseline minus current
  prob: number // probability recent accuracy is below baseline accuracy
  survivesFdr: boolean
  extraErrorsPerDay: number
  status: Status
}

export interface Finding {
  cause: string
  sliceBy: string
  slices: { label: string; failShare: number; volShare: number }[]
  action: string
}

export interface QueueItem {
  id: string
  metricId: string
  ref: string
  field?: string
  claimed: string
  why: 'unsure' | 'audit'
  judge: 'right' | 'wrong' | 'unsure'
  confidence: number
  reason: string
  doc: { title?: string; rows?: [string, string][]; highlight?: string; note?: string; images?: string[] }
}

export interface State {
  today: Date
  products: Product[]
  customers: Customer[]
  metrics: Metric[]
  findings: Record<string, Finding>
  queue: QueueItem[]
  judge: { agree: number; n: number }
}

type RawMetric = Omit<Metric, 'customer' | 'product' | 'itemType' | 'check' | 'days'> & { customerId: string; itemTypeId: string; checkId: string; days: (Omit<Day, 'date'> & { date: string })[] }

/** Join the flat API response into the objects the screens use. */
export function assemble(raw: Omit<State, 'today' | 'metrics'> & { today: string; metrics: RawMetric[] }): State {
  const metrics: Metric[] = []
  for (const m of raw.metrics) {
    const customer = raw.customers.find((c) => c.id === m.customerId)
    const product = raw.products.find((p) => p.id === customer?.productId)
    const itemType = customer?.itemTypes.find((t) => t.id === m.itemTypeId)
    const check = product?.checkTypes.find((k) => k.id === m.checkId)
    if (customer && product && itemType && check) metrics.push({ ...m, customer, product, itemType, check, days: m.days.map((d) => ({ ...d, date: new Date(d.date) })) })
  }
  return { ...raw, today: new Date(raw.today), metrics }
}

export interface Rollup extends Point {
  baseline: number
  outputsPerDay: number
  wrongPerDay: number
  wrongPerDayAtBaseline: number
  days: Point[]
}

/** Volume-weighted accuracy across checks: of everything the product returned, how much was right. */
export function rollup(metrics: Metric[]): Rollup | null {
  if (!metrics.length) return null
  const length = Math.min(...metrics.map((m) => m.days.length))
  const weights = metrics.map((m) => m.customer.itemsPerDay * m.itemType.share * (m.check.perField ? m.itemType.fields.length : 1))
  const total = weights.reduce((s, w) => s + w, 0)
  const days: Point[] = []
  for (let back = length; back >= 1; back--) {
    let p = 0
    let variance = 0
    metrics.forEach((m, i) => {
      const { k, n } = m.days[m.days.length - back]
      const w = weights[i] / total
      const adjusted = (k + 2) / (n + 4) // Agresti–Coull, so a perfect small sample still carries uncertainty
      p += w * (n ? k / n : 1)
      variance += w * w * ((adjusted * (1 - adjusted)) / (n + 4))
    })
    const half = 1.96 * Math.sqrt(variance)
    days.push({ date: metrics[0].days[metrics[0].days.length - back].date, p, lo: Math.max(0, p - half), hi: Math.min(1, p + half) })
  }
  const baseline = metrics.reduce((s, m, i) => s + (weights[i] / total) * m.baseline, 0)
  const last = days[days.length - 1]
  return { ...last, baseline, outputsPerDay: total, wrongPerDay: total * (1 - last.p), wrongPerDayAtBaseline: total * (1 - baseline), days }
}

export const findingPath = (m: Metric) => `/finding/${m.id}`
export const sure = (prob: number) => (prob >= 0.999 ? 'Over 99.9%' : pct(prob, prob >= 0.99 ? 1 : 0))
export const worst = (metrics: Metric[]): Status => (metrics.some((m) => m.status === 'act') ? 'act' : metrics.some((m) => m.status === 'watch') ? 'watch' : 'healthy')
