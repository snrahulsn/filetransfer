/** Wilson score interval for k successes out of n. */
export function wilson(k: number, n: number, z = 1.96): [number, number] {
  if (n === 0) return [0, 1]
  const p = k / n
  const z2 = z * z
  const centre = (p + z2 / (2 * n)) / (1 + z2 / n)
  const half = (z * Math.sqrt((p * (1 - p)) / n + z2 / (4 * n * n))) / (1 + z2 / n)
  return [Math.max(0, centre - half), Math.min(1, centre + half)]
}

/** Standard normal CDF (Abramowitz–Stegun 7.1.26). */
export function normCdf(x: number): number {
  const y = Math.abs(x) / Math.SQRT2
  const t = 1 / (1 + 0.3275911 * y)
  const poly = ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t
  const erf = 1 - poly * Math.exp(-y * y)
  return x >= 0 ? 0.5 * (1 + erf) : 0.5 * (1 - erf)
}

/** Probability the recent true rate is below the baseline true rate, from a Beta posterior on each (normal approximation). */
export function probBelow(k: number, n: number, baseK: number, baseN: number): number {
  const posterior = (k: number, n: number) => {
    const mean = (k + 1) / (n + 2)
    return { mean, variance: (mean * (1 - mean)) / (n + 3) }
  }
  const recent = posterior(k, n)
  const base = posterior(baseK, baseN)
  return normCdf((base.mean - recent.mean) / Math.sqrt(recent.variance + base.variance))
}

/** Benjamini–Hochberg: which p-values survive at false-discovery rate q. */
export function benjaminiHochberg(p: number[], q = 0.05): boolean[] {
  const order = p.map((v, i) => [v, i] as const).sort((a, b) => a[0] - b[0])
  let cut = -1
  order.forEach(([v], rank) => {
    if (v <= ((rank + 1) / p.length) * q) cut = rank
  })
  const out = p.map(() => false)
  order.forEach(([, i], rank) => {
    if (rank <= cut) out[i] = true
  })
  return out
}

/** Items needed for a ± margin at 95% confidence, given the accuracy we expect. */
export function sampleSize(margin: number, expected = 0.95, z = 1.96): number {
  return Math.ceil((z * z * expected * (1 - expected)) / (margin * margin))
}

export function hash(s: string): number {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

/** Small seeded generator so fake data is the same on every load. */
export function mulberry32(seed: number) {
  let a = seed
  return () => {
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export const pct = (x: number, digits = 1) => (x * 100).toFixed(digits) + '%'
export const num = (x: number) => Math.round(x).toLocaleString('en-US')
export const shortDate = (d: Date) => d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
