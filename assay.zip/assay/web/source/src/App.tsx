import { BrowserRouter, Link, Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { rollup, worst } from './data'
import { StoreProvider, useStore } from './store'
import { pct, shortDate } from './lib/stats'
import { STATUS } from './ui'
import ProductPage from './pages/Product'
import Finding from './pages/Finding'
import Review from './pages/Review'
import { CustomerDetail, NewCustomer } from './pages/Customers'
import { NewProduct } from './pages/Products'

function Shell() {
  const { products, customers, metrics, today, judge } = useStore()
  const [, section, id] = useLocation().pathname.split('/')
  // Customer and finding pages belong to a product too, so its row stays lit while you are inside it.
  const activeProduct = section === 'products' ? id : customers.find((c) => c.id === id)?.productId

  return (
    <div className="flex h-full">
      <aside className="flex w-60 shrink-0 flex-col border-r border-line bg-surface">
        <Link to="/" className="flex h-16 items-center gap-2.5 px-5">
          <span className="grid h-7 w-7 place-items-center rounded-lg bg-ink text-[13px] font-bold text-white">A</span>
          <span className="text-[15px] font-semibold tracking-tight">Assay</span>
        </Link>

        <div className="px-5 pb-2 pt-3 text-[11px] font-semibold uppercase tracking-wider text-ink-3">Products</div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3">
          {products.map((p) => {
            const own = customers.filter((c) => c.productId === p.id)
            const mine = metrics.filter((m) => m.product.id === p.id)
            const status = worst(mine)
            const roll = rollup(mine)
            return (
              <NavLink
                key={p.id}
                to={`/products/${p.id}`}
                className={`flex items-center gap-2.5 rounded-lg px-2.5 py-2 transition-colors ${activeProduct === p.id ? 'bg-sunken' : 'hover:bg-sunken/60'}`}
              >
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: p.live && own.length ? STATUS[status].color : 'var(--color-line-strong)' }} />
                <span className="min-w-0 flex-1">
                  <span className={`block truncate text-sm font-medium ${activeProduct === p.id ? 'text-ink' : 'text-ink-2'}`}>{p.name}</span>
                  <span className="block text-xs text-ink-3">{p.live ? `${own.length} ${own.length === 1 ? 'customer' : 'customers'}` : 'Draft'}</span>
                </span>
                {roll && <span className="num text-sm font-semibold">{pct(roll.p)}</span>}
              </NavLink>
            )
          })}
          <Link to="/products/new" className="flex h-9 items-center gap-2.5 rounded-lg px-2.5 text-sm font-medium text-ink-2 transition-colors hover:bg-sunken/60 hover:text-ink">
            <Plus size={15} /> Add product
          </Link>
        </nav>

        <div className="border-t border-line p-4 text-xs text-ink-3">
          <div className="flex items-center gap-1.5 text-ink-2">
            <span className="h-1.5 w-1.5 rounded-full bg-good" /> Checked through {shortDate(new Date(today.getTime() - 86400000))}
          </div>
          <div className="num mt-0.5 pl-3">{judge.n ? `Judge matched people on ${judge.agree} of ${judge.n} audits` : 'No audit labels yet'}</div>
        </div>
      </aside>

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto max-w-[1080px] px-8 py-9">
          <Routes>
            <Route path="/" element={<Navigate to={`/products/${products[0].id}`} replace />} />
            <Route path="/products/new" element={<NewProduct />} />
            <Route path="/products/:productId" element={<ProductPage />} />
            <Route path="/products/:productId/new-customer" element={<NewCustomer />} />
            <Route path="/customers/:id" element={<CustomerDetail />} />
            <Route path="/customers/:id/review" element={<Review />} />
            <Route path="/finding/:customer/:itemType/:check" element={<Finding />} />
          </Routes>
        </div>
      </main>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <StoreProvider>
        <Shell />
      </StoreProvider>
    </BrowserRouter>
  )
}
