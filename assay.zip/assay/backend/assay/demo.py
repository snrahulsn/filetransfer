"""A fake platform with known truth, so the whole engine runs with no customer data and no model key."""
import random
import zlib
from datetime import date

from .sources import Claim, Item

PRODUCTS = [
    {
        "id": "ocr", "name": "Document OCR", "unit": "document", "live": 1, "source": "demo",
        "blurb": "Classifies documents, extracts fields, masks sensitive numbers and flags tampering.",
        "items_url": "https://api.example.com/v1/orders?date={date}",
        "output_url": "https://api.example.com/v1/orders/{id}/result",
        "evidence_url": "https://api.example.com/v1/orders/{id}/images",
        "mapping": {"Item IDs": "orders[].id", "One checked thing": "documents[]", "Its type": "documents[].type", "Its values": "documents[].fields.*", "Evidence": "images[].url"},
        "check_types": [
            {"id": "type", "name": "Document type", "evidence": "Original image", "instruction": "Look at the image. Is it the document type the platform says it is?"},
            {"id": "fields", "name": "Field values", "evidence": "Original image", "perField": True, "instruction": "Find each extracted value on the image. Does it match, ignoring spacing and letter case?"},
            {"id": "masking", "name": "Masking", "evidence": "Masked image", "instruction": "Look at the masked image. Is every sensitive number fully covered?"},
            {"id": "tamper", "name": "Tamper flag", "evidence": "Original image", "instruction": "Does the image show edits, overlays or mismatched fonts? Compare with the platform's tamper flag."},
        ],
    },
    {
        "id": "voice", "name": "Voice transcription", "unit": "call", "live": 0, "source": "demo",
        "blurb": "Transcribes support calls, labels speakers and redacts card numbers.",
        "items_url": "https://api.example.com/v1/calls?date={date}",
        "output_url": "https://api.example.com/v1/calls/{id}/transcript",
        "evidence_url": "https://api.example.com/v1/calls/{id}/audio",
        "mapping": {"Item IDs": "calls[].id", "One checked thing": "segments[]", "Its type": "call.category", "Its values": "segments[].text", "Evidence": "audio.url"},
        "check_types": [
            {"id": "transcript", "name": "Transcript accuracy", "evidence": "Audio clip", "instruction": "Listen to the clip. Does the transcript segment say what was spoken?"},
            {"id": "redaction", "name": "Redaction", "evidence": "Audio clip", "instruction": "Is every spoken card number removed from the transcript?"},
        ],
    },
]


def _t(id, name, share, fields, checks):
    return {"id": id, "name": name, "share": share, "fields": fields, "checks": checks}


CUSTOMERS = [
    {"id": "meridian", "name": "Meridian Finance", "product_id": "ocr", "use_case": "KYC for loan applications", "items_per_day": 900, "sample_per_day": 100, "audit_rate": 0.05, "auth_env": "",
     "item_types": [
         _t("aadhaar", "Aadhaar card", 0.34, ["Name", "Date of birth", "Aadhaar number", "Address"], ["type", "fields", "masking", "tamper"]),
         _t("pan", "PAN card", 0.28, ["Name", "Father's name", "Date of birth", "PAN number"], ["type", "fields", "tamper"]),
         _t("passbook", "Bank passbook", 0.18, ["Account holder", "Account number", "IFSC", "Branch"], ["type", "fields", "tamper"]),
         _t("voter", "Voter ID", 0.12, ["Name", "EPIC number", "Date of birth"], ["type", "fields"]),
         _t("licence", "Driving licence", 0.08, ["Name", "Licence number", "Valid until"], ["type", "fields"]),
     ]},
    {"id": "northwind", "name": "Northwind Insurance", "product_id": "ocr", "use_case": "Health claim intake", "items_per_day": 420, "sample_per_day": 60, "audit_rate": 0.05, "auth_env": "",
     "item_types": [
         _t("claim-form", "Claim form", 0.36, ["Policy number", "Patient name", "Admission date", "Claim amount"], ["type", "fields"]),
         _t("hospital-bill", "Hospital bill", 0.30, ["Hospital name", "Bill number", "Bill date", "Total amount"], ["type", "fields", "tamper"]),
         _t("discharge", "Discharge summary", 0.22, ["Patient name", "Diagnosis", "Discharge date"], ["type", "fields"]),
         _t("policy", "Policy schedule", 0.12, ["Policy number", "Insured name", "Sum insured"], ["type", "fields"]),
     ]},
    {"id": "harbor", "name": "Harbor Freight Lines", "product_id": "ocr", "use_case": "Customs paperwork", "items_per_day": 260, "sample_per_day": 30, "audit_rate": 0.08, "auth_env": "",
     "item_types": [
         _t("lading", "Bill of lading", 0.40, ["Shipper", "Consignee", "Container number", "Port of loading"], ["type", "fields"]),
         _t("invoice", "Commercial invoice", 0.38, ["Invoice number", "Seller", "Total value", "Currency"], ["type", "fields", "tamper"]),
         _t("packing", "Packing list", 0.22, ["Package count", "Gross weight", "Container number"], ["type", "fields"]),
     ]},
]

# What a new demo customer's recent output "contains".
DISCOVERED = [
    _t("invoice", "Invoice", 0.46, ["Invoice number", "Vendor", "Invoice date", "Total"], ["type", "fields", "tamper"]),
    _t("purchase-order", "Purchase order", 0.31, ["PO number", "Buyer", "Order date"], ["type", "fields"]),
    _t("delivery-note", "Delivery note", 0.19, ["Note number", "Received by", "Delivery date"], ["type", "fields"]),
    _t("unrecognised", "Unrecognised", 0.04, [], []),
]

# Where the fake platform has quietly got worse, and what the failures have in common.
DROPS = {
    "meridian/aadhaar/masking": {"base": 0.985, "to": 0.88, "days": 6, "attr": ("Image side", "Back", 0.84)},
    "meridian/pan/fields": {"base": 0.968, "to": 0.88, "days": 4, "field": ("Father's name", 0.61)},
    "northwind/hospital-bill/fields": {"base": 0.962, "to": 0.915, "days": 5, "attr": ("Format", "Handwritten", 0.58)},
}
ATTRS = {"Image side": ("Back", 0.22, "Front"), "Format": ("Handwritten", 0.31, "Printed")}


def _unit(key: str) -> float:
    return zlib.crc32(key.encode()) / 0xFFFFFFFF


def _rate(key: str, day: str) -> float:
    drop = DROPS.get(key)
    if drop and (date.today() - date.fromisoformat(day)).days <= drop["days"]:
        return drop["to"]
    return drop["base"] if drop else 0.955 + _unit(key) * 0.04


def sample(product: dict, customer: dict, day: str, rng: random.Random) -> list[Item]:
    types = [t for t in customer["item_types"] if t["checks"]]
    quota = max(1, round(customer["sample_per_day"] / max(1, len(types))))
    checks = {c["id"]: c for c in product["check_types"]}
    items = []
    for item_type in types:
        for _ in range(quota):
            ref = f"{customer['id'][:3].upper()}-{rng.randrange(10000, 99999)}"
            attrs = {name: (rare if rng.random() < share else common) for name, (rare, share, common) in ATTRS.items()}
            values = {f: f"{f[:3].upper()}-{rng.randrange(1000, 9999)}" for f in item_type["fields"]}
            claims, truth, note = [], [], None
            for check_id in item_type["checks"]:
                check = checks.get(check_id)
                if not check:
                    continue
                key = f"{customer['id']}/{item_type['id']}/{check_id}"
                wrong_rate = 1 - _rate(key, day)
                drop = DROPS.get(key, {}) if wrong_rate > 0.07 else {}
                if check.get("perField"):
                    for name in item_type["fields"]:
                        weight = 1.0
                        if "field" in drop:  # failures pile up on one field
                            hot, share = drop["field"]
                            weight = len(values) * (share if name == hot else (1 - share) / (len(values) - 1))
                        ok = rng.random() >= wrong_rate * weight
                        claims.append(Claim(check_id, name, values[name] if ok else values[name][:-1] + str((int(values[name][-1]) + 3) % 10)))
                        truth.append(ok)
                else:
                    ok = rng.random() >= wrong_rate
                    if not ok and "attr" in drop:  # failures pile up on one kind of item
                        name, value, share = drop["attr"]
                        attrs[name] = value if rng.random() < share else ATTRS[name][2]
                    if not ok:
                        note = f"{check['name']}: evidence does not support the platform's answer"
                    claims.append(Claim(check_id, None, item_type["name"] if check_id == "type" else "Passed"))
                    truth.append(ok)
            evidence = {"title": item_type["name"], "rows": [[f, v] for f, v in values.items()], "note": note}
            items.append(Item(ref, item_type["id"], claims, evidence, attrs, truth))
    return items


def judge(item: Item, rng: random.Random) -> list[dict]:
    """Stand-in judge: usually agrees with the truth, sometimes unsure, occasionally wrong, like a real one."""
    out = []
    for claim, ok in zip(item.claims, item.truth or []):
        if rng.random() < (0.04 if ok else 0.22):
            out.append({"verdict": "unsure", "confidence": round(rng.uniform(0.45, 0.7), 2), "reason": "Evidence is hard to read here; could go either way."})
            continue
        says_right = ok if rng.random() < 0.985 else not ok
        what = f"{claim.field} reads the same on the evidence." if claim.field else "Evidence supports the platform's answer."
        why_not = f"{claim.field} on the evidence differs from the extracted value." if claim.field else "Evidence contradicts the platform's answer."
        out.append({"verdict": "right" if says_right else "wrong", "confidence": round(rng.uniform(0.88, 0.99), 2), "reason": what if says_right else why_not})
    return out
