"""HTTP API and scheduler. Run with: uvicorn assay.api:app"""
import os
import threading
import time
from contextlib import asynccontextmanager
from datetime import date, timedelta
from pathlib import Path

from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db, demo, engine, sources
from .sources import slug

WEB = Path(os.environ.get("ASSAY_WEB", Path(__file__).resolve().parent.parent.parent / "web" / "dist"))
RUN_HOUR = int(os.environ.get("ASSAY_RUN_HOUR", "6"))


def load(con):
    products = [db.row(r) for r in con.execute("SELECT * FROM products ORDER BY rowid")]
    customers = [db.row(r) for r in con.execute("SELECT * FROM customers ORDER BY rowid")]
    return products, customers


def run_all(day: str) -> int:
    """Run one day for every customer of every live product. Days already run are skipped."""
    con = db.connect()
    products, customers = load(con)
    by_id = {p["id"]: p for p in products}
    stored = 0
    for customer in customers:
        product = by_id[customer["product_id"]]
        if not product["live"]:
            continue
        try:
            stored += engine.run_day(con, product, customer, day)
        except Exception as error:  # one unreachable platform must not stop the others
            print(f"run failed for {customer['id']} on {day}: {error}")
    con.close()
    return stored


def seed() -> None:
    con = db.connect()
    if os.environ.get("ASSAY_DEMO", "1") == "1" and not con.execute("SELECT 1 FROM products").fetchone():
        for product in demo.PRODUCTS:
            db.insert(con, "products", product)
        for customer in demo.CUSTOMERS:
            db.insert(con, "customers", customer)
        con.commit()
    con.close()
    # Demo customers get their history filled in; real ones start from the day they are added.
    con = db.connect()
    products, customers = load(con)
    by_id = {p["id"]: p for p in products}
    for customer in customers:
        if by_id[customer["product_id"]]["source"] == "demo" and customer["id"] in {c["id"] for c in demo.CUSTOMERS}:
            for back in range(engine.HISTORY_DAYS, 0, -1):
                engine.run_day(con, by_id[customer["product_id"]], customer, (date.today() - timedelta(days=back)).isoformat())
    con.close()


def scheduler() -> None:
    """Once a day after RUN_HOUR, check yesterday for everyone."""
    while True:
        if time.localtime().tm_hour >= RUN_HOUR:
            run_all((date.today() - timedelta(days=1)).isoformat())
        time.sleep(1800)


@asynccontextmanager
async def lifespan(_: FastAPI):
    seed()
    threading.Thread(target=scheduler, daemon=True).start()
    yield


app = FastAPI(title="Assay", lifespan=lifespan)


def product_out(p: dict) -> dict:
    return {"id": p["id"], "name": p["name"], "unit": p["unit"], "blurb": p["blurb"], "live": bool(p["live"]), "source": p["source"],
            "itemsUrl": p["items_url"], "outputUrl": p["output_url"], "evidenceUrl": p["evidence_url"], "mapping": p["mapping"], "checkTypes": p["check_types"]}


def customer_out(c: dict, collecting: bool) -> dict:
    return {"id": c["id"], "name": c["name"], "productId": c["product_id"], "useCase": c["use_case"], "itemsPerDay": c["items_per_day"],
            "samplePerDay": c["sample_per_day"], "auditRate": c["audit_rate"], "authEnv": c["auth_env"], "itemTypes": c["item_types"], "collecting": collecting}


@app.get("/api/state")
def state():
    con = db.connect()
    products, customers = load(con)
    today = date.today()
    metrics = engine.metrics(con, products, customers, today)
    names = {}
    for c in customers:
        checks = {k["id"]: k["name"] for p in products if p["id"] == c["product_id"] for k in p["check_types"]}
        for t in c["item_types"]:
            for k in t["checks"]:
                names[f"{c['id']}/{t['id']}/{k}"] = (t["name"], checks.get(k, k))
    measured = {m["customerId"] for m in metrics}
    out = {
        "today": today.isoformat(),
        "products": [product_out(p) for p in products],
        "customers": [customer_out(c, c["id"] not in measured) for c in customers],
        "metrics": metrics,
        "findings": engine.findings(con, [m for m in metrics if m["status"] != "healthy"], names, today),
        "queue": engine.queue(con, today),
        "judge": engine.judge_agreement(con),
    }
    con.close()
    return out


class LabelIn(BaseModel):
    id: str
    label: str


@app.post("/api/labels")
def label(body: LabelIn):
    if body.label not in ("right", "wrong", "unclear"):
        raise HTTPException(400, "label must be right, wrong or unclear")
    con = db.connect()
    con.execute("UPDATE results SET label = ? WHERE id = ?", (body.label, int(body.id)))
    con.commit()
    con.close()
    return {"ok": True}


class ProductIn(BaseModel):
    name: str
    unit: str
    blurb: str = ""
    source: str = "http"
    itemsUrl: str = ""
    outputUrl: str = ""
    evidenceUrl: str = ""
    mapping: dict
    checkTypes: list[dict]


@app.post("/api/products")
def add_product(body: ProductIn):
    con = db.connect()
    id = slug(body.name)
    if not id or con.execute("SELECT 1 FROM products WHERE id = ?", (id,)).fetchone():
        raise HTTPException(409, "A product with this name already exists.")
    checks = [{**c, "id": slug(c.get("name", "")) or f"check-{i + 1}"} for i, c in enumerate(body.checkTypes)]
    db.insert(con, "products", {"id": id, "name": body.name, "unit": body.unit, "blurb": body.blurb or "No description.", "live": 1, "source": body.source,
                                "items_url": body.itemsUrl, "output_url": body.outputUrl, "evidence_url": body.evidenceUrl, "mapping": body.mapping, "check_types": checks})
    con.commit()
    con.close()
    return {"id": id}


class ProductPatch(BaseModel):
    live: bool


@app.patch("/api/products/{id}")
def patch_product(id: str, body: ProductPatch):
    con = db.connect()
    db.update(con, "products", id, {"live": int(body.live)})
    con.commit()
    con.close()
    return {"ok": True}


class ProbeIn(BaseModel):
    outputUrl: str
    evidenceUrl: str
    sampleId: str
    authEnv: str = ""


@app.post("/api/probe")
def probe(body: ProbeIn):
    """Fetch one real item so the mapping can be drafted from what the platform actually returns."""
    headers = sources._auth({"auth_env": body.authEnv})
    try:
        output = sources.get_json(body.outputUrl.replace("{id}", body.sampleId), headers)
        evidence = sources.get_json(body.evidenceUrl.replace("{id}", body.sampleId), headers)
    except Exception as error:
        raise HTTPException(502, f"Could not read the endpoints: {error}")
    return {"sample": output, "mapping": sources.guess_mapping(output, evidence)}


class DiscoverIn(BaseModel):
    productId: str
    authEnv: str = ""


@app.post("/api/discover")
def discover(body: DiscoverIn):
    con = db.connect()
    product = next((p for p in load(con)[0] if p["id"] == body.productId), None)
    con.close()
    if not product:
        raise HTTPException(404, "No such product.")
    try:
        return sources.discover(product, {"auth_env": body.authEnv}, (date.today() - timedelta(days=1)).isoformat())
    except Exception as error:
        raise HTTPException(502, f"Could not read recent output: {error}")


class CustomerIn(BaseModel):
    name: str
    productId: str
    useCase: str = ""
    itemsPerDay: int
    samplePerDay: int
    auditRate: float
    authEnv: str = ""
    itemTypes: list[dict]


@app.post("/api/customers")
def add_customer(body: CustomerIn):
    con = db.connect()
    id = slug(body.name)
    if not id or con.execute("SELECT 1 FROM customers WHERE id = ?", (id,)).fetchone():
        raise HTTPException(409, "A customer with this name already exists.")
    db.insert(con, "customers", {"id": id, "name": body.name, "product_id": body.productId, "use_case": body.useCase or "Not specified", "items_per_day": body.itemsPerDay,
                                 "sample_per_day": body.samplePerDay, "audit_rate": body.auditRate, "auth_env": body.authEnv, "item_types": body.itemTypes})
    con.commit()
    con.close()
    return {"id": id}


class CustomerPatch(BaseModel):
    samplePerDay: int | None = None
    auditRate: float | None = None


@app.patch("/api/customers/{id}")
def patch_customer(id: str, body: CustomerPatch):
    values = {k: v for k, v in {"sample_per_day": body.samplePerDay, "audit_rate": body.auditRate}.items() if v is not None}
    if values:
        con = db.connect()
        db.update(con, "customers", id, values)
        con.commit()
        con.close()
    return {"ok": True}


@app.post("/api/run")
def run_now():
    """Run yesterday's check now instead of waiting for the scheduler."""
    return {"stored": run_all((date.today() - timedelta(days=1)).isoformat())}


@app.get("/api/evidence/{result_id}/{n}")
def evidence_image(result_id: int, n: int):
    """Serve an evidence image to the reviewer through the server, so the customer's key never reaches the browser."""
    con = db.connect()
    r = con.execute("SELECT r.evidence, c.auth_env FROM results r JOIN customers c ON c.id = r.customer_id WHERE r.id = ?", (result_id,)).fetchone()
    con.close()
    images = db.row(r)["evidence"].get("images", []) if r else []
    if n >= len(images):
        raise HTTPException(404)
    data, media_type = sources.http_get(images[n], sources._auth({"auth_env": r["auth_env"]}))
    return Response(data, media_type=media_type)


if WEB.exists():
    app.mount("/assets", StaticFiles(directory=WEB / "assets"), name="assets")

    @app.get("/{path:path}")
    def spa(path: str):
        return FileResponse(WEB / "index.html")
