"""Statistics used to turn sampled verdicts into decisions. Pure Python, no dependencies."""
import math


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score interval for k successes out of n."""
    if n == 0:
        return 0.0, 1.0
    p = k / n
    z2 = z * z
    centre = (p + z2 / (2 * n)) / (1 + z2 / n)
    half = z * math.sqrt(p * (1 - p) / n + z2 / (4 * n * n)) / (1 + z2 / n)
    return max(0.0, centre - half), min(1.0, centre + half)


def norm_cdf(x: float) -> float:
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def prob_below(k: int, n: int, base_k: int, base_n: int) -> float:
    """Probability the recent true rate is below the baseline true rate (Beta posteriors, normal approximation)."""

    def posterior(k: int, n: int) -> tuple[float, float]:
        mean = (k + 1) / (n + 2)
        return mean, mean * (1 - mean) / (n + 3)

    recent_mean, recent_var = posterior(k, n)
    base_mean, base_var = posterior(base_k, base_n)
    return norm_cdf((base_mean - recent_mean) / math.sqrt(recent_var + base_var))


def benjamini_hochberg(p_values: list[float], q: float = 0.05) -> list[bool]:
    """Which p-values survive at false-discovery rate q. Needed because many checks are tested every day."""
    order = sorted(range(len(p_values)), key=lambda i: p_values[i])
    cut = -1
    for rank, i in enumerate(order):
        if p_values[i] <= (rank + 1) / len(p_values) * q:
            cut = rank
    survives = [False] * len(p_values)
    for rank, i in enumerate(order):
        survives[i] = rank <= cut
    return survives


def sample_size(margin: float, expected: float = 0.95, z: float = 1.96) -> int:
    """Items needed for a +/- margin at 95% confidence, given the accuracy we expect."""
    return math.ceil(z * z * expected * (1 - expected) / (margin * margin))
