"""Where sampled items come from: a real platform over HTTP, or the built-in demo platform."""
import json
import os
import random
import re
import urllib.request
from dataclasses import dataclass, field


@dataclass
class Claim:
    check_id: str
    field: str | None
    claimed: str


@dataclass
class Item:
    ref: str
    type_id: str
    claims: list[Claim]
    evidence: dict  # shown to the judge and to the reviewer: {"images": [...]} or {"title", "rows", ...}
    attrs: dict = field(default_factory=dict)
    truth: list[bool] | None = None  # demo platform only: whether each claim is actually right


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-")


def dig(data, path: str) -> list:
    """Follow a path like `documents[].fields.*` and return every value it reaches."""
    found = [data]
    for token in [t for t in path.split(".") if t]:
        each = token.endswith("[]")
        key = token[:-2] if each else token
        step = []
        for node in found:
            if key == "*":
                step.extend(node.values() if isinstance(node, dict) else [])
                continue
            value = node.get(key) if isinstance(node, dict) and key else node
            if value is None:
                continue
            step.extend(value if each and isinstance(value, list) else [value])
        found = step
    return found


def _auth(customer: dict) -> dict:
    key = os.environ.get(customer.get("auth_env") or "", "")
    return {"Authorization": f"Bearer {key}"} if key else {}


def http_get(url: str, headers: dict) -> tuple[bytes, str]:
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=30) as response:
        return response.read(), response.headers.get_content_type()


def get_json(url: str, headers: dict):
    return json.loads(http_get(url, headers)[0])


def http_refs(product: dict, customer: dict, day: str) -> list[str]:
    data = get_json(product["items_url"].replace("{date}", day), _auth(customer))
    return [str(r) for r in dig(data, product["mapping"].get("Item IDs", ""))]


def http_items(product: dict, customer: dict, ref: str) -> list[Item]:
    """Fetch one item from the platform and turn each checked thing in it into claims."""
    mapping, headers = product["mapping"], _auth(customer)
    output = get_json(product["output_url"].replace("{id}", ref), headers)
    evidence = get_json(product["evidence_url"].replace("{id}", ref), headers)
    images = [u for u in dig(evidence, mapping.get("Evidence", "")) if isinstance(u, str)]
    unit_path = mapping["One checked thing"]
    relative = lambda name: mapping.get(name, "").removeprefix(unit_path).lstrip(".")
    types = {slug(t["name"]): t for t in customer["item_types"]} | {t["id"]: t for t in customer["item_types"]}
    checks = {c["id"]: c for c in product["check_types"]}

    items = []
    for i, unit in enumerate(dig(output, unit_path)):
        kind = next(iter(dig(unit, relative("Its type"))), "")
        item_type = types.get(slug(kind))
        if not item_type:
            continue  # a type this customer is not set up to check
        fields_path = relative("Its values").removesuffix(".*").removesuffix("*")
        values = next(iter(dig(unit, fields_path)), {}) if fields_path else unit
        values = {slug(k): (k, v) for k, v in values.items()} if isinstance(values, dict) else {}
        claims = []
        for check_id in item_type["checks"]:
            check = checks.get(check_id)
            if not check:
                continue
            if check.get("perField"):
                claims += [Claim(check_id, name, str(values[slug(name)][1])) for name in item_type["fields"] if slug(name) in values]
            else:
                # A whole-item check reads the unit's own value for that check when the platform returns one.
                stated = unit.get(check_id) if isinstance(unit, dict) else None
                claims.append(Claim(check_id, None, str(kind if stated is None else stated)))
        items.append(Item(f"{ref}#{i + 1}", item_type["id"], claims, {"images": images, "headers": bool(headers)}))
    return items


def sample(product: dict, customer: dict, day: str, rng: random.Random) -> list[Item]:
    """Random sample for one day, capped per item type so small types are measured as precisely as large ones."""
    if product["source"] == "demo":
        from . import demo

        return demo.sample(product, customer, day, rng)
    quota = max(1, round(customer["sample_per_day"] / max(1, len(customer["item_types"]))))
    taken: dict[str, int] = {}
    out: list[Item] = []
    refs = http_refs(product, customer, day)
    rng.shuffle(refs)
    for ref in refs[: customer["sample_per_day"] * 3]:
        for item in http_items(product, customer, ref):
            if taken.get(item.type_id, 0) < quota:
                taken[item.type_id] = taken.get(item.type_id, 0) + 1
                out.append(item)
        if len(taken) == len(customer["item_types"]) and all(n >= quota for n in taken.values()):
            break
    return out


def discover(product: dict, customer: dict, day: str, limit: int = 40) -> list[dict]:
    """Profile recent output for a new customer: which item types and fields actually occur."""
    if product["source"] == "demo":
        from . import demo

        return demo.DISCOVERED
    mapping, headers = product["mapping"], _auth(customer)
    unit_path = mapping["One checked thing"]
    relative = lambda name: mapping.get(name, "").removeprefix(unit_path).lstrip(".")
    seen: dict[str, dict] = {}
    total = 0
    for ref in http_refs(product, customer, day)[:limit]:
        for unit in dig(get_json(product["output_url"].replace("{id}", ref), headers), unit_path):
            kind = str(next(iter(dig(unit, relative("Its type"))), "Unrecognised"))
            fields_path = relative("Its values").removesuffix(".*").removesuffix("*")
            values = next(iter(dig(unit, fields_path)), {}) if fields_path else {}
            entry = seen.setdefault(kind, {"count": 0, "fields": {}})
            entry["count"] += 1
            total += 1
            for name in values if isinstance(values, dict) else []:
                entry["fields"][name] = entry["fields"].get(name, 0) + 1
    all_checks = [c["id"] for c in product["check_types"]]
    return [
        {
            "id": slug(kind),
            "name": kind,
            "share": round(entry["count"] / total, 3),
            # keep fields present on at least half of the items of this type
            "fields": [f for f, n in entry["fields"].items() if n >= entry["count"] / 2],
            "checks": all_checks if entry["count"] / total >= 0.05 else [],
        }
        for kind, entry in sorted(seen.items(), key=lambda kv: -kv[1]["count"])
    ]


def guess_mapping(output, evidence) -> dict:
    """First guess at where things live in a sample output; the person corrects it in the UI."""

    def first_list(node, path=""):
        if isinstance(node, list) and node and isinstance(node[0], dict):
            return path + "[]", node[0]
        if isinstance(node, dict):
            for key, value in node.items():
                hit = first_list(value, f"{path}.{key}" if path else key)
                if hit:
                    return hit
        return None

    def first_url(node, path=""):
        if isinstance(node, str) and node.startswith("http"):
            return path
        if isinstance(node, list) and node:
            return first_url(node[0], path + "[]")
        if isinstance(node, dict):
            for key, value in node.items():
                hit = first_url(value, f"{path}.{key}" if path else key)
                if hit:
                    return hit
        return None

    unit_path, unit = first_list(output) or ("", output if isinstance(output, dict) else {})
    type_key = next((k for k in unit if k.lower() in ("type", "doc_type", "document_type", "category", "class", "label")), "")
    values_key = next((k for k, v in unit.items() if isinstance(v, dict)), "")
    join = lambda key: f"{unit_path}.{key}" if unit_path and key else key
    return {
        "Item IDs": "",
        "One checked thing": unit_path,
        "Its type": join(type_key),
        "Its values": join(values_key) + ".*" if values_key else "",
        "Evidence": first_url(evidence) or "",
    }
