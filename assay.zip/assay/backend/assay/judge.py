"""The judge: a cheap model that verifies the platform's existing output against the evidence. It never redoes the work."""
import base64
import json
import os
import random

from . import demo
from .sources import Item, _auth, http_get

UNSURE_BELOW = float(os.environ.get("ASSAY_UNSURE_BELOW", "0.8"))

SCHEMA = {
    "type": "object",
    "properties": {
        "verdicts": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "claim": {"type": "integer"},
                    "verdict": {"type": "string", "enum": ["right", "wrong", "unsure"]},
                    "confidence": {"type": "number"},
                    "reason": {"type": "string"},
                },
                "required": ["claim", "verdict", "confidence", "reason"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["verdicts"],
    "additionalProperties": False,
}

SYSTEM = """You check the output of another AI system against the evidence it was produced from.
For each numbered claim, decide whether the evidence supports it: right, wrong, or unsure.
Judge only from what the evidence shows. If the evidence is unreadable, cropped or ambiguous, answer unsure.
Give a confidence from 0 to 1 and one short sentence saying what you saw."""


def _client():
    import anthropic

    if os.environ.get("ASSAY_JUDGE") == "bedrock":
        return anthropic.AnthropicBedrockMantle(aws_region=os.environ.get("AWS_REGION", "us-east-1")), os.environ.get("ASSAY_JUDGE_MODEL", "anthropic.claude-haiku-4-5")
    return anthropic.Anthropic(), os.environ.get("ASSAY_JUDGE_MODEL", "claude-haiku-4-5")


def judge(product: dict, customer: dict, item: Item, rng: random.Random) -> list[dict]:
    """One verdict per claim on the item: {verdict, confidence, reason}."""
    if item.truth is not None:
        return demo.judge(item, rng)
    if os.environ.get("ASSAY_JUDGE", "") not in ("anthropic", "bedrock"):
        raise RuntimeError("Set ASSAY_JUDGE to 'anthropic' or 'bedrock' to check a real platform.")

    checks = {c["id"]: c for c in product["check_types"]}
    content = []
    for url in item.evidence.get("images", [])[:8]:
        data, media_type = http_get(url, _auth(customer))  # fetched here because the model cannot reach a private URL
        content.append({"type": "image", "source": {"type": "base64", "media_type": media_type, "data": base64.standard_b64encode(data).decode()}})
    lines = []
    for i, claim in enumerate(item.claims):
        check = checks[claim.check_id]
        subject = f"{claim.field} = {claim.claimed!r}" if claim.field else f"platform says {claim.claimed!r}"
        lines.append(f"Claim {i}: [{check['name']}] {subject}. {check['instruction']}")
    content.append({"type": "text", "text": "\n".join(lines)})

    client, model = _client()
    response = client.messages.create(
        model=model,
        max_tokens=4000,
        system=SYSTEM,
        messages=[{"role": "user", "content": content}],
        output_config={"format": {"type": "json_schema", "schema": SCHEMA}},
    )
    text = next(b.text for b in response.content if b.type == "text")
    by_claim = {v["claim"]: v for v in json.loads(text)["verdicts"]}
    out = []
    for i in range(len(item.claims)):
        v = by_claim.get(i, {"verdict": "unsure", "confidence": 0.0, "reason": "The judge returned no verdict for this claim."})
        verdict = "unsure" if v["confidence"] < UNSURE_BELOW else v["verdict"]
        out.append({"verdict": verdict, "confidence": v["confidence"], "reason": v["reason"]})
    return out
