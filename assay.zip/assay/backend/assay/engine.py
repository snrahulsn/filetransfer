"""The daily loop and the numbers that come out of it: sample, judge, store, then measure and explain."""
import json
import random
from collections import defaultdict
from datetime import date, timedelta

from . import db, judge, sources
from .stats import benjamini_hochberg, prob_below, wilson

HISTORY_DAYS = 36   # kept in view: 30 plotted plus 6 to fill the first trailing window
RECENT_DAYS = 7     # the headline number pools this many days
BASELINE_DAYS = 20  # the first days of the window are the baseline
MIN_DAYS = 14       # a check needs this much history before it gets a verdict

# A person's label beats the judge; anything still undecided is left out of the count.
FINAL = "CASE WHEN label IN ('right', 'wrong') THEN label WHEN label = 'unclear' THEN NULL WHEN verdict = 'unsure' THEN NULL ELSE verdict END"


def run_day(con, product: dict, customer: dict, day: str) -> int:
    """Sample one day's items for one customer, judge every claim, store the verdicts. Safe to call twice."""
    if con.execute("SELECT 1 FROM results WHERE customer_id = ? AND day = ? LIMIT 1", (customer["id"], day)).fetchone():
        return 0
    rng = random.Random(f"{customer['id']}/{day}")
    stored = 0
    for item in sources.sample(product, customer, day, rng):
        for claim, v in zip(item.claims, judge.judge(product, customer, item, rng)):
            audit = v["verdict"] != "unsure" and rng.random() < customer["audit_rate"]
            db.insert(con, "results", {
                "customer_id": customer["id"], "item_type": item.type_id, "check_id": claim.check_id, "field": claim.field,
                "item_ref": item.ref, "day": day, "claimed": claim.claimed, "verdict": v["verdict"], "confidence": v["confidence"],
                "reason": v["reason"], "audit": int(audit), "evidence": {**item.evidence, "highlight": claim.field}, "attrs": item.attrs,
            })
            stored += 1
    con.commit()
    return stored


def metrics(con, products: list[dict], customers: list[dict], today: date) -> list[dict]:
    """One entry per customer x item type x check: 30-day trend, baseline, and a verdict."""
    days = [(today - timedelta(days=HISTORY_DAYS - i)).isoformat() for i in range(HISTORY_DAYS)]
    index = {d: i for i, d in enumerate(days)}
    counts: dict[tuple, list[list[int]]] = defaultdict(lambda: [[0, 0] for _ in days])
    for r in con.execute(
        f"SELECT customer_id, item_type, check_id, day, SUM(({FINAL}) = 'right') AS k, COUNT({FINAL}) AS n FROM results WHERE day >= ? AND day < ? GROUP BY 1, 2, 3, 4",
        (days[0], today.isoformat()),
    ):
        counts[(r["customer_id"], r["item_type"], r["check_id"])][index[r["day"]]] = [r["k"] or 0, r["n"]]

    product_by_id = {p["id"]: p for p in products}
    out = []
    for customer in customers:
        product = product_by_id[customer["product_id"]]
        checks = {c["id"]: c for c in product["check_types"]}
        for item_type in customer["item_types"]:
            for check_id in item_type["checks"]:
                raw = counts.get((customer["id"], item_type["id"], check_id))
                check = checks.get(check_id)
                if not raw or not check:
                    continue
                first = next(i for i, (_, n) in enumerate(raw) if n)
                if HISTORY_DAYS - first < MIN_DAYS:
                    continue  # still collecting a baseline
                start = first + RECENT_DAYS - 1
                series = []
                for i in range(start, HISTORY_DAYS):
                    k = sum(c[0] for c in raw[i - RECENT_DAYS + 1 : i + 1])
                    n = sum(c[1] for c in raw[i - RECENT_DAYS + 1 : i + 1])
                    lo, hi = wilson(k, n)
                    series.append({"date": days[i], "k": k, "n": n, "p": k / n if n else 1.0, "lo": lo, "hi": hi, "dayK": raw[i][0], "dayN": raw[i][1]})
                base = raw[start : start + min(BASELINE_DAYS, len(series) - RECENT_DAYS)]
                base_k, base_n = sum(c[0] for c in base), sum(c[1] for c in base)
                if not base_n or not series[-1]["n"]:
                    continue
                last, baseline = series[-1], base_k / base_n
                per_item = len(item_type["fields"]) if check.get("perField") else 1
                out.append({
                    "id": f"{customer['id']}/{item_type['id']}/{check_id}",
                    "customerId": customer["id"], "itemTypeId": item_type["id"], "checkId": check_id,
                    "days": series, "baseline": baseline, "baseN": base_n,
                    "k": last["k"], "n": last["n"], "p": last["p"], "lo": last["lo"], "hi": last["hi"],
                    "drop": baseline - last["p"], "prob": prob_below(last["k"], last["n"], base_k, base_n),
                    "extraErrorsPerDay": max(0.0, baseline - last["p"]) * customer["items_per_day"] * item_type["share"] * per_item,
                    "survivesFdr": False, "status": "healthy",
                })

    # Many checks are tested every day, so control the false-discovery rate before raising an alarm.
    if out:
        for m, survives in zip(out, benjamini_hochberg([1 - m["prob"] for m in out])):
            m["survivesFdr"] = survives
            if survives and m["drop"] >= 0.02:
                m["status"] = "act"
            elif (survives or m["prob"] >= 0.95) and m["drop"] >= 0.01:
                m["status"] = "watch"
    return out


def findings(con, flagged: list[dict], names: dict, today: date) -> dict:
    """For each flagged check, find the slice where failures pile up: by field, or by any item attribute."""
    since = (today - timedelta(days=RECENT_DAYS)).isoformat()
    out = {}
    for m in flagged:
        rows = con.execute(
            f"SELECT field, attrs, ({FINAL}) AS final FROM results WHERE customer_id = ? AND item_type = ? AND check_id = ? AND day >= ?",
            (m["customerId"], m["itemTypeId"], m["checkId"], since),
        ).fetchall()
        rows = [r for r in rows if r["final"]]
        fails = sum(r["final"] == "wrong" for r in rows)
        if fails < 8:
            continue
        groups: dict[str, dict[str, list[int]]] = defaultdict(lambda: defaultdict(lambda: [0, 0]))
        for r in rows:
            tags = dict(json.loads(r["attrs"]))
            if r["field"]:
                tags["Field"] = r["field"]
            for key, value in tags.items():
                groups[key][str(value)][0] += r["final"] == "wrong"
                groups[key][str(value)][1] += 1
        best = None
        for key, values in groups.items():
            slices = sorted(({"label": v, "failShare": f / fails, "volShare": n / len(rows)} for v, (f, n) in values.items()), key=lambda s: -s["failShare"])
            gap = max(s["failShare"] - s["volShare"] for s in slices)
            if len(slices) > 1 and (best is None or gap > best[0]):
                best = (gap, key, slices)
        if not best or best[0] < 0.25:
            continue
        _, key, slices = best
        top = max(slices, key=lambda s: s["failShare"] - s["volShare"])
        item_type, check = names[m["id"]]
        out[m["id"]] = {
            "sliceBy": key, "slices": slices,
            "cause": f"{top['label']} is {top['failShare']:.0%} of failures but only {top['volShare']:.0%} of volume.",
            "action": f"Send {item_type} items where {key.lower()} is {top['label']} to manual handling for {check.lower()} until the platform is fixed."
            if m["status"] == "act" else "Nothing yet. The evidence is not strong enough; sampling continues.",
        }
    return out


def queue(con, today: date, per_customer: int = 12) -> list[dict]:
    """What a person should look at: what the judge could not settle, plus a random audit of what it did."""
    since = (today - timedelta(days=2)).isoformat()
    out, taken = [], defaultdict(int)
    for r in con.execute("SELECT * FROM results WHERE label IS NULL AND day >= ? AND (verdict = 'unsure' OR audit = 1) ORDER BY verdict = 'unsure' DESC, day DESC, id", (since,)):
        if taken[r["customer_id"]] >= per_customer:
            continue
        taken[r["customer_id"]] += 1
        r = db.row(r)
        out.append({
            "id": str(r["id"]), "metricId": f"{r['customer_id']}/{r['item_type']}/{r['check_id']}", "ref": r["item_ref"], "field": r["field"],
            "claimed": r["claimed"], "why": "unsure" if r["verdict"] == "unsure" else "audit", "judge": r["verdict"],
            "confidence": r["confidence"], "reason": r["reason"], "doc": r["evidence"],
        })
    return out


def judge_agreement(con) -> dict:
    """How often people agreed with the judge on the random audit: the judge's own measured accuracy."""
    r = con.execute("SELECT SUM(label = verdict) AS agree, COUNT(*) AS n FROM results WHERE audit = 1 AND label IN ('right', 'wrong')").fetchone()
    return {"agree": r["agree"] or 0, "n": r["n"]}
