"""SQLite storage. Products and customers are rows, never code."""
import json
import os
import sqlite3
from pathlib import Path

DB_PATH = Path(os.environ.get("ASSAY_DB", Path(__file__).resolve().parent.parent / "assay.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, unit TEXT NOT NULL, blurb TEXT NOT NULL, live INTEGER NOT NULL,
  source TEXT NOT NULL,            -- 'http' for a real platform, 'demo' for the built-in fake one
  items_url TEXT NOT NULL, output_url TEXT NOT NULL, evidence_url TEXT NOT NULL,
  mapping TEXT NOT NULL,           -- JSON: where things live in the platform's output
  check_types TEXT NOT NULL        -- JSON list: id, name, instruction, evidence, perField
);
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, product_id TEXT NOT NULL REFERENCES products(id),
  use_case TEXT NOT NULL, items_per_day INTEGER NOT NULL, sample_per_day INTEGER NOT NULL, audit_rate REAL NOT NULL,
  auth_env TEXT NOT NULL,          -- name of the environment variable holding this customer's API key
  item_types TEXT NOT NULL         -- JSON list: id, name, share, fields, checks
);
CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id TEXT NOT NULL, item_type TEXT NOT NULL, check_id TEXT NOT NULL, field TEXT,
  item_ref TEXT NOT NULL, day TEXT NOT NULL, claimed TEXT NOT NULL,
  verdict TEXT NOT NULL,           -- judge: right | wrong | unsure
  confidence REAL NOT NULL, reason TEXT NOT NULL,
  audit INTEGER NOT NULL,          -- 1 = confident verdict picked at random for a person to re-check
  label TEXT,                      -- person: right | wrong | unclear
  evidence TEXT NOT NULL,          -- JSON shown to the reviewer
  attrs TEXT NOT NULL              -- JSON: item attributes used to find where failures concentrate
);
CREATE INDEX IF NOT EXISTS results_by_customer_day ON results (customer_id, day);
"""

JSON_COLUMNS = {"mapping", "check_types", "item_types", "evidence", "attrs"}


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    return con


def row(r: sqlite3.Row) -> dict:
    return {k: json.loads(r[k]) if k in JSON_COLUMNS else r[k] for k in r.keys()}


def insert(con: sqlite3.Connection, table: str, values: dict) -> None:
    values = {k: json.dumps(v) if k in JSON_COLUMNS else v for k, v in values.items()}
    con.execute(f"INSERT INTO {table} ({', '.join(values)}) VALUES ({', '.join('?' * len(values))})", list(values.values()))


def update(con: sqlite3.Connection, table: str, id: str, values: dict) -> None:
    values = {k: json.dumps(v) if k in JSON_COLUMNS else v for k, v in values.items()}
    con.execute(f"UPDATE {table} SET {', '.join(f'{k} = ?' for k in values)} WHERE id = ?", [*values.values(), id])
