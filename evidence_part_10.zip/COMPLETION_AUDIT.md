# Completion audit

- ASR: 15/15 models have raw records; frozen shared-corpus WER is reported for every executed supported locale.
- TTS: 19/19 models have raw records and verified local waveforms.
- Streaming: no pending model paths. T11 and T19 use adapter-active merged checkpoints; T16 uses the released SGLang path; T12 covers all ten report locales.
- Report: exactly two tables, 15 ASR rows, 19 TTS rows, 105 playable TTS cells, one-page A3 PDF.
- Evidence: 34/34 model directories, 6,721 record rows, 168 successful audio references, zero missing files, zero hash failures.
- RunPod: 0 active instances; 14 historical pod records verified EXITED on 2026-09-29T06:08:52Z.
- Recorded compute: $13.009395 against the authorised $15 cap.
- Owner listening scores: intentionally left blank for the owner to enter in `LISTENING_REVIEW/index.html`; this is not an execution gap.
