#!/usr/bin/env python3
"""Render the authored PRD and supporting guides to HTML/PDF; no benchmark data."""
from __future__ import annotations
from pathlib import Path
import html
import re
from markdown_it import MarkdownIt
from weasyprint import HTML

ROOT=Path(__file__).resolve().parents[1]
md=MarkdownIt('commonmark',{'html':True}).enable('table')
main=(ROOT/'PRD.md').read_text(encoding='utf-8')
# Cover supplies the document title; preserve the canonical Markdown itself.
main='\n'.join(main.splitlines()[3:])
body=md.render(main)
headings=[]
counter=0
def heading(match):
    global counter
    counter+=1
    text=match.group(1)
    ident=f'section-{counter}'
    headings.append((ident,re.sub('<[^>]+>','',text)))
    return f'<h2 id="{ident}">{text}</h2>'
body=re.sub(r'<h2>(.*?)</h2>',heading,body,flags=re.S)
body=re.sub(r'\[(S\d{2})\]',r'<a class="citation" href="#\1">[\1]</a>',body)
verification=md.render((ROOT/'CODE_VERIFICATION.md').read_text())
verification=verification.replace('<h1>Code verification guide</h1>','<h1 id="verification">Appendix A · Code verification guide</h1>',1)
source_md=(ROOT/'SOURCES.md').read_text()
sources=md.render(source_md)
sources=sources.replace('<h1>Primary-source register</h1>','<h1 id="sources">Appendix B · Primary-source register</h1>',1)
sources=re.sub(r'<h2>\[(S\d{2})\] (.*?)</h2>',r'<h3 id="\1">[\1] \2</h3>',sources)
sources=re.sub(r'<p>(https?://[^<]+)</p>',lambda m:f'<p class="url"><a href="{html.escape(m.group(1),quote=True)}">{html.escape(m.group(1))}</a></p>',sources)
toc=''.join(f'<li><a href="#{ident}">{html.escape(text)}</a></li>' for ident,text in headings)
toc+='<li><a href="#verification">Appendix A · Code verification guide</a></li><li><a href="#sources">Appendix B · Primary-source register</a></li>'
css='''
@page { size:A4; margin:19mm 18mm 18mm 18mm;
  @top-left { content:"INDIC SPEECH BENCHMARK"; font-family:Lato,sans-serif; font-size:8pt; color:#506373; }
  @top-right { content:"CODEX EXECUTION PRD · v1.0"; font-family:Lato,sans-serif; font-size:8pt; color:#506373; }
  @bottom-left { content:"Research snapshot · 24 September 2026"; font-family:Lato,sans-serif; font-size:8pt; color:#647480; }
  @bottom-right { content:counter(page); font-family:Lato,sans-serif; font-size:8pt; color:#647480; }
}
@page:first { @top-left{content:none;} @top-right{content:none;} @bottom-left{content:none;} @bottom-right{content:none;} }
html { font-family:Lato,"Noto Sans",sans-serif; font-size:10.6pt; line-height:1.43; color:#1d2b36; }
body { margin:0; }
p { margin:0 0 8pt; orphans:3; widows:3; }
h1,h2,h3,h4 { color:#123d52; line-height:1.2; break-after:avoid; }
h1 { font-size:25pt; margin:0 0 15pt; }
h2 { font-size:17pt; margin:21pt 0 10pt; border-bottom:1px solid #c7d7dc; padding-bottom:5pt; }
h3 { font-size:12.5pt; margin:15pt 0 7pt; }
ul,ol { margin:5pt 0 10pt; padding-left:20pt; }
li { margin:0 0 4pt; }
hr { border:none; border-top:1px solid #d9e3e7; margin:14pt 0; }
a { color:#086b75; text-decoration:none; overflow-wrap:anywhere; }
strong { font-weight:700; }
code { font-family:"DejaVu Sans Mono","Noto Sans Devanagari",monospace; font-size:8.6pt; overflow-wrap:anywhere; }
pre { background:#f0f4f6; border:1px solid #d8e2e7; border-left:3px solid #19737a;
      padding:9pt; margin:9pt 0 12pt; white-space:pre-wrap; overflow-wrap:anywhere; font-size:8.6pt; line-height:1.35; }
pre code { white-space:pre-wrap; }
table { border-collapse:collapse; width:100%; margin:9pt 0 13pt; font-size:9pt; line-height:1.32; }
thead { display:table-header-group; }
th:first-child, td:first-child { white-space:nowrap; min-width:28pt; }
tr { break-inside:avoid; }
th { color:white; background:#173f53; text-align:left; padding:7pt; vertical-align:top; }
td { padding:6pt 7pt; border-bottom:1px solid #d5e0e5; vertical-align:top; overflow-wrap:anywhere; }
tbody tr:nth-child(even) { background:#f1f5f7; }
.cover { break-after:page; padding-top:29mm; }
.kicker { font-size:10pt; font-weight:700; letter-spacing:2px; color:#147a7a; }
.cover h1 { font-size:42pt; line-height:1.08; margin:20pt 0 15pt; }
.cover .subtitle { font-size:20pt; line-height:1.25; color:#335767; margin-bottom:25pt; }
.cover .rule { width:65pt; height:5pt; background:#198482; margin:0 0 22pt; }
.cover .summary { font-size:12.5pt; line-height:1.5; max-width:455pt; }
.stats { margin-top:25pt; display:table; width:100%; border-top:1px solid #c7d7dc; border-bottom:1px solid #c7d7dc; }
.stat { display:table-cell; width:33%; padding:15pt 8pt 15pt 0; }
.stat b { display:block; font-size:27pt; color:#123d52; }
.stat span { font-size:10pt; color:#506373; }
.cover .footnote { margin-top:23pt; font-size:9.5pt; color:#526674; }
.toc { break-after:page; }
.toc ol { list-style:none; padding:0; }
.toc li { padding:4pt 0; margin:0; border-bottom:1px solid #ecf0f2; font-size:10pt; }
.toc a::after { content:leader('.') target-counter(attr(href), page); }
.appendix { break-before:page; }
.sources { font-size:9pt; line-height:1.35; }
.sources h3 { margin-top:12pt; font-size:10.8pt; }
.sources .url { font-size:8pt; margin-bottom:4pt; word-break:break-all; overflow-wrap:anywhere; }
.citation { font-size:0.91em; white-space:nowrap; }
'''
cover='''<section class="cover"><div class="kicker">CODEX IMPLEMENTATION &amp; EXECUTION PACKAGE</div>
<h1>Indic Speech<br>Benchmark</h1><div class="subtitle">From model discovery to a complete,<br>reproducible ASR / TTS report</div><div class="rule"></div>
<p class="summary">A detailed execution specification covering language support, Indian English, accuracy, real streaming behavior, hardware, usage rights and genuine blind-listening quality.</p>
<div class="stats"><div class="stat"><b>34</b><span>ASR / TTS inventory entries</span></div><div class="stat"><b>10</b><span>Target language locales</span></div><div class="stat"><b>52</b><span>Primary-source references</span></div></div>
<p class="footnote"><strong>Version 1.0 · 24 September 2026</strong><br>Includes independent checking code, integration probes and acceptance gates.<br>TTS quality scores require real human blind ratings. This specification does not contain model benchmark results.</p></section>'''
page='<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Indic Speech Benchmark — Codex PRD v1.0</title><style>'+css+'</style></head><body>'+cover+'<section class="toc"><h1>Contents</h1><ol>'+toc+'</ol></section><main>'+body+'</main><section class="appendix">'+verification+'</section><section class="appendix sources">'+sources+'</section></body></html>'
(ROOT/'PRD.html').write_text(page,encoding='utf-8')
HTML(string=page,base_url=str(ROOT)).write_pdf(ROOT/'PRD.pdf')
print('Rendered PRD.html and PRD.pdf')
