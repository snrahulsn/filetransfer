# Start here — instruction to Codex

You are implementing and executing the benchmark specified in `PRD.md`. Build the whole pipeline and generate the final evidence-backed report. Do not return another PRD or merely fill in model-card facts.

1. Read `PRD.md`, `MODEL_INVENTORY.md`, `configs/benchmark.json`, `SOURCES.md` and `examples/README.md`.
2. Run `python -m unittest discover -s tests -v`. These are independent checking utilities, not a finished benchmark. Preserve their safeguards.
3. Inspect this workspace and available hardware/data/permissions. Create one precise missing-input list. Do not assume access to historical emails, remote files or a GPU that is not present.
4. Execute milestones M0–M6. Begin with the 34-entry inventory, resolve exact configurations and perform the bounded current-model discovery step. Benchmark eligible approved candidates rather than silently narrowing to the easiest few.
5. Freeze datasets, prompts, model/backend versions, voice/adapter configurations, scoring rules and human-study design before full evaluation. Treat English as Indian English. Keep all attempts/failures.
6. Implement real offline/streaming adapters and verified per-configuration snippets. Do not fabricate outputs, replace unsupported code with canned answers, or infer real-time behavior from a streaming flag.
7. Generate the TTS audio, anonymize it, collect/import genuine human blind ratings and complete pre-registered QC. Missing human ratings block the corresponding final results. Never use an automated quality predictor or yourself as a substitute listener.
8. Generate HTML/PDF and structured outputs from immutable evidence, run strict completion/privacy/rights checks and ship both the report and the executed code/evidence package. Continue unrelated work when one task needs an external input.

**Authority limits:** no paid provisioning, cloud-data upload, gated-term acceptance, redistribution of restricted assets, or voice cloning without the stated authorization. Missing authorization is an explicit blocker, not licence to improvise. Preserve the distinction between a complete benchmark account and a model passing a deployment target.

**Final response:** provide the report/package paths, exact reproduction commands, machine-generated coverage/release-gate status and a truthful list of any remaining blockers. Do not announce completion with required work outstanding.
