# Schema seeds

These JSON Schema 2020-12 contracts are minimum executable data shapes, not the whole semantic release gate. Codex must add all PRD metadata, cross-field checks and immutable configuration hashing. `additionalProperties` remains enabled for those extensions. Fixture/event schemas permit synthetic software-test data, but the release gate rejects it as model evidence. An empty template is not a valid completed record.
