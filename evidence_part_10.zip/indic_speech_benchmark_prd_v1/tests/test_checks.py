from __future__ import annotations
from collections import Counter
import json
from pathlib import Path
import struct
import tempfile
import unittest
import wave

from checks.audio import inspect_wav, strip_wav_metadata
from checks.blind import make_pack, assign_raters, rating_summary
from checks.gate import validate_release
from checks.io_utils import canonical_hash, sha256_file, within, read_jsonl, write_jsonl
from checks.scoring import align, normalize, corpus_score
from checks.streaming import validate_events, asr_metrics, tts_metrics, playout, synthesis_class


def event(name, t, clock='client', **extra):
    if name == 'audio_chunk' and 'audio_ms' not in extra:
        extra['audio_ms'] = 100
    return {'run_id':'unit-test-only','clock_id':clock,'event':name,'t_ms':t,
            'data_class':'synthetic_fixture',**extra}


def wavfile(path, samples=(0,100,-100,32767), rate=16000):
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(struct.pack('<'+'h'*len(samples),*samples))


class ScoringTests(unittest.TestCase):
    def test_identical(self): self.assertEqual(align(['a'],['a']).errors,0)
    def test_substitution(self): self.assertEqual(align(['a'],['b']).substitutions,1)
    def test_deletion(self): self.assertEqual(align(['a'],[]).deletions,1)
    def test_insertion(self): self.assertEqual(align([],['a']).insertions,1)
    def test_wer_above_one(self): self.assertEqual(align(['a'],['b','c','d']).rate,3)
    def test_empty_rate_is_null(self): self.assertIsNone(align([],['x']).rate)
    def test_weighted_corpus(self):
        rows=[{'sample_id':'1','reference':'a','hypothesis':'b'},
              {'sample_id':'2','reference':'a b c d','hypothesis':'a b c d'}]
        self.assertEqual(corpus_score(rows)['error_rate'],0.2)
    def test_silence_separate(self):
        out=corpus_score([{'sample_id':'s','reference':'','hypothesis':'hello there'}])
        self.assertIsNone(out['error_rate']); self.assertEqual(out['empty_reference_false_positive_units'],2)
    def test_vowel_marks_preserved(self):
        for text in ['कि','की','தமிழ்','తెలుగు','বাংলা','മലയാളം','ગુજરાતી','ಕನ್ನಡ','ଓଡ଼ିଆ']:
            with self.subTest(text=text):
                self.assertTrue(normalize(text))
                self.assertEqual(normalize(text),normalize(normalize(text)))
        self.assertNotEqual(normalize('कि'),normalize('क'))
    def test_punctuation_not_marks(self): self.assertEqual(normalize('कि, की!',remove_punctuation=True),'कि की')
    def test_nfc_equivalence(self): self.assertEqual(normalize('e\u0301'),normalize('\u00e9'))
    def test_casefold_explicit(self):
        self.assertNotEqual(normalize('EN'),normalize('en'))
        self.assertEqual(normalize('EN',casefold=True),'en')
    def test_duplicate_sample_rejected(self):
        row={'sample_id':'x','reference':'a','hypothesis':'a'}
        with self.assertRaises(ValueError): corpus_score([row,row])
    def test_empty_dataset_rejected(self):
        with self.assertRaises(ValueError): corpus_score([])
    def test_failure_in_denominator(self):
        out=corpus_score([{'sample_id':'x','reference':'one two','hypothesis':'','status':'timeout'}])
        self.assertEqual(out['error_rate'],1); self.assertEqual(out['failure_samples'],1)
    def test_codepoint_cer(self):
        out=corpus_score([{'sample_id':'x','reference':'कि','hypothesis':'क'}],unit='codepoint')
        self.assertEqual(out['error_rate'],0.5)


class TraceTests(unittest.TestCase):
    def asr_trace(self):
        return [event('audio_start',0),event('input_chunk',500,source_end_ms=500),
                event('partial_transcript',600,text='नमस्ते'),event('input_chunk',1000,source_end_ms=1000),
                event('audio_end',1000),event('flush_called',1001),event('final_transcript',1100,text='नमस्ते')]
    def test_partial_and_flush(self):
        out=asr_metrics(self.asr_trace())
        self.assertTrue(out['partial_before_audio_end']); self.assertTrue(out['tail_flush_called'])
        self.assertFalse(out['input_supplied_before_available'])
    def test_source_clock_exposes_delayed_end(self):
        rows=[event('audio_start',0),event('input_chunk',1000,source_end_ms=1000),
              event('partial_transcript',1500,text='hello'),event('audio_end',1600),
              event('final_transcript',1700,text='hello')]
        out=asr_metrics(rows)
        self.assertTrue(out['partial_before_audio_end'])
        self.assertFalse(out['partial_before_source_audio_end'])
    def test_empty_producer_chunk_rejected(self):
        with self.assertRaises(ValueError):
            synthesis_class([event('audio_chunk',1,'producer',audio_ms=0,segment_id='s'),
                              event('segment_end',2,'producer',segment_id='s'),event('generation_end',2,'producer')])
    def test_future_audio_detected(self):
        rows=self.asr_trace(); rows[1]['t_ms']=10
        self.assertTrue(asr_metrics(rows)['input_supplied_before_available'])
    def test_out_of_order_rejected(self):
        with self.assertRaises(ValueError): validate_events([event('a',2),event('b',1)])
    def test_clock_domains_separate(self):
        validate_events([event('a',100,'server'),event('b',1,'client')])
    def test_mixed_runs_rejected(self):
        rows=[event('a',0),{**event('b',1),'run_id':'other'}]
        with self.assertRaises(ValueError): validate_events(rows)
    def test_nan_rejected(self):
        with self.assertRaises(ValueError): validate_events([event('a',float('nan'))])
    def test_playout_no_stall(self): self.assertEqual(playout([(100,400),(300,400)])['stall_ms'],0)
    def test_playout_stall(self): self.assertEqual(playout([(100,100),(700,100)])['stall_ms'],300)
    def test_bad_chunk_duration(self):
        with self.assertRaises(ValueError): playout([(100,0)])
    def test_client_chunks_are_not_native_proof(self):
        out=tts_metrics([event('request_start',0),event('audio_chunk',100,audio_ms=500),
                         event('audio_chunk',300,audio_ms=500),event('request_end',400)])
        self.assertEqual(out['first_playable_audio_ms'],100)
        self.assertFalse(out['native_synthesis_streaming_proven'])
    def test_class_a(self):
        out=synthesis_class([event('audio_chunk',10,'producer',segment_id='s'),
                             event('segment_end',20,'producer',segment_id='s'),
                             event('generation_end',20,'producer')])
        self.assertTrue(out['observed_output_class'].startswith('A'))
    def test_class_b(self):
        rows=[event('segment_end',10,'producer',segment_id='s1'),
              event('audio_chunk',11,'producer',segment_id='s1'),
              event('segment_end',20,'producer',segment_id='s2'),
              event('audio_chunk',21,'producer',segment_id='s2'),event('generation_end',21,'producer')]
        self.assertTrue(synthesis_class(rows)['observed_output_class'].startswith('B'))
    def test_class_c_even_many_network_chunks(self):
        rows=[event('segment_end',10,'producer',segment_id='s'),event('generation_end',10,'producer'),
              event('audio_chunk',11,'producer',segment_id='s'),event('audio_chunk',12,'producer',segment_id='s')]
        self.assertTrue(synthesis_class(rows)['observed_output_class'].startswith('C'))
    def test_missing_segment_proof_rejected(self):
        with self.assertRaises(ValueError):
            synthesis_class([event('audio_chunk',10,'producer'),event('generation_end',20,'producer')])

    def test_segment_cannot_finish_after_generation(self):
        with self.assertRaises(ValueError):
            synthesis_class([event('generation_end',1,'producer'),
                             event('audio_chunk',2,'producer',segment_id='s'),
                             event('segment_end',3,'producer',segment_id='s')])

    def test_duplicate_segment_completion_rejected(self):
        with self.assertRaises(ValueError):
            synthesis_class([event('segment_end',1,'producer',segment_id='s'),
                             event('audio_chunk',2,'producer',segment_id='s'),
                             event('segment_end',3,'producer',segment_id='s'),
                             event('generation_end',3,'producer')])


class FilesAndAudioTests(unittest.TestCase):
    def test_canonical_hash_order_independent(self): self.assertEqual(canonical_hash({'a':1,'b':2}),canonical_hash({'b':2,'a':1}))
    def test_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError): within(tmp,'../private')
    def test_jsonl_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'x.jsonl'; write_jsonl(p,[{'text':'हिन्दी'}]); self.assertEqual(read_jsonl(p),[{'text':'हिन्दी'}])
    def test_bad_jsonl_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'x'; p.write_text('[]\n')
            with self.assertRaises(ValueError): read_jsonl(p)
    def test_wav_measurements(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'x.wav'; wavfile(p); out=inspect_wav(p)
            self.assertEqual(out['clipped_sample_fraction'],0.25)
            self.assertEqual(out['duration_s'],4/16000)
            self.assertIsNone(out['quality_rating'])
    def test_zero_audio_no_invented_score(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'x.wav'; wavfile(p,(0,0)); out=inspect_wav(p)
            self.assertTrue(out['all_zero']); self.assertIsNone(out['rms_dbfs'])
    def test_metadata_strip_keeps_pcm(self):
        with tempfile.TemporaryDirectory() as tmp:
            p,q=Path(tmp)/'a.wav',Path(tmp)/'b.wav'; wavfile(p); strip_wav_metadata(p,q)
            self.assertEqual(inspect_wav(p)['duration_s'],inspect_wav(q)['duration_s'])
    def test_audio_source_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'a.wav'; wavfile(p)
            with self.assertRaises(ValueError): strip_wav_metadata(p,p)


class BlindTests(unittest.TestCase):
    def test_invalid_minimum_cannot_complete_empty_study(self):
        for minimum in (0, -1, True, 1.5):
            with self.subTest(minimum=minimum), self.assertRaises(ValueError):
                rating_summary([], ['c'], minimum_raters=minimum)

    def ratings(self):
        return [{'clip_id':'c','rater_id':str(i),'quality':3,'rating_source':'human_blind',
                 'data_class':'synthetic_fixture'} for i in range(5)]
    def test_five_independent_raters(self): self.assertTrue(rating_summary(self.ratings(),['c'])['complete'])
    def test_missing_ratings_block(self): self.assertFalse(rating_summary(self.ratings()[:4],['c'])['complete'])
    def test_auto_ratings_rejected(self):
        rows=self.ratings(); rows[0]['rating_source']='predicted'
        with self.assertRaises(ValueError): rating_summary(rows,['c'])
    def test_duplicate_not_independent(self):
        with self.assertRaises(ValueError): rating_summary(self.ratings()+self.ratings()[:1],['c'])
    def test_repeat_not_sample_size(self):
        rows=self.ratings()+[{**self.ratings()[0],'is_repeat':True,'quality':1}]
        out=rating_summary(rows,['c']); self.assertEqual(out['clip_weighted_mean'],3); self.assertEqual(out['qc_repeat_ratings'],1)
    def test_invalid_rating_rejected(self):
        rows=self.ratings(); rows[0]['quality']=True
        with self.assertRaises(ValueError): rating_summary(rows,['c'])
    def test_assignments_balanced_unique(self):
        out=assign_raters([str(i) for i in range(20)],[f'r{i}' for i in range(10)])
        self.assertEqual(len(out),100); self.assertEqual(len({(r['clip_id'],r['rater_id']) for r in out}),100)
        counts=Counter(r['rater_id'] for r in out)
        self.assertLessEqual(max(counts.values())-min(counts.values()),1)
    def test_make_pack_hides_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); audio=root/'model_name.wav'; wavfile(audio)
            records=[{'recording_id':'secret-model-voice','audio_path':str(audio),'audio_sha256':sha256_file(audio),
                      'config_id':'SECRET','locale':'hi-IN','condition':'clean'}]
            make_pack(records,root/'public',root/'private')
            text=(root/'public/manifest.jsonl').read_text()
            self.assertNotIn('SECRET',text); self.assertNotIn('secret-model',text)
            self.assertIn('SECRET',(root/'private/blind_key.jsonl').read_text())
    def test_nested_key_directory_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError): make_pack([{}],tmp,Path(tmp)/'private')


class GateTests(unittest.TestCase):
    def setup_case(self,root,status='measured_success'):
        p=Path(root)/'evidence.txt'; p.write_text('Unit-test-only evidence fixture, NOT a real model result.')
        plan={'requirements':[{'cell_id':'a','kind':'latency'}]}
        row={'cell_id':'a','status':status,'data_class':'measured',
             'evidence':[{'path':'evidence.txt','sha256':sha256_file(p)}]}
        return plan,row
    def test_closed_evidence(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root); self.assertTrue(validate_release(p,[r],root)['complete'])
    def test_missing_result(self):
        with tempfile.TemporaryDirectory() as root:
            p,_=self.setup_case(root); self.assertFalse(validate_release(p,[],root)['complete'])
    def test_fixture_forbidden(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root); r['data_class']='synthetic_fixture'; self.assertFalse(validate_release(p,[r],root)['complete'])
    def test_bad_hash(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root); r['evidence'][0]['sha256']='0'*64; self.assertFalse(validate_release(p,[r],root)['complete'])
    def test_exclusion_requires_approval(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root,'approved_exclusion'); r['reason']='rights'; self.assertFalse(validate_release(p,[r],root)['complete'])
    def test_failure_is_closed_not_qualification_pass(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root,'measured_failure'); o=validate_release(p,[r],root)
            self.assertTrue(o['complete']); self.assertIsNone(o['qualification_pass'])
    def test_human_gate(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root); p['requirements'][0]['kind']='human_quality'
            self.assertFalse(validate_release(p,[r],root)['complete'])
    def test_human_rollup_accounts_for_failed_generation(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root)
            p['requirements']=[{'cell_id':'a','kind':'human_quality','minimum_prompts':40,
                                'generation_cell_ids':['failed-prompt']},
                               {'cell_id':'failed-prompt','kind':'generation'}]
            r['human_quality']={'rating_source':'human_blind','complete':True,'minimum_raters':5,
                                'planned_prompts':40,'expected_clips':39,
                                'failed_generation_cell_ids':['failed-prompt']}
            failure={**r,'cell_id':'failed-prompt','status':'measured_failure'}
            self.assertTrue(validate_release(p,[r,failure],root)['complete'])
            p['requirements'][1]['kind']='latency'
            self.assertFalse(validate_release(p,[r,failure],root)['complete'])
            p['requirements'][1]['kind']='generation'
            p['requirements'][0]['generation_cell_ids']=[]
            self.assertFalse(validate_release(p,[r,failure],root)['complete'])
    def test_human_rollup_cannot_invent_failed_generation(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root); p['requirements'][0]['kind']='human_quality'
            r['human_quality']={'rating_source':'human_blind','complete':True,'minimum_raters':5,
                                'planned_prompts':40,'expected_clips':39,
                                'failed_generation_cell_ids':['made-up-failure']}
            self.assertFalse(validate_release(p,[r],root)['complete'])
    def test_duplicate_result_fails(self):
        with tempfile.TemporaryDirectory() as root:
            p,r=self.setup_case(root); self.assertFalse(validate_release(p,[r,r],root)['complete'])

if __name__=='__main__': unittest.main()
