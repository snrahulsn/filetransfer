# Synthetic software-test fixtures only

No fixture in this folder is a measured model output or a genuine listener rating. Fixtures test validators and must be rejected by the final benchmark release gate.
