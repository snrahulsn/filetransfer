#!/usr/bin/env python3
"""Verify extracted package files against the shipped SHA-256 manifest."""
from pathlib import Path
import json
import hashlib
import sys

root=Path(__file__).resolve().parent
manifest=root/'SHA256SUMS.json'
if not manifest.is_file():
    raise SystemExit('Missing SHA256SUMS.json')
records=json.loads(manifest.read_text())
errors=[]
for relative,expected in records.items():
    path=(root/relative).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        errors.append(f'missing/unsafe: {relative}'); continue
    digest=hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''): digest.update(data)
    if digest.hexdigest()!=expected: errors.append(f'hash mismatch: {relative}')
if errors:
    print('\n'.join(errors),file=sys.stderr); raise SystemExit(2)
print(f'OK: {len(records)} files match. Integrity is not evidence of model inference or human ratings.')
