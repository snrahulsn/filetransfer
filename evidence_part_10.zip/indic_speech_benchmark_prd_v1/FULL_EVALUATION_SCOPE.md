# Full ASR and TTS evaluation scope

The user explicitly requested evaluation of both streaming and non-streaming models. All 34 PRD inventory entries (15 ASR and 19 TTS) remain required for screening and accounting. Execute every eligible, accessible, approved configuration on its supported subset of the ten project locales. No model is excluded merely because it is non-streaming. The earlier streaming shortlist specifies priority only.

## Non-streaming and full-utterance evaluation

The PRD includes these ASR references beyond the streaming shortlist: SraVaani-1.0, IndicConformer-600M multilingual, OmniASR CTC 1B and 300M, Whisper large-v3 and large-v3-turbo, Shrutam-2, VibeVoice ASR, IndicWhisper language checkpoints, and MMS ASR adapters. Qwen3-ASR 1.7B and 0.6B also need their documented offline modes evaluated independently of their streaming modes.

For TTS, include full-output evaluation of eligible configurations across all 19 entries. The inventory includes IndicF5, MMS TTS language checkpoints, Chatterbox multilingual and Hindi, Sooktam-2, Kokoro, Maya1, Veena, and the previously shortlisted models. These names must not all be assigned a blanket non-streaming label: the delivered behavior depends on checkpoint, runtime and mode. XTTS v2, for example, remains in the inventory for both mode screening and rights review. An unverified implementation is `unverified`, not `non_streaming`.

`configs/evaluation_coverage.json` accounts for every original entry and records the requested modes and metrics. It is a planning artifact, not a frozen per-configuration execution plan or measured results. Expand checkpoints, adapters, voices, backends and precision into distinct configurations before running. Additional discovery candidates such as DhVaani remain separately tracked in the streaming scope review until formally added.

## Metrics in the final report

| Task | Quality | Runtime and resources | Streaming-specific diagnostics |
| --- | --- | --- | --- |
| ASR, all modes | Per-language WER/CER; service-level and successful-run quality; failure/empty-output rate; code-switch and entity diagnostics; clean/telephony conditions; sample counts and uncertainty | Warm p50/p95 inference latency, compute RTF, throughput, cold load time, peak RAM/VRAM, concurrency, actual CPU/GPU configuration | First/stable partial latency, revisions, source-feed lateness, queue backlog, lookahead, finalization, flush and session isolation |
| TTS, all modes | Genuine blind human quality mean, fraction rated at least 3/5, intelligibility/accent/content diagnostics, generation failure rate; sample/rater counts and uncertainty | First playable audio, first audible speech, full generation time, RTF, throughput, cold load time, peak RAM/VRAM, concurrency, actual CPU/GPU configuration | Producer classification, chunk gaps/continuity, stalls under a fixed buffer, cancellation/barge-in, incremental-text support |

Measure TTS first playable audio for full-utterance output too: it includes the wait for generation to finish. Do not report it as zero or substitute a transport-header timestamp. Keep first audible speech separate because initial silence can delay useful output.

ASR offline inference latency starts when the complete input becomes available to the model. Also report user-observed response timing under a common real-time audio arrival schedule, including buffering and endpointing. Keep this separate from compute RTF so offline and streaming timings are not misleadingly compared. Streaming-only fields for a verified full-utterance path are null with an explicit `not_applicable_full_utterance` reason, never zero. Fields for an unexecuted configuration are null with `not_run`, never `not_applicable`.

Quality comparisons use matching test data and conditions. Timing comparisons use matching hardware, concurrency and definitions. Do not average across different language support sets or merge offline and streaming modes into one result. A non-streaming model can still be suitable for short conversational turns if measured latency and quality meet the target.

## Required report labels

- ASR: native incremental state/cache; buffered or retranscribing wrapper; full utterance; unverified.
- TTS: A, audio produced within an unfinished segment; B, completed segments delivered sequentially; C, full requested utterance generated before output; unverified.
- Record ASR audio-input/transcript-output and TTS text-input/audio-output capability separately.
- Every row identifies model revision, locale, voice/adapter, backend, precision, mode, hardware, rights status and evidence links.
- Main quality tables include both modes and allow filtering by mode. Streaming diagnostics have their own tables. Final recommendations distinguish quality leaders, measured conversational suitability and batch suitability.
- Publisher claims appear only in a separate source-labelled reference section with original dataset/hardware context. They never populate our measured columns.

## Execution status

The initial scope review preceded GPU execution. The bounded RunPod reference runs have finished and all account pods were verified stopped with null runtime at 2026-09-24 01:45:30 UTC. Real measurements and documented unfinished work are retained. See [the live progress report](../BENCHMARK_PROGRESS.md), [measured results](../MEASURED_RESULTS.md), and [language coverage](../LANGUAGE_COVERAGE.md) for the current evidence and remaining work. The planning configuration is not an execution ledger. Fixture scores and validator tests remain software checks only; they are never model results. The historical preflight shutdown record in `evidence/runpod_preflight_20260924.json` does not establish the current pod state. Full qualification and genuine human ratings remain incomplete.
