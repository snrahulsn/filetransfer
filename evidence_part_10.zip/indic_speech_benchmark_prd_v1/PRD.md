# Indic Speech Benchmark
## End-to-end execution PRD for Codex

**Version:** 1.0 · **Research snapshot:** 24 September 2026  
**Deliverable:** a complete, reproducible ASR/TTS benchmark and evidence-backed report, built and run from scratch.  
**Primary scope:** self-hosted speech models for nine Indian languages and Indian English.  
**Human evaluation:** genuine blind listening is the source of TTS quality scores.  
**Implementation status of this handoff:** specification plus tested independent checking utilities and integration probes; not a completed model benchmark.

---

## 0. The instruction to Codex

Implement this specification, execute its approved test plan, organize the human blind-listening stage, and generate the final report and reproducibility package. Do not stop after returning an architecture, research audit, model-card summary or scaffold. A functioning implementation without completed evaluations is an intermediate deliverable, not the requested final report.

Read `CODEX_START.md`, this PRD, `MODEL_INVENTORY.md`, `configs/benchmark.json`, and `examples/README.md`. Run the existing validator tests before changing them. Then work through the milestones in section 20. Keep an execution journal containing commands, decisions, failures, fixes and artifact paths. Continue independent work when a task is blocked; identify the precise external input required to unblock it.

The two original screenshots are historical context, not a trusted data source. Do not copy their scores into fresh results. Do not assume that disputed assertions from earlier conversations or an earlier audit are true. Every deployed configuration and every report result must have its own evidence.

**Hard requirements:** do not fabricate listener ratings, inference outputs, timing logs, hardware measurements, source revisions, permission records or citations. Do not silently remove difficult models, failed requests, unsupported configurations, inconvenient listeners or poor outputs. Do not replace human listening with an automated estimate. Do not call the report complete while required work remains unexecuted.

### 0.1 What “complete” means

Completeness is defined against a frozen, finite model/configuration/language/test plan. Every planned item has a disposition and evidence; every required eligible evaluation is executed; every successful TTS recording selected for the release study has the required independent human ratings; every report claim is traceable. An honestly documented execution failure is a result, not a reason to erase a row. A missing credential, unidentified model or absent rating is a blocker, not proof that a capability is unsupported.

Completeness does not mean every model passes every product target, every model supports every language, or that the report covers all future releases. The report must state its freeze date, resource envelope and coverage. Claims of universal hardware minima, accent suitability, commercial rights or real-time operation require appropriate evidence rather than a forced yes/no.

### 0.2 Normative vocabulary

**MUST** is a release requirement. **SHOULD** is the default unless a documented reason is approved. **MAY** is an extension that cannot substitute for required work. Numerical sample counts and qualification targets below are benchmark-design requirements or proposed targets, not facts about model capabilities.

Source IDs such as **[S07]** refer to `SOURCES.md` and `evidence/sources.json`. They are primary-source starting points. Capture immutable versions, relevant excerpts/code locations and access dates during execution. Source discovery is not runtime verification.

---

## 1. Product objective, audience and decisions

The report must allow an engineering/product team to choose an ASR and TTS configuration for Indian-language interactions using measured quality, response timing, operational behavior, hardware cost and usage rights. It must support three distinct decisions: which model is accurate or intelligible in a language; which exact deployment handles incremental interaction at the required speed; and which configuration is legally and operationally deployable in the intended setting.

The primary audience is the team selecting self-hosted models. A reader must be able to drill from a summary cell to the model/configuration, test set, raw evidence, executable snippet and scoring rule. A second engineer must be able to rebuild the report from stored results without rerunning inference, and rerun a specific result using its pinned environment and inputs.

### 1.1 In scope

- All original ASR/TTS families, plus the additional candidates in section 3 and the machine-readable inventory.
- Per-language quality, Indian-English evaluation, Hindi-English and regional-English code switching, clean and telephony conditions, critical text/number handling and failure behavior.
- Native/model-level and implementation-level streaming semantics; actual delivery timing, lookahead, buffering, finalization, playback starvation and cancellation.
- Executed CPU/GPU paths, resource use, controlled concurrency, reference-hardware and deployment-optimized comparisons.
- Exact weights/code/adapter/vocoder/voice/data licensing and access conditions, with restricted-use entries clearly separated.
- A genuine human blind-listening workflow, quality-control process, rating import, statistics, sample playback and immutable provenance.
- Versioned code, reproducibility snippets, evidence, interactive HTML, print-friendly report, structured data and release validation.

### 1.2 Explicitly separate tracks

**Self-hosted primary lane:** downloadable configurations run on named hardware. **Restricted-use research lane:** models whose intended benchmark use is authorized but whose commercial deployment rights differ. **Hosted reference lane:** enabled only after API credentials, data-processing permission and a spend ceiling are authorized. Their network/service measurements cannot be described as local GPU performance.

Do not turn this project into a general LLM reasoning or voice-agent benchmark. A fixed scripted interaction test may measure ASR-to-TTS pipeline delay, but it must exclude an invented or variable LLM response. Diarization, translation, voice cloning similarity and emotion control are separate supplementary tasks, not mixed into primary transcription or naturalness scores.

---

## 2. Target languages and locale semantics

Use these ten columns, in this order:

| Column | Display name | Evaluation locale |
|---|---|---|
| HI | Hindi | hi-IN |
| EN-IN | Indian English | en-IN |
| BN | Bengali | bn-IN |
| MR | Marathi | mr-IN |
| TA | Tamil | ta-IN |
| TE | Telugu | te-IN |
| GU | Gujarati | gu-IN |
| KN | Kannada | kn-IN |
| ML | Malayalam | ml-IN |
| OR | Odia | or-IN |

These are benchmark locale identifiers, not necessarily valid model API arguments. Store a separate mapping to each model's expected language token/name. Never send `en-IN` to an API that accepts only `English` and treat a parameter error as evidence that Indian-accented speech is unsupported.

### 2.1 Language declaration and observed results are different fields

For each model-language pair, record the publisher declaration, exact source, selectable language configuration, benchmark eligibility, executed outcome and observed quality. Allowed declarations include `explicitly_listed`, `generic_english`, `not_listed`, `explicitly_excluded`, and `declaration_unavailable`. They are not scores.

A bad transcription or unnatural recording does not automatically mean the model does not support the language. An API rejecting a language name may reflect a configuration issue, not lack of acoustic capability. “Not listed” is not proof of impossibility. Conversely, one plausible output is not evidence of reliable supported operation. Preserve these distinctions in the report and the machine-readable data.

Every listed/claimed target language must be evaluated when legally executable and accessible. Every English-capable ASR candidate must enter the Indian-English evaluation. For otherwise unlisted languages, run a small, separately labelled exploratory probe when technically possible and justified; it does not enter the primary quality matrix until eligibility and the full test are approved. Account for the other cells with evidence-backed scope dispositions, not ambiguous dashes.

### 2.2 Indian English

ASR English accuracy is measured on Indian-accented English audio, irrespective of whether the model exposes a regional English token. Generic English support does not establish Indian-English accuracy, but lack of a regional marketing claim does not establish non-support. Svarah is the primary public Indian-English evaluation source [S41]. No American-English result may appear under EN-IN.

For TTS, distinguish an explicitly offered Indian-English voice from a generic English voice evaluated by Indian-English listeners. A native or highly familiar listener rates accent authenticity independently of general voice quality. Good generic-English naturalness is not automatically an Indian-English voice qualification. Preserve Indian names, rupee amounts, local terms and code-switching in the test prompts.

---

## 3. Model coverage: mandatory inventory and discovery closure

The initial scope contains **34 inventory entries: 15 ASR and 19 TTS**. An inventory entry may expand to several language checkpoints, adapters, backend modes or voices. Report counts of families, exact checkpoints and tested configurations separately. See `MODEL_INVENTORY.md`, `MODEL_INVENTORY.csv` and `configs/model_inventory.json` for locators and purposes.

### 3.1 ASR inventory

| ID | Model/family | Scope reason |
|---|---|---|
| A01 | SraVaani-0.5-live | Original streaming Indic reference [S01] |
| A02 | Voxtral Mini 4B Realtime | Original Hindi/English realtime reference [S03] |
| A03 | SraVaani-1.0 | Original offline Indic reference [S02] |
| A04 | IndicConformer-600M multilingual | Original Indic baseline [S04] |
| A05 | OmniASR-CTC-1B | Original multilingual CTC baseline [S05] |
| A06 | OmniASR-CTC-300M | Original smaller CTC baseline [S06] |
| A07 | Qwen3-ASR-1.7B | Original base Hindi and backend-specific streaming [S07, S37] |
| A08 | Whisper large-v3-turbo | Original general multilingual baseline [S08] |
| A09 | Qwen3-ASR-0.6B | Added smaller efficiency comparator [S09] |
| A10 | Whisper large-v3 | Added full-model control versus turbo [S10] |
| A11 | BharatGen Shrutam-2 | Added Indic-specific candidate; rights gate [S11] |
| A12 | Microsoft VibeVoice-ASR | Added long-form/speaker-aware architecture [S12] |
| A13 | VibeVoice-ASR-Streaming-1.5B | Added English-capable streaming control [S13] |
| A14 | IndicWhisper language checkpoints | Added Indic-specialized fine-tuned baseline [S14] |
| A15 | MMS ASR language adapters | Added broad-language adapter baseline [S15] |

A13's advertised language list includes English but not Hindi; do not transfer A12's language claims onto it [S13]. A14/A15 must be expanded to named language checkpoints/adapters with their own configurations, not treated as one unqualified model row. Check training/evaluation overlap before interpreting adapted-model comparisons.

### 3.2 TTS inventory

| ID | Model/family | Scope reason |
|---|---|---|
| T01 | svara-TTS | Original Indic/Indian-English candidate [S16] |
| T02 | Official Pocket TTS | Original CPU-oriented baseline [S17, S18] |
| T03 | Kokoro | Original small-model baseline [S19] |
| T04 | Indic Parler-TTS | Original Indic candidate, including Hindi [S20] |
| T05 | Maya1 | Original English voice candidate [S21] |
| T06 | Bodhan Indic-Speak | Original Indic candidate [S22] |
| T07 | Veena | Original Hindi/English candidate [S23] |
| T08 | IndicF5 | Original Indic reference-conditioned model [S24] |
| T09 | Sooktam-2 | Original Indic candidate with rights review [S25] |
| T10 | Voxtral-4B-TTS-2603 | Original model, now test its documented streaming path [S26] |
| T11 | Qwen3-TTS plus named Hindi adapter | Fresh auditable replacement configuration for the unidentified historical slot [S27, S29] |
| T12 | Qwen3-TTS matched base controls | Added base controls for adapter comparisons [S27, S28, S38] |
| T13 | Chatterbox multilingual | Added Hindi/English challenger [S30] |
| T14 | Chatterbox dedicated Hindi | Added official Hindi-specific derivative [S31] |
| T15 | VoxCPM2 | Added Hindi/English generator-streaming candidate [S32, S52] |
| T16 | Fish Audio S2 Pro | Added broad-language candidate; rights gate [S33] |
| T17 | XTTS v2 | Added established Hindi/English reference-conditioned baseline [S34] |
| T18 | MMS TTS language checkpoints | Added per-language synthesis baseline [S35] |
| T19 | Qwen 0.6B community Indic adapter collection | Added explicitly named regional-language adapter candidates [S36] |

T11 is a new run of a named community adapter, not a claim about which weights produced the old scores. T12 includes the matching 1.7B and 0.6B Base controls as configuration variants. T19 is a collection of separate adapters; enumerate the actual target-language subfolders, bases and voice assets. Never infer that one set of weights supports all the languages named by a collection.

### 3.3 Additional discovery requirement, bounded in time

Before freezing scope, survey the official publishers above plus AI4Bharat, ARTPARK/IISc, BharatGen, Meta, Qwen, Microsoft, Mistral, NVIDIA, Kyutai and relevant Indian speech providers. Search for newer or omitted self-hostable target-language ASR/TTS releases. Record search date, exact candidate, publisher source, target-language intersection, accessible weights/API, licence, maintenance and reason to include or exclude. Include a CPU-only baseline in the discovery review, not only large GPU models.

Use these inclusion criteria: a released, identifiable implementation; at least one target language or a justified Indian-English use case; legally accessible evaluation; and a nonredundant role such as language coverage, quality, efficiency, streaming or architecture. A newer family member may extend the scope, but must not silently replace a fixed candidate after results are seen. Similar model names, mirrors, quantizations and adapters must be deduplicated or explicitly designated variants.

Deliver `scope/discovery_ledger.csv` and `scope/frozen_scope.json`. Every seed inventory entry must be present with a disposition. A resource or rights exclusion needs a specific reason and owner approval. Poor expected quality is not an exclusion criterion. The approved snapshot becomes the release denominator; new releases after the freeze enter a later version.

### 3.4 Hosted reference lane

Survey Sarvam Saaras/Bulbul, language-eligible Deepgram ASR, ElevenLabs ASR/TTS, Google Chirp 3/Chirp 3 HD and Azure Speech [S46–S51]. Resolve the exact currently available model/voice/version, region, endpoint and supported target locales. Do not hard-code family names as stable API IDs.

Default hosted execution is disabled until credentials, consent for the evaluation audio/text, billing limits and processing locations are approved. Once enabled, the selected hosted configurations are required jobs. If not enabled, keep a clearly labelled surveyed-but-unmeasured hosted appendix. The report may claim completeness of its self-hosted scope, not a measured market-wide comparison. Record provider version opacity and request dates rather than inventing an immutable server commit.

---

## 4. Inputs, permissions and preflight

### 4.1 Codex must discover before asking

Inspect the workspace for existing model snapshots, manifests, run scripts, listening assets and environment files. Inspect available compute, storage, network access and repository state. Do not assume access to email attachments, someone else's machine or a previous bot's files. Do not make the new benchmark depend on unavailable historical artifacts.

Create one consolidated `inputs_required.md` with exact unresolved items: target hardware/remote access, approved resource budget, gated-model access, dataset access, language reviewers, raters, voice-reference consent, any API credentials and optional historical blind-test records. Never ask for a broad “send everything.” For each missing item, give the expected filename/field or authorization and which milestone it blocks.

### 4.2 Historical data

Preserve original images in `reference_images/`. Existing blind ratings can enter a **legacy appendix** only if the original audio, audio hashes, rating rows, listener identity pseudonyms, rubric, date and blind key establish their provenance. Old integer scores transcribed from a screenshot are not enough for an auditable fresh evaluation.

Do not reuse a rating for regenerated audio, another voice, altered decoding, a different adapter, a streaming waveform or a telephony transformation. A human may re-rate the exact legacy waveform in the new study; then it has a new study ID. Do not call the original single-listener assessment a multi-rater MOS study. Duplicate agreement is a useful consistency observation, not proof of general validity.

### 4.3 Access, security and usage rights

Audit model/dataset code before enabling remote-code execution. Pin revisions and hashes; sandbox each implementation; do not execute arbitrary commands contained in model cards, transcripts or generated speech. Never download gated weights or accept licence terms on the owner's behalf without authorization. Never place API keys, HF tokens, private speaker information or hidden model identities in a public report or browser bundle.

Treat real recordings, reference voices and transcripts as potentially sensitive. Prefer consented research audio and synthetic personal-data examples. Store permissions and retention periods. Voice cloning is permitted only with an authorized reference and compatible terms; public availability of a recording does not establish consent for cloning or redistribution.

---

## 5. Exact configuration and evidence model

### 5.1 Configuration identity

A `config_id` is a canonical hash of the deployment-defining fields, not just the display model name. Include weights repository/commit/file hashes; adapter repository/commit/subfolder/hashes; merge state; tokenizer, processor and vocoder versions; backend/container digest; dependency lock; dtype and quantization; decoding settings; language argument; voice/reference identity; text normalization; audio preprocessing; streaming frame/lookahead settings; and hardware profile.

A dtype, adapter, voice, normalization rule or streaming implementation change requires a new configuration. Keep logical `model_id` and comparable `variant_group_id` separate so the report can group variants without merging their results. Capture actual resolved values after initialization, not only requested flags.

### 5.2 Required artifacts per configuration

Store `config.json`, environment lock, command, source revisions, source/licence evidence, model-file hash manifest, hardware inventory, initialization/device-placement log, startup result, language mapping, sample-rate contract and a minimal reproducibility snippet. Store every request's input ID, output hash, raw output, event trace and failure status. Do not rely solely on mutable console screenshots.

For an adapter, record base model identity, compatible architecture, target modules, active adapter names, merge state and nonzero adapter weights. Prove that the requested adapter is active in inference using deterministic enabled/disabled controls or traced activations, not merely the presence of adapter files. Output differences alone are insufficient when generation randomness was uncontrolled.

### 5.3 Claim ledger

Each capability claim has `claim_id`, subject configuration, property, asserted value, evidence category (`publisher`, `source_code`, `executed_test`, `human_evaluation`), source URL or local artifact, version/date, evidence hash, relevant code location and reviewer status. Keep publisher memory/latency claims distinct from measured results.

A source contradiction is resolved for a **specific pinned implementation**, not by declaring one model family always streaming or always offline. Capture both conflicting sources and the executed path. The production report must link a cell to this ledger.

---

## 6. Dataset and input construction

### 6.1 Required ASR dataset lanes

**D1: common public read-speech benchmark.** Use the full eligible official FLEURS test split for each of the nine Indic languages, with a frozen dataset revision, configuration and sample manifest [S42]. Resolve actual configuration identifiers programmatically; do not assume every guessed locale spelling exists. Do not substitute a training/development split or selectively choose easy examples.

**D2: Indian English.** Use the full eligible Svarah evaluation data under its applicable terms, preserving official splits/identifiers and speaker metadata when available [S41]. If the published release is not organized into a test split, freeze its evaluation manifest explicitly. Record the actual accent/population composition rather than inventing missing demographic fields. Do not put FLEURS en_us or LibriSpeech results into this column.

**D3: conversational holdout.** For each locale, target at least 300 distinct utterances from at least 30 speakers, using a licensed held-out conversational split such as an appropriate IndicVoices release or newly collected, consented audio [S43]. Record spontaneous/read status. For Indian English, keep D3 distinct from D2; do not reuse the same recordings under another name. Missing material requires collection or an explicitly approved scope change, not unlabelled substitution with synthesized speech.

**D4: code switching and entities.** Include at least 100 Hindi-English code-switch clips and at least 50 for each other regional-language/English pair. Use naturally spoken or consented elicited speech with native-reviewed references. Mark turn-level versus intra-sentence switches. Maintain separate results for names, addresses, order identifiers, rupee amounts, dates, times, percentages and long digit strings. Do not derive this corpus by asking a TTS model under evaluation to generate “human” ASR ground truth.

**D5: operational stress.** Silence, background-only audio, overlapping speakers, clipped input, low volume, long pauses, rapid speech and 30-second/1-minute/5-minute sessions. Use these for failure and stability measurements, not to distort the clean public benchmark score.

### 6.2 Splits, contamination and representativeness

Use development material for selecting decoding, voices and normalization. Freeze test data before scoring. Record known training-set overlap and publication dates; publicly available benchmark performance is not evidence of unseen-domain generalization. For model selection intended for production, include a fresh private/held-out sample whose sources are independent of known public training corpora, while acknowledging that complete training-data provenance may be unavailable.

Deduplicate by waveform fingerprint and transcript/speaker metadata across datasets and conditions. No speaker or reference-voice leakage across development, voice conditioning and held-out evaluation where the task requires speaker independence. Existing published partitions take precedence; document any necessary deviation. Store sample counts, hours, speakers, duration distributions and missing metadata per language, not just a total count.

### 6.3 Telephony and noise transformations

For every eligible primary ASR sample, generate paired clean, 8 kHz G.711 mu-law and 8 kHz G.711 A-law conditions. Apply a documented band-limiting/resampling and encode/decode chain. Resample the decoded signal back to a model's required input rate only after the telephony degradation. Record encoder, sample format, resampler parameters and output hashes. Renaming a 16 kHz file “telephony” or merely lowering its sample rate is not sufficient.

Use a licensed fixed noise set at 20, 10 and 5 dB SNR in a separate stress lane. Calibrate signal/noise levels consistently; preserve the clean reference and align sample IDs. Do not call these simulated conditions representative of every real phone network. Optional real-call recordings and wideband codecs must have distinct condition IDs.

Streaming resampling/filtering must preserve state across chunks and must not consume future audio. Validate boundary continuity and cumulative sample counts. Record packet/frame duration separately from a model's inference chunk and lookahead.

### 6.4 TTS text inventory

Create 40 native-reviewed release prompts per locale for the primary voice/mode comparison, plus a separate development set. Use the same release texts for all applicable models in a locale. The 40 prompts comprise: 8 ordinary customer-service utterances, 6 numbers/currency/dates, 6 Indian names/places, 6 abbreviations/borrowed terms, 6 punctuation/questions/prosody cases, 4 short acknowledgments and 4 longer responses. Categories may overlap, but every prompt has one primary category and all critical spans are annotated.

Add a distinct code-switching set and operational long-text set; do not silently count these as part of the primary 40. Native reviewers approve spelling, intended pronunciation, script choices and semantic naturalness. Translations must be independently reviewed; equal character count is not a fairness criterion across scripts. Use culturally appropriate, non-sensitive fictional entities. No real phone numbers, customer records or unauthorized personal information.

The primary request uses the reviewed display text without model-specific manual repairs. A production text-normalization lane may expand numbers or abbreviations, but uses a frozen shared policy, records the transformed text and has separate configuration/results. Do not selectively fix only the weak model's prompts after hearing outputs.

---

## 7. ASR execution and scoring

### 7.1 Required run matrix

For every eligible model-language configuration, run the primary clean and two telephony datasets, conversational holdout, applicable code-switching set and operational stress cases. Native offline and officially supported streaming paths must be separate configurations when both are selected. Use identical sample manifests for comparisons within each lane. If a model lacks a native offline API, its full-file result can be produced through its supported streaming path, but label the mode accurately.

Primary transcription is in the source language, not translation. For models offering both forced-language and automatic detection, run the forced-language primary configuration where appropriate and a separately labelled language-identification/control run. Do not feed reference transcripts as prompts, use test-derived hotwords, or hand-correct outputs before scoring. Domain adaptation and hotword assistance are supplementary controlled lanes with the exact allowed hints disclosed.

### 7.2 Scoring rules

Compute corpus WER as `(substitutions + deletions + insertions) / reference_words`, summing counts over the dataset. Do not average per-utterance WER and call it corpus WER. WER may exceed 100%; do not clamp it for a heatmap. Also compute CER with an explicit unit definition. Primary CER uses Unicode code points after NFC; a grapheme-cluster metric may be added but must be named separately.

Store two text views: raw NFC with whitespace normalization, and a documented normalized view that may handle case/punctuation/numbers under a frozen policy. Preserve the original reference and hypothesis. Indic vowel signs and other combining marks must not be removed. Include regression tests for Devanagari, Bengali, Tamil, Telugu, Gujarati, Kannada, Malayalam and Odia. A regular-expression rule that accidentally removes marks is a scoring defect and invalidates affected scores until recomputed.

Use a production scorer such as a pinned jiwer implementation and compare it with the independent golden alignments in this package [S44]. Test insertions, substitutions, deletions, empty hypotheses, empty references, numbers, composed/decomposed Unicode and rates above 100%. Define tokenization for punctuation, code switching, acronyms and digit grouping. Romanized output versus native-script references must be reported honestly; transliteration-equivalent scoring is an additional metric, not a hidden repair.

### 7.3 Failures and silence

Every planned sample produces a status, even on timeout, OOM, empty output or crash. An unavailable hypothesis for a nonempty reference contributes deletions to the service-level transcription score; also publish success-only quality and the failure rate separately. Keep recoverable partial output if that is what the client received, with its status. Do not hide failures by dropping rows from the denominator.

For empty-reference/silence cases, publish hallucinated words per audio minute and fraction of clips producing text, rather than dividing WER by zero. A model returning nothing for speech is different from returning nothing for silence. Retain unmodified logs for both.

### 7.4 Uncertainty and comparisons

Use 2,000 bootstrap resamples with a fixed recorded seed; cluster by speaker when available, otherwise disclose the sampling unit. For paired model comparisons, resample the same units for both systems and report the difference interval. Keep each dataset/condition separate. A nine-language macro-average is valid only over the same nine languages and same conditions; publish its coverage. Do not compare partial-language averages as if they had the same denominator. Indian English may be shown separately or in an explicitly defined ten-language macro-average.

Include subgroup and entity results with counts and uncertainty. Avoid declaring tiny differences meaningful solely because one rounded number is smaller. Diagnostic examples must be selected by a preregistered rule or sampled reproducibly, not cherry-picked to flatter one system.

---

## 8. Streaming definitions and proof

### 8.1 Separate input and output capabilities

Record ASR audio-input mode, ASR transcript-output mode, TTS text-input mode and TTS audio-output mode independently. A model accepting a complete sentence can still emit audio incrementally. A WebSocket may accept incremental text but buffer it to sentence boundaries. HTTP transfer chunks do not prove synthesis is incremental.

For **TTS audio output**, use A: playable audio is generated before synthesis of that same segment completes; B: completed segments are delivered sequentially; C: the requested utterance is completed before usable output is returned. Classification applies to the exact implementation/configuration. For **ASR**, distinguish native incremental state/cache, a buffered/retranscribing wrapper, and full-utterance processing. A wrapper may be useful; it must not be relabelled native streaming.

Do not use “streaming = usable for live conversation,” “non-streaming = fixed announcements only,” or “batch = cannot be used on calls.” Application suitability is a measured latency/quality decision under stated targets.

### 8.2 Producer and client evidence

Instrument producer-side segment/generation events and client-side arrival/playback events. Each event contains run/request ID, event type, monotonic timestamp, clock-domain ID, segment/sample offsets and relevant payload. Use wall-clock UTC only for provenance. Do not subtract timestamps from different hosts without synchronization evidence and an error bound.

For TTS A/B/C, record segment start/end, generation end, decoded playable chunk production and client receipt. GPU launch completion is not necessarily computation completion; instrument the actual decoded waveform boundary and use synchronization appropriate to the backend. A client receiving many chunks after full synthesis is class C for synthesis, even if transport is chunked.

For ASR, use an independent producer that delivers audio at real-time speed against absolute deadlines and a consumer that runs inference. Record source sample offsets, send times, queue length and drops. The model must not see future audio. A synchronous loop that simply sleeps after processing can slow the source clock and conceal backlog; use it only as a smoke probe, not the production latency harness.

### 8.3 Required streaming tests

For each claimed streaming configuration, execute a short utterance, a long single segment, a multi-sentence utterance, a trailing-final-word case, a silence/long-pause case, repeated sessions and a five-minute continuous session. Confirm ASR nonempty partials before the input ends; record revisions and finalization. Confirm that the final tail is flushed and that state does not leak into the next session.

For TTS, confirm first playable and first non-silent audio separately. Record chunk duration, inter-arrival gaps, total generated duration and completion. Replay chunks through a playout simulator with a fixed 200 ms initial buffer, reporting startup delay and all underruns. Measure actual browser/device playback on a representative subset; simulated continuity alone does not prove a deployed audio stack behaves identically.

Test cancellation/barge-in: cancel at a fixed point after the first output, measure last audible delivery, confirm generation stops or that residual queued audio is discarded, and inspect subsequent session state. Run at concurrency 1 and 4; extend to 8/16 only after resource approval. On failure, preserve the trace and classify the exact implementation rather than making a universal model claim.

### 8.4 Latency and throughput metrics

Report first partial transcript latency; finalization after last input sample; configured lookahead; source-feed lateness; queue backlog; first playable TTS audio; first audible TTS output; completion time; audio duration; inter-chunk gap distribution; stall duration/count; cancellations; error rate; and throughput at each concurrency.

Define RTF consistently as elapsed processing time divided by audio duration, lower being faster. Distinguish model-compute RTF, client end-to-end RTF and inverse throughput. Real-time-paced ASR wall duration is not its compute RTF. Separate model load/cold start, warm request processing, queue delay and network effects. Show p50 and p95 with sample count and intervals; do not infer stable p99 from a tiny sample.

---

## 9. Model-specific implementation checks

These checks are mandatory because a superficially successful demo can still misrepresent the configuration.

### 9.1 Qwen ASR versus Qwen TTS

Keep A07/A09 ASR separate from T11/T12/T19 TTS. Qwen3-ASR's base Hindi support and official vLLM streaming path are documented [S07, S37]. Run Hindi offline and real-time-paced streaming; verify a forced language parameter against the pinned implementation, with automatic language detection as a separate option. Save partials and the final flush output. Do not assume an ASR Hindi adapter exists merely because the TTS row uses one.

For Qwen TTS, the base language list and adapter behavior are different [S27–S29]. Check current versioned backend documentation and code: vLLM-Omni documentation describes incremental PCM and sentence-buffered text input [S38]. Do not carry forward a blanket “offline-only” conclusion from older documentation. Base, CustomVoice and VoiceDesign have different task contracts and reference/voice requirements; use the matching checkpoint.

For the Hindi/Indic adapters, inspect actual adapter target modules, loading compatibility and reference assets. A model-card quickstart is a hypothesis to validate, not proof that every wrapper method exists. Do not silently bypass a rejected `Hindi` parameter with `auto`; record and test that choice as its own configuration. Prove active adapter use, compare a matched base control, and attempt a supported streaming configuration only after proving the adapter is loaded. A merged adapter gets new output hashes and a new configuration. No inheritance of base streaming or licence claims without checking the exact derivative.

### 9.2 Pocket TTS

Benchmark the official checkpoint as named, including Indian-English listening of the selected English voice. Its official release and code are separately identified [S17, S18]. Do not invent a community checkpoint to explain the old Hindi/Tamil/Telugu samples. If original identities can be recovered, audit and evaluate them separately; otherwise the historical scores remain outside the fresh comparison.

A newly discovered Indic derivative must have a verified owner, exact weights, language evidence and licence. A small exploratory generation from official weights is not automatically a supported Indic model and must not be disguised as an official capability. Verify CPU operation and actual audio delivery in the selected release.

### 9.3 Indic Parler, svara, Kokoro and original non-streaming rows

For Indic Parler, include Hindi, use the correct description and transcript tokenizers, check prompt lengths and masks, select voices on development material, and instrument the actual streamer [S20, S39]. Do not attribute bad scores to an implementation bug without reproducing evidence; keep original failing outputs and corrected runs separately.

For svara and Maya1, follow the pinned token/vocoder decoding path, confirm chunk boundaries and actual returned PCM, and inspect startup and starvation. For Kokoro, differentiate paragraph splitting and completed-segment generation from intra-segment audio [S16, S19, S21].

For Bodhan, Veena, IndicF5 and Sooktam-2, inspect the released implementation and execute the path selected for the report [S22–S25]. Classify what was tested. Failure to find a streaming example is not proof that no future or alternate implementation is possible. Reference-conditioned models must use consented reference audio and disjoint prompt content.

### 9.4 Voxtral, new families and per-language baselines

Use the exact Voxtral realtime ASR and TTS IDs; never substitute an older similarly named transcription model [S03, S26]. For TTS, verify sample rate, task/voice configuration, PCM streaming and the producer/client distinction. Memory claims must be tied to dtype and stack, not treated as universal hardware requirements.

For VibeVoice, remove timestamps/speaker labels from the transcription-scoring view only through a documented parser while retaining raw outputs. Report diarization separately. For MMS/IndicWhisper and community Indic TTS collections, verify the selected language-specific weights and prevent adapter state leaking between requests. For VoxCPM2, read the output sample rate from the model rather than copying a stale quickstart constant [S32, S52]. For Chatterbox and XTTS, record watermarks/reference conditioning and licensing implications rather than silently removing them [S30, S31, S34].

---

## 10. Hardware, memory, reproducibility and operating cost

### 10.1 Hardware profiles

Create named profiles from actual available infrastructure: CPU model, physical/logical cores, instruction features, thread counts, RAM, OS, power mode; GPU model, physical VRAM, device count, driver, CUDA/runtime, power limit and interconnect; storage and network. Record shared-machine interference and concurrent processes. A desired hardware profile is not a measured one.

Use a common reference-hardware lane for directly comparable resource/timing measurements. Add a best-supported-deployment lane for optimized runtimes, quantization or specialized hardware. Never merge their timing figures into one ranked column. Accuracy/voice quality must be rechecked for changed precision or decoding; quantization is not assumed quality-neutral.

### 10.2 CPU and GPU checks

For every eligible documented CPU path, execute initialization and a real inference smoke test with GPU visibility disabled, recording actual tensor/device placement and output. A source-code CPU fallback alone is not a measured CPU result. For CPU-oriented deployment claims, run the full runtime test, not only a ten-second smoke sample.

Do not label a model GPU-only because it was benchmarked on a GPU. Conversely, one successful CPU execution is not evidence of real-time speed. Give separate fields for documented compatibility, tested device, measured performance and publisher recommendation. Unsupported kernels, unavailable conversion paths and OOMs have precise failure statuses.

### 10.3 Measurements

After three warm-up requests, run at least 100 measured warm requests spanning short, medium and long inputs at concurrency 1, and the same controlled workload at concurrency 4. Use five independent cold starts, explicitly labelled as a small cold-start sample. Randomize request ordering reproducibly. Record all retries rather than presenting retry-selected timings.

Measure process RSS/peak RSS for CPU memory; GPU framework allocated/reserved memory and process/device utilization as available. State sampling interval and scope. Peak allocated tensors are not the same as peak process VRAM, and total device memory is not all attributable to the model. Reset peak counters correctly. Persist OOM evidence.

Published OmniASR memory figures must retain their original batch/duration/precision/hardware context [S40]. Apply the same discipline to “16 GB” statements for Maya1 and Voxtral: distinguish publisher minimum/recommendation, example configuration and actual successful tested hardware. Never infer a universal minimum from one test machine.

### 10.4 Resource and cost policy

Use the pilot to estimate GPU/CPU hours, storage, downloads and rater workload for the frozen plan. For hosted or rented compute, record currency, price source/date, billable unit, taxes/exclusions and spend ceiling. No automatic provisioning or open-ended API spending. Report measured resource consumption separately from price-derived estimates. Include retries and failed requests in service cost; show any excluded setup cost explicitly.

Stop safely on the approved spend limit, disk reserve, thermal/resource limits or provider rate limits. A budget stop is an execution blocker to be resolved or approved as a scope change, not an unsupported-language result. Resume from immutable completed jobs rather than rerunning everything.

---

## 11. TTS synthesis and genuine blind evaluation

### 11.1 What produces a quality score

The primary quality score comes from qualified humans listening blind to actual saved recordings. Automated intelligibility estimates, ASR round-trip WER, similarity models and predicted MOS may be supplementary diagnostics only. They must never populate the human score column, stand in for absent raters, or be portrayed as the user's original blind-test method.

Preserve the business-readiness anchor from the original evaluation: **3 is the minimum acceptable quality for presentation to a customer**. Use the clearly defined five-point scale below. Also collect distinct judgments for intelligibility/fidelity, naturalness and Indian-English accent authenticity as applicable. The primary field is labelled **blind quality score**, not automatically “MOS.” A claim of compliance with a standardized listening method requires its actual protocol to be implemented and audited; P.808 is guidance, not a label to apply by default [S45].

| Score | Anchor for primary blind quality |
|---|---|
| 1 | Unusable: major speech/content failures or severe unnaturalness |
| 2 | Understandable in parts, but below customer-facing acceptability |
| 3 | Acceptable for a customer, with noticeable imperfections |
| 4 | Good: clear, natural enough and only minor issues |
| 5 | Excellent: highly natural and accurate for the intended text |

Provide native-language explanations and calibrated practice clips. Test that raters understand the threshold. Do not instruct them to reward a model's open-source status, size or speed; those identities are hidden.

### 11.2 Voice and configuration controls

Select a canonical voice per model-language on disjoint development prompts, recording the selection rule before the blind release study. Use a normal conversational style and documented defaults unless the intended product requires a different style. Do not choose a different “best” voice for every test prompt. Include a second voice on a predefined sensitivity subset for shortlisted systems rather than treating one voice as representative of all voices.

Keep stock/design-voice and reference-conditioned/cloning tracks distinguishable. For models requiring reference audio, use authorized neutral references with matched reference conditions where feasible, and disclose residual differences. Never reuse the target sentence as reference speech or provide a transcript that reveals the desired evaluation output. Voice similarity is not the primary naturalness score.

If production streaming audio differs from offline audio, generate and blind-rate the actual streaming waveform. Do not borrow the offline score. Exact identical PCM hashes can establish identical audio for score reuse, but a different header hash alone is not enough; compare canonical decoded PCM and configuration provenance.

### 11.3 Synthesis outputs and operational failures

Generate one frozen primary output per prompt/configuration/voice using a declared seed policy. Save additional repeated generations for stability tests separately. Persist failed attempts and retries. No manual selection of the nicest sample from multiple generations. If a backend performs hidden retries or text repairs, disable them for a baseline where supported or record their behavior and cost as part of the tested system.

Validate sample rate, duration, finite PCM, channel count, clipping, leading/trailing silence and pathological repetition. Preserve the raw output; create listening copies through a common documented rendering chain. Loudness normalization for a listening condition is permitted only when identical and declared across models; do not remove pronunciation defects, splice speech or denoise only poor models.

A failed/empty generation receives an operational failure status, not a fabricated human rating of 1. Show generation success rate alongside quality of available audio so models cannot gain an advantage by failing hard prompts. The study plan records unsuccessful prompts and their impact on coverage. If a corrected implementation changes the waveform, regenerate and rerate under a new configuration.

### 11.4 Listening conditions and workload

For each eligible primary model-language-mode-voice configuration, obtain ratings on 40 release prompts in two listening conditions: a common clean rendering and simulated 8 kHz G.711 mu-law. Keep native/raw audio available for technical inspection; the common clean rendering avoids exposing models simply through inconsistent file formats. A-law is an automated runtime/audio condition, with a preregistered blind subset where codec differences or artifacts warrant it.

Use **five independent raters per successful clip** and a **pool of at least ten qualified raters per locale**. Five ratings from one person are not five independent raters. Separate clean and telephony sessions or counterbalance them so repeated exposure does not reveal the comparison. For Indian English, recruit listeners familiar with multiple Indian accents and record qualification without requiring an invented “single Indian accent.”

Estimate the required rating count before launch: successful clips × listening conditions × independent raters, plus controls and repeats. Estimate person-hours from clip duration, replay allowance and response time using the pilot. Obtain owner approval for human evaluation cost/availability; do not replace the required study with three convenient listeners or an automated metric when the estimate is large.

### 11.5 Blinding and listener application

Build an authenticated listening application or an equivalent auditable import workflow. Public listener manifests contain opaque random clip IDs and only the information needed for the task. Strip model/vendor metadata from filenames, WAV tags, URLs, captions, HTTP headers and client bundles. Keep the mapping to models/configurations in a separate access-controlled directory/database unavailable to listeners. Hiding the model name in the visible UI while sending it in JSON is not blinding.

Randomize order with a reproducible private seed and balanced assignment by model, prompt and condition. Include approximately 10% hidden repeats per rater for reliability, plus authorized natural-speech controls and deliberately degraded controls. Repeats are QC observations, not additional independent quality samples. Avoid immediate duplicates and run sessions short enough to limit fatigue. Record playback completion, replays, timestamps and interruptions without collecting unnecessary personal data.

Use two steps: audio-first quality/naturalness, then display the intended text for fidelity and critical-entity checking. Keep the same workflow for all models. For Indian English, add an accent-authenticity rating and optional structured pronunciation notes. Native-language TTS prompts must be reviewed by native readers before raters see them.

### 11.6 Rater quality control and ethics

Pre-register training, hearing/headphone screening where appropriate, language qualification, attention checks, minimum playback, implausibly short response detection and repeat-consistency rules before unblinding. A single repeat disagreement is not automatic evidence of an unreliable rater. Audit exclusions without knowing which models benefit; preserve raw data and reasons. Never exclude a rater because they give low scores or disagree with a vendor claim.

Use pseudonymous rater IDs and explicit consent/payment terms. Keep personal identity and payment records outside the report package. Allow raters to stop, report discomfort and flag offensive outputs. Replace invalid ratings through the original randomization policy, not by soliciting a more favorable opinion.

### 11.7 Aggregation and uncertainty

Store raw rating events, QC decisions and the immutable study plan. Compute clip/prompt-weighted means, medians, score histograms and the fraction of ratings at or above 3. Report number of prompts, successful/failed generations, distinct raters, ratings per clip, listening condition and uncertainty. Do not combine clean/telephony, languages, different voices or offline/streaming outputs without an explicitly defined aggregation.

Use a preregistered crossed prompt/rater bootstrap or a suitable hierarchical model for 95% intervals; do not treat every repeated rating as an independent clip. Retain language-specific results and paired comparisons on shared prompts. Report listener agreement/repeat consistency separately. Do not rank two models confidently from rounded integer means or overlapping small-sample estimates. The included arithmetic utility deliberately leaves the production confidence interval unfilled; Codex must implement and validate the chosen inferential method.

---

## 12. Licence and provenance review

Create a rights matrix for each exact configuration: weights, code, tokenizer/processor, vocoder, adapter, voice embeddings/references, evaluation datasets and redistribution of generated samples. Link the actual licence files and notices at pinned revisions, not only HF metadata tags. State declared licence identifiers separately from the owner's approval for the intended benchmark/deployment use.

Do not infer weight rights from code rights, adapter rights from the base model, or derivative rights from an official checkpoint. A non-commercial licence can affect evaluation inside a commercial organization as well as deployment; obtain a rights decision before execution. A freely accessible model is not automatically unrestricted. Escalate ambiguous or custom terms for qualified review rather than having Codex invent legal certainty.

The report must distinguish permission to evaluate internally, deploy commercially, redistribute weights, redistribute code, publish reference audio and publish generated audio. Record attribution and share-alike/notice requirements. Where use is not permitted or not approved, retain the catalog entry with a visible, evidence-backed exclusion rather than running the model anyway. Never publish dataset audio or voice references merely to make the ZIP self-contained when their terms prohibit it; publish manifests and lawful fetch instructions instead.

---

## 13. Implementation architecture and data contracts

### 13.1 Repository structure Codex must deliver

```text
speech_benchmark/
  README.md                  # setup, scope and exact run commands
  pyproject.toml              # orchestration package
  scope/                     # discovery, frozen plan, approvals
  configs/                   # exact model, backend, voice, hardware configs
  environments/              # per-family containers/locks, not one conflicted env
  adapters/asr/              # real implementations, no fallback fake outputs
  adapters/tts/
  data/                      # manifests, licensed fetch/transform scripts
  prompts/                   # native-reviewed texts and critical spans
  runners/                   # offline, paced streaming, concurrency, CPU, GPU
  scoring/                   # WER/CER, entities, bootstrap, human stats
  listening/                 # listener app, allocation and import/QC tools
  schemas/                   # versioned JSON schemas
  tests/                     # golden, integration, regression, report checks
  runs/                      # immutable raw outputs, events, metrics, failures
  private/                   # blind key/consent links; not served or published
  evidence/                  # source snapshots, licences, hashes, claim ledger
  reproduce/<config_id>/     # executed minimal snippets and exact environment
  report/                    # build code, HTML/PDF, structured exports
  release/                   # internal and publishable packages, manifests
```

### 13.2 Isolation and determinism

Use an orchestration environment independent of model runtimes. Pin per-family dependencies and container images; incompatible torch/transformers/vLLM releases must not be forced into one virtual environment. Record build/platform digests. Validate tokenizer/vocoder dependencies and external text normalizers. Cache downloads and expose only authorized data to each container.

Store seeds for sampling, decoding and randomization, but do not claim bitwise determinism on all accelerators. For nondeterministic backends, record repeatability bounds and rerun a fixed subset. Immutable raw artifacts must never be overwritten on retry; use attempt IDs and a declared primary-attempt policy. Canonical configuration hashing must exclude ephemeral fields such as run timestamps but include all behavior-changing settings.

### 13.3 Minimum data contracts

The handoff includes `schemas/` seeds. Codex must enforce schemas at write and read boundaries and extend them with the following fields:

**Input manifest:** sample ID, dataset/revision/split, speaker pseudonym, locale, condition, source/derived hashes, duration/sample rate/channels, reference text, reference review status, permission/consent reference and duplicate/overlap group.

**Configuration:** model/adapter/voice IDs and revisions, component hashes, backend and environment digest, quantization/dtype, decoding/normalization, API language mapping, streaming/lookahead settings, hardware profile and rights decision.

**Inference result:** request/run/attempt/config/sample IDs; status; raw output path/hash; parsed text or audio metadata; start/end timestamps; event trace; failure taxonomy; retry history; GPU/CPU samples and source-data class.

**Human rating:** study/clip/prompt/condition/locale IDs; pseudonymous rater; rubric version; actual human rating source; quality and auxiliary scales; playback/replay/QC metadata; repeat/control flags; timestamps and exclusion decisions stored separately.

**Aggregate result:** metric definition/version; exact numerator/denominator; count of attempts/failures/speakers/raters; manifest/config hashes; estimate/interval; sampling unit; eligible coverage; claim/evidence references and report location.

### 13.4 Failure taxonomy

Use distinct codes for access denied, licence blocked, missing artifact, invalid language argument, unsupported operator/backend, dependency failure, startup OOM, runtime OOM, timeout, invalid/empty output, wrong-language output, truncation, stream stalls, missing final flush, listener-data shortfall and report-validation failure. `Not supported` is not a general error bucket. Debug documented correctable integration errors before concluding a model failed; retain both broken and corrected attempts.

---

## 14. Commands and execution workflow

Codex must implement these command contracts, or document an exactly equivalent CLI in the final README. They are target interfaces to build, not commands already implemented by the starter package.

```bash
speechbench doctor --output runs/preflight.json
speechbench discover --inventory configs/model_inventory.json
speechbench freeze --scope scope/approved.json
speechbench rights-check --scope scope/frozen_scope.json
speechbench data prepare --plan scope/frozen_scope.json
speechbench validate-inputs --plan scope/frozen_scope.json
speechbench smoke --all-eligible --save-failures
speechbench pilot --plan scope/frozen_scope.json
speechbench estimate --include-human-listening
speechbench run asr --resume --plan scope/frozen_scope.json
speechbench run tts --resume --plan scope/frozen_scope.json
speechbench run runtime --resume --plan scope/frozen_scope.json
speechbench blind build --study configs/blind-study.json
speechbench blind serve --public-root listening/public
speechbench blind import --ratings private/ratings-export.jsonl
speechbench blind qc --preregistered-policy configs/blind-qc.json
speechbench score --all --from-immutable-runs
speechbench validate-release --strict
speechbench report build --html --pdf --csv --json
speechbench reproduce --config-id CONFIG --sample-id SAMPLE
speechbench package --internal --public-redacted
```

Commands must return nonzero on failure and structured diagnostics, not merely print a warning and continue as if successful. `--resume` verifies matching configuration/input hashes. `report build` must work offline from valid stored results. `validate-release` must reject fixture data, stale aggregates, missing required cells and missing human ratings.

The executable starter commands supplied **now** are `python -m checks.cli ...` and the integration probes listed in `examples/README.md`. Do not confuse their presence with an implemented `speechbench` orchestration system.

---

## 15. Performance qualification and scripted interaction

The configuration file includes proposed benchmark thresholds: warm p95 TTS first playable audio at most 300 ms, steady processing RTF at most 0.8, no playout stall on at least 99% of requests under the stated buffer, and ASR p95 finalization within 500 ms after the last audio sample. These are explicit starting targets for discussion, not vendor facts or a customer SLA. Obtain owner approval or retain the label “proposed benchmark target.”

Report quality and each timing measure separately even when a target is missed. A model with excellent quality but high startup delay must not be called unusable for all applications. A streaming model below the quality threshold must not be called customer-ready. Do not collapse quality, rights, speed and memory into an unexplained total score.

For shortlisted eligible ASR/TTS pairs, run a scripted turn test using prerecorded user speech and fixed response texts in each target language. Measure endpointing separately from ASR finalization and TTS first audio; include telephony encode/decode and client buffering. Use the same endpointing policy for comparisons and report that policy. Add barge-in/cancel cases and concurrent sessions. No variable LLM generation is included in this speech-component benchmark; a future complete-agent test is a separate project.

---

## 16. Final report specification

### 16.1 Required report sections

1. Executive scope and measured decision summary: freeze date, datasets, hardware, blind-study design, coverage and restricted/hosted lanes.
2. ASR capability/configuration table, independent of accuracy.
3. ASR per-language WER/CER with separate datasets and clean/telephony conditions, counts and uncertainty.
4. ASR streaming/latency/endpointing and operational-failure tables.
5. TTS capability/configuration table, independent of listener quality.
6. TTS blind-quality matrices with counts, intervals, acceptability fractions and playable exact samples.
7. TTS accent/intelligibility/entity diagnostics, streaming delivery and playback continuity.
8. CPU/GPU compatibility versus measured runtime/memory, controlled concurrency and cost assumptions.
9. Rights/licence and provenance matrix, with deployment and publication restrictions clearly separated.
10. Coverage ledger, failed/excluded/blocked items, methodology, reproducibility guide and evidence register.

Provide interactive HTML with filters for locale, condition, mode, hardware and deployment lane. Provide print-friendly PDF plus CSV/JSON exports with metric definitions. Avoid a giant unreadable table with every configuration detail squeezed into one cell. Each summary row links to its expanded configuration page.

### 16.2 Cell semantics and visuals

Use named states: measured value, measured failure, declared-not-listed/out-of-scope, rights/access exclusion, and blocked pending work. Never use an unqualified dash or `n/s` for both unsupported and untested. A blocked required cell prevents the release status from being complete. The public catalogue may include an excluded model, but its score must not be fabricated.

Show low-is-better versus high-is-better clearly; retain raw numbers above 100% WER. Do not imply precision beyond the data. Include CI/count on hover or detail views and in machine exports. Use accessible colours, readable contrast and symbols/text so meaning does not depend on colour alone. Audio sample links must point to the exact evaluated waveform or an explicitly identified lawful listening copy.

### 16.3 Conclusions and comparisons

Make conditional, language-specific conclusions grounded in measured evidence: quality on a particular dataset, latency on a particular profile, rights for a specific use. Use Pareto-style comparisons or clearly approved eligibility filters rather than an invented weighted overall rank. Different model support sets cannot be averaged into misleading “overall” winners. Separate declared capabilities from demonstrated readiness.

Describe observed failure modes with representative examples and trace IDs. Do not generalize an implementation bug or one bad clip into a universal architectural claim. Reuse no stale historical score under a new model/version label.

### 16.4 Coverage statement

Publish counts for planned inventory entries, expanded configurations, model-language pairs, executed samples, completed human ratings, successful runs, measured failures, approved exclusions and unresolved blockers. A complete release has zero required blockers and no silently missing planned cells. Include a machine-generated scope hash and release-gate result; do not manually edit the completion badge.

---

## 17. Required tests and independent review

### 17.1 Unit and property tests

Test configuration hashing, schema validation, transcript normalization across all scripts, WER/CER golden cases, sample-rate/channel handling, deterministic condition generation, file hashing, path traversal protection, private/public artifact separation, balanced rater assignment, duplicate/QC handling, human-only rating imports, aggregate denominators and completion-gate behavior.

Add property tests: identical transcripts yield zero error; removing speech cannot improve service-level failure accounting through row deletion; streaming chunk reassembly matches intended sample order; per-clock monotonicity is checked; altered evidence hashes break release; a changed configuration invalidates cached results; hidden repeats do not increase independent sample size; fixture data cannot enter a release.

### 17.2 Integration and adversarial regressions

Implement tests that deliberately reproduce the earlier report risks: mark-stripping halves apparent Indic error; American-English data relabelled en-IN; generic English labelled unsupported for lack of an accent token; Qwen ASR/TTS identity confusion; a loaded-but-inactive LoRA; wrong TTS task variant; incorrect sample-rate constants; all-at-once generated WAV divided into HTTP chunks; a synchronous feeder hiding backlog; a final ASR word lost at flush; CPU “support” tested on a GPU; licence metadata inherited from the wrong component; a single listener counted as five; and model IDs exposed in the blind browser payload.

A regression must fail on the deliberately broken implementation and pass on the corrected one. Keep example traces and expected outputs. Simulated data is permitted for these software tests only and must be labelled `synthetic_fixture`.

### 17.3 Independent verification

Recompute a stratified sample of WER/CER from raw references/hypotheses with the independent checker. Recompute TTS summary arithmetic from raw imported human ratings. Inspect at least one producer/client streaming trace per configuration and every ambiguous case. Replay a sample of generated audio with native reviewers to confirm language/voice/condition mapping. Check all licence and exclusion links. Rebuild HTML/PDF from the same immutable aggregates and confirm their values agree.

Render every PDF page and inspect for clipped tables, tiny text, missing glyphs or broken links. Run automated link and schema checks. Test the listener interface for identity leakage through DOM, network requests and static assets. Test the public package for secrets, personal identifiers, hidden blind keys and unauthorized audio files.

---

## 18. Code snippets and final reproducibility package

This section is a mandatory part of the user's deliverable, not an optional developer appendix.

### 18.1 Executed snippet for every tested configuration

For each configuration, deliver `reproduce/<config_id>/README.md`, exact environment lock/container, `config.json`, minimal runnable inference script, example command, input/sample identifiers, expected output schema, actual recorded output/evidence IDs and an assertion script. ASR examples include offline transcription and streaming/finalization when applicable. TTS examples include audio generation and the exact observed output mode; adapters include a proof-of-activation check.

Each snippet must identify what it proves and what it does not. A model-card quotation is not a code snippet. A stub that returns a canned transcript is not an integration. A client-only HTTP trace cannot prove internal synthesis streaming. A script that parses without error is not a tested model execution. Record execution time, environment/config hashes, return code and verification result.

Include explicit commands to reproduce CPU placement, peak-memory measurement, first output timing, chunk reassembly, ASR scoring, blind-pack construction, rating import/QC and final aggregation. Use real selected test sample IDs rather than private customer recordings or unverifiable demo URLs.

### 18.2 Supplied starter checking package

`checks/` contains independent reference arithmetic and conservative validators for transcript scoring, PCM WAV metadata, timing traces, synthesis classification, playout, blind-pack identity separation, independent rater allocation, human rating arithmetic and evidence/coverage closure. The `tests/` directory exercises them using synthetic software-test fixtures. `examples/` contains metadata resolution, local ASR/generator probes, a generic PCM client, CPU isolation wrapper and adapter interfaces.

Codex must retain or strengthen these checks, not weaken them to make incomplete data pass. The starter functions do not implement the entire benchmark, rater interface, production bootstrap or model integrations. Their limitations are explicit in the code and examples README. Extend them where required and run the full test suite after every change.

### 18.3 Internal and public packages

The internal package contains all lawful raw outputs, input manifests/hashes, rating/QC records, configurations, code, logs, source snapshots, licences and full provenance. Keep blind keys and sensitive consent links in a restricted area; do not embed personal data unnecessarily. The public package is independently checked and redacted, with only permitted audio/data, pseudonymous aggregates, reproducible code, source references and lawful fetch instructions.

Produce checksums for every shipped file, a software/component manifest, a release manifest and a machine-readable validation result. Do not bundle model weights, datasets, third-party font files or reference recordings unless their redistribution is authorized. Include exact fetch/revision instructions instead. Package creation itself must be reproducible and must not modify raw results.

---

## 19. Acceptance criteria and release gate

The release validator consumes the frozen expected-cell plan and actual results. It must reject duplicate cells, unknown configurations, absent hashes, stale aggregates, missing required evidence, synthetic model results and incomplete listening data.

| Gate | Required evidence to pass |
|---|---|
| G01 Scope | Every seed and discovered candidate accounted for; frozen approved inclusion/exclusion ledger |
| G02 Identity | All executed weights, adapters, voices, backend and input hashes resolved |
| G03 Rights | Intended use and shipped artifacts approved; unresolved rights do not slip through |
| G04 Data | Correct locales/splits, native review, no hidden substitutions or duplicate leakage |
| G05 ASR | Every required eligible run has output/failure evidence and validated scoring |
| G06 Streaming | Exact configuration classified with appropriate code/producer/client proof |
| G07 Hardware | Compatibility, actual device, memory and performance claims separated and checked |
| G08 Blind TTS | Planned successful audio rated by required independent qualified humans; QC complete |
| G09 Statistics | Denominators, failed-run accounting and uncertainty independently checked |
| G10 Reproduction | Per-configuration executed snippets and offline report rebuild pass |
| G11 Presentation | HTML/PDF/exports agree; links/audio work; no hidden unsupported claims |
| G12 Packaging | Integrity, privacy, licence notices and public/private separation verified |

Terminal dispositions are `measured_success`, `measured_failure`, `not_applicable` with evidence, and `approved_exclusion` with an owner decision. `Blocked`, `unknown`, `not_run` and `pending_ratings` are not completed required jobs. Applicability or exclusion cannot be chosen merely because an execution failed or a score was poor.

A `measured_failure` closes an attempted evaluation but is not a product pass. The report must expose the failure and preserve its denominator. A configuration with no generated audio cannot have a human quality mean; the generation failures are displayed instead. Distinguish completeness of execution/accounting from success on quality/latency qualification.

No owner-authorized exclusion permits a claim that the excluded model was measured. No missing field can be “fixed” by inserting a confident claim with no evidence. If required external inputs remain absent, generate an explicitly incomplete interim build and an exact blocker list; continue other work. The final completion badge is issued only after the accepted scope is fully closed.

---

## 20. Milestones and Codex work plan

### M0 — Inventory, access and frozen plan

Read source materials; run preflight; complete discovery/rights review; resolve configurations and available hardware; define dataset, voice and rater scope; create expected cells and a consolidated input request. Deliver the frozen plan, source/rights ledger, required inputs and initial cost-risk estimate. No inference is presented as completed at this stage.

### M1 — Harness and golden checks

Implement schemas, isolated environments, adapters, causal input preparation, timestamp/event logging, scoring and the orchestration CLI. Pass unit/regression tests. Execute one successful or fully diagnosed smoke case per eligible model-language configuration. Resolve integration bugs before large jobs. Deliver executable code and smoke evidence, not just scaffolding.

### M2 — Pilot and study freeze

Run the runtime/data/listening pilot on development material. Select voices and decoding by fixed rules; estimate the complete workload and obtain resource/rater approval. Freeze all test manifests, text prompts, human rubrics, QC rules and analysis plan. No test-set feedback is used for ad hoc tuning after this milestone.

### M3 — Full machine evaluation

Run the complete ASR matrix, TTS generation, streaming, hardware, concurrency and operational tests. Retain every attempt and failure. Resume safely and run validation continuously. Deliver raw outputs and measurements, with quality scores still absent where human ratings are pending.

### M4 — Blind human evaluation

Launch the blinded interface or controlled collection workflow. Collect the required independent ratings, complete pre-registered QC, replace invalid assignments through the fixed policy and lock the dataset. Only then unblind for analysis. Codex cannot substitute itself for the raters.

### M5 — Analysis and report

Compute validated scores, confidence intervals, coverage and hardware/licence tables. Build interactive HTML, print PDF and structured exports. Add measured, conditional conclusions and exact sample links. Independently verify a stratified sample and all disputed metadata/classifications.

### M6 — Reproduction, review and release

Execute per-configuration reproduction snippets, rebuild the report offline, pass all release gates, inspect rendered pages and publish lawful internal/public packages. Return the final paths, completion status and reproducibility command. Do not announce completion merely because all scripts were written.

---

## 21. Default decisions, boundaries and handoff checklist

The initial numerical defaults are in `configs/benchmark.json`. Codex must not replace them silently with a tiny convenience subset. Changes require a decision record with rationale, impact on completeness/statistical precision and owner approval before results are examined.

The project needs real compute and real human ratings. Discovery and validator work can proceed without them, but production inference/human-study milestones cannot be simulated. Existing historical artifacts are optional for a legacy comparison and do not block a fresh auditable run. Hosted services require explicit approval; no API secret or paid service is assumed available.

The final handoff must contain: the frozen scope and discovery ledger; all code/environments; dataset/prompt manifests and preparation commands; actual inference/audio/event artifacts; human rating/QC data and methodology; complete source/rights ledger; per-configuration verification snippets; HTML/PDF/CSV/JSON report; test/release-gate logs; and checksummed internal/public packages. Every human score, accuracy value, timing number and capability assertion must be traceable.

**The outcome is not just a table with corrected labels. It is a complete execution record and a reproducible report whose quality, streaming, language, hardware and rights claims can each be checked.**
