#!/usr/bin/env python3
"""Resolve an HF model revision to a commit, WITHOUT downloading weights.

Requires huggingface_hub in a separately pinned discovery environment. Network
metadata access does not constitute licence acceptance or an inference test.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from datetime import datetime, timezone


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',required=True)
    p.add_argument('--revision',required=True,help='Tag, branch or SHA to resolve explicitly')
    p.add_argument('--output',required=True)
    a=p.parse_args()
    from huggingface_hub import HfApi
    info=HfApi().model_info(a.repo,revision=a.revision,files_metadata=True)
    if not info.sha: raise RuntimeError('No immutable revision returned')
    record={'repo_id':a.repo,'requested_revision':a.revision,'resolved_commit':info.sha,
            'checked_at':datetime.now(timezone.utc).isoformat(),'gated':info.gated,
            'files':[{'path':x.rfilename,'size':getattr(x,'size',None)} for x in info.siblings],
            'rights_approved':False,'weights_downloaded':False,'inference_executed':False}
    Path(a.output).write_text(json.dumps(record,indent=2)+'\n')

if __name__=='__main__': main()
