#!/usr/bin/env python3
"""Local Qwen3-ASR vLLM Hindi streaming smoke probe, not the production latency runner.

Prerequisites: audited, pinned qwen-asr[vllm] environment; local checkpoint;
PCM16 mono 16 kHz test WAV with human reference kept separately. No downloads.
The synchronous feeder records lateness; it is NOT evidence of zero backlog.
Source/API entry points: PRD sources S07, S37.
"""
from __future__ import annotations
import argparse
import inspect
import json
from pathlib import Path
import time
import uuid
import wave


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-path', required=True)
    p.add_argument('--audio', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--language', default='Hindi', help='Use auto for language identification')
    p.add_argument('--frame-ms', type=int, default=100)
    p.add_argument('--chunk-size-sec', type=float, default=2.0)
    a = p.parse_args()
    if not Path(a.model_path).is_dir() or a.frame_ms <= 0 or a.chunk_size_sec <= 0:
        p.error('Need a local pinned model directory and positive chunk sizes')
    # Optional model-specific imports are intentionally delayed until execution.
    import numpy as np
    from qwen_asr import Qwen3ASRModel
    with wave.open(a.audio, 'rb') as wav:
        if (wav.getnchannels(), wav.getsampwidth(), wav.getframerate()) != (1, 2, 16000):
            p.error('Prepare PCM16 mono 16 kHz audio with an audited resampler first')
        samples = np.frombuffer(wav.readframes(wav.getnframes()), dtype='<i2').astype(np.float32) / 32768
    if not len(samples):
        p.error('Empty audio')
    model = Qwen3ASRModel.LLM(model=str(Path(a.model_path).resolve()),
                             gpu_memory_utilization=0.8, max_new_tokens=256)
    signature = inspect.signature(model.init_streaming_state)
    if 'language' not in signature.parameters:
        raise RuntimeError('Pinned API has no forced-language parameter; inspect source before adapting')
    state = model.init_streaming_state(language=None if a.language == 'auto' else a.language,
                                       chunk_size_sec=a.chunk_size_sec)
    target = Path(a.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    run_id, epoch, previous = uuid.uuid4().hex, time.perf_counter(), ''
    with target.open('x', encoding='utf-8') as handle:
        def emit(event: str, **extra: object) -> None:
            row = {'run_id': run_id, 'clock_id': 'client', 'event': event,
                   't_ms': 1000 * (time.perf_counter() - epoch), 'data_class': 'measured', **extra}
            handle.write(json.dumps(row, ensure_ascii=False) + '\n'); handle.flush()
        emit('audio_start')
        step = round(a.frame_ms * 16)
        for left in range(0, len(samples), step):
            right = min(left + step, len(samples))
            deadline = epoch + right / 16000
            time.sleep(max(0, deadline - time.perf_counter()))
            emit('input_chunk', source_end_ms=right / 16)
            model.streaming_transcribe(samples[left:right], state)
            if state.text and state.text != previous:
                emit('partial_transcript', text=state.text)
                previous = state.text
        emit('audio_end')
        emit('flush_called')
        model.finish_streaming_transcribe(state)
        emit('final_transcript', text=state.text, language=state.language)
    print(f'Trace written: {target}. Use checks.cli stream; inspect input pacing before interpreting latency.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
