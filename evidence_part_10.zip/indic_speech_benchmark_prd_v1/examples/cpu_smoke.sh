#!/usr/bin/env bash
# Run the IMPLEMENTED per-model smoke command with accelerator visibility disabled.
# This wrapper alone does not prove CPU inference; retain model/device/placement logs.
set -euo pipefail
if [ "$#" -eq 0 ]; then
  echo 'Usage: bash examples/cpu_smoke.sh <implemented model smoke command and arguments>' >&2
  exit 2
fi
export CUDA_VISIBLE_DEVICES=""
export HIP_VISIBLE_DEVICES=""
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-4}"
exec "$@"
