#!/usr/bin/env python3
"""Measure an already-running raw-PCM HTTP TTS endpoint.

This measures CLIENT delivery, not proof of intra-segment synthesis. It does not
start a model, accept licences, discover cloud credentials or buy API credits.
Use a JSON payload that matches the pinned server's documented task/voice.
"""
from __future__ import annotations
import argparse
import http.client
import json
import os
from pathlib import Path
import time
from urllib.parse import urlsplit
import uuid
import wave


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--url', default='http://127.0.0.1:8000/v1/audio/speech')
    p.add_argument('--payload', required=True, help='JSON file; must request raw PCM streaming')
    p.add_argument('--output-dir', required=True)
    p.add_argument('--sample-rate', type=int, required=True)
    p.add_argument('--channels', type=int, default=1)
    p.add_argument('--timeout-s', type=float, default=120)
    p.add_argument('--max-bytes', type=int, default=32 * 1024 * 1024)
    p.add_argument('--allow-remote', action='store_true')
    p.add_argument('--api-key-env', default='SPEECH_API_KEY')
    a = p.parse_args()
    u = urlsplit(a.url)
    if u.scheme not in ('http', 'https') or not u.hostname or u.username or u.password:
        p.error('Use an http(s) URL without embedded credentials')
    if u.hostname not in ('localhost', '127.0.0.1', '::1') and not a.allow_remote:
        p.error('Remote requests require --allow-remote and prior owner authorization')
    if a.sample_rate <= 0 or a.channels not in (1, 2) or a.max_bytes <= 0:
        p.error('Invalid audio parameters')
    payload = json.loads(Path(a.payload).read_text(encoding='utf-8'))
    if payload.get('stream') is not True or payload.get('response_format') != 'pcm':
        p.error('Payload must set stream=true and response_format="pcm"')
    out = Path(a.output_dir)
    out.mkdir(parents=True, exist_ok=False)
    run_id = uuid.uuid4().hex
    start = time.perf_counter_ns()
    events = []
    def emit(event: str, **extra: object) -> None:
        events.append({'run_id': run_id, 'clock_id': 'client', 'event': event,
                       't_ms': (time.perf_counter_ns() - start) / 1e6,
                       'data_class': 'measured', **extra})
    conn_cls = http.client.HTTPSConnection if u.scheme == 'https' else http.client.HTTPConnection
    conn = conn_cls(u.hostname, u.port, timeout=a.timeout_s)
    headers = {'Content-Type': 'application/json', 'Accept': 'application/octet-stream'}
    token = os.getenv(a.api_key_env)
    if token:
        headers['Authorization'] = 'Bearer ' + token
    byte_count, carry = 0, b''
    frame_size = 2 * a.channels
    success = False
    try:
        emit('request_start')
        conn.request('POST', u.path + ('?' + u.query if u.query else ''),
                     body=json.dumps(payload).encode(), headers=headers)
        response = conn.getresponse()
        emit('response_headers', status=response.status,
             content_type=response.getheader('Content-Type', ''))
        if not 200 <= response.status < 300:
            raise RuntimeError(f'HTTP {response.status}; response: {response.read(2048)!r}')
        if 'json' in response.getheader('Content-Type', '').lower():
            raise RuntimeError('Server returned JSON, not the raw PCM format expected by this probe')
        with wave.open(str(out / 'received.wav'), 'wb') as wav:
            wav.setnchannels(a.channels); wav.setsampwidth(2); wav.setframerate(a.sample_rate)
            while True:
                if (time.perf_counter_ns() - start) / 1e9 > a.timeout_s:
                    raise TimeoutError('Total request deadline exceeded')
                block = response.read1(8192)
                if not block:
                    break
                byte_count += len(block)
                if byte_count > a.max_bytes:
                    raise ValueError('Output exceeded the configured byte limit')
                carry += block
                complete = len(carry) // frame_size * frame_size
                if complete:
                    pcm, carry = carry[:complete], carry[complete:]
                    emit('audio_chunk', bytes=len(pcm),
                         audio_ms=1000 * len(pcm) / (frame_size * a.sample_rate))
                    wav.writeframesraw(pcm)
        if carry:
            raise ValueError('PCM response ended with an incomplete audio frame')
        if byte_count == 0:
            raise ValueError('Server returned no audio')
        emit('request_end')
        success = True
    except Exception as exc:
        emit('request_error', error_type=type(exc).__name__, detail=str(exc))
        print(f'Probe failed: {exc}')
    finally:
        conn.close()
        (out / 'events.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in events))
        (out / 'probe.json').write_text(json.dumps({'run_id': run_id, 'success': success,
            'url_host': u.hostname, 'bytes': byte_count, 'sample_rate': a.sample_rate,
            'channels': a.channels, 'proof_scope': 'client_delivery_only',
            'producer_streaming_class': None}, indent=2) + '\n')
    return 0 if success else 2

if __name__ == '__main__':
    raise SystemExit(main())
