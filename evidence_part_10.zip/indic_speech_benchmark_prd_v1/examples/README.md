# Verification snippets and integration probes

The standalone validators in `checks/` are runnable now. The probes here require the named model/server environments; **they were not model-executed when this PRD was created**. Codex must pin dependencies, run them and replace diagnostic probes with production adapters where specified. Syntax checking is not an inference test.

| File | What it checks | What it does not establish |
|---|---|---|
| `freeze_model.py` | Resolves a model locator to an immutable revision without weight downloads | Licence approval, successful inference, historical checkpoint identity |
| `http_pcm_probe.py` | First playable PCM arrival, chunk durations, client delivery trace | Native synthesis streaming or server compute time |
| `qwen_asr_stream_probe.py` | Local Qwen ASR streaming state, forced Hindi parameter, partials and final flush | Production concurrency, lack of backlog, or a stable p95 latency estimate |
| `voxcpm_stream_probe.py` | Generator output and model-declared sample rate | Internal model architecture or voice-quality rating |
| `adapter_contract.py` | Required adapter methods for Codex to implement | A working integration by itself |
| `cpu_smoke.sh` | Removes accelerator visibility before launching a supplied command | Successful model computation or real-time CPU speed |

## Run independent checks first

```bash
python -m unittest discover -s tests -v
python -m checks.cli score tests/fixtures/asr.jsonl
python -m checks.cli stream tests/fixtures/tts_events.jsonl --kind tts
python -m checks.cli stream tests/fixtures/producer_events.jsonl --kind producer
python -m checks.cli doctor
```

The fixtures are explicitly synthetic software-test data. Their values must never appear as model benchmark results.

## Probe a pinned local ASR deployment

```bash
python examples/qwen_asr_stream_probe.py \
  --model-path /absolute/path/to/pinned-qwen-asr-snapshot \
  --audio /absolute/path/to/real-hi-16k-mono-pcm16.wav \
  --language Hindi --output runs/qwen-hi-stream/events.jsonl
python -m checks.cli stream runs/qwen-hi-stream/events.jsonl --kind asr
```

The synchronous diagnostic feeder may fall behind. Use the recorded lateness as a failure indicator. The production runner must have an independent real-time producer and queue instrumentation. Never copy this probe's timing into a production-latency table without those controls.

## Probe local HTTP PCM output

Create a JSON payload from the pinned server's actual model/task/voice schema. The generic probe requires `stream: true` and `response_format: "pcm"`; it intentionally does not guess a voice, a reference recording or a sample rate.

```bash
python examples/http_pcm_probe.py \
  --url http://127.0.0.1:8000/v1/audio/speech \
  --payload private/verified-request.json \
  --sample-rate 24000 --output-dir runs/http-probe
python -m checks.cli stream runs/http-probe/events.jsonl --kind tts
```

The sample rate in this example is a caller-selected value, not a universal TTS rate. Verify it from server metadata. Provide producer-side events separately to establish A/B/C output semantics. Do not send private recordings to a hosted endpoint without permission.

## Final report requirement

The finished benchmark MUST contain an executed `reproduce/<config_id>/` folder for **every tested configuration**, including the exact install/lockfile, command, minimal inference snippet, input ID, expected result schema and assertion script. The six generic examples above do not substitute for those per-configuration artifacts. See PRD section 18.
