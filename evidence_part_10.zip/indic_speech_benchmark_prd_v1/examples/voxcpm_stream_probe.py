#!/usr/bin/env python3
"""Check a local pinned VoxCPM generator without guessing its output sample rate.

Model execution is not performed by the PRD package tests. See S32 and S52.
This caller trace measures yielded audio. Add internal producer hooks before
claiming a model-architecture class. Reference-voice use requires consent.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import uuid


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-path',required=True)
    p.add_argument('--text-file',required=True)
    p.add_argument('--output-dir',required=True)
    a = p.parse_args()
    if not Path(a.model_path).is_dir(): p.error('A local pinned checkpoint is required')
    from voxcpm import VoxCPM
    import numpy as np
    import soundfile as sf
    out = Path(a.output_dir); out.mkdir(parents=True,exist_ok=False)
    model = VoxCPM.from_pretrained(a.model_path, load_denoiser=False)
    sample_rate = int(model.tts_model.sample_rate)
    text = Path(a.text_file).read_text(encoding='utf-8').strip()
    if not text: p.error('Empty text')
    events, chunks, run, epoch = [], [], uuid.uuid4().hex, time.perf_counter()
    def emit(name: str, **extra: object) -> None:
        events.append({'run_id':run,'clock_id':'client','event':name,
                       't_ms':(time.perf_counter()-epoch)*1000,'data_class':'measured',**extra})
    emit('request_start')
    for value in model.generate_streaming(text=text):
        audio = np.asarray(value,dtype=np.float32).reshape(-1)
        if audio.size == 0: continue
        if not np.isfinite(audio).all(): raise ValueError('Non-finite audio')
        emit('audio_chunk',audio_ms=audio.size/sample_rate*1000)
        chunks.append(audio)
    emit('request_end')
    if not chunks: raise ValueError('No audio emitted')
    sf.write(out/'received.wav',np.concatenate(chunks),sample_rate,subtype='PCM_16')
    (out/'events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in events))
    (out/'config.json').write_text(json.dumps({'model_path':a.model_path,'sample_rate':sample_rate,
                                               'proof_scope':'generator_delivery'},indent=2))
    return 0

if __name__ == '__main__': raise SystemExit(main())
