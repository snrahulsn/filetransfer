"""Small independent validators; not a model-inference implementation."""
__version__ = '1.0.0'
