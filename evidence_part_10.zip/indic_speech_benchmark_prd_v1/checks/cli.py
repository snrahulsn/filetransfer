from __future__ import annotations
import argparse
import json
import platform
import sys
from pathlib import Path
from .audio import inspect_wav
from .blind import rating_summary, make_pack
from .gate import validate_release
from .io_utils import read_jsonl
from .scoring import corpus_score
from .streaming import asr_metrics, tts_metrics, synthesis_class


def main() -> int:
    parser = argparse.ArgumentParser(description='Independent benchmark validation utilities')
    sub = parser.add_subparsers(dest='command', required=True)
    s = sub.add_parser('score'); s.add_argument('jsonl'); s.add_argument('--unit', choices=['word','codepoint'], default='word')
    s.add_argument('--casefold', action='store_true'); s.add_argument('--remove-punctuation', action='store_true')
    w = sub.add_parser('wav'); w.add_argument('path')
    st = sub.add_parser('stream'); st.add_argument('jsonl'); st.add_argument('--kind',choices=['asr','tts','producer'],required=True)
    st.add_argument('--clock'); st.add_argument('--buffer-ms',type=float,default=200)
    g = sub.add_parser('gate'); g.add_argument('plan'); g.add_argument('results'); g.add_argument('--root',required=True)
    b = sub.add_parser('blind-summary'); b.add_argument('ratings'); b.add_argument('expected_clips'); b.add_argument('--minimum-raters',type=int,default=5)
    p = sub.add_parser('blind-pack'); p.add_argument('recordings'); p.add_argument('--public',required=True); p.add_argument('--private',required=True)
    sub.add_parser('doctor')
    a = parser.parse_args()
    try:
        if a.command == 'score':
            output = corpus_score(read_jsonl(a.jsonl), unit=a.unit, casefold=a.casefold, remove_punctuation=a.remove_punctuation)
        elif a.command == 'wav': output = inspect_wav(a.path)
        elif a.command == 'stream':
            rows = read_jsonl(a.jsonl)
            if a.kind == 'asr': output = asr_metrics(rows, clock=a.clock or 'client')
            elif a.kind == 'tts': output = tts_metrics(rows, clock=a.clock or 'client',initial_buffer_ms=a.buffer_ms)
            else: output = synthesis_class(rows, clock=a.clock or 'producer')
        elif a.command == 'gate':
            output = validate_release(json.loads(Path(a.plan).read_text()), read_jsonl(a.results),a.root)
        elif a.command == 'blind-summary':
            output = rating_summary(read_jsonl(a.ratings),json.loads(Path(a.expected_clips).read_text()),minimum_raters=a.minimum_raters)
        elif a.command == 'blind-pack':
            output = make_pack(read_jsonl(a.recordings),a.public,a.private)
        else:
            output = {'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),
                      'model_inference_tested':False,'purpose':'validator environment only'}
        print(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False))
        if a.command in ('gate','blind-summary') and not output['complete']: return 2
        return 0
    except (ValueError,TypeError,KeyError,OSError) as exc:
        print(f'CHECK FAILED: {exc}',file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
