"""Check traces, not marketing labels. Network chunks alone cannot prove native streaming."""
from __future__ import annotations
import math
from typing import Iterable


def validate_events(events: Iterable[dict]) -> list[dict]:
    rows = list(events)
    if not rows:
        raise ValueError('Empty trace')
    run_ids = {r.get('run_id') for r in rows}
    if len(run_ids) != 1 or None in run_ids:
        raise ValueError('A trace must contain exactly one non-null run_id')
    last = {}
    for row in rows:
        clock, time = row.get('clock_id'), row.get('t_ms')
        if not clock or not isinstance(row.get('event'), str):
            raise ValueError('Every event needs clock_id and event')
        if isinstance(time, bool) or not isinstance(time, (int, float)) or not math.isfinite(time) or time < 0:
            raise ValueError('t_ms must be finite and non-negative')
        if time < last.get(clock, -1):
            raise ValueError('Events must be monotonic within each clock domain')
        last[clock] = time
    return rows


def one(rows: list[dict], event: str, clock: str) -> dict:
    found = [r for r in rows if r['event'] == event and r['clock_id'] == clock]
    if len(found) != 1:
        raise ValueError(f'Expected exactly one {event} on clock {clock}')
    return found[0]


def asr_metrics(events: Iterable[dict], *, clock: str = 'client',
                pacing_tolerance_ms: float = 5.0) -> dict:
    rows = validate_events(events)
    start = one(rows, 'audio_start', clock)['t_ms']
    end = one(rows, 'audio_end', clock)['t_ms']
    final = one(rows, 'final_transcript', clock)['t_ms']
    if end <= start or final < end:
        raise ValueError('Expected audio_start < audio_end <= final_transcript')
    partials = [r for r in rows if r['clock_id'] == clock and
                r['event'] == 'partial_transcript' and r.get('text', '').strip()]
    chunks = [r for r in rows if r['clock_id'] == clock and r['event'] == 'input_chunk']
    if not chunks:
        raise ValueError('Pacing evidence requires input_chunk events')
    source_ends = [float(r['source_end_ms']) for r in chunks]
    if source_ends != sorted(source_ends) or len(set(source_ends)) != len(source_ends):
        raise ValueError('Input source offsets must strictly increase')
    if source_ends[0] <= 0:
        raise ValueError('source_end_ms must be positive')
    lateness = [r['t_ms'] - start - r['source_end_ms'] for r in chunks]
    first = partials[0]['t_ms'] if partials else None
    return {'first_partial_ms': None if first is None else first - start,
            'partial_before_audio_end': first is not None and start <= first < end,
            'partial_before_source_audio_end': first is not None and start <= first < start + source_ends[-1],
            'final_after_audio_end_ms': final - end,
            'input_supplied_before_available': min(lateness) < -pacing_tolerance_ms,
            'maximum_feed_lateness_ms': max(lateness),
            'tail_flush_called': any(r['event'] == 'flush_called' for r in rows),
            'native_streaming_proven_by_this_trace': False}


def playout(chunks: list[tuple[float, float]], initial_buffer_ms: float = 200.0) -> dict:
    if initial_buffer_ms < 0 or not chunks:
        raise ValueError('Need non-negative buffer and at least one playable chunk')
    previous = -1.0
    for arrival, duration in chunks:
        if not math.isfinite(arrival) or not math.isfinite(duration) or arrival < previous or duration <= 0:
            raise ValueError('Chunks need monotonic arrivals and finite positive durations')
        previous = arrival
    first = chunks[0][0] + initial_buffer_ms
    available_until, stalls, stall_count = first, 0.0, 0
    for i, (arrival, duration) in enumerate(chunks):
        if i and arrival > available_until:
            stalls += arrival - available_until
            stall_count += 1
        available_until = max(available_until, arrival) + duration
    return {'playback_start_ms': first, 'playback_end_ms': available_until,
            'stall_ms': stalls, 'stall_count': stall_count,
            'initial_buffer_ms': initial_buffer_ms}


def tts_metrics(events: Iterable[dict], *, clock: str = 'client',
                initial_buffer_ms: float = 200.0) -> dict:
    rows = validate_events(events)
    start = one(rows, 'request_start', clock)['t_ms']
    end = one(rows, 'request_end', clock)['t_ms']
    audio = [r for r in rows if r['clock_id'] == clock and r['event'] == 'audio_chunk']
    if not audio or end < start:
        raise ValueError('Need playable audio and an ordered request lifecycle')
    if audio[0]['t_ms'] < start or audio[-1]['t_ms'] > end:
        raise ValueError('Audio must be inside request lifecycle')
    chunks = [(r['t_ms'] - start, float(r['audio_ms'])) for r in audio]
    playback = playout(chunks, initial_buffer_ms)
    total_audio = sum(d for _, d in chunks)
    return {'first_playable_audio_ms': chunks[0][0], 'audio_duration_ms': total_audio,
            'client_request_duration_ms': end - start,
            'client_elapsed_rtf': (end - start) / total_audio,
            'transport_chunks': len(chunks), 'playout': playback,
            'native_synthesis_streaming_proven': False}


def synthesis_class(events: Iterable[dict], *, clock: str = 'producer') -> dict:
    """Classify this observed producer path only. GPU work must be synchronized correctly."""
    rows = [r for r in validate_events(events) if r['clock_id'] == clock]
    done = one(rows, 'generation_end', clock)['t_ms']
    audio = [r for r in rows if r['event'] == 'audio_chunk']
    if not audio:
        raise ValueError('Need producer audio-chunk events, not network-only evidence')
    if any(not isinstance(r.get('audio_ms'), (int, float)) or not math.isfinite(r['audio_ms']) or r['audio_ms'] <= 0 for r in audio):
        raise ValueError('Producer audio chunks need positive playable audio_ms')
    segment_ends = [r for r in rows if r['event'] == 'segment_end']
    completed = {r['segment_id']: r['t_ms'] for r in segment_ends}
    if len(completed) != len(segment_ends):
        raise ValueError('Each segment must have exactly one segment_end')
    if any(t > done for t in completed.values()):
        raise ValueError('Segments must finish no later than generation_end')
    ids = {r.get('segment_id') for r in audio}
    if None in ids or any(i not in completed for i in ids):
        raise ValueError('Need segment_id and segment_end for every produced chunk')
    if any(r['t_ms'] < completed[r['segment_id']] for r in audio):
        mode = 'A_incremental_within_segment'
    elif all(r['t_ms'] >= done for r in audio):
        mode = 'C_full_request_output'
    elif len(ids) >= 2:
        mode = 'B_completed_segment_delivery'
    else:
        raise ValueError('Trace does not distinguish a single completed segment from full output')
    return {'observed_output_class': mode, 'scope': 'this_configuration_and_trace',
            'requires_source_code_review_for_architecture_claim': True}
