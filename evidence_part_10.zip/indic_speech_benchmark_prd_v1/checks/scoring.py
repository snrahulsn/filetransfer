"""Reference WER/CER arithmetic. Production should cross-check jiwer against this.

NFC is deliberate: vowel marks are not stripped. This is NOT language-specific
number normalization. Empty-reference false positives are reported separately.
"""
from __future__ import annotations
from dataclasses import dataclass
import unicodedata as ud
from typing import Iterable, Sequence


def normalize(text: str, *, casefold: bool = False,
              remove_punctuation: bool = False) -> str:
    if not isinstance(text, str):
        raise TypeError('Transcript must be a string')
    text = ud.normalize('NFC', text)
    if casefold:
        text = text.casefold()
    if remove_punctuation:
        text = ''.join(' ' if ud.category(ch).startswith('P') else ch for ch in text)
    return ' '.join(text.split())


@dataclass(frozen=True)
class Edits:
    substitutions: int
    deletions: int
    insertions: int
    reference_units: int

    @property
    def errors(self) -> int:
        return self.substitutions + self.deletions + self.insertions

    @property
    def rate(self) -> float | None:
        return self.errors / self.reference_units if self.reference_units else None


def align(reference: Sequence[str], hypothesis: Sequence[str]) -> Edits:
    # Each state contains distance, substitutions, deletions, insertions.
    previous = [(j, 0, 0, j) for j in range(len(hypothesis) + 1)]
    for i, ref in enumerate(reference, 1):
        current = [(i, 0, i, 0)]
        for j, hyp in enumerate(hypothesis, 1):
            a = previous[j - 1]
            delta = int(ref != hyp)
            substitution = (a[0] + delta, a[1] + delta, a[2], a[3])
            b = previous[j]
            deletion = (b[0] + 1, b[1], b[2] + 1, b[3])
            c = current[j - 1]
            insertion = (c[0] + 1, c[1], c[2], c[3] + 1)
            current.append(min((substitution, deletion, insertion), key=lambda x: x[0]))
        previous = current
    _, s, d, ins = previous[-1]
    return Edits(s, d, ins, len(reference))


def corpus_score(rows: Iterable[dict], *, unit: str = 'word',
                 casefold: bool = False, remove_punctuation: bool = False) -> dict:
    if unit not in ('word', 'codepoint'):
        raise ValueError('unit must be word or codepoint; grapheme CER is a separate metric')
    totals = [0, 0, 0, 0]
    n = silence = false_positive_units = failures = 0
    seen = set()
    for row in rows:
        key = row['sample_id']
        if key in seen:
            raise ValueError(f'Duplicate sample_id: {key}')
        seen.add(key)
        ref = normalize(row['reference'], casefold=casefold,
                        remove_punctuation=remove_punctuation)
        hyp = normalize(row['hypothesis'], casefold=casefold,
                        remove_punctuation=remove_punctuation)
        rt = ref.split() if unit == 'word' else list(ref.replace(' ', ''))
        ht = hyp.split() if unit == 'word' else list(hyp.replace(' ', ''))
        n += 1
        if row.get('status') in ('timeout', 'runtime_error', 'oom'):
            failures += 1
        if not rt:
            silence += 1
            false_positive_units += len(ht)
            continue
        e = align(rt, ht)
        for index, value in enumerate((e.substitutions, e.deletions,
                                        e.insertions, e.reference_units)):
            totals[index] += value
    if n == 0:
        raise ValueError('No rows to score')
    s, d, ins, count = totals
    return {'unit': unit, 'normalization': {'nfc': True, 'casefold': casefold,
            'remove_punctuation': remove_punctuation, 'strip_combining_marks': False},
            'samples': n, 'reference_units': count, 'substitutions': s,
            'deletions': d, 'insertions': ins,
            'error_rate': (s + d + ins) / count if count else None,
            'empty_reference_samples': silence,
            'empty_reference_false_positive_units': false_positive_units,
            'failure_samples': failures}
