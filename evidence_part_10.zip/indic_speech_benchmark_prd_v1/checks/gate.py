"""Conservative evidence/coverage gate for planned cells.

A closed measured failure is not a pass on a product-performance target.
This starter gate is extended by Codex with the metric-specific requirements.
"""
from __future__ import annotations
from pathlib import Path
from .io_utils import sha256_file, within

CLOSED = {'measured_success', 'measured_failure', 'not_applicable', 'approved_exclusion'}


def validate_release(plan: dict, results: list[dict], root: str | Path) -> dict:
    errors, outcomes = [], {}
    requirements = plan.get('requirements', [])
    required = {r['cell_id']: r for r in requirements}
    if len(required) != len(requirements) or not required:
        raise ValueError('Plan needs non-empty unique cell IDs')
    for row in results:
        cell = row.get('cell_id')
        if cell in outcomes:
            errors.append(f'{cell}: duplicate result')
        outcomes[cell] = row
        if cell not in required:
            errors.append(f'{cell}: not in frozen plan')
    for cell, req in required.items():
        row = outcomes.get(cell)
        if row is None:
            errors.append(f'{cell}: missing')
            continue
        status = row.get('status')
        if status not in CLOSED:
            errors.append(f'{cell}: not closed ({status})')
        if row.get('data_class') == 'synthetic_fixture':
            errors.append(f'{cell}: synthetic fixture cannot support a report result')
        if status in ('measured_success', 'measured_failure') and row.get('data_class') != 'measured':
            errors.append(f'{cell}: actual measurement provenance required')
        evidence = row.get('evidence', [])
        if not evidence:
            errors.append(f'{cell}: no evidence')
        for item in evidence:
            try:
                path = within(root, item['path'])
                if not path.is_file() or sha256_file(path) != item['sha256']:
                    errors.append(f'{cell}: evidence absent or hash mismatch')
            except (KeyError, ValueError, OSError):
                errors.append(f'{cell}: invalid evidence path')
        if status in ('approved_exclusion', 'not_applicable'):
            if not row.get('reason'):
                errors.append(f'{cell}: exclusion/applicability reason required')
            if status == 'approved_exclusion' and not row.get('owner_approval_id'):
                errors.append(f'{cell}: owner approval required')
        if req.get('kind') == 'human_quality' and status == 'measured_success':
            q = row.get('human_quality', {})
            if q.get('rating_source') != 'human_blind' or q.get('complete') is not True:
                errors.append(f'{cell}: complete human blind ratings required')
            if q.get('minimum_raters', 0) < req.get('minimum_raters', 5):
                errors.append(f'{cell}: insufficient independent raters')
            planned = q.get('planned_prompts', q.get('expected_clips', 0))
            failed_ids = q.get('failed_generation_cell_ids', [])
            if planned < req.get('minimum_prompts', req.get('minimum_clips', 40)):
                errors.append(f'{cell}: insufficient planned prompts')
            if q.get('expected_clips', 0) + len(failed_ids) != planned:
                errors.append(f'{cell}: successful and failed prompt counts do not reconcile')
            if len(failed_ids) != len(set(failed_ids)):
                errors.append(f'{cell}: duplicate failed generation references')
            for failure_id in failed_ids:
                if outcomes.get(failure_id, {}).get('status') != 'measured_failure':
                    errors.append(f'{cell}: failed generation lacks its own closed evidence cell')
                if required.get(failure_id, {}).get('kind') != 'generation':
                    errors.append(f'{cell}: failed prompt must reference a planned generation cell')
                if failure_id not in req.get('generation_cell_ids', []):
                    errors.append(f'{cell}: failed generation is not associated with this study in the frozen plan')
            if q.get('expected_clips', 0) == 0:
                errors.append(f'{cell}: no audio exists for a human quality result')
    counts = {status: sum(r.get('status') == status for r in outcomes.values()) for status in sorted(CLOSED)}
    return {'complete': not errors, 'planned_cells': len(required), 'status_counts': counts,
            'errors': errors, 'qualification_pass': None,
            'note': 'Completeness is not a claim that every model is usable or every target is met.'}
