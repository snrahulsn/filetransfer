"""Strict PCM16 WAV checks; no inference or automatic quality rating."""
from __future__ import annotations
from array import array
import math
import sys
import wave
from pathlib import Path
from .io_utils import sha256_file


def read_pcm16(path: str | Path) -> tuple[bytes, int, int]:
    with wave.open(str(path), 'rb') as wav:
        if wav.getcomptype() != 'NONE' or wav.getsampwidth() != 2:
            raise ValueError('Expected uncompressed PCM16 WAV; convert explicitly before checking')
        rate, channels, frames = wav.getframerate(), wav.getnchannels(), wav.getnframes()
        payload = wav.readframes(frames)
        if rate <= 0 or channels <= 0 or frames == 0:
            raise ValueError('Invalid or empty audio')
        if len(payload) != frames * channels * 2:
            raise ValueError('Truncated WAV payload')
    return payload, rate, channels


def inspect_wav(path: str | Path) -> dict:
    payload, rate, channels = read_pcm16(path)
    samples = array('h')
    samples.frombytes(payload)
    if sys.byteorder != 'little':
        samples.byteswap()
    rms = math.sqrt(sum(int(v) * int(v) for v in samples) / len(samples)) / 32768
    return {'path': str(path), 'sha256': sha256_file(path), 'sample_rate': rate,
            'channels': channels, 'duration_s': len(samples) / (rate * channels),
            'peak_abs': max(abs(int(v)) for v in samples) / 32768,
            'rms_dbfs': 20 * math.log10(rms) if rms > 0 else None,
            'clipped_sample_fraction': sum(v in (-32768, 32767) for v in samples) / len(samples),
            'all_zero': all(v == 0 for v in samples),
            'quality_rating': None}


def strip_wav_metadata(source: str | Path, destination: str | Path) -> None:
    """Re-encode the same PCM frames in a minimal WAV, removing INFO/vendor chunks."""
    if Path(source).resolve() == Path(destination).resolve():
        raise ValueError('Never overwrite the source recording')
    data, rate, channels = read_pcm16(source)
    Path(destination).parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), 'wb') as out:
        out.setparams((channels, 2, rate, 0, 'NONE', 'not compressed'))
        out.writeframes(data)
