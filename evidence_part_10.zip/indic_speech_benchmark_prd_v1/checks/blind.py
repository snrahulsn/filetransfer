"""Blind-pack construction and honest arithmetic for existing human ratings.

No ratings are generated here. This module does not implement a listening UI or
infer native-speaker qualification; those are mandatory Codex deliverables.
"""
from __future__ import annotations
from collections import defaultdict
import json
import random
import statistics
import uuid
from pathlib import Path
from .audio import strip_wav_metadata
from .io_utils import sha256_file, write_jsonl


def make_pack(records: list[dict], public_dir: str | Path, private_dir: str | Path) -> dict:
    public, private = Path(public_dir).resolve(), Path(private_dir).resolve()
    if private == public or private.is_relative_to(public) or public.is_relative_to(private):
        raise ValueError('Public and private directories must be disjoint siblings, not nested')
    if not records:
        raise ValueError('No recordings')
    if (public / 'manifest.jsonl').exists() or (private / 'blind_key.jsonl').exists():
        raise FileExistsError('Refusing to overwrite a previous blind pack')
    public.mkdir(parents=True, exist_ok=True)
    private.mkdir(parents=True, exist_ok=True)
    exposed, key = [], []
    seen = set()
    for record in records:
        original_id = record['recording_id']
        if original_id in seen:
            raise ValueError('Duplicate recording_id')
        seen.add(original_id)
        source = Path(record['audio_path'])
        if record.get('audio_sha256') != sha256_file(source):
            raise ValueError(f'Audio hash mismatch: {original_id}')
        token = uuid.uuid4().hex
        target = public / 'audio' / (token + '.wav')
        strip_wav_metadata(source, target)
        exposed.append({'clip_id': token, 'audio': f'audio/{token}.wav',
                        'locale': record['locale'], 'condition': record['condition']})
        key.append({**record, 'clip_id': token, 'blind_audio_sha256': sha256_file(target)})
    random.SystemRandom().shuffle(exposed)
    write_jsonl(public / 'manifest.jsonl', exposed)
    write_jsonl(private / 'blind_key.jsonl', key)
    (private / 'DO_NOT_PUBLISH.txt').write_text('Contains model identities and recording provenance. Never serve or publish this directory.\n')
    return {'clips': len(exposed), 'public_manifest': str(public / 'manifest.jsonl'),
            'private_key': str(private / 'blind_key.jsonl')}


def assign_raters(clip_ids: list[str], rater_ids: list[str], *, per_clip: int = 5,
                  seed: int = 20260924) -> list[dict]:
    if len(set(clip_ids)) != len(clip_ids) or len(set(rater_ids)) != len(rater_ids):
        raise ValueError('IDs must be unique')
    if not clip_ids or per_clip <= 0 or len(rater_ids) < per_clip:
        raise ValueError('Insufficient clips or independent raters')
    rng = random.Random(seed)
    counts = dict.fromkeys(rater_ids, 0)
    out = []
    shuffled = list(clip_ids)
    rng.shuffle(shuffled)
    for clip_id in shuffled:
        priorities = {rater: rng.random() for rater in rater_ids}
        selected = sorted(rater_ids, key=lambda r: (counts[r], priorities[r]))[:per_clip]
        for rater_id in selected:
            counts[rater_id] += 1
            out.append({'clip_id': clip_id, 'rater_id': rater_id})
    rng.shuffle(out)
    return out


def rating_summary(rows: list[dict], expected_clip_ids: list[str], *, minimum_raters: int = 5) -> dict:
    if isinstance(minimum_raters, bool) or not isinstance(minimum_raters, int) or minimum_raters <= 0:
        raise ValueError('minimum_raters must be a positive integer')
    if not expected_clip_ids or len(set(expected_clip_ids)) != len(expected_clip_ids):
        raise ValueError('Need unique expected clips')
    grouped = defaultdict(list)
    seen = set()
    repeats = 0
    for row in rows:
        if row.get('rating_source') != 'human_blind':
            raise ValueError('Only imported human_blind ratings are accepted')
        if row['clip_id'] not in expected_clip_ids:
            raise ValueError('Rating for unplanned clip')
        value = row['quality']
        if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 5:
            raise ValueError('Quality must be an integer from 1 through 5')
        if row.get('is_repeat', False):
            repeats += 1
            continue
        key = (row['clip_id'], row['rater_id'])
        if key in seen:
            raise ValueError('Duplicate rater/clip rating; hidden repeats must be tagged')
        seen.add(key)
        grouped[row['clip_id']].append(value)
    missing = {clip: len(grouped[clip]) for clip in expected_clip_ids
               if len(grouped[clip]) < minimum_raters}
    per_clip = {clip: statistics.mean(values) for clip, values in grouped.items() if values}
    accept = {clip: sum(v >= 3 for v in values) / len(values)
              for clip, values in grouped.items() if values}
    return {'rating_source': 'human_blind', 'complete': not missing,
            'expected_clips': len(expected_clip_ids), 'rated_clips': len(per_clip),
            'incomplete_clips': missing, 'minimum_raters': minimum_raters,
            'unique_raters': len({r for _, r in seen}), 'qc_repeat_ratings': repeats,
            'clip_weighted_mean': statistics.mean(per_clip.values()) if per_clip else None,
            'clip_weighted_fraction_at_least_3': statistics.mean(accept.values()) if accept else None,
            'per_clip_means': per_clip,
            'confidence_interval': None,
            'ci_note': 'Production report must add the preregistered prompt/rater-aware interval; this utility does not invent one.'}
