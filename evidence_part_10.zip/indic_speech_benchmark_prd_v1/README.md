# Indic Speech Benchmark — Codex PRD and checking package

**Version 1.0 · Source snapshot: 24 September 2026**

This package specifies a fresh end-to-end benchmark and report. It includes a detailed PRD, an expanded model inventory, primary-source references, data/schema templates, independent executable validators, integration probes and tests. It does **not** contain model benchmark results or fabricated human ratings.

## Give this to Codex

Attach this folder/ZIP and instruct Codex:

> Read `CODEX_START.md` and implement `PRD.md` through execution and final report generation. Use the checking code, expand the exact configurations, and do not stop at a plan. TTS quality must come from genuine human blind listening. Report concrete missing permissions/data/raters, and continue independent work while waiting for those inputs.

## Main documents

- `PRD.md` — canonical execution specification, including datasets, blind study, streaming proof, hardware, licences, report, acceptance gates and final per-configuration code requirements.
- `PRD.pdf` — readable print edition of the specification, verification guide and source register.
- `MODEL_INVENTORY.md` / `.csv` and `configs/model_inventory.json` — **15 ASR + 19 TTS entries**, including the original families and additional candidates. Language families/adapters expand into separate configurations.
- `SOURCES.md` / `evidence/sources.json` — 52 primary-source seeds with dates and scope notes. Codex must freeze actual revisions at execution time.
- `CODE_VERIFICATION.md` — commands to run the supplied checks and what each proves.
- `templates/` and `schemas/` — input request, rating import, failure/rights decisions and data-contract seeds.

## Run the supplied code

The independent checker/test suite uses Python 3.10+ and the standard library. No GPU, model download or API key is needed.

```bash
cd indic_speech_benchmark_prd_v1
python -m unittest discover -s tests -v
python -m checks.cli doctor
python -m checks.cli score tests/fixtures/asr.jsonl
python -m checks.cli stream tests/fixtures/tts_events.jsonl --kind tts
python -m checks.cli stream tests/fixtures/producer_events.jsonl --kind producer
```

The synthetic fixtures exercise software behavior only. Do not treat their scores or timestamps as real model measurements. The evidence gate rejects data explicitly marked `synthetic_fixture`.

`examples/` includes model/endpoint probes that require separately pinned environments or running servers. They were syntax-checked, not model-executed in this package. Read `examples/README.md` before running them. `speechbench ...` in the PRD is the target CLI Codex must build; it is not a command supplied by this starter package.

## Important study decisions

English means **Indian English**. Each deployed adapter, voice, dtype and backend is separately identifiable. The main TTS score uses actual blind human listening, with the original business anchor of 3/5 as the customer-acceptable minimum. The proposed release study uses 40 prompts per eligible model/locale/mode/primary voice, five independent raters per successful clip, and separate clean/telephony listening conditions. Existing single-listener scores are legacy observations unless their exact recordings and provenance can be recovered.

Current seed candidates include additional Indic-specific ASR, small-model controls, contemporary streaming models and explicitly named Indic TTS adapters. A separate authorized hosted-reference lane prevents a self-hosted-only report from pretending to measure the entire service market.

## What is tested in this package

See `evidence/BUILD_STATUS.json` and `evidence/validator_test_run.txt` for the actual utility test run. No model weights, real evaluation data, listener identities, ratings or API secrets are bundled. Historical photos are reference material only. The full model benchmark and report are Codex's implementation/execution task.
