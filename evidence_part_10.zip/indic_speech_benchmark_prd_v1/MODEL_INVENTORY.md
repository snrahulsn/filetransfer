# Model inventory and scope

**34 inventory entries: 15 ASR and 19 TTS.** Entries expand into configurations; a per-language family, an adapter, a voice, a precision and an inference mode are not interchangeable rows. The inventory is a finite starting scope, not a claim that every listed model supports all ten languages.

Every entry must be screened. All legally executable, accessible, target-language-eligible entries are mandatory benchmark candidates. A rights or access exclusion requires evidence, an owner decision, and visible accounting in the final report.

## ASR

### A01 — SraVaani-0.5-live

`ARTPARK-IISc/SraVaani-0.5-live`

Streaming Indic reference and named-CPU verification. Sources: [S01]. Expansion: `single_checkpoint`.

### A02 — Voxtral Mini 4B Realtime

`mistralai/Voxtral-Mini-4B-Realtime-2602`

Hindi and Indian-English realtime comparison. Sources: [S03]. Expansion: `single_checkpoint`.

### A03 — SraVaani-1.0

`ARTPARK-IISc/SraVaani-1.0`

Offline Indic reference. Sources: [S02]. Expansion: `single_checkpoint`.

### A04 — IndicConformer-600M multilingual

`ai4bharat/indic-conformer-600m-multilingual`

Indic multilingual reference. Sources: [S04]. Expansion: `single_checkpoint`.

### A05 — OmniASR CTC 1B

`facebook/omniASR-CTC-1B`

Multilingual CTC comparison. Sources: [S05], [S40]. Expansion: `single_checkpoint`.

### A06 — OmniASR CTC 300M

`facebook/omniASR-CTC-300M`

Smaller CTC efficiency comparison. Sources: [S06], [S40]. Expansion: `single_checkpoint`.

### A07 — Qwen3-ASR 1.7B

`Qwen/Qwen3-ASR-1.7B`

Separate native Hindi offline and supported streaming configurations. Sources: [S07], [S37]. Expansion: `single_checkpoint`.

### A08 — Whisper large-v3-turbo

`openai/whisper-large-v3-turbo`

General multilingual control; native and wrapper modes kept distinct. Sources: [S08]. Expansion: `single_checkpoint`.

### A09 — Qwen3-ASR 0.6B

`Qwen/Qwen3-ASR-0.6B`

Efficiency counterpart to 1.7B. Sources: [S09], [S37]. Expansion: `single_checkpoint`.

### A10 — Whisper large-v3

`openai/whisper-large-v3`

Quality/control comparison with turbo. Sources: [S10]. Expansion: `single_checkpoint`.

### A11 — Shrutam-2

`bharatgenai/Shrutam-2`

Indic-specific additional model; usage-rights gate. Sources: [S11]. Expansion: `single_checkpoint`.

### A12 — VibeVoice ASR

`microsoft/VibeVoice-ASR`

Long-form baseline; language eligibility and output parser verified. Sources: [S12]. Expansion: `single_checkpoint`.

### A13 — VibeVoice ASR Streaming 1.5B

`microsoft/VibeVoice-ASR-Streaming-1.5B`

Indian-English evaluation of an English-capable streaming model; not a Hindi-native claim. Sources: [S13]. Expansion: `single_checkpoint`.

### A14 — IndicWhisper language checkpoints

`https://github.com/AI4Bharat/vistaar`

Indic-specialized language checkpoints. Do not combine their weights into an imaginary multilingual model. Sources: [S14]. Expansion: `per_language_checkpoint`.

### A15 — MMS ASR language adapters

`facebook/mms-1b-all`

Broad language-adapter reference; flag dataset contamination risk. Sources: [S15]. Expansion: `per_language_adapter`.

## TTS

### T01 — svara-TTS

`kenpath/svara-tts-v1`

Indic output, Indian-English voice and CPU/streaming paths. Sources: [S16]. Expansion: `single_checkpoint`.

### T02 — Pocket TTS official

`kyutai/pocket-tts`

Official CPU streaming baseline; historical Indic clips are not attributed without proof. Sources: [S17], [S18]. Expansion: `single_checkpoint`.

### T03 — Kokoro

`hexgrad/Kokoro-82M`

Small Hindi/English voice baseline with explicit segment semantics. Sources: [S19]. Expansion: `single_checkpoint`.

### T04 — Indic Parler-TTS

`ai4bharat/indic-parler-tts`

Include Hindi; separate description and transcript tokenizers. Sources: [S20], [S39]. Expansion: `single_checkpoint`.

### T05 — Maya1

`maya-research/maya1`

English/Indian-accent listening and latency baseline. Sources: [S21]. Expansion: `single_checkpoint`.

### T06 — Bodhan Indic-Speak

`bodhan-ai/indic-speak`

Indic-language synthesis; classify exact implementation. Sources: [S22]. Expansion: `single_checkpoint`.

### T07 — Veena

`maya-research/Veena`

Hindi/English synthesis baseline. Sources: [S23]. Expansion: `single_checkpoint`.

### T08 — IndicF5

`ai4bharat/IndicF5`

Indic reference-conditioned synthesis. Sources: [S24]. Expansion: `single_checkpoint`.

### T09 — Sooktam-2

`bharatgenai/sooktam2`

Indic synthesis subject to usage-rights review. Sources: [S25]. Expansion: `single_checkpoint`.

### T10 — Voxtral 4B TTS

`mistralai/Voxtral-4B-TTS-2603`

Self-hosted Hindi/English streaming; rights-separated lane. Sources: [S26]. Expansion: `single_checkpoint`.

### T11 — Qwen3-TTS Hindi adapter (new named configuration)

`aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned`

Benchmark a named fresh Hindi adapter. Never assert it reproduces the unidentified historical row. Sources: [S27], [S29]. Expansion: `base_plus_adapter_subfolder`.

### T12 — Qwen3-TTS base controls

`Qwen/Qwen3-TTS-12Hz-1.7B-Base`

Base control versus Hindi/Indic adapters; 1.7B and 0.6B controls matched to adapter families. Sources: [S27], [S28], [S38]. Expansion: `matched_base_controls`.

### T13 — Chatterbox multilingual

`ResembleAI/chatterbox`

Hindi/English multilingual challenger. Sources: [S30]. Expansion: `single_checkpoint`.

### T14 — Chatterbox Hindi

`ResembleAI/Chatterbox-Multilingual-hi`

Hindi-specific official derivative. Sources: [S31]. Expansion: `single_checkpoint`.

### T15 — VoxCPM2

`openbmb/VoxCPM2`

Hindi/English streaming generator and new architecture comparison. Sources: [S32], [S52]. Expansion: `single_checkpoint`.

### T16 — Fish Audio S2 Pro

`fishaudio/s2-pro`

Broader-language challenger; research/commercial licence gate. Sources: [S33]. Expansion: `single_checkpoint`.

### T17 — XTTS v2

`coqui/XTTS-v2`

Hindi/English reference-conditioned baseline with custom licence. Sources: [S34]. Expansion: `single_checkpoint`.

### T18 — MMS TTS language checkpoints

`facebook/mms-tts-hin`

Per-language baseline; resolve official repositories for every target language. Sources: [S35]. Expansion: `per_language_checkpoint`.

### T19 — Qwen 0.6B community Indic adapters

`aguken-ai/Qwen3-TTS-0.6B-LoRA-Finetuned-Indic-Multilingual`

Expand verified target-language subfolders as distinct configurations; not one joint model. Sources: [S36]. Expansion: `per_language_adapter`.

## Hosted reference lane

Survey the following providers during scope freeze. Benchmark them in a separately labelled API lane only after credentials, rights, geographic processing and a spend ceiling are authorized. Once enabled, their required jobs participate in the same completion gate. Record opaque provider version limitations rather than inventing a commit.

- Sarvam: current Saaras ASR and Bulbul TTS [S46].
- Deepgram: eligible Nova/Flux ASR variants, resolved from the current language matrix [S47].
- ElevenLabs: Scribe ASR and a language-eligible conversational/low-latency TTS variant [S48].
- Google Cloud: Chirp 3 ASR and Chirp 3 HD TTS [S49, S50].
- Azure Speech: eligible en-IN/Indic recognition and voice endpoints [S51].

These services must not be described as open-weight or CPU/GPU-self-hostable merely because a client SDK is public. API charges and network latency are separate measurements.
