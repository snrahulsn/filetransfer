# Consolidated preflight input checklist

Codex: inspect the workspace first, fill the “found” fields, and ask only for missing prerequisites. No secret values belong in this file.

| Input | Found path / decision | Blocks |
|---|---|---|
| Approved self-hosted scope and legal evaluation context | | Scope/rights freeze |
| CPU/GPU hardware access and target deployment profile | | Runtime tests |
| Compute/storage budget and provisioning authorization | | Full runs |
| Gated model and dataset access, terms decision | | Affected downloads/runs |
| Ten-locale native prompt/reference reviewers | | Dataset/prompt freeze |
| Qualified listening panel and compensation approval | | Human evaluation |
| Voice reference consent/usage rights where required | | Reference-conditioned TTS |
| Hosted API credentials/regions/spend ceiling (optional lane) | | Hosted execution only |
| Historical blind audio, ratings, rubric, key (optional) | | Legacy appendix only |

For each blocker: state exact model/dataset/locale, exact file/field or authorization needed, owner, dependency and next action. Do not ask for unavailable historical artifacts as a prerequisite for a new auditable run.
