# Configuration verification — one record per executed configuration

- Model, tokenizer, processor and vocoder repository IDs/revisions/hashes.
- Adapter base/subfolder/weights/revision/target modules; loaded/merged state and proof it is active.
- Voice ID/reference PCM hash, transcript, consent and usage terms.
- Backend, container/environment lock, actual loaded versions and decoding parameters.
- Model API language argument versus benchmark locale.
- Input and output sample rates/formats; transformations and causality.
- ASR audio-input/transcript-output modes or TTS text-input/audio-output modes.
- Actual CPU/GPU placement, precision, threads, lookahead, memory and concurrency profile.
- Exact command, input manifest, output/events and validation result.
- Publisher claim evidence versus executed evidence, with contradictions resolved for this configuration.
- Intended-use approval for weights, code, adapter, voices, data and shipped artifacts.
- Minimal executed snippet in `reproduce/<config_id>/`.

Do not mark complete from documentation alone when the field is a measured capability.
