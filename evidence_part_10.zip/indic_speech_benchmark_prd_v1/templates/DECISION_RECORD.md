# Scope / rights / protocol decision

Decision ID:
Date:
Owner/approver:
Affected model/configuration/test cells:
Question:
Evidence and hashes:
Options considered:
Decision:
Reason:
Impact on coverage, statistics, cost and report wording:
Required reruns or new blind ratings:
Approval record location:

A model's bad performance is not a reason to delete it. A change made after seeing results must be disclosed and cannot silently redefine the primary analysis.
