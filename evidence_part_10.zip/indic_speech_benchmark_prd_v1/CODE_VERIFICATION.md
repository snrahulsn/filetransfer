# Code verification guide

The final report must ship code for checking every result, not only this generic starter. This guide distinguishes the runnable utilities already provided from model integrations Codex must execute.

## 1. Test the checker itself

```bash
python -m unittest discover -s tests -v
python -m compileall -q checks examples
```

Expected: all unit tests pass and compilation returns zero. Test fixtures are synthetic and cannot serve as benchmark evidence. A syntax pass says nothing about model API compatibility.

## 2. Check Indic scoring and corpus denominators

Input JSONL has `sample_id`, `reference`, `hypothesis` and an optional failure status. Use empty hypotheses for unavailable speech outputs; retain the failure status.

```bash
python -m checks.cli score runs/asr/raw_transcripts.jsonl
python -m checks.cli score runs/asr/raw_transcripts.jsonl --unit codepoint
python -m checks.cli score runs/asr/raw_transcripts.jsonl \
  --casefold --remove-punctuation
```

Inspect substitutions/deletions/insertions, reference units, silence false positives and the explicit normalization record. NFC/whitespace normalization preserves Indic marks. The primary CER here uses code points excluding spaces, not grapheme clusters. Language-specific number normalization is a separate production feature; this utility does not pretend to implement it.

```python
from checks.scoring import normalize, align
assert normalize("कि") != normalize("क")
assert align(["a"], ["b", "c", "d"]).rate == 3.0  # WER can exceed 100%
```

## 3. Inspect actual audio files

```bash
python -m checks.cli wav runs/tts/recording.wav
```

The input must be uncompressed PCM16 WAV. The output includes sample rate, duration, hash, clipping and RMS. `quality_rating` remains null: these checks do not produce human scores. Conversions from other formats must be explicit and retain raw files.

## 4. Check streaming traces

```bash
python -m checks.cli stream runs/asr/events.jsonl --kind asr
python -m checks.cli stream runs/tts/client_events.jsonl --kind tts --buffer-ms 200
python -m checks.cli stream runs/tts/producer_events.jsonl --kind producer
```

ASR requires audio start/end, actual input-chunk source offsets and a final transcript on a shared client clock. It exposes future-audio feeding and feed lateness. The production runner must additionally measure queue depth and tail coverage. TTS client metrics report first playable audio and simulated stalls. A/B/C synthesis proof uses producer-side segment-completion events; it cannot be inferred from network chunk counts alone.

```python
from checks.streaming import playout
result = playout([(100, 100), (700, 100)], initial_buffer_ms=200)
assert result["stall_ms"] == 300  # synthetic diagnostic, not a measured model result
```

## 5. Build a blinded audio pack

Supply a JSONL manifest with exact `recording_id`, `audio_path`, `audio_sha256`, `locale`, `condition` and private model/configuration metadata. Public and private destinations must be disjoint, not nested.

```bash
python -m checks.cli blind-pack private/recordings.jsonl \
  --public listening/public --private listening_private
```

The public manifest contains only opaque clip IDs, anonymous filenames, locale and condition. WAV metadata is stripped without changing PCM frames. Keep `listening_private/blind_key.jsonl` inaccessible to the listener application and public package. The production workflow must add authenticated assignments, controls/repeats, playback logging and a UI or controlled human import; this utility is not the complete study.

## 6. Check imported human ratings

The ratings schema includes `rating_source: "human_blind"`; values must be integers 1–5. Expected clip IDs are a JSON array from the frozen assignment plan. Never create a ratings file populated with invented people or estimates.

```bash
python -m checks.cli blind-summary private/real_ratings.jsonl \
  private/expected_successful_clip_ids.json --minimum-raters 5
```

A nonzero exit means required independent ratings are missing or invalid. Tagged hidden repeats do not increase the sample count. This utility calculates clip-weighted arithmetic; Codex must implement the preregistered prompt/rater-aware confidence intervals and QC workflow. The `human_blind` field is a provenance assertion that must be backed by actual collection records, not permission to synthesize ratings.

## 7. Check release coverage and evidence

```bash
python -m checks.cli gate scope/expected_cells.json runs/cell_results.jsonl \
  --root .
```

The gate checks that every required cell is represented once, is in a valid closed state and has hash-verified evidence. Exclusions need reasons and owner approval; measured failures remain visible. Human-quality rollups require actual complete human provenance and minimum independent raters. Planned prompts that failed generation must point to separate closed failure evidence; no human score is fabricated for missing audio. Codex must add the full metric-specific checks in the PRD, rather than treating this minimum gate as exhaustive.

## 8. Check the archive

After extraction, verify the package's file hashes with:

```bash
python verify_package.py
```

A successful check means bytes match the shipped manifest, not that all model claims or results have been verified. See `evidence/BUILD_STATUS.json` for execution status.

## 9. Required final per-configuration snippets

For every tested model/backend/language-adapter configuration, Codex must supply an executed minimal generation/transcription script, exact lock/container and command, input ID, expected output schema and assertion file. Include offline/streaming and CPU/memory checks where applicable. A generic client or a link to upstream documentation does not replace the executed snippet for that configuration.
