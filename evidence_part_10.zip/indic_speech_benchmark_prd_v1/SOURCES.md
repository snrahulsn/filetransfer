# Primary-source register

Research snapshot: **24 September 2026**. These are discovery/evidence seeds, not claims that model inference was executed in this package. Codex must capture the exact revisions and licence files at execution freeze. Re-check changed releases and document changes; never silently substitute a new version.

## [S01] SraVaani-0.5-live

https://huggingface.co/ARTPARK-IISc/SraVaani-0.5-live

Cache-aware streaming model; CPU and lookahead claims must be tested on the selected runtime.

## [S02] SraVaani-1.0

https://huggingface.co/ARTPARK-IISc/SraVaani-1.0

Original offline comparison entry. Freeze access, language list, code and weights.

## [S03] Voxtral Mini 4B Realtime

https://huggingface.co/mistralai/Voxtral-Mini-4B-Realtime-2602

Exact realtime ASR candidate; distinct from the Voxtral TTS checkpoint.

## [S04] IndicConformer multilingual

https://huggingface.co/ai4bharat/indic-conformer-600m-multilingual

Indic-language ASR reference. Resolve actual language identifiers and inference path.

## [S05] OmniASR CTC 1B

https://huggingface.co/facebook/omniASR-CTC-1B

Broader multilingual CTC reference; memory figures are configuration-dependent.

## [S06] OmniASR CTC 300M

https://huggingface.co/facebook/omniASR-CTC-300M

Smaller CTC comparison entry.

## [S07] Qwen3-ASR 1.7B

https://huggingface.co/Qwen/Qwen3-ASR-1.7B

Hindi is included in the base ASR language list; distinguish its supported streaming backend.

## [S08] Whisper large-v3-turbo

https://huggingface.co/openai/whisper-large-v3-turbo

Original general multilingual ASR control; wrapper streaming is a separate configuration.

## [S09] Qwen3-ASR 0.6B

https://huggingface.co/Qwen/Qwen3-ASR-0.6B

Smaller ASR efficiency baseline.

## [S10] Whisper large-v3

https://huggingface.co/openai/whisper-large-v3

Full-size control separate from turbo.

## [S11] BharatGen Shrutam-2

https://huggingface.co/bharatgenai/Shrutam-2

Additional Indic ASR; publisher lists twelve Indian languages and a non-commercial licence.

## [S12] Microsoft VibeVoice ASR

https://huggingface.co/microsoft/VibeVoice-ASR

Additional long-form ASR. Do not conflate long-form speaker attribution with live streaming.

## [S13] Microsoft VibeVoice ASR Streaming 1.5B

https://huggingface.co/microsoft/VibeVoice-ASR-Streaming-1.5B

Additional streaming English control; the advertised ten-language list does not include Hindi.

## [S14] AI4Bharat Vistaar / IndicWhisper

https://github.com/AI4Bharat/vistaar

Official IndicWhisper checkpoints and benchmark context; expand individual language checkpoints.

## [S15] Meta MMS ASR

https://huggingface.co/facebook/mms-1b-all

Language-adapter baseline; verify adapter IDs and training/test overlap.

## [S16] svara-TTS

https://huggingface.co/kenpath/svara-tts-v1

Original Indic TTS entry; freeze the code path and tokenizer/vocoder dependencies.

## [S17] Pocket TTS official weights

https://huggingface.co/kyutai/pocket-tts

Official weights source. Do not attribute unidentified Indic recordings to this checkpoint.

## [S18] Pocket TTS official code

https://github.com/kyutai-labs/pocket-tts

CPU and incremental audio interface; code and weights licences are separate.

## [S19] Kokoro 82M

https://huggingface.co/hexgrad/Kokoro-82M

Hindi/English baseline. Segment delivery must not be confused with intra-segment synthesis.

## [S20] Indic Parler-TTS

https://huggingface.co/ai4bharat/indic-parler-tts

Includes Hindi and Indian-English voice support; follow model-specific tokenizer handling.

## [S21] Maya1

https://huggingface.co/maya-research/maya1

Original English TTS entry; CPU compatibility and GPU recommendation must be separated.

## [S22] Bodhan Indic-Speak

https://huggingface.co/bodhan-ai/indic-speak

Original Indic TTS entry; inspect released inference and custom licence.

## [S23] Veena

https://huggingface.co/maya-research/Veena

Original Hindi/English TTS entry; freeze the currently implemented output interface.

## [S24] IndicF5

https://huggingface.co/ai4bharat/IndicF5

Original Indic TTS entry; reference voice rights and output mode require configuration-level checks.

## [S25] Sooktam-2

https://huggingface.co/bharatgenai/sooktam2

Original Indic TTS entry with non-commercial licensing considerations.

## [S26] Voxtral 4B TTS

https://huggingface.co/mistralai/Voxtral-4B-TTS-2603

Hindi/English TTS; self-hosted streaming is documented. Distinct from realtime ASR.

## [S27] Qwen3-TTS 1.7B Base

https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-Base

Base TTS language list excludes Hindi. Base, CustomVoice and VoiceDesign are distinct tasks.

## [S28] Qwen3-TTS implementation

https://github.com/QwenLM/Qwen3-TTS

Source for exact local generation semantics; reconcile with backend-specific current implementations.

## [S29] Named community Qwen Hindi adapter

https://huggingface.co/aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned

New auditable candidate, not assumed to be the adapter in the old screenshot. Validate actual PEFT attachment and voice rights.

## [S30] Chatterbox multilingual

https://huggingface.co/ResembleAI/chatterbox

Additional multilingual TTS including a Hindi candidate.

## [S31] Chatterbox dedicated Hindi

https://huggingface.co/ResembleAI/Chatterbox-Multilingual-hi

Official Hindi-specific derivative; test separately from the multilingual checkpoint.

## [S32] VoxCPM2

https://huggingface.co/openbmb/VoxCPM2

Additional Hindi/English candidate with a released streaming generator. Read output sample rate from the model.

## [S33] Fish Audio S2 Pro

https://huggingface.co/fishaudio/s2-pro

Additional broad-language TTS; research licence requires usage review before execution.

## [S34] XTTS v2

https://huggingface.co/coqui/XTTS-v2

Hindi/English reference baseline. Custom weights licence and reference voice rights are separate checks.

## [S35] MMS TTS family example

https://huggingface.co/facebook/mms-tts-hin

Seed for official per-language MMS TTS discovery; do not guess other repository IDs.

## [S36] Community Qwen 0.6B Indic adapter collection

https://huggingface.co/aguken-ai/Qwen3-TTS-0.6B-LoRA-Finetuned-Indic-Multilingual

A collection of language-specific adapters, not proof of one joint multilingual checkpoint. Expand only verified target-language subfolders.

## [S37] Qwen ASR streaming example

https://github.com/QwenLM/Qwen3-ASR/blob/main/examples/example_qwen3_asr_vllm_streaming.py

Official stateful streaming API example; benchmark pacing and resampling must be more rigorous than a minimal demo.

## [S38] vLLM-Omni Qwen3-TTS v0.18.0

https://docs.vllm.ai/projects/vllm-omni/en/v0.18.0/user_guide/examples/online_serving/qwen3_tts/

Versioned docs describe incremental PCM and a sentence-buffered text WebSocket. Adapter compatibility still needs testing.

## [S39] Parler inference guide

https://github.com/huggingface/parler-tts/blob/main/INFERENCE.md

Streamer implementation and generation lifecycle. Apply Indic-specific tokenization separately.

## [S40] Meta omnilingual ASR code

https://github.com/facebookresearch/omnilingual-asr

CPU path and published memory setup. Record precision, batch size, duration and hardware.

## [S41] Svarah Indian-English dataset

https://github.com/AI4Bharat/Svarah

Primary Indian-accented English evaluation dataset; resolve licence, files, speakers and split.

## [S42] FLEURS dataset

https://huggingface.co/datasets/google/fleurs

Primary common read-speech test source for the nine Indic languages. en_us is not Indian English.

## [S43] IndicVoices dataset

https://huggingface.co/datasets/ai4bharat/IndicVoices

Conversational coverage candidate. Dataset size/version has changed; freeze exact release and split.

## [S44] jiwer reference scoring implementation

https://github.com/jitsi/jiwer

Production WER implementation to cross-check against independently tested golden alignments.

## [S45] ITU-T P.808 (2021)

https://www.itu.int/ITU-T/recommendations/rec.aspx?id=14665

Guidance for human speech-quality evaluation. A custom business-readiness rubric is not automatically a standards-conformant MOS.

## [S46] Sarvam model catalogue

https://docs.sarvam.ai/api/getting-started/models

Hosted reference discovery: Saaras v3 ASR and Bulbul v3 TTS; APIs are not self-hosted models.

## [S47] Deepgram model/language matrix

https://developers.deepgram.com/docs/models-languages-overview

Hosted reference discovery; freeze exact model/language/API configuration and region.

## [S48] ElevenLabs model catalogue

https://elevenlabs.io/docs/overview/models

Hosted reference discovery: ASR and TTS model IDs differ; select frozen IDs and measure rather than copy latency claims.

## [S49] Google Chirp 3 ASR

https://docs.cloud.google.com/speech-to-text/docs/models/chirp-3

Hosted ASR reference; supported locations, methods and languages must be validated.

## [S50] Google Chirp 3 HD TTS

https://docs.cloud.google.com/text-to-speech/docs/chirp3-hd

Hosted TTS reference; voice locale and streaming endpoint are separate fields.

## [S51] Azure Speech language support

https://learn.microsoft.com/en-us/azure/ai-services/speech-service/language-support

Hosted discovery reference with explicit locales and service-specific feature coverage.

## [S52] VoxCPM implementation

https://github.com/OpenBMB/VoxCPM

Implementation source for sample-rate-correct offline and generator integration.
