# On-prem streaming evaluation scope

Reviewed 24 September 2026. Candidate selection and source screening only: no model inference or human listening has been performed in this review. This document prioritizes the original 34-entry inventory; it does not silently remove entries or claim every candidate qualifies for deployment.

**User clarification:** Evaluate non-streaming configurations as well as streaming ones. All 15 ASR and 19 TTS inventory entries remain in the benchmark scope, subject to language eligibility, access and approved resources. See `FULL_EVALUATION_SCOPE.md` and `configs/evaluation_coverage.json` for full inventory accounting and reporting requirements. The shortlist below is a streaming priority list, not the complete execution list.

## Languages

The existing project scope is retained: Hindi (hi-IN), Indian English (en-IN), Bengali (bn-IN), Marathi (mr-IN), Tamil (ta-IN), Telugu (te-IN), Gujarati (gu-IN), Kannada (kn-IN), Malayalam (ml-IN), Odia (or-IN). This is a product target list, not a verified population ranking. English-language support alone does not establish Indian-English ASR accuracy or an Indian-English TTS accent.

## Prioritized candidates

Language coverage below comes from publisher descriptions, not our measurements. Each listed English path must be evaluated on en-IN data. Model revisions, voices, adapters, precision and runtime versions must be frozen before inference.

| Task | Candidate | Target-language coverage to evaluate | Streaming qualification |
| --- | --- | --- | --- |
| ASR | [SraVaani-0.5-live](https://huggingface.co/ARTPARK-IISc/SraVaani-0.5-live) | All ten | Publisher exposes stateful audio feed and finalization; compare 0/80/480/1040 ms lookahead, CPU and GPU. |
| ASR | [Qwen3-ASR 1.7B and 0.6B](https://huggingface.co/Qwen/Qwen3-ASR-1.7B) | Hindi, en-IN | Evaluate both sizes using the documented vLLM streaming path. |
| ASR | [Voxtral Mini 4B Realtime](https://huggingface.co/mistralai/Voxtral-Mini-4B-Realtime-2602) | Hindi, en-IN | Native realtime candidate; sweep transcription delay and verify actual input pacing. |
| ASR | [VibeVoice-ASR-Streaming-1.5B](https://huggingface.co/microsoft/VibeVoice-ASR-Streaming-1.5B) | en-IN | English-capable streaming challenger; its ten languages are not our ten Indian locales. |
| TTS | [Indic Parler-TTS](https://huggingface.co/ai4bharat/indic-parler-tts) | All ten | Test the upstream [ParlerTTSStreamer](https://github.com/huggingface/parler-tts/blob/main/parler_tts/streamer.py) with this exact checkpoint. Availability of a library streamer is not a latency result. |
| TTS | [Svara-TTS v1](https://huggingface.co/kenpath/svara-tts-v1) | All except Odia | Indian English is explicitly listed. Audit incremental codec decoding and CPU/GPU paths; streaming remains unverified. |
| TTS | [Qwen3-TTS 0.6B Indic adapters](https://huggingface.co/aguken-ai/Qwen3-TTS-0.6B-LoRA-Finetuned-Indic-Multilingual) | Bengali, Marathi, Tamil, Telugu, Gujarati, Kannada, Malayalam, Odia | Eight target regional languages have separate male/female adapters. Qualify each adapter/backend independently; the card's full-waveform example does not prove streaming. |
| TTS | [Qwen3-TTS 1.7B Hindi adapter](https://huggingface.co/aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned) | Hindi | Existing inventory candidate; exact adapter and streaming compatibility still need source audit and execution. Match with a base control. |
| TTS | [VoxCPM2](https://huggingface.co/openbmb/VoxCPM2) | Hindi, en-IN | Publisher supplies a streaming generator; verify first playable audio, continuous playback and accent. |
| TTS | [Pocket TTS](https://huggingface.co/kyutai/pocket-tts) | en-IN | CPU streaming control. Official language list does not cover the nine regional targets. Indian accent remains unproven. |
| TTS | [Bodhan Indic-Speak](https://huggingface.co/bodhan-ai/indic-speak) | All ten | Conditional on access/terms and producer streaming proof; resolve the model card's differing checkpoint names before loading. |
| TTS | [Voxtral 4B TTS](https://huggingface.co/mistralai/Voxtral-4B-TTS-2603) | Hindi, en-IN | Conditional research lane: card lists CC-BY-NC-4.0. Do not recommend as commercially deployable without compatible rights. |

Keep Whisper/IndicConformer and full-utterance TTS candidates as explicitly labelled quality controls where useful. Repeated offline inference or slicing a completed waveform must not be counted as native streaming. Newly discovered [DhVaani-0.5](https://huggingface.co/ARTPARK-IISc/DhVaani-0.5) covers the ten target languages but currently has no demonstrated streaming path in this review; screen it as a conditional control, with gated access and reference-voice permissions unresolved.

## Required measurements

- ASR: real-time paced 20 ms input, first nonempty/stable partial, finalization latency, WER/CER, partial revisions, silence hallucinations, endpointing, Hindi-English and regional-English code switching.
- TTS: first playable audio and first audible speech, within-segment versus completed-segment output, RTF, stalls under a fixed 200 ms playout buffer, cancellation/barge-in, chunk continuity, long-input stability. Test incremental text input separately from audio-output streaming.
- Both: clean and 8 kHz telephony conditions, cold/warm runs, concurrency 1 and 4 initially, sustained sessions, CPU/RAM/GPU/VRAM use, failure rate. Final deployment capacity requires the user's actual hardware and concurrency target.
- TTS quality: 40 prompts per eligible configuration/locale/mode/primary voice, five independent qualified human raters per successful clip, clean and telephony conditions. That is 400 ratings per configuration-language combination before repeats. Human ratings must remain absent until collected.
- On-prem acceptance: all required weights/tokenizers/codecs available locally, no hosted inference dependency, network-disabled inference test, pinned containers and reproducible deployment commands, compatible model/voice/runtime terms.

## RunPod and outstanding inputs

A configured RunPod key authenticated successfully. All four visible Pods were EXITED with runtime=null; no start/stop/create/delete was needed. See `evidence/runpod_preflight_20260924.json` for timestamp and IDs. This is a point-in-time check of Pods, not continuous monitoring or verification of all account billing. Storage was retained and can still incur charges, as documented by [RunPod](https://docs.runpod.io/pods/manage-pods).

No rented compute was started. Before a GPU pilot, define target hardware, peak concurrent sessions, approved hourly/total spend and maximum runtime. The execution harness must persist results, stop its owned Pod on normal completion and errors, use an independent shutdown watchdog, and verify the stopped state. This lifecycle controller is not implemented by the starter package.

Real evaluation data, applicable gated access, authorized voice references, native-language reviewers and a rater pool remain prerequisites. Credentials alone do not establish benchmark readiness. A RunPod result must be labelled with its actual hardware; it does not establish performance on different on-prem hardware.

## Validator amendments

Three findings from review were repaired: reject nonpositive/noninteger rater minimums; reject segment completion after generation completion and duplicate segment-end events; require failed TTS prompts to reference planned generation cells explicitly associated with the quality study through its frozen `generation_cell_ids` list.

The amended utility suite passed 62 tests on the local Python 3.14 environment. This is not a comprehensive security audit or proof of benchmark correctness. Existing `evidence/BUILD_STATUS.json` and its test log describe the original package. `evidence/SHA256SUMS.original.json` preserves the original manifest; the root manifest is refreshed for the amended files. The supplied ZIP and rendered PRD remain original artifacts, not an updated distribution of these changes.
