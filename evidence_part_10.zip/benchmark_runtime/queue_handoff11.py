"""Preserve the active IndicConformer worker before remaining streaming-language coverage, then resume the revised bounded queue."""
import datetime,json,os,pathlib,shutil,signal,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924');PARENT=10109;CHILD=10409
def command(pid):
    try:return pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
    except FileNotFoundError:return ''
if 'unified_queue.py' not in command(PARENT) or 'asr_baselines.py A04' not in command(CHILD):
    raise RuntimeError('Worker changed; no process was interrupted')
os.kill(PARENT,signal.SIGSTOP)
deadline=datetime.datetime(2026,9,24,1,15,31,tzinfo=datetime.timezone.utc).timestamp()
rec=dict(job='A04-subset',queue_handoff=True,started_utc='2026-09-24T01:07:10.933863+00:00',started_utc_precision='estimated from preceding job boundary',timeout_s=501,timed_out=False,exit_code=None)
while True:
    try:
        fields=pathlib.Path(f'/proc/{CHILD}/stat').read_text().rsplit(')',1)[1].split()
        if fields[0]=='Z':rec['exit_code']=os.waitstatus_to_exitcode(int(fields[49]));break
    except FileNotFoundError:break
    if time.time()>=deadline:
        os.killpg(CHILD,signal.SIGTERM);time.sleep(5)
        if command(CHILD):os.killpg(CHILD,signal.SIGKILL)
        rec.update(timed_out=True,exit_code=-15);break
    time.sleep(2)
try:os.killpg(CHILD,signal.SIGTERM)
except ProcessLookupError:pass
rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (ROOT/'queue_outcomes.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
os.kill(PARENT,signal.SIGTERM);os.kill(PARENT,signal.SIGCONT)
for parent in ['/tmp/asr_model_stage','/tmp/benchmark_model_stage']:
    stage=pathlib.Path(parent)/'A04'
    if stage.is_dir() and not stage.is_symlink():shutil.rmtree(stage)
with (ROOT/'unified_queue11.log').open('wb') as log:
    proc=subprocess.Popen(['python3',str(ROOT/'unified_queue.py')],env=dict(os.environ,QUEUE_START_AFTER='A04-subset'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps(dict(completed=rec,next_queue_pid=proc.pid)),flush=True)
