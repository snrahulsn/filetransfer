"""Wait for this queue to finish, then validate saved audio within the shutdown reserve."""
import datetime,pathlib,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924')
deadline=datetime.datetime(2026,9,24,1,16,0,tzinfo=datetime.timezone.utc).timestamp()
while time.time()<deadline:
    time.sleep(min(10,deadline-time.time()))
for proc in pathlib.Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        state=(proc/'stat').read_text().rsplit(')',1)[1].split()[0]
        command=(proc/'cmdline').read_bytes()
        if state!='Z' and b'/workspace/speechbench_20260924/unified_queue.py' in command:raise RuntimeError('Queue still active; defer validation rather than overlap inference')
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
subprocess.run(['/workspace/tts_streaming_suite/.venv_gpu/bin/python',str(ROOT/'validate_audio.py')],check=True,timeout=120)
