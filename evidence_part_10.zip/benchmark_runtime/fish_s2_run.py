#!/usr/bin/env python3
"""Pinned, offline Fish Audio S2 Pro synthesis benchmark for the ten target locales."""

import argparse
import hashlib
import json
import os
import platform
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from fish_speech.models.text2semantic.inference import (
    decode_to_audio,
    generate_long,
    init_model,
    load_codec_model,
)


TEXTS = {
    "hi-IN": "नमस्ते, यह भारत में चलने वाली स्थानीय वाणी प्रणाली का परीक्षण है।",
    "en-IN": "Hello, this is a test of an on premises speech system for India.",
    "bn-IN": "নমস্কার, এটি ভারতে চলা একটি স্থানীয় কণ্ঠস্বর ব্যবস্থার পরীক্ষা।",
    "mr-IN": "नमस्कार, ही भारतात चालणाऱ्या स्थानिक वाणी प्रणालीची चाचणी आहे.",
    "ta-IN": "வணக்கம், இது இந்தியாவில் இயங்கும் உள்ளூர் குரல் அமைப்பின் சோதனை.",
    "te-IN": "నమస్కారం, ఇది భారతదేశంలో నడిచే స్థానిక వాక్య వ్యవస్థ పరీక్ష.",
    "gu-IN": "નમસ્તે, આ ભારતમાં ચાલતી સ્થાનિક વાણી પ્રણાલીનું પરીક્ષણ છે.",
    "kn-IN": "ನಮಸ್ಕಾರ, ಇದು ಭಾರತದಲ್ಲಿ ನಡೆಯುವ ಸ್ಥಳೀಯ ಧ್ವನಿ ವ್ಯವಸ್ಥೆಯ ಪರೀಕ್ಷೆ.",
    "ml-IN": "നമസ്കാരം, ഇത് ഇന്ത്യയിൽ പ്രവർത്തിക്കുന്ന പ്രാദേശിക ശബ്ദ സംവിധാനത്തിന്റെ പരീക്ഷണമാണ്.",
    "or-IN": "ନମସ୍କାର, ଏହା ଭାରତରେ ଚାଲୁଥିବା ସ୍ଥାନୀୟ କଣ୍ଠ ବ୍ୟବସ୍ଥାର ପରୀକ୍ଷା।",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--source-dir", type=Path, required=True)
    p.add_argument("--revision", required=True)
    args = p.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    precision = torch.float16
    t0 = time.perf_counter()
    model, decode_one_token = init_model(args.checkpoint, "cuda", precision, compile=False)
    with torch.device("cuda"):
        model.setup_caches(
            max_batch_size=1,
            max_seq_len=model.config.max_seq_len,
            dtype=next(model.parameters()).dtype,
        )
    torch.cuda.synchronize()
    codec = load_codec_model(args.checkpoint / "codec.pth", "cuda", precision)
    torch.cuda.synchronize()
    init_s = time.perf_counter() - t0

    results = []
    for i, (locale, text) in enumerate(TEXTS.items()):
        torch.manual_seed(42 + i)
        torch.cuda.manual_seed(42 + i)
        started = time.perf_counter()
        codes = []
        for response in generate_long(
            model=model,
            device="cuda",
            decode_one_token=decode_one_token,
            text=text,
            num_samples=1,
            max_new_tokens=512,
            top_p=0.7,
            top_k=30,
            temperature=0.7,
            compile=False,
            iterative_prompt=True,
            chunk_length=300,
            prompt_text=None,
            prompt_tokens=None,
        ):
            if response.action == "sample":
                codes.append(response.codes)
        merged = torch.cat(codes, dim=1)
        audio = decode_to_audio(merged.to("cuda"), codec)
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        wav = args.output_dir / f"{locale}.wav"
        samples = audio.detach().cpu().float().numpy().reshape(-1)
        sf.write(wav, samples, codec.sample_rate)
        duration = len(samples) / codec.sample_rate
        row = {
            "run_id": run_id,
            "model_id": "T16",
            "model": "fishaudio/s2-pro",
            "revision": args.revision,
            "locale": locale,
            "text": text,
            "output": wav.name,
            "output_sha256": sha256(wav),
            "audio_duration_s": duration,
            "synthesis_s": elapsed,
            "rtf": elapsed / duration,
            "sample_rate": codec.sample_rate,
            "semantic_tokens": int(merged.shape[-1]),
            "mode": "full_output",
            "synthesis_class": "C",
        }
        results.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)

    source_revision = subprocess.check_output(
        ["git", "-C", str(args.source_dir), "rev-parse", "HEAD"], text=True
    ).strip()
    environment = {
        "run_id": run_id,
        "model_id": "T16",
        "model": "fishaudio/s2-pro",
        "revision": args.revision,
        "source_repo": "https://github.com/fishaudio/fish-speech",
        "source_revision": source_revision,
        "runner_sha256": sha256(Path(__file__)),
        "checkpoint_files": {
            p.name: sha256(p)
            for p in sorted(args.checkpoint.iterdir())
            if p.is_file() and (p.suffix in {".json", ".jinja", ".pth"} or "safetensors" in p.name)
        },
        "model_initialization_s": init_s,
        "torch": torch.__version__,
        "python": platform.python_version(),
        "gpu": torch.cuda.get_device_name(0),
        "precision": "float16",
        "mode": "full_output",
        "synthesis_class": "C",
        "hf_offline": os.environ.get("HF_HUB_OFFLINE") == "1",
        "network_namespace_isolated": False,
        "evaluated_locales": list(TEXTS),
    }
    (args.output_dir / f"environment-{run_id}.json").write_text(
        json.dumps(environment, ensure_ascii=False, indent=2) + "\n"
    )
    with (args.output_dir / f"results-{run_id}.jsonl").open("w") as f:
        for row in results:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
