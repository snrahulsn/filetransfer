"""Download pinned public test assets without executing dataset repository code."""
import concurrent.futures, hashlib, json, os, pathlib, re, urllib.request

ROOT=pathlib.Path('/workspace/speechbench_20260924')
OUT=pathlib.Path(os.environ.get('DATA_ROOT',str(ROOT/'datasets'))); OUT.mkdir(parents=True,exist_ok=True)
token_file=pathlib.Path('/workspace/.hf_token_env')
TOKEN=(re.search(r'hf_[A-Za-z0-9]+',token_file.read_text()).group()
       if token_file.exists() else None)
FREV='70bb2e84b976b7e960aa89f1c648e09c59f894dd'
SREV='ebbf7777fe771490696a3f7b007097606fa8c924'

def download(job):
    repo,rev,file=job
    dst=OUT/repo.replace('/','--')/file; dst.parent.mkdir(parents=True,exist_ok=True)
    url=f'https://huggingface.co/datasets/{repo}/resolve/{rev}/{file}'
    rec=dict(repo=repo,revision=rev,file=file,url=url)
    try:
        headers={'User-Agent':'speechbench/1.0'}
        if TOKEN:headers['Authorization']='Bearer '+TOKEN
        req=urllib.request.Request(url,headers=headers)
        if not dst.exists():
            with urllib.request.urlopen(req,timeout=180) as src,open(str(dst)+'.part','wb') as out:
                while chunk:=src.read(4*1024*1024):out.write(chunk)
            os.replace(str(dst)+'.part',dst)
        h=hashlib.sha256()
        with dst.open('rb') as f:
            while chunk:=f.read(4*1024*1024):h.update(chunk)
        rec.update(status='downloaded',bytes=dst.stat().st_size,sha256=h.hexdigest())
    except Exception as e:rec.update(status='failed',error_type=type(e).__name__,http_status=getattr(e,'code',None))
    (dst.parent/(dst.name+'.provenance.json')).write_text(json.dumps(rec,indent=2))
    print(json.dumps(rec),flush=True)
    return rec

if __name__=='__main__':
    jobs=[('google/fleurs',FREV,f'parquet-data/{lang}_in/test-00000-of-00001.parquet') for lang in ['hi','bn','mr','ta','te','gu','kn','ml','or']]
    jobs += [('ai4bharat/Svarah',SREV,f'data/test-{i:05d}-of-00003.parquet') for i in range(3)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(download,jobs))
    (OUT/'download_manifest.json').write_text(json.dumps(results,indent=2))
