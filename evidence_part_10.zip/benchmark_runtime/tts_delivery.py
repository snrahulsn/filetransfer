"""Idealized playback simulation from measured chunk arrivals; no network/device model."""
import json,math
def diagnose(record):
    events=record.get('chunk_events',record.get('events',[]));sr=record['sample_rate']
    if not math.isfinite(sr) or sr<=0:raise ValueError('Invalid sample rate')
    events=[e for e in events if e['samples']>0]
    if not events:return None
    cursor=events[0]['at_s'];start=cursor;duration=0;stalls=[];previous=-1;required_start=0
    for event in events:
        at=event['at_s'];samples=event['samples']
        if not math.isfinite(at) or at<previous or at<0:raise ValueError('Invalid chunk ordering')
        previous=at;required_start=max(required_start,at-duration)
        if at>cursor+1e-9:stalls.append(at-cursor)
        cursor=max(cursor,at)+samples/sr;duration+=samples/sr
    if abs(duration-record['audio_duration_s'])>1/sr+1e-8:raise ValueError('Chunk samples differ from saved audio duration')
    return dict(first_audio_s=start,chunk_count=len(events),simulated_stall_count=len(stalls),simulated_stall_total_s=sum(stalls),
                simulated_largest_stall_s=max(stalls,default=0),minimum_stall_free_start_s=required_start,
                additional_initial_buffer_s=required_start-start,audio_duration_s=duration)
def rows(root):
    result=[]
    for file in sorted(root.glob('T*/records.jsonl')):
        for line in file.read_text().splitlines():
            r=json.loads(line)
            if not r.get('ok') or r.get('phase')!='smoke' or 'stream' not in r.get('mode','') or not (r.get('chunk_events') or r.get('events')):continue
            result.append(dict(model_id=file.parent.name,locale=r['locale'],mode=r['mode'],run_id=r.get('run_id'),**diagnose(r)))
    return result
