"""Pinned full-utterance evaluation for Meta OmniASR CTC checkpoints."""
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import pathlib
import resource
import time
import traceback

import torch

from asr_corpus import records
from metrics import score

ROOT = pathlib.Path("/workspace/speechbench_20260924")
MODELS = {
    "A05": ("omniASR_CTC_1B_local", "facebook/omniASR-CTC-1B"),
    "A06": ("omniASR_CTC_300M_local", "facebook/omniASR-CTC-300M"),
}
LANG = {
    "hi-IN": "hin_Deva", "en-IN": "eng_Latn", "bn-IN": "ben_Beng",
    "mr-IN": "mar_Deva", "ta-IN": "tam_Taml", "te-IN": "tel_Telu",
    "gu-IN": "guj_Gujr", "kn-IN": "kan_Knda", "ml-IN": "mal_Mlym",
    "or-IN": "ory_Orya",
}


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def main(model_id: str, limit: int) -> None:
    from omnilingual_asr.models.inference.pipeline import ASRInferencePipeline

    card, repo = MODELS[model_id]
    download = json.loads((ROOT / f"{model_id}_download.json").read_text())
    checkpoint = next(pathlib.Path(download["path"]).glob("*.pt"))
    output = ROOT / model_id
    output.mkdir(exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    started = time.perf_counter()
    pipeline = ASRInferencePipeline(card, device="cuda", dtype=torch.bfloat16)
    initialized = time.perf_counter() - started
    environment = {
        "run_id": stamp,
        "model": repo,
        "revision": download["revision"],
        "model_card": card,
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256(checkpoint),
        "runner_sha256": sha256(pathlib.Path(__file__)),
        "mode": "full_utterance",
        "precision": "bfloat16",
        "torch": torch.__version__,
        "torchaudio": importlib.metadata.version("torchaudio"),
        "omnilingual_asr": importlib.metadata.version("omnilingual-asr"),
        "fairseq2": importlib.metadata.version("fairseq2"),
        "gpu": torch.cuda.get_device_name(0),
        "model_initialization_s": initialized,
        "evaluation_limit_per_locale": limit,
        "network_namespace_isolated": False,
        "checkpoint_loaded_from_pinned_local_file": True,
    }
    (output / f"environment-{stamp}.json").write_text(json.dumps(environment, indent=2))

    def infer(audio, locale):
        item = {"waveform": audio, "sample_rate": 16000}
        return pipeline.transcribe([item], lang=[LANG[locale]], batch_size=1)[0]

    first = next(records(["hi-IN"], limit=1))
    for _ in range(3):
        with torch.inference_mode():
            infer(first["audio"], "hi-IN")

    record_file = output / "file_records.jsonl"
    for locale in LANG:
        for row in records([locale], limit=limit):
            record = {key: value for key, value in row.items() if key != "audio"}
            record.update(run_id=stamp, phase="coverage_sweep", mode="full_utterance", ok=False)
            try:
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                start = time.perf_counter()
                with torch.inference_mode():
                    hypothesis = infer(row["audio"], locale)
                torch.cuda.synchronize()
                elapsed = time.perf_counter() - start
                duration = len(row["audio"]) / 16000
                record.update(
                    ok=True,
                    hypothesis=hypothesis,
                    total_s=elapsed,
                    audio_duration_s=duration,
                    rtf=elapsed / duration,
                    peak_torch_allocated_bytes=torch.cuda.max_memory_allocated(),
                    peak_torch_reserved_bytes=torch.cuda.max_memory_reserved(),
                    process_lifetime_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                    **score(row["reference"], hypothesis),
                )
            except Exception as error:
                record.update(
                    hypothesis="",
                    error_type=type(error).__name__,
                    error=str(error),
                    traceback=traceback.format_exc(),
                    **score(row["reference"], ""),
                )
            with record_file.open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(json.dumps({key: record.get(key) for key in ("id", "ok", "wer", "rtf", "error")}), flush=True)
    (output / f"DONE-{stamp}").write_text(json.dumps({"model": model_id, "limit": limit}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=MODELS)
    parser.add_argument("--limit", type=int, default=3)
    args = parser.parse_args()
    main(args.model, args.limit)
