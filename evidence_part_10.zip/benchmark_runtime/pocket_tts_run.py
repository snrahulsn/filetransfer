"""Pinned Pocket TTS native-stream benchmark for the English target."""
import os
os.environ.update(HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",HF_HOME="/workspace/hf_cache",HF_HUB_CACHE="/workspace/hf_cache/hub")
import datetime,hashlib,json,pathlib,time,traceback
import numpy as np,soundfile as sf,torch
from pocket_tts import TTSModel
from snac_run import TEXTS
ROOT=pathlib.Path("/workspace/speechbench_20260924");PIN="d0ebc5deb50bc6b225f686782f124dd37e2dca0a"
def digest(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        while b:=f.read(8388608):h.update(b)
    return h.hexdigest()
def main():
    d=json.loads((ROOT/"T02_download.json").read_text());path=pathlib.Path(d["path"])
    if d.get("status")!="downloaded" or d.get("revision")!=PIN:raise RuntimeError("invalid T02 pinned download")
    # The package resolves named configs through hf://main; bind that ref to the audited pin for offline use.
    repo_cache=path.parents[1];refs=repo_cache/"refs";refs.mkdir(exist_ok=True);(refs/"main").write_text(PIN)
    model=TTSModel.load_model(language="english")
    voice=model.get_state_for_audio_prompt("alba")
    out=ROOT/"T02";out.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    (out/f"environment-{stamp}.json").write_text(json.dumps(dict(run_id=stamp,model="kyutai/pocket-tts",revision=PIN,package="pocket-tts==3.2.0",runner_sha256=digest(__file__),torch=torch.__version__,hardware="CPU",precision="float32",mode="native_stream",synthesis_class="A",hf_offline=True,network_namespace_isolated=False,english_accent_verified=False),indent=2))
    text=next(x[2] for x in TEXTS if x[0]=="en-IN")
    for i,phase in enumerate(["warmup"]*3+["smoke"]):
        rec=dict(run_id=stamp,phase=phase,index=i,locale="en-IN",text=text,voice="alba",mode="native_stream",synthesis_class="A",ok=False,english_accent_verified=False)
        try:
            torch.manual_seed(20260924);start=time.perf_counter();chunks=[];events=[]
            for chunk in model.generate_audio_stream(voice,text):
                audio=np.asarray(chunk.detach().float().cpu(),dtype=np.float32).reshape(-1)
                if len(audio):chunks.append(audio);events.append(dict(at_s=time.perf_counter()-start,samples=len(audio)))
            elapsed=time.perf_counter()-start
            if not chunks:raise ValueError("stream emitted no audio")
            audio=np.concatenate(chunks);sr=model.sample_rate
            if not np.isfinite(audio).all():raise ValueError("non-finite waveform")
            duration=len(audio)/sr;rec.update(ok=True,sample_rate=sr,ttfa_s=events[0]["at_s"],total_s=elapsed,audio_duration_s=duration,rtf=elapsed/duration,chunk_events=events,audio_before_generation_end=len(events)>1)
            if phase=="smoke":
                file=out/f"{stamp}-en-IN.flac";sf.write(file,audio,sr,subtype="PCM_24");rec.update(file=str(file.relative_to(ROOT)),sha256=digest(file))
        except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (out/"records.jsonl").open("a",encoding="utf-8") as f:f.write(json.dumps(rec,ensure_ascii=False)+"\n")
        print(json.dumps({k:rec.get(k) for k in ["phase","ok","ttfa_s","rtf","error"]}),flush=True)
        if not rec["ok"]:break
    (out/"DONE").write_text("Pinned native-stream English smoke benchmark attempted.\n")
if __name__=="__main__":main()
