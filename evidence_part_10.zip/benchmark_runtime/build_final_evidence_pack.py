"""Create independently verifiable ZIP parts, each below 20 MB."""
from __future__ import annotations
import hashlib, json, pathlib, shutil, zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/"SHARE_EVIDENCE_PACK_FINAL"
LIMIT=19_000_000

def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def collect():
    files=[]
    direct=[ROOT/"BENCHMARK_REPORT.html",ROOT/"BENCHMARK_REPORT.pdf",ROOT/"Makefile",ROOT/"GIT_SETUP.md",
            ROOT/"README.md",ROOT/"COMPLETION_AUDIT.md",
            ROOT/"execution/final_shutdown_verification.json",ROOT/"execution/metadata_corrections.json",
            ROOT/"execution/FINAL_STATUS.json",ROOT/"execution/final_report_validation.json",
            ROOT/"execution/final_local_data_audit.json",ROOT/"execution/primary_configuration_ledger.json",
            ROOT/"execution/asr_frozen_plan.json",ROOT/"execution/language_coverage.json",
            ROOT/"execution/evidence_integrity.json",ROOT/"execution/runner_provenance.json"]
    roots=[ROOT/"LISTENING_REVIEW",ROOT/"execution/fresh_current",ROOT/"execution/sources",
           ROOT/"execution/dataset_sources",ROOT/"execution/metrics_current",
           ROOT/"execution/runner_sources",ROOT/"execution/retained_code",
           ROOT/"indic_speech_benchmark_prd_v1",ROOT/"benchmark_runtime",ROOT/"handoff_tools"]
    for p in direct:
        if p.is_file(): files.append(p)
    for base in roots:
        if not base.exists(): continue
        for p in base.rglob("*"):
            if not p.is_file() or "__pycache__" in p.parts: continue
            if "grok" in p.name.lower(): continue
            files.append(p)
    files.extend(sorted((ROOT/"execution").glob("lease-*.json")))
    return sorted(set(files))

def main():
    shutil.rmtree(OUT,ignore_errors=True); OUT.mkdir()
    rows=[]; parts=[]; current=[]; current_size=0
    for p in sorted(collect(),key=lambda x:x.stat().st_size,reverse=True):
        n=p.stat().st_size
        if n>=LIMIT: raise SystemExit(f"single file too large: {p} ({n})")
        if current and current_size+n>17_500_000: parts.append(current);current=[];current_size=0
        current.append(p);current_size+=n
    if current: parts.append(current)
    for i,group in enumerate(parts,1):
        name=f"evidence_part_{i:02d}.zip"; target=OUT/name
        with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED,compresslevel=6,strict_timestamps=False) as z:
            for p in group:
                rel=p.relative_to(ROOT).as_posix();z.write(p,rel)
                rows.append({"path":rel,"bytes":p.stat().st_size,"sha256":sha(p),"part":name})
        if target.stat().st_size>=20_000_000: raise SystemExit(f"part exceeds 20MB: {target}")
    (OUT/"SCRIPTS").mkdir()
    direct_files=[]
    copies=((ROOT/"handoff_tools/START_HERE.md",OUT/"README.md"),
            (ROOT/"handoff_tools/assemble_verify.py",OUT/"SCRIPTS/assemble_verify.py"),
            (ROOT/"handoff_tools/run_blind_test.py",OUT/"SCRIPTS/run_blind_test.py"))
    for source,target in copies:
        shutil.copy2(source,target)
        direct_files.append({"path":target.relative_to(OUT).as_posix(),"bytes":target.stat().st_size,"sha256":sha(target)})
    manifest={"schema_version":2,"grok_reviews_included":False,"files":sorted(rows,key=lambda r:r["path"]),
              "parts":[{"name":p.name,"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(OUT.glob("*.zip"))],
              "direct_files":direct_files}
    (OUT/"MASTER_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps({"parts":len(parts),"files":len(rows),"largest_part_bytes":max(p.stat().st_size for p in OUT.glob('*.zip'))},indent=2))

if __name__=="__main__": main()
