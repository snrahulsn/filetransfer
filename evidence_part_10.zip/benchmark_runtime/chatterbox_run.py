"""Pinned full-output Chatterbox multilingual and Hindi-pack smoke benchmark."""
import os
os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HOME="/workspace/hf_cache")
import argparse, datetime, hashlib, inspect, json, pathlib, sys, time, traceback
import numpy as np
import soundfile as sf
import torch
from safetensors.torch import load_file

TEXTS = [
    ("en-IN", "English", "Your meeting with Priya is tomorrow at three thirty PM."),
    ("hi-IN", "Hindi", "आपकी बैठक कल दोपहर तीन बजे है।"),
]

ROOT = pathlib.Path("/workspace/speechbench_20260924")
PINS = {"T13": "5bb1f6ee58e50c3b8d408bc82a6d3740c2db6e18", "T14": "82ca71273cc2a9ab19efdf8315f865c1a5af0ee7"}

def digest(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        while b:=f.read(8388608): h.update(b)
    return h.hexdigest()

def path_for(mid):
    d=json.loads((ROOT/f"{mid}_download.json").read_text())
    if d.get("status")!="downloaded" or d.get("revision")!=PINS[mid]: raise RuntimeError(f"invalid {mid} pinned download")
    return pathlib.Path(d["path"])

def main(mid):
    if mid=="T14":
        runtime=json.loads((ROOT/"T14-runtime_download.json").read_text())
        if runtime.get("status")!="downloaded": raise RuntimeError("pinned T14 publisher Space runtime is missing")
        sys.path.insert(0,str(pathlib.Path(runtime["path"])/"chatterbox"/"src"))
        from chatterbox.tts import ChatterboxTTS
        pack=path_for("T14");repo_cache=pack.parents[1];refs=repo_cache/"refs";refs.mkdir(exist_ok=True);(refs/"main").write_text(PINS["T14"])
        base=path_for("T13");base_refs=base.parents[1]/"refs";base_refs.mkdir(exist_ok=True);(base_refs/"main").write_text(PINS["T13"])
        model=ChatterboxTTS.from_pretrained("cuda"); repo="ResembleAI/Chatterbox-Multilingual-hi"; revision=PINS["T14"]
        runtime_revision=pathlib.Path(runtime["path"]).name
        items=[x for x in TEXTS if x[0]=="hi-IN"]
    else:
        model,repo,revision,items=load_general()

    run(model,repo,revision,items,mid,locals().get("runtime_revision"))

def load_general():
    import chatterbox.mtl_tts as mtl
    base=path_for("T13"); mtl.snapshot_download=lambda **_: str(base)
    loader=mtl.ChatterboxMultilingualTTS.from_pretrained
    supports_v3="t3_model" in inspect.signature(loader).parameters
    model=loader(device="cuda",**({"t3_model":"v3"} if supports_v3 else {}))
    repo="ResembleAI/chatterbox"; revision=PINS["T13"]
    items=[x for x in TEXTS if x[0] in {"en-IN","hi-IN"}]
    return model,repo,revision,items

def run(model,repo,revision,items,mid,runtime_revision=None):
    out=ROOT/mid;out.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    env=dict(run_id=stamp,model=repo,revision=revision,base_revision=PINS["T13"],publisher_runtime_revision=runtime_revision,runner_sha256=digest(__file__),torch=torch.__version__,gpu=torch.cuda.get_device_name(0),precision="float32",mode="full_output",synthesis_class="C",hf_offline=True,network_namespace_isolated=False)
    (out/f"environment-{stamp}.json").write_text(json.dumps(env,indent=2))
    for index,(phase,(locale,_,text)) in enumerate([("warmup",items[0])]*3+[("smoke",x) for x in items]):
        rec=dict(run_id=stamp,phase=phase,index=index,locale=locale,text=text,language_id=locale[:2],mode="full",synthesis_class="C",voice="publisher built-in condition",ok=False)
        try:
            torch.manual_seed(20260924);torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter()
            kwargs={"language_id":locale[:2]}
            if mid=="T14":
                ref_record=json.loads((ROOT/"T12-ref_download.json").read_text());kwargs["audio_prompt_path"]=str(pathlib.Path(ref_record["path"])/"adapters/hindi_female/ref.wav")
            with torch.inference_mode(): audio=model.generate(text,**kwargs)
            torch.cuda.synchronize();elapsed=time.perf_counter()-start;audio=np.asarray(audio.detach().float().cpu()).reshape(-1)
            if not len(audio) or not np.isfinite(audio).all(): raise ValueError("empty or invalid waveform")
            dur=len(audio)/model.sr;rec.update(ok=True,sample_rate=model.sr,total_s=elapsed,ttfa_s=elapsed,audio_duration_s=dur,rtf=elapsed/dur,peak_memory_bytes=torch.cuda.max_memory_allocated())
            if phase=="smoke":
                file=out/f"{stamp}-{locale}.flac";sf.write(file,audio,model.sr,subtype="PCM_24");rec.update(file=str(file.relative_to(ROOT)),sha256=digest(file))
        except Exception as e: rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (out/"records.jsonl").open("a",encoding="utf-8") as f:f.write(json.dumps(rec,ensure_ascii=False)+"\n")
        print(json.dumps({k:rec.get(k) for k in ["locale","phase","ok","rtf","error"]},ensure_ascii=False),flush=True)
        if not rec["ok"]: break
    (out/"DONE").write_text("Pinned full-output smoke benchmark attempted.\n")

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("model",choices=["T13","T14"]);main(p.parse_args().model)
