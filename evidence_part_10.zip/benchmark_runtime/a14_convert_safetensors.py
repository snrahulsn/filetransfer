"""Convert pinned legacy IndicWhisper weight archives to safe tensors."""
import argparse
import json
import pathlib

import torch
from safetensors.torch import save_file

ROOT = pathlib.Path("/workspace/speechbench_20260924")


def checkpoint(locale: str) -> pathlib.Path:
    assets = json.loads((ROOT / "A14_download.json").read_text())
    asset = next(item for item in assets if item["locale"] == locale)
    paths = [pathlib.Path(path) for path in asset["model_directories"]]
    matches = [path for path in paths if "whisper-medium" in str(path).lower() and "alldata" in str(path).lower()]
    if len(matches) != 1:
        raise RuntimeError(f"no unique medium all-data checkpoint for {locale}: {paths}")
    return matches[0]


def main(locale: str) -> None:
    folder = checkpoint(locale)
    source = folder / "pytorch_model.bin"
    target = folder / "model.safetensors"
    state = torch.load(source, map_location="cpu", weights_only=True, mmap=True)
    seen = {}
    safe = {}
    for name, tensor in state.items():
        if not isinstance(tensor, torch.Tensor):
            continue
        identity = (tensor.untyped_storage().data_ptr(), tensor.storage_offset(), tuple(tensor.shape), tuple(tensor.stride()))
        safe[name] = tensor.clone() if identity in seen else tensor.contiguous()
        seen[identity] = name
    save_file(safe, target, metadata={"format": "pt", "source": source.name})
    print(json.dumps({"locale": locale, "source": str(source), "target": str(target), "tensors": len(safe), "bytes": target.stat().st_size}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("locale")
    main(parser.parse_args().locale)
