"""Generate the readable four-section ASR/TTS benchmark report."""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import html
import json
import pathlib
import statistics
from typing import Any
from urllib.parse import quote

import one_page_report as core


LANGUAGES = core.LANGUAGES
DISPLAY_NAMES = {
    "A01": "SraVaani 0.5 Live", "A02": "Voxtral Mini 4B Realtime", "A03": "SraVaani 1.0",
    "A04": "IndicConformer 600M", "A05": "OmniASR CTC 1B", "A06": "OmniASR CTC 300M",
    "A07": "Qwen3-ASR 1.7B", "A08": "Whisper large-v3-turbo", "A09": "Qwen3-ASR 0.6B",
    "A10": "Whisper large-v3", "A11": "Shrutam-2", "A12": "VibeVoice-ASR",
    "A13": "VibeVoice Streaming 1.5B", "A14": "IndicWhisper — language checkpoints", "A15": "MMS ASR 1B All",
    "T01": "Svara-TTS", "T02": "Pocket TTS — language checkpoints", "T03": "Kokoro 82M", "T04": "Indic Parler-TTS",
    "T05": "Maya1", "T06": "Bodhan Indic-Speak", "T07": "Veena", "T08": "IndicF5",
    "T09": "Sooktam-2", "T10": "Voxtral TTS", "T11": "Qwen3-TTS Hindi adapter",
    "T12": "Qwen3-TTS Base", "T13": "Chatterbox", "T14": "Chatterbox Hindi",
    "T15": "VoxCPM2", "T16": "Fish S2 Pro", "T17": "XTTS-v2",
    "T18": "MMS-TTS — language checkpoints", "T19": "Qwen3-TTS Indic adapters",
}

# Chosen without consulting quality outcomes: maintained streaming implementation where it was executed,
# otherwise full utterance. Explicit pending entries require the publisher path named in the review brief.
ASR_STREAM_PRIMARY = {"A01", "A02", "A07", "A09", "A13"}
CPU_PUBLISHER_SUPPORTED = {"A01", "A03", "A04", "A08", "A10", "A11", "A15", "T01", "T02", "T03", "T04"}
GPU_PUBLISHER_SUPPORTED = {"T02"}
TTS_POLICY = {
    "T01": ("Yes", "native_stream", "Publisher streaming endpoint; chunked audio response"),
    "T02": ("Yes", "native_stream", "Native streaming with pinned per-language checkpoints"),
    "T03": ("Yes", "completed_segment_stream", "Completed segments played while later segments were generated"),
    "T04": ("Yes", "stream", "Audio arrived before generation completed"),
    "T05": ("Yes", "native_stream", "Publisher vllm_streaming_inference.py; overlap verified"),
    "T06": ("No", "full", "Full-output implementation"),
    "T07": ("No", "full", "Full-output implementation"),
    "T08": ("No", "full", "Full-output implementation"),
    "T09": ("No", "full", "Full-output implementation"),
    "T10": ("Yes", "native_stream", "Audio arrived before generation completed"),
    "T11": ("Yes", "native_stream", "SGLang progressive streaming with the Hindi LoRA merged at publisher scale 0.35"),
    "T12": ("Yes", "native_stream", "Current vLLM-Omni Base streaming path; overlap verified"),
    "T13": ("No", "full", "Full-output implementation"),
    "T14": ("No", "full", "Full-output Hindi adapter"),
    "T15": ("Yes", "stream", "Audio arrived before generation completed"),
    "T16": ("Yes", "native_stream", "Released SGLang-Omni streaming endpoint; overlap verified"),
    "T17": ("Yes", "native_stream", "Publisher inference_stream(...); overlap verified"),
    "T18": ("No", "full", "Language-specific full-output checkpoints"),
    "T19": ("Yes", "native_stream", "SGLang progressive streaming with each language LoRA merged at publisher scale 0.35"),
}

SUPPORTED_OVERRIDE = {
    "A04": {"hi", "bn", "mr", "ta", "te", "gu", "kn", "ml", "or"},
    "A14": {"hi", "bn", "mr", "ta", "te", "gu", "kn", "ml", "or"},
    "T02": {"hi", "en", "ta", "te"},
    "T17": {"hi", "en"},
    "T18": {"hi", "bn", "mr", "ta", "te", "gu", "kn", "ml", "or"},
}


def read_json(path: pathlib.Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def record_file_summary(path: pathlib.Path) -> dict[str, Any]:
    """Summarize preserved JSONL without mutating or silently accepting bad lines."""
    rows = []
    invalid_lines = []
    for line_number, line in enumerate(path.read_text(errors="replace").splitlines(), 1):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            invalid_lines.append(line_number)
    return {
        "file": path,
        "rows": len(rows),
        "modes": sorted({str(row.get("mode")) for row in rows}),
        "invalid_lines": invalid_lines,
    }


def href(path: pathlib.Path, output: pathlib.Path) -> str:
    return quote(path.resolve().relative_to(output.parent.resolve()).as_posix())


def median(values: list[float]) -> float | None:
    return statistics.median(values) if values else None


def is_supported(item: dict[str, Any], locale: str) -> bool | None:
    language = locale.split("-", 1)[0].lower()
    override = SUPPORTED_OVERRIDE.get(str(item["model_id"]))
    if override is not None:
        return language in override
    declared = item.get("declared_languages")
    if isinstance(declared, list):
        return language in {str(value).lower() for value in declared}
    return None


def runner_path(root: pathlib.Path, model_id: str, model_dir: pathlib.Path) -> pathlib.Path | None:
    return core.resolve_runner(root / "execution/fresh_current", model_dir, root / "benchmark_runtime", core.RUNNERS.get(model_id))


def environment_path(model_dir: pathlib.Path) -> pathlib.Path | None:
    return core.newest_environment(model_dir)


def selected_asr(root: pathlib.Path, model_id: str) -> tuple[pathlib.Path | None, list[dict[str, Any]], str, str]:
    model_dir = root / "execution/fresh_current" / model_id
    frozen = model_dir / "frozen_records.jsonl"
    if model_id in ASR_STREAM_PRIMARY:
        path = frozen if frozen.is_file() else model_dir / "stream_records.jsonl"
        return path if path.is_file() else None, core.valid_rows(core.read_jsonl(path)), "Yes", "maintained streaming implementation"
    path = frozen if frozen.is_file() else model_dir / "file_records.jsonl"
    return path if path.is_file() else None, core.valid_rows(core.read_jsonl(path)), "No", "full-utterance implementation"


def selected_tts(root: pathlib.Path, model_id: str) -> tuple[pathlib.Path | None, list[dict[str, Any]], str, str, str | None]:
    model_dir = root / "execution/fresh_current" / model_id
    records = model_dir / "records.jsonl"
    stream, mode, reason = TTS_POLICY[model_id]
    if mode is None or not records.is_file():
        return records if records.is_file() else None, [], stream, reason, mode
    raw = core.read_jsonl(records)
    smoke = [row for row in raw if row.get("phase") == "smoke"]
    rows = core.valid_rows(smoke or raw)
    rows = [row for row in rows if str(row.get("mode", "")) == mode]
    return records, rows, stream, reason, mode


def quality_maps(path: pathlib.Path, grok_path: pathlib.Path) -> tuple[dict, dict]:
    owner = collections.defaultdict(list)
    owner_data = read_json(path, {}) or {}
    for row in owner_data.get("rows", []):
        score = (row.get("ratings") or {}).get("Overall")
        if type(score) is int and 1 <= score <= 5:
            owner[(row.get("model_id"), row.get("locale"), row.get("mode"))].append(score)
    grok = collections.defaultdict(list)
    grok_data = read_json(grok_path, {}) or {}
    for row in grok_data.get("rows", []):
        grok[(row.get("model_id"), row.get("locale"), row.get("mode"))].append(row)
    return owner, grok


def compact_findings(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "clip_id": row.get("id"), "score": row.get("overall_score"), "correct": row.get("correct"),
            "reason": row.get("score_reason"), "heard": row.get("heard_text"),
            "mispronunciations": row.get("mispronunciations", []), "naturalness": row.get("naturalness_issues", []),
            "confidence": row.get("confidence"),
        }
        for row in rows
    ]


def status_cell(label: str, kind: str, title: str = "") -> str:
    return f'<span class="status {kind}" title="{html.escape(title)}">{html.escape(label)}</span>'


def asr_table(root: pathlib.Path, inventory: list[dict], output: pathlib.Path, details: dict) -> str:
    rows_html = []
    for item in [row for row in inventory if str(row["model_id"]).startswith("A")]:
        model_id = str(item["model_id"]);records, rows, streaming, config = selected_asr(root, model_id)
        cells = []
        for locale, _ in LANGUAGES:
            locale_rows = [row for row in rows if row.get("locale") == locale]
            metric = core.micro_wer(locale_rows)
            if metric:
                value, count = metric;percent = value * 100
                key = f"asr:{model_id}:{locale}"
                details[key] = {"title": f"{DISPLAY_NAMES[model_id]} · {locale}", "kind": "ASR diagnostic", "wer": percent, "trials": count, "records": href(records, output) if records else None, "configuration": config}
                cells.append(f'<button class="score wer" style="--value:{min(percent,100):.1f}" data-detail="{key}">{percent:.1f}%</button>')
            else:
                supported = is_supported(item, locale)
                if supported is False: cells.append(status_cell("N/S", "unsupported", "Publisher does not declare this language"))
                elif locale_rows: cells.append(status_cell("Failed", "failed", "All attempted trials failed"))
                else: cells.append(status_cell("Not tested", "untested", "No result for the selected primary configuration"))
        model_key = f"model:{model_id}"
        columns = [f'<button class="model-name" data-detail="{model_key}"><span>{model_id}</span>{html.escape(DISPLAY_NAMES[model_id])}</button>', f'<span class="stream {streaming.lower()}">{streaming}</span>', *cells]
        rows_html.append("<tr>" + "".join(f"<td>{cell}</td>" for cell in columns) + "</tr>")
    return comparison_section("asr", "ASR comparison", "Frozen micro-WER · lower is better", "Each measured cell uses the shared frozen manifest with 10 clips for that locale. Click a score for the exact count and raw record; missing states distinguish N/S from Not tested.", rows_html)


def blind_lookup(root: pathlib.Path) -> dict[tuple[str, str, str], list[dict]]:
    result = collections.defaultdict(list)
    for row in read_json(root / "LISTENING_REVIEW/blind_key.json", []) or []:
        result[(row.get("model_id"), row.get("locale"), row.get("mode"))].append(row)
    return result


def tts_table(root: pathlib.Path, inventory: list[dict], output: pathlib.Path, details: dict, owner: dict) -> str:
    rows_html = [];blind = blind_lookup(root)
    pocket_results_path = root / "execution/fresh_current/T02_indic/results.json"
    pocket_results = {
        row.get("locale"): row
        for row in (read_json(pocket_results_path, {}) or {}).get("results", [])
        if row.get("success") and row.get("locale")
    }
    for item in [row for row in inventory if str(row["model_id"]).startswith("T")]:
        model_id = str(item["model_id"]);records, rows, streaming, reason, mode = selected_tts(root, model_id)
        model_dir = root / "execution/fresh_current" / model_id;cells=[]
        fallback_rows=[]
        if records and records.is_file():
            raw=core.read_jsonl(records);smoke=[row for row in raw if row.get("phase") == "smoke"]
            fallback_rows=core.valid_rows(smoke or raw)
        for locale, _ in LANGUAGES:
            if model_id == "T02" and locale in pocket_results:
                extra = pocket_results[locale]
                audio = root / str(extra["file"])
                if not audio.is_file() or hashlib.sha256(audio.read_bytes()).hexdigest() != extra.get("sha256"):
                    raise ValueError(f"Pocket TTS supplemental audio failed verification: {audio}")
                human = owner.get((model_id, locale, "native_stream"), [])
                human_score = statistics.mean(human) if human else None
                key = f"tts:{model_id}:{locale}"
                details[key] = {
                    "title": f"{DISPLAY_NAMES[model_id]} · {locale}",
                    "kind": "TTS listening detail · language checkpoint",
                    "human_score": human_score,
                    "human_ratings": len(human),
                    "audio": href(audio, output),
                    "checkpoint": extra.get("repo"),
                    "revision": extra.get("revision"),
                    "ttfa_s": extra.get("ttfa_s"),
                    "rtf": extra.get("rtf"),
                    "configuration": "CPU native streaming; exact language checkpoint shown above",
                    "records": href(pocket_results_path, output),
                }
                visible = f"{human_score:.1f}" if human_score is not None else "▶"
                css = "quality" if human_score is not None else "playable"
                cells.append(f'<button class="score {css}" data-detail="{key}" data-audio="{href(audio, output)}">{visible}</button>')
                continue
            choices = [row for row in rows if row.get("locale") == locale and row.get("ok")]
            # Runs are appended chronologically. Use the latest successful trial so
            # one-time server/JIT warm-up does not replace the warmed measurement.
            record = choices[-1] if choices else None
            if record is None:
                fallbacks=[row for row in fallback_rows if row.get("locale") == locale and row.get("ok")]
                fallback=fallbacks[0] if fallbacks else None
                if fallback is not None:
                    fallback_mode=str(fallback.get("mode") or "full")
                    audio=core.choose_audio(fallback,model_dir,fallback_mode)
                    if audio is not None:
                        if fallback.get("sha256") and hashlib.sha256(audio.read_bytes()).hexdigest() != fallback["sha256"]:
                            raise ValueError(f"Audio hash mismatch: {audio}")
                        human=owner.get((model_id,locale,fallback_mode),[]);human_score=statistics.mean(human) if human else None
                        blind_rows=blind.get((model_id,locale,fallback_mode),[])
                        key=f"tts:{model_id}:{locale}"
                        details[key]={"title":f"{DISPLAY_NAMES[model_id]} · {locale}","kind":"TTS listening detail · alternate executed mode","human_score":human_score,"human_ratings":len(human),"sample_ids":[row.get("id") for row in blind_rows],"audio":href(audio,output),"ttfa_s":fallback.get("ttfa_s"),"rtf":fallback.get("rtf"),"configuration":f"Executed {fallback_mode} waveform; selected streaming status: {reason}","records":href(records,output)}
                        visible=f"{human_score:.1f}" if human_score is not None else "▶"
                        css="quality" if human_score is not None else "playable"
                        cells.append(f'<button class="score {css}" data-detail="{key}" data-audio="{href(audio,output)}">{visible}</button>');continue
                blind_candidates = [row for (mid, loc, _), values in blind.items() if mid == model_id and loc == locale for row in values]
                if blind_candidates:
                    blind_row = next((row for row in blind_candidates if row.get("mode") == mode), blind_candidates[0])
                    matches = sorted((root / "LISTENING_REVIEW/clips").glob(f"{blind_row.get('id')}.*"))
                    if matches:
                        audio = matches[0]
                        if blind_row.get("sha256") and hashlib.sha256(audio.read_bytes()).hexdigest() != blind_row["sha256"]:
                            raise ValueError(f"Audio hash mismatch: {audio}")
                        blind_mode = str(blind_row.get("mode") or "full")
                        human = owner.get((model_id, locale, blind_mode), [])
                        human_score = statistics.mean(human) if human else None
                        key = f"tts:{model_id}:{locale}"
                        details[key] = {
                            "title": f"{DISPLAY_NAMES[model_id]} · {locale}",
                            "kind": "TTS listening detail · verified listening pack",
                            "human_score": human_score,
                            "human_ratings": len(human),
                            "sample_ids": [row.get("id") for row in blind_candidates],
                            "audio": href(audio, output),
                            "configuration": f"Executed {blind_mode} waveform retained in the hash-verified listening pack; selected streaming status: {reason}",
                            "records": href(root / "LISTENING_REVIEW/blind_key.json", output),
                        }
                        visible = f"{human_score:.1f}" if human_score is not None else "▶"
                        css = "quality" if human_score is not None else "playable"
                        cells.append(f'<button class="score {css}" data-detail="{key}" data-audio="{href(audio,output)}">{visible}</button>');continue
                supported = is_supported(item, locale)
                if supported is False:
                    cells.append(status_cell("N/S", "unsupported", "No executed waveform and publisher does not declare this language"))
                else:
                    cells.append(status_cell("Not tested", "untested", "No verified waveform exists for this model-language cell"))
                continue
            audio = core.choose_audio(record, model_dir, mode or "")
            if audio is None:
                cells.append(status_cell("Failed", "failed", "Successful record has no locally verified waveform"));continue
            if record.get("sha256") and hashlib.sha256(audio.read_bytes()).hexdigest() != record["sha256"]:
                raise ValueError(f"Audio hash mismatch: {audio}")
            key_tuple = (model_id, locale, mode);human = owner.get(key_tuple, []);human_score = statistics.mean(human) if human else None
            blind_rows = blind.get(key_tuple, [])
            key = f"tts:{model_id}:{locale}"
            details[key] = {
                "title": f"{DISPLAY_NAMES[model_id]} · {locale}", "kind": "TTS listening detail",
                "human_score": human_score, "human_ratings": len(human),
                "sample_ids": [row.get("id") for row in blind_rows], "audio": href(audio, output),
                "ttfa_s": record.get("ttfa_s"), "rtf": record.get("rtf"), "configuration": reason,
                "records": href(records, output) if records else None,
            }
            visible = f"{human_score:.1f}" if human_score is not None else "▶"
            css = "quality" if human_score is not None else "playable"
            cells.append(f'<button class="score {css}" data-detail="{key}" data-audio="{href(audio, output)}">{visible}</button>')
        model_key = f"model:{model_id}"
        columns = [f'<button class="model-name" data-detail="{model_key}"><span>{model_id}</span>{html.escape(DISPLAY_NAMES[model_id])}</button>', f'<span class="stream {streaming.lower()}">{streaming}</span>', *cells]
        rows_html.append("<tr>" + "".join(f"<td>{cell}</td>" for cell in columns) + "</tr>")
    return comparison_section("tts", "TTS comparison", "Your blind quality score 1–5 · higher is better", "▶ means a verified waveform is available and awaits your score. N/S appears only when no waveform exists and the publisher excludes the language.", rows_html)


def comparison_section(section_id: str, title: str, legend: str, note: str, rows: list[str]) -> str:
    headers = "".join(f'<th title="{html.escape(locale)}">{label}</th>' for locale, label in LANGUAGES)
    return f'''<section id="{section_id}" class="report-section comparison">
      <div class="section-heading"><div><p class="eyebrow">{section_id.upper()}</p><h2>{html.escape(title)}</h2><p>{html.escape(note)}</p></div><div class="legend">{html.escape(legend)}<span class="swatch good"></span><span class="swatch mid"></span><span class="swatch bad"></span><span class="swatch neutral"></span></div></div>
      <div class="table-wrap"><table><thead><tr><th>Model</th><th>Streaming</th>{headers}</tr></thead><tbody>{''.join(rows)}</tbody></table></div>
    </section>'''


def primary_rows(root: pathlib.Path, model_id: str) -> tuple[list[dict], str, str]:
    if model_id.startswith("A"):
        _, rows, streaming, config = selected_asr(root, model_id);return rows, streaming, config
    _, rows, streaming, config, _ = selected_tts(root, model_id);return rows, streaming, config


def tested_device(model_dir: pathlib.Path, rows: list[dict] | None = None) -> str:
    values=[]
    run_ids = {str(row.get("run_id")) for row in (rows or []) if row.get("run_id")}
    for path in model_dir.glob("environment*.json"):
        data=read_json(path,{}) or {}
        if run_ids and data.get("run_id") and str(data.get("run_id")) not in run_ids:
            continue
        value=data.get("gpu") or data.get("hardware") or data.get("device")
        if value:values.append(str(value).replace("NVIDIA GeForce ","").replace("NVIDIA ",""))
    if not values and run_ids:
        return tested_device(model_dir, None)
    display = " / ".join(sorted(set(values))) or "Not captured"
    return "Apple Silicon CPU" if display.lower() == "arm" else display


def peak_memory(rows: list[dict]) -> str:
    values=[]
    for row in rows:
        for key in ("peak_memory_allocated_bytes","peak_memory_bytes"):
            if row.get(key) is not None:values.append(float(row[key]))
    return f"{max(values)/1024**3:.1f} GB" if values else "Not captured"


def measured_first_output(rows: list[dict], streaming: str) -> float | None:
    values=[]
    for row in rows:
        value=row.get("ttfa_s")
        if value is None and streaming == "Yes": value=row.get("first_partial_s")
        if value is None and streaming == "No": value=row.get("total_s")
        if value is not None: values.append(float(value))
    return median(values)


def fmt_seconds(value: float | None) -> str:
    if value is None: return "Pending"
    return "<0.01s" if value < .01 else f"{value:.2f}s"


def fmt_ratio(value: float | None) -> str:
    if value is None: return "Pending"
    return "<0.01" if value < .01 else f"{value:.2f}"


def deployment_section(root: pathlib.Path, inventory: list[dict], output: pathlib.Path) -> str:
    body=[]
    for item in inventory:
        model_id=str(item["model_id"]);rows,streaming,config=primary_rows(root,model_id);model_dir=root/"execution/fresh_current"/model_id
        ttfa=[float(r["ttfa_s"]) for r in rows if r.get("ok") and r.get("ttfa_s") is not None]
        rtf=[float(r["rtf"]) for r in rows if r.get("ok") and r.get("rtf") is not None]
        device=tested_device(model_dir,rows);lower=device.lower()
        cpu="Yes — tested" if "cpu" in lower or "arm" in lower else ("Yes — publisher" if model_id in CPU_PUBLISHER_SUPPORTED else "Not verified")
        gpu_markers=("rtx","gpu","a40","a100","h100","h200","blackwell","ada")
        gpu="Yes — tested" if any(marker in lower for marker in gpu_markers) else ("Yes — publisher" if model_id in GPU_PUBLISHER_SUPPORTED else "Not verified")
        stalls=[int(r["simulated_stall_count"]) for r in rows if r.get("simulated_stall_count") is not None]
        interruptions=f"{max(stalls)} max" if stalls else ("Not captured" if streaming in {"Yes","Pending"} else "N/A")
        first_output=measured_first_output(rows,streaming)
        cells=[f'<button class="model-name" data-detail="model:{model_id}"><span>{model_id}</span>{html.escape(DISPLAY_NAMES[model_id])}</button>',streaming,fmt_seconds(first_output),fmt_ratio(median(rtf)),interruptions,cpu,gpu,device,peak_memory(rows)]
        body.append("<tr>"+"".join(f"<td>{html.escape(str(cell)) if not str(cell).startswith('<') else cell}</td>" for cell in cells)+"</tr>")
    return f'''<section id="deployment" class="report-section"><div class="section-heading"><div><p class="eyebrow">OPERATIONS</p><h2>Deployment</h2><p>Timing and memory belong to the selected primary configuration. Compatibility is reported only when tested or explicitly verified.</p></div></div><div class="table-wrap"><table class="deployment"><thead><tr><th>Model</th><th>Streaming</th><th>First output</th><th>RTF</th><th>Playback interruptions</th><th>CPU compatibility</th><th>GPU compatibility</th><th>Tested device</th><th>Peak RAM/VRAM</th></tr></thead><tbody>{''.join(body)}</tbody></table></div></section>'''


def license_label(item: dict) -> str:
    overrides={"A11":"BharatGen non-commercial","T09":"BharatGen non-commercial","T06":"Indic Open Model License v1.0","T16":"Fish Audio Research License","T17":"Coqui Public Model License 1.0.0","A14":"MIT"}
    return overrides.get(str(item["model_id"]),str(item.get("license") or "Not declared"))


def evidence_section(root: pathlib.Path, inventory: list[dict], output: pathlib.Path) -> str:
    body=[]
    for item in inventory:
        model_id=str(item["model_id"]);model_dir=root/"execution/fresh_current"/model_id;audit=root/"execution/sources"/model_id/"audit.json";runner=runner_path(root,model_id,model_dir);env=environment_path(model_dir)
        _,streaming,config=primary_rows(root,model_id);links=[f'<a href="{href(audit,output)}">source</a>'] if audit.is_file() else []
        if runner:links.append(f'<a href="{href(runner,output)}">code</a>')
        if env:links.append(f'<a href="{href(env,output)}">environment</a>')
        revision=str(item.get("revision") or read_json(audit,{}).get("revision") or "Not captured")[:12]
        cells=[f'<button class="model-name" data-detail="model:{model_id}"><span>{model_id}</span>{html.escape(DISPLAY_NAMES[model_id])}</button>',html.escape(config),html.escape(license_label(item)),html.escape(revision)," · ".join(links)]
        body.append("<tr>"+"".join(f"<td>{cell}</td>" for cell in cells)+"</tr>")
    return f'''<section id="evidence" class="report-section"><div class="section-heading"><div><p class="eyebrow">TRACEABILITY</p><h2>Licences and evidence</h2><p>Repository identifiers, pinned revisions, alternative-mode records, adapter mappings, restrictions and full source records stay behind the comparison.</p></div></div><div class="evidence-cards"><a href="{href(root/'execution/final_report_validation.json',output)}"><strong>Release validation</strong><span>links, counts and report structure</span></a><a href="{href(root/'execution/primary_configuration_ledger.json',output)}"><strong>Primary configurations</strong><span>selection locked independently of quality</span></a><a href="{href(root/'execution/metadata_corrections.json',output)}"><strong>Metadata corrections</strong><span>licences, checkpoints and adapter mapping</span></a><a href="{href(root/'execution/final_local_data_audit.json',output)}"><strong>Local completeness</strong><span>records and audio hashes</span></a><a href="{href(root/'execution/final_shutdown_verification.json',output)}"><strong>RunPod shutdown</strong><span>all runtimes exited</span></a></div><div class="table-wrap"><table class="evidence"><thead><tr><th>Model</th><th>Primary configuration</th><th>Licence</th><th>Revision</th><th>Evidence</th></tr></thead><tbody>{''.join(body)}</tbody></table></div></section>'''


def model_details(root: pathlib.Path, inventory: list[dict], output: pathlib.Path, details: dict) -> None:
    for item in inventory:
        model_id=str(item["model_id"]);model_dir=root/"execution/fresh_current"/model_id;audit=root/"execution/sources"/model_id/"audit.json";env=environment_path(model_dir);runner=runner_path(root,model_id,model_dir)
        rows,streaming,config=primary_rows(root,model_id)
        alternatives=[]
        for path in sorted(model_dir.glob("*records*.jsonl")):
            summary = record_file_summary(path)
            alternatives.append({"file":href(path,output),"rows":summary["rows"],"modes":summary["modes"],"invalid_lines":summary["invalid_lines"]})
        detail={"title":f"{model_id} · {DISPLAY_NAMES[model_id]}","kind":"Model configuration","repository":item.get("repo"),"revision":item.get("revision") or read_json(audit,{}).get("revision"),"licence":license_label(item),"streaming":streaming,"primary_configuration":config,"tested_device":tested_device(model_dir,rows),"source":href(audit,output) if audit.is_file() else None,"code":href(runner,output) if runner else None,"environment":href(env,output) if env else None,"alternative_records":alternatives}
        if model_id == "T02":
            supplemental = (read_json(root / "execution/fresh_current/T02_indic/results.json", {}) or {}).get("results", [])
            detail["checkpoint_mapping"] = {
                "en-IN": "kyutai/pocket-tts-without-voice-cloning",
                **{str(row.get("locale")): f"{row.get('repo')}@{row.get('revision')}" for row in supplemental if row.get("success")},
            }
            detail["checkpoint_evidence"] = href(root / "execution/fresh_current/T02_indic/results.json", output)
        details[f"model:{model_id}"]=detail


CSS = r'''
:root{--ink:#18221d;--muted:#66736b;--paper:#fbfcfa;--panel:#fff;--line:#dfe5df;--brand:#174f3a;--brand2:#2f7759;--good:#dcebdd;--mid:#f2e8c9;--bad:#efd4cc;--neutral:#eef1ee;--shadow:0 18px 45px rgba(25,45,34,.10)}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font:14px/1.45 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:var(--brand);text-underline-offset:3px}.shell{max-width:1540px;margin:auto;padding:0 28px 72px}.hero{padding:54px 0 30px;display:flex;justify-content:space-between;gap:36px;align-items:flex-end}.hero h1{font-size:clamp(34px,5vw,64px);line-height:.96;letter-spacing:-.045em;margin:8px 0 18px;max-width:820px}.hero p{color:var(--muted);max-width:770px;font-size:16px}.eyebrow{font-size:11px!important;font-weight:800;letter-spacing:.16em;color:var(--brand2)!important;margin:0!important}.summary{display:grid;grid-template-columns:repeat(2,minmax(120px,1fr));gap:10px;min-width:310px}.summary div{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px 16px}.summary strong{display:block;font-size:24px}.summary span{color:var(--muted);font-size:12px}.nav{position:sticky;top:0;z-index:20;display:flex;gap:4px;padding:10px;background:rgba(251,252,250,.94);backdrop-filter:blur(12px);border:1px solid var(--line);border-radius:16px;box-shadow:0 8px 26px rgba(25,45,34,.06)}.nav a{flex:1;text-align:center;padding:10px 12px;border-radius:10px;text-decoration:none;font-weight:750;color:var(--ink)}.nav a:hover{background:#e9f1ec;color:var(--brand)}.report-section{scroll-margin-top:84px;margin-top:38px;background:var(--panel);border:1px solid var(--line);border-radius:22px;box-shadow:var(--shadow);padding:28px}.section-heading{display:flex;justify-content:space-between;align-items:flex-end;gap:30px;margin-bottom:20px}.section-heading h2{font-size:30px;letter-spacing:-.03em;margin:4px 0 7px}.section-heading p{margin:0;color:var(--muted);max-width:850px}.legend{font-size:12px;color:var(--muted);white-space:nowrap;display:flex;align-items:center;gap:7px}.swatch{width:18px;height:18px;border-radius:5px;display:inline-block}.swatch.good{background:var(--good)}.swatch.mid{background:var(--mid)}.swatch.bad{background:var(--bad)}.swatch.neutral{background:var(--neutral)}.table-wrap{overflow:auto;border:1px solid var(--line);border-radius:14px}table{width:100%;border-collapse:collapse;min-width:1140px}th{position:sticky;top:0;background:#f2f5f2;color:#536158;font-size:11px;text-transform:uppercase;letter-spacing:.06em;padding:12px 10px;text-align:center;border-bottom:1px solid #cfd8d1}th:first-child,td:first-child{text-align:left;min-width:220px}td{padding:10px;border-bottom:1px solid #e7ebe8;text-align:center;vertical-align:middle}tbody tr:last-child td{border-bottom:0}tbody tr:hover{background:#fafcfb}.model-name{display:flex;gap:9px;align-items:center;border:0;background:none;padding:0;color:var(--ink);font:inherit;font-weight:750;cursor:pointer;text-align:left}.model-name span{font:700 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace;background:#e6eee9;color:var(--brand);padding:5px 6px;border-radius:6px}.stream{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800}.stream.yes{background:#d9ecdf;color:#17543b}.stream.no{background:#edf0ed;color:#637067}.stream.pending{background:#f4e5bc;color:#755412}.score{width:100%;min-height:38px;border:0;border-radius:9px;font:750 13px/1 inherit;cursor:pointer;color:var(--ink)}.score.wer{background:color-mix(in srgb,var(--good) calc(100% - var(--value)*.75%),var(--bad) calc(var(--value)*.75%))}.score.quality{background:var(--good)}.score.playable{background:#e8f0ea;color:var(--brand);font-size:16px}.score.pending{background:var(--neutral);color:#69746d;font-size:11px}.score:hover{outline:2px solid var(--brand);outline-offset:-2px}.status{display:flex;min-height:38px;align-items:center;justify-content:center;border-radius:9px;padding:6px;font-size:10px;font-weight:750}.status.unsupported{background:#f5f6f5;color:#9aa19c}.status.untested,.status.pending{background:#eef1ee;color:#68736c}.status.failed{background:#f5dddd;color:#8f3329}.deployment th:first-child,.deployment td:first-child{min-width:245px}.deployment td{font-size:12px}.evidence-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.evidence-cards a{display:flex;flex-direction:column;text-decoration:none;border:1px solid var(--line);border-radius:13px;padding:15px;background:#fbfcfb}.evidence-cards strong{color:var(--ink)}.evidence-cards span{font-size:12px;color:var(--muted);margin-top:3px}.evidence{min-width:900px}.evidence td:nth-child(2){text-align:left}dialog{width:min(760px,calc(100vw - 30px));border:0;border-radius:20px;padding:0;box-shadow:0 30px 100px rgba(0,0,0,.28)}dialog::backdrop{background:rgba(12,20,16,.55);backdrop-filter:blur(3px)}.dialog-head{display:flex;justify-content:space-between;align-items:start;padding:24px 26px 18px;border-bottom:1px solid var(--line)}.dialog-head h3{font-size:24px;margin:3px 0}.dialog-head button{border:0;background:#eef2ef;border-radius:999px;width:36px;height:36px;font-size:20px;cursor:pointer}.dialog-body{padding:22px 26px 28px;max-height:70vh;overflow:auto}.dialog-body dl{display:grid;grid-template-columns:150px 1fr;gap:9px 16px;margin:0}.dialog-body dt{font-weight:750;color:#526158}.dialog-body dd{margin:0;overflow-wrap:anywhere}.dialog-body audio{width:100%;margin:18px 0}.finding{border-left:3px solid var(--brand2);padding:10px 12px;background:#f5f8f6;margin:10px 0;border-radius:0 9px 9px 0}.finding p{margin:4px 0}.finding ul{margin:7px 0;padding-left:20px}.muted{color:var(--muted)}@media(max-width:850px){.shell{padding:0 14px 45px}.hero{display:block;padding-top:32px}.summary{margin-top:22px}.nav{overflow:auto}.report-section{padding:18px;border-radius:16px}.section-heading{display:block}.legend{margin-top:14px}.evidence-cards{grid-template-columns:1fr 1fr}}@page{size:A3 landscape;margin:10mm}@media print{body{background:white;font-size:10pt}.shell{max-width:none;padding:0}.hero,.nav{display:none}.report-section{border:0;box-shadow:none;border-radius:0;padding:0;margin:0;break-before:page}.report-section:first-of-type{break-before:auto}.section-heading{margin-bottom:3mm}.section-heading h2{font-size:20pt;margin:0 0 1.5mm}.section-heading p,.legend{font-size:10pt}.table-wrap{overflow:visible;border:0;border-radius:0}table{min-width:0;table-layout:fixed}th{position:static;font-size:10pt;padding:1.6mm 1mm}td{font-size:10pt;padding:1.4mm 1mm}.score,.status{min-height:0;padding:1.2mm .8mm;font-size:10pt}.model-name,.model-name span,.stream{font-size:10pt}.model-name span{padding:1mm}.evidence-cards{display:none}.comparison{min-height:0}dialog{display:none}.deployment,.evidence{font-size:10pt}.report-section#deployment,.report-section#evidence{break-before:page}tr{break-inside:avoid}}
@page{size:A3 landscape;margin:6mm}
@media print{body{line-height:1.15}.section-heading{margin-bottom:2mm}.section-heading h2{font-size:19pt;margin:0 0 1mm}th{padding:1.2mm .8mm}td{padding:.9mm .8mm}.score,.status{padding:.8mm .6mm}.model-name span{padding:.8mm}}
@media print{.evidence td{padding:.65mm .8mm;line-height:1.05}}
'''


def main() -> None:
    parser=argparse.ArgumentParser();parser.add_argument("--output",type=pathlib.Path,default=pathlib.Path("BENCHMARK_REPORT.html"));parser.add_argument("--owner-ratings",type=pathlib.Path,default=pathlib.Path("execution/listening_ratings_current.json"));args=parser.parse_args()
    root=pathlib.Path(__file__).resolve().parents[1];output=(root/args.output).resolve() if not args.output.is_absolute() else args.output.resolve();inventory=read_json(root/"execution/sources/inventory_audit.json",[]);owner,_=quality_maps((root/args.owner_ratings).resolve(),root/"execution/grok_review.json");details={};model_details(root,inventory,output,details)
    content=asr_table(root,inventory,output,details)+tts_table(root,inventory,output,details,owner)+deployment_section(root,inventory,output)+evidence_section(root,inventory,output)
    timestamp=(read_json(root/"execution/fresh_current/snapshot.json",{}) or {}).get("snapshot_utc") or dt.datetime.now(dt.timezone.utc).isoformat()
    doc=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>On-prem Indic speech benchmark</title><style>{CSS}</style></head><body><div class="shell"><header class="hero"><div><p class="eyebrow">ON-PREM · INDIA · EVIDENCE-LED</p><h1>Indic speech benchmark</h1><p>A readable comparison of self-hosted ASR and TTS across HI, EN-IN, BN, MR, TA, TE, GU, KN, ML and OR. Model identities open exact configurations; score cells open their raw records or waveform-level review.</p><p class="muted">Evidence snapshot {html.escape(str(timestamp))}</p></div><div class="summary"><div><strong>15</strong><span>ASR models</span></div><div><strong>19</strong><span>TTS models</span></div><div><strong>10</strong><span>target locales</span></div><div><strong>1–5</strong><span>your single TTS score</span></div></div></header><nav class="nav"><a href="#asr">ASR</a><a href="#tts">TTS</a><a href="#deployment">Deployment</a><a href="#evidence">Evidence</a></nav>{content}</div><dialog id="detail"><div class="dialog-head"><div><p class="eyebrow" id="detail-kind"></p><h3 id="detail-title"></h3></div><button id="close" aria-label="Close">×</button></div><div class="dialog-body" id="detail-body"></div></dialog><audio id="player"></audio><script>const DETAILS={json.dumps(details,ensure_ascii=False).replace('<','\\u003c')};const dialog=document.getElementById('detail'),body=document.getElementById('detail-body'),title=document.getElementById('detail-title'),kind=document.getElementById('detail-kind'),player=document.getElementById('player');const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c]));function render(d){{let out='';if(d.audio)out+=`<audio controls autoplay src="${{esc(d.audio)}}"></audio>`;const skip=new Set(['title','kind','audio']);out+='<dl>'+Object.entries(d).filter(([k,v])=>!skip.has(k)&&v!==null&&v!==undefined).map(([k,v])=>`<dt>${{esc(k.replaceAll('_',' '))}}</dt><dd>${{Array.isArray(v)||typeof v==='object'?`<pre>${{esc(JSON.stringify(v,null,2))}}</pre>`:String(v).endsWith('.json')||String(v).endsWith('.jsonl')||String(v).endsWith('.py')?`<a href="${{esc(v)}}">${{esc(v)}}</a>`:esc(v)}}</dd>`).join('')+'</dl>';return out}}document.querySelectorAll('[data-detail]').forEach(el=>el.addEventListener('click',()=>{{const d=DETAILS[el.dataset.detail];if(!d)return;kind.textContent=d.kind||'DETAIL';title.textContent=d.title||'';body.innerHTML=render(d);dialog.showModal()}}));document.getElementById('close').onclick=()=>dialog.close();dialog.addEventListener('click',e=>{{if(e.target===dialog)dialog.close()}});</script></body></html>'''
    output.write_text(doc);print(json.dumps({"output":str(output),"sections":doc.count('class="report-section'),"asr_rows":sum(str(row["model_id"]).startswith("A") for row in inventory),"tts_rows":sum(str(row["model_id"]).startswith("T") for row in inventory),"details":len(details)}))


if __name__=="__main__":main()
