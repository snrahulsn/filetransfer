"""Evaluate the publisher's re-transcribing streaming API, not an incremental encoder claim."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',VLLM_WORKER_MULTIPROC_METHOD='spawn')
import argparse,datetime,hashlib,importlib.metadata,inspect,json,pathlib,traceback
import torch
from qwen_asr import Qwen3ASRModel
from asr_corpus import records
from stage_model import stage
from metrics import score
from sravaani_run import paced
ROOT=pathlib.Path('/workspace/speechbench_20260924')
class Adapter:
    def __init__(self,model,language):self.model=model;self.language=language
    def new_stream(self):return self.model.init_streaming_state(language=self.language,unfixed_chunk_num=2,unfixed_token_num=5,chunk_size_sec=2.0)
    def stream_audio(self,state,chunk):self.model.streaming_transcribe(chunk,state);return state.text
    def finalize(self,state):self.model.finish_streaming_transcribe(state);return state.text
LANGUAGES={'hi-IN':'Hindi','en-IN':'English','bn-IN':'Bengali','mr-IN':'Marathi','ta-IN':'Tamil','te-IN':'Telugu','gu-IN':'Gujarati','kn-IN':'Kannada','ml-IN':'Malayalam','or-IN':'Odia'}
def main(key,limit,locales):
    out=ROOT/key;out.mkdir(exist_ok=True);job=json.loads((ROOT/(key+'_download.json')).read_text())
    path,files=stage(job['path'],key)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    model=Qwen3ASRModel.LLM(model=str(path),dtype='bfloat16',gpu_memory_utilization=.7,max_new_tokens=128,max_model_len=4096,max_num_seqs=1,enforce_eager=True,seed=20260924)
    env=dict(run_id=stamp,model=job['repo'],revision=job['revision'],files=files,torch=torch.__version__,vllm=importlib.metadata.version('vllm'),qwen_asr=importlib.metadata.version('qwen-asr'),
        runner_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),provider_source_sha256=hashlib.sha256(pathlib.Path(inspect.getfile(type(model))).read_bytes()).hexdigest(),
        mode='publisher_buffered_retranscription',chunk_size_sec=2.0,unfixed_chunk_num=2,unfixed_token_num=5,max_new_tokens=128,enforce_eager=True,
        hf_offline=True,network_namespace_isolated=False,incremental_audio_encoder_cache=False,gpu=torch.cuda.get_device_name(0))
    (out/f'environment-stream-{stamp}.json').write_text(json.dumps(env,indent=2))
    for locale in locales:
        language=LANGUAGES[locale];adapter=Adapter(model,language);samples=list(records([locale],limit=limit))
        for index,row in enumerate([samples[0]]*3+samples):
            rec={k:v for k,v in row.items() if k!='audio'}
            rec.update(run_id=stamp,phase='warmup' if index<3 else 'streaming_smoke',mode='publisher_buffered_retranscription',chunk_size_sec=2.0,ok=False,audio_duration_s=len(row['audio'])/16000)
            try:
                hyp,timing=paced(adapter,row['audio']);rec.update(ok=True,hypothesis=hyp,**timing,**score(row['reference'],hyp))
            except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
            with (out/'stream_records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            print(json.dumps({k:rec.get(k) for k in ['locale','phase','ok','wer','total_s','error']}),flush=True)
    (out/'DONE-stream-smoke').write_text('Publisher streaming implementation smoke completed; full streaming qualification pending.\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('model',choices=['A07','A09']);p.add_argument('--limit',type=int,default=2);p.add_argument('--all-locales',action='store_true');a=p.parse_args();main(a.model,a.limit,list(LANGUAGES) if a.all_locales else ['hi-IN','en-IN'])
