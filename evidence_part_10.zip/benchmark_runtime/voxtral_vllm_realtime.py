"""Measure Voxtral through vLLM's official realtime WebSocket endpoint."""
from __future__ import annotations

import argparse
import asyncio
import base64
import datetime as dt
import hashlib
import importlib.metadata
import json
import pathlib
import time

import numpy as np
import torch
import websockets

from asr_corpus import records
from metrics import score


ROOT = pathlib.Path("/workspace/speechbench_20260924")
OUT = ROOT / "A02"
OUT.mkdir(exist_ok=True)
MODEL = "mistralai/Voxtral-Mini-4B-Realtime-2602"
REVISION = "2769294da9567371363522aac9bbcfdd19447add"


def sha256(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


async def transcribe(uri: str, audio: np.ndarray) -> tuple[str, dict]:
    pcm = np.rint(np.clip(audio, -1, 1 - 1 / 32768) * 32768).astype("<i2").tobytes()
    chunk_bytes = 4096
    events = []
    releases = []
    started = time.perf_counter()
    async with websockets.connect(uri, max_size=16 * 1024 * 1024) as socket:
        created = json.loads(await socket.recv())
        if created.get("type") != "session.created":
            raise RuntimeError(f"Expected session.created, received {created}")
        await socket.send(json.dumps({"type": "session.update", "model": MODEL}))
        await socket.send(json.dumps({"type": "input_audio_buffer.commit"}))

        async def send_audio() -> None:
            for offset in range(0, len(pcm), chunk_bytes):
                chunk = pcm[offset : offset + chunk_bytes]
                due = (offset + len(chunk)) / 2 / 16000
                await asyncio.sleep(max(0, started + due - time.perf_counter()))
                released = time.perf_counter() - started
                releases.append({"end_sample": (offset + len(chunk)) // 2, "due_s": due, "released_s": released})
                await socket.send(json.dumps({
                    "type": "input_audio_buffer.append",
                    "audio": base64.b64encode(chunk).decode("ascii"),
                }))
            await socket.send(json.dumps({"type": "input_audio_buffer.commit", "final": True}))

        sender = asyncio.create_task(send_audio())
        text = ""
        try:
            while True:
                message = json.loads(await socket.recv())
                kind = message.get("type")
                if kind == "transcription.delta":
                    delta = message.get("delta", "")
                    text += delta
                    events.append({"at_s": time.perf_counter() - started, "delta": delta, "text": text})
                elif kind == "transcription.done":
                    text = message.get("text", text)
                    break
                elif kind == "error":
                    raise RuntimeError(json.dumps(message.get("error", message)))
        finally:
            await sender
    elapsed = time.perf_counter() - started
    duration = len(audio) / 16000
    return text, {
        "total_s": elapsed,
        "audio_duration_s": duration,
        "rtf": elapsed / duration,
        "first_partial_s": events[0]["at_s"] if events else None,
        "finalization_lag_s": elapsed - duration,
        "partial_events": events,
        "producer_events": releases,
        "max_release_lateness_s": max(item["released_s"] - item["due_s"] for item in releases),
        "received_all_input_audio": releases[-1]["end_sample"] == len(audio),
    }


async def main(port: int, limit: int) -> None:
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    snapshot = pathlib.Path("/workspace/hf_cache/hub/models--mistralai--Voxtral-Mini-4B-Realtime-2602/snapshots") / REVISION
    weight = snapshot / "model.safetensors"
    environment = {
        "run_id": stamp,
        "model": MODEL,
        "revision": REVISION,
        "weights_sha256": {weight.name: sha256(weight)},
        "runner_sha256": sha256(pathlib.Path(__file__)),
        "vllm": importlib.metadata.version("vllm"),
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0),
        "mode": "official_vllm_realtime_websocket_paced_pcm16_16khz",
        "audio_chunk_bytes": 4096,
        "network_namespace_isolated": False,
    }
    (OUT / f"environment-vllm-{stamp}.json").write_text(json.dumps(environment, indent=2))
    uri = f"ws://127.0.0.1:{port}/v1/realtime"
    for locale in ("hi-IN", "en-IN"):
        for row in records([locale], limit=limit):
            record = {key: value for key, value in row.items() if key != "audio"}
            record.update(run_id=stamp, phase="streaming_smoke", mode=environment["mode"], ok=False)
            try:
                hypothesis, timing = await transcribe(uri, row["audio"])
                record.update(ok=True, hypothesis=hypothesis, **timing, **score(row["reference"], hypothesis))
            except Exception as error:
                record.update(error_type=type(error).__name__, error=str(error))
            with (OUT / "stream_records.jsonl").open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(json.dumps({key: record.get(key) for key in ("id", "ok", "wer", "first_partial_s", "error")}), flush=True)
            if not record["ok"]:
                raise RuntimeError(record["error"])
    (OUT / f"DONE-vllm-{stamp}").write_text(f"{limit} frozen clips per supported locale completed.\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--limit", type=int, default=10)
    args = parser.parse_args()
    asyncio.run(main(args.port, args.limit))
