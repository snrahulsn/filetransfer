"""Hash-verified sequential staging of HF inference assets to pod-local disk."""
import hashlib,json,pathlib,re
def stage(source,model_id,target_root='/tmp/asr_model_stage'):
    source=pathlib.Path(source);target=pathlib.Path(target_root)/model_id;target.mkdir(parents=True,exist_ok=True)
    manifest={}
    for p in sorted(source.rglob('*')):
        relative=p.relative_to(source)
        if not p.is_file() or (relative.parts[0]!='assets' and p.suffix not in ['.json','.safetensors','.txt','.model','.jinja','.ts','.pt','.py']):continue
        if '.fp32' in p.name:continue
        dst=target/relative;dst.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();git=hashlib.sha1(('blob '+str(p.stat().st_size)+'\0').encode())
        with p.open('rb') as inp,dst.open('wb') as out:
            while chunk:=inp.read(8388608):h.update(chunk);git.update(chunk);out.write(chunk)
        actual=h.hexdigest();expected=p.resolve().name if p.is_symlink() else None
        lfs=bool(expected and re.fullmatch('[0-9a-f]{64}',expected));blob=bool(expected and re.fullmatch('[0-9a-f]{40}',expected))
        if lfs and expected!=actual:raise ValueError('LFS digest mismatch: '+p.name)
        if blob and expected!=git.hexdigest():raise ValueError('Git blob digest mismatch: '+p.name)
        manifest[str(relative)]=dict(sha256=actual,bytes=dst.stat().st_size,upstream_lfs_digest_verified=lfs,upstream_git_blob_digest_verified=blob)
    (target/'staging_manifest.json').write_text(json.dumps(manifest,indent=2))
    return target,manifest
