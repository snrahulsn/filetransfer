"""Audit that final benchmark records and referenced audio are present locally."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pathlib


ROOT = pathlib.Path(__file__).resolve().parents[1]


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(fresh: pathlib.Path, sources: pathlib.Path) -> dict:
    model_ids = [*(f"A{i:02d}" for i in range(1, 16)), *(f"T{i:02d}" for i in range(1, 20))]
    rows = 0
    audio_references = 0
    audio_files = set()
    missing = []
    hash_failures = []
    model_summary = []
    for model_id in model_ids:
        directory = fresh / model_id
        record_files = sorted(directory.glob("*records*.jsonl"))
        audit_path = sources / model_id / "audit.json"
        if not record_files:
            missing.append(f"{model_id}:records")
        if not audit_path.is_file():
            missing.append(f"{model_id}:source-audit")
        model_rows = 0
        model_audio = 0
        for record_file in record_files:
            for line_number, line in enumerate(record_file.read_text().splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    missing.append(f"{record_file}:{line_number}:invalid-json")
                    continue
                rows += 1
                model_rows += 1
                if not record.get("ok") or not record.get("file"):
                    continue
                audio_references += 1
                model_audio += 1
                audio = fresh / str(record["file"])
                if not audio.is_file():
                    missing.append(str(audio.relative_to(ROOT)))
                    continue
                audio_files.add(str(audio.relative_to(ROOT)))
                expected = record.get("sha256")
                if expected and sha256(audio) != expected:
                    hash_failures.append(str(audio.relative_to(ROOT)))
        model_summary.append(
            {"model_id": model_id, "record_files": len(record_files), "record_rows": model_rows, "successful_audio_references": model_audio}
        )
    if missing or hash_failures:
        raise ValueError(json.dumps({"missing": missing, "hash_failures": hash_failures}, indent=2))
    return {
        "verified_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "models_expected": len(model_ids),
        "models_with_records": sum(bool(item["record_files"]) for item in model_summary),
        "record_rows": rows,
        "successful_audio_references": audio_references,
        "distinct_referenced_audio_files": len(audio_files),
        "missing": [],
        "hash_failures": [],
        "models": model_summary,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh", type=pathlib.Path, default=ROOT / "execution/fresh_current")
    parser.add_argument("--sources", type=pathlib.Path, default=ROOT / "execution/sources")
    parser.add_argument("--output", type=pathlib.Path, default=ROOT / "execution/final_local_data_audit.json")
    args = parser.parse_args()
    result = audit(args.fresh.resolve(), args.sources.resolve())
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "models"}))


if __name__ == "__main__":
    main()
