#!/usr/bin/env python3
"""Regenerate the executed Pocket TTS community-checkpoint evidence on CPU."""
from __future__ import annotations

import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np
import soundfile as sf
from pocket_tts import TTSModel


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "execution/fresh_current/T02_indic"
OUT.mkdir(parents=True, exist_ok=True)

SPECS = [
    {
        "locale": "hi-IN",
        "repo": "saryps-labs/pocket-tts-hindi",
        "revision": "dbaa326069d20bfbdaeb625613736773741a24ea",
        "config": "config.yaml",
        "voice": "samples/voice_01_f.wav",
        "text": "आपकी बैठक कल दोपहर तीन बजे है।",
    },
    {
        "locale": "te-IN",
        "repo": "prasadvittaldev/pocket-tts-telugu-female-syspin",
        "revision": "563ea1739d29a8c203c4be9d8aa23b7e9113fec2",
        "config": "config.yaml",
        "voice": "voice_prompt.wav",
        "text": "మీ సమావేశం రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.",
    },
    {
        "locale": "ta-IN",
        "repo": "prasadvittaldev/pocket-tts-tamil-female-audiobook",
        "revision": "dd6aba695471b75d2775947efc42805cca283981",
        "config": "config.yaml",
        "voice": "voice_prompt.wav",
        "text": "உங்கள் கூட்டம் நாளை பிற்பகல் மூன்று மணிக்கு உள்ளது.",
    },
]


def hf(repo: str, path: str, revision: str) -> str:
    return f"hf://{repo}/{path}@{revision}"


def generate(spec: dict) -> dict:
    started = time.perf_counter()
    model = TTSModel.load_model(config=hf(spec["repo"], spec["config"], spec["revision"]), quantize=True)
    state = model.get_state_for_audio_prompt(hf(spec["repo"], spec["voice"], spec["revision"]))
    chunks = []
    first = None
    generated = time.perf_counter()
    for chunk in model.generate_audio_stream(model_state=state, text_to_generate=spec["text"]):
        if first is None:
            first = time.perf_counter()
        values = np.asarray(chunk, dtype=np.float32).reshape(-1)
        if values.size:
            chunks.append(values)
    finished = time.perf_counter()
    audio = np.concatenate(chunks)
    path = OUT / f"pocket-tts-{spec['locale']}.wav"
    sf.write(path, audio, model.sample_rate)
    return {
        **spec,
        "model_id": "T02",
        "success": True,
        "mode": "native_stream",
        "device": "cpu",
        "quantize": True,
        "sample_rate": model.sample_rate,
        "audio_duration_s": len(audio) / model.sample_rate,
        "load_s": generated - started,
        "ttfa_s": first - generated if first else None,
        "total_generation_s": finished - generated,
        "rtf": (finished - generated) / (len(audio) / model.sample_rate),
        "chunks": len(chunks),
        "file": str(path.relative_to(ROOT)),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def main() -> None:
    rows = []
    for spec in SPECS:
        print(f"Generating {spec['locale']} with {spec['repo']}", flush=True)
        try:
            rows.append(generate(spec))
        except Exception as exc:
            rows.append({**spec, "model_id": "T02", "success": False, "error": f"{type(exc).__name__}: {exc}"})
    payload = {"runtime": {"platform": platform.platform(), "python": platform.python_version()}, "results": rows}
    (OUT / "results.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    if not all(row.get("success") for row in rows):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
