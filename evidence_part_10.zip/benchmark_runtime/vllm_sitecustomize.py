"""Compatibility shim for Transformers 5 Mistral Common tokenizers in vLLM."""
try:
    from transformers.tokenization_mistral_common import MistralCommonBackend
    from transformers.tokenization_utils_base import PreTrainedTokenizerBase

    PreTrainedTokenizerBase.is_fast = False
    MistralCommonBackend.is_fast = False
except ImportError:
    pass
