#!/usr/bin/env python3
"""Convert the Fish S2 runner's emitted result rows into the canonical evidence schema."""

import argparse
import json
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("directory", type=Path)
    args = p.parse_args()
    result_files = sorted(args.directory.glob("results-*.jsonl"))
    if len(result_files) != 1:
        raise SystemExit(f"Expected one results file, found {len(result_files)}")
    rows = []
    for index, line in enumerate(result_files[0].read_text().splitlines()):
        row = json.loads(line)
        rows.append(
            {
                **row,
                "phase": "smoke",
                "index": index,
                "mode": "full",
                "voice": "publisher zero-shot default",
                "ok": True,
                "total_s": row["synthesis_s"],
                "ttfa_s": row["synthesis_s"],
                "file": f"T16/{row['output']}",
                "sha256": row["output_sha256"],
            }
        )
    with (args.directory / "records.jsonl").open("w") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    (args.directory / "DONE").write_text("ok\n")
    print(json.dumps({"records": len(rows), "source": result_files[0].name}))


if __name__ == "__main__":
    main()
