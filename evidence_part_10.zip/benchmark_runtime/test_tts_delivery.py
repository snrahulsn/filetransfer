import unittest
from tts_delivery import diagnose
class DeliveryTests(unittest.TestCase):
    def make(self,times):return dict(sample_rate=10,audio_duration_s=len(times),events=[dict(at_s=t,samples=10) for t in times])
    def test_ready_chunks_do_not_stall(self):
        r=diagnose(self.make([1,1.5,2]));self.assertEqual(r['simulated_stall_count'],0);self.assertEqual(r['additional_initial_buffer_s'],0)
    def test_repeated_late_chunks(self):
        r=diagnose(self.make([1,3,5]));self.assertEqual(r['simulated_stall_count'],2);self.assertEqual(r['simulated_stall_total_s'],2);self.assertEqual(r['minimum_stall_free_start_s'],3)
    def test_buffer_absorbs_gap(self):
        r=diagnose(self.make([1,1,3.5]));self.assertEqual(r['simulated_stall_total_s'],.5);self.assertEqual(r['additional_initial_buffer_s'],.5)
    def test_incomplete_chunks_rejected(self):
        r=self.make([1,2]);r['audio_duration_s']=3
        with self.assertRaises(ValueError):diagnose(r)
if __name__=='__main__':unittest.main()
