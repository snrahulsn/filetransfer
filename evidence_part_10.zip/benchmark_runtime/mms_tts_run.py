"""Pinned MMS full-output baselines for ten requested locales."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import datetime,hashlib,json,pathlib,time,traceback
import numpy as np,soundfile as sf,torch
from transformers import AutoTokenizer,VitsModel
from snac_run import TEXTS
from stage_model import stage
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T18';OUT.mkdir(exist_ok=True)
torch.set_num_threads(4)
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while b:=f.read(8388608):h.update(b)
    return h.hexdigest()
def main():
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    texts={loc:text for loc,lang,text in TEXTS};texts['or-IN']='ଆପଣଙ୍କ ବୈଠକ କାଲି ଅପରାହ୍ନ ତିନିଟାରେ ଅଛି।'
    for job in json.loads((ROOT/'mms_tts_jobs.json').read_text()):
        locale=job['id'].removeprefix('T18-'); model=None
        try:
            manifest=json.loads((ROOT/(job['id']+'_download.json')).read_text());path=pathlib.Path(manifest['path'])
            path,staged=stage(path,job['id'])
            tokenizer=AutoTokenizer.from_pretrained(path,local_files_only=True)
            model=VitsModel.from_pretrained(path,local_files_only=True).to('cuda').eval()
            env=dict(model=job['repo'],revision=job['revision'],torch=torch.__version__,gpu=torch.cuda.get_device_name(0),
                runner_sha256=sha(__file__),weights_sha256=sha(path/'model.safetensors'),precision='float32',hf_offline=True,
                network_namespace_isolated=False,english_accent_verified=False)
            (OUT/f'environment-{locale}-{stamp}.json').write_text(json.dumps(env,indent=2))
            for i in range(104):
                rec=dict(run_id=stamp,locale=locale,text=texts[locale],index=i,phase='warmup' if i<3 else 'smoke' if i==3 else 'performance_c1',mode='full',synthesis_class='C',ok=False)
                try:
                    torch.manual_seed(20260924);torch.cuda.synchronize();start=time.perf_counter()
                    inputs=tokenizer(texts[locale],return_tensors='pt').to('cuda')
                    with torch.inference_mode():audio=model(**inputs).waveform[0].float().cpu().numpy()
                    torch.cuda.synchronize();elapsed=time.perf_counter()-start;sr=model.config.sampling_rate
                    if not len(audio) or not np.isfinite(audio).all():raise ValueError('Invalid waveform')
                    rec.update(ok=True,ttfa_s=elapsed,total_s=elapsed,audio_duration_s=len(audio)/sr,rtf=elapsed/(len(audio)/sr),sample_rate=sr)
                    if rec['phase']=='smoke':
                        file=OUT/f'{stamp}-{locale}.flac';sf.write(file,audio,sr,subtype='PCM_24');rec.update(file=str(file.relative_to(ROOT)),sha256=sha(file))
                except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
                with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
                if i<4 or not rec['ok']:print(json.dumps(rec,ensure_ascii=False),flush=True)
                if not rec['ok']:break
        except Exception as e:
            rec=dict(run_id=stamp,locale=locale,phase='initialization',ok=False,error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
            with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec)+'\n')
            print(json.dumps(rec),flush=True)
        finally:
            if model is not None:del model
            torch.cuda.empty_cache()
    (OUT/'DONE').write_text('Attempted 10 locale full-output smoke and 100 C1 trials per successful locale.\n')
if __name__=='__main__':main()
