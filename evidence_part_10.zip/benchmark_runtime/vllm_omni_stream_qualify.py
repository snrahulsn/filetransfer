"""Qualify vLLM-Omni raw-audio streaming for Qwen3-TTS Base and Fish S2."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import http.server
import json
import os
import pathlib
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request

import numpy as np
import soundfile as sf

from tts_delivery import diagnose


ROOT = pathlib.Path("/workspace/speechbench_20260924")
PYTHON = pathlib.Path("/tmp/vllm_omni_env/bin/python")
VLLM = pathlib.Path("/tmp/vllm_omni_env/bin/vllm")
TEXTS = {
    "hi-IN": "आपकी बैठक कल दोपहर तीन बजे है।",
    "en-IN": "Your meeting with Priya is tomorrow at three thirty PM.",
    "bn-IN": "আপনার মিটিং আগামীকাল দুপুর তিনটায়।",
    "mr-IN": "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.",
    "ta-IN": "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.",
    "te-IN": "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.",
    "gu-IN": "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.",
    "kn-IN": "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.",
    "ml-IN": "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.",
}


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args) -> None:
        pass


def readiness(port: int, process: subprocess.Popen, timeout: float = 900) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"vLLM-Omni server exited with {process.returncode}")
        for path in ("/health", "/v1/health", "/v1/models"):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=3) as response:
                    if response.status < 500:
                        return
            except (urllib.error.URLError, TimeoutError):
                pass
        time.sleep(3)
    raise TimeoutError("vLLM-Omni server did not become ready")


def request_audio(port: int, payload: dict, timeout: float = 600) -> tuple[bytes, list[dict], dict]:
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}/v1/audio/speech",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    began = time.perf_counter()
    pieces = []
    events = []
    with urllib.request.urlopen(request, timeout=timeout) as response:
        while True:
            block = response.read(4096)
            if not block:
                break
            pieces.append(block)
            events.append({"at_s": time.perf_counter() - began, "bytes": len(block), "samples": len(block) // 2})
        headers = dict(response.headers.items())
    return b"".join(pieces), events, {"status": response.status, "headers": headers, "total_s": time.perf_counter() - began}


def main(model_id: str) -> None:
    if not VLLM.is_file():
        raise FileNotFoundError(VLLM)
    download = json.loads((ROOT / f"{model_id}_download.json").read_text())
    if download.get("status") != "downloaded":
        raise RuntimeError(f"{model_id} pinned download is incomplete")
    model_path = pathlib.Path(download["path"])
    output = ROOT / model_id
    output.mkdir(exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    port = 18121 if model_id == "T12" else 18122
    log_path = output / f"vllm-omni-{stamp}.log"
    command = [str(VLLM), "serve", str(model_path), "--omni", "--port", str(port), "--trust-remote-code", "--enforce-eager", "--gpu-memory-utilization", "0.82"]
    process = None
    reference_server = None
    try:
        server_env = dict(
            os.environ,
            HF_HOME="/workspace/hf_cache",
            HF_HUB_CACHE="/workspace/hf_cache/hub",
            USE_TF="0",
            PATH=f"{VLLM.parent}:{os.environ.get('PATH', '')}",
        )
        with log_path.open("wb") as log:
            process = subprocess.Popen(command, cwd=ROOT, env=server_env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        readiness(port, process)
        if model_id == "T12":
            reference_record = json.loads((ROOT / "T12-ref_download.json").read_text())
            reference_dir = pathlib.Path(reference_record["path"]) / "adapters" / "hindi_female"
            handler = lambda *args, **kwargs: QuietHandler(*args, directory=str(reference_dir), **kwargs)
            reference_server = http.server.ThreadingHTTPServer(("127.0.0.1", 18123), handler)
            threading.Thread(target=reference_server.serve_forever, daemon=True).start()
            locales = ["en-IN"]
            sample_rate = 24000
        else:
            locales = list(TEXTS)
            sample_rate = 44100
        for locale in locales:
            payload = {
                "input": TEXTS[locale],
                "voice": "default",
                "response_format": "pcm",
                "stream": True,
                "stream_format": "audio",
                "max_new_tokens": 700,
            }
            if model_id == "T12":
                payload.update(task_type="Base", language="English", ref_audio="http://127.0.0.1:18123/ref.wav", ref_text=(reference_dir / "ref.txt").read_text().strip(), non_streaming_mode=False)
            raw, events, response = request_audio(port, payload)
            audio = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768
            if not len(audio):
                raise RuntimeError(f"{model_id} returned no audio for {locale}")
            duration = len(audio) / sample_rate
            normalized_events = [{"at_s": item["at_s"], "samples": item["samples"]} for item in events]
            record = {
                "run_id": stamp,
                "phase": "smoke",
                "locale": locale,
                "text": TEXTS[locale],
                "voice": "publisher reference" if model_id == "T12" else "default",
                "mode": "native_stream",
                "implementation": "vllm-omni raw audio streaming",
                "synthesis_class": "A",
                "ok": True,
                "sample_rate": sample_rate,
                "events": normalized_events,
                "chunk_events": normalized_events,
                "ttfa_s": events[0]["at_s"],
                "total_s": response["total_s"],
                "audio_duration_s": duration,
                "rtf": response["total_s"] / duration,
                "http_status": response["status"],
                "response_headers": response["headers"],
                "overlap_verified": len(events) > 1 and events[0]["at_s"] < response["total_s"],
            }
            record.update(**diagnose(record))
            target = output / f"{stamp}-vllm-omni-stream-{locale}.flac"
            sf.write(target, audio, sample_rate, subtype="PCM_24")
            record.update(file=str(target.relative_to(ROOT)), sha256=digest(target))
            with (output / "records.jsonl").open("a", encoding="utf-8") as target_file:
                target_file.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(json.dumps({key: record.get(key) for key in ("locale", "ok", "ttfa_s", "rtf", "chunk_count", "simulated_stall_count")}), flush=True)
        environment = {
            "run_id": stamp,
            "model_id": model_id,
            "repo": download["repo"],
            "revision": download["revision"],
            "model_path": str(model_path),
            "model_weight_sha256": digest(next(model_path.glob("model*.safetensors"))),
            "runner_sha256": digest(pathlib.Path(__file__)),
            "server_command": command,
            "vllm": subprocess.check_output([str(PYTHON), "-c", "import importlib.metadata as m;print(m.version('vllm'))"], text=True).strip(),
            "vllm_omni": subprocess.check_output([str(PYTHON), "-c", "import importlib.metadata as m;print(m.version('vllm-omni'))"], text=True).strip(),
            "mode": "native_stream",
            "log": str(log_path.relative_to(ROOT)),
        }
        (output / f"environment-vllm-omni-{stamp}.json").write_text(json.dumps(environment, indent=2))
    finally:
        if reference_server:
            reference_server.shutdown()
        if process and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=["T12", "T16"])
    main(parser.parse_args().model)
