"""VoxCPM2 native waveform streaming versus full-output synthesis."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import datetime,hashlib,importlib.metadata,json,pathlib,time,traceback
import numpy as np,soundfile as sf,torch
from voxcpm import VoxCPM
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T15';OUT.mkdir(exist_ok=True)
torch.set_num_threads(4)
TEXTS=[('hi-IN','आपकी बैठक कल दोपहर तीन बजे है।'),('en-IN','Your meeting with Priya is tomorrow at three thirty PM.')]
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while b:=f.read(8388608):h.update(b)
    return h.hexdigest()
def main():
    job=json.loads((ROOT/'T15_download.json').read_text());path=pathlib.Path(job['path'])
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    env=dict(run_id=stamp,model=job['repo'],revision=job['revision'],torch=torch.__version__,voxcpm=importlib.metadata.version('voxcpm'),gpu=torch.cuda.get_device_name(0),
        runner_sha256=sha(__file__),weights_sha256=sha(path/'model.safetensors'),codec_sha256=sha(path/'audiovae.pth'),hf_offline=True,network_namespace_isolated=False,
        cfg_value=2.0,inference_timesteps=10,torch_compile_enabled=os.environ.get('VOXCPM_OPTIMIZE','1')=='1',voice='default unconditioned',indian_english_accent_verified=False)
    (OUT/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    model=VoxCPM.from_pretrained(str(path),load_denoiser=False,optimize=env['torch_compile_enabled'],device='cuda',local_files_only=True)
    sr=model.tts_model.sample_rate
    for locale,text in TEXTS:
        for mode in ['full','stream']:
            for i in range(4):
                rec=dict(run_id=stamp,locale=locale,text=text,phase='warmup' if i<3 else 'smoke',mode=mode,index=i,ok=False,sample_rate=sr)
                try:
                    torch.manual_seed(20260924);torch.cuda.synchronize();start=time.perf_counter();events=[]
                    with torch.inference_mode():
                        if mode=='stream':
                            chunks=[]
                            for chunk in model.generate_streaming(text=text,cfg_value=2.0,inference_timesteps=10):
                                if isinstance(chunk,torch.Tensor):chunk=chunk.detach().float().cpu().numpy()
                                chunk=np.asarray(chunk).reshape(-1)
                                if len(chunk):chunks.append(chunk);events.append(dict(at_s=time.perf_counter()-start,samples=len(chunk)))
                            audio=np.concatenate(chunks)
                        else:
                            audio=model.generate(text=text,cfg_value=2.0,inference_timesteps=10)
                            if isinstance(audio,torch.Tensor):audio=audio.detach().float().cpu().numpy()
                            audio=np.asarray(audio).reshape(-1)
                    torch.cuda.synchronize();elapsed=time.perf_counter()-start
                    if not len(audio) or not np.isfinite(audio).all():raise ValueError('Invalid waveform')
                    rec.update(ok=True,total_s=elapsed,ttfa_s=events[0]['at_s'] if events else elapsed,rtf=elapsed/(len(audio)/sr),audio_duration_s=len(audio)/sr,
                        chunk_events=events,synthesis_class='A' if mode=='stream' and len(events)>1 else 'C',audio_before_generation_end=bool(events and events[0]['at_s']<elapsed))
                    if i==3:
                        file=OUT/f'{stamp}-{locale}-{mode}.flac';sf.write(file,audio,sr,subtype='PCM_24');rec.update(file=str(file.relative_to(ROOT)),sha256=sha(file))
                except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
                with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
                print(json.dumps({k:rec.get(k) for k in ['locale','phase','mode','ok','ttfa_s','rtf','error']}),flush=True)
                if not rec['ok']:break
    (OUT/'DONE').write_text('Hindi/English smoke attempted; remaining full qualification pending.\n')
if __name__=='__main__':main()
