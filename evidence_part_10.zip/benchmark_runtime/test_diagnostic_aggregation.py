import ast,json,pathlib,tempfile,unittest,hashlib
from aggregate_metrics import aggregate
class DiagnosticAggregationTests(unittest.TestCase):
    def test_invalidated_run_does_not_contaminate_corrected_run(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);folder=root/'A08';folder.mkdir()
            base=dict(locale='hi-IN',phase='coverage_sweep',mode='full_utterance',reference='एक दो',ok=True)
            old=dict(base,run_id='bad',hypothesis='गलत');new=dict(base,run_id='corrected',hypothesis='एक दो')
            prefix=(json.dumps(old)+'\n').encode();file=folder/'file_records.jsonl';file.write_bytes(prefix+(json.dumps(new)+'\n').encode())
            (folder/'run_validity.json').write_text(json.dumps(dict(records_file=file.name,records_prefix_bytes=len(prefix),records_prefix_sha256=hashlib.sha256(prefix).hexdigest(),invalid_runs={'bad':'Wrong preprocessing'})))
            result=aggregate(root);self.assertEqual(len(result),1);self.assertEqual(result[0]['run_id'],'corrected');self.assertEqual(result[0]['wer_failure_as_empty'],0)
    def test_classification_correction_is_bound_to_original_trace(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);folder=root/'T10';folder.mkdir()
            row=dict(run_id='r',locale='hi-IN',phase='smoke',mode='native_stream',ok=True,synthesis_class='C')
            raw=(json.dumps(row)+'\n').encode();file=folder/'records.jsonl';file.write_bytes(raw)
            correction=dict(records_file=file.name,records_prefix_bytes=len(raw),records_prefix_sha256=hashlib.sha256(raw).hexdigest(),
                corrections=[dict(row_number=1,run_id='r',locale='hi-IN',phase='smoke',synthesis_class='A',audio_before_final_result=True)])
            (folder/'classification_correction.json').write_text(json.dumps(correction))
            result=aggregate(root)[0];self.assertEqual(result['synthesis_classes'],'A');self.assertTrue(result['classification_corrected'])
            self.assertEqual(json.loads(file.read_text())['synthesis_class'],'C')
            file.write_bytes(raw.replace(b'"r"',b'"x"'))
            with self.assertRaises(ValueError):aggregate(root)
    def test_resume_preserves_identical_audio_in_distinct_configurations(self):
        tree=ast.parse(pathlib.Path(__file__).with_name('tts_intelligibility.py').read_text())
        function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='association_key')
        scope={};exec(compile(ast.Module(body=[function],type_ignores=[]),'<association_key>','exec'),scope)
        key=scope['association_key']
        base=dict(source_tts_model='T04',source_tts_mode='full',source_tts_run_id='r1',id='clip.flac',synthetic_audio_sha256='same')
        self.assertEqual(key(base),key(dict(base)))
        for field,value in [('source_tts_model','T18'),('source_tts_mode','stream'),('source_tts_run_id','r2'),('id','other.flac')]:
            self.assertNotEqual(key(base),key(dict(base,**{field:value})))
    def test_modes_and_source_models_remain_separate(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);(root/'A01').mkdir()
            base=dict(locale='hi-IN',phase='tts_intelligibility',mode='asr_on_generated_tts_full_utterance',run_id='asr-run',reference='एक दो',hypothesis='एक दो',ok=True)
            rows=[dict(base,source_tts_model=model,source_tts_mode=mode,source_tts_run_id='tts-run') for model,mode in [('T04','full'),('T04','native_stream'),('T18','full')]]
            (root/'A01/tts_intelligibility_records.jsonl').write_text('\n'.join(json.dumps(x) for x in rows)+'\n')
            result=aggregate(root)
            self.assertEqual(len(result),3)
            self.assertTrue(all(r['attempted']==1 and r['wer_failure_as_empty']==0 for r in result))
            self.assertTrue(all(not r['accuracy_protocol_complete'] for r in result))
if __name__=='__main__':unittest.main()
