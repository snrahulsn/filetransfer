"""Materialize the frozen ASR corpus on a fresh benchmark worker."""
from __future__ import annotations

import hashlib
import json
import pathlib
import shutil
import tarfile
import urllib.request

from huggingface_hub import hf_hub_download


ROOT = pathlib.Path("/workspace/speechbench_20260924/datasets")
FLEURS_REVISION = "70bb2e84b976b7e960aa89f1c648e09c59f894dd"
LANGUAGES = ("hi_in", "bn_in", "mr_in", "ta_in", "te_in", "gu_in", "kn_in", "ml_in", "or_in")
NPTEL_URL = (
    "https://github.com/AI4Bharat/NPTEL2020-Indian-English-Speech-Dataset/"
    "releases/download/v0.1/nptel-pure-set.tar.gz"
)


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def main() -> None:
    entries = []
    for language in LANGUAGES:
        name = f"parquet-data/{language}/test-00000-of-00001.parquet"
        cached = pathlib.Path(
            hf_hub_download(
                "google/fleurs",
                filename=name,
                repo_type="dataset",
                revision=FLEURS_REVISION,
                cache_dir="/workspace/hf_cache",
            )
        )
        target = ROOT / "google--fleurs" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.copyfile(cached, target)
        entries.append(
            {
                "file": str(target),
                "source": f"hf://datasets/google/fleurs@{FLEURS_REVISION}/{name}",
                "bytes": target.stat().st_size,
                "sha256": digest(target),
            }
        )
        print(json.dumps(entries[-1]), flush=True)

    archive = ROOT / "supplemental" / "nptel-pure-set.tar.gz"
    archive.parent.mkdir(parents=True, exist_ok=True)
    if not archive.exists():
        partial = archive.with_suffix(".part")
        request = urllib.request.Request(NPTEL_URL, headers={"User-Agent": "speechbench/1.0"})
        with urllib.request.urlopen(request, timeout=180) as source, partial.open("wb") as target:
            shutil.copyfileobj(source, target, 8 * 1024 * 1024)
        partial.replace(archive)
    extract_root = ROOT / "supplemental" / "nptel-pure-set"
    if not extract_root.exists():
        extract_root.mkdir(parents=True)
        with tarfile.open(archive, "r:gz") as bundle:
            bundle.extractall(extract_root, filter="data")
    entries.append(
        {
            "file": str(archive),
            "source": NPTEL_URL,
            "bytes": archive.stat().st_size,
            "sha256": digest(archive),
        }
    )
    (ROOT / "download_manifest.json").write_text(json.dumps(entries, indent=2))
    print(json.dumps(entries[-1]), flush=True)


if __name__ == "__main__":
    main()
