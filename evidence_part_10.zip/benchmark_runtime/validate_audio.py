"""Decode saved synthesis clips and verify physical integrity; no perceptual scoring."""
import datetime,hashlib,json,math,pathlib,time
import numpy as np,soundfile as sf
ROOT=pathlib.Path('/workspace/speechbench_20260924')
def main():
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();rows=[]
    for records in sorted(ROOT.glob('T*/records.jsonl')):
        for line in records.read_text().splitlines():
            source=json.loads(line)
            if source.get('phase')!='smoke' or not source.get('ok') or not source.get('file'):continue
            row=dict(model=records.parent.name,locale=source['locale'],file=source['file'],sha256=source['sha256'],ok=False)
            try:
                path=(ROOT/source['file']).resolve()
                if not path.is_relative_to(ROOT):raise ValueError('Path outside benchmark')
                if hashlib.sha256(path.read_bytes()).hexdigest()!=source['sha256']:raise ValueError('Checksum mismatch')
                audio,sr=sf.read(path,dtype='float64')
                if audio.ndim!=1 or sr!=source['sample_rate']:raise ValueError('Channel or sample-rate mismatch')
                if not len(audio) or not np.isfinite(audio).all():raise ValueError('Empty or nonfinite audio')
                if abs(len(audio)/sr-source['audio_duration_s'])>1/sr+1e-8:raise ValueError('Saved duration mismatch')
                peak=float(np.max(np.abs(audio)));rms=float(np.sqrt(np.mean(audio**2)))
                if peak==0:raise ValueError('All-zero waveform')
                frame=max(1,round(.01*sr));window=audio[:len(audio)//frame*frame].reshape(-1,frame)
                activity=np.flatnonzero(np.sqrt(np.mean(window**2,axis=1))>=.01)
                row.update(ok=True,sample_rate=sr,frames=len(audio),duration_s=len(audio)/sr,peak_abs=peak,rms_dbfs=20*math.log10(rms),
                    near_full_scale_samples=int(np.sum(np.abs(audio)>=.9999)),
                    first_10ms_frame_above_minus40_dbfs_s=float(activity[0]*frame/sr) if len(activity) else None)
            except Exception as e:row.update(error_type=type(e).__name__,error=str(e))
            rows.append(row)
    report=dict(started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        interpretation='Signal integrity only. The fixed RMS activity threshold is not speech detection, first audible speech, intelligibility, accent quality or MOS. Near-full-scale samples do not alone prove clipping.',
        checked=len(rows),failed=sum(not r['ok'] for r in rows),rows=rows)
    target=ROOT/'audio_validation.json';temporary=target.with_suffix('.json.part');temporary.write_text(json.dumps(report,indent=2));temporary.replace(target)
    print(json.dumps({k:report[k] for k in ['checked','failed','finished_utc']}),flush=True)
if __name__=='__main__':main()
