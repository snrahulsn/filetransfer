"""Bounded publisher-path TTS streaming qualification queue."""
from __future__ import annotations

import datetime as dt
import json
import os
import pathlib
import signal
import subprocess
import time


ROOT = pathlib.Path("/workspace/speechbench_20260924")
DEADLINE = float(os.environ["BENCH_DEADLINE_EPOCH"])
DEFAULT = "/workspace/tts_streaming_suite/.venv_gpu/bin/python"
JOBS = [
    ("T03", [DEFAULT, "kokoro_stream_qualify.py"], 600),
    ("T05", ["/tmp/speechbench_vllm_env/bin/python", "maya_vllm_stream_qualify.py"], 1200),
    ("T17", ["/tmp/xtts_env/bin/python", "xtts_stream_qualify.py"], 900),
    ("T12", ["/tmp/vllm_omni_env/bin/python", "vllm_omni_stream_qualify.py", "T12"], 1500),
    ("T16", ["/tmp/vllm_omni_env/bin/python", "vllm_omni_stream_qualify.py", "T16"], 1800),
]


def main() -> None:
    for name, command, timeout in JOBS:
        remaining = DEADLINE - time.time() - 900
        if remaining < 180:
            break
        record = {
            "job": name,
            "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "command": command,
            "timeout_s": min(timeout, int(remaining)),
        }
        with (ROOT / f"{name}-stream-qualification.log").open("ab") as log:
            process = subprocess.Popen(
                command,
                cwd=ROOT,
                env=dict(os.environ, HF_HOME="/workspace/hf_cache", HF_HUB_CACHE="/workspace/hf_cache/hub", USE_TF="0"),
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            try:
                process.wait(timeout=record["timeout_s"])
                record.update(exit_code=process.returncode, timed_out=False)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                record.update(exit_code=process.returncode, timed_out=True)
        record["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
        with (ROOT / "streaming_tts_outcomes.jsonl").open("a", encoding="utf-8") as target:
            target.write(json.dumps(record) + "\n")
        print(json.dumps(record), flush=True)


if __name__ == "__main__":
    main()
