"""Build a portable blind listening page from verified fresh successful clips."""
import argparse,hashlib,html,json,pathlib,random,shutil

PAGE='''<!doctype html><html lang="en"><meta charset="utf-8"><title>Indic speech listening review</title>
<style>body{font:17px system-ui;max-width:1000px;margin:40px auto;padding:0 24px;color:#17232b;background:#f7f8f9}h1{font-size:30px}article{padding:22px;background:white;border:1px solid #dce2e6;border-radius:12px;margin:20px 0}label{display:inline-block;margin:10px 18px 8px 0}select,input,button{font:inherit;padding:8px;border:1px solid #9eaeb8;border-radius:6px}audio{width:100%;margin:12px 0}button{background:#174d65;color:white;cursor:pointer}small{color:#4c5d66}.ratings{display:flex;flex-wrap:wrap}textarea{width:95%;font:inherit;padding:10px}header{position:sticky;top:0;background:#f7f8f9;padding:15px 0;border-bottom:1px solid #ddd}</style>
<h1>Blind speech listening test</h1><p>Play each clip and give one score: 1 Not usable · 2 Bad, usable only if no other option · 3 Decent, usable if no alternative · 4 Almost natural · 5 Perfect. Model identities are hidden.</p>
<header><label>Rater <input id="rater" value="owner"></label><label>Language <select id="language"><option value="">All languages</option></select></label><button id="export">Export ratings</button><p id="progress"></p><small id="storage-note"></small></header><main id="clips"></main>
<script>const clips=CLIPS_JSON;const storageKey='indic-listening-overall-'+PACKAGE_ID;
let state={};try{state=JSON.parse(localStorage.getItem(storageKey)||localStorage.getItem('indic-listening-overall-'+PREV_PACKAGE_ID)||'{}');const ids=new Set(clips.map(c=>c.id));state=Object.fromEntries(Object.entries(state).filter(([id])=>ids.has(id)))}catch(e){}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const language=document.getElementById('language');
const save=()=>{try{localStorage.setItem(storageKey,JSON.stringify(state))}catch(e){document.getElementById('storage-note').textContent='Autosave is unavailable. Export your ratings before closing this page.'}document.getElementById('progress').textContent=Object.values(state).filter(r=>r.Overall).length+' / '+clips.length+' clips rated';};
document.getElementById('language').innerHTML+=Array.from(new Set(clips.map(c=>c.locale))).sort().map(l=>'<option>'+esc(l)+'</option>').join('');
function render(){document.getElementById('clips').innerHTML=clips.filter(c=>!language.value||c.locale===language.value).map(c=>{const r=state[c.id]||{};return '<article data-id="'+c.id+'"><strong>'+c.id+' · '+esc(c.locale)+'</strong><p>'+esc(c.text)+'</p><audio controls preload="none" src="'+c.file+'"></audio><div class="ratings"><label>Overall score<br><select data-score><option value="">Choose 1–5</option>'+[1,2,3,4,5].map(v=>'<option '+(r.Overall===v?'selected':'')+' value="'+v+'">'+v+['',' — Not usable',' — Bad',' — Decent',' — Almost natural',' — Perfect'][v]+'</option>').join('')+'</select></label></div></article>'}).join('');
document.querySelectorAll('article').forEach(el=>{const id=el.dataset.id;el.querySelector('audio').addEventListener('ended',()=>{state[id]={...state[id],listened_to_end:true};save()});el.querySelector('[data-score]').onchange=e=>{state[id]={...state[id],Overall:e.target.value?Number(e.target.value):null,updated_at:new Date().toISOString()};save()}});save()}
language.onchange=render;render();
document.getElementById('export').onclick=()=>{const rater=document.getElementById('rater').value.trim();if(!rater){alert('Enter your rater label first.');return}const blob=new Blob([JSON.stringify({package_id:PACKAGE_ID,rater,exported_at:new Date().toISOString(),ratings:state},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='listening-ratings.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};
</script></html>'''

def build(root,out):
    clips=[];mapping=[]
    out.mkdir(parents=True,exist_ok=True);(out/'clips').mkdir(exist_ok=True)
    for records in sorted(root.glob('*/records.jsonl')):
        if 'initial_threading_attempt' in str(records):continue
        for line in records.read_text().splitlines():
            r=json.loads(line)
            if r.get('phase')=='warmup' or not r.get('ok') or not r.get('file'):continue
            source=root/r['file']
            actual=hashlib.sha256(source.read_bytes()).hexdigest()
            if actual!=r['sha256']:raise ValueError(f'Audio checksum mismatch: {source}')
            blind='C'+hashlib.sha256((str(records.parent.name)+r['file']+actual).encode()).hexdigest()[:10]
            dst=out/'clips'/(blind+source.suffix)
            shutil.copyfile(source,dst)
            clips.append(dict(id=blind,locale=r['locale'],text=r['text'],file='clips/'+dst.name))
            mapping.append(dict(id=blind,locale=r['locale'],text=r['text'],model_id=records.parent.name,source_file=r['file'],sha256=actual,mode=r['mode'],voice=r.get('voice'),run_id=r.get('run_id'),prompt_sha256=hashlib.sha256(r['text'].encode()).hexdigest()))
    random.Random(20260924).shuffle(clips)
    package_id=hashlib.sha256(json.dumps(mapping,sort_keys=True).encode()).hexdigest()
    # Prevent script-tag termination by text supplied in transcripts.
    safe=json.dumps(clips,ensure_ascii=False).replace('<','\\u003c')
    page=PAGE.replace('CLIPS_JSON',safe).replace('PREV_PACKAGE_ID',json.dumps(package_id)).replace('PACKAGE_ID',json.dumps(package_id))
    (out/'index.html').write_text(page)
    (out/'blind_key.json').write_text(json.dumps(mapping,indent=2))
    (out/'package_manifest.json').write_text(json.dumps(dict(package_id=package_id,clip_count=len(clips),rating_scope='single listener; one overall 1-5 score per clip'),indent=2))
    return len(clips)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);p.add_argument('out',type=pathlib.Path);a=p.parse_args()
    print(build(a.root,a.out))
