"""Pinned VibeVoice-ASR-Streaming evaluation on Indian-English speech."""
import argparse
import datetime
import hashlib
import json
import pathlib
import resource
import time
import traceback

import torch

from asr_corpus import records
from metrics import score
from vibevoice.modular.modeling_vibevoice_asr import VibeVoiceASRForConditionalGeneration
from vibevoice.processor.vibevoice_asr_processor import VibeVoiceASRProcessor

ROOT = pathlib.Path("/workspace/speechbench_20260924")
SOURCE_REVISION = "1541f590c7099820f10ea012f48d2399282df69f"


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def main(limit: int) -> None:
    manifest = json.loads((ROOT / "A13_download.json").read_text())
    model_path = pathlib.Path(manifest["path"])
    frame_cfg = json.loads((model_path / "preprocessor_config.json").read_text())
    sample_rate = frame_cfg["target_sample_rate"]
    frame_seconds = frame_cfg["speech_tok_compress_ratio"] / sample_rate
    chunk_duration = frame_cfg["chunk_frames"] * frame_seconds
    lookahead_duration = frame_cfg["lookahead_frames"] * frame_seconds
    output = ROOT / "A13"
    output.mkdir(exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    started = time.perf_counter()
    processor = VibeVoiceASRProcessor.from_pretrained(model_path, local_files_only=True)
    model = VibeVoiceASRForConditionalGeneration.from_pretrained(
        model_path,
        torch_dtype=torch.bfloat16,
        attn_implementation="sdpa",
        local_files_only=True,
    ).to("cuda").eval()
    initialized = time.perf_counter() - started

    environment = {
        "run_id": stamp,
        "model": manifest["repo"],
        "model_revision": manifest["revision"],
        "source_revision": SOURCE_REVISION,
        "weights": {file.name: sha256(file) for file in sorted(model_path.glob("*.safetensors"))},
        "runner_sha256": sha256(pathlib.Path(__file__)),
        "mode": "native_incremental_stream_paced_by_model_chunks",
        "precision": "bfloat16",
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0),
        "model_initialization_s": initialized,
        "evaluation_limit_per_locale": limit,
        "sample_rate": sample_rate,
        "chunk_duration_s": chunk_duration,
        "lookahead_duration_s": lookahead_duration,
        "local_files_only": True,
    }
    (output / f"environment-{stamp}.json").write_text(json.dumps(environment, indent=2))

    def infer(audio):
        events = []
        parts = []
        began = time.perf_counter()
        for chunk_index, total_chunks, chunk_text in model.streaming_generate(
            audio_tensor=torch.from_numpy(audio),
            tokenizer=processor.tokenizer,
            chunk_duration=chunk_duration,
            text_audio_delay=lookahead_duration,
            sample_rate=sample_rate,
            max_new_tokens_per_chunk=256,
            temperature=0.0,
        ):
            text = str(chunk_text)
            parts.append(text)
            events.append({
                "at_s": time.perf_counter() - began,
                "chunk_index": int(chunk_index),
                "total_chunks": int(total_chunks),
                "text": text,
            })
        return "".join(parts), events, time.perf_counter() - began

    first = next(records(["en-IN"], limit=1))
    for _ in range(3):
        with torch.inference_mode():
            infer(first["audio"])

    record_file = output / "stream_records.jsonl"
    for row in records(["en-IN"], limit=limit):
        record = {key: value for key, value in row.items() if key != "audio"}
        record.update(
            run_id=stamp,
            phase="streaming_smoke",
            mode="native_incremental_stream_paced_by_model_chunks",
            ok=False,
            chunk_duration_s=chunk_duration,
            lookahead_duration_s=lookahead_duration,
        )
        try:
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            with torch.inference_mode():
                hypothesis, events, elapsed = infer(row["audio"])
            torch.cuda.synchronize()
            duration = len(row["audio"]) / sample_rate
            nonempty = [event["at_s"] for event in events if event["text"].strip()]
            record.update(
                ok=True,
                hypothesis=hypothesis,
                events=events,
                first_partial_s=min(nonempty) if nonempty else None,
                total_s=elapsed,
                audio_duration_s=duration,
                rtf=elapsed / duration,
                peak_torch_allocated_bytes=torch.cuda.max_memory_allocated(),
                peak_torch_reserved_bytes=torch.cuda.max_memory_reserved(),
                process_lifetime_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                **score(row["reference"], hypothesis),
            )
        except Exception as error:
            record.update(
                hypothesis="",
                events=[],
                error_type=type(error).__name__,
                error=str(error),
                traceback=traceback.format_exc(),
                **score(row["reference"], ""),
            )
        with record_file.open("a", encoding="utf-8") as target:
            target.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(json.dumps({key: record.get(key) for key in ("id", "ok", "wer", "rtf", "first_partial_s", "error")}), flush=True)
    (output / f"DONE-{stamp}").write_text(json.dumps({"model": "A13", "limit": limit}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=3)
    main(parser.parse_args().limit)
