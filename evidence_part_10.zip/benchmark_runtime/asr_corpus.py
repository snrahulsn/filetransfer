"""Common, explicitly identified test inputs for all ASR backends."""
import hashlib,io,json,math,pathlib
import numpy as np
import pyarrow.parquet as pq
import soundfile as sf
from scipy.signal import resample_poly

ROOT=pathlib.Path('/workspace/speechbench_20260924/datasets')
REGIONAL=['hi-IN','bn-IN','mr-IN','ta-IN','te-IN','gu-IN','kn-IN','ml-IN','or-IN']

def local_parquet(file):
    target=pathlib.Path('/tmp/benchmark_corpus')/file.parent.name/file.name
    if target.exists():return target
    target.parent.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((ROOT/'download_manifest.json').read_text())
    entry=next(x for x in manifest if x['file'].endswith(file.parent.name+'/'+file.name))
    h=hashlib.sha256();part=target.with_suffix('.part')
    with file.open('rb') as inp,part.open('wb') as out:
        while chunk:=inp.read(8388608):h.update(chunk);out.write(chunk)
    if h.hexdigest()!=entry['sha256']:raise ValueError('Corpus staging digest mismatch')
    part.replace(target)
    return target

def condition_audio(audio,condition):
    if condition=='clean':return audio
    if condition not in ['g711_mulaw','g711_alaw']:raise ValueError(condition)
    import audioop
    low=resample_poly(audio,1,2)
    pcm=np.rint(np.clip(low,-1,1-1/32768)*32768).astype('<i2').tobytes()
    if condition=='g711_mulaw':packed=audioop.lin2ulaw(pcm,2);decoded=audioop.ulaw2lin(packed,2)
    else:packed=audioop.lin2alaw(pcm,2);decoded=audioop.alaw2lin(packed,2)
    return resample_poly(np.frombuffer(decoded,dtype='<i2').astype(np.float32)/32768,2,1).astype(np.float32)

def records(locales=None,limit=None,condition='clean'):
    locales=locales or REGIONAL+['en-IN']
    for locale in locales:
        if locale=='en-IN':
            root=ROOT/'supplemental/nptel-pure-set/nptel-pure'
            files=sorted((root/'corrected_txt').glob('*.txt'))
            if len(files)!=1000:raise ValueError('Expected all 1000 corrected NPTEL Pure Set references')
            for i,text in enumerate(files):
                if limit is not None and i>=limit:break
                file=root/'wav'/(text.stem+'.wav');raw=file.read_bytes()
                audio,sr=sf.read(io.BytesIO(raw),dtype='float32')
                if sr!=16000 or audio.ndim!=1:raise ValueError('Unexpected NPTEL audio format')
                reference=text.read_text(encoding='utf-8').strip()
                yield dict(id='nptel-pure/v0.1/'+text.stem,locale=locale,index=i,reference=reference,
                    dataset='NPTEL2020 Pure Set',dataset_revision='v0.1; archive cad8b68cce78adb4af2b432a2112d43c4c4425b0762564db20a03c3263bc051e',
                    condition=condition,original_audio_sha256=hashlib.sha256(raw).hexdigest(),audio=condition_audio(audio,condition))
        else:
            lang=locale[:2]+'_in';file=ROOT/'google--fleurs/parquet-data'/lang/'test-00000-of-00001.parquet'
            file=local_parquet(file)
            index=0
            for batch in pq.ParquetFile(file).iter_batches(batch_size=8):
                for row in batch.to_pylist():
                    if limit is not None and index>=limit:break
                    raw=row['audio']['bytes'];audio,sr=sf.read(io.BytesIO(raw),dtype='float32')
                    if sr!=16000 or audio.ndim!=1:raise ValueError('Unexpected FLEURS format')
                    yield dict(id=f'fleurs/{lang}/test/{index}',locale=locale,index=index,reference=row['transcription'],
                        raw_reference=row['raw_transcription'],dataset='google/fleurs',dataset_revision='70bb2e84b976b7e960aa89f1c648e09c59f894dd',
                        condition=condition,original_audio_sha256=hashlib.sha256(raw).hexdigest(),audio=condition_audio(audio,condition))
                    index+=1
                if limit is not None and index>=limit:break
