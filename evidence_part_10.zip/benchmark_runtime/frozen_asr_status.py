"""Report and materialize exact frozen ASR rows from preserved raw records."""
from __future__ import annotations

import argparse
import json
import pathlib


ROOT = pathlib.Path("/workspace/speechbench_20260924")
STREAMING = {"A01", "A02", "A07", "A09", "A13"}
MODELS = [f"A{i:02d}" for i in range(1, 16)]


def read_jsonl(path: pathlib.Path) -> list[dict]:
    if not path.is_file():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return rows


def main(write: bool) -> None:
    manifest = json.loads((ROOT / "asr_frozen_manifest.json").read_text())
    expected = {row["id"]: row for row in manifest["rows"]}
    summary = {}
    for model in MODELS:
        filename = "stream_records.jsonl" if model in STREAMING else "file_records.jsonl"
        candidates = read_jsonl(ROOT / model / filename)
        selected = {}
        for row in candidates:
            want = expected.get(row.get("id"))
            if not want or not row.get("ok") or row.get("condition", "clean") != "clean":
                continue
            if row.get("reference") != want.get("reference"):
                continue
            if row.get("original_audio_sha256") != want.get("original_audio_sha256"):
                continue
            if model == "A01" and row.get("lookahead_ms") != 480:
                continue
            if model in {"A07", "A09"} and row.get("mode") != "publisher_buffered_retranscription":
                continue
            selected[row["id"]] = row
        output = sorted(selected.values(), key=lambda row: (row["locale"], row["index"]))
        if write and output:
            target = ROOT / model / "frozen_records.jsonl"
            target.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in output))
        per_locale = {}
        for locale in manifest["locales"]:
            per_locale[locale] = sum(row["locale"] == locale for row in output)
        summary[model] = {"rows": len(output), "per_locale": per_locale, "source": filename}
    (ROOT / "asr_frozen_status.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    main(parser.parse_args().write)
