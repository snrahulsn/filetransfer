"""Sequential extensible queue under an externally enforced fixed lease deadline."""
import datetime,json,os,pathlib,signal,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924');deadline=float(os.environ['BENCHMARK_DEADLINE'])
out=ROOT/'resume_outcomes.jsonl';done=set()
if out.exists():done={json.loads(x)['job'] for x in out.read_text().splitlines()}
empty_since=None
while time.time()<deadline-180:
    jobs=json.loads((ROOT/'resume_jobs.json').read_text());pending=[j for j in jobs if j['id'] not in done]
    if not pending:
        if empty_since is None:empty_since=time.time()
        if time.time()-empty_since>300:break
        time.sleep(5);continue
    empty_since=None;j=pending[0];remaining=deadline-time.time()-180
    if remaining<60:break
    rec=dict(job=j['id'],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=j['command'],timeout_s=min(j['timeout_seconds'],remaining))
    print('Starting '+j['id'],flush=True)
    with (ROOT/(j['id']+'.log')).open('ab') as log:
        proc=subprocess.Popen(j['command'],cwd=ROOT,env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',USE_TF='0',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',**j.get('environment',{})),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:proc.wait(timeout=rec['timeout_s']);rec.update(exit_code=proc.returncode,timed_out=False)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            rec.update(exit_code=proc.returncode,timed_out=True)
    try:os.killpg(proc.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    for file in [out,ROOT/'queue_outcomes.jsonl']:
        with file.open('a') as f:f.write(json.dumps(rec)+'\n')
    done.add(j['id']);print(json.dumps(rec),flush=True)
print('Queue exited within fixed lease window',flush=True)
