#!/usr/bin/env python3
import argparse, pathlib, shutil, torch
from qwen_tts import Qwen3TTSModel
from peft import PeftModel
from peft.tuners.lora.layer import LoraLayer
p=argparse.ArgumentParser(); p.add_argument("--base",required=True); p.add_argument("--adapter",required=True); p.add_argument("--out",required=True); p.add_argument("--scale",type=float,default=.35); a=p.parse_args()
out=pathlib.Path(a.out); shutil.rmtree(out,ignore_errors=True)
print("LOAD",flush=True)
w=Qwen3TTSModel.from_pretrained(a.base,device_map="cpu",dtype=torch.bfloat16,attn_implementation="sdpa",local_files_only=True)
print("ADAPTER",flush=True)
pmodel=PeftModel.from_pretrained(w.model,a.adapter,is_trainable=False,local_files_only=True)
layers=0
for m in pmodel.modules():
    if isinstance(m,LoraLayer): m.scale_layer(a.scale); layers+=1
if not layers: raise RuntimeError("no LoRA layers")
print("MERGE",layers,flush=True)
merged=pmodel.merge_and_unload(safe_merge=True)
base_root = pathlib.Path(a.base).resolve()
def ignore_root_models(src, names):
    if pathlib.Path(src).resolve() != base_root:
        return []
    return [n for n in names if n == "adapters" or n == "model.safetensors" or n.startswith("model-") or n == "model.safetensors.index.json"]
shutil.copytree(a.base,out,ignore=ignore_root_models)
from safetensors.torch import save_model
save_model(merged, out / "model.safetensors", metadata={"format": "pt"})
print("DONE",out,flush=True)
