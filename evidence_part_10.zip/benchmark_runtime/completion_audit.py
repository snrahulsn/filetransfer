"""Rebuild the explicit incomplete PRD gate audit from current retained evidence.
This is an audit report, not a replacement for the PRD's final release validator.
"""
import datetime,hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parents[1];E=ROOT/'execution'
GAPS={
'G01':('All34 seed entries are present; a frozen approved expanded configuration/cell plan and discovery closure are absent.','LANGUAGE_COVERAGE.md'),
'G02':('38 recorded environment runner hashes match retained code. This does not resolve every required configuration, voice, adapter, backend and input identity across the complete planned scope.','execution/runner_provenance.json'),
'G03':('Source licence declarations and access probes exist; intended-use and redistribution approvals remain unresolved. Authentication is not a rights approval.','BENCHMARK_PROGRESS.md'),
'G04':('Public corpora and small code-switch samples exist. Native-reviewed release texts/domain/entity data, complete paired conditions and independent-test provenance are incomplete.','indic_speech_benchmark_prd_v1/inputs_required.md'),
'G05':('Successful small ASR trials exist; full eligible test splits and conditions are not executed. A setup timeout cannot close every unattempted sample in a configuration.','MEASURED_RESULTS.md'),
'G06':('Executed streams have source/event evidence and separated producer classes. Classification, continuity, cancellation, isolation and long-session proof are incomplete for the full scope.','execution/metrics_current/stream_diagnostics.json'),
'G07':('Reference RTX4090 and scoped resource/timing observations exist. Controlled concurrency, cold-start and full CPU/GPU qualification are incomplete; deployment hardware remains TBD.','MEASURED_RESULTS.md'),
'G08':('70 successful smoke clips are saved; zero human ratings. Complete release prompts/voices/modes and independent qualified raters/QC are missing.','execution/evidence_integrity.json'),
'G09':('Counts, normalization and invalid-run exclusions are preserved. Full sample denominators, uncertainty, significance and independent statistical review remain incomplete.','execution/metrics_current/measured_metrics.json'),
'G10':('Offline progress/metric regeneration and source hashing work. Full per-configuration reproducible snippets and independent rebuild verification remain incomplete.','execution/runner_provenance.json'),
'G11':('Markdown and machine-readable progress artifacts exist. Final HTML/PDF/export agreement, complete audio-link verification and complete-coverage presentation are not established.','BENCHMARK_PROGRESS.md'),
'G12':('Starter-package hashes and retained audio/source integrity checks pass. A final checksummed public/private release, complete notices and rights/privacy review are unfinished.','execution/evidence_integrity.json')}
def main():
    prd=ROOT/'indic_speech_benchmark_prd_v1/PRD.md';gates=[]
    for line in prd.read_text().splitlines():
        if not re.match(r'^\| G[0-9]{2} ',line):continue
        title,requirement=[x.strip() for x in line.strip('|').split('|')];key=title.split()[0]
        reason,path=GAPS[key];file=ROOT/path
        if not file.is_file():raise ValueError('Required audit evidence absent: '+path)
        gates.append(dict(id=key,title=title,requirement=requirement,status='incomplete',completion_proven=False,finding=reason,evidence=path,evidence_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
    if len(gates)!=12:raise ValueError('Unexpected PRD gate count; audit must be updated')
    stop=json.loads((E/'final_shutdown_verification.json').read_text());integrity=json.loads((E/'evidence_integrity.json').read_text())
    result=dict(audited_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),prd_sha256=hashlib.sha256(prd.read_bytes()).hexdigest(),scope='Original 34-entry PRD, all eligible configurations and ten target locales; scope has not been reduced to smoke trials',release_complete=False,audit_kind='Evidence-backed interim audit; not a final release validator',all_pods_stopped_at_recorded_verification=stop['all_stopped'],integrity_errors=integrity['errors'],gates=gates)
    (E/'completion_audit.json').write_text(json.dumps(result,indent=2))
    lines=['# Completion audit — incomplete','',f"Audited {result['audited_at_utc']}. The original PRD scope remains unchanged. No complete-release claim is supported.",'','All 12 gates below require full-scope evidence. Passing a local integrity check or completing a smoke test does not pass the corresponding release gate. This audit is not a substitute for the final expected-cell release validator.','','| Gate | Required evidence | Current finding |','|---|---|---|']
    for g in gates:lines.append(f"| {g['title']} | {g['requirement']} | {g['finding']} [Evidence]({g['evidence']}). |")
    lines+=['','Operational safety is separately verified: all six account pods were EXITED with null runtime at the recorded shutdown check. Estimated compute is $3.969319; final billing is unreconciled and the retained network volume may incur storage charges. See [shutdown evidence](execution/final_shutdown_verification.json).','','The next machine-evaluation work is to complete the expanded plan and remaining adapters, then execute full eligible runs under a resolved compute allowance. The specific larger-budget and contact-sharing confirmations remain pending after automatic approval review rejection. Native review, intended-use approvals, qualified human ratings and deployment capacity inputs cannot be invented. No missing model is an approved exclusion.','','[Current required inputs](indic_speech_benchmark_prd_v1/inputs_required.md) · [Machine-readable audit with evidence hashes](execution/completion_audit.json)','']
    (ROOT/'COMPLETION_AUDIT.md').write_text('\n'.join(lines))
    print(json.dumps({'gates':len(gates),'release_complete':False,'artifact':'COMPLETION_AUDIT.md'}))
if __name__=='__main__':main()
