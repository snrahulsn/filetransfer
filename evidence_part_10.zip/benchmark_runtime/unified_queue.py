"""Bounded sequential recovery queue; one GPU workload, explicit failures."""
import datetime,json,os,pathlib,shutil,signal,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924')
PY='/workspace/tts_streaming_suite/.venv_gpu/bin/python'
ENV=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',USE_TF='0',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
JOBS=[('T18',[PY,'mms_tts_run.py'],{},600),('T03',[PY,'kokoro_run.py'],{},600),
 ('T15',[str(ROOT/'envs/voxcpm/bin/python'),'voxcpm_run.py'],{},900),
 ('T15-eager',[str(ROOT/'envs/voxcpm/bin/python'),'voxcpm_run.py'],dict(VOXCPM_OPTIMIZE='0'),900),
 ('A09-subset',[str(ROOT/'envs/qwen_asr/bin/python'),'asr_baselines.py','A09','--limit','25'],{},900),
 ('A09-stream',[ '/tmp/speechbench_vllm_env/bin/python','qwen_stream_run.py','A09'],{},1200),
 ('A07-stream',[ '/tmp/speechbench_vllm_env/bin/python','qwen_stream_run.py','A07'],{},1200),
 ('A02',[str(ROOT/'envs/voxcpm/bin/python'),'voxtral_asr_run.py'],{},1200),
 ('T07',[PY,'snac_run.py','veena'],{},600),('T05',[PY,'snac_run.py','maya1'],{},600),
 ('T08',[PY,'indic_f5_run.py'],{},600),
 ('T06',[str(ROOT/'envs/voxcpm/bin/python'),'bodhan_run.py'],{},900),
 ('T09',[PY,'sooktam_run.py'],{},600),
 ('T10',['/tmp/speechbench_omni_env/bin/python','voxtral_tts_run.py'],{},900),
 ('T01',[PY,'snac_run.py','svara'],{},900),
 ('A01-stream-resume',[PY,'sravaani_run.py'],dict(ASR_STAGE='stream'),600),
 ('A01-file',[PY,'sravaani_run.py'],dict(ASR_STAGE='file'),600)]
for model in ['A08','A15','A03','A04','A10','A07','A09']:
    JOBS.append((model+('-coverage' if model=='A09' else '-subset'),[str(ROOT/'envs/qwen_asr/bin/python') if model in ['A07','A09'] else PY,'asr_baselines.py',model,'--limit','25'],{},600))
for model in ['A09','A07','A08','A15','A03','A10','A04']:
    JOBS.append((model+'-full',[str(ROOT/'envs/qwen_asr/bin/python') if model in ['A07','A09'] else PY,'asr_baselines.py',model],{},1800))
JOBS.append(('A08-retry',[PY,'asr_baselines.py','A08','--limit','25'],{},600))
JOBS.append(('A08-padding-fixed',[PY,'asr_baselines.py','A08','--limit','25'],{},600))
# Give the prepared offline ASR families coverage before another slow SNAC sweep.
# This changes priority only; every queued configuration and the fixed lease remain.
priority=['T18','T03','T15','T15-eager','A09-subset','A09-stream','A07-stream','A02','T07','T05','T08','T06','T09','T10',
          'A08-subset','A15-subset','A08-retry','A03-subset','A08-padding-fixed','A04-subset','A01-stream-resume','A01-file','T01','A10-subset','A07-subset','A09-coverage']
order={name:i for i,name in enumerate(priority)}
JOBS.sort(key=lambda job:order.get(job[0],len(order)))
def main():
    cursor=os.environ.get('QUEUE_START_AFTER');ready=not cursor
    for name,cmd,extra,limit in JOBS:
        if not ready:
            if name==cursor:ready=True
            continue
        remaining=1790212651-time.time()
        if remaining<180:break
        rec=dict(job=name,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeout_s=min(limit,remaining-120),command=cmd)
        print('Starting '+name,flush=True)
        with (ROOT/(name+'-recovery.log')).open('ab') as log:
            proc=subprocess.Popen(cmd,env=dict(ENV,**extra),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:proc.wait(timeout=rec['timeout_s']);rec.update(exit_code=proc.returncode,timed_out=False)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGTERM)
                try:proc.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                rec.update(exit_code=proc.returncode,timed_out=True)
        rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        # The per-job session also owns any backend worker children.
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        model_id=name.split('-')[0]
        for parent in ['/tmp/asr_model_stage','/tmp/benchmark_model_stage']:
            staged=pathlib.Path(parent)/model_id
            if staged.is_dir() and not staged.is_symlink():shutil.rmtree(staged)
        with (ROOT/'queue_outcomes.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
        print(json.dumps(rec),flush=True)
if __name__=='__main__':main()
