"""Resolve the predeclared ASR sample selection before any model inference."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import pathlib

from asr_corpus import records


ROOT = pathlib.Path("/workspace/speechbench_20260924")
LOCALES = ["hi-IN", "en-IN", "bn-IN", "mr-IN", "ta-IN", "te-IN", "gu-IN", "kn-IN", "ml-IN", "or-IN"]


def main() -> None:
    rows = []
    for locale in LOCALES:
        for row in records([locale], limit=10, condition="clean"):
            rows.append({key: value for key, value in row.items() if key != "audio"})
    if len(rows) != 100:
        raise ValueError(f"Expected 100 frozen samples, found {len(rows)}")
    payload = {
        "schema_version": 1,
        "materialized_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "selection_made_without_model_outputs": True,
        "clips_per_locale": 10,
        "locales": LOCALES,
        "rows": rows,
    }
    canonical = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    payload["rows_sha256"] = hashlib.sha256(canonical).hexdigest()
    target = ROOT / "asr_frozen_manifest.json"
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2))
    print(json.dumps({"path": str(target), "rows": len(rows), "rows_sha256": payload["rows_sha256"]}))


if __name__ == "__main__":
    main()
