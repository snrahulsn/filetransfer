"""Download and extract the publisher-hosted IndicWhisper checkpoints."""
import argparse
import datetime
import hashlib
import json
import pathlib
import urllib.request
import zipfile

ROOT = pathlib.Path("/workspace/speechbench_20260924")


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def remote_etag(url: str) -> str:
    request = urllib.request.Request(
        url, headers={"User-Agent": "speechbench/1.0"}, method="HEAD"
    )
    with urllib.request.urlopen(request, timeout=120) as response:
        return response.headers.get("ETag", "")


def download(url: str, destination: pathlib.Path) -> str:
    partial = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "speechbench/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response, partial.open("wb") as target:
        etag = response.headers.get("ETag", "")
        while chunk := response.read(8 * 1024 * 1024):
            target.write(chunk)
    partial.replace(destination)
    return etag


def main(selected: set[str]) -> None:
    assets = json.loads((ROOT / "a14_assets.json").read_text())
    archive_dir = ROOT / "models" / "A14" / "archives"
    extract_root = ROOT / "models" / "A14" / "extracted"
    archive_dir.mkdir(parents=True, exist_ok=True)
    extract_root.mkdir(parents=True, exist_ok=True)
    results = []
    for asset in assets:
        if selected and asset["locale"] not in selected:
            continue
        archive = archive_dir / f'{asset["language"]}_models.zip'
        observed_etag = remote_etag(asset["url"])
        if observed_etag != asset["etag"]:
            raise RuntimeError(
                f'{asset["locale"]}: expected ETag {asset["etag"]}, '
                f"publisher returned {observed_etag}"
            )
        if not archive.exists() or archive.stat().st_size != asset["content_length"]:
            response_etag = download(asset["url"], archive)
            if response_etag and response_etag != asset["etag"]:
                raise RuntimeError(
                    f'{asset["locale"]}: download ETag changed to {response_etag}'
                )
        if archive.stat().st_size != asset["content_length"]:
            raise RuntimeError(
                f'{asset["locale"]}: expected {asset["content_length"]} bytes, '
                f"received {archive.stat().st_size}"
            )
        destination = extract_root / asset["language"]
        destination.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive) as bundle:
            corrupt = bundle.testzip()
            if corrupt:
                raise RuntimeError(f'{asset["locale"]}: corrupt ZIP member {corrupt}')
            bundle.extractall(destination)
        model_dirs = sorted(
            {config.parent for config in destination.rglob("config.json")}
        )
        if not model_dirs:
            raise RuntimeError(f'{asset["locale"]}: no Transformers checkpoint found')
        result = {
            **asset,
            "archive": str(archive),
            "archive_sha256": sha256(archive),
            "archive_bytes": archive.stat().st_size,
            "model_directories": [str(path) for path in model_dirs],
            "downloaded_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "status": "downloaded_and_extracted",
        }
        results.append(result)
        print(json.dumps(result), flush=True)
    (ROOT / "A14_download.json").write_text(json.dumps(results, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--locales",
        nargs="*",
        help="Optional locale subset such as hi-IN bn-IN; default downloads all nine.",
    )
    args = parser.parse_args()
    main(set(args.locales or []))
