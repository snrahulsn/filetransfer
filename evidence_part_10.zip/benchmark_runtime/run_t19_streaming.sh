#!/usr/bin/env bash
set -euo pipefail
export CUDA_HOME=/tmp/sgl/lib/python3.11/site-packages/nvidia/cu13
export PATH=$CUDA_HOME/bin:$PATH
export LD_LIBRARY_PATH=$CUDA_HOME/lib:${LD_LIBRARY_PATH:-}
export PYTORCH_ALLOC_CONF=expandable_segments:True
for pair in bn-IN:bengali_female mr-IN:marathi_female ta-IN:tamil_female te-IN:telugu_female gu-IN:gujarati_female kn-IN:kannada_female ml-IN:malayalam_female or-IN:odia_female; do
  loc=${pair%%:*}; adapter=${pair#*:}; log=/workspace/logs/T19-${loc}-server.log
  for gpu_pid in $(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits); do kill -9 "$gpu_pid" 2>/dev/null || true; done
  sleep 2
  : > "$log"
  nohup /tmp/sgl/bin/sgl-omni serve --model-path "/workspace/merged/T19-$loc" --config /workspace/qwen_tts_24gb.yaml --port 8000 --allowed-local-media-path /workspace > "$log" 2>&1 & pid=$!
  ready=0
  for i in $(seq 1 36); do
    if curl -sf http://127.0.0.1:8000/health >/dev/null; then ready=1; break; fi
    if ! kill -0 "$pid" 2>/dev/null; then tail -n 100 "$log"; exit 1; fi
    sleep 5
  done
  if [ "$ready" != 1 ]; then tail -n 100 "$log"; exit 2; fi
  for pass in warm measured; do
    /tmp/sgl/bin/python /workspace/speechbench_20260924/sgl_stream_benchmark.py T19 --port 8000 --sample-rate 24000 --model "/workspace/merged/T19-$loc" --checkpoint aguken-ai/Qwen3-TTS-0.6B-LoRA-Finetuned-Indic-Multilingual --revision 5450c7fc7b497d19209e202bf55b825c98b2b312 --ref-audio "/workspace/models/T19/adapters/$adapter/ref.wav" --ref-text-file "/workspace/models/T19/adapters/$adapter/ref.txt" --locales "$loc"
  done
  kill -TERM "$pid" 2>/dev/null || true
  sleep 3
  pkill -9 -f "sglang_omni|sgl-omni" 2>/dev/null || true
  for gpu_pid in $(nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits); do kill -9 "$gpu_pid" 2>/dev/null || true; done
  sleep 2
  echo "DONE $loc"
done
