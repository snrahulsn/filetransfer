"""Publisher Sooktam safetensors configuration, strict weight loading, local CLS."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import datetime,hashlib,json,pathlib,shutil,sys,time,traceback
import numpy as np,soundfile as sf,torch
from snac_run import TEXTS,digest
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T09'
SOURCE=pathlib.Path('/workspace/sooktam2_qual/model_cache/sooktam2');TARGET=pathlib.Path('/tmp/benchmark_model_stage/T09')
PIN='eb270c0ceebd58e0e513820eb71c637e9f486a7b'
torch.set_num_threads(4)
def stage():
    meta=json.loads((ROOT/'T09-metadata-blobs.json').read_text())
    if meta['sha']!=PIN:raise ValueError('Revision mismatch')
    manifest={}
    for item in meta['siblings']:
        name=item['rfilename']
        if not (name.startswith('src/f5_tts/') or name in ['config.json','vocab.txt','sooktam.safetensors','ref.wav']):continue
        source=SOURCE/name;dest=TARGET/name;dest.parent.mkdir(parents=True,exist_ok=True)
        sha=hashlib.sha256();git=hashlib.sha1(('blob '+str(source.stat().st_size)+'\0').encode())
        with source.open('rb') as f,dest.open('wb') as out:
            while data:=f.read(8388608):sha.update(data);git.update(data);out.write(data)
        if (sha.hexdigest() if 'lfs' in item else git.hexdigest())!=(item.get('lfs',{}).get('sha256') or item['blobId']):raise ValueError('Publisher hash mismatch: '+name)
        manifest[name]=dict(sha256=sha.hexdigest(),bytes=dest.stat().st_size,publisher_digest_verified=True)
    return manifest
def main():
    OUT.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');files=stage()
    # Isolate this pinned source from the older installed f5_tts package.
    (TARGET/'src/f5_tts/__init__.py').write_text('')
    sys.path.insert(0,str(TARGET/'src'))
    from f5_tts.infer import utils_infer
    # The publisher's permissive loader can silently retain random layers; reject that outcome.
    utils_infer._load_state_dict_resilient=lambda model,state:model.load_state_dict(state,strict=True)
    from f5_tts.infer.cls_tokenizer_v2 import wordparse
    if wordparse is None:raise RuntimeError('Required local CLS parser is unavailable')
    import f5_tts.api as f5_api
    if not pathlib.Path(f5_api.__file__).is_relative_to(TARGET):raise RuntimeError('Wrong F5 runtime imported')
    F5TTS=f5_api.F5TTS
    vocoder=pathlib.Path('/workspace/hf_cache/hub/models--charactr--vocos-mel-24khz/snapshots/0feb3fdd929bcd6649e0e7c5a688cf7dd012ef21')
    model=F5TTS(model='F5TTS_v1_Base',ckpt_file=str(TARGET/'sooktam.safetensors'),vocab_file=str(TARGET/'vocab.txt'),use_ema=False,vocoder_local_path=str(vocoder),device='cuda')
    reftext='सर, मैं तब से यह कह रहा हूँ कि मैंने अपना टिकट कैंसल कर दिया है, लेकिन अब तक मेरे पैसे वापस नहीं आए हैं। आप इस मामले को देखेंगे भी या नहीं?'
    env=dict(run_id=stamp,model='bharatgenai/sooktam2',revision=PIN,files=files,runner_sha256=digest(__file__),torch=torch.__version__,gpu=torch.cuda.get_device_name(0),
             checkpoint='sooktam.safetensors',added_empty_package_initializer=True,use_ema=False,strict_loading_override=True,precision='float32',tokenizer='local CLS',
             reference_source='publisher-bundled ref.wav and README transcript',reference_sha256=digest(TARGET/'ref.wav'),reference_text=reftext,
             individual_speaker_consent_independently_verified=False,reference_preprocessing_in_timed_scope=True,
             vocoder_revision=vocoder.name,hf_offline=True,network_namespace_isolated=False)
    (OUT/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2,ensure_ascii=False),encoding='utf-8')
    items=TEXTS+[('or-IN','Odia','ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।')]
    for i,(locale,language,text) in enumerate([items[1]]*3+items):
        rec=dict(run_id=stamp,locale=locale,text=text,voice='publisher Hindi ref.wav',phase='warmup' if i<3 else 'smoke',mode='full',synthesis_class='C',ok=False,nfe_step=32,cfg_strength=2,seed=20260924)
        try:
            torch.cuda.synchronize();start=time.perf_counter()
            with torch.inference_mode():audio,sr,_=model.infer(ref_file=str(TARGET/'ref.wav'),ref_text=reftext,gen_text=text,tokenizer='cls',cls_language=language.lower(),nfe_step=32,cfg_strength=2,seed=20260924,show_info=lambda *a:None,progress=None)
            torch.cuda.synchronize();elapsed=time.perf_counter()-start;audio=np.asarray(audio,dtype=np.float32).reshape(-1)
            if not len(audio) or not np.isfinite(audio).all():raise ValueError('Invalid waveform')
            rec.update(ok=True,total_s=elapsed,ttfa_s=elapsed,sample_rate=sr,audio_duration_s=len(audio)/sr,rtf=elapsed/(len(audio)/sr),prequantization_out_of_range_samples=int(np.sum(np.abs(audio)>=1)))
            if i>=3:
                file=OUT/f'{stamp}-{locale}.flac';sf.write(file,audio,sr,subtype='PCM_24');rec.update(file=str(file.relative_to(ROOT)),sha256=digest(file))
        except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        print(json.dumps({k:rec.get(k) for k in ['locale','phase','ok','rtf','error']}),flush=True)
    (OUT/'DONE').write_text('Ten full-output target-language smoke attempts complete; full qualification pending.\n');shutil.rmtree(TARGET)
if __name__=='__main__':main()
