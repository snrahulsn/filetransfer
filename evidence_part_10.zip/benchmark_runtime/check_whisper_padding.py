"""Demonstrate the corrected waveform padding on one exact corpus input, CPU only."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import json,pathlib,numpy as np
from transformers import WhisperFeatureExtractor
from asr_corpus import records
ROOT=pathlib.Path('/workspace/speechbench_20260924')
source=json.loads((ROOT/'A08_download.json').read_text())['path'];processor=WhisperFeatureExtractor.from_pretrained(source,local_files_only=True)
row=next(records(['hi-IN'],limit=1))
short=processor(row['audio'],sampling_rate=16000,truncation=False,padding='longest',return_tensors='np').input_features
standard=processor(row['audio'],sampling_rate=16000,truncation=False,padding='max_length',return_tensors='np').input_features
old=np.pad(short,[(0,0),(0,0),(0,3000-short.shape[-1])])
if standard.shape[-1]!=3000 or np.array_equal(old,standard):raise ValueError('Unexpected feature comparison')
result=dict(id=row['id'],original_audio_sha256=row['original_audio_sha256'],short_shape=list(short.shape),standard_shape=list(standard.shape),
    max_absolute_feature_difference=float(np.max(np.abs(old-standard))),old_padded_tail_mean=float(old[:,:,-100:].mean()),standard_padded_tail_mean=float(standard[:,:,-100:].mean()),
    conclusion='Manual zero feature padding differs from standard waveform padding; affected old-run trials excluded and rerun.')
(ROOT/'A08/preprocessing_diagnostic.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
