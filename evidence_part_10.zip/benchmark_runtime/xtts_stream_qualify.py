"""Qualify XTTS-v2 with the publisher's inference_stream API."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import pathlib
import time
import traceback

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", COQUI_TOS_AGREED="1")

import numpy as np
import soundfile as sf
import torch
from TTS.config.shared_configs import BaseDatasetConfig
from TTS.tts.configs.xtts_config import XttsConfig
from TTS.tts.models.xtts import Xtts, XttsArgs, XttsAudioConfig

from tts_delivery import diagnose


ROOT = pathlib.Path("/workspace/speechbench_20260924")
PIN = "6c2b0d75eae4b7047358e3b6bd9325f857d43f77"
TEXTS = {
    "hi-IN": ("hi", "आपकी बैठक कल दोपहर तीन बजे है। कृपया समय पर पहुँचें। बैठक में नई योजना और अगले सप्ताह के काम पर चर्चा होगी।"),
    "en-IN": ("en", "Your meeting with Priya is tomorrow at three thirty PM. Please arrive on time. The team will discuss the new plan and next week's work."),
}


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    download = json.loads((ROOT / "T17_download.json").read_text())
    path = pathlib.Path(download["path"])
    if download.get("status") != "downloaded" or download.get("revision") != PIN:
        raise RuntimeError("invalid T17 pinned download")
    reference_record = json.loads((ROOT / "T12-ref_download.json").read_text())
    reference = pathlib.Path(reference_record["path"]) / "adapters/hindi_female/ref.wav"
    config = XttsConfig()
    config.load_json(str(path / "config.json"))
    model = Xtts.init_from_config(config)
    safe_types = [BaseDatasetConfig, XttsConfig, XttsArgs, XttsAudioConfig]
    if hasattr(torch.serialization, "safe_globals"):
        with torch.serialization.safe_globals(safe_types):
            model.load_checkpoint(config, checkpoint_dir=str(path), eval=True)
    else:
        torch.serialization.add_safe_globals(safe_types)
        model.load_checkpoint(config, checkpoint_dir=str(path), eval=True)
    model.cuda()
    conditioning, speaker = model.get_conditioning_latents(audio_path=[str(reference)])
    output = ROOT / "T17"
    output.mkdir(exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    environment = {
        "run_id": stamp,
        "model": "coqui/XTTS-v2",
        "revision": PIN,
        "runner_sha256": digest(pathlib.Path(__file__)),
        "gpu": torch.cuda.get_device_name(0),
        "reference_sha256": digest(reference),
        "mode": "native_inference_stream",
        "stream_chunk_size": 20,
        "overlap_wav_len": 1024,
        "enable_text_splitting": True,
        "hf_offline": True,
    }
    (output / f"environment-stream-{stamp}.json").write_text(json.dumps(environment, indent=2))
    for locale, (language, text) in TEXTS.items():
        for phase in ("warmup", "smoke"):
            record = {"run_id": stamp, "phase": phase, "locale": locale, "text": text, "voice": "T11 publisher Hindi female reference", "mode": "native_stream", "synthesis_class": "A", "ok": False}
            try:
                torch.manual_seed(20260924)
                torch.cuda.reset_peak_memory_stats()
                torch.cuda.synchronize()
                started = time.perf_counter()
                chunks = []
                events = []
                iterator = model.inference_stream(
                    text,
                    language,
                    conditioning,
                    speaker,
                    stream_chunk_size=20,
                    overlap_wav_len=1024,
                    enable_text_splitting=True,
                )
                for value in iterator:
                    chunk = value.detach().cpu().float().numpy().reshape(-1)
                    if len(chunk):
                        chunks.append(chunk)
                        events.append({"at_s": time.perf_counter() - started, "samples": len(chunk)})
                torch.cuda.synchronize()
                total = time.perf_counter() - started
                waveform = np.concatenate(chunks)
                sample_rate = int(config.audio.output_sample_rate)
                duration = len(waveform) / sample_rate
                record.update(ok=True, events=events, chunk_events=events, sample_rate=sample_rate, ttfa_s=events[0]["at_s"], total_s=total, audio_duration_s=duration, rtf=total / duration, peak_memory_bytes=torch.cuda.max_memory_allocated())
                record.update(**diagnose(record))
                record["overlap_verified"] = len(events) > 1 and events[0]["at_s"] < total
                if not record["overlap_verified"]:
                    raise RuntimeError("inference_stream did not yield audio before synthesis completed")
                if phase == "smoke":
                    target = output / f"{stamp}-stream-{locale}.flac"
                    sf.write(target, waveform, sample_rate, subtype="PCM_24")
                    record.update(file=str(target.relative_to(ROOT)), sha256=digest(target))
            except Exception as error:
                record.update(ok=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
            with (output / "records.jsonl").open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(json.dumps({key: record.get(key) for key in ("locale", "phase", "ok", "ttfa_s", "rtf", "chunk_count", "simulated_stall_count", "error")}), flush=True)


if __name__ == "__main__":
    main()
