"""Validate the four-section benchmark report and its portable evidence links."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import sys
from urllib.parse import unquote


ROOT = pathlib.Path(__file__).resolve().parents[1]
EXPECTED_ASR = [f"A{i:02d}" for i in range(1, 16)]
EXPECTED_TTS = [f"T{i:02d}" for i in range(1, 20)]
ALLOWED_EMPTY = {"N/S", "Not tested", "Pending", "Failed"}


def section(document: str, section_id: str) -> str:
    match = re.search(rf'<section id="{re.escape(section_id)}"[^>]*>.*?</section>', document, re.S)
    if not match:
        raise AssertionError(f"missing section {section_id}")
    return match.group(0)


def main_rows(block: str) -> list[tuple[str, str]]:
    tbody = re.search(r"<tbody>(.*?)</tbody>", block, re.S)
    if not tbody:
        raise AssertionError("missing table body")
    rows = []
    for row in re.findall(r"<tr>(.*?)</tr>", tbody.group(1), re.S):
        model = re.search(r"<span>([AT]\d{2})</span>", row)
        if model:
            rows.append((model.group(1), row))
    return rows


def local_target(report: pathlib.Path, value: str) -> pathlib.Path | None:
    if value.startswith("#") or re.match(r"^[a-z]+://", value):
        return None
    return (report.parent / unquote(value)).resolve()


def hash_ok(path: pathlib.Path, digest: str) -> bool:
    return path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest


def pdf_pages(path: pathlib.Path) -> int | None:
    if not path.is_file():
        return None
    output = subprocess.check_output(["pdfinfo", str(path)], text=True)
    match = re.search(r"^Pages:\s+(\d+)$", output, re.M)
    return int(match.group(1)) if match else None


def validate(report: pathlib.Path, pdf: pathlib.Path) -> dict:
    document = report.read_text(encoding="utf-8")
    checks: dict[str, object] = {}
    failures: list[str] = []

    section_ids = re.findall(r'<section id="([^"]+)" class="report-section', document)
    checks["section_ids"] = section_ids
    if section_ids != ["asr", "tts", "deployment", "evidence"]:
        failures.append("report must contain exactly ASR, TTS, Deployment and Evidence in that order")

    asr = section(document, "asr")
    tts = section(document, "tts")
    asr_rows = main_rows(asr)
    tts_rows = main_rows(tts)
    checks["asr_model_rows"] = len(asr_rows)
    checks["tts_model_rows"] = len(tts_rows)
    if [model for model, _ in asr_rows] != EXPECTED_ASR:
        failures.append("ASR table must contain A01-A15 exactly once")
    if [model for model, _ in tts_rows] != EXPECTED_TTS:
        failures.append("TTS table must contain T01-T19 exactly once")
    if re.search(r"<th>Mode</th>", asr + tts, re.I):
        failures.append("main comparison tables must not expose a mode column")
    for model, row in asr_rows + tts_rows:
        streams = re.findall(r'class="stream [^"]+">(Yes|No|Pending)</span>', row)
        if len(streams) != 1:
            failures.append(f"{model} must have one Streaming value")

    tts_table = re.search(r"<table>.*?</table>", tts, re.S).group(0)
    checks["tts_human_numeric_cells"] = len(re.findall(r'class="score quality"', tts_table))
    checks["tts_playable_cells"] = len(re.findall(r'class="score playable"', tts_table))
    if "AI score" in tts_table or re.search(r">\s*\d(?:\.\d)?g\s*<", tts_table):
        failures.append("AI ratings appear in the human TTS table")
    pocket_row = dict(tts_rows).get("T02", "")
    pocket_locales = sorted(set(re.findall(r'data-detail="tts:T02:([^"]+)"', pocket_row)))
    checks["pocket_tts_executed_locales"] = pocket_locales
    if pocket_locales != ["en-IN", "hi-IN", "ta-IN", "te-IN"]:
        failures.append("Pocket TTS must expose the four executed language checkpoints")

    visible_empty = set(re.findall(r'class="status [^"]+"[^>]*>([^<]+)</span>', asr + tts))
    checks["explicit_missing_states"] = sorted(visible_empty)
    if not visible_empty <= ALLOWED_EMPTY:
        failures.append(f"unrecognised missing states: {sorted(visible_empty - ALLOWED_EMPTY)}")

    if "/Users/" in document or "file://" in document:
        failures.append("report contains a machine-specific absolute path")
    refs = re.findall(r'(?:href|data-audio)="([^"]+)"', document)
    missing = []
    for value in refs:
        if "${" in value:
            continue
        target = local_target(report, value)
        if target is not None and not target.exists():
            missing.append(value)
    checks["static_link_count"] = len(refs)
    checks["missing_static_links"] = sorted(set(missing))
    if missing:
        failures.append(f"{len(set(missing))} static links are broken")

    metadata = json.loads((ROOT / "execution/metadata_corrections.json").read_text())
    bad_hashes = []
    for model, correction in metadata["corrections"].items():
        relative = correction.get("license_file") or correction.get("model_card_file")
        digest = correction.get("license_sha256") or correction.get("model_card_sha256")
        if relative and digest and not hash_ok(ROOT / "execution" / relative, digest):
            bad_hashes.append(model)
    checks["metadata_hash_failures"] = bad_hashes
    if bad_hashes:
        failures.append(f"metadata source hash mismatch: {bad_hashes}")

    required_labels = [
        "BharatGen non-commercial", "Indic Open Model License v1.0",
        "Fish Audio Research License", "Coqui Public Model License 1.0.0",
        "IndicWhisper — language checkpoints", "MMS-TTS — language checkpoints",
    ]
    absent_labels = [label for label in required_labels if label not in document]
    checks["missing_corrected_labels"] = absent_labels
    if absent_labels:
        failures.append(f"corrected labels missing: {absent_labels}")

    ledger = json.loads((ROOT / "execution/primary_configuration_ledger.json").read_text())
    pending = sorted(ledger["tts"]["pending_streaming_execution"])
    checks["pending_streaming_models"] = pending
    for model in pending:
        row = dict(tts_rows).get(model, "")
        if ">Pending</span>" not in row:
            failures.append(f"{model} pending streaming work is not visible")

    pages = pdf_pages(pdf)
    checks["pdf_pages"] = pages
    if pages is None or not 4 <= pages <= 8:
        failures.append("PDF must be a readable multi-page export")
    if "font-size:10pt" not in document:
        failures.append("print CSS does not preserve 10-point table text")

    owner = ROOT / "execution/listening_ratings_current.json"
    owner_count = 0
    if owner.is_file():
        owner_count = len((json.loads(owner.read_text()) or {}).get("rows", []))
    release_blockers = []
    if owner_count == 0:
        release_blockers.append("owner blind TTS ratings have not been imported")
    if pending:
        release_blockers.append(f"streaming execution remains for {', '.join(pending)}")
    frozen = ROOT / "execution/fresh_current/asr_frozen_manifest.json"
    if not frozen.is_file():
        release_blockers.append("shared frozen ASR manifest has not been materialised")
    checks["owner_rating_rows"] = owner_count

    return {
        "schema_version": 1,
        "report": report.name,
        "pdf": pdf.name,
        "structure_pass": not failures,
        "release_ready": not failures and not release_blockers,
        "checks": checks,
        "failures": failures,
        "release_blockers": release_blockers,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=pathlib.Path, default=ROOT / "BENCHMARK_REPORT.html")
    parser.add_argument("--pdf", type=pathlib.Path, default=ROOT / "BENCHMARK_REPORT.pdf")
    parser.add_argument("--output", type=pathlib.Path, default=ROOT / "execution/final_report_validation.json")
    parser.add_argument("--require-release", action="store_true")
    args = parser.parse_args()
    result = validate(args.report.resolve(), args.pdf.resolve())
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if not result["structure_pass"] or (args.require_release and not result["release_ready"]):
        sys.exit(1)
