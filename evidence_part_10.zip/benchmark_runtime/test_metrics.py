import unittest
from metrics import normalize,score

class MetricsTest(unittest.TestCase):
    def test_combining_marks(self):
        self.assertEqual(normalize('हिंदी, বাংলা! தமிழ்।'),'हिंदी বাংলা தமிழ்')
    def test_real_edit_distance(self):
        r=score('a b','a x y b')
        self.assertEqual(r['word_edits'],2)
        self.assertEqual(r['wer'],1)
    def test_failure_not_dropped(self):
        self.assertEqual(score('hello world','')['wer'],1)
    def test_empty_reference(self):
        r=score('','hallucination')
        self.assertIsNone(r['wer'])
        self.assertTrue(r['hallucinated_on_empty'])

if __name__=='__main__':unittest.main()
