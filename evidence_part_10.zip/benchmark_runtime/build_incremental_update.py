"""Build a portable incremental handoff for the final streaming completions."""
from __future__ import annotations

import csv, hashlib, json, pathlib, shutil, zipfile
import final_two_table_report as report

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/"INCREMENTAL_UPDATE_20260929"
TARGET=14_000_000

def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
    return h.hexdigest()

def selected_rows(mid):
    if mid.startswith("A"):
        return [r for r in report.read_jsonl(report.DATA/mid/"frozen_records.jsonl") if r.get("ok")]
    mode=report.TTS_MODE[mid][1]
    rows=[r for r in report.read_jsonl(report.DATA/mid/"records.jsonl") if r.get("ok") and r.get("mode")==mode]
    return list({r.get("locale"):r for r in rows}.values())

def main():
    shutil.rmtree(OUT,ignore_errors=True); OUT.mkdir(parents=True); (OUT/"TABLES").mkdir()
    for name in ("BENCHMARK_REPORT.html","BENCHMARK_REPORT.pdf"):
        shutil.copy2(ROOT/name,OUT/name)
    inventory=report.read_json(ROOT/"execution/sources/inventory_audit.json",[])
    hardware=[]
    for item in inventory:
        mid=item["model_id"]; rows=selected_rows(mid)
        hardware.append({"model_id":mid,"model":report.NAMES[mid],"task":"ASR" if mid.startswith("A") else "TTS",
                         "streaming":("Yes" if mid in report.ASR_STREAM else "No") if mid.startswith("A") else report.TTS_MODE[mid][0],
                         "selected_mode":"stream" if mid in report.ASR_STREAM else ("file" if mid.startswith("A") else report.TTS_MODE[mid][1]),
                         "cpu_gpu":report.device(mid,rows),
                         "record_evidence":f"execution/fresh_current/{mid}/"})
    with (OUT/"TABLES/hardware_by_model.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=hardware[0]);w.writeheader();w.writerows(hardware)
    additional=[]
    for mid in ("T11","T12","T16","T19"):
        for row in selected_rows(mid):
            env={}
            for p in (report.DATA/mid).glob(f"environment-sglang-{row.get('run_id')}.json"):
                env=report.read_json(p,{}) or {}
            additional.append({"model_id":mid,"model":report.NAMES[mid],"locale":row.get("locale"),"mode":row.get("mode"),
                               "ttfa_s":row.get("ttfa_s"),"rtf":row.get("rtf"),"chunk_count":row.get("chunk_count"),
                               "overlap_verified":row.get("overlap_verified"),"cpu_gpu":report.device(mid),
                               "checkpoint":row.get("checkpoint"),"revision":row.get("revision"),"adapter":env.get("adapter"),
                               "adapter_scale":env.get("adapter_scale"),"file":row.get("file"),"sha256":row.get("sha256")})
    with (OUT/"TABLES/additional_streaming_results.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=additional[0]);w.writeheader();w.writerows(additional)
    files=[]
    for mid in ("T11","T12","T16","T19"):
        base=report.DATA/mid
        files += [p for p in base.iterdir() if p.is_file() and (p.name in {"records.jsonl"} or "20260929" in p.name or "server.log" in p.name)]
    files += [report.DATA/"qwen_tts_24gb.yaml",report.DATA/"s2pro_24gb.yaml"]
    files += [ROOT/"execution"/n for n in ("primary_configuration_ledger.json","final_shutdown_verification.json","final_report_validation.json","final_local_data_audit.json","FINAL_STATUS.json")]
    files += list((ROOT/"LISTENING_REVIEW").rglob("*"))
    files += [ROOT/"benchmark_runtime"/n for n in ("final_two_table_report.py","render_final_pdf.py","validate_two_table_report.py","build_incremental_update.py","build_final_blind_test.py","listening_package.py","merge_qwen_lora.py","sgl_stream_benchmark.py","run_t19_streaming.sh")]
    files=[p for p in files if p.is_file()]
    groups=[]; current=[]; size=0
    for p in sorted(set(files),key=lambda p:p.stat().st_size,reverse=True):
        if current and size+p.stat().st_size>TARGET: groups.append(current);current=[];size=0
        current.append(p);size+=p.stat().st_size
    if current:groups.append(current)
    entries=[];parts=[]
    for i,group in enumerate(groups,1):
        part=OUT/f"evidence_part_{i:02d}.zip"
        with zipfile.ZipFile(part,"w",zipfile.ZIP_DEFLATED,compresslevel=6,strict_timestamps=False) as z:
            for p in group:
                rel=p.relative_to(ROOT).as_posix();z.write(p,rel)
                entries.append({"path":rel,"bytes":p.stat().st_size,"sha256":sha(p),"part":part.name})
        if part.stat().st_size>=20_000_000: raise RuntimeError(f"part exceeds 20 MB: {part}")
        parts.append({"name":part.name,"bytes":part.stat().st_size,"sha256":sha(part)})
    direct=[]
    for p in [OUT/"BENCHMARK_REPORT.html",OUT/"BENCHMARK_REPORT.pdf"]+sorted((OUT/"TABLES").glob("*")):
        direct.append({"path":p.relative_to(OUT).as_posix(),"bytes":p.stat().st_size,"sha256":sha(p)})
    manifest={"schema_version":1,"created_at_utc":"2026-09-29T06:17:56Z","direct_files":direct,"evidence_files":entries,"parts":parts}
    (OUT/"MASTER_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
    (OUT/"README.md").write_text("""# Incremental benchmark update

- `BENCHMARK_REPORT.html` and `BENCHMARK_REPORT.pdf` are the final one-page, two-table report.
- `TABLES/hardware_by_model.csv` lists the CPU/GPU deployment class for every ASR and TTS row.
- `TABLES/additional_streaming_results.csv` contains the completed T11, T12, T16 and T19 warmed streaming metrics and exact waveform hashes.
- `LISTENING_REVIEW/index.html` and its 105 anonymous clips are included in the evidence ZIPs; extract them before opening the blind test.
- `evidence_part_*.zip` contains only the added WAVs, JSONL records, environments, logs, runtime configs, validation, shutdown audit and report code. Every ZIP is below 20 MB.
- `MASTER_MANIFEST.json` provides SHA-256 hashes for direct files, evidence files and ZIP parts.

Copy this folder over the previously shared evidence-pack root, then extract every evidence ZIP into that same root. The repository-relative paths replace the older report and add only the new evidence. The report contains no Grok ratings; the owner scoring interface remains separate.
""")
    print(json.dumps({"folder":str(OUT),"parts":len(parts),"evidence_files":len(entries),"largest_part_bytes":max(p["bytes"] for p in parts)},indent=2))

if __name__=="__main__": main()
