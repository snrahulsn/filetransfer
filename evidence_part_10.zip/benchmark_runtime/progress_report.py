"""Evidence-backed progress report; never labels pending work complete."""
import collections,datetime,json,pathlib
from stream_diagnostics import main as streaming_diagnostics
from coverage_report import main as coverage_report
from metrics_report import main as metrics_report
from record_validity import invalid_runs
ROOT=pathlib.Path(__file__).resolve().parents[1]
E=ROOT/'execution';fresh=E/'fresh_current'
inventory=json.loads((ROOT/'indic_speech_benchmark_prd_v1/configs/model_inventory.json').read_text())['entries']
access={x['id']:x for x in json.loads((E/'authenticated_access.json').read_text())}
counts=collections.defaultdict(collections.Counter)
for file in fresh.glob('*/**/*records.jsonl'):
    invalid=invalid_runs(file)
    for line in file.read_text().splitlines():
        row=json.loads(line)
        if row.get('run_id') in invalid:continue
        counts[file.relative_to(fresh).parts[0]][(row.get('phase','asr'),bool(row.get('ok')))]+=1
snapshot=json.loads((fresh/'snapshot.json').read_text())['snapshot_utc']
streaming_diagnostics(fresh,E/'metrics_current/stream_diagnostics.json')
coverage_report()
metrics_report()
leases=[json.loads(p.read_text()) for p in sorted(E.glob('lease-*.json'))]
actual=sum(float(x.get('estimated_compute_usd',0)) for x in leases if x.get('status')=='stopped_verified')
active=[x for x in leases if x.get('status') not in ('stopped_verified','not_created')]
budget_summary=f'The accepted spending limit is $10. Verified stopped leases have estimated compute of ${actual:.6f}; final provider billing remains unreconciled. '
if active:
    x=active[-1];deadline=datetime.datetime.fromtimestamp(x['deadline_epoch'],datetime.timezone.utc).isoformat()
    budget_summary+=f"The bounded follow-up lease for pod {x.get('pod_id')} is recorded as {x.get('status')}, at ${x.get('hourly_usd')}/hour, ending {deadline}. Its independent local watchdog was verified alive; final shutdown verification remains pending."
else:
    budget_summary+='All recorded created leases are verified stopped. The network volume is retained and may continue incurring storage charges.'
lines=['# Indic speech benchmark — in progress','',f'Evidence snapshot: {snapshot}. This is a progress report, not a completed qualification or a model ranking.','',
'The scope remains all 34 PRD entries: 15 ASR and 19 TTS, including both streaming and full-output modes. The target locales are hi-IN, en-IN, bn-IN, mr-IN, ta-IN, te-IN, gu-IN, kn-IN, ml-IN and or-IN. No unexecuted model has been excluded merely because it is non-streaming.','',
'## Verified measurements so far','',
'[Readable measured results: WER, CER, streaming delays, TTFA and RTF](MEASURED_RESULTS.md). [PRD completion-gate audit](COMPLETION_AUDIT.md) and [current required inputs](indic_speech_benchmark_prd_v1/inputs_required.md).','',
'Fresh records and audio are in [the evidence snapshot](execution/fresh_current/). [Metric JSON](execution/metrics_current/measured_metrics.json) and [CSV](execution/metrics_current/measured_metrics.csv) retain language, mode, lookahead, run, corpus, condition and decoder distinctions. Audio hashes were checked locally; see [snapshot verification](execution/fresh_current/local_verification.json) and the [executed-source/audio integrity audit](execution/evidence_integrity.json). Integrity checks do not establish model quality.','',
'| Model | Successful measured records | Recorded successful warmups | Recorded trial failures |','|---|---:|---:|---:|']
for model,c in sorted(counts.items()):
    warm=str(c[("warmup",True)]) if any(phase=='warmup' for phase,ok in c) else '—'
    lines.append(f'| {model} | {sum(v for (phase,ok),v in c.items() if phase!="warmup" and ok)} | {warm} | {sum(v for (phase,ok),v in c.items() if not ok)} |')
lines += ['',
'A dash in the warmup column means no individual warmup records were saved; it does not mean no warmup occurred. Startup failures before trial recording appear in the queue outcomes and are not model-quality scores.','',
'Parler TTS has one full-output and one native streaming smoke clip per target locale. These are not the 40-prompt quality protocol. Its observed streamed first-audio timing was approximately 1.6–1.8 seconds, but the tested configuration took substantially longer than the produced audio duration to finish. Early audio output therefore does not establish real-time throughput.','',
'SraVaani native streams use an independent producer paced at 20 ms, preserve state, and save partial transcripts, arrival lateness and queue depth. Only the 480 ms file path received the initial warmup; first use of other lookahead settings includes additional startup effects. Results remain provisional, with no claimed steady-state p95 or full-test accuracy.','',
'MMS TTS uses distinct pinned language checkpoints and a full-output path. Repeated C1 trials use one fixed prompt, not a broad quality workload. Background dependency installation overlapped the first run, so these timings are provisional and do not establish controlled latency qualification. Generic English voices have not been verified as Indian-accent voices.','',
'[Declared languages and actual trial counts for every model](LANGUAGE_COVERAGE.md). Language coverage does not establish Indian-accent quality.','',
'## Inventory accounting','',
'Access below means the authenticated probe could read the selected asset. It does not certify all dependencies, runtime success or commercial rights. Declared licences are copied from the pinned source audit; full rights review remains separate. “Pending” is unfinished work, not an exclusion.','',
'| ID | Model | Declared licence | Access | Current execution status |','|---|---|---|---|---|']
attempted_jobs=set()
if (fresh/'queue_outcomes.jsonl').exists():
    attempted_jobs={json.loads(line).get('job','').split('-')[0] for line in (fresh/'queue_outcomes.jsonl').read_text().splitlines()}
queued={'A02','A03','A04','A07','A08','A09','A10','A15','T01','T03','T05','T06','T07','T08','T09','T10'}
for entry in inventory:
    key=entry['model_id'];audit=json.loads((E/'sources'/key/'audit.json').read_text())
    a=access.get(key,{}).get('access','GitHub source inspected')
    state='Source/access checked; runtime not reached within the bounded GPU allowance; pending, not excluded'
    if key in queued:state='Adapter prepared; execution not reached within the bounded GPU allowance; pending, not excluded'
    if key in attempted_jobs:state='Runtime attempted; no successful non-warmup trial saved yet; inspect recorded timeout/error outcome'
    if (fresh/key/'run_validity.json').exists():state='A prior harness run was invalidated; see measured report for the reason and corrected-run evidence'
    if key in counts:
        state='Measured records available; full qualification incomplete' if any(ok and phase!='warmup' and n for (phase,ok),n in counts[key].items()) else 'Runtime attempted; no successful non-warmup trial in this snapshot'
    if key=='T02':state='Browser gate accepted; authenticated checkpoint staging to the isolated benchmark pod remains incomplete'
    if key=='T15' and key not in counts:state='Native streaming adapter prepared; compiled and eager configurations tracked separately'
    repo=entry['source_locator'];url=repo if repo.startswith('https://') else 'https://huggingface.co/'+repo
    license_label=audit.get('license') or {'A11':'BharatGen non-commercial (model card)','T09':'BharatGen non-commercial (model card)','A14':'MIT (pinned project README)'}.get(key,'Unresolved')
    lines.append(f'| {key} | [{entry["display_name"]}]({url}) | {license_label} | {a} | {state} |')
lines += ['',
'## Data and remaining qualification gates','',
'- Regional accuracy corpus: all 7,095 official FLEURS test utterances across the nine Indic locales, with pinned revision and archive hashes. Download completion is not inference completion.',
'- Indian English: all 1,000 NPTEL Pure Set clips with human-corrected references. This is an educational speech corpus, not the gated Svarah corpus and not a conversational banking holdout.',
'- Public Hindi-English and Bengali-English code-switch test archives have been downloaded and hashed. Six seeded smoke segments have verified sentence boundaries and audio/reference pairs; completed inference, if present, is identified by code_switch_smoke rows in the measured table. The source test populations contain 3,136 Hindi-English and 4,275 Bengali-English segments. These technical tutorials do not establish conversational banking accuracy.',
'- Required full eligible test splits, conversational/domain holdouts, codec/noise conditions, entity diagnostics, concurrency, cold starts, long sessions, cancellation, and the complete per-configuration TTS prompt protocol remain incomplete.',
'- Human listening ratings: zero. The owner requested the complete clip collection before rating it. Owner ratings will be identified separately from the PRD’s five-rater protocol.',
'- On-prem hardware and target concurrent calls remain TBD. The RTX 4090 and RTX PRO 4500 Blackwell reference measurements can inform selection; they cannot establish capacity on unspecified hardware.',
'- Local-only model loading flags are enabled where recorded. A kernel network-isolation probe failed with “Operation not permitted”; independently enforced offline operation has not been demonstrated.','',
'## Budget, access and incident record','',
budget_summary,'',
'The storage quota interrupted workers and some file uploads. Two redundant FP32 Whisper cache shards (6,174,112,072 bytes total) were removed; selected weights, source corpora and evidence were retained. Runtime files were restored and syntax-checked, and 64 saved ASR records parsed successfully. The recovery queue records exit codes and timeouts. A diagnostic attach attempt was denied by the container’s missing SYS_PTRACE capability; no bypass was attempted.','',
'The owner authorized the required Hugging Face contact-sharing forms. Pocket TTS, Svarah, IndicVoices and Rasa access terms were accepted in the signed-in browser; browser access does not by itself place authenticated gated assets on the isolated benchmark pod.','',
'Additional isolated backend installation overlapped Veena, Maya, IndicF5 and part of Bodhan execution. These remain provisional timings; setup intervals and package reports are preserved in the evidence snapshot. The Voxtral runtime install initially timed out, then completed through a bounded repair with successful import checks. This setup incident is not a model-quality failure.','',
'The baseline package-version list and 46 installed synthesis source files are preserved in [the source capture](execution/fresh_current/baseline_source_capture.json). This is a post-run capture, not a pre-run source attestation. A local disk-space error interrupted one evidence backup; the preceding verified snapshot was preserved and the next backup succeeded.','',
'The bounded allowance was spent on setup, completed measured trials and recorded timeout attempts. Unreached models remain unfinished work; the spending/runtime cutoff is not evidence that those models are unsuitable. Additional runtime would be needed to finish these evaluations, and the amount required has not been established.','',
'No final quality leader or production recommendation is supported yet. Every missing metric remains missing; publisher scores and fixture tests are not used as measured benchmark results.','']
lines += ['## Additional source and protocol findings','',
'The pinned qwen-asr 0.0.6 streaming API re-feeds accumulated audio with prefix rollback. It is classified as publisher-provided buffered/retranscribing streaming, not an incremental audio-encoder-cache implementation. Its measurements remain separate from the Transformers full-utterance backend.','',
'Earlier unauthenticated probes returned HTTP 403 for Svarah, IndicVoices and Rasa. Their contact-sharing forms were subsequently accepted in the signed-in browser. See [the access authorization record](execution/access_authorizations.json).','',
'The first MMS Odia prompt differs from the Parler Odia prompt. Those clips must not be presented as a matched-text pair or combined into a controlled cross-model comparison. Text is preserved in every record.','',
'Listening clips are saved waveforms, not simulations of live playback stalls. Human audio-quality ratings and streaming delivery timing are separate measures.','']
outcomes=fresh/'queue_outcomes.jsonl'
if outcomes.exists():
    lines+=['## Queue outcomes','', 'These are job outcomes, not statements that a model is inherently unusable. Timed-out jobs retain any completed records.','', '| Job | Exit | Timed out | Finished (UTC) |','|---|---:|---|---|']
    for line in outcomes.read_text().splitlines():
        row=json.loads(line)
        lines.append(f'| {row.get("job")} | {row.get("exit_code")} | {row.get("timed_out")} | {row.get("finished_utc")} |')
    lines.append('')
(ROOT/'BENCHMARK_PROGRESS.md').write_text('\n'.join(lines),encoding='utf-8')
print(ROOT/'BENCHMARK_PROGRESS.md')
