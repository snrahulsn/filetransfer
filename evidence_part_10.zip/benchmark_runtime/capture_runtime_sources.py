"""Preserve versions and small installed synthesis source packages for reproducibility."""
import datetime,hashlib,importlib.metadata,json,pathlib,shutil
ROOT=pathlib.Path('/workspace/speechbench_20260924')
SITE=pathlib.Path('/workspace/tts_streaming_suite/.venv_gpu/lib/python3.11/site-packages')
OUT=ROOT/'runtime_sources';OUT.mkdir(exist_ok=True)
record=dict(captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),site=str(SITE),
    timing_note='Post-run source capture; not a pre-run attestation',
    versions={d.metadata['Name']:d.version for d in importlib.metadata.distributions(path=[str(SITE)])},files={})
for package in ['f5_tts','parler_tts','snac','vocos']:
    source=SITE/package
    if not source.is_dir():record.setdefault('missing_packages',[]).append(package);continue
    for file in source.rglob('*.py'):
        if file.is_symlink():raise ValueError('Unexpected source symlink')
        relative=file.relative_to(SITE);dest=OUT/relative;dest.parent.mkdir(parents=True,exist_ok=True)
        data=file.read_bytes();dest.write_bytes(data)
        record['files'][str(relative)]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
(ROOT/'baseline_source_capture.json').write_text(json.dumps(record,indent=2))
print(json.dumps(dict(files=len(record['files']),packages=len(record['versions']))))
