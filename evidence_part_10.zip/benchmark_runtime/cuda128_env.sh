#!/usr/bin/env bash
# Stable persisted CUDA 12.8/Torch 2.8 environment for the Blackwell worker.
set -euo pipefail
SITE=/workspace/speechbench_20260924/envs/qwen_asr/lib/python3.11/site-packages
OMNI=/workspace/speechbench_20260924/envs/omni/lib/python3.11/site-packages
export LD_LIBRARY_PATH="$SITE/nvidia/cuda_runtime/lib:$SITE/nvidia/cuda_cupti/lib:$SITE/nvidia/cuda_nvrtc/lib:$SITE/nvidia/cublas/lib:$SITE/nvidia/cudnn/lib:$SITE/nvidia/cufft/lib:$SITE/nvidia/curand/lib:$SITE/nvidia/cusolver/lib:$SITE/nvidia/cusparse/lib:$SITE/nvidia/cusparselt/lib:$SITE/nvidia/nccl/lib:$SITE/nvidia/nvjitlink/lib:$SITE/nvidia/nvtx/lib"
export PYTHONPATH="$OMNI:/workspace/speechbench_20260924/VibeVoice-A13:/workspace/speechbench_20260924"
export HF_HOME=/workspace/hf_cache
export HF_HUB_CACHE=/workspace/hf_cache/hub
export HF_HUB_DISABLE_TELEMETRY=1
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export USE_TF=0
exec "$@"
