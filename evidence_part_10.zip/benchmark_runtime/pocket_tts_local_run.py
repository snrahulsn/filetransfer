#!/usr/bin/env python3
"""Pinned offline Pocket TTS native-stream benchmark on the local CPU."""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.update(
    HF_HOME=str(ROOT / ".pocket_hf"),
    HF_HUB_OFFLINE="1",
    TRANSFORMERS_OFFLINE="1",
)

import datetime
import hashlib
import json
import platform
import time
import traceback

import numpy as np
import soundfile as sf
import torch
from pocket_tts import TTSModel


MODEL_REPO = "kyutai/pocket-tts-without-voice-cloning"
WEIGHTS_REVISION = "e7205b6ee50e654a5ea19f0e9df2b0813b05e921"
TOKENIZER_REVISION = "00eac05ed3d16bdc3f6b5d598874019c34a89214"
VOICE_REVISION = "8843db76457a91db32077edf8dfcd1c0e3e755fd"
TEXT = "Hello, this is a test of an on premises speech system for India."


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def cached_file(revision: str, filename: str) -> Path:
    return (
        ROOT
        / ".pocket_hf/hub/models--kyutai--pocket-tts-without-voice-cloning/snapshots"
        / revision
        / filename
    ).resolve()


def main() -> None:
    files = {
        "weights": cached_file(WEIGHTS_REVISION, "languages/english/model.safetensors"),
        "tokenizer": cached_file(TOKENIZER_REVISION, "languages/english/tokenizer.json"),
        "voice": cached_file(
            VOICE_REVISION, "languages/english/embeddings/alba.safetensors"
        ),
    }
    for name, path in files.items():
        if not path.is_file():
            raise FileNotFoundError(f"Missing pinned offline {name}: {path}")

    out = ROOT / "execution/fresh_current/T02"
    out.mkdir(parents=True, exist_ok=True)
    for old in out.glob("records.jsonl"):
        old.unlink()
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    init_start = time.perf_counter()
    model = TTSModel.load_model(language="english")
    voice = model.get_state_for_audio_prompt("alba")
    init_s = time.perf_counter() - init_start

    environment = {
        "run_id": stamp,
        "model_id": "T02",
        "model": "Pocket TTS",
        "checkpoint_repo": MODEL_REPO,
        "checkpoint_variant": "official public checkpoint without arbitrary voice cloning",
        "weights_revision": WEIGHTS_REVISION,
        "tokenizer_revision": TOKENIZER_REVISION,
        "voice_revision": VOICE_REVISION,
        "checkpoint_files": {name: digest(path) for name, path in files.items()},
        "package": "pocket-tts==3.2.0",
        "runner_sha256": digest(Path(__file__)),
        "torch": torch.__version__,
        "python": platform.python_version(),
        "hardware": platform.processor() or platform.machine(),
        "precision": "float32",
        "mode": "native_stream",
        "synthesis_class": "A",
        "model_initialization_s": init_s,
        "hf_offline": True,
        "network_namespace_isolated": False,
        "english_accent_verified": False,
    }
    (out / f"environment-{stamp}.json").write_text(
        json.dumps(environment, ensure_ascii=False, indent=2) + "\n"
    )

    for index, phase in enumerate(["warmup", "warmup", "warmup", "smoke"]):
        rec = {
            "run_id": stamp,
            "phase": phase,
            "index": index,
            "locale": "en-IN",
            "text": TEXT,
            "voice": "alba official predefined state",
            "mode": "native_stream",
            "synthesis_class": "A",
            "ok": False,
            "english_accent_verified": False,
        }
        try:
            torch.manual_seed(20260924)
            started = time.perf_counter()
            chunks = []
            events = []
            for chunk in model.generate_audio_stream(voice, TEXT):
                audio = np.asarray(chunk.detach().float().cpu(), dtype=np.float32).reshape(-1)
                if len(audio):
                    chunks.append(audio)
                    events.append(
                        {"at_s": time.perf_counter() - started, "samples": len(audio)}
                    )
            elapsed = time.perf_counter() - started
            if not chunks:
                raise ValueError("stream emitted no audio")
            audio = np.concatenate(chunks)
            if not np.isfinite(audio).all():
                raise ValueError("non-finite waveform")
            sample_rate = model.sample_rate
            duration = len(audio) / sample_rate
            rec.update(
                ok=True,
                sample_rate=sample_rate,
                ttfa_s=events[0]["at_s"],
                total_s=elapsed,
                audio_duration_s=duration,
                rtf=elapsed / duration,
                chunk_events=events,
                audio_before_generation_end=len(events) > 1,
            )
            if phase == "smoke":
                audio_file = out / f"{stamp}-en-IN.flac"
                sf.write(audio_file, audio, sample_rate, subtype="PCM_24")
                rec.update(
                    file=f"T02/{audio_file.name}",
                    sha256=digest(audio_file),
                )
        except Exception as exc:
            rec.update(
                error_type=type(exc).__name__,
                error=str(exc),
                traceback=traceback.format_exc(),
            )
        with (out / "records.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        print(
            json.dumps(
                {key: rec.get(key) for key in ("phase", "ok", "ttfa_s", "rtf", "error")}
            ),
            flush=True,
        )
        if not rec["ok"]:
            break
    (out / "DONE").write_text("Pinned offline Pocket TTS native-stream benchmark completed.\n")


if __name__ == "__main__":
    main()
