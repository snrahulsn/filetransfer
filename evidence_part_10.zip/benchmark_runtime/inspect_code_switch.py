"""Read archive metadata without extracting speech recordings."""
import json,pathlib,tarfile
ROOT=pathlib.Path('/workspace/speechbench_20260924/datasets/supplemental')
for name in ['Hindi-English_test.tar.gz','Bengali-English_test.tar.gz']:
    out=ROOT/'code_switch_metadata'/name.replace('.tar.gz','');out.mkdir(parents=True,exist_ok=True)
    entries=[]
    with tarfile.open(ROOT/name,'r|gz') as tar:
        for member in tar:
            if not member.isfile() or member.name.lower().endswith('.wav'):continue
            if member.size>10_000_000:raise ValueError('Unexpected large metadata file')
            relative=pathlib.PurePosixPath(member.name)
            if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe archive path')
            data=tar.extractfile(member).read();file=out.joinpath(*relative.parts);file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(data)
            entries.append(dict(file=member.name,bytes=member.size,preview=data[:1500].decode(errors='replace')))
    (out/'listing.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
    print(json.dumps(dict(archive=name,metadata=entries),ensure_ascii=False),flush=True)
