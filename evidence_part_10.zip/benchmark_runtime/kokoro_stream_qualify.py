"""Qualify Kokoro's completed-segment generator for overlapping playback."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import pathlib
import time
import traceback

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", USE_TF="0", HF_HOME="/workspace/hf_cache")

import numpy as np
import soundfile as sf
import torch
from kokoro import KModel, KPipeline

from tts_delivery import diagnose


ROOT = pathlib.Path("/workspace/speechbench_20260924")
OUT = ROOT / "T03"
PIN = "f3ff3571791e39611d31c381e3a41a3af07b4987"
MODEL = pathlib.Path("/workspace/hf_cache/models--hexgrad--Kokoro-82M/snapshots") / PIN
ITEMS = [
    ("hi-IN", "h", "hf_alpha", " ".join(["आपकी बैठक कल दोपहर तीन बजे है। कृपया समय पर पहुँचें। बैठक में नई योजना, बजट और अगले सप्ताह के काम पर चर्चा होगी। अंत में सभी प्रश्नों के उत्तर दिए जाएंगे।"] * 8)),
    ("en-IN", "a", "af_heart", " ".join(["Your meeting with Priya is tomorrow at three thirty PM. Please arrive on time. The team will discuss the new plan, budget, and work for next week. Questions will be answered at the end."] * 8)),
]


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(4 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    OUT.mkdir(exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    model = KModel(repo_id="hexgrad/Kokoro-82M", config=str(MODEL / "config.json"), model=str(MODEL / "kokoro-v1_0.pth")).to("cuda").eval()
    environment = {
        "run_id": stamp,
        "model": "hexgrad/Kokoro-82M",
        "revision": PIN,
        "runner_sha256": digest(pathlib.Path(__file__)),
        "gpu": torch.cuda.get_device_name(0),
        "mode": "completed_segment_stream",
        "streaming_semantics": "each yielded completed segment is playable while later segments are still synthesized",
        "within_segment_streaming": False,
        "hf_offline": True,
    }
    (OUT / f"environment-stream-{stamp}.json").write_text(json.dumps(environment, indent=2))
    for locale, language_code, voice, text in ITEMS:
        pipeline = KPipeline(lang_code=language_code, model=model, repo_id="hexgrad/Kokoro-82M", device="cuda")
        voice_path = str(MODEL / "voices" / f"{voice}.pt")
        for phase in ("warmup", "smoke"):
            record = {"run_id": stamp, "phase": phase, "locale": locale, "voice": voice, "text": text, "mode": "completed_segment_stream", "synthesis_class": "B", "ok": False}
            try:
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                started = time.perf_counter()
                chunks = []
                events = []
                for graphemes, phonemes, audio in pipeline(text, voice=voice_path, speed=1):
                    chunk = audio.detach().cpu().float().numpy().reshape(-1)
                    if len(chunk):
                        chunks.append(chunk)
                        events.append({"at_s": time.perf_counter() - started, "samples": len(chunk), "completed_text": graphemes})
                torch.cuda.synchronize()
                total = time.perf_counter() - started
                waveform = np.concatenate(chunks)
                duration = len(waveform) / 24000
                record.update(ok=True, events=events, chunk_events=events, sample_rate=24000, ttfa_s=events[0]["at_s"], total_s=total, audio_duration_s=duration, rtf=total / duration, peak_memory_bytes=torch.cuda.max_memory_allocated())
                record.update(**diagnose(record))
                record["overlap_verified"] = len(events) > 1 and events[0]["at_s"] < total
                if not record["overlap_verified"]:
                    raise RuntimeError("publisher generator did not yield playable audio before synthesis completed")
                if phase == "smoke":
                    target = OUT / f"{stamp}-stream-{locale}.flac"
                    sf.write(target, waveform, 24000, subtype="PCM_24")
                    record.update(file=str(target.relative_to(ROOT)), sha256=digest(target))
            except Exception as error:
                record.update(ok=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
            with (OUT / "records.jsonl").open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(json.dumps({key: record.get(key) for key in ("locale", "phase", "ok", "ttfa_s", "rtf", "chunk_count", "simulated_stall_count", "error")}), flush=True)


if __name__ == "__main__":
    main()
