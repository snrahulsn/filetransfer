"""Post-process observed partials; stability is against the model's final text, not truth."""
import argparse,json,pathlib
from metrics import normalize
def common(a,b):
    i=0
    while i<min(len(a),len(b)) and a[i]==b[i]:i+=1
    return i
def diagnose(record):
    final=normalize(record.get('hypothesis','')).split()
    events=[(e['at_s'],normalize(e['text']).split()) for e in record.get('partial_events',[])]
    events.append((record['total_s'],final))
    stable=[None]*len(final);suffix_common=len(final)
    for at,words in reversed(events):
        suffix_common=min(suffix_common,common(words,final))
        for i in range(suffix_common):stable[i]=at
    previous=[];invalidated=0;revisions=0
    for at,words in events:
        count=len(previous)-common(previous,words)
        if count:revisions+=1;invalidated+=count
        previous=words
    source=record.get('producer_events',[])
    return dict(stability_reference='model final transcript; not reference-text correctness',
        stable_first_word_s=stable[0] if stable else None,final_word_stable_at_s=stable,
        non_monotonic_updates=revisions,invalidated_suffix_word_count=invalidated,
        source_duration_s=source[-1]['end_sample']/16000 if source else None,
        max_source_release_lateness_s=max((e['released_s']-e['due_s'] for e in source),default=None),
        queue_count_note='Original queue counter may include the end-of-stream sentinel; do not interpret it as exact queued audio duration')
def main(root,out):
    rows=[]
    for file in root.glob('*/stream_records.jsonl'):
        for line in file.read_text().splitlines():
            r=json.loads(line)
            if not r.get('ok') or r.get('phase')=='warmup':continue
            rows.append(dict(model_id=file.parent.name,**{k:r.get(k) for k in ['id','locale','run_id','mode','lookahead_ms']},**diagnose(r)))
    out.write_text(json.dumps(dict(qualification_complete=False,rows=rows),indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);p.add_argument('out',type=pathlib.Path);a=p.parse_args();main(a.root,a.out)
