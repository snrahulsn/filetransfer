"""One bounded isolated backend setup; retire only the completed temporary Qwen vLLM environment."""
import datetime,importlib.metadata,json,os,pathlib,shutil,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924')
OLD=pathlib.Path('/tmp/speechbench_vllm_env');NEW=pathlib.Path('/tmp/speechbench_omni_env')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    if OLD.is_symlink() or NEW.exists():raise RuntimeError('Unexpected runtime path state')
    for proc in pathlib.Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        try:cmd=(proc/'cmdline').read_bytes()
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if str(OLD).encode() in cmd:raise RuntimeError('The old runtime is still in use; do not remove it')
    for pth in (ROOT/'envs').glob('*/lib/python*/site-packages/*.pth'):
        if str(OLD) in pth.read_text():raise RuntimeError('A retained environment depends on the old runtime')
    outcomes=[json.loads(x) for x in (ROOT/'queue_outcomes.jsonl').read_text().splitlines()]
    for job in ['A09-stream','A07-stream']:
        if not any(r.get('job')==job and r.get('exit_code')==0 for r in outcomes):raise RuntimeError('Prior streaming job not verified complete: '+job)
    packages={}
    site=OLD/'lib/python3.11/site-packages'
    if OLD.exists():
        for dist in importlib.metadata.distributions(path=[str(site)]):packages[dist.metadata['Name']]=dist.version
        preserved=ROOT/'retired_qwen_source';preserved.mkdir(exist_ok=True)
        for p in (site/'qwen_asr').rglob('*.py'):
            dest=preserved/p.relative_to(site);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
        (ROOT/'qwen_vllm_retirement.json').write_text(json.dumps(dict(at_utc=now(),path=str(OLD),reason='Completed isolated streaming runtime; reclaim scratch for the next backend',packages=packages),indent=2))
        shutil.rmtree(OLD)
    if shutil.disk_usage('/tmp').free<20*1024**3:raise RuntimeError('Insufficient scratch space for another isolated backend')
    record=dict(started_utc=now(),backend='vllm==0.18.0 + vllm-omni==0.18.0',state='installing',may_overlap_provisional_inference=True)
    status=ROOT/'voxtral_tts_setup.json';status.write_text(json.dumps(record,indent=2))
    try:
        subprocess.run(['python3','-m','venv',str(NEW)],check=True,timeout=120)
        proc=subprocess.run([str(NEW/'bin/python'),'-m','pip','install','--no-cache-dir','--report',str(ROOT/'envs/vllm_omni_install.json'),
                            'vllm==0.18.0','vllm-omni==0.18.0','numpy==2.2.6','mistral-common[audio]==1.12.0'],check=True,timeout=1200)
        record.update(state='installed',exit_code=proc.returncode)
    except Exception as e:record.update(state='failed',error_type=type(e).__name__,error=str(e));raise
    finally:record['finished_utc']=now();status.write_text(json.dumps(record,indent=2))
if __name__=='__main__':main()
