"""Create a small evidence-only snapshot; no model weights, credentials or datasets."""
import datetime,io,json,pathlib,re,tarfile
root=pathlib.Path('/workspace/speechbench_20260924');out=pathlib.Path('/tmp/speechbench-evidence.tgz')
notes=[]
with tarfile.open(out,'w:gz') as tar:
    files=[]
    for directory in root.iterdir():
        if directory.is_dir() and re.fullmatch(r'[AT]\d\d',directory.name):
            files.extend(p for p in directory.rglob('*') if p.is_file() and p.suffix in ['.json','.jsonl','.flac'])
    files.extend(p for p in root.iterdir() if p.is_file() and (p.suffix in ['.py','.log'] or p.name.startswith('host-') or p.name.endswith(('_download.json','_setup.json','_retirement.json','-metadata-blobs.json')) or p.name in ['queue_outcomes.jsonl','redundant_cache_cleanup.json','dataset_authenticated_access.json']))
    files.extend(p for p in (root/'retired_qwen_source').rglob('*.py') if p.is_file())
    files.extend(p for p in (root/'runtime_sources').rglob('*.py') if p.is_file())
    for p in [root/'baseline_source_capture.json',root/'audio_validation.json',root/'datasets/supplemental/code_switch_smoke/manifest.json']:
        if p.exists():files.append(p)
    for name in ['qwen_vllm_install.json','voxcpm_install.json','mistral_common_install.json','vllm_omni_install.json','vllm_omni_repair_install.json']:
        p=root/'envs'/name
        if p.exists():files.append(p)
    for p in files:
        data=p.read_bytes()
        if p.suffix=='.jsonl' and data and not data.endswith(b'\n'):
            kept=data.rsplit(b'\n',1)[0]+b'\n' if b'\n' in data else b''
            notes.append(dict(path=str(p.relative_to(root)),incomplete_trailing_bytes_excluded=len(data)-len(kept)));data=kept
        info=tarfile.TarInfo(str(p.relative_to(root)));info.size=len(data);tar.addfile(info,io.BytesIO(data))
    meta=json.dumps(dict(snapshot_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),notes=notes),indent=2).encode()
    info=tarfile.TarInfo('snapshot.json');info.size=len(meta);tar.addfile(info,io.BytesIO(meta))
print(json.dumps(dict(path=str(out),bytes=out.stat().st_size)))
