"""Fetch supplemental public ASR assets and retain exact download hashes."""
import concurrent.futures,hashlib,json,os,pathlib,urllib.request
ROOT=pathlib.Path('/workspace/speechbench_20260924/datasets/supplemental');ROOT.mkdir(parents=True,exist_ok=True)
JOBS=[('nptel-pure-set.tar.gz','https://github.com/AI4Bharat/NPTEL2020-Indian-English-Speech-Dataset/releases/download/v0.1/nptel-pure-set.tar.gz','NPTEL2020 Pure Set','https://github.com/AI4Bharat/NPTEL2020-Indian-English-Speech-Dataset'),
('Hindi-English_test.tar.gz','https://openslr.trmal.net/resources/104/Hindi-English_test.tar.gz','MUCS2021 Hindi-English test','https://www.openslr.org/104/'),
('Bengali-English_test.tar.gz','https://openslr.trmal.net/resources/104/Bengali-English_test.tar.gz','MUCS2021 Bengali-English test','https://www.openslr.org/104/')]
def one(j):
    name,url,label,source=j;p=ROOT/name;rec=dict(file=name,url=url,dataset=label,source_page=source)
    try:
        h=hashlib.sha256()
        if not p.exists():
            req=urllib.request.Request(url,headers={'User-Agent':'speechbench/1.0'})
            with urllib.request.urlopen(req,timeout=180) as src,open(str(p)+'.part','wb') as out:
                while c:=src.read(8*1024*1024):out.write(c);h.update(c)
            os.replace(str(p)+'.part',p)
        else:
            with p.open('rb') as f:
                while c:=f.read(8*1024*1024):h.update(c)
        rec.update(status='downloaded',bytes=p.stat().st_size,sha256=h.hexdigest())
    except Exception as e:rec.update(status='failed',error_type=type(e).__name__,http_status=getattr(e,'code',None))
    (ROOT/(name+'.json')).write_text(json.dumps(rec,indent=2));print(json.dumps(rec),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,JOBS))
