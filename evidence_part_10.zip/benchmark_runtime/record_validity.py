"""Keep invalidated harness runs in raw evidence but out of benchmark comparisons."""
import hashlib,json
def invalid_runs(file):
    path=file.parent/'run_validity.json'
    if not path.exists():return {}
    record=json.loads(path.read_text())
    if record['records_file']!=file.name:return {}
    raw=file.read_bytes()[:record['records_prefix_bytes']]
    if hashlib.sha256(raw).hexdigest()!=record['records_prefix_sha256']:raise ValueError('Run-validity declaration does not match preserved records')
    return record['invalid_runs']
