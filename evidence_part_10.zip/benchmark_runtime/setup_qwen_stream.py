"""Install the publisher-required vLLM backend in disposable local pod storage."""
import pathlib,subprocess,json
root=pathlib.Path('/workspace/speechbench_20260924');env=pathlib.Path('/tmp/speechbench_vllm_env')
subprocess.run(['python3','-m','venv','--system-site-packages',str(env)],check=True)
with (root/'qwen_vllm_install.log').open('wb') as log:
    proc=subprocess.Popen([str(env/'bin/pip'),'install','qwen-asr[vllm]==0.0.6','vllm==0.14.0','numpy==1.26.4','pyarrow==19.0.1',
        '--no-cache-dir','--report',str(root/'envs/qwen_vllm_install.json')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps(dict(pid=proc.pid,environment=str(env))))
