"""Bounded frozen-set ASR queue for the retained RunPod volume."""
from __future__ import annotations

import datetime as dt
import json
import os
import pathlib
import shutil
import signal
import subprocess
import time


ROOT = pathlib.Path("/workspace/speechbench_20260924")
DEFAULT = "/workspace/tts_streaming_suite/.venv_gpu/bin/python"
QWEN = "/tmp/speechbench_vllm_env/bin/python"
VOX = "/workspace/speechbench_20260924/envs/voxcpm/bin/python"
DEADLINE = float(os.environ["BENCH_DEADLINE_EPOCH"])
BASE_ENV = dict(
    os.environ,
    PYTHONUTF8="1",
    PYTHONIOENCODING="utf-8",
    HF_HOME="/workspace/hf_cache",
    HF_HUB_CACHE="/workspace/hf_cache/hub",
    USE_TF="0",
    OMP_NUM_THREADS="4",
    MKL_NUM_THREADS="4",
    COVERAGE_LIMIT="10",
)

JOBS = [
    ("A01", [DEFAULT, "sravaani_run.py"], {"ASR_STAGE": "stream", "ASR_FROZEN_LIMIT": "10"}, 2100),
    ("A02", [VOX, "voxtral_asr_run.py", "--limit", "10"], {"ASR_STAGE": "stream"}, 1200),
    ("A03", [DEFAULT, "asr_baselines.py", "A03", "--limit", "10"], {}, 1500),
    ("A04", [DEFAULT, "asr_baselines.py", "A04", "--limit", "10"], {"A04_CUDNN_SEARCH": "HEURISTIC"}, 1800),
    ("A08", [DEFAULT, "asr_baselines.py", "A08", "--limit", "10"], {}, 1800),
    ("A10", [DEFAULT, "asr_baselines.py", "A10", "--limit", "10"], {}, 1800),
    ("A15", [DEFAULT, "asr_baselines.py", "A15", "--limit", "10"], {}, 1800),
    ("A07", [QWEN, "qwen_stream_run.py", "A07", "--limit", "10", "--all-locales"], {}, 2400),
    ("A09", [QWEN, "qwen_stream_run.py", "A09", "--limit", "10", "--all-locales"], {}, 2400),
]


def run_job(name: str, command: list[str], extra: dict[str, str], timeout: int) -> None:
    remaining = DEADLINE - time.time() - 900
    if remaining < 180:
        raise TimeoutError("RunPod lease has entered its collection-and-shutdown reserve")
    if not pathlib.Path(command[0]).is_file():
        raise FileNotFoundError(command[0])
    record = {
        "job": name,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "command": command,
        "timeout_s": min(timeout, int(remaining)),
    }
    log_path = ROOT / f"{name}-frozen.log"
    with log_path.open("ab") as log:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=dict(BASE_ENV, **extra),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            process.wait(timeout=record["timeout_s"])
            record.update(exit_code=process.returncode, timed_out=False)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            record.update(exit_code=process.returncode, timed_out=True)
    for stage_root in ("/tmp/asr_model_stage", "/tmp/benchmark_model_stage"):
        staged = pathlib.Path(stage_root) / name
        if staged.is_dir() and not staged.is_symlink():
            shutil.rmtree(staged)
    status = subprocess.run(
        [DEFAULT, "frozen_asr_status.py", "--write"],
        cwd=ROOT,
        env=BASE_ENV,
        capture_output=True,
        text=True,
        timeout=120,
    )
    record.update(
        finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        status_exit_code=status.returncode,
    )
    with (ROOT / "frozen_asr_outcomes.jsonl").open("a", encoding="utf-8") as target:
        target.write(json.dumps(record) + "\n")
    print(json.dumps(record), flush=True)


def main() -> None:
    start_at = os.environ.get("ASR_QUEUE_START_AT")
    ready = start_at is None
    for job in JOBS:
        if not ready:
            ready = job[0] == start_at
            if not ready:
                continue
        try:
            run_job(*job)
        except Exception as error:
            failure = {
                "job": job[0],
                "queue_error_type": type(error).__name__,
                "queue_error": str(error),
                "at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            }
            with (ROOT / "frozen_asr_outcomes.jsonl").open("a", encoding="utf-8") as target:
                target.write(json.dumps(failure) + "\n")
            print(json.dumps(failure), flush=True)
            if isinstance(error, TimeoutError):
                break


if __name__ == "__main__":
    main()
