import unittest
from stream_diagnostics import diagnose
class StabilityTests(unittest.TestCase):
    def test_suffix_revision_does_not_reset_stable_first_word(self):
        d=diagnose(dict(hypothesis='The dog',total_s=3,partial_events=[dict(at_s=1,text='The cat'),dict(at_s=2,text='The dog')]))
        self.assertEqual(d['final_word_stable_at_s'],[1,2]);self.assertEqual(d['invalidated_suffix_word_count'],1)
    def test_earlier_match_is_not_stable_if_later_retracted(self):
        d=diagnose(dict(hypothesis='The dog',total_s=4,partial_events=[dict(at_s=1,text='The'),dict(at_s=2,text='A dog'),dict(at_s=3,text='The dog')]))
        self.assertEqual(d['stable_first_word_s'],3)
    def test_empty_final_is_not_zero_latency(self):
        d=diagnose(dict(hypothesis='',total_s=4,partial_events=[dict(at_s=1,text='noise')]))
        self.assertIsNone(d['stable_first_word_s']);self.assertEqual(d['non_monotonic_updates'],1)
