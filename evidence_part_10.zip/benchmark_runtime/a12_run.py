"""Pinned full-utterance evaluation for Microsoft VibeVoice-ASR.

The publisher declares Hindi and English among the benchmark's target
languages. Other target Indic languages are intentionally not sent to this
model because they are absent from its declared language list.
"""
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import pathlib
import resource
import time
import traceback

import torch

from asr_corpus import records
from metrics import score
from vibevoice.modular.modeling_vibevoice_asr import (
    VibeVoiceASRForConditionalGeneration,
)
from vibevoice.processor.vibevoice_asr_processor import VibeVoiceASRProcessor

ROOT = pathlib.Path("/workspace/speechbench_20260924")
LOCALES = ("hi-IN", "en-IN")
SOURCE_REVISION = "1541f590c7099820f10ea012f48d2399282df69f"


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def hypothesis_text(processor, generated_ids) -> tuple[str, str, list]:
    """Return scorer text, raw model text, and parsed timestamped segments."""
    raw_text = processor.decode(generated_ids, skip_special_tokens=True)
    try:
        segments = processor.post_process_transcription(raw_text)
    except Exception:
        segments = []
    texts = []
    for segment in segments or []:
        if isinstance(segment, dict):
            text = segment.get("text") or segment.get("content") or ""
            if text:
                texts.append(str(text).strip())
    return (" ".join(texts).strip() or raw_text.strip(), raw_text, segments)


def main(limit: int, max_new_tokens: int) -> None:
    model_manifest = json.loads((ROOT / "A12_download.json").read_text())
    tokenizer_manifest = json.loads((ROOT / "A12QWEN_download.json").read_text())
    model_path = pathlib.Path(model_manifest["path"])
    tokenizer_path = pathlib.Path(tokenizer_manifest["path"])
    output = ROOT / "A12"
    output.mkdir(exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    started = time.perf_counter()
    processor = VibeVoiceASRProcessor.from_pretrained(
        model_path,
        language_model_pretrained_name=str(tokenizer_path),
        local_files_only=True,
    )
    model = VibeVoiceASRForConditionalGeneration.from_pretrained(
        model_path,
        torch_dtype=torch.bfloat16,
        attn_implementation="sdpa",
        local_files_only=True,
    ).to("cuda").eval()
    initialized = time.perf_counter() - started

    weight_files = sorted(model_path.glob("*.safetensors"))
    environment = {
        "run_id": stamp,
        "model": model_manifest["repo"],
        "revision": model_manifest["revision"],
        "source_repo": "https://github.com/microsoft/VibeVoice",
        "source_revision": SOURCE_REVISION,
        "tokenizer_model": tokenizer_manifest["repo"],
        "tokenizer_revision": tokenizer_manifest["revision"],
        "weights": {file.name: sha256(file) for file in weight_files},
        "runner_sha256": sha256(pathlib.Path(__file__)),
        "mode": "full_utterance",
        "precision": "bfloat16",
        "attention": "sdpa",
        "torch": torch.__version__,
        "transformers": importlib.metadata.version("transformers"),
        "gpu": torch.cuda.get_device_name(0),
        "model_initialization_s": initialized,
        "evaluation_limit_per_locale": limit,
        "max_new_tokens": max_new_tokens,
        "network_namespace_isolated": False,
        "local_files_only": True,
        "evaluated_locales": list(LOCALES),
    }
    (output / f"environment-{stamp}.json").write_text(
        json.dumps(environment, indent=2)
    )

    def infer(audio):
        inputs = processor(
            audio=audio,
            sampling_rate=16000,
            return_tensors="pt",
            padding=True,
            add_generation_prompt=True,
        )
        inputs = {
            key: value.to("cuda") if isinstance(value, torch.Tensor) else value
            for key, value in inputs.items()
        }
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            pad_token_id=processor.pad_id,
            eos_token_id=processor.tokenizer.eos_token_id,
            do_sample=False,
            num_beams=1,
        )
        generated = output_ids[0, inputs["input_ids"].shape[1] :]
        return hypothesis_text(processor, generated)

    first = next(records(["hi-IN"], limit=1))
    with torch.inference_mode():
        infer(first["audio"])

    record_file = output / "file_records.jsonl"
    for locale in LOCALES:
        for row in records([locale], limit=limit):
            record = {key: value for key, value in row.items() if key != "audio"}
            record.update(run_id=stamp, phase="coverage_sweep", mode="full_utterance", ok=False)
            try:
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                started = time.perf_counter()
                with torch.inference_mode():
                    hypothesis, raw_text, segments = infer(row["audio"])
                torch.cuda.synchronize()
                elapsed = time.perf_counter() - started
                duration = len(row["audio"]) / 16000
                record.update(
                    ok=True,
                    hypothesis=hypothesis,
                    raw_model_output=raw_text,
                    structured_segments=segments,
                    total_s=elapsed,
                    audio_duration_s=duration,
                    rtf=elapsed / duration,
                    peak_torch_allocated_bytes=torch.cuda.max_memory_allocated(),
                    peak_torch_reserved_bytes=torch.cuda.max_memory_reserved(),
                    process_lifetime_peak_rss_bytes=(
                        resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
                    ),
                    **score(row["reference"], hypothesis),
                )
            except Exception as error:
                record.update(
                    hypothesis="",
                    error_type=type(error).__name__,
                    error=str(error),
                    traceback=traceback.format_exc(),
                    **score(row["reference"], ""),
                )
            with record_file.open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(
                json.dumps(
                    {key: record.get(key) for key in ("id", "ok", "wer", "rtf", "error")}
                ),
                flush=True,
            )
    (output / f"DONE-{stamp}").write_text(
        json.dumps({"model": "A12", "limit": limit, "locales": LOCALES})
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=3)
    parser.add_argument("--max-new-tokens", type=int, default=512)
    args = parser.parse_args()
    main(args.limit, args.max_new_tokens)
