"""Read-only authenticated HEAD probe. Never emit credential or signed URLs."""
import concurrent.futures,datetime,json,pathlib,re,urllib.request,urllib.parse,os
ROOT=pathlib.Path('/workspace/speechbench_20260924')
token=re.search(r'hf_[A-Za-z0-9]+',pathlib.Path('/workspace/.hf_token_env').read_text()).group()
class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        new=super().redirect_request(req,fp,code,msg,headers,newurl)
        if new is not None and urllib.parse.urlsplit(req.full_url).netloc!=urllib.parse.urlsplit(newurl).netloc:new.remove_header('Authorization')
        return new
def one(j):
    r={**j,'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    prefix='datasets/' if os.environ.get('PROBE_DATASETS')=='1' else ''
    req=urllib.request.Request(f'https://huggingface.co/{prefix}{j["repo"]}/resolve/{j["revision"]}/{j["file"]}',method='HEAD',headers={'Authorization':'Bearer '+token,'User-Agent':'speechbench/1.0'})
    try:
        with urllib.request.build_opener(SafeRedirect()).open(req,timeout=60) as response:r.update(http_status=response.status,access='readable')
    except Exception as e:r.update(http_status=getattr(e,'code',None),access='failed',error_type=type(e).__name__)
    print(json.dumps(r),flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,json.loads((ROOT/os.environ.get('PROBE_MANIFEST','access_jobs.json')).read_text())))
(ROOT/os.environ.get('PROBE_OUTPUT','authenticated_access.json')).write_text(json.dumps(rows,indent=2))
