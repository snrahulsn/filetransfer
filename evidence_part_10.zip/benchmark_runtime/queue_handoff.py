"""Replace the idle parent queue at a worker boundary without overlapping GPU jobs."""
import datetime,json,os,pathlib,signal,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924');PARENT=2577;CHILD=2855
def command(pid):
    try:return pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
    except FileNotFoundError:return ''
if 'unified_queue.py' not in command(PARENT) or 'voxcpm_run.py' not in command(CHILD):raise RuntimeError('Worker changed; no process was interrupted')
os.kill(PARENT,signal.SIGSTOP)
deadline=datetime.datetime(2026,9,23,22,45,22,tzinfo=datetime.timezone.utc).timestamp()
rec=dict(job='T15',queue_handoff=True,started_utc='2026-09-23T22:30:21.770844+00:00',timed_out=False,exit_code=None)
while True:
    try:
        fields=pathlib.Path(f'/proc/{CHILD}/stat').read_text().rsplit(')',1)[1].split()
        if fields[0]=='Z':rec['exit_code']=os.waitstatus_to_exitcode(int(fields[49]));break
    except FileNotFoundError:break
    if time.time()>=deadline:
        os.killpg(CHILD,signal.SIGTERM);time.sleep(5)
        if command(CHILD):os.killpg(CHILD,signal.SIGKILL)
        rec.update(timed_out=True,exit_code=-15);break
    time.sleep(2)
rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (ROOT/'queue_outcomes.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
os.kill(PARENT,signal.SIGTERM);os.kill(PARENT,signal.SIGCONT)
with (ROOT/'unified_queue2.log').open('wb') as log:
    proc=subprocess.Popen(['python3',str(ROOT/'unified_queue.py')],env=dict(os.environ,QUEUE_START_AFTER='T15'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps(dict(completed=rec,next_queue_pid=proc.pid)),flush=True)
