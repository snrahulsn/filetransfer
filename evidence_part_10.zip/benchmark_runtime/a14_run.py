"""Pinned full-utterance evaluation for AI4Bharat IndicWhisper checkpoints."""
import argparse
import datetime
import gc
import hashlib
import importlib.metadata
import json
import os
import pathlib
import resource
import time
import traceback

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

import torch
from safetensors.torch import load_file
from transformers import AutoConfig, AutoModelForSpeechSeq2Seq, AutoProcessor

from asr_corpus import records
from metrics import score

ROOT = pathlib.Path("/workspace/speechbench_20260924")
SOURCE_REVISION = "21dce3406fddf0e18984165e735d23db38760dd3"
LANGUAGE_CODE = {
    "hi-IN": "hi", "bn-IN": "bn", "mr-IN": "mr", "ta-IN": "ta",
    "te-IN": "te", "gu-IN": "gu", "kn-IN": "kn", "ml-IN": "ml",
    "or-IN": "or",
}


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def choose_checkpoint(paths: list[str]) -> pathlib.Path:
    """Select the publisher-documented medium all-data checkpoint."""
    candidates = [pathlib.Path(path) for path in paths]
    preferred = [
        path for path in candidates
        if "whisper-medium" in str(path).lower() and "alldata" in str(path).lower()
    ]
    if not preferred:
        preferred = [path for path in candidates if "whisper-medium" in str(path).lower()]
    if len(preferred) != 1:
        raise RuntimeError(
            "Could not uniquely identify the documented whisper-medium all-data "
            f"checkpoint. Candidates: {[str(path) for path in candidates]}"
        )
    return preferred[0]


def load_model(model_path: pathlib.Path):
    """Load converted publisher tensors without the pathological legacy HF path."""
    tensor_file = model_path / "model.safetensors"
    if not tensor_file.is_file():
        raise FileNotFoundError(f"converted checkpoint missing: {tensor_file}")
    config = AutoConfig.from_pretrained(model_path, local_files_only=True)
    with torch.device("meta"):
        model = AutoModelForSpeechSeq2Seq.from_config(config)
    state = load_file(tensor_file, device="cpu")
    incompatible = model.load_state_dict(state, strict=False, assign=True)
    missing = list(incompatible.missing_keys)
    if missing == ["proj_out.weight"]:
        model.proj_out.weight = model.model.decoder.embed_tokens.weight
        missing = []
    if missing or incompatible.unexpected_keys:
        raise RuntimeError(
            f"checkpoint mismatch missing={missing} "
            f"unexpected={incompatible.unexpected_keys}"
        )
    return model.to(device="cuda", dtype=torch.float16).eval()


def main(limit: int, selected: set[str]) -> None:
    downloads = json.loads((ROOT / "A14_download.json").read_text())
    output = ROOT / "A14"
    output.mkdir(exist_ok=True)
    record_file = output / "file_records.jsonl"
    completed = []

    for asset in downloads:
        locale = asset["locale"]
        if selected and locale not in selected:
            continue
        model_path = choose_checkpoint(asset["model_directories"])
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        started = time.perf_counter()
        processor = AutoProcessor.from_pretrained(model_path, local_files_only=True)
        model = load_model(model_path)
        language = LANGUAGE_CODE[locale]
        if language == "or":
            forced_decoder_ids = processor.get_decoder_prompt_ids(
                language=None, task="transcribe"
            )
        else:
            forced_decoder_ids = processor.get_decoder_prompt_ids(
                language=language, task="transcribe"
            )
        model.generation_config.forced_decoder_ids = forced_decoder_ids
        initialized = time.perf_counter() - started
        weight_files = sorted(model_path.glob("*.safetensors")) + sorted(
            model_path.glob("*.bin")
        )
        environment = {
            "run_id": stamp,
            "model": "AI4Bharat IndicWhisper medium all-data",
            "source_repo": "https://github.com/AI4Bharat/vistaar",
            "source_revision": SOURCE_REVISION,
            "locale": locale,
            "checkpoint": str(model_path),
            "checkpoint_files": {file.name: sha256(file) for file in weight_files},
            "archive_url": asset["url"],
            "archive_sha256": asset["archive_sha256"],
            "archive_bytes": asset["archive_bytes"],
            "publisher_etag": asset["etag"],
            "runner_sha256": sha256(pathlib.Path(__file__)),
            "mode": "full_utterance",
            "precision": "float16",
            "load_strategy": "converted_safetensors_meta_assign_then_cuda",
            "torch": torch.__version__,
            "transformers": importlib.metadata.version("transformers"),
            "gpu": torch.cuda.get_device_name(0),
            "model_initialization_s": initialized,
            "evaluation_limit_per_locale": limit,
            "network_namespace_isolated": False,
            "local_files_only": True,
        }
        (output / f"environment-{locale}-{stamp}.json").write_text(
            json.dumps(environment, indent=2)
        )

        first = next(records([locale], limit=1))

        def infer(audio):
            features = processor(
                audio, return_tensors="pt", sampling_rate=16000
            ).input_features.to(device="cuda", dtype=torch.float16)
            predicted_ids = model.generate(
                features,
            )
            return processor.tokenizer.batch_decode(
                predicted_ids, skip_special_tokens=True, normalize=False
            )[0]

        with torch.inference_mode():
            infer(first["audio"])

        for row in records([locale], limit=limit):
            record = {key: value for key, value in row.items() if key != "audio"}
            record.update(run_id=stamp, phase="coverage_sweep", mode="full_utterance", ok=False)
            try:
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                started = time.perf_counter()
                with torch.inference_mode():
                    hypothesis = infer(row["audio"])
                torch.cuda.synchronize()
                elapsed = time.perf_counter() - started
                duration = len(row["audio"]) / 16000
                record.update(
                    ok=True,
                    hypothesis=hypothesis,
                    total_s=elapsed,
                    audio_duration_s=duration,
                    rtf=elapsed / duration,
                    peak_torch_allocated_bytes=torch.cuda.max_memory_allocated(),
                    peak_torch_reserved_bytes=torch.cuda.max_memory_reserved(),
                    process_lifetime_peak_rss_bytes=(
                        resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
                    ),
                    checkpoint=str(model_path),
                    **score(row["reference"], hypothesis),
                )
            except Exception as error:
                record.update(
                    hypothesis="",
                    error_type=type(error).__name__,
                    error=str(error),
                    traceback=traceback.format_exc(),
                    checkpoint=str(model_path),
                    **score(row["reference"], ""),
                )
            with record_file.open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(
                json.dumps(
                    {key: record.get(key) for key in ("id", "ok", "wer", "rtf", "error")}
                ),
                flush=True,
            )
        completed.append(locale)
        del model, processor
        gc.collect()
        torch.cuda.empty_cache()

    done_stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    (output / f"DONE-{done_stamp}").write_text(
        json.dumps({"model": "A14", "limit": limit, "locales": completed})
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=3)
    parser.add_argument("--locales", nargs="*")
    args = parser.parse_args()
    main(args.limit, set(args.locales or []))
