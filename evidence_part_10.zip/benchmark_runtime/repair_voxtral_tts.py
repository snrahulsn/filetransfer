"""Resume the timed-out isolated install without optional bytecode compilation."""
import datetime,json,pathlib,subprocess
ROOT=pathlib.Path('/workspace/speechbench_20260924')
PY='/tmp/speechbench_omni_env/bin/python'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    status=ROOT/'voxtral_tts_setup.json';previous=json.loads(status.read_text())
    if previous['state']!='failed' or previous.get('error_type')!='TimeoutExpired':raise RuntimeError('Unexpected setup state')
    record=dict(started_utc=now(),state='installing',backend=previous['backend'],previous_attempt=previous,may_overlap_provisional_inference=True)
    status.write_text(json.dumps(record,indent=2))
    try:
        subprocess.run([PY,'-m','pip','install','--no-compile','--no-cache-dir','--progress-bar','off','--report',str(ROOT/'envs/vllm_omni_repair_install.json'),
            'vllm==0.18.0','vllm-omni==0.18.0','numpy==2.2.6','mistral-common[audio]==1.12.0'],check=True,timeout=600)
        subprocess.run([PY,'-c','from vllm import SamplingParams; from vllm_omni import AsyncOmni; from mistral_common.protocol.speech.request import SpeechRequest; import torch; print(torch.__version__)'],check=True,timeout=120)
        record.update(state='installed',import_check_passed=True)
    except Exception as e:record.update(state='failed',error_type=type(e).__name__,error=str(e));raise
    finally:record['finished_utc']=now();status.write_text(json.dumps(record,indent=2))
if __name__=='__main__':main()
