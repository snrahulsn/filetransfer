"""Pinned Bodhan full-output smoke with verified cached artifacts and stock voices."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import datetime,hashlib,importlib.util,json,pathlib,shutil,sys,time,traceback,warnings
import numpy as np,soundfile as sf,torch
from snac_run import TEXTS,digest
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T06'
PIN='76e0814f189321efe550011850cd288dae366aad'
SOURCE=pathlib.Path('/workspace/bodhan_indic_speak_qual/model_cache/indic-speak')
TARGET=pathlib.Path('/tmp/benchmark_model_stage/T06')
VOICES={'en-IN':'Kavya','hi-IN':'Kavya','bn-IN':'Ishita','mr-IN':'Anagha','te-IN':'Sravani','ta-IN':'Anitha','gu-IN':'Dhara','kn-IN':'Deepika','ml-IN':'Lakshmi','or-IN':'Itishree'}
torch.set_num_threads(4)
def verified_stage():
    meta=json.loads((ROOT/'T06-metadata-blobs.json').read_text())
    if meta['sha']!=PIN:raise ValueError('Publisher revision mismatch')
    manifest={}
    for item in meta['siblings']:
        name=item['rfilename']
        if pathlib.Path(name).suffix not in {'.py','.json','.safetensors','.pt','.model','.jinja'}:continue
        source=SOURCE/name
        if not source.is_file():raise FileNotFoundError(str(source))
        dest=TARGET/name;dest.parent.mkdir(parents=True,exist_ok=True)
        h=hashlib.sha256();git=hashlib.sha1(('blob '+str(source.stat().st_size)+'\0').encode())
        with source.open('rb') as src,dest.open('wb') as out:
            while data:=src.read(8388608):h.update(data);git.update(data);out.write(data)
        expected=item.get('lfs',{}).get('sha256') or item['blobId']
        actual=h.hexdigest() if 'lfs' in item else git.hexdigest()
        if actual!=expected:raise ValueError('Publisher hash mismatch: '+name)
        manifest[name]=dict(sha256=h.hexdigest(),bytes=dest.stat().st_size,publisher_digest_verified=True)
    return manifest
def main():
    OUT.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    files=verified_stage()
    # All executable source is verified before import. Resolve the codec to its pinned local snapshot.
    spec=importlib.util.spec_from_file_location('bodhan_pinned_inference',TARGET/'inference.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    codec=pathlib.Path('/workspace/hf_cache/hub/models--hubertsiuzdak--snac_24khz/snapshots/d73ad176a12188fcf4f360ba3bf2c2fbbe8f58ec')
    module.SNAC_REPO=str(codec)
    tts=module.TTS(str(TARGET),device='cuda')
    env=dict(run_id=stamp,model='bodhan-ai/indic-speak',revision=PIN,files=files,runner_sha256=digest(__file__),
             torch=torch.__version__,gpu=torch.cuda.get_device_name(0),precision='bfloat16 LM; float32 Vocos',
             codec_revision=codec.name,codec_sha256=digest(codec/'pytorch_model.bin'),mode='full_output',synthesis_class='C',
             voice_source='publisher-listed stock voices',hf_offline=True,network_namespace_isolated=False)
    (OUT/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    items=TEXTS+[('or-IN','Odia','ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।')]
    for i,(locale,language,text) in enumerate([items[0]]*3+items):
        rec=dict(run_id=stamp,locale=locale,text=text,voice=VOICES[locale],phase='warmup' if i<3 else 'smoke',mode='full',synthesis_class='C',ok=False,
                 temperature=.6,top_p=.9,top_k=50,max_new_tokens=2520,seed=20260924)
        try:
            torch.cuda.synchronize();start=time.perf_counter()
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                audio=tts(text,speaker=VOICES[locale],temperature=.6,top_p=.9,top_k=50,max_new_tokens=2520,seed=20260924)
            torch.cuda.synchronize();elapsed=time.perf_counter()-start
            rec['warnings']=[str(w.message) for w in caught]
            if any('max_new_tokens' in s for s in rec['warnings']):raise RuntimeError('Token limit reached; output may be truncated')
            if not len(audio) or not np.isfinite(audio).all():raise ValueError('Invalid audio')
            rec.update(ok=True,total_s=elapsed,ttfa_s=elapsed,sample_rate=24000,audio_duration_s=len(audio)/24000,rtf=elapsed/(len(audio)/24000))
            if i>=3:
                path=OUT/f'{stamp}-{locale}.flac';sf.write(path,audio,24000,subtype='PCM_24')
                rec.update(file=str(path.relative_to(ROOT)),sha256=digest(path))
        except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        print(json.dumps({k:rec.get(k) for k in ['locale','phase','ok','rtf','error']}),flush=True)
    (OUT/'DONE').write_text('Ten target-language full-output smoke attempts complete; full qualification pending.\n')
    shutil.rmtree(TARGET)
if __name__=='__main__':main()
