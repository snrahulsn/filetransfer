"""Verify retained evidence and source provenance without inferring qualification."""
import datetime,hashlib,json,pathlib
from record_validity import invalid_runs
ROOT=pathlib.Path(__file__).resolve().parents[1]
E=ROOT/'execution';SNAP=E/'fresh_current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    sources=list((ROOT/'benchmark_runtime').glob('*.py'))+list((E/'runner_sources').glob('*.py'))+list(E.glob('*.py'))+list(SNAP.glob('*.py'))
    by_hash={}
    for p in sources:by_hash.setdefault(sha(p),[]).append(str(p.relative_to(ROOT)))
    provenance=[];errors=[];audio={};smoke=set();valid_rows=0;invalid_rows=0
    for p in SNAP.glob('*/environment*.json'):
        row=json.loads(p.read_text());digest=row.get('runner_sha256')
        if digest:
            found=by_hash.get(digest,[])
            provenance.append(dict(environment=str(p.relative_to(ROOT)),recorded_runner_sha256=digest,matching_sources=found))
            if not found:errors.append('Missing executed source: '+str(p))
    for p in SNAP.glob('*/**/*records.jsonl'):
        excluded=invalid_runs(p)
        for line in p.read_text().splitlines():
            row=json.loads(line)
            if row.get('run_id') in excluded:invalid_rows+=1
            else:valid_rows+=1
            if row.get('file'):
                f=(SNAP/row['file']).resolve()
                if not f.is_relative_to(SNAP.resolve()):raise ValueError('Unsafe audio path')
                if row['file'] in audio and audio[row['file']]!=row['sha256']:errors.append('Conflicting audio hash '+row['file'])
                audio[row['file']]=row['sha256']
                if row.get('phase')=='smoke' and row.get('ok'):smoke.add(row['file'])
    for name,digest in audio.items():
        p=SNAP/name
        if not p.exists() or sha(p)!=digest:errors.append('Missing or altered audio '+name)
    out=dict(at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshot=json.loads((SNAP/'snapshot.json').read_text()),executed_sources_checked=len(provenance),distinct_audio_files=len(audio),successful_smoke_audio_files=len(smoke),valid_record_rows=valid_rows,invalidated_record_rows_retained=invalid_rows,errors=errors,qualification_complete=False)
    (E/'evidence_integrity.json').write_text(json.dumps(out,indent=2))
    (E/'runner_provenance.json').write_text(json.dumps(dict(checked=len(provenance),missing=sum(not x['matching_sources'] for x in provenance),rows=provenance),indent=2))
    print(json.dumps(out,indent=2))
    if errors:raise SystemExit(1)
if __name__=='__main__':main()
