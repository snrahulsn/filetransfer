"""Validate the owner's single-score listening export."""
import argparse,collections,datetime,hashlib,json,pathlib
DIMS=('Overall',)
def validate(package,export):
    manifest=json.loads((package/'package_manifest.json').read_text())
    mapping=json.loads((package/'blind_key.json').read_text())
    if hashlib.sha256(json.dumps(mapping,sort_keys=True).encode()).hexdigest()!=manifest['package_id']:raise ValueError('Package mapping checksum mismatch')
    key={r['id']:r for r in mapping}
    if len(key)!=len(mapping) or len(key)!=manifest['clip_count']:raise ValueError('Clip accounting mismatch')
    if export.get('package_id')!=manifest['package_id']:raise ValueError('Ratings belong to a different clip package')
    rater=export.get('rater')
    if not isinstance(rater,str) or not rater.strip():raise ValueError('Missing rater label')
    ratings=export.get('ratings')
    if not isinstance(ratings,dict):raise ValueError('Ratings must be keyed by clip ID')
    rows=[]
    for clip,r in ratings.items():
        if clip not in key:raise ValueError('Unknown clip ID: '+clip)
        if not isinstance(r,dict):raise ValueError('Invalid rating object')
        values={}
        for dim in DIMS:
            value=r.get(dim)
            if value is not None and (type(value) is not int or not 1<=value<=5):raise ValueError('Rating must be an integer from 1 to 5 or null')
            values[dim]=value
        comment=r.get('comment','')
        if not isinstance(comment,str):raise ValueError('Invalid comment')
        listened=r.get('listened_to_end',False)
        if type(listened) is not bool:raise ValueError('Invalid listening-completion flag')
        rows.append(dict(**key[clip],rater=rater.strip(),ratings=values,comment=comment,listened_to_end=listened))
    return dict(package_id=manifest['package_id'],rater=rater.strip(),scope='individual listener; one overall 1-5 score per clip',
                package_clips=len(key),submitted_clips=len(rows),unsubmitted_clips=len(key)-len(rows),rows=rows)
def main():
    p=argparse.ArgumentParser();p.add_argument('package',type=pathlib.Path);p.add_argument('export',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
    raw=a.export.read_bytes();result=validate(a.package,json.loads(raw));result.update(source_export_sha256=hashlib.sha256(raw).hexdigest(),imported_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if a.output.exists():raise FileExistsError('Choose a new output path to preserve earlier rating evidence')
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
if __name__=='__main__':main()
