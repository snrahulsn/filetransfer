"""Repair only dependency additions interrupted by the volume quota."""
import json,pathlib,subprocess
root=pathlib.Path('/workspace/speechbench_20260924')
report=json.loads((root/'envs/voxcpm_install.json').read_text())
packages=[x['metadata']['name']+'=='+x['metadata']['version'] for x in report['install']]
with (root/'voxcpm_install_repair.log').open('wb') as log:
    proc=subprocess.Popen([str(root/'envs/voxcpm/bin/pip'),'install','--force-reinstall','--no-deps','--no-cache-dir',*packages],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps(dict(pid=proc.pid,packages=packages)))
