"""Build one blind listening clip for every playable TTS report cell."""
from __future__ import annotations

import hashlib
import json
import pathlib
import random
import shutil

import final_two_table_report as report
from listening_package import PAGE

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "LISTENING_REVIEW"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    previous = report.read_json(OUT / "blind_key.json", []) or []
    old_manifest = report.read_json(OUT / "package_manifest.json", {}) or {}
    old_by_pair = {(r["model_id"], r["locale"]): r for r in previous}
    pocket = {r.get("locale"): r for r in (report.read_json(report.DATA / "T02_indic" / "results.json", {}) or {}).get("results", []) if r.get("success")}
    staging = ROOT / "tmp" / "blind_final_build"
    shutil.rmtree(staging, ignore_errors=True)
    (staging / "clips").mkdir(parents=True)
    clips, mapping, missing = [], [], []
    for mid in (m for m in report.NAMES if m.startswith("T")):
        mode = report.TTS_MODE[mid][1]
        records = [r for r in report.read_jsonl(report.DATA / mid / "records.jsonl") if r.get("ok") and r.get("mode") == mode]
        for locale, _ in report.LANGS:
            row = pocket.get(locale) if mid == "T02" else None
            if row is None:
                matching = [r for r in records if r.get("locale") == locale]
                row = matching[-1] if matching else None
            source = report.choose_audio(row, mid) if row else None
            old = old_by_pair.get((mid, locale))
            if source is None and old:
                source = OUT / "clips" / (old["id"] + pathlib.Path(old["source_file"]).suffix)
            if source is None or not source.is_file():
                missing.append((mid, locale))
                continue
            sha = digest(source)
            if row and row.get("sha256") and row["sha256"] != sha:
                raise ValueError(f"Audio checksum mismatch: {source}")
            if old and old.get("sha256") == sha:
                clip_id = old["id"]
            else:
                source_id = str(row.get("file") if row else source.relative_to(ROOT))
                clip_id = "C" + hashlib.sha256((mid + source_id + sha).encode()).hexdigest()[:10]
            target = staging / "clips" / (clip_id + source.suffix)
            shutil.copyfile(source, target)
            spoken = (row or {}).get("text") or (old or {}).get("text")
            if not spoken:
                raise ValueError(f"Missing reference sentence: {mid} {locale}")
            source_file = (row or {}).get("file") or (old or {}).get("source_file")
            mapping.append({"id": clip_id, "locale": locale, "text": spoken, "model_id": mid,
                            "source_file": source_file, "sha256": sha, "mode": mode,
                            "voice": (row or {}).get("voice"), "run_id": (row or {}).get("run_id"),
                            "prompt_sha256": hashlib.sha256(spoken.encode()).hexdigest()})
            clips.append({"id": clip_id, "locale": locale, "text": spoken, "file": "clips/" + target.name})
    if len(clips) != 105 or len({r["id"] for r in mapping}) != len(clips):
        raise ValueError(f"Expected 105 unique playable model-language clips, found {len(clips)}; missing: {missing}")
    random.Random(20260930).shuffle(clips)
    package_id = hashlib.sha256(json.dumps(mapping, sort_keys=True).encode()).hexdigest()
    safe = json.dumps(clips, ensure_ascii=False).replace("<", "\\u003c")
    previous_id = old_manifest.get("previous_package_id", old_manifest.get("package_id", package_id))
    page = PAGE.replace("CLIPS_JSON", safe).replace("PREV_PACKAGE_ID", json.dumps(previous_id)).replace("PACKAGE_ID", json.dumps(package_id))
    (staging / "index.html").write_text(page)
    (staging / "blind_key.json").write_text(json.dumps(mapping, indent=2, ensure_ascii=False) + "\n")
    (staging / "package_manifest.json").write_text(json.dumps({"package_id": package_id, "previous_package_id": previous_id, "clip_count": len(clips),
        "rating_scope": "one blind overall 1-5 score per playable model-language cell"}, indent=2) + "\n")
    shutil.rmtree(OUT)
    shutil.move(staging, OUT)
    print(json.dumps({"clips": len(clips), "models": len({r["model_id"] for r in mapping}), "languages": len({r["locale"] for r in mapping}), "package_id": package_id}))


if __name__ == "__main__":
    main()
