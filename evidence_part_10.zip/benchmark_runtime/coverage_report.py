"""Keep publisher-declared language coverage separate from actual successful trials."""
import collections,hashlib,json,pathlib
from record_validity import invalid_runs
ROOT=pathlib.Path(__file__).resolve().parents[1];E=ROOT/'execution';S=E/'sources'
TARGET=['hi','en','bn','mr','ta','te','gu','kn','ml','or']
REGIONAL=[x for x in TARGET if x!='en']
OVERRIDES={
 'A04':(REGIONAL,'README.md'),
 'A05':(TARGET,'../omni-lang-ids.py'), 'A06':(TARGET,'../omni-lang-ids.py'),
 'A07':(['hi','en'],'README.md'),'A09':(['hi','en'],'README.md'),
 'A14':(REGIONAL,'README.md'),'T03':(['hi','en'],'VOICES.md'),
 'T12':(['en'],'README.md'),'T17':(['hi','en'],'README.md'),
 'T18':(TARGET,'../T18-family'),'T19':([x for x in TARGET if x not in ['hi','en']],'README.md')}
NOTES={
 'A05':'Declared family language IDs verified in pinned Omni source 81f51e224ce9e74b02cc2a3eaf21b2d91d743455; CTC runtime validation pending.',
 'A06':'Declared family language IDs verified in pinned Omni source 81f51e224ce9e74b02cc2a3eaf21b2d91d743455; CTC runtime validation pending.',
 'A08':'Odia is absent from the published language-token list; no native Odia configuration is claimed.',
 'A10':'Odia is absent from the published language-token list; no native Odia configuration is claimed.',
 'A14':'Nine target-language archive URLs returned HTTP 200 on HEAD. Archives total about 15.55 GB; HEAD access is not downloaded-weight verification. Each language is a separate model.',
 'A15':'Separate language adapters. The pinned model card lists google/fleurs among its datasets; split provenance is not established here, so independent-test status is not assumed.',
 'T01':'Odia is absent from the explicit 19-language list.',
 'T02':'Official checkpoint only; community Hindi derivatives are not attributed to it. Repository contact-sharing confirmation remains pending.',
 'T03':'Hindi coverage comes from the pinned VOICES.md; the model-card language header lists only English. Tested English voice af_heart is American English.',
 'T08':'English is absent from the explicit supported-language list.',
 'T11':'Separate Hindi female and male adapters, with required matched base controls; not the unidentified historical configuration.',
 'T12':'English is the only target language declared for the unadapted base. Hindi/Indic base controls, if run for adapter comparisons, are out-of-declared-language controls.',
 'T16':'Odia is not explicitly listed; “and more” is insufficient evidence to assert support.',
 'T18':'Ten separate official language repositories have pinned manifests; this is not one multilingual checkpoint.',
 'T19':'Eight target languages have explicitly listed adapter pairs. Hindi and English are not listed; adapters are separate configurations.'}
def main():
    inventory=json.loads((ROOT/'indic_speech_benchmark_prd_v1/configs/model_inventory.json').read_text())['entries']
    counts=collections.defaultdict(collections.Counter)
    for file in (E/'fresh_current').glob('*/**/*records.jsonl'):
        invalid=invalid_runs(file)
        for line in file.read_text().splitlines():
            row=json.loads(line)
            if row.get('run_id') in invalid:continue
            if row.get('phase') not in ['warmup','tts_intelligibility']:counts[file.relative_to(E/'fresh_current').parts[0]][(row.get('locale'),bool(row.get('ok')))]+=1
    rows=[]
    for entry in inventory:
        key=entry['model_id'];audit=json.loads((S/key/'audit.json').read_text())
        declared,source=OVERRIDES.get(key,(audit.get('declared_languages') or [],'audit.json'))
        cells={lang+'-IN':dict(publisher_declared=lang in declared,successful_trials=counts[key][(lang+'-IN',True)],failed_trials=counts[key][(lang+'-IN',False)]) for lang in TARGET}
        rows.append(dict(model_id=key,name=entry['display_name'],revision=audit.get('revision'),declaration_source=str((S/key/source).relative_to(ROOT)),
                         declaration_source_sha256=hashlib.sha256((S/key/source).read_bytes()).hexdigest() if (S/key/source).is_file() else None,
                         cells=cells,note=NOTES.get(key,''),qualification_complete=False))
    (E/'language_coverage.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False))
    lines=['# Language coverage and execution accounting','',
           'All ten columns are target locales ending in -IN. **D** means the publisher declares the language; **—** means it is not explicitly listed in the reviewed source. Neither is a quality score or an automatic exclusion. Generic English support does not establish Indian-accent quality.','',
           'A number after the slash is the count of successful non-warmup trials saved so far. Counts can include repeated prompts, multiple modes and lookaheads; they are **not unique utterance counts** or comparable quality sample sizes. Zero means no successful measured trial is present, not that the model failed. Failures and configuration details remain in the JSON and raw evidence.','',
           '| ID | '+ ' | '.join(TARGET)+' |','|---|'+'---|'*len(TARGET)]
    for row in rows:
        cells=[('D' if row['cells'][lang+'-IN']['publisher_declared'] else '—')+'/'+str(row['cells'][lang+'-IN']['successful_trials']) for lang in TARGET]
        lines.append('| '+row['model_id']+' | '+' | '.join(cells)+' |')
    lines+=['','## Evidence and configuration notes','']
    for row in rows:
        if row['note']:lines.append(f'- **{row["model_id"]}**: {row["note"]}')
    lines+=['','[Machine-readable matrix with source paths and revisions](execution/language_coverage.json). [Current execution report and metric links](BENCHMARK_PROGRESS.md). All 34 entries remain in scope; full qualification is incomplete.','']
    (ROOT/'LANGUAGE_COVERAGE.md').write_text('\n'.join(lines))
if __name__=='__main__':main()
