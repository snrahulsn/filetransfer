"""Preserve raw traces; correct interpretation of AsyncOmni's per-chunk finished flag."""
import datetime,hashlib,json,pathlib
ROOT=pathlib.Path('/workspace/speechbench_20260924/T10')
raw=(ROOT/'records.jsonl').read_bytes();corrections=[]
for index,line in enumerate(raw.splitlines(),1):
    row=json.loads(line);events=row.get('chunk_events',[])
    if row.get('ok') and len(events)>1 and events[0]['at_s']<events[-1]['at_s']:
        corrections.append(dict(row_number=index,run_id=row['run_id'],locale=row['locale'],phase=row['phase'],
            original_synthesis_class=row.get('synthesis_class'),synthesis_class='A',audio_before_final_result=True))
report=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records_file='records.jsonl',
    records_prefix_bytes=len(raw),records_prefix_sha256=hashlib.sha256(raw).hexdigest(),corrections=corrections,
    reason='AsyncOmni finished is true for each completed codec chunk. It does not mean the entire requested utterance has finished. Distinct waveform chunks arrive over time within the single input sentence; the publisher codec-streaming path does not split input into completed sentences. Class C in the original runner was an interpretation error.',
    timing_and_audio_unchanged=True)
(ROOT/'classification_correction.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(corrected=len(corrections),original_records_preserved=True)))
