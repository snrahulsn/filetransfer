"""Transparent corpus-weighted edit counts; preserve Indic combining marks."""
import unicodedata

def normalize(text):
    text=unicodedata.normalize('NFC',text).casefold()
    return ' '.join(''.join(' ' if unicodedata.category(c)[0] in 'PZ' else c for c in text).split())

def distance(a,b):
    previous=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        current=[i]
        for j,y in enumerate(b,1):
            current.append(min(previous[j]+1,current[j-1]+1,previous[j-1]+(x!=y)))
        previous=current
    return previous[-1]

def score(reference,hypothesis):
    ref,hyp=normalize(reference),normalize(hypothesis)
    rw,hw=ref.split(),hyp.split()
    rc,hc=list(ref.replace(' ','')),list(hyp.replace(' ',''))
    we,ce=distance(rw,hw),distance(rc,hc)
    return dict(word_edits=we,reference_words=len(rw),char_edits=ce,reference_chars=len(rc),
                wer=we/len(rw) if rw else None,cer=ce/len(rc) if rc else None,
                empty_reference=not ref,hallucinated_on_empty=not ref and bool(hyp))
