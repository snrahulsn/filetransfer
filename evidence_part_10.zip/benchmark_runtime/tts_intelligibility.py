"""ASR-on-synthesis diagnostic; not a human intelligibility or MOS substitute."""
import hashlib,json,pathlib,time,traceback
import numpy as np,soundfile as sf,torch
from scipy.signal import resample_poly
from math import gcd
from metrics import score
def association_key(row):
    return (row.get('source_tts_model'),row.get('source_tts_mode'),row.get('source_tts_run_id'),row.get('id'),row.get('synthetic_audio_sha256'))
def run(model,root,run_id,asr_revision):
    output=root/'A01/tts_intelligibility_records.jsonl';completed=set()
    if output.exists():
        for line in output.read_text().splitlines():
            row=json.loads(line)
            if row.get('ok'):completed.add(association_key(row))
    for records in sorted(root.glob('T[0-9][0-9]/records.jsonl')):
        for line in records.read_text().splitlines():
            source=json.loads(line)
            if source.get('phase')!='smoke' or not source.get('ok') or not source.get('file'):continue
            audio_file=(root/source['file']).resolve()
            if not audio_file.is_relative_to(root.resolve()):raise ValueError('Audio path outside benchmark')
            if hashlib.sha256(audio_file.read_bytes()).hexdigest()!=source['sha256']:raise ValueError('Synthetic audio checksum mismatch')
            rec=dict(run_id=run_id,id=source['file'],locale=source['locale'],reference=source['text'],source_tts_model=records.parent.name,
                     source_tts_mode=source['mode'],source_tts_run_id=source.get('run_id'),synthetic_audio_sha256=source['sha256'],
                     dataset='generated_tts/'+records.parent.name,condition='saved_clean_waveform',phase='tts_intelligibility',
                     mode='asr_on_generated_tts_full_utterance',asr_model='ARTPARK-IISc/SraVaani-0.5-live',asr_revision=asr_revision,
                     lookahead_ms=480,ok=False,human_intelligibility_score=None)
            if association_key(rec) in completed:continue
            try:
                audio,sr=sf.read(audio_file,dtype='float32')
                if audio.ndim!=1:raise ValueError('Expected mono TTS output')
                rec['original_sample_rate']=sr
                if sr!=16000:
                    divisor=gcd(sr,16000);audio=resample_poly(audio,16000//divisor,sr//divisor).astype(np.float32)
                rec.update(resampling='scipy.signal.resample_poly' if sr!=16000 else 'none',audio_duration_s=len(audio)/16000)
                start=time.perf_counter()
                with torch.inference_mode():hyp=model.transcribe([audio])[0]
                torch.cuda.synchronize()
                rec.update(ok=True,hypothesis=hyp,diagnostic_processing_s=time.perf_counter()-start,**score(rec['reference'],hyp))
            except Exception as e:rec.update(hypothesis='',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),**score(rec['reference'],''))
            with output.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            if rec['ok']:completed.add(association_key(rec))
            print(json.dumps({k:rec.get(k) for k in ['source_tts_model','locale','ok','wer','error']}),flush=True)
