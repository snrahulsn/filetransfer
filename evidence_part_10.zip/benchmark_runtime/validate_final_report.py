"""Validate the final report, waveform links, frozen ASR counts, and shutdown state."""
import hashlib,json,pathlib,re,subprocess
from urllib.parse import unquote
ROOT=pathlib.Path(__file__).resolve().parents[1]
doc=(ROOT/"BENCHMARK_REPORT.html").read_text()
assert doc.count("<table")==2
assert doc.count("<b>A")==15 and doc.count("<b>T")==19
assert "Pending" not in doc and "Grok" not in doc
assert doc.count(">▶</a>")==92
for value in re.findall(r'href="([^"]+)"',doc):
    if value.startswith(("http://","https://")): continue
    p=ROOT/unquote(value)
    if value.endswith("/"): assert p.is_dir(),value
    else: assert p.exists(),value
for i in range(1,16):
    p=ROOT/"execution/fresh_current"/f"A{i:02d}"/"frozen_records.jsonl"
    assert p.is_file() and any(json.loads(x).get("ok") for x in p.read_text().splitlines())
for i in range(1,20):
    p=ROOT/"execution/fresh_current"/f"T{i:02d}"/"records.jsonl"
    assert p.is_file() and any(json.loads(x).get("ok") for x in p.read_text().splitlines())
shutdown=json.loads((ROOT/"execution/final_shutdown_verification.json").read_text())
assert shutdown["all_stopped"] and all(x["desiredStatus"]=="EXITED" and x["runtime"] is None for x in shutdown["runtime_states"])
info=subprocess.check_output(["pdfinfo",str(ROOT/"BENCHMARK_REPORT.pdf")],text=True)
assert re.search(r"^Pages:\s+1$",info,re.M)
result={"valid":True,"tables":2,"asr_models":15,"tts_models":19,"playable_tts_cells":92,"pdf_pages":1,"runpod_records":len(shutdown["pods"]),"all_runpod_instances_stopped":True}
(ROOT/"execution/final_report_validation.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
