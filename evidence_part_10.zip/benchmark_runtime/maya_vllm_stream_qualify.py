"""Execute Maya1's pinned publisher vLLM streaming reference implementation."""
from __future__ import annotations

import asyncio
import datetime as dt
import hashlib
import json
import os
import pathlib
import time
import traceback

os.environ.update(HF_HOME="/workspace/hf_cache", HF_HUB_CACHE="/workspace/hf_cache/hub", USE_TF="0")

import numpy as np
import soundfile as sf
import torch

from maya1_vllm_streaming_inference import Maya1VoiceModel, Maya1VoiceStreamingPipeline, SNACDecoder
from tts_delivery import diagnose


ROOT = pathlib.Path("/workspace/speechbench_20260924")
OUT = ROOT / "T05"
PIN = "21c682a0afef8c13a89b2512733c8bf5f0c52eb7"
SOURCE_PIN = "74c342b77ac595eae1f49da16f4a706b720ea63b"
MODEL = pathlib.Path("/workspace/hf_cache/models--maya-research--maya1/snapshots") / PIN
DESCRIPTION = "A clear adult female voice with an Indian English accent, moderate pace, warm timbre, and neutral professional delivery."
TEXT = "Your meeting with Priya is tomorrow at three thirty PM. Please arrive on time and bring the updated project plan."


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


async def main() -> None:
    OUT.mkdir(exist_ok=True)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    model = Maya1VoiceModel(model_path=str(MODEL), dtype="bfloat16", max_model_len=4096, gpu_memory_utilization=0.72)
    # The pinned publisher runner calls apply_chat_template(), but the pinned
    # checkpoint omits chat_template. Supply the model family's canonical
    # Llama-3 conversation framing so the published streaming path can run.
    if not model.tokenizer.chat_template:
        model.tokenizer.chat_template = (
            "{{ bos_token }}{% for message in messages %}"
            "{{ '<|start_header_id|>' + message['role'] + '<|end_header_id|>\\n\\n' }}"
            "{{ message['content'] | trim }}{{ '<|eot_id|>' }}"
            "{% endfor %}{% if add_generation_prompt %}"
            "{{ '<|start_header_id|>assistant<|end_header_id|>\\n\\n' }}{% endif %}"
        )
    decoder = SNACDecoder(device="cuda")
    pipeline = Maya1VoiceStreamingPipeline(model, decoder)
    environment = {
        "run_id": stamp,
        "model": "maya-research/maya1",
        "model_revision": PIN,
        "publisher_source_revision": SOURCE_PIN,
        "publisher_source_sha256": digest(ROOT / "maya1_vllm_streaming_inference.py"),
        "runner_sha256": digest(pathlib.Path(__file__)),
        "gpu": torch.cuda.get_device_name(0),
        "mode": "publisher_vllm_streaming_snac7",
        "precision": "bfloat16",
        "sample_rate": 24000,
    }
    (OUT / f"environment-stream-{stamp}.json").write_text(json.dumps(environment, indent=2))
    for phase in ("warmup", "smoke"):
        record = {"run_id": stamp, "phase": phase, "locale": "en-IN", "text": TEXT, "voice": DESCRIPTION, "mode": "native_stream", "implementation": "publisher_vllm_streaming_inference.py", "synthesis_class": "A", "ok": False}
        try:
            torch.manual_seed(20260924)
            torch.cuda.reset_peak_memory_stats()
            started = time.perf_counter()
            chunks = []
            events = []
            async for raw in pipeline.generate_speech_stream(description=DESCRIPTION, text=TEXT, temperature=0.4, top_p=0.9, max_tokens=700, repetition_penalty=1.1):
                chunk = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768
                if len(chunk):
                    chunks.append(chunk)
                    events.append({"at_s": time.perf_counter() - started, "samples": len(chunk)})
            torch.cuda.synchronize()
            total = time.perf_counter() - started
            waveform = np.concatenate(chunks)
            duration = len(waveform) / 24000
            record.update(ok=True, events=events, chunk_events=events, sample_rate=24000, ttfa_s=events[0]["at_s"], total_s=total, audio_duration_s=duration, rtf=total / duration, peak_memory_bytes=torch.cuda.max_memory_allocated())
            record.update(**diagnose(record))
            record["overlap_verified"] = len(events) > 1 and events[0]["at_s"] < total
            if not record["overlap_verified"]:
                raise RuntimeError("publisher vLLM implementation did not yield audio before completion")
            if phase == "smoke":
                target = OUT / f"{stamp}-publisher-vllm-stream-en-IN.flac"
                sf.write(target, waveform, 24000, subtype="PCM_24")
                record.update(file=str(target.relative_to(ROOT)), sha256=digest(target))
        except Exception as error:
            record.update(ok=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        with (OUT / "records.jsonl").open("a", encoding="utf-8") as target:
            target.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(json.dumps({key: record.get(key) for key in ("phase", "ok", "ttfa_s", "rtf", "chunk_count", "simulated_stall_count", "error")}), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
