#!/usr/bin/env python3
import argparse, datetime, hashlib, json, pathlib, struct, time, urllib.request

TEXTS = {
    "hi-IN": "आपकी बैठक कल दोपहर तीन बजे है।",
    "en-IN": "Your meeting with Priya is tomorrow at three thirty PM.",
    "bn-IN": "আপনার মিটিং আগামীকাল দুপুর তিনটায়।",
    "mr-IN": "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.",
    "ta-IN": "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.",
    "te-IN": "మీ సమావేశం రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.",
    "gu-IN": "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.",
    "kn-IN": "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.",
    "ml-IN": "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.",
    "or-IN": "ଆପଣଙ୍କ ବୈଠକ କାଲି ଅପରାହ୍ନ ତିନିଟାରେ ଅଛି।",
}

def wav(path, pcm, rate):
    data = struct.pack("<4sI4s4sIHHIIHH4sI", b"RIFF", 36+len(pcm), b"WAVE", b"fmt ", 16, 1, 1, rate, rate*2, 2, 16, b"data", len(pcm)) + pcm
    path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument("model_id");p.add_argument("--port",type=int,default=8000);p.add_argument("--sample-rate",type=int,required=True);p.add_argument("--model",required=True);p.add_argument("--locales",nargs="+",required=True);p.add_argument("--ref-audio");p.add_argument("--ref-text");p.add_argument("--ref-text-file");p.add_argument("--checkpoint");p.add_argument("--revision");a=p.parse_args()
    if a.ref_text_file:
        a.ref_text = pathlib.Path(a.ref_text_file).read_text().strip()
    out=pathlib.Path("/workspace/speechbench_20260924")/a.model_id;out.mkdir(parents=True,exist_ok=True)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    recs=[]
    for locale in a.locales:
        payload={"model":a.model,"voice":"default","input":TEXTS[locale],"stream":True,"response_format":"pcm","max_new_tokens":700,"language":"auto"}
        if a.ref_audio: payload.update(ref_audio=a.ref_audio,ref_text=a.ref_text or "")
        req=urllib.request.Request(f"http://127.0.0.1:{a.port}/v1/audio/speech",data=json.dumps(payload,ensure_ascii=False).encode(),headers={"Content-Type":"application/json"})
        began=time.perf_counter();blocks=[];events=[]
        with urllib.request.urlopen(req,timeout=600) as response:
            while True:
                block=response.read(4096)
                if not block:break
                blocks.append(block);events.append({"at_s":time.perf_counter()-began,"bytes":len(block)})
        total=time.perf_counter()-began;pcm=b"".join(blocks)
        target=out/f"{stamp}-sglang-stream-{locale}.wav";digest=wav(target,pcm,a.sample_rate);duration=len(pcm)/2/a.sample_rate
        record={"run_id":stamp,"phase":"smoke","model_id":a.model_id,"locale":locale,"text":TEXTS[locale],"mode":"native_stream","implementation":"SGLang-Omni /v1/audio/speech","synthesis_class":"A","ok":bool(pcm),"sample_rate":a.sample_rate,"ttfa_s":events[0]["at_s"] if events else None,"total_s":total,"audio_duration_s":duration,"rtf":total/duration if duration else None,"chunk_events":events,"chunk_count":len(events),"overlap_verified":len(events)>1 and events[0]["at_s"]<total,"file":str(target.relative_to('/workspace/speechbench_20260924')),"sha256":digest,"checkpoint":a.checkpoint,"revision":a.revision}
        recs.append(record);print(json.dumps({k:record[k] for k in ('locale','ok','ttfa_s','rtf','chunk_count','overlap_verified')}),flush=True)
    with (out/'records.jsonl').open('a') as f:
        for r in recs:f.write(json.dumps(r,ensure_ascii=False)+'\n')
    (out/f'environment-sglang-{stamp}.json').write_text(json.dumps({"run_id":stamp,"model_id":a.model_id,"checkpoint":a.checkpoint,"revision":a.revision,"implementation":"SGLang-Omni","streaming":True},indent=2))

if __name__=='__main__':main()
