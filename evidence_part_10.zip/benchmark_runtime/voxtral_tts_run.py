"""Pinned vLLM-Omni AsyncOmni waveform streaming with publisher stock voices."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',VLLM_WORKER_MULTIPROC_METHOD='spawn')
import asyncio,datetime,hashlib,importlib.metadata,json,pathlib,shutil,time,traceback,uuid
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T10'
PIN='b81be46c3777f88621676791b512bb01dc1cb970'
SOURCE=pathlib.Path('/workspace/voxtral_tts_qual/model_cache/voxtral');TARGET=pathlib.Path('/tmp/benchmark_model_stage/T10')
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while data:=f.read(8388608):h.update(data)
    return h.hexdigest()
def stage():
    meta=json.loads((ROOT/'T10-metadata-blobs.json').read_text());manifest={}
    if meta['sha']!=PIN:raise ValueError('Revision mismatch')
    for item in meta['siblings']:
        name=item['rfilename']
        if pathlib.Path(name).suffix not in {'.json','.safetensors','.pt'}:continue
        source=SOURCE/name;dest=TARGET/name;dest.parent.mkdir(parents=True,exist_ok=True)
        h=hashlib.sha256();git=hashlib.sha1(('blob '+str(source.stat().st_size)+'\0').encode())
        with source.open('rb') as f,dest.open('wb') as out:
            while data:=f.read(8388608):h.update(data);git.update(data);out.write(data)
        if (h.hexdigest() if 'lfs' in item else git.hexdigest())!=(item.get('lfs',{}).get('sha256') or item['blobId']):raise ValueError('Publisher hash mismatch: '+name)
        manifest[name]=dict(sha256=h.hexdigest(),bytes=dest.stat().st_size,publisher_digest_verified=True)
    return manifest
async def main():
    if json.loads((ROOT/'voxtral_tts_setup.json').read_text())['state']!='installed':raise RuntimeError('Isolated backend setup did not complete')
    import numpy as np,soundfile as sf,torch,yaml
    from vllm import SamplingParams
    from vllm_omni import AsyncOmni
    from mistral_common.protocol.speech.request import SpeechRequest
    from mistral_common.tokens.tokenizers.mistral import MistralTokenizer
    OUT.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');files=stage()
    config=yaml.safe_load((ROOT/'T10-stage-default.yaml').read_text())
    for index,stage_config in enumerate(config['stage_args']):
        stage_config['engine_args'].update(enforce_eager=True,max_num_seqs=1,gpu_memory_utilization=.65 if index==0 else .15)
        stage_config['default_sampling_params']['seed']=20260924
    cfg=OUT/f'stage-config-{stamp}.yaml';cfg.write_text(yaml.safe_dump(config))
    sampling=[SamplingParams(**x['default_sampling_params']) for x in config['stage_args']]
    tokenizer=MistralTokenizer.from_file(str(TARGET/'tekken.json')).instruct_tokenizer
    env=dict(run_id=stamp,model='mistralai/Voxtral-4B-TTS-2603',revision=PIN,files=files,runner_sha256=digest(__file__),
             versions={p:importlib.metadata.version(p) for p in ['torch','vllm','vllm-omni','mistral-common','numpy']},gpu=torch.cuda.get_device_name(0),
             stage_config=config,stage_config_sha256=digest(cfg),precision='publisher BF16 checkpoint',mode='native_async_waveform_stream',
             input_text_supplied_in_full=True,voice_source='publisher stock embeddings',hf_offline=True,network_namespace_isolated=False)
    (OUT/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    engine=AsyncOmni(model=str(TARGET),stage_configs_path=str(cfg),log_stats=False)
    async def synth(text,voice):
        start=time.perf_counter();request_id=str(uuid.uuid4());events=[];parts=[];received_finished=False
        tokenized=tokenizer.encode_speech_request(SpeechRequest(input=text,voice=voice))
        inputs=dict(prompt_token_ids=tokenized.tokens,additional_information={'voice':[voice]})
        async for result in engine.generate(inputs,request_id=request_id,sampling_params_list=sampling):
            outputs=getattr(getattr(result,'request_output',None),'outputs',[]) or []
            if any(getattr(o,'finish_reason',None)=='length' for o in outputs):raise RuntimeError('Token limit reached')
            mm=result.multimodal_output
            if not mm or 'audio' not in mm:continue
            raw=mm['audio'];finished=bool(result.finished);received_finished|=finished
            def array(x):return x.detach().float().cpu().numpy().reshape(-1) if isinstance(x,torch.Tensor) else np.asarray(x,dtype=np.float32).reshape(-1)
            old=np.concatenate(parts) if parts else np.empty(0,dtype=np.float32)
            if isinstance(raw,list):
                data=np.concatenate([array(x) for x in raw]) if raw else np.empty(0,dtype=np.float32)
                if len(data)<len(old) or not np.array_equal(data[:len(old)],old):raise RuntimeError('Unexpected cumulative-list audio protocol')
                data=data[len(old):]
            else:
                data=array(raw)
                if not len(data):continue
                if finished and len(old):
                    if len(data)>=len(old) and np.array_equal(data[:len(old)],old):data=data[len(old):]
                    else:raise RuntimeError('Ambiguous final audio payload; refusing to duplicate or drop samples')
            if not len(data):continue
            if not np.isfinite(data).all():raise ValueError('Nonfinite audio')
            events.append(dict(at_s=time.perf_counter()-start,samples=len(data),finished=finished));parts.append(data)
        elapsed=time.perf_counter()-start
        if not parts or not received_finished:raise RuntimeError('No complete audio result')
        return np.concatenate(parts),events,elapsed
    items=[('hi-IN','hi_female','आपकी बैठक कल दोपहर तीन बजे है।'),('en-IN','casual_female','Your meeting with Priya is tomorrow at three thirty PM.')]
    try:
        for locale,voice,text in items:
            for i in range(4):
                rec=dict(run_id=stamp,locale=locale,voice=voice,text=text,phase='warmup' if i<3 else 'smoke',mode='native_stream',ok=False)
                try:
                    audio,events,elapsed=await asyncio.wait_for(synth(text,voice),timeout=180)
                    # AsyncOmni marks each completed codec chunk finished, not the utterance.
                    native=len(events)>1 and events[0]['at_s']<events[-1]['at_s']
                    rec.update(ok=True,ttfa_s=events[0]['at_s'],total_s=elapsed,sample_rate=24000,audio_duration_s=len(audio)/24000,rtf=elapsed/(len(audio)/24000),chunk_events=events,synthesis_class='A' if native else 'C',audio_before_final_result=native)
                    if i==3:
                        file=OUT/f'{stamp}-{locale}.flac';sf.write(file,audio,24000,subtype='PCM_24');rec.update(file=str(file.relative_to(ROOT)),sha256=digest(file))
                except Exception as e:
                    rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
                with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
                print(json.dumps({k:rec.get(k) for k in ['locale','phase','ok','ttfa_s','rtf','error']}),flush=True)
                if not rec['ok']:raise RuntimeError('End this engine after a failed request; preserve failure evidence')
    finally:engine.shutdown()
    (OUT/'DONE-stream-smoke').write_text('Two stock-voice streaming smoke clips; full qualification pending.\n');shutil.rmtree(TARGET)
if __name__=='__main__':asyncio.run(main())
