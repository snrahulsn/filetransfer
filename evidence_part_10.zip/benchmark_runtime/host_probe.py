"""Record observable container limits; never change host configuration."""
import datetime,json,os,pathlib,statistics,subprocess
root=pathlib.Path('/workspace/speechbench_20260924')
def read(p):
    try:return pathlib.Path(p).read_text().strip()
    except OSError:return None
cpu=read('/proc/cpuinfo');mhz=[float(line.split(':')[1]) for line in cpu.splitlines() if line.startswith('cpu MHz')]
d=dict(observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),logical_cpu_count=os.cpu_count(),affinity=sorted(os.sched_getaffinity(0)),
    cpu_model=next(line.split(':',1)[1].strip() for line in cpu.splitlines() if line.startswith('model name')),
    reported_cpu_mhz=dict(min=min(mhz),max=max(mhz),mean=statistics.mean(mhz)),
    cgroup_cpu_quota_us=read('/sys/fs/cgroup/cpu/cpu.cfs_quota_us'),cgroup_cpu_period_us=read('/sys/fs/cgroup/cpu/cpu.cfs_period_us'),
    cgroup_cpu_stat=read('/sys/fs/cgroup/cpu/cpu.stat'),memory_limit_bytes=read('/sys/fs/cgroup/memory/memory.limit_in_bytes'))
d['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version,memory.total,power.limit','--format=csv,noheader'],text=True).strip()
path=root/('host-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json');path.write_text(json.dumps(d,indent=2))
print(json.dumps(d))
