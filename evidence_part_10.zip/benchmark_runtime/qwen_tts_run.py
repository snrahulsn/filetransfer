"""Pinned Qwen3-TTS voice-clone smoke benchmarks for T11, T12, and T19."""
import os
os.environ.update(
    HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", USE_TF="0",
    HF_HOME="/workspace/hf_cache", HF_HUB_CACHE="/workspace/hf_cache/hub",
)

import argparse
import datetime
import hashlib
import json
import pathlib
import time
import traceback

import numpy as np
import soundfile as sf
import torch
from peft import PeftModel
from peft.tuners.lora.layer import LoraLayer
from qwen_tts import Qwen3TTSModel

ROOT = pathlib.Path("/workspace/speechbench_20260924")
TEXTS = [
    ("en-IN", "English", "Your meeting with Priya is tomorrow at three thirty PM."),
    ("hi-IN", "Hindi", "आपकी बैठक कल दोपहर तीन बजे है।"),
    ("bn-IN", "Bengali", "আপনার মিটিং আগামীকাল দুপুর তিনটায়।"),
    ("mr-IN", "Marathi", "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे."),
    ("te-IN", "Telugu", "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది."),
    ("ta-IN", "Tamil", "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு."),
    ("gu-IN", "Gujarati", "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે."),
    ("kn-IN", "Kannada", "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ."),
    ("ml-IN", "Malayalam", "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്."),
]
ODIA = ("or-IN", "Odia", "ଆପଣଙ୍କ ବୈଠକ କାଲି ଅପରାହ୍ନ ତିନିଟାରେ ଅଛି।")
TEXT_BY_LOCALE = {locale: (language, text) for locale, language, text in [*TEXTS, ODIA]}
JOBS = {
    "T11": {
        "repo": "aguken-ai/Qwen-3-TTS-12Hz-1.7B-Base-hi-LoRA-Finetuned",
        "revision": "b84766274af71506758ccf45a9965bd1d934297b",
        "locales": {"hi-IN": ("Hindi", "hindi_female")},
    },
    "T12": {
        "repo": "Qwen/Qwen3-TTS-12Hz-1.7B-Base",
        "revision": "fd4b254389122332181a7c3db7f27e918eec64e3",
        "locales": {"en-IN": ("English", None)},
    },
    "T19": {
        "repo": "aguken-ai/Qwen3-TTS-0.6B-LoRA-Finetuned-Indic-Multilingual",
        "revision": "5450c7fc7b497d19209e202bf55b825c98b2b312",
        "locales": {
            "bn-IN": ("Bengali", "bengali_female"),
            "mr-IN": ("Marathi", "marathi_female"),
            "ta-IN": ("Tamil", "tamil_female"),
            "te-IN": ("Telugu", "telugu_female"),
            "gu-IN": ("Gujarati", "gujarati_female"),
            "kn-IN": ("Kannada", "kannada_female"),
            "ml-IN": ("Malayalam", "malayalam_female"),
            "or-IN": ("Odia", "odia_female"),
        },
    },
}


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        while block := handle.read(8 * 1024 * 1024):
            h.update(block)
    return h.hexdigest()


def downloaded_path(model_id):
    record = json.loads((ROOT / f"{model_id}_download.json").read_text())
    if record.get("status") != "downloaded" or record.get("revision") != JOBS[model_id]["revision"]:
        raise RuntimeError(f"{model_id} pinned download is missing or revision does not match")
    path = pathlib.Path(record["path"])
    if not path.is_dir():
        raise FileNotFoundError(path)
    return path


def reference(model_id, model_path, adapter_name):
    if adapter_name:
        folder = model_path / "adapters" / adapter_name
    else:
        reference_record = json.loads((ROOT / "T12-ref_download.json").read_text())
        if reference_record.get("status") != "downloaded":
            raise RuntimeError("T12-ref pinned reference download is missing")
        folder = pathlib.Path(reference_record["path"]) / "adapters" / "hindi_female"
    audio, text = folder / "ref.wav", folder / "ref.txt"
    if not audio.is_file() or not text.is_file():
        raise FileNotFoundError(f"reference pair missing under {folder}")
    return audio, text.read_text(encoding="utf-8").strip()


def apply_lora_scale(model, scale):
    """Apply PEFT's documented multiplicative scale to every active LoRA layer."""
    layers = 0
    active_adapters = set()
    for module in model.modules():
        if not isinstance(module, LoraLayer):
            continue
        layers += 1
        active_adapters.update(module.active_adapters)
        module.scale_layer(scale)
    if not layers:
        raise RuntimeError("PEFT loaded no LoRA layers")
    return layers, sorted(active_adapters)


def load_model(model_id, model_path, adapter_name):
    # T11's publisher snapshot contains an internally inconsistent
    # custom-voice config at its root while its published adapter and example
    # invoke the Base model's voice-clone API.  Load the pinned official Base
    # checkpoint and apply the pinned T11 adapter to that compatible base.
    base_path = downloaded_path("T12") if model_id == "T11" else model_path
    wrapper = Qwen3TTSModel.from_pretrained(
        str(base_path), device_map="cuda:0", dtype=torch.bfloat16,
        attn_implementation="sdpa", local_files_only=True,
    )
    scale_evidence = None
    if adapter_name:
        # Qwen3TTSModel is an inference wrapper rather than an nn.Module.  PEFT
        # must wrap its underlying Qwen3TTSForConditionalGeneration instance;
        # generation still runs through the outer wrapper.
        wrapper.model = PeftModel.from_pretrained(
            wrapper.model, str(model_path / "adapters" / adapter_name),
            is_trainable=False, local_files_only=True,
        )
        layers, active_adapters = apply_lora_scale(wrapper.model, 0.35)
        scale_evidence = {
            "adapter": adapter_name,
            "active_adapters": active_adapters,
            "scaled_lora_layers": layers,
            "scale_multiplier": 0.35,
        }
    return wrapper, scale_evidence, base_path


def main(model_id, locales=None):
    job = JOBS[model_id]
    items = [
        item for item in job["locales"].items()
        if not locales or item[0] in locales
    ]
    if not items:
        raise ValueError("no requested locales are supported by this job")
    out = ROOT / model_id
    out.mkdir(exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    model_path = downloaded_path(model_id)
    first_adapter = items[0][1][1]
    model, scale_evidence, base_path = load_model(model_id, model_path, first_adapter)
    environment = {
        "run_id": stamp, "model": job["repo"], "revision": job["revision"],
        "model_weight_sha256": digest(base_path / "model.safetensors"),
        "base_model": "Qwen/Qwen3-TTS-12Hz-1.7B-Base" if model_id == "T11" else job["repo"],
        "base_revision": JOBS["T12"]["revision"] if model_id == "T11" else job["revision"],
        "runner_sha256": digest(__file__), "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0), "precision": "bfloat16",
        "attention": "sdpa", "lora_scale": 0.35 if first_adapter else None,
        "lora_scale_evidence": scale_evidence,
        "mode": "full_output", "synthesis_class": "C", "hf_offline": True,
        "network_namespace_isolated": False,
    }
    (out / f"environment-{stamp}.json").write_text(json.dumps(environment, indent=2))

    current_adapter = first_adapter
    trials = [("warmup", items[0])] * 3 + [("smoke", item) for item in items]
    for index, (phase, (locale, (qwen_language, adapter_name))) in enumerate(trials):
        if adapter_name != current_adapter:
            del model
            torch.cuda.empty_cache()
            model, scale_evidence, base_path = load_model(model_id, model_path, adapter_name)
            current_adapter = adapter_name
        _, text = TEXT_BY_LOCALE[locale]
        ref_audio, ref_text = reference(model_id, model_path, adapter_name)
        record = {
            "run_id": stamp, "phase": phase, "index": index, "locale": locale,
            "language_argument": qwen_language, "text": text, "voice": adapter_name or "hindi_female cross-lingual reference",
            "mode": "full", "synthesis_class": "C", "ok": False,
            "reference_audio_sha256": digest(ref_audio), "reference_text": ref_text,
            "adapter_weight_sha256": (
                digest(model_path / "adapters" / adapter_name / "adapter_model.safetensors")
                if adapter_name else None
            ),
            "lora_scale_evidence": scale_evidence,
        }
        try:
            torch.manual_seed(20260924)
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            start = time.perf_counter()
            # The Base checkpoint's public language enum omits Indic names;
            # its documented multilingual fallback is ``auto``.
            generation_language = (
                qwen_language if qwen_language.lower() in {
                    "english", "chinese", "french", "german", "italian",
                    "japanese", "korean", "portuguese", "russian", "spanish",
                } else "auto"
            )
            record["generation_language_argument"] = generation_language
            record["max_new_tokens"] = 384
            wavs, sample_rate = model.generate_voice_clone(
                text=text, language=generation_language, ref_audio=str(ref_audio), ref_text=ref_text,
                max_new_tokens=384,
            )
            torch.cuda.synchronize()
            elapsed = time.perf_counter() - start
            audio = np.asarray(wavs[0], dtype=np.float32).reshape(-1)
            if not len(audio) or not np.isfinite(audio).all():
                raise ValueError("empty or non-finite waveform")
            duration = len(audio) / sample_rate
            record.update(
                ok=True, sample_rate=sample_rate, total_s=elapsed, ttfa_s=elapsed,
                audio_duration_s=duration, rtf=elapsed / duration,
                peak_memory_bytes=torch.cuda.max_memory_allocated(),
                prequantization_out_of_range_samples=int(np.sum(np.abs(audio) >= 1)),
            )
            if phase == "smoke":
                output = out / f"{stamp}-{locale}.flac"
                sf.write(output, audio, sample_rate, subtype="PCM_24")
                record.update(file=str(output.relative_to(ROOT)), sha256=digest(output))
        except Exception as error:
            record.update(error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        with (out / "records.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        print(json.dumps({key: record.get(key) for key in ("locale", "phase", "ok", "rtf", "error")}, ensure_ascii=False), flush=True)
        if not record["ok"]:
            break
    (out / "DONE").write_text("Pinned full-output voice-clone smoke benchmark attempted.\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=JOBS)
    parser.add_argument("--locales", nargs="*")
    args = parser.parse_args()
    main(args.model, args.locales)
