"""Pinned full-utterance Shrutam-2 coverage evaluation."""
import argparse
import datetime
import hashlib
import json
import pathlib
import resource
import time
import traceback

import torch
from transformers import AutoModel, AutoTokenizer

from asr_corpus import records
from metrics import score

ROOT = pathlib.Path("/workspace/speechbench_20260924")
LANGUAGES = {
    "hi-IN": "Hindi", "bn-IN": "Bengali", "mr-IN": "Marathi",
    "ta-IN": "Tamil", "te-IN": "Telugu", "gu-IN": "Gujarati",
    "kn-IN": "Kannada", "ml-IN": "Malayalam", "or-IN": "Odia",
}


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def main(limit: int) -> None:
    manifest = json.loads((ROOT / "A11_download.json").read_text())
    path = pathlib.Path(manifest["path"])
    output = ROOT / "A11"
    output.mkdir(exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    started = time.perf_counter()
    tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, fix_mistral_regex=True)
    tokenizer.chat_template = (path / "chat_template.jinja").read_text(encoding="utf-8")
    model = AutoModel.from_pretrained(
        path,
        trust_remote_code=True,
        local_files_only=True,
        dtype=torch.float32,
    ).to("cuda").eval()
    # The pinned checkpoint publishes only the token embedding matrix while
    # the custom model declares the LM head as tied. Transformers does not tie
    # this nested head because the published text config omits the tie flag.
    model.llm.lm_head.weight = model.llm.model.embed_tokens.weight
    initialized = time.perf_counter() - started
    weight_files = sorted(path.glob("*.safetensors"))
    environment = {
        "run_id": stamp,
        "model": manifest["repo"],
        "revision": manifest["revision"],
        "weights": {file.name: sha256(file) for file in weight_files},
        "runner_sha256": sha256(pathlib.Path(__file__)),
        "mode": "full_utterance",
        "precision": "float32",
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0),
        "model_initialization_s": initialized,
        "evaluation_limit_per_locale": limit,
        "network_namespace_isolated": False,
        "local_files_only": True,
    }
    (output / f"environment-{stamp}.json").write_text(json.dumps(environment, indent=2))

    def infer(audio, locale):
        prompt = f"Transcribe speech to {LANGUAGES[locale]} text."
        return model.transcribe(
            [torch.from_numpy(audio)],
            prompts=[prompt],
            tokenizer=tokenizer,
            batch_size=1,
            sampling_rate=16000,
        )[0]

    first = next(records(["hi-IN"], limit=1))
    for _ in range(3):
        with torch.inference_mode():
            infer(first["audio"], "hi-IN")

    record_file = output / "file_records.jsonl"
    for locale in LANGUAGES:
        for row in records([locale], limit=limit):
            record = {key: value for key, value in row.items() if key != "audio"}
            record.update(run_id=stamp, phase="coverage_sweep", mode="full_utterance", ok=False)
            try:
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
                started = time.perf_counter()
                with torch.inference_mode():
                    hypothesis = infer(row["audio"], locale)
                torch.cuda.synchronize()
                elapsed = time.perf_counter() - started
                duration = len(row["audio"]) / 16000
                record.update(
                    ok=True,
                    hypothesis=hypothesis,
                    total_s=elapsed,
                    audio_duration_s=duration,
                    rtf=elapsed / duration,
                    peak_torch_allocated_bytes=torch.cuda.max_memory_allocated(),
                    peak_torch_reserved_bytes=torch.cuda.max_memory_reserved(),
                    process_lifetime_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                    **score(row["reference"], hypothesis),
                )
            except Exception as error:
                record.update(
                    hypothesis="",
                    error_type=type(error).__name__,
                    error=str(error),
                    traceback=traceback.format_exc(),
                    **score(row["reference"], ""),
                )
            with record_file.open("a", encoding="utf-8") as target:
                target.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(json.dumps({key: record.get(key) for key in ("id", "ok", "wer", "rtf", "error")}), flush=True)
    (output / f"DONE-{stamp}").write_text(json.dumps({"model": "A11", "limit": limit}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=3)
    main(parser.parse_args().limit)
