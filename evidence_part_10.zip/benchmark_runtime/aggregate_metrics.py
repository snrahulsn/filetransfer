"""Aggregate fresh records without turning small smoke samples into performance claims."""
import argparse,collections,csv,json,math,pathlib,hashlib
from metrics import score
from record_validity import invalid_runs

def percentile(values,p):
    values=sorted(values)
    return values[max(0,math.ceil(len(values)*p)-1)] if values else None

def aggregate(root):
    groups=collections.defaultdict(list)
    for file in root.glob('*/**/*records.jsonl'):
        if 'initial_threading_attempt' in str(file):continue
        model=file.relative_to(root).parts[0]
        invalid=invalid_runs(file)
        corrections={};raw=file.read_bytes();correction_file=file.parent/'classification_correction.json'
        if correction_file.exists():
            correction=json.loads(correction_file.read_text())
            if correction['records_file']==file.name:
                prefix=raw[:correction['records_prefix_bytes']]
                if hashlib.sha256(prefix).hexdigest()!=correction['records_prefix_sha256']:raise ValueError('Classification correction does not match preserved source records')
                corrections={x['row_number']:x for x in correction['corrections']}
        for row_number,line in enumerate(raw.decode().splitlines(),1):
            r=json.loads(line)
            if r.get('run_id') in invalid:continue
            if row_number in corrections:
                c=corrections[row_number]
                if any(r[k]!=c[k] for k in ['run_id','locale','phase']):raise ValueError('Classification correction identity mismatch')
                r.update(synthesis_class=c['synthesis_class'],audio_before_final_result=c['audio_before_final_result'],classification_corrected=True)
            if r.get('phase')=='warmup':continue
            groups[(model,r.get('locale'),r.get('phase','asr'),r.get('mode'),r.get('lookahead_ms'),r.get('run_id'),r.get('condition','clean'),r.get('decoder'),r.get('dataset'),r.get('source_tts_model'),r.get('source_tts_mode'),r.get('source_tts_run_id'),r.get('runtime_variant'))].append(r)
    output=[]
    for (model,locale,phase,mode,lookahead,run_id,condition,decoder,dataset,source_tts_model,source_tts_mode,source_tts_run_id,runtime_variant),rows in sorted(groups.items(),key=lambda x:str(x[0])):
        success=[r for r in rows if r.get('ok')]
        result=dict(model_id=model,locale=locale,phase=phase,mode=mode,lookahead_ms=lookahead,run_id=run_id,condition=condition,decoder=decoder,dataset=dataset,source_tts_model=source_tts_model,source_tts_mode=source_tts_mode,source_tts_run_id=source_tts_run_id,runtime_variant=runtime_variant,
                    attempted=len(rows),successful=len(success),failed=len(rows)-len(success),
                    latency_protocol_complete=False,ttfa_p50_s=None,ttfa_p95_s=None,rtf_p50=None,
                    human_quality_rating=None)
        result['synthesis_classes']=','.join(sorted({r['synthesis_class'] for r in rows if r.get('synthesis_class')})) or None
        result['classification_corrected']=any(r.get('classification_corrected') for r in rows)
        if len(rows)>=100 and phase=='performance_c1':
            # Failures remain explicit in denominator; percentiles describe successful trials only.
            result.update(latency_protocol_complete=len(success)==len(rows),
                ttfa_p50_s=percentile([r['ttfa_s'] for r in success if r.get('ttfa_s') is not None],.5),
                ttfa_p95_s=percentile([r['ttfa_s'] for r in success if r.get('ttfa_s') is not None],.95),
                rtf_p50=percentile([r['rtf'] for r in success if r.get('rtf') is not None],.5))
            result['c1_repeated_prompt_trials_complete']=result['latency_protocol_complete']
            result['latency_protocol_complete']=False  # C4, cold-start, cancellation and long-text gates are separate.
        elif len(success)==1:
            result.update(single_trial_ttfa_s=success[0].get('ttfa_s'),single_trial_rtf=success[0].get('rtf'))
        for key in ['peak_torch_allocated_bytes','peak_torch_reserved_bytes','process_lifetime_peak_rss_bytes']:
            values=[r[key] for r in success if r.get(key) is not None]
            if values:result[key+'_observed_max']=max(values)
        if any('reference' in r for r in rows):
            scores=[score(r['reference'],r.get('hypothesis','') if r.get('ok') else '') for r in rows]
            words=sum(s['reference_words'] for s in scores);chars=sum(s['reference_chars'] for s in scores)
            result.update(reference_words=words,reference_chars=chars,
                          wer_failure_as_empty=sum(s['word_edits'] for s in scores)/words if words else None,
                          cer_failure_as_empty=sum(s['char_edits'] for s in scores)/chars if chars else None,
                          accuracy_protocol_complete=False)
            for key in ['total_s','first_partial_s','finalization_lag_s','rtf']:
                values=[r[key] for r in success if r.get(key) is not None]
                if values:result[key+'_observed_min']=min(values);result[key+'_observed_max']=max(values)
        output.append(result)
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
    rows=aggregate(a.root);a.output.mkdir(parents=True,exist_ok=True)
    (a.output/'measured_metrics.json').write_text(json.dumps(dict(percentile_definition='nearest rank; successful trials only, failures retained separately',rows=rows),indent=2))
    if rows:
        fields=sorted(set().union(*(r.keys() for r in rows)))
        with (a.output/'measured_metrics.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
