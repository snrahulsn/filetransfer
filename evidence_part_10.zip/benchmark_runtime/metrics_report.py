"""Render actual measured rows, with sample size and scope next to every number."""
import pathlib,json
from aggregate_metrics import aggregate
from tts_delivery import rows as delivery_rows
ROOT=pathlib.Path(__file__).resolve().parents[1]
def number(x):return '—' if x is None else f'{x:.3f}'
def percent(x):return '—' if x is None else f'{100*x:.2f}%'
def span(row,key):
    lo=row.get(key+'_observed_min');hi=row.get(key+'_observed_max')
    return '—' if lo is None else number(lo) if lo==hi else number(lo)+'–'+number(hi)
def main():
    rows=aggregate(ROOT/'execution/fresh_current')
    lines=['# Measured results — provisional','',
           'These are fresh recorded measurements on RTX 4090 and RTX PRO 4500 Blackwell reference pods, not a completed PRD qualification or an on-prem capacity guarantee. On-prem hardware and required call concurrency are still unspecified. The source snapshot, revisions, exact configurations, hashes and raw trials are linked in [the progress report](BENCHMARK_PROGRESS.md).','',
           '## ASR','',
           'WER and CER are corpus-weighted edit counts with NFC normalization, case folding and punctuation removal; Indic combining marks are preserved. Failed attempts are scored as empty hypotheses, and their count remains visible. CER excludes spaces. N is attempted non-warmup trials in the displayed group. These small first-N subsets are not representative full-test scores. Compare only matched utterances and conditions; no significance or quality ranking is claimed.','',
           'First partial and finalization lag are observed ranges in seconds, not p95 estimates. Lag is completion time minus input audio duration. Streaming tests use an independent paced producer; producer lateness is retained in raw evidence. Initial SraVaani lookahead configurations did not all receive matching warmups.','',
           '| Model | Locale | Corpus / phase | Path / lookahead | Condition | N / failures | WER | CER | First partial (s) | Finalization lag (s) |','|---|---|---|---|---|---:|---:|---:|---:|---:|']
    for r in rows:
        if not r['model_id'].startswith('A') or r['phase']=='tts_intelligibility':continue
        mode=r['mode'] or 'unspecified'
        mode={'native_stream_paced_20ms':'native 20 ms input','publisher_buffered_retranscription':'Qwen accumulated-audio retranscription','native_incremental_transformers_paced_20ms':'Voxtral incremental','full_utterance':'full utterance','full_utterance_transformers':'full utterance Transformers'}.get(mode,mode)
        if r.get('lookahead_ms') is not None:mode+=f' / {r["lookahead_ms"]} ms'
        if r.get('decoder'):mode+=' / '+r['decoder']
        if r.get('runtime_variant'):mode+=' / '+r['runtime_variant']
        lines.append('| '+' | '.join([r['model_id'],r['locale'],str(r.get('dataset') or 'see raw record')+' / '+str(r['phase']),mode,r['condition'],f'{r["attempted"]} / {r["failed"]}',percent(r.get('wer_failure_as_empty')),percent(r.get('cer_failure_as_empty')),span(r,'first_partial_s'),span(r,'finalization_lag_s')])+' |')
    for validity_file in sorted((ROOT/'execution/fresh_current').glob('A*/run_validity.json')):
        validity=json.loads(validity_file.read_text())
        for run_id,reason in validity['invalid_runs'].items():
            lines+=['',f'**Excluded harness run — {validity_file.parent.name}, {run_id}:** {reason} Raw trials are retained in [the evidence](execution/fresh_current/{validity_file.parent.name}/{validity["records_file"]}); the [hash-bound validity record](execution/fresh_current/{validity_file.parent.name}/run_validity.json) explains the exclusion. They are not counted in the tables above.','']
    offline=[r for r in rows if r['model_id'].startswith('A') and r['phase']!='tts_intelligibility' and 'full_utterance' in (r['mode'] or '')]
    if offline:
        lines+=['','### Full-utterance ASR runtime observations','', 'Elapsed time starts after the complete input is available. It is separate from live audio capture and endpointing delay. These small coverage-run ranges include the recorded preprocessing/adaptation scope and are not warm p95 qualification.','', '| Model / runtime | Locale | Corpus / phase | N / failures | Elapsed range (s) | RTF range |','|---|---|---|---:|---:|---:|']
        for r in offline:
            lines.append('| '+' | '.join([r['model_id']+(' / '+r['runtime_variant'] if r.get('runtime_variant') else ''),r['locale'],str(r.get('dataset') or 'see raw record')+' / '+r['phase'],f'{r["attempted"]} / {r["failed"]}',span(r,'total_s'),span(r,'rtf')])+' |')
    memory=[r for r in offline if 'peak_torch_allocated_bytes_observed_max' in r]
    if memory:
        lines+=['','### Memory observations','', 'MiB uses 1,048,576 bytes. Torch allocator peaks exclude ONNX Runtime and driver allocations, so these are not total GPU-memory requirements. Process RSS is the process-lifetime high-water mark, including loading and earlier trials.','', '| Model | Locale | Peak Torch allocated (MiB) | Peak Torch reserved (MiB) | Process lifetime peak RSS (MiB) |','|---|---|---:|---:|---:|']
        for r in memory:
            lines.append('| '+' | '.join([r['model_id'],r['locale']]+[number(r[k+'_observed_max']/1048576) if k+'_observed_max' in r else '—' for k in ['peak_torch_allocated_bytes','peak_torch_reserved_bytes','process_lifetime_peak_rss_bytes']])+' |')
    lines+=['','Each model/locale/path row also remains separated by run, phase and corpus in the [machine-readable metrics](execution/metrics_current/measured_metrics.json). NPTEL English is educational speech; regional FLEURS is read speech. Neither establishes banking-call accuracy.','',
            '## TTS','',
            'Smoke rows show one observed sample, never a p95. Repeated C1 rows show nearest-rank p50/p95 over successful repeated calls on one fixed prompt. Background dependency work overlapped the initial repeated-call runs and some later model jobs, so these are provisional observations. Setup intervals are preserved with the raw evidence. No concurrency, long-session or cold-start qualification is implied.','',
            'TTFA is time to first returned audio. For full-output synthesis it is effectively the complete synthesis delay. RTF is synthesis elapsed time divided by generated audio duration: below 1 means the measured synthesis completed faster than the resulting audio plays. Saved listening clips do not reproduce delivery stalls. Human quality ratings remain uncollected.','',
            '| Model | Locale | Mode | Producer class | Phase | N / failures | TTFA observed or p50 (s) | TTFA p95 (s) | RTF observed or p50 |','|---|---|---|---|---|---:|---:|---:|---:|']
    for r in rows:
        if not r['model_id'].startswith('T'):continue
        lines.append('| '+' | '.join([r['model_id'],r['locale'],r['mode'] or 'unspecified',r.get('synthesis_classes') or 'see trace',r['phase'],f'{r["attempted"]} / {r["failed"]}',number(r.get('single_trial_ttfa_s',r.get('ttfa_p50_s'))),number(r.get('ttfa_p95_s')),number(r.get('single_trial_rtf',r.get('rtf_p50')))])+' |')
    lines+=['','The first MMS Odia prompt differs from the Parler prompt. Voice, conditioning and backend differences also prevent treating all rows as controlled head-to-head comparisons. VoxCPM2 uses the recorded eager configuration; its compiled initialization attempt timed out separately. Missing values are unmeasured, not zero.','']
    lines+=['Producer classes: A = audio generated within an unfinished segment; B = completed segments delivered sequentially; C = the requested utterance completes before audio is returned. “See trace” means no producer-class field was recorded for that row; it does not establish non-streaming behavior.','']
    if any(r.get('classification_corrected') for r in rows):
        lines+=['Voxtral TTS class A uses a [hash-bound classification correction](execution/fresh_current/T10/classification_correction.json): the original runner mistook AsyncOmni’s per-codec-chunk finished flag for whole-utterance completion. The original records, waveforms, and timing values are preserved.','']
    delivery=delivery_rows(ROOT/'execution/fresh_current')
    if delivery:
        lines+=['## Streaming playback simulation','', 'This calculation uses recorded chunk arrival times and sample counts, with playback starting immediately at first audio. It assumes instantaneous transfer and decoding, and includes no network or audio-device delays. These are simulated stalls for the measured configuration, not listening scores. The minimum stall-free start is computed retrospectively from the complete trace; a live client cannot know it in advance. Saved audio files omit these delivery gaps.','', '| Model | Locale | Chunks | First audio (s) | Simulated stalls | Total stall time (s) | Minimum stall-free start (s) |','|---|---|---:|---:|---:|---:|---:|']
        for r in delivery:
            lines.append('| '+' | '.join([r['model_id'],r['locale'],str(r['chunk_count']),number(r['first_audio_s']),str(r['simulated_stall_count']),number(r['simulated_stall_total_s']),number(r['minimum_stall_free_start_s'])])+' |')
        lines.append('')
    diagnostics=[r for r in rows if r['phase']=='tts_intelligibility']
    if diagnostics:
        lines+=['## ASR-on-TTS intelligibility diagnostic','', 'SraVaani-0.5-live transcribes the saved synthetic clips. These WER/CER values combine synthesis errors and recognizer errors; they are not human intelligibility scores, MOS, or a reliable model ranking. Failures are counted as empty transcriptions. Different TTS modes and runs remain separate.','', '| TTS model | Locale | TTS mode | N / failures | ASR WER | ASR CER |','|---|---|---|---:|---:|---:|']
        for r in diagnostics:
            lines.append('| '+' | '.join([r['source_tts_model'],r['locale'],r['source_tts_mode'],f'{r["attempted"]} / {r["failed"]}',percent(r.get('wer_failure_as_empty')),percent(r.get('cer_failure_as_empty'))])+' |')
        lines.append('')
    (ROOT/'MEASURED_RESULTS.md').write_text('\n'.join(lines))
if __name__=='__main__':main()
