import hashlib,json,pathlib,tempfile,unittest
from import_ratings import validate
class RatingsEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)
        mapping=[dict(id='C1',model_id='T04',locale='hi-IN'),dict(id='C2',model_id='T18',locale='hi-IN')]
        self.package_id=hashlib.sha256(json.dumps(mapping,sort_keys=True).encode()).hexdigest()
        (self.root/'blind_key.json').write_text(json.dumps(mapping))
        (self.root/'package_manifest.json').write_text(json.dumps(dict(package_id=self.package_id,clip_count=2)))
        self.export=dict(package_id=self.package_id,rater='owner',ratings={'C1':{'Overall':4}})
    def test_partial_ratings_do_not_become_zero_scores(self):
        result=validate(self.root,self.export)
        self.assertEqual(result['unsubmitted_clips'],1)
        self.assertEqual(result['rows'][0]['ratings']['Overall'],4)
    def test_reject_boolean_and_out_of_range_scores(self):
        for value in [True,0,6,3.5,'4']:
            self.export['ratings']['C1']['Overall']=value
            with self.subTest(value=value),self.assertRaises(ValueError):validate(self.root,self.export)
    def test_reject_wrong_clip_package(self):
        self.export['package_id']='different-package'
        with self.assertRaises(ValueError):validate(self.root,self.export)
    def test_reject_modified_blind_key(self):
        (self.root/'blind_key.json').write_text('[{"id":"C1","model_id":"T99"}]')
        with self.assertRaises(ValueError):validate(self.root,self.export)
if __name__=='__main__':unittest.main()
