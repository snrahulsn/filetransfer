"""Build a portable, hash-verified evidence pack in sub-20 MB folders."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import shutil
from dataclasses import dataclass


ROOT = pathlib.Path(__file__).resolve().parents[1]
MAX_PART_BYTES = 19_000_000
TARGET_PAYLOAD_BYTES = 18_000_000


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True)
class Asset:
    path: str
    data: bytes
    category: str

    @property
    def size(self) -> int:
        return len(self.data)

    @property
    def sha256(self) -> str:
        return digest(self.data)


def keep(path: pathlib.Path) -> bool:
    return not any(part in {"__pycache__", ".DS_Store"} for part in path.parts) and path.suffix != ".pyc"


def source_assets() -> list[Asset]:
    found: dict[str, Asset] = {}

    def add(path: pathlib.Path, category: str, relative: pathlib.Path | None = None) -> None:
        if not path.is_file() or not keep(path):
            return
        rel = relative or path.relative_to(ROOT)
        key = rel.as_posix()
        found[key] = Asset(key, path.read_bytes(), category)

    def tree(relative: str, category: str) -> None:
        base = ROOT / relative
        for path in sorted(base.rglob("*")):
            if path.is_file():
                add(path, category)

    for name in ("BENCHMARK_REPORT.html", "BENCHMARK_REPORT.pdf", "Indic_Speech_Benchmark_Codex_PRD_v1.zip"):
        add(ROOT / name, "final deliverable")
    tree("LISTENING_REVIEW", "blind listening package")
    tree("execution/fresh_current", "raw run evidence")
    tree("execution/sources", "publisher and dependency provenance")
    tree("execution/metrics_current", "aggregated metrics")
    tree("execution/dataset_sources", "evaluation dataset provenance")
    tree("benchmark_runtime", "benchmark and validation code")
    tree("indic_speech_benchmark_prd_v1", "benchmark specification")

    for name in (
        "FINAL_STATUS.json",
        "final_report_validation.json",
        "final_shutdown_verification.json",
        "final_local_data_audit.json",
        "grok_batch_01.jsonl",
        "grok_batch_02.jsonl",
        "grok_review.json",
        "language_coverage.json",
        "runner_provenance.json",
        "access_authorizations.json",
        "authenticated_access.json",
        "local_execution_feasibility.json",
        "report_blockers.json",
        "primary_configuration_ledger.json",
        "metadata_corrections.json",
    ):
        add(ROOT / "execution" / name, "final audit evidence")
    for path in sorted((ROOT / "execution").glob("lease-*.json")):
        add(path, "RunPod lease evidence")
    for name in (
        "README.md",
        "PROMPT.md",
        "package_manifest.json",
        "batch_01/review_manifest.csv",
        "batch_02/review_manifest.csv",
    ):
        add(ROOT / "GROK_REVIEW" / name, "Grok review protocol")
    for path in sorted(ROOT.glob("*.py")):
        add(path, "orchestration code")
    return sorted(found.values(), key=lambda item: item.path)


VERIFY_SCRIPT = r'''#!/usr/bin/env python3
import argparse, hashlib, json
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
class P(HTMLParser):
 def __init__(self):super().__init__();self.tables=0;self.audio=[];self.href=[];self.grok=0;self.blockers=0
 def handle_starttag(self,t,a):
  d=dict(a);c=d.get('class','').split()
  if t=='table':self.tables+=1
  if 'data-audio' in d:self.audio.append(d['data-audio'])
  if 'href' in d:self.href.append(d['href'])
  if 'quality' in c and 'g' in c:self.grok+=1
  if 'blocker' in c:self.blockers+=1
def main():
 m=json.loads((ROOT/'EVIDENCE_MANIFEST.json').read_text());bad=[]
 for row in m['files']:
  p=ROOT/row['path']
  if not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:bad.append(row['path'])
 assert not bad,f'missing or changed files: {bad[:20]}'
 report=(ROOT/'BENCHMARK_REPORT.html').read_text();p=P();p.feed(report)
 assert (p.tables,p.blockers)==(4,0),(p.tables,p.blockers)
 assert all(f'id="{s}"' in report for s in ('asr','tts','deployment','evidence'))
 assert '<th>Mode</th>' not in report
 assert all(report.count(f'<span>{m}</span>')==3 for m in [f'A{i:02d}' for i in range(1,16)]+[f'T{i:02d}' for i in range(1,20)])
 assert 'Grok AI diagnostic — separate from human quality' in report
 for value in p.href+p.audio:
  if value.startswith(('http://','https://','#')):continue
  assert (ROOT/unquote(value.split('#',1)[0])).is_file(),value
 review=json.loads((ROOT/'execution/grok_review.json').read_text())
 assert review['clip_count']==len(review['rows'])==107
 assert len({r['id'] for r in review['rows']})==107
 assert all(type(r['overall_score']) is int and 1<=r['overall_score']<=5 for r in review['rows'])
 key=json.loads((ROOT/'LISTENING_REVIEW/blind_key.json').read_text())
 assert len(key)==107 and {r['id'] for r in key}=={r['id'] for r in review['rows']}
 for r in key:
  src=ROOT/'execution/fresh_current'/r['source_file'];blind=ROOT/'LISTENING_REVIEW/clips'/(r['id']+src.suffix)
  assert src.is_file() and blind.is_file() and sha(src)==sha(blind)==r['sha256']
 shutdown=json.loads((ROOT/'execution/final_shutdown_verification.json').read_text())
 assert shutdown['all_stopped'] is True
 assert all(r['desiredStatus']=='EXITED' and r['runtime'] is None for r in shutdown['runtime_states'])
 local=json.loads((ROOT/'execution/final_local_data_audit.json').read_text())
 assert local['models_expected']==local['models_with_records']==34
 assert local['missing']==[] and local['hash_failures']==[]
 final=json.loads((ROOT/'execution/FINAL_STATUS.json').read_text())
 assert final['asr_models_with_records']==15 and final['tts_models_with_records']==19
 assert final['grok_review_complete'] is True and final['grok_review_clips']==107
 result={'manifest_files':len(m['files']),'manifest_bytes':sum(r['bytes'] for r in m['files']),'sections':4,'tables':4,'playable_primary_or_alternative_waveforms':len(p.audio),'grok_clips':107,'listening_clips':107,'asr_models':15,'tts_models':19,'local_record_rows':local['record_rows'],'local_audio_references':local['successful_audio_references'],'all_runpod_instances_stopped':True}
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
'''


SERVE_SCRIPT = r'''#!/usr/bin/env python3
import argparse, functools, http.server
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8000);p.add_argument('--bind',default='127.0.0.1');a=p.parse_args()
root=Path(__file__).resolve().parent
handler=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(root))
print(f'Report: http://{a.bind}:{a.port}/BENCHMARK_REPORT.html')
http.server.ThreadingHTTPServer((a.bind,a.port),handler).serve_forever()
'''


ASSEMBLER = r'''#!/usr/bin/env python3
import argparse, hashlib, json, shutil
from pathlib import Path
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
p=argparse.ArgumentParser();p.add_argument('--parts-root',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
parts=(a.parts_root or Path(__file__).resolve().parents[2]).resolve();manifest_path=Path(__file__).parent/'MASTER_MANIFEST.json';manifest=json.loads(manifest_path.read_text())
a.output.mkdir(parents=True,exist_ok=True)
for row in manifest['files']:
 src=parts/row['part']/'payload'/row['path'];dst=a.output/row['path']
 if not src.is_file() or src.stat().st_size!=row['bytes'] or sha(src)!=row['sha256']:raise SystemExit(f'Invalid source part file: {src}')
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 if sha(dst)!=row['sha256']:raise SystemExit(f'Copy verification failed: {dst}')
(a.output/'EVIDENCE_MANIFEST.json').write_bytes(manifest_path.read_bytes())
print(f'Assembled and verified {len(manifest["files"])} files in {a.output}')
print(f'Next: python3 {a.output/"verify_pack.py"}')
'''


def generated_assets() -> list[Asset]:
    index = """# Evidence index

This is the authoritative portable evidence set for the on-prem Indic ASR/TTS benchmark.

- `BENCHMARK_REPORT.html` — interactive four-section report with one primary row per model and waveform-level evidence.
- `BENCHMARK_REPORT.pdf` — readable six-page A3 landscape rendering; ASR and TTS each occupy one page.
- `execution/fresh_current/` — raw JSONL records, generated audio, environments, validity declarations, and run logs for all 15 ASR and 19 TTS models.
- `execution/sources/` — pinned publisher metadata, licenses, language declarations, revisions, and dependency provenance.
- `execution/metrics_current/` — machine-readable aggregate metrics.
- `execution/dataset_sources/` — evaluation corpus provenance.
- `LISTENING_REVIEW/` — 107 blind clips, manifest, checksums, and single-score review UI.
- `execution/grok_batch_01.jsonl` and `grok_batch_02.jsonl` — raw blinded Grok outputs.
- `execution/grok_review.json` — validated, deblinded 107-clip Grok review with scores, exact mispronunciations, naturalness findings, and source hashes.
- `benchmark_runtime/` — runners, aggregators, report generator, importers, and validators.
- `execution/final_shutdown_verification.json` — RunPod terminal-state evidence.
- `execution/final_local_data_audit.json` — local record, audio-reference, and checksum completeness audit across all 34 models.
- `execution/FINAL_STATUS.json` and `final_report_validation.json` — release status and final checks.
- `indic_speech_benchmark_prd_v1/` — benchmark specification and schemas.

Run `python3 verify_pack.py` after assembly. Run `python3 serve_report.py` to host locally without changing relative evidence links.
"""
    claude = """# Prompt for Claude

Independently verify and host this on-prem Indic speech benchmark. Do not trust summary claims without checking the underlying files.

1. Run `python3 verify_pack.py` and retain its output.
2. Recompute the SHA-256 values in `EVIDENCE_MANIFEST.json` for all files.
3. Inspect `BENCHMARK_REPORT.html`: it must contain exactly four sections (ASR, TTS, Deployment, Evidence), one main row for each of 15 ASR and 19 TTS models, no mode column, no duplicate main rows, and one Streaming value per model.
4. Verify every local `href` and `data-audio` target exists.
5. Verify all 107 blind clips against `LISTENING_REVIEW/blind_key.json`, and verify that `execution/grok_review.json` contains one valid 1–5 result for each ID. Treat Grok scores as Grok judgments, not human MOS.
6. Recompute ASR WER from the raw JSONL using the normalization and edit counts implemented in `benchmark_runtime/one_page_report.py`; compare with the HTML cells.
7. Verify that the main TTS table contains only owner blind ratings for exact waveforms. Treat Grok rows as separate AI diagnostics and never as human scores.
8. Verify model revisions, declared languages, licenses, runners, hardware environments, and supported/unsupported cells through `execution/sources/`, `execution/fresh_current/`, and `benchmark_runtime/`.
9. Verify all RunPod states are `EXITED` with null runtime in `execution/final_shutdown_verification.json`; verify local download completeness through `execution/final_local_data_audit.json`; and trace the recorded spend through the included lease evidence and `FINAL_STATUS.json`.
10. Report every discrepancy with exact file paths and calculations. Do not silently repair or reinterpret evidence.
11. If verification passes, host the assembled directory as static files while preserving its relative paths. For a local preview run `python3 serve_report.py`; for another host deploy the entire assembled directory unchanged and use `BENCHMARK_REPORT.html` as the entry point.
"""
    return [
        Asset("EVIDENCE_INDEX.md", index.encode(), "pack documentation"),
        Asset("CLAUDE_VERIFICATION_PROMPT.md", claude.encode(), "pack documentation"),
        Asset("verify_pack.py", VERIFY_SCRIPT.encode(), "portable verifier"),
        Asset("serve_report.py", SERVE_SCRIPT.encode(), "portable host"),
    ]


def assign_parts(assets: list[Asset]) -> list[list[Asset]]:
    parts: list[list[Asset]] = []
    sizes: list[int] = []
    for asset in sorted(assets, key=lambda item: item.size, reverse=True):
        placed = False
        for index, size in enumerate(sizes):
            if size + asset.size <= TARGET_PAYLOAD_BYTES:
                parts[index].append(asset);sizes[index] += asset.size;placed = True;break
        if not placed:
            if asset.size > TARGET_PAYLOAD_BYTES:
                raise ValueError(f"Single file exceeds part target: {asset.path}")
            parts.append([asset]);sizes.append(asset.size)
    return parts


def build(output: pathlib.Path) -> dict:
    assets = source_assets() + generated_assets()
    parts = assign_parts(assets)
    assignment = {}
    for index, part in enumerate(parts, 1):
        name = f"part_{index:03d}"
        for asset in part:
            assignment[asset.path] = name
    rows = [
        {"path": asset.path, "bytes": asset.size, "sha256": asset.sha256, "category": asset.category, "part": assignment[asset.path]}
        for asset in sorted(assets, key=lambda item: item.path)
    ]
    manifest = {
        "format": "indic-speech-evidence-pack-v1",
        "part_limit_bytes": MAX_PART_BYTES,
        "file_count": len(rows),
        "payload_bytes": sum(row["bytes"] for row in rows),
        "parts": len(parts),
        "files": rows,
    }
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    by_path = {asset.path: asset for asset in assets}
    for index, part in enumerate(parts, 1):
        name = f"part_{index:03d}";directory = output / name;control = directory / "_PACK";control.mkdir(parents=True)
        for asset in part:
            destination = directory / "payload" / asset.path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(asset.data)
        part_rows = [row for row in rows if row["part"] == name]
        (control / "PART_MANIFEST.json").write_text(json.dumps({"part": name, "files": part_rows}, indent=2, ensure_ascii=False) + "\n")
        (control / "MASTER_MANIFEST.json").write_bytes(manifest_bytes)
        (control / "assemble_and_verify.py").write_text(ASSEMBLER)
        (control / "README.txt").write_text("Keep every part_* folder together. Run: python3 part_001/_PACK/assemble_and_verify.py --output assembled_evidence_pack\n")
        logical = sum(p.stat().st_size for p in directory.rglob("*") if p.is_file())
        if logical >= MAX_PART_BYTES:
            raise ValueError(f"{name} is {logical} bytes, above the strict part limit")
    archives = {}
    for directory in sorted(path for path in output.glob("part_*") if path.is_dir()):
        archive = pathlib.Path(shutil.make_archive(str(output / directory.name), "zip", root_dir=output, base_dir=directory.name))
        if archive.stat().st_size >= MAX_PART_BYTES:
            raise ValueError(f"{archive.name} is {archive.stat().st_size} bytes, above the strict part limit")
        archives[archive.name] = archive.stat().st_size
    summary = {
        "output": str(output),
        "parts": len(parts),
        "files": len(rows),
        "payload_bytes": manifest["payload_bytes"],
        "part_sizes": {
            path.name: sum(p.stat().st_size for p in path.rglob("*") if p.is_file())
            for path in sorted(path for path in output.glob("part_*") if path.is_dir())
        },
        "archive_sizes": archives,
        "master_manifest_sha256": digest(manifest_bytes),
    }
    (output / "PACK_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=pathlib.Path, default=ROOT / "SHARE_EVIDENCE_PACK")
    args = parser.parse_args()
    print(json.dumps(build(args.output.resolve()), indent=2))
