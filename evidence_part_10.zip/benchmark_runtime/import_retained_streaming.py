"""Normalize preserved publisher streaming probes into benchmark records."""
from __future__ import annotations

import hashlib
import json
import pathlib
import shutil


ROOT = pathlib.Path("/workspace/speechbench_20260924")
SUITE = pathlib.Path("/workspace/tts_streaming_suite")


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def import_svara() -> None:
    source = json.loads((SUITE / "svara/results.json").read_text())
    config = json.loads((SUITE / "svara/config.json").read_text())
    output = ROOT / "T01"
    output.mkdir(exist_ok=True)
    mapping = {
        "hi-IN": ("stream_hi", SUITE / "svara/samples/hi_stream.wav"),
        "en-IN": ("stream_en", SUITE / "svara/samples/en_stream.wav"),
    }
    with (output / "records.jsonl").open("a", encoding="utf-8") as target:
        for locale, (probe_name, audio_source) in mapping.items():
            probe = source["probes"][probe_name]
            audio_target = output / f"publisher-endpoint-stream-{locale}.wav"
            shutil.copy2(audio_source, audio_target)
            record = {
                "run_id": "retained-20260918-svara-endpoint",
                "phase": "smoke",
                "locale": locale,
                "voice": probe["voice"],
                "mode": "native_stream",
                "synthesis_class": "A",
                "ok": bool(probe["ok"]),
                "sample_rate": 24000,
                "ttfa_s": probe["ttfa_s"],
                "total_s": probe["total_s"],
                "audio_duration_s": probe["audio_duration_s"],
                "rtf": probe["rtf"],
                "chunk_count": probe["n_chunks"],
                "stream_flag": True,
                "http_status": probe["status"],
                "transfer_encoding": probe["headers"].get("transfer-encoding"),
                "endpoint": config["endpoint"],
                "publisher_inference_revision": config["inference_git_rev"],
                "model_revision": config["model_revision"],
                "file": str(audio_target.relative_to(ROOT)),
                "sha256": digest(audio_target),
                "source_results_sha256": digest(SUITE / "svara/results.json"),
                "source_config_sha256": digest(SUITE / "svara/config.json"),
            }
            target.write(json.dumps(record, ensure_ascii=False) + "\n")
    environment = {
        **config,
        "source_results": str(SUITE / "svara/results.json"),
        "source_results_sha256": digest(SUITE / "svara/results.json"),
        "normalizer_sha256": digest(pathlib.Path(__file__)),
    }
    (output / "environment-retained-publisher-endpoint.json").write_text(json.dumps(environment, indent=2))


if __name__ == "__main__":
    import_svara()
    print(json.dumps({"imported": ["T01"], "source": str(SUITE / "svara")}))
