"""Preserve the affected run and explain its exclusion from stock-model comparisons."""
import datetime,hashlib,json,pathlib
ROOT=pathlib.Path('/workspace/speechbench_20260924/A08');raw=(ROOT/'file_records.jsonl').read_bytes()
rows=[json.loads(x) for x in raw.splitlines()]
bad='20260924T005427Z'
if not any(r.get('run_id')==bad for r in rows):raise ValueError('Affected run missing')
record=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records_file='file_records.jsonl',
    records_prefix_bytes=len(raw),records_prefix_sha256=hashlib.sha256(raw).hexdigest(),
    invalid_runs={bad:'Harness preprocessing error: short log-mel features were zero-padded after extraction instead of padding the waveform through the Whisper feature extractor. These are not the standard checkpoint input features.'},
    affected_trials=sum(r.get('run_id')==bad for r in rows),raw_records_preserved=True,rerun_required=True)
(ROOT/'run_validity.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
