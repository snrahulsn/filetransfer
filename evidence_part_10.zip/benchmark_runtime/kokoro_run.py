"""Pinned Kokoro generator: completed-segment output is not within-segment streaming."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',HF_HOME='/workspace/hf_cache',HF_HUB_CACHE='/workspace/hf_cache')
import hashlib,importlib.metadata,json,pathlib,time,traceback
import numpy as np,soundfile as sf,torch
torch.set_num_threads(4)
from kokoro import KModel,KPipeline
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T03';OUT.mkdir(exist_ok=True)
PIN='f3ff3571791e39611d31c381e3a41a3af07b4987'
MODEL=pathlib.Path('/workspace/hf_cache/models--hexgrad--Kokoro-82M/snapshots')/PIN
ITEMS=[('hi-IN','h','hf_alpha','आपकी बैठक कल दोपहर तीन बजे है।'),('en-IN','a','af_heart','Your meeting with Priya is tomorrow at three thirty PM.')]
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while c:=f.read(4*1024*1024):h.update(c)
    return h.hexdigest()
def main():
    env=dict(model='hexgrad/Kokoro-82M',revision=PIN,gpu=torch.cuda.get_device_name(0),precision='float32',
             torch=torch.__version__,kokoro=importlib.metadata.version('kokoro'),runner_sha256=sha(__file__),
             weights_sha256=sha(MODEL/'kokoro-v1_0.pth'),hf_offline=True,network_namespace_isolated=False,
             english_voice_note='American English af_heart evaluated against en-IN target; no Indian-accent claim')
    (OUT/'environment.json').write_text(json.dumps(env,indent=2))
    model=KModel(repo_id='hexgrad/Kokoro-82M',config=str(MODEL/'config.json'),model=str(MODEL/'kokoro-v1_0.pth')).to('cuda').eval()
    for locale,code,voice,text in ITEMS:
        try:pipeline=KPipeline(lang_code=code,model=model,repo_id='hexgrad/Kokoro-82M',device='cuda')
        except Exception as e:
            with (OUT/'records.jsonl').open('a') as f:f.write(json.dumps(dict(locale=locale,phase='initialization',ok=False,error=str(e)))+'\n')
            continue
        voice_path=str(MODEL/'voices'/(voice+'.pt'))
        for i in range(104):
            phase='warmup' if i<3 else 'smoke' if i==3 else 'performance_c1'
            rec=dict(locale=locale,voice=voice,text=text,phase=phase,index=i,mode='completed_segment_generator',ok=False)
            try:
                torch.cuda.synchronize();start=time.perf_counter();events=[];chunks=[]
                for graphemes,phonemes,audio in pipeline(text,voice=voice_path,speed=1):
                    a=audio.detach().cpu().float().numpy().reshape(-1)
                    if len(a):chunks.append(a);events.append(dict(at_s=time.perf_counter()-start,samples=len(a),completed_text=graphemes))
                torch.cuda.synchronize();total=time.perf_counter()-start
                audio=np.concatenate(chunks);duration=len(audio)/24000
                if not np.isfinite(audio).all() or duration==0:raise ValueError('Invalid audio')
                rec.update(ok=True,events=events,ttfa_s=events[0]['at_s'],total_s=total,audio_duration_s=duration,rtf=total/duration,
                           synthesis_class='B' if len(events)>1 else 'C',within_segment_streaming=False)
                if phase=='smoke':
                    file=OUT/f'{locale}-{i}.flac';sf.write(file,audio,24000,subtype='PCM_24')
                    rec.update(file=str(file.relative_to(ROOT)),sha256=sha(file),sample_rate=24000)
            except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
            with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            if i<5 or i%20==0:print(json.dumps({k:rec.get(k) for k in ['locale','phase','index','ok','ttfa_s','rtf','error']}),flush=True)
            if not rec['ok']:break
    (OUT/'DONE').write_text('Smoke and 100 C1 trials per successful locale; remaining quality/concurrency/long-text tests pending.\n')
if __name__=='__main__':main()
