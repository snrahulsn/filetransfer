"""Render the dense two-table report as one A2 landscape page."""
from pathlib import Path
import os
import signal
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
CHROME=Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
try:
    from playwright.sync_api import sync_playwright
except ModuleNotFoundError:
    if not CHROME.is_file():
        raise RuntimeError("PDF export requires Playwright or Google Chrome")
    target = ROOT / "BENCHMARK_REPORT.pdf"
    target.unlink(missing_ok=True)
    process = subprocess.Popen(
        [str(CHROME), "--headless", "--disable-gpu", "--disable-background-networking",
         "--disable-component-update", "--disable-sync", "--no-first-run",
         "--no-pdf-header-footer", f"--user-data-dir=/tmp/asr-tts-report-chrome",
         f"--print-to-pdf={target}", (ROOT/"BENCHMARK_REPORT.html").as_uri()],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
    )
    try:
        deadline = time.time() + 45
        previous_size = -1
        stable_checks = 0
        while time.time() < deadline:
            if target.is_file() and target.stat().st_size > 0:
                size = target.stat().st_size
                stable_checks = stable_checks + 1 if size == previous_size else 0
                previous_size = size
                if stable_checks >= 3:
                    break
            if process.poll() is not None and not target.is_file():
                raise RuntimeError(f"Chrome PDF export exited with {process.returncode}")
            time.sleep(.25)
        else:
            raise TimeoutError("Chrome PDF export did not finish within 45 seconds")
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=10)
else:
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=str(CHROME) if CHROME.exists() else None,headless=True)
        page=browser.new_page(viewport={"width":2246,"height":1587})
        page.goto((ROOT/"BENCHMARK_REPORT.html").as_uri(),wait_until="networkidle")
        page.pdf(path=str(ROOT/"BENCHMARK_REPORT.pdf"), print_background=True,
                 prefer_css_page_size=True, scale=0.92,
                 margin={"top":"0","right":"0","bottom":"0","left":"0"})
        browser.close()
