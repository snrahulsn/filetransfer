"""Use only the remaining lease window after the sequential queue has exited."""
import datetime,json,os,pathlib,signal,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924')
DEADLINE=datetime.datetime(2026,9,24,1,43,0,tzinfo=datetime.timezone.utc).timestamp()
def command(pid):
    try:return pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
    except FileNotFoundError:return ''
while 'followup_queue.py' in command(178) and time.time()<DEADLINE-90:time.sleep(2)
remaining=DEADLINE-time.time()
if 'followup_queue.py' in command(178) or remaining<90:raise SystemExit('Insufficient bounded window; no additional worker launched')
gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
if gpu:raise SystemExit('GPU still occupied; no additional worker launched')
cmd=['/workspace/tts_streaming_suite/.venv_gpu/bin/python','asr_baselines.py','A10','--limit','25']
rec=dict(job='A10-final-window',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,timeout_s=min(180,remaining))
with (ROOT/'A10-final-window.log').open('ab') as log:
    proc=subprocess.Popen(cmd,cwd=ROOT,env=dict(os.environ,USE_TF='0',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:proc.wait(timeout=rec['timeout_s']);rec.update(exit_code=proc.returncode,timed_out=False)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        rec.update(exit_code=proc.returncode,timed_out=True)
try:os.killpg(proc.pid,signal.SIGTERM)
except ProcessLookupError:pass
rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (ROOT/'queue_outcomes.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
print(json.dumps(rec),flush=True)
