import hashlib,pathlib,tempfile,unittest
from stage_model import stage
class StageIntegrityTests(unittest.TestCase):
    def test_git_source_and_lfs_weights_are_both_checked(self):
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);source=root/'source';source.mkdir();blobs=root/'blobs';blobs.mkdir()
            code=b'print("audited")\n';weight=b'weight fixture'
            for name,data,key in [('model.py',code,hashlib.sha1(b'blob '+str(len(code)).encode()+b'\0'+code).hexdigest()),('model.safetensors',weight,hashlib.sha256(weight).hexdigest())]:
                blob=blobs/key;blob.write_bytes(data);(source/name).symlink_to(blob)
            _,manifest=stage(source,'A00',root/'stage')
            self.assertTrue(manifest['model.py']['upstream_git_blob_digest_verified'])
            self.assertTrue(manifest['model.safetensors']['upstream_lfs_digest_verified'])
            (source/'model.py').resolve().write_bytes(b'changed code')
            with self.assertRaisesRegex(ValueError,'Git blob digest mismatch'):stage(source,'A00',root/'stage')
if __name__=='__main__':unittest.main()
