"""Continue after the existing TTS queue, preserving every job outcome."""
import datetime,json,os,pathlib,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924')
PYS={'default':'/workspace/tts_streaming_suite/.venv_gpu/bin/python','qwen':str(ROOT/'envs/qwen_asr/bin/python')}
ENV=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',USE_TF='0',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
def main():
    while pathlib.Path('/proc/1571').exists():time.sleep(10)
    jobs=[('T15',None,900),('A01-stream-resume',None,900)]+[(m,25,900) for m in ['A09','A07','A08','A10','A15','A03','A04']]+[(m,None,2400) for m in ['A09','A07','A08','A15','A03','A10','A04']]
    for model,limit,timeout in jobs:
        # Leave collection and watchdog shutdown time before the paid lease ends.
        remaining=1790212651-time.time()
        if remaining<180:break
        cmd=[PYS['qwen' if model in ['A07','A09'] else 'default'],'-X','utf8',str(ROOT/'asr_baselines.py'),model]
        if model=='T15':cmd=[str(ROOT/'envs/voxcpm/bin/python'),'-X','utf8',str(ROOT/'voxcpm_run.py')]
        if model=='A01-stream-resume':cmd=[PYS['default'],'-X','utf8',str(ROOT/'sravaani_run_resume2.py')]
        if limit:cmd+=['--limit',str(limit)]
        rec=dict(job=model,limit_per_locale=limit,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd)
        with (ROOT/(model+'-queue.log')).open('ab') as log:
            try:
                result=subprocess.run(cmd,cwd=ROOT,env=dict(ENV,ASR_STAGE='stream') if model=='A01-stream-resume' else ENV,stdout=log,stderr=subprocess.STDOUT,timeout=min(timeout,remaining-120))
                rec.update(exit_code=result.returncode,timed_out=False)
            except subprocess.TimeoutExpired:rec.update(exit_code=None,timed_out=True)
        rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (ROOT/'queue_outcomes.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
        print(json.dumps(rec),flush=True)
if __name__=='__main__':main()
