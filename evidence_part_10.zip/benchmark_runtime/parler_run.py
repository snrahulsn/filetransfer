"""Fresh Indic Parler smoke measurements. Not the full qualification gate."""
import os
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'
os.environ['HF_HOME']='/workspace/hf_cache'
os.environ['USE_TF']='0'
os.environ['OMP_NUM_THREADS']='4'
os.environ['MKL_NUM_THREADS']='4'
import hashlib, importlib.metadata, json, pathlib, queue, threading, time, traceback, datetime
import numpy as np
import soundfile as sf
import torch
torch.set_num_threads(4)
from transformers import AutoTokenizer, StoppingCriteria, StoppingCriteriaList
from parler_tts import ParlerTTSForConditionalGeneration, ParlerTTSStreamer

ROOT=pathlib.Path('/workspace/speechbench_20260924')
OUT=ROOT/'T04'; OUT.mkdir(exist_ok=True)
MODEL=pathlib.Path('/workspace/indic_parler_qual/model_cache/indic-parler-tts')
PIN='7b527af5ee8ed1f9a28d80b19703ed9bb8ba10ca'
TEXTS=[
('en-IN','Mary','Your meeting with Priya is tomorrow at three thirty PM.'),
('hi-IN','Divya','आपकी बैठक कल दोपहर तीन बजे है।'),
('bn-IN','Aditi','আপনার মিটিং আগামীকাল দুপুর তিনটায়।'),
('mr-IN','Sunita','तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.'),
('te-IN','Lalitha','మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.'),
('ta-IN','Jaya','உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.'),
('gu-IN','Neha','તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.'),
('kn-IN','Anu','ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.'),
('ml-IN','Anjali','നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.'),
('or-IN','Debjani','ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।')]

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while c:=f.read(4*1024*1024):h.update(c)
    return h.hexdigest()

def main():
    run_id=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    previous=[]
    if (OUT/'records.jsonl').exists():
        for line in (OUT/'records.jsonl').read_text().splitlines():
            try:previous.append(json.loads(line))
            except json.JSONDecodeError:raise RuntimeError('Truncated previous evidence; reconcile before resuming')
    completed={(r['locale'],r['mode']) for r in previous if r.get('phase')=='smoke' and r.get('ok')}
    metadata=(MODEL/'.cache/huggingface/download/model.safetensors.metadata').read_text().splitlines()
    assert metadata[0]==PIN, 'Cached model revision mismatch'
    actual=sha(MODEL/'model.safetensors')
    assert actual==metadata[1], 'Cached weight hash mismatch'
    env={'run_id':run_id,'model':'ai4bharat/indic-parler-tts','revision':PIN,'weights_sha256':actual,
         'purpose':'smoke; not full qualification','precision':'bfloat16','seed':20260924,
         'gpu':torch.cuda.get_device_name(0),'cuda':torch.version.cuda,'torch_cpu_threads':torch.get_num_threads(),
         'versions':{k:importlib.metadata.version(k) for k in ['torch','transformers','parler-tts','soundfile']},
         'huggingface_offline':True,'network_namespace_isolated':False,'runner_sha256':sha(__file__)}
    (OUT/f'environment-{run_id}.json').write_text(json.dumps(env,indent=2))
    print('Loading verified pinned model',flush=True)
    t=time.perf_counter()
    model=ParlerTTSForConditionalGeneration.from_pretrained(MODEL,torch_dtype=torch.bfloat16,local_files_only=True).to('cuda').eval()
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
    dtok=AutoTokenizer.from_pretrained('/workspace/hf_cache/models--google--flan-t5-large/snapshots/0613663d0d48ea86ba8cb3d7a44f0f65dc596a2a',local_files_only=True)
    env['load_s']=time.perf_counter()-t
    (OUT/f'environment-{run_id}.json').write_text(json.dumps(env,indent=2))
    sr=int(model.config.sampling_rate)
    for phase,items in [('warmup',[TEXTS[0]]*3),('smoke',TEXTS)]:
        for i,(locale,voice,text) in enumerate(items):
            for mode in ['full','stream']:
                if phase=='smoke' and (locale,mode) in completed:continue
                rec={'run_id':run_id,'phase':phase,'locale':locale,'voice':voice,'text':text,'mode':mode,'index':i,'ok':False}
                rec['description']=f"{voice}'s voice delivers clear speech at a moderate pace, in a close recording with no background noise."
                stop=threading.Event()
                class Stop(StoppingCriteria):
                    def __call__(self,*args,**kwargs):return stop.is_set()
                th=None; chunks=[]; events=[]; holder={}
                try:
                    torch.manual_seed(20260924)
                    torch.cuda.reset_peak_memory_stats()
                    torch.cuda.synchronize(); start=time.perf_counter()
                    d=dtok(rec['description'],return_tensors='pt').to('cuda')
                    p=tok(text,return_tensors='pt').to('cuda')
                    kw=dict(input_ids=d.input_ids,attention_mask=d.attention_mask,prompt_input_ids=p.input_ids,
                            prompt_attention_mask=p.attention_mask,max_new_tokens=1800,do_sample=True,
                            temperature=1.0,stopping_criteria=StoppingCriteriaList([Stop()]))
                    if mode=='stream':
                        streamer=ParlerTTSStreamer(model,device='cuda',play_steps=10,timeout=120)
                        def generate():
                            try:
                                with torch.inference_mode():model.generate(**kw,streamer=streamer)
                                torch.cuda.synchronize();holder['generation_end_s']=time.perf_counter()-start
                            except BaseException as e:holder['error']=str(e)
                        th=threading.Thread(target=generate,daemon=True);th.start()
                        for chunk in streamer:
                            chunk=np.asarray(chunk,dtype=np.float32).reshape(-1)
                            if len(chunk):
                                events.append({'at_s':time.perf_counter()-start,'samples':len(chunk)})
                                chunks.append(chunk)
                        th.join(120)
                        if th.is_alive():raise TimeoutError('generation did not finish')
                        if 'error' in holder:raise RuntimeError(holder['error'])
                    else:
                        with torch.inference_mode():a=model.generate(**kw)
                        torch.cuda.synchronize();holder['generation_end_s']=time.perf_counter()-start
                        chunks=[a.detach().cpu().float().numpy().reshape(-1)]
                        events=[{'at_s':time.perf_counter()-start,'samples':len(chunks[0])}]
                    audio=np.concatenate(chunks);end=time.perf_counter()-start
                    if len(audio)==0 or not np.isfinite(audio).all():raise ValueError('Empty/nonfinite waveform')
                    duration=len(audio)/sr
                    file=OUT/f'{run_id}-{phase}-{i:03d}-{locale}-{mode}.flac'
                    sf.write(file,audio,sr,subtype='PCM_24')
                    rec.update(ok=True,sample_rate=sr,audio_duration_s=duration,total_s=end,rtf=end/duration,
                               ttfa_s=events[0]['at_s'],generation_end_s=holder['generation_end_s'],events=events,
                               output_emitted_before_generation_end=events[0]['at_s']<holder['generation_end_s'],
                               peak_memory_allocated_bytes=torch.cuda.max_memory_allocated(),peak_abs=float(np.max(np.abs(audio))),
                               prequantization_out_of_range_samples=int(np.sum(np.abs(audio)>=1)),
                               file=str(file.relative_to(ROOT)),sha256=sha(file))
                except Exception as e:
                    stop.set()
                    if th:th.join(20)
                    rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
                with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n');f.flush()
                print(json.dumps({k:rec.get(k) for k in ['phase','locale','mode','ok','ttfa_s','rtf','error']}),flush=True)
                if th and th.is_alive():raise RuntimeError('Unsafe to continue while generation thread remains active')
    (OUT/'DONE').write_text('Smoke complete; qualification still requires quality and performance corpus.\n')

if __name__=='__main__':main()
