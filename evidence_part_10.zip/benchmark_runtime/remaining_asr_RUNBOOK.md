# A12 and A14 execution

All commands assume `/workspace/speechbench_20260924` contains `asr_corpus.py`,
`metrics.py`, and the five A12/A14 files beside them.

## A12 VibeVoice-ASR

Pinned inputs:

- model: `microsoft/VibeVoice-ASR@d0c9efdb8d614685062c04425d91e01b6f37d944`
- tokenizer: `Qwen/Qwen2.5-7B@d149729398750b98c0af14eb82c78cfe92750796`
- inference source: `microsoft/VibeVoice@1541f590c7099820f10ea012f48d2399282df69f`

The publisher model card declares Hindi and English among this benchmark's ten
target languages. Run both with three clips per locale:

```bash
cd /workspace/speechbench_20260924
python3 -m venv envs/vibevoice
envs/vibevoice/bin/pip install --upgrade pip
envs/vibevoice/bin/pip install "torch==2.8.0" "torchaudio==2.8.0" \
  "transformers==4.57.6" "accelerate==1.10.1"
git clone https://github.com/microsoft/VibeVoice.git runtime_sources/VibeVoice
git -C runtime_sources/VibeVoice checkout 1541f590c7099820f10ea012f48d2399282df69f
envs/vibevoice/bin/pip install -e runtime_sources/VibeVoice
JOB_MANIFEST=a12_download.json envs/vibevoice/bin/python download_models.py
envs/vibevoice/bin/python a12_run.py --limit 3 --max-new-tokens 512
```

The model has 8,674,021,857 BF16 parameters and its weights occupy 17.35 GB.
Use a CUDA GPU with at least 32 GB VRAM; the adapter uses SDPA and BF16.

## A14 IndicWhisper

Pinned inputs are the nine public ZIP URLs recorded in `a14_assets.json`. The
downloader verifies the exact byte lengths from the source audit, tests every
ZIP member, computes SHA-256, extracts it, and records all checkpoint paths.
The inference source is
`AI4Bharat/vistaar@21dce3406fddf0e18984165e735d23db38760dd3`.

```bash
cd /workspace/speechbench_20260924
python3 -m venv envs/indicwhisper
envs/indicwhisper/bin/pip install --upgrade pip
envs/indicwhisper/bin/pip install "torch==2.8.0" "torchaudio==2.8.0" \
  "transformers==4.57.6" "accelerate==1.10.1" "soundfile==0.13.1"
envs/indicwhisper/bin/python a14_download.py
envs/indicwhisper/bin/python a14_run.py --limit 3
```

This runs Bengali, Gujarati, Hindi, Kannada, Malayalam, Marathi, Odia, Tamil,
and Telugu sequentially, unloading each language model before loading the next.
The publisher does not provide an English IndicWhisper checkpoint.
