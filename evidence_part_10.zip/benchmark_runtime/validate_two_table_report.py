"""Validate the one-page, two-table release report and its evidence links."""
from __future__ import annotations

import hashlib, json, pathlib, re, subprocess
from urllib.parse import unquote

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPORT = ROOT / "BENCHMARK_REPORT.html"
PDF = ROOT / "BENCHMARK_REPORT.pdf"

def pdf_pages(path: pathlib.Path) -> int:
    text = subprocess.check_output(["pdfinfo", str(path)], text=True)
    return int(re.search(r"^Pages:\s+(\d+)$", text, re.M).group(1))

def main() -> None:
    doc = REPORT.read_text()
    failures=[]
    tables=doc.count("<table")
    asr=[x for x in re.findall(r"<b>(A\d{2})</b>",doc)]
    tts=[x for x in re.findall(r"<b>(T\d{2})</b>",doc)]
    if tables!=2: failures.append(f"expected 2 tables, found {tables}")
    if asr!=[f"A{i:02d}" for i in range(1,16)]: failures.append("ASR rows are not A01-A15 exactly once")
    if tts!=[f"T{i:02d}" for i in range(1,20)]: failures.append("TTS rows are not T01-T19 exactly once")
    if "Pending" in doc: failures.append("report contains Pending")
    missing=[]
    for value in re.findall(r'href="([^"]+)"',doc):
        if value.startswith(("http://","https://","#")): continue
        target=ROOT/unquote(value.split("#",1)[0])
        if not target.exists(): missing.append(value)
    if missing: failures.append(f"broken local links: {sorted(set(missing))}")
    pages=pdf_pages(PDF)
    if pages!=1: failures.append(f"expected one PDF page, found {pages}")
    ledger=json.loads((ROOT/"execution/primary_configuration_ledger.json").read_text())
    pending=sorted(ledger["tts"].get("pending_streaming_execution",{}))
    if pending: failures.append(f"pending streaming models: {pending}")
    shutdown=json.loads((ROOT/"execution/final_shutdown_verification.json").read_text())
    if shutdown.get("all_stopped") is not True: failures.append("RunPod audit is not all_stopped")
    playable=len(re.findall(r'<td class="audio(?: rated [a-z]+)?">',doc))
    blind_root=ROOT/"LISTENING_REVIEW"
    blind=json.loads((blind_root/"blind_key.json").read_text())
    manifest=json.loads((blind_root/"package_manifest.json").read_text())
    if len(blind)!=playable or manifest.get("clip_count")!=playable:
        failures.append(f"blind test count {len(blind)} differs from {playable} playable report cells")
    if hashlib.sha256(json.dumps(blind,sort_keys=True).encode()).hexdigest()!=manifest.get("package_id"):
        failures.append("blind test package checksum mismatch")
    invalid_clips=[]
    for row in blind:
        source=next(iter((blind_root/"clips").glob(row["id"]+".*")),None)
        if source is None or hashlib.sha256(source.read_bytes()).hexdigest()!=row["sha256"]:
            invalid_clips.append(row["id"])
    if invalid_clips: failures.append(f"invalid blind clips: {invalid_clips}")
    result={"schema_version":1,"report":REPORT.name,"pdf":PDF.name,"structure_pass":not failures,
            "release_ready":not failures,"checks":{"tables":tables,"asr_rows":len(asr),"tts_rows":len(tts),
            "playable_tts_cells":playable,"blind_test_clips":len(blind),"invalid_blind_clips":invalid_clips,"pending_streaming_models":pending,
            "broken_local_links":sorted(set(missing)),"pdf_pages":pages,"all_runpod_instances_stopped":shutdown.get("all_stopped")},
            "failures":failures}
    (ROOT/"execution/final_report_validation.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
    if failures: raise SystemExit(1)

if __name__ == "__main__": main()
