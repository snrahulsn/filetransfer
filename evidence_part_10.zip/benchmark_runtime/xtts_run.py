"""Pinned XTTS-v2 Hindi full-output smoke benchmark."""
import os
os.environ.update(HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",COQUI_TOS_AGREED="1")
import datetime,hashlib,json,pathlib,time,traceback
import numpy as np,soundfile as sf,torch
from TTS.config.shared_configs import BaseDatasetConfig
from TTS.tts.configs.xtts_config import XttsConfig
from TTS.tts.models.xtts import Xtts, XttsArgs, XttsAudioConfig
TEXTS=[("hi-IN","Hindi","आपकी बैठक कल दोपहर तीन बजे है।")]
ROOT=pathlib.Path("/workspace/speechbench_20260924");PIN="6c2b0d75eae4b7047358e3b6bd9325f857d43f77"
def digest(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        while b:=f.read(8388608):h.update(b)
    return h.hexdigest()
def main():
    d=json.loads((ROOT/"T17_download.json").read_text());path=pathlib.Path(d["path"])
    if d.get("status")!="downloaded" or d.get("revision")!=PIN:raise RuntimeError("invalid T17 pinned download")
    ref_record=json.loads((ROOT/"T12-ref_download.json").read_text());ref=pathlib.Path(ref_record["path"])/"adapters/hindi_female/ref.wav"
    config=XttsConfig();config.load_json(str(path/"config.json"));model=Xtts.init_from_config(config)
    with torch.serialization.safe_globals([BaseDatasetConfig, XttsConfig, XttsArgs, XttsAudioConfig]):
        model.load_checkpoint(config,checkpoint_dir=str(path),eval=True)
    model.cuda()
    out=ROOT/"T17";out.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    (out/f"environment-{stamp}.json").write_text(json.dumps(dict(run_id=stamp,model="coqui/XTTS-v2",revision=PIN,runner_sha256=digest(__file__),torch=torch.__version__,gpu=torch.cuda.get_device_name(0),reference_sha256=digest(ref),mode="full_output",synthesis_class="C",hf_offline=True,network_namespace_isolated=False),indent=2))
    item=next(x for x in TEXTS if x[0]=="hi-IN")
    for i,(phase,(_,_,text)) in enumerate([("warmup",item)]*3+[("smoke",item)]):
        rec=dict(run_id=stamp,phase=phase,index=i,locale="hi-IN",text=text,voice="T11 publisher Hindi female reference",mode="full",synthesis_class="C",ok=False)
        try:
            torch.manual_seed(20260924);torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter()
            result=model.synthesize(text,config,speaker_wav=str(ref),gpt_cond_len=3,language="hi");torch.cuda.synchronize();elapsed=time.perf_counter()-start
            audio=np.asarray(result["wav"],dtype=np.float32);sr=config.audio.output_sample_rate
            if not len(audio) or not np.isfinite(audio).all():raise ValueError("empty or invalid waveform")
            dur=len(audio)/sr;rec.update(ok=True,sample_rate=sr,total_s=elapsed,ttfa_s=elapsed,audio_duration_s=dur,rtf=elapsed/dur,peak_memory_bytes=torch.cuda.max_memory_allocated())
            if phase=="smoke":
                file=out/f"{stamp}-hi-IN.flac";sf.write(file,audio,sr,subtype="PCM_24");rec.update(file=str(file.relative_to(ROOT)),sha256=digest(file))
        except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (out/"records.jsonl").open("a",encoding="utf-8") as f:f.write(json.dumps(rec,ensure_ascii=False)+"\n")
        print(json.dumps({k:rec.get(k) for k in ["phase","ok","rtf","error"]}),flush=True)
        if not rec["ok"]:break
    (out/"DONE").write_text("Pinned Hindi full-output smoke benchmark attempted.\n")
if __name__=="__main__":main()
