"""Deterministic public code-switch smoke selection with exact segment boundaries."""
import hashlib,io,json,pathlib,random,tarfile,wave
ROOT=pathlib.Path('/workspace/speechbench_20260924/datasets/supplemental')
OUT=ROOT/'code_switch_smoke';OUT.mkdir(exist_ok=True)
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while c:=f.read(8388608):h.update(c)
    return h.hexdigest()
def main():
    rows=[]
    for locale,name in [('hi-IN','Hindi-English_test'),('bn-IN','Bengali-English_test')]:
        archive=ROOT/(name+'.tar.gz');manifest=json.loads((ROOT/(name+'.tar.gz.json')).read_text())
        if digest(archive)!=manifest['sha256']:raise ValueError('Archive checksum mismatch')
        metadata=ROOT/'code_switch_metadata'/name/'test/transcripts'
        texts=dict(line.split(maxsplit=1) for line in (metadata/'text').read_text().splitlines())
        segments=[line.split() for line in (metadata/'segments').read_text().splitlines()]
        if len({s[0] for s in segments})!=len(segments):raise ValueError('Duplicate segment id')
        selected=random.Random(20260924).sample(sorted(segments),3)
        wanted={}
        for item in selected:
            uid,recording,start,end=item
            if uid not in texts:raise ValueError('Missing transcript')
            wanted.setdefault('test/'+recording+'.wav',[]).append(item)
        found=set()
        with tarfile.open(archive,'r|gz') as tar:
            for member in tar:
                if member.name not in wanted:continue
                raw=tar.extractfile(member).read();original_hash=hashlib.sha256(raw).hexdigest()
                with wave.open(io.BytesIO(raw),'rb') as wav:
                    if (wav.getframerate(),wav.getnchannels(),wav.getsampwidth())!=(16000,1,2):raise ValueError('Unexpected corpus WAV format')
                    for uid,recording,start,end in wanted[member.name]:
                        begin=round(float(start)*16000);finish=round(float(end)*16000)
                        if not 0<=begin<finish<=wav.getnframes():raise ValueError('Segment outside recording')
                        wav.setpos(begin);pcm=wav.readframes(finish-begin)
                        if len(pcm)!=2*(finish-begin):raise ValueError('Short segment')
                        file=OUT/(locale+'-'+uid+'.wav')
                        with wave.open(str(file),'wb') as output:
                            output.setnchannels(1);output.setsampwidth(2);output.setframerate(16000);output.writeframes(pcm)
                        row=dict(id='MUCS2021/'+name+'/'+uid,locale=locale,reference=texts[uid],dataset='MUCS2021 '+name,
                            dataset_revision='archive sha256 '+manifest['sha256'],condition='clean',selection='seeded random 3 test segments per language; smoke only',seed=20260924,
                            population_segments=len(segments),source_page=manifest['source_page'],archive_sha256=manifest['sha256'],
                            recording=recording,original_recording_sha256=original_hash,start_sample=begin,end_sample=finish,
                            file=file.name,original_audio_sha256=digest(file),audio_duration_s=(finish-begin)/16000)
                        rows.append(row);found.add(uid)
        if found!={x[0] for x in selected}:raise ValueError('Missing selected recording')
    (OUT/'manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    print(json.dumps(dict(prepared=len(rows),population_by_locale={r['locale']:r['population_segments'] for r in rows})))
if __name__=='__main__':main()
