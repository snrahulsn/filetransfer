"""Load verified, preselected code-switch segments; never relabel as full-test coverage."""
import hashlib,json,pathlib
import soundfile as sf
ROOT=pathlib.Path('/workspace/speechbench_20260924/datasets/supplemental/code_switch_smoke')
def records():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for index,row in enumerate(manifest):
        path=(ROOT/row['file']).resolve()
        if not path.is_relative_to(ROOT.resolve()):raise ValueError('Segment outside corpus')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['original_audio_sha256']:raise ValueError('Segment checksum mismatch')
        audio,sr=sf.read(path,dtype='float32')
        if sr!=16000 or audio.ndim!=1 or len(audio)!=row['end_sample']-row['start_sample']:raise ValueError('Unexpected segmented audio')
        yield dict({k:v for k,v in row.items() if k!='file'},audio=audio,index=index,phase='code_switch_smoke')
