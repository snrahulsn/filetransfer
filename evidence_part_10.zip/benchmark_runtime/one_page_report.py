"""Generate the dense, traceable two-table ASR/TTS benchmark report."""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import html
import json
import pathlib
from typing import Any
from urllib.parse import quote


LANGUAGES = [
    ("hi-IN", "HI"),
    ("en-IN", "EN-IN"),
    ("bn-IN", "BN"),
    ("mr-IN", "MR"),
    ("ta-IN", "TA"),
    ("te-IN", "TE"),
    ("gu-IN", "GU"),
    ("kn-IN", "KN"),
    ("ml-IN", "ML"),
    ("or-IN", "OR"),
]

RUNNERS = {
    "A01": "sravaani_run.py",
    "A02": "voxtral_asr_run.py",
    "A03": "asr_baselines.py",
    "A04": "asr_baselines.py",
    "A05": "omni_run.py",
    "A06": "omni_run.py",
    "A07": "asr_baselines.py",
    "A08": "asr_baselines.py",
    "A09": "asr_baselines.py",
    "A10": "asr_baselines.py",
    "A11": "shrutam_run.py",
    "A12": "a12_run.py",
    "A13": "vibevoice_stream_run.py",
    "A14": "a14_run.py",
    "A15": "asr_baselines.py",
    "T01": "snac_run.py",
    "T02": "pocket_tts_local_run.py",
    "T03": "kokoro_run.py",
    "T04": "parler_run.py",
    "T05": "snac_run.py",
    "T06": "bodhan_run.py",
    "T07": "snac_run.py",
    "T08": "indic_f5_run.py",
    "T09": "sooktam_run.py",
    "T10": "voxtral_tts_run.py",
    "T11": "qwen_tts_run.py",
    "T12": "qwen_tts_run.py",
    "T13": "chatterbox_run.py",
    "T14": "chatterbox_run.py",
    "T15": "voxcpm_run.py",
    "T16": "fish_s2_run.py",
    "T17": "xtts_run.py",
    "T18": "mms_tts_run.py",
    "T19": "qwen_tts_run.py",
}


def read_json(path: pathlib.Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def read_jsonl(path: pathlib.Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows = []
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON at {path}:{line_number}") from exc
        row["_line"] = line_number
        rows.append(row)
    validity_path = path.parent / "run_validity.json"
    if validity_path.is_file():
        validity = read_json(validity_path, {}) or {}
        if validity.get("records_file") == path.name:
            prefix_bytes = int(validity["records_prefix_bytes"])
            prefix = path.read_bytes()[:prefix_bytes]
            if hashlib.sha256(prefix).hexdigest() != validity["records_prefix_sha256"]:
                raise ValueError(f"Run-validity declaration does not match {path}")
            invalid = set((validity.get("invalid_runs") or {}).keys())
            rows = [row for row in rows if row.get("run_id") not in invalid]
    correction_path = path.parent / "classification_correction.json"
    if correction_path.is_file():
        correction = read_json(correction_path, {}) or {}
        if correction.get("records_file") == path.name:
            prefix_bytes = int(correction["records_prefix_bytes"])
            prefix = path.read_bytes()[:prefix_bytes]
            if hashlib.sha256(prefix).hexdigest() != correction["records_prefix_sha256"]:
                raise ValueError(f"Classification correction does not match {path}")
            by_line = {int(item["row_number"]): item for item in correction.get("corrections", [])}
            for row in rows:
                item = by_line.get(row["_line"])
                if item:
                    for key in ("run_id", "locale", "phase"):
                        if row.get(key) != item.get(key):
                            raise ValueError(f"Classification correction identity mismatch in {path}")
                    row.update(
                        synthesis_class=item.get("synthesis_class"),
                        audio_before_final_result=item.get("audio_before_final_result"),
                    )
    return rows


def rel_href(path: pathlib.Path, output: pathlib.Path) -> str:
    relative = path.resolve().relative_to(output.resolve().parent)
    return quote(relative.as_posix())


def link(label: str, path: pathlib.Path | None, output: pathlib.Path, css: str = "") -> str:
    if path is None or not path.is_file():
        return html.escape(label)
    cls = f' class="{css}"' if css else ""
    return f'<a{cls} href="{rel_href(path, output)}">{html.escape(label)}</a>'


def model_label(repo: str) -> str:
    return repo.rstrip("/").split("/")[-1]


def gpu_label(model_dir: pathlib.Path) -> str:
    values = set()
    for path in model_dir.glob("environment*.json"):
        data = read_json(path, {}) or {}
        value = data.get("gpu") or data.get("hardware")
        if value:
            value = str(value).replace("NVIDIA GeForce ", "").replace("NVIDIA ", "")
            values.add(value)
    return " / ".join(sorted(values)) if values else "—"


def valid_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Drop warmups and retain one final observation per input/configuration identity."""
    rows = [row for row in rows if row.get("phase") != "warmup"]
    deduped: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in rows:
        identity = (
            row.get("id", row.get("index")),
            row.get("locale"),
            row.get("mode"),
            row.get("condition", "clean"),
            row.get("decoder"),
            row.get("runtime_variant"),
        )
        deduped[identity] = row
    return list(deduped.values())


def asr_mode_label(filename: str, rows: list[dict[str, Any]]) -> tuple[str, str]:
    raw_modes = {str(row.get("mode", "")) for row in rows}
    if filename == "stream_records.jsonl":
        if any("native" in mode for mode in raw_modes):
            return "Native stream", "Yes"
        if any("retranscription" in mode for mode in raw_modes):
            return "Buffered retranscription", "Buffered"
        return "Stream", "Yes"
    return "Full utterance", "No"


def tts_stream_value(rows: list[dict[str, Any]]) -> str:
    emitted = []
    for row in rows:
        for key in (
            "audio_before_final_result",
            "audio_before_generation_end",
            "output_emitted_before_generation_end",
        ):
            if key in row:
                emitted.append(bool(row[key]))
    if emitted:
        return "Yes" if any(emitted) else "No"
    if any(row.get("synthesis_class") == "A" for row in rows):
        return "Yes"
    return "No"


def micro_wer(rows: list[dict[str, Any]]) -> tuple[float, int] | None:
    if not rows:
        return None
    edits = 0
    words = 0
    n = 0
    for row in rows:
        reference_words = row.get("reference_words")
        word_edits = row.get("word_edits")
        if reference_words is None or word_edits is None:
            continue
        reference_words = int(reference_words)
        if not row.get("ok", False):
            word_edits = reference_words
        edits += int(word_edits)
        words += reference_words
        n += 1
    return (edits / words, n) if words and n else None


def wer_cell(rows: list[dict[str, Any]], records: pathlib.Path, output: pathlib.Path) -> str:
    result = micro_wer(rows)
    if result is None:
        return '<span class="na">—</span>'
    value, n = result
    pct = value * 100
    shade = min(100, max(0, pct))
    title = f"Micro WER {pct:.2f}%; {n} preserved trials; click for raw JSONL"
    return (
        f'<a class="metric" style="--wer:{shade:.2f}" '
        f'href="{rel_href(records, output)}" title="{html.escape(title)}">'
        f"{pct:.1f}%<small>n={n}</small></a>"
    )


def choose_audio(record: dict[str, Any], model_dir: pathlib.Path, mode: str) -> pathlib.Path | None:
    declared = record.get("file")
    if declared:
        candidate = model_dir.parent / str(declared)
        if candidate.is_file():
            return candidate
    locale = str(record.get("locale", ""))
    candidates = sorted(model_dir.glob(f"*{locale}*.flac"))
    if mode in {"full", "stream"}:
        preferred = [path for path in candidates if f"-{mode}.flac" in path.name]
        if preferred:
            candidates = preferred
    candidates = [path for path in candidates if "warmup" not in path.name]
    return candidates[0] if candidates else None


def audio_cell(
    record: dict[str, Any] | None,
    audio: pathlib.Path | None,
    output: pathlib.Path,
    quality_sources: list[tuple[str, tuple[float, int] | None, pathlib.Path, str]] | None = None,
) -> str:
    if record is None or audio is None:
        return '<span class="na">—</span>'
    expected_hash = record.get("sha256")
    if expected_hash:
        actual_hash = hashlib.sha256(audio.read_bytes()).hexdigest()
        if actual_hash != expected_hash:
            raise ValueError(f"Audio hash mismatch: {audio}")
    ttfa = record.get("ttfa_s")
    rtf = record.get("rtf")
    timing = []
    if ttfa is not None:
        timing.append(f"t{float(ttfa):.1f}")
    if rtf is not None:
        timing.append(f"r{float(rtf):.2f}")
    detail = " ".join(timing)
    title = f"Play {record.get('locale')} clip"
    if detail:
        title += f"; TTFA {float(ttfa):.3f}s" if ttfa is not None else ""
        title += f"; RTF {float(rtf):.3f}" if rtf is not None else ""
    quality_html = ""
    for label, quality, ratings_path, title_prefix in quality_sources or []:
        if quality is None or not ratings_path.is_file():
            continue
        score, count = quality
        quality_html += (
            f'<a class="quality {html.escape(label)}" href="{rel_href(ratings_path, output)}" '
            f'title="{html.escape(title_prefix)}; {count} rated clip(s)">{html.escape(label)}{score:.1f}</a>'
        )
    return (
        f'<button class="play" data-audio="{rel_href(audio, output)}" '
        f'title="{html.escape(title)}">▶</button>'
        + quality_html
        + (f"<small>{html.escape(detail)}</small>" if detail else "")
    )


def load_quality_ratings(path: pathlib.Path) -> dict[tuple[str, str, str], tuple[float, int]]:
    data = read_json(path, {}) or {}
    grouped: dict[tuple[str, str, str], list[float]] = collections.defaultdict(list)
    for row in data.get("rows", []):
        score = (row.get("ratings") or {}).get("Overall")
        if type(score) not in (int, float) or not 1 <= float(score) <= 5:
            continue
        key = (str(row.get("model_id")), str(row.get("locale")), str(row.get("mode")))
        grouped[key].append(float(score))
    return {key: (sum(values) / len(values), len(values)) for key, values in grouped.items()}


def load_grok_ratings(path: pathlib.Path) -> dict[tuple[str, str, str], tuple[float, int]]:
    data = read_json(path, {}) or {}
    grouped: dict[tuple[str, str, str], list[float]] = collections.defaultdict(list)
    for row in data.get("rows", []):
        score = row.get("overall_score")
        if type(score) is not int or not 1 <= score <= 5:
            continue
        key = (str(row.get("model_id")), str(row.get("locale")), str(row.get("mode")))
        grouped[key].append(float(score))
    return {key: (sum(values) / len(values), len(values)) for key, values in grouped.items()}


def evidence_links(
    model_id: str,
    records: pathlib.Path | None,
    runner: pathlib.Path | None,
    environment: pathlib.Path | None,
    output: pathlib.Path,
    blocker: str | None,
) -> str:
    pieces = []
    if records and records.is_file():
        pieces.append(link("data", records, output))
    if runner and runner.is_file():
        pieces.append(link("code", runner, output))
    if environment and environment.is_file():
        pieces.append(link("env", environment, output))
    if pieces:
        return " · ".join(pieces)
    return f'<span class="blocker">{html.escape(blocker or "Execution evidence pending")}</span>'


def source_cell(item: dict[str, Any], audit_path: pathlib.Path, output: pathlib.Path) -> str:
    label = f"{item['model_id']} {model_label(str(item['repo']))}"
    return link(label, audit_path, output, "model")


def empty_language_cell(
    item: dict[str, Any], locale: str, audit_path: pathlib.Path, output: pathlib.Path,
) -> str:
    declared = item.get("declared_languages")
    language = locale.split("-", 1)[0].lower()
    if isinstance(declared, list) and language not in {str(value).lower() for value in declared}:
        title = f"Not supported: {language} is absent from the publisher-declared language list"
        return (
            f'<a class="na" href="{rel_href(audit_path, output)}" '
            f'title="{html.escape(title)}">n/s</a>'
        )
    return '<span class="na">—</span>'


def newest_environment(model_dir: pathlib.Path) -> pathlib.Path | None:
    paths = sorted(model_dir.glob("environment*.json"), key=lambda path: path.stat().st_mtime)
    return paths[-1] if paths else None


def resolve_runner(
    fresh: pathlib.Path, model_dir: pathlib.Path, runtime: pathlib.Path,
    runner_name: str | None,
) -> pathlib.Path | None:
    if not runner_name:
        return None
    for candidate in (fresh / runner_name, model_dir / runner_name, runtime / runner_name):
        if candidate.is_file():
            return candidate
    return None


def build_asr_rows(
    inventory: list[dict[str, Any]], fresh: pathlib.Path, sources: pathlib.Path,
    output: pathlib.Path, blockers: dict[str, str], runtime: pathlib.Path,
) -> list[str]:
    result = []
    for item in (row for row in inventory if str(row["model_id"]).startswith("A")):
        model_id = item["model_id"]
        model_dir = fresh / model_id
        files = [path for path in (model_dir / "stream_records.jsonl", model_dir / "file_records.jsonl") if path.is_file()]
        if not files:
            files = [None]
        for records in files:
            rows = valid_rows(read_jsonl(records)) if records else []
            mode, streams = asr_mode_label(records.name, rows) if records else ("—", "—")
            cells = []
            audit_path = sources / model_id / "audit.json"
            for locale, _ in LANGUAGES:
                locale_rows = [row for row in rows if row.get("locale") == locale]
                cells.append(
                    wer_cell(locale_rows, records, output)
                    if locale_rows and records
                    else empty_language_cell(item, locale, audit_path, output)
                )
            runner_name = RUNNERS.get(model_id)
            if model_id in {"A07", "A09"} and records and records.name == "stream_records.jsonl":
                runner_name = "qwen_stream_run.py"
            runner = resolve_runner(fresh, model_dir, runtime, runner_name)
            environment = newest_environment(model_dir)
            evidence = evidence_links(model_id, records, runner, environment, output, blockers.get(model_id))
            license_label = item.get("license") or "not declared"
            columns = [
                source_cell(item, audit_path, output), html.escape(mode), html.escape(streams),
                html.escape(gpu_label(model_dir)), html.escape(str(license_label)), *cells, evidence,
            ]
            result.append("<tr>" + "".join(f"<td>{cell}</td>" for cell in columns) + "</tr>")
    return result


def build_tts_rows(
    inventory: list[dict[str, Any]], fresh: pathlib.Path, sources: pathlib.Path,
    output: pathlib.Path, blockers: dict[str, str], runtime: pathlib.Path,
    quality_ratings: dict[tuple[str, str, str], tuple[float, int]],
    ratings_path: pathlib.Path,
    grok_ratings: dict[tuple[str, str, str], tuple[float, int]],
    grok_ratings_path: pathlib.Path,
) -> list[str]:
    result = []
    for item in (row for row in inventory if str(row["model_id"]).startswith("T")):
        model_id = item["model_id"]
        model_dir = fresh / model_id
        records = model_dir / "records.jsonl"
        raw_rows = read_jsonl(records)
        smoke_rows = [row for row in raw_rows if row.get("phase") == "smoke"]
        rows = valid_rows(smoke_rows or raw_rows)
        modes = sorted({str(row.get("mode", "unspecified")) for row in rows}) or ["—"]
        for mode in modes:
            mode_rows = [row for row in rows if str(row.get("mode", "unspecified")) == mode] if rows else []
            cells = []
            audit_path = sources / model_id / "audit.json"
            for locale, _ in LANGUAGES:
                choices = [row for row in mode_rows if row.get("locale") == locale and row.get("ok")]
                smoke = [row for row in choices if row.get("phase") == "smoke"]
                record = (smoke or choices)[0] if choices else None
                audio = choose_audio(record, model_dir, mode) if record else None
                cells.append(
                    audio_cell(
                        record, audio, output,
                        [
                            ("u", quality_ratings.get((model_id, locale, mode)), ratings_path, "Owner overall score"),
                            ("g", grok_ratings.get((model_id, locale, mode)), grok_ratings_path, "Grok overall score"),
                        ],
                    )
                    if record and audio
                    else empty_language_cell(item, locale, audit_path, output)
                )
            runner_name = RUNNERS.get(model_id)
            runner = resolve_runner(fresh, model_dir, runtime, runner_name)
            environment = newest_environment(model_dir)
            evidence = evidence_links(
                model_id, records if records.is_file() else None, runner, environment,
                output, blockers.get(model_id),
            )
            license_label = item.get("license") or "not declared"
            streams = tts_stream_value(mode_rows) if mode_rows else "—"
            columns = [
                source_cell(item, audit_path, output), html.escape(mode), html.escape(streams),
                html.escape(gpu_label(model_dir)), html.escape(str(license_label)), *cells, evidence,
            ]
            result.append("<tr>" + "".join(f"<td>{cell}</td>" for cell in columns) + "</tr>")
    return result


def render_table(title: str, cell_note: str, rows: list[str]) -> str:
    language_headers = "".join(f'<th title="{html.escape(locale)}">{label}</th>' for locale, label in LANGUAGES)
    return f"""
<section>
  <h2>{html.escape(title)} <small>{html.escape(cell_note)}</small></h2>
  <table>
    <thead><tr><th>MODEL</th><th>MODE</th><th>STREAMS</th><th>HARDWARE</th><th>LICENCE</th>{language_headers}<th>EVIDENCE</th></tr></thead>
    <tbody>{''.join(rows)}</tbody>
  </table>
</section>"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fresh", type=pathlib.Path, default=pathlib.Path("execution/fresh_current"))
    parser.add_argument("--sources", type=pathlib.Path, default=pathlib.Path("execution/sources"))
    parser.add_argument("--inventory", type=pathlib.Path, default=pathlib.Path("execution/sources/inventory_audit.json"))
    parser.add_argument("--blockers", type=pathlib.Path, default=pathlib.Path("execution/report_blockers.json"))
    parser.add_argument("--ratings", type=pathlib.Path, default=pathlib.Path("execution/listening_ratings_current.json"))
    parser.add_argument("--grok-ratings", type=pathlib.Path, default=pathlib.Path("execution/grok_review.json"))
    parser.add_argument("--output", type=pathlib.Path, default=pathlib.Path("ONE_PAGE_REPORT.html"))
    args = parser.parse_args()
    root = pathlib.Path(__file__).resolve().parents[1]
    fresh = (root / args.fresh).resolve() if not args.fresh.is_absolute() else args.fresh.resolve()
    sources = (root / args.sources).resolve() if not args.sources.is_absolute() else args.sources.resolve()
    inventory_path = (root / args.inventory).resolve() if not args.inventory.is_absolute() else args.inventory.resolve()
    blockers_path = (root / args.blockers).resolve() if not args.blockers.is_absolute() else args.blockers.resolve()
    ratings_path = (root / args.ratings).resolve() if not args.ratings.is_absolute() else args.ratings.resolve()
    grok_ratings_path = (root / args.grok_ratings).resolve() if not args.grok_ratings.is_absolute() else args.grok_ratings.resolve()
    output = (root / args.output).resolve() if not args.output.is_absolute() else args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    inventory = read_json(inventory_path, [])
    if not isinstance(inventory, list) or not inventory:
        raise ValueError(f"Inventory is missing or empty: {inventory_path}")
    blockers_data = read_json(blockers_path, {}) or {}
    blockers = blockers_data.get("models", blockers_data) if isinstance(blockers_data, dict) else {}
    blockers = {str(key): str(value) for key, value in blockers.items()}

    asr_rows = build_asr_rows(inventory, fresh, sources, output, blockers, root / "benchmark_runtime")
    quality_ratings = load_quality_ratings(ratings_path)
    grok_ratings = load_grok_ratings(grok_ratings_path)
    tts_rows = build_tts_rows(
        inventory, fresh, sources, output, blockers, root / "benchmark_runtime",
        quality_ratings, ratings_path, grok_ratings, grok_ratings_path,
    )
    snapshot = read_json(fresh / "snapshot.json", {}) or {}
    timestamp = snapshot.get("snapshot_utc") or dt.datetime.now(dt.timezone.utc).isoformat()
    body = render_table("ASR", "cell = micro WER · n", asr_rows)
    body += render_table("TTS", "cell = ▶ · u owner / g Grok score 1–5 · TTFA seconds · RTF", tts_rows)
    document = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>On-prem Indic speech benchmark</title>
<style>
:root{{--ink:#172018;--muted:#667066;--rule:#ccd2cc;--head:#e9ede9;--good:#dcebdd;--warn:#f4e2bd;--bad:#efc5ba}}
*{{box-sizing:border-box}} body{{margin:12px;font:11px/1.16 ui-sans-serif,system-ui,-apple-system,sans-serif;color:var(--ink);background:#fff}}
h1{{font:700 18px/1.1 Georgia,serif;margin:0 0 2px}} .meta{{margin:0 0 7px;color:var(--muted)}}
section{{margin:0 0 9px}} h2{{font:700 14px/1.1 Georgia,serif;margin:0 0 3px}} h2 small{{font:500 9px/1 sans-serif;color:var(--muted)}}
table{{width:100%;border-collapse:collapse;table-layout:fixed}} th,td{{border:1px solid var(--rule);padding:2px 3px;vertical-align:middle;text-align:center;overflow-wrap:anywhere}}
th{{background:var(--head);font-size:8px;letter-spacing:.035em}} th:first-child,td:first-child{{width:15%;text-align:left}} th:nth-child(2),td:nth-child(2){{width:8%}} th:nth-child(3),td:nth-child(3){{width:4.5%}} th:nth-child(4),td:nth-child(4){{width:8%}} th:nth-child(5),td:nth-child(5){{width:6%}} th:last-child,td:last-child{{width:8%}}
a{{color:#184f33;text-decoration:none;border-bottom:1px solid #8eab9a}} a.model{{font-weight:700}} small{{display:block;font-size:7.5px;color:#4c574e;white-space:nowrap}}
.metric{{display:block;border:0;padding:1px;background:color-mix(in srgb,var(--good) calc(100% - var(--wer)*.75%),var(--bad) calc(var(--wer)*.75%));font-weight:700;color:#182219}}
.play{{border:1px solid #78917f;border-radius:3px;background:#edf3ee;color:#174a2f;cursor:pointer;padding:0 4px;font-weight:700}} .play.active{{background:#174a2f;color:#fff}}
.quality{{margin-left:2px;font-weight:700}}
.na{{color:#a2aaa3}} .blocker{{font-size:8px;color:#7b291b}} td:last-child{{font-size:8px}}
@page{{size:A3 landscape;margin:5mm}} @media print{{body{{margin:0;font-size:5.1pt;line-height:1.04}} h1{{font-size:9pt}} .meta{{margin-bottom:1.2mm}} h2{{font-size:7pt;margin-bottom:.6mm}} h2 small{{font-size:5pt}} section{{margin-bottom:1.4mm}} th,td{{padding:.22mm .4mm}} th{{font-size:5.2pt}} small{{font-size:4.8pt}} .play{{padding:0 .7mm}}}}
</style></head><body>
<h1>On-prem Indic speech benchmark</h1><p class="meta">Evidence snapshot {html.escape(str(timestamp))} · target locales: HI, EN-IN, BN, MR, TA, TE, GU, KN, ML, OR · click every number, source, code, environment, or audio control for its evidence.</p>
{body}
<audio id="player" preload="none"></audio>
<script>
const player=document.getElementById('player'); let active=null;
document.querySelectorAll('.play').forEach(button=>button.addEventListener('click',()=>{{
  if(active===button&&!player.paused){{player.pause();button.classList.remove('active');active=null;return;}}
  if(active)active.classList.remove('active'); active=button; button.classList.add('active'); player.src=button.dataset.audio; player.play();
}})); player.addEventListener('ended',()=>{{if(active)active.classList.remove('active');active=null;}});
</script></body></html>"""
    output.write_text(document)
    print(json.dumps({"output": str(output), "asr_rows": len(asr_rows), "tts_rows": len(tts_rows), "tables": document.count("<table>"), "audio_buttons": document.count('class="play"')}))


if __name__ == "__main__":
    main()
