"""Pinned full-output SNAC TTS baselines; never label these runs as streaming."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',HF_HOME='/workspace/hf_cache',HF_HUB_CACHE='/workspace/hf_cache/hub')
import argparse,datetime,hashlib,json,pathlib,shutil,time,traceback
import numpy as np,soundfile as sf,torch
torch.set_num_threads(4)
from transformers import AutoModelForCausalLM,AutoTokenizer
from snac import SNAC
ROOT=pathlib.Path('/workspace/speechbench_20260924')
MODELS={
'svara':('T01','kenpath/svara-tts-v1','db8a02fc1e4eab827ff6dda5bed3b56d4d2dd51e','/workspace/svara_tts_qual/model_cache/svara'),
'maya1':('T05','maya-research/maya1','21c682a0afef8c13a89b2512733c8bf5f0c52eb7','/workspace/hf_cache/models--maya-research--maya1/snapshots/21c682a0afef8c13a89b2512733c8bf5f0c52eb7'),
'veena':('T07','maya-research/Veena','8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f','/workspace/hf_cache/models--maya-research--Veena/snapshots/8b770f9e69e6b35ef320d4cd70a99a4ab6dd022f')}
TEXTS=[('en-IN','English','Your meeting with Priya is tomorrow at three thirty PM.'),
('hi-IN','Hindi','आपकी बैठक कल दोपहर तीन बजे है।'),('bn-IN','Bengali','আপনার মিটিং আগামীকাল দুপুর তিনটায়।'),
('mr-IN','Marathi','तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.'),('te-IN','Telugu','మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.'),
('ta-IN','Tamil','உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.'),('gu-IN','Gujarati','તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.'),
('kn-IN','Kannada','ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.'),('ml-IN','Malayalam','നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.')]

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while c:=f.read(8*1024*1024):h.update(c)
    return h.hexdigest()

def stage(source,target,pin):
    """Sequential local staging avoids network-filesystem mmap overhead."""
    target.mkdir(parents=True,exist_ok=True);manifest={}
    for p in sorted(source.iterdir()):
        if not p.is_file() or p.suffix not in ['.json','.safetensors','.model','.bin','.jinja']:continue
        dst=target/p.name
        h=hashlib.sha256()
        with p.open('rb') as src,dst.open('wb') as out:
            while c:=src.read(8*1024*1024):h.update(c);out.write(c)
        actual=h.hexdigest()
        meta=source/'.cache/huggingface/download'/(p.name+'.metadata')
        expected=None
        if meta.exists():
            lines=meta.read_text().splitlines()
            if lines[0]!=pin:raise ValueError('Source revision mismatch: '+p.name)
            if len(lines[1])==64:expected=lines[1]
        elif p.is_symlink() and len(p.resolve().name)==64:expected=p.resolve().name
        if expected and expected!=actual:raise ValueError('Source digest mismatch: '+p.name)
        manifest[p.name]={'sha256':actual,'bytes':dst.stat().st_size,'upstream_lfs_digest_verified':expected is not None}
        print('Staged',p.name,flush=True)
    return manifest

def decode(tokens,codec,kind):
    tokens=[t for t in tokens if 128266<=t<128266+7*4096]
    discarded=len(tokens)%7;tokens=tokens[:len(tokens)-discarded] if discarded else tokens
    if not tokens:raise ValueError('No complete codec frames')
    bands=[[],[],[]]
    for i in range(0,len(tokens),7):
        values=[tokens[i+j]-128266-j*4096 for j in range(7)]
        if any(v<0 or v>=4096 for v in values):raise ValueError('Invalid codec interleave')
        bands[0].append(values[0]);bands[1].extend([values[1],values[4]])
        bands[2].extend([values[2],values[3],values[5],values[6]])
    codes=[torch.tensor(x,dtype=torch.long,device='cuda').unsqueeze(0) for x in bands]
    with torch.inference_mode():audio=codec.decode(codes).detach().float().cpu().numpy().reshape(-1)
    if kind=='maya1' and len(audio)>2048:audio=audio[2048:]
    return audio,discarded

def main(kind):
    model_id,repo,pin,source=MODELS[kind];out=ROOT/model_id;out.mkdir(exist_ok=True)
    if model_id == 'T01':
        source=json.loads((ROOT/'T01_download.json').read_text())['path']
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    target=pathlib.Path('/tmp/benchmark_model_stage')/model_id
    manifest=stage(pathlib.Path(source),target,pin)
    env=dict(model=repo,revision=pin,run_id=stamp,files=manifest,precision='bfloat16',gpu=torch.cuda.get_device_name(0),torch=torch.__version__,runner_sha256=digest(__file__),mode='full_output',synthesis_class='C',hf_offline=True,network_namespace_isolated=False)
    codec_path=pathlib.Path(json.loads((ROOT/'SNAC_download.json').read_text())['path'])
    env['codec_revision']=codec_path.name;env['codec_sha256']=digest(codec_path/'pytorch_model.bin')
    (out/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    codec=SNAC.from_pretrained(str(codec_path)).to('cuda').eval()
    tokenizer=AutoTokenizer.from_pretrained(target,local_files_only=True)
    model=AutoModelForCausalLM.from_pretrained(target,torch_dtype=torch.bfloat16,local_files_only=True).to('cuda').eval()
    items=TEXTS if kind=='svara' else TEXTS[:2] if kind=='veena' else TEXTS[:1]
    for phase,sequence in [('warmup',[items[0]]*3),('smoke',items)]:
        for i,(locale,language,text) in enumerate(sequence):
            rec=dict(run_id=stamp,phase=phase,index=i,locale=locale,text=text,mode='full',synthesis_class='C',ok=False)
            try:
                torch.manual_seed(20260924);torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();start=time.perf_counter()
                if kind=='svara':
                    rec['voice']=language+' (Female)';prompt=rec['voice']+': '+text
                    ids=[128259]+tokenizer.encode(prompt)+[128009,128260];temperature=.7;top_p=.8;rep=1.1
                elif kind=='veena':
                    rec['voice']='kavya';ids=[128259]+tokenizer.encode('<spk_kavya> '+text,add_special_tokens=False)+[128260,128261,128257];temperature=.4;top_p=.9;rep=1.05
                else:
                    rec['voice']='described adult female; Indian-accent target, not guaranteed'
                    description='A clear adult female voice with an Indian English accent, speaking at a moderate pace.'
                    prompt=tokenizer.decode([128259])+(tokenizer.bos_token or '')+f'<description="{description}"> {text}'+tokenizer.decode([128009,128260,128261,128257])
                    ids=tokenizer.encode(prompt,add_special_tokens=False);temperature=.4;top_p=.9;rep=1.1
                inp=torch.tensor([ids],device='cuda');mask=torch.ones_like(inp)
                with torch.inference_mode():
                    generated=model.generate(input_ids=inp,attention_mask=mask,max_new_tokens=2048,do_sample=True,temperature=temperature,top_p=top_p,repetition_penalty=rep,eos_token_id=[128258,128262],pad_token_id=tokenizer.pad_token_id or 128258)
                tokens=generated[0,len(ids):].tolist()
                if len(tokens)>=2048:raise RuntimeError('Generation reached token limit; truncated output is not a successful clip')
                audio,discarded=decode(tokens,codec,kind);torch.cuda.synchronize();total=time.perf_counter()-start
                if len(audio)==0 or not np.isfinite(audio).all():raise ValueError('Invalid waveform')
                file=out/f'{stamp}-{phase}-{locale}-{i}.flac';sf.write(file,audio,24000,subtype='PCM_24')
                duration=len(audio)/24000
                rec.update(ok=True,sample_rate=24000,total_s=total,ttfa_s=total,audio_duration_s=duration,rtf=total/duration,
                           generated_tokens=len(tokens),hit_token_limit=len(tokens)>=2048,discarded_incomplete_codec_tokens=discarded,
                           peak_memory_bytes=torch.cuda.max_memory_allocated(),prequantization_out_of_range_samples=int(np.sum(np.abs(audio)>=1)),
                           file=str(file.relative_to(ROOT)),sha256=digest(file))
            except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
            with (out/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            print(json.dumps({k:rec.get(k) for k in ['phase','locale','ok','rtf','error']}),flush=True)
    (out/'DONE').write_text('Full-output smoke complete; streaming and full qualification pending.\n')
    shutil.rmtree(target)  # Only this runner's regenerable pod-local staging copy.

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('model',choices=list(MODELS));a=p.parse_args();main(a.model)
