"""Isolated additions over the retained Torch 2.6 inference environment."""
import pathlib,subprocess,os
root=pathlib.Path('/workspace/speechbench_20260924');env=root/'envs/voxcpm'
subprocess.run(['python3','-m','venv',str(env)],check=True)
sites=list((env/'lib').glob('python*/site-packages'))
base=list(pathlib.Path('/workspace/tts_streaming_suite/.venv_gpu/lib').glob('python*/site-packages'))
if len(sites)!=1 or len(base)!=1:raise ValueError('Ambiguous environment site-packages')
(sites[0]/'benchmark_base.pth').write_text(str(base[0])+'\n')
with (root/'voxcpm_install.log').open('wb') as log:
    subprocess.Popen([str(env/'bin/pip'),'install','voxcpm==2.0.3','torch==2.6.0','torchaudio==2.6.0','torchcodec==0.2.1',
        '--report',str(root/'envs/voxcpm_install.json'),'--no-cache-dir'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('Started isolated VoxCPM dependency installation')
