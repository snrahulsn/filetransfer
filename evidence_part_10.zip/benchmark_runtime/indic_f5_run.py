"""Strictly loaded IndicF5 eager full-output baseline with publisher demo reference."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',HF_HOME='/workspace/hf_cache',HF_HUB_CACHE='/workspace/hf_cache/hub')
import datetime,io,json,pathlib,shutil,time,traceback
import numpy as np,soundfile as sf,torch
from safetensors.torch import load_file
from pydub import AudioSegment,silence
from f5_tts.infer.utils_infer import load_model,load_vocoder,preprocess_ref_audio_text,infer_process
from f5_tts.model import DiT
from snac_run import TEXTS,stage,digest
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'T08';OUT.mkdir(exist_ok=True)
PIN='ba85abedf18dc479a447eaa0eccbd76ab78a47d5'
torch.set_num_threads(4)
def main():
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    source=pathlib.Path(json.loads((ROOT/'T08-source_download.json').read_text())['path'])
    target=pathlib.Path('/tmp/benchmark_model_stage/T08')
    weights=stage(pathlib.Path('/workspace/indic_f5_qual/model_cache/IndicF5'),target,PIN)
    vocoder_path=pathlib.Path('/workspace/hf_cache/hub/models--charactr--vocos-mel-24khz/snapshots/0feb3fdd929bcd6649e0e7c5a688cf7dd012ef21')
    vocoder=load_vocoder(vocoder_name='vocos',is_local=True,local_path=str(vocoder_path),device='cuda')
    model=load_model(DiT,dict(dim=1024,depth=22,heads=16,ff_mult=2,text_dim=512,conv_layers=4),mel_spec_type='vocos',vocab_file=str(source/'checkpoints/vocab.txt'),device='cuda')
    raw=load_file(target/'model.safetensors',device='cpu');ema={};voc={};extra=[]
    for key,value in raw.items():
        key=key.replace('_orig_mod.','')
        if key.startswith('ema_model.'):ema[key[len('ema_model.'):]]=value
        elif key.startswith('vocoder.'):voc[key[len('vocoder.'):]]=value
        else:extra.append(key)
    if extra or not ema or not voc:raise ValueError('Unexpected or missing checkpoint groups: '+repr(extra))
    model.load_state_dict(ema,strict=True);vocoder.load_state_dict(voc,strict=True)
    model.eval();vocoder.eval();del raw,ema,voc
    ref=source/'prompts/PAN_F_HAPPY_00001.wav'
    reftext='ਭਹੰਪੀ ਵਿੱਚ ਸਮਾਰਕਾਂ ਦੇ ਭਵਨ ਨਿਰਮਾਣ ਕਲਾ ਦੇ ਵੇਰਵੇ ਗੁੰਝਲਦਾਰ ਅਤੇ ਹੈਰਾਨ ਕਰਨ ਵਾਲੇ ਹਨ, ਜੋ ਮੈਨੂੰ ਖੁਸ਼ ਕਰਦੇ  ਹਨ।'
    env=dict(run_id=stamp,model='ai4bharat/IndicF5',revision=PIN,files=weights,runner_sha256=digest(__file__),torch=torch.__version__,gpu=torch.cuda.get_device_name(0),
        precision=str(next(model.parameters()).dtype),backend='installed f5_tts eager; compiled checkpoint names unwrapped; strict=True',
        reference_source='publisher-bundled demonstration prompt',reference_sha256=digest(ref),reference_text=reftext,individual_speaker_consent_independently_verified=False,
        vocab_sha256=digest(source/'checkpoints/vocab.txt'),vocoder_revision=vocoder_path.name,reference_preprocessing_in_timed_scope=False,
        nfe_step=32,cfg_strength=2.0,speed=1.0,hf_offline=True,network_namespace_isolated=False)
    (OUT/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2,ensure_ascii=False),encoding='utf-8')
    ref_audio,ref_text=preprocess_ref_audio_text(str(ref),reftext,show_info=lambda *a:None,device='cuda')
    items=[x for x in TEXTS if x[0]!='en-IN']+[('or-IN','Odia','ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।')]
    for i,(locale,language,text) in enumerate([items[0]]*3+items):
        rec=dict(run_id=stamp,locale=locale,text=text,phase='warmup' if i<3 else 'smoke',mode='full',synthesis_class='C',voice='publisher PAN_F_HAPPY_00001 reference',ok=False)
        try:
            torch.manual_seed(20260924);torch.cuda.synchronize();start=time.perf_counter()
            with torch.inference_mode():audio,sr,_=infer_process(ref_audio,ref_text,text,model,vocoder,nfe_step=32,cfg_strength=2.0,speed=1.0,device='cuda',show_info=lambda *a:None,progress=None)
            buffer=io.BytesIO();sf.write(buffer,audio,sr,format='WAV');buffer.seek(0)
            segment=AudioSegment.from_file(buffer,format='wav')
            pieces=silence.split_on_silence(segment,min_silence_len=1000,silence_thresh=-50,keep_silence=500,seek_step=10)
            segment=sum(pieces,AudioSegment.silent(duration=0))
            if not len(segment) or not np.isfinite(segment.dBFS):raise ValueError('Silent/invalid output')
            segment=segment.apply_gain(-20.0-segment.dBFS)
            audio=np.asarray(segment.get_array_of_samples(),dtype=np.float32)/(2**(8*segment.sample_width-1))
            torch.cuda.synchronize();elapsed=time.perf_counter()-start
            rec.update(ok=True,sample_rate=sr,ttfa_s=elapsed,total_s=elapsed,audio_duration_s=len(audio)/sr,rtf=elapsed/(len(audio)/sr))
            if i>=3:
                file=OUT/f'{stamp}-{locale}.flac';sf.write(file,audio,sr,subtype='PCM_24');rec.update(file=str(file.relative_to(ROOT)),sha256=digest(file))
        except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (OUT/'records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        print(json.dumps({k:rec.get(k) for k in ['locale','phase','ok','rtf','error']}),flush=True)
    (OUT/'DONE').write_text('Nine supported target locales attempted; full-output smoke only.\n');shutil.rmtree(target)
if __name__=='__main__':main()
