"""One GPU benchmark process at a time, with explicit subprocess outcomes."""
import datetime,json,os,pathlib,subprocess,time
ROOT=pathlib.Path('/workspace/speechbench_20260924')
PY='/workspace/tts_streaming_suite/.venv_gpu/bin/python'
ENV=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',USE_TF='0',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
JOBS=[
 ('A01-stream',[PY,'-X','utf8',str(ROOT/'sravaani_run_stage.py')],dict(ASR_STAGE='stream'),1200),
 ('T18',[PY,'-X','utf8',str(ROOT/'mms_tts_run.py')],{},900),
 ('T03',[PY,'-X','utf8',str(ROOT/'kokoro_run.py')],{},900),
 ('T07',[PY,'-X','utf8',str(ROOT/'snac_run.py'),'veena'],{},1200),
 ('T05',[PY,'-X','utf8',str(ROOT/'snac_run.py'),'maya1'],{},1200),
 ('T01',[PY,'-X','utf8',str(ROOT/'snac_run.py'),'svara'],{},1800),
]
def main():
    for name,cmd,extra,limit in JOBS:
        rec=dict(job=name,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeout_s=limit,command=cmd)
        with (ROOT/(name+'-queue.log')).open('ab') as log:
            try:
                proc=subprocess.run(cmd,env=dict(ENV,**extra),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=limit)
                rec.update(exit_code=proc.returncode,timed_out=False)
            except subprocess.TimeoutExpired:rec.update(exit_code=None,timed_out=True)
        rec['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (ROOT/'queue_outcomes.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
        print(json.dumps(rec),flush=True)
if __name__=='__main__':main()
