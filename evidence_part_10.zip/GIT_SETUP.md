# Git and GitHub setup

This machine is authenticated to GitHub through GitHub CLI and the macOS
keychain. Do not copy tokens, keychain files, or credentials between projects
or machines.

## Verified account details

- GitHub account: `snrahulsn`
- Git protocol: HTTPS
- Commit author: `Rahul Natarajan`
- Commit email: `rahulnatarajan@users.noreply.github.com`
- Credential helper on this Mac: `osxkeychain`
- Benchmark repository: `https://github.com/snrahulsn/tts_asr_onprem_benchmarking.git`
- Default branch: `main`

## One-time setup on another machine

Install GitHub CLI, then authenticate in the browser:

```bash
gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git
git config --global user.name "Rahul Natarajan"
git config --global user.email "rahulnatarajan@users.noreply.github.com"
```

Verify the setup without exposing credentials:

```bash
gh auth status
git config --global --get user.name
git config --global --get user.email
```

## Commit an existing local project

From the project directory:

```bash
git init -b main
git add .
git commit -m "Initial commit"
gh repo create snrahulsn/REPOSITORY_NAME --private --source=. --remote=origin --push
```

Before `git add .`, add secret and generated files to `.gitignore`. Check the
staged files before committing:

```bash
git status --short
git diff --cached --stat
git diff --cached
```

## Connect a project to an existing repository

```bash
git remote add origin https://github.com/snrahulsn/REPOSITORY_NAME.git
git branch -M main
git push -u origin main
```

If `origin` already exists:

```bash
git remote set-url origin https://github.com/snrahulsn/REPOSITORY_NAME.git
git push -u origin main
```

## Clone this benchmark repository

```bash
gh repo clone snrahulsn/tts_asr_onprem_benchmarking
```

GitHub CLI retrieves authentication from the operating-system credential
store. No access token belongs in a repository, shell script, `.env` file, or
this setup file.
