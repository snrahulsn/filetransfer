"""Serve an assembled blind listening test on this machine only."""
from __future__ import annotations

import argparse
import functools
import http.server
import pathlib


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("assembled", nargs="?", type=pathlib.Path, default=pathlib.Path("ASSEMBLED"))
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    root = args.assembled.resolve()
    page = root / "LISTENING_REVIEW" / "index.html"
    if not page.is_file():
        parser.error(f"Blind test not found: {page}. Assemble the evidence ZIPs first.")
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(root))
    server = http.server.ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    print(f"Open http://127.0.0.1:{args.port}/LISTENING_REVIEW/index.html", flush=True)
    print("Press Ctrl+C to stop the local server.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
