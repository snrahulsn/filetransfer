"""Assemble the shareable ZIP parts and verify every extracted evidence file."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import shutil
import stat
import zipfile


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_relative(name: str) -> pathlib.PurePosixPath:
    path = pathlib.PurePosixPath(name)
    if path.is_absolute() or not path.parts or any(part in ("", ".", "..") for part in path.parts):
        raise ValueError(f"Unsafe archive path: {name!r}")
    return path


def assemble(pack: pathlib.Path, output: pathlib.Path) -> dict:
    manifest = json.loads((pack / "MASTER_MANIFEST.json").read_text())
    expected = {row["path"]: row for row in manifest["files"]}
    if len(expected) != len(manifest["files"]):
        raise ValueError("Duplicate evidence path in manifest")
    for row in manifest.get("direct_files", []):
        direct = pack / row["path"]
        if direct.stat().st_size != row["bytes"] or sha256(direct) != row["sha256"]:
            raise ValueError(f"Direct handoff file hash or size mismatch: {row['path']}")
    for part in manifest["parts"]:
        archive = pack / part["name"]
        if archive.stat().st_size != part["bytes"] or sha256(archive) != part["sha256"]:
            raise ValueError(f"ZIP hash or size mismatch: {archive}")
    if output.exists():
        raise FileExistsError(f"Output already exists: {output}; choose a new folder to preserve it")
    staging = output.with_name(output.name + ".building")
    if staging.exists():
        raise FileExistsError(f"Previous assembly staging folder exists: {staging}")
    staging.mkdir(parents=True)
    extracted = set()
    try:
        for part in manifest["parts"]:
            with zipfile.ZipFile(pack / part["name"]) as archive:
                if archive.testzip() is not None:
                    raise ValueError(f"ZIP CRC failure: {part['name']}")
                for info in archive.infolist():
                    if info.is_dir():
                        continue
                    rel = safe_relative(info.filename)
                    name = rel.as_posix()
                    if name not in expected or expected[name]["part"] != part["name"] or name in extracted:
                        raise ValueError(f"Unexpected or duplicate ZIP member: {name}")
                    if stat.S_IFMT(info.external_attr >> 16) == stat.S_IFLNK:
                        raise ValueError(f"Symlink in ZIP: {name}")
                    target = staging.joinpath(*rel.parts)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(info) as source, target.open("wb") as destination:
                        shutil.copyfileobj(source, destination)
                    row = expected[name]
                    if target.stat().st_size != row["bytes"] or sha256(target) != row["sha256"]:
                        raise ValueError(f"Evidence hash or size mismatch: {name}")
                    extracted.add(name)
        if extracted != set(expected):
            raise ValueError(f"Missing {len(set(expected) - extracted)} evidence files")
        required = ("BENCHMARK_REPORT.html", "BENCHMARK_REPORT.pdf", "LISTENING_REVIEW/index.html",
                    "LISTENING_REVIEW/blind_key.json", "benchmark_runtime/final_two_table_report.py",
                    "benchmark_runtime/import_ratings.py", "Makefile")
        missing = [name for name in required if not (staging / name).is_file()]
        if missing:
            raise ValueError(f"Missing required handoff files: {missing}")
        staging.rename(output)
    except Exception:
        shutil.rmtree(staging)
        raise
    return {"output": str(output), "parts": len(manifest["parts"]), "verified_files": len(extracted),
            "report": str(output / "BENCHMARK_REPORT.html"),
            "blind_test": str(output / "LISTENING_REVIEW/index.html")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("pack", nargs="?", type=pathlib.Path, default=pathlib.Path("."))
    parser.add_argument("output", nargs="?", type=pathlib.Path, default=pathlib.Path("ASSEMBLED"))
    args = parser.parse_args()
    print(json.dumps(assemble(args.pack.resolve(), args.output.resolve()), indent=2))
