# On-prem Indic ASR and TTS benchmark

This repository contains the code, raw measurements, exact audio evidence, publisher metadata, licence texts, review data, and generated report for 15 ASR and 19 TTS models across Hindi, Indian English, Bengali, Marathi, Tamil, Telugu, Gujarati, Kannada, Malayalam, and Odia.

## Current report

- `BENCHMARK_REPORT.html` is the interactive report.
- `BENCHMARK_REPORT.pdf` is the one-page A3 landscape export.
- The report has exactly two dense tables: ASR and TTS. Each has one row per model, one Streaming value, a CPU/GPU deployment category, licence, and direct evidence links.
- ASR values are frozen-corpus micro-WER from 10 clips per supported locale.
- TTS cells play exact waveforms; use `LISTENING_REVIEW/` to give one 1-5 score per anonymous clip. Grok ratings are excluded.

## Reproduce the report

Requirements:

- Python 3.11 or newer
- Python package `playwright`
- Google Chrome or Chromium for PDF export
- Poppler `pdfinfo` for PDF validation

Run:

```bash
make report
```

This regenerates the HTML, exports the PDF with headless Chrome, and writes `execution/final_report_validation.json`.

To validate without rebuilding:

```bash
make validate
```

To build the portable evidence pack in independently shareable ZIP files below 20 MB:

```bash
make pack
```

To serve the report locally:

```bash
make serve
```

Then open `http://127.0.0.1:8000/BENCHMARK_REPORT.html`.

## Evidence layout

- `execution/fresh_current/`: raw inference records, environments, logs, and generated waveforms.
- `execution/sources/`: pinned publisher metadata, licences, revisions, and captured runtime source.
- `execution/dataset_sources/`: evaluation-dataset provenance.
- `LISTENING_REVIEW/`: 105 anonymous clips, one for each playable TTS model-language cell, and the single-score review interface (`make blind` rebuilds it).
- `benchmark_runtime/`: inference runners, report generator, validators, and pack builder.
- `execution/primary_configuration_ledger.json`: the configuration selected independently of quality results.
- `execution/metadata_corrections.json`: corrected licences, checkpoint mappings, and adapter provenance.
- `execution/final_shutdown_verification.json`: last RunPod terminal-state audit.

`SHARE_EVIDENCE_PACK_FINAL/` is the standalone handoff. Its `README.md` gives exact assembly, verification, blind-test, rating-import, and rebuild commands. Every ZIP part is below 20 MB and the manifest hashes every included file. The `.gitignore` excludes local Python environments, downloaded Hugging Face cache files, temporary PDF renders, and duplicate raw archives.
