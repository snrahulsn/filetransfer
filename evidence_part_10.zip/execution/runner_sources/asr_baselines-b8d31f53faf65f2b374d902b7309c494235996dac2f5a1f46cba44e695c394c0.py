"""Pinned full-utterance ASR baselines; never report these as streaming."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import argparse,datetime,hashlib,json,pathlib,time,traceback,resource
import numpy as np,torch
from asr_corpus import records,REGIONAL
from metrics import score
from stage_model import stage
ROOT=pathlib.Path('/workspace/speechbench_20260924')
LANG={'hi-IN':'Hindi','en-IN':'English','bn-IN':'Bengali','mr-IN':'Marathi','ta-IN':'Tamil','te-IN':'Telugu','gu-IN':'Gujarati','kn-IN':'Kannada','ml-IN':'Malayalam','or-IN':'Odia'}
CODES=dict(zip(['en-IN','hi-IN','bn-IN','mr-IN','ta-IN','te-IN','gu-IN','kn-IN','ml-IN','or-IN'],['eng','hin','ben','mar','tam','tel','guj','kan','mal','ory']))
torch.set_num_threads(4)
def main(args):
    requested_limit=args.limit
    # Breadth-first coverage before the separately queued complete-split jobs.
    if args.limit is not None:args.limit=min(args.limit,int(os.environ.get('COVERAGE_LIMIT','3')))
    out=ROOT/args.model;out.mkdir(exist_ok=True)
    manifest=json.loads((ROOT/(args.model+'_download.json')).read_text());path=pathlib.Path(manifest['path'])
    path,weights=stage(path,args.model)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    decoder=args.decoder if args.model=='A04' else {'A03':'tdt','A15':'ctc'}.get(args.model,'autoregressive')
    env=dict(run_id=stamp,model=manifest['repo'],revision=manifest['revision'],torch=torch.__version__,gpu=torch.cuda.get_device_name(0),
        mode='full_utterance',precision='bfloat16' if args.model in ['A07','A09'] else 'float32' if args.model in ['A03','A04','A15'] else 'float16',
        runner_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),hf_offline=True,network_namespace_isolated=False,
        evaluation_limit_per_locale=args.limit,requested_limit_per_locale=requested_limit,condition=args.condition,staged_files=weights,decoder=decoder,
        warmup_scope='three calls on the first locale only',timing_scope='coverage-run preprocessing/adaptation/inference; not a steady-state latency qualification')
    (out/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    initialization_start=time.perf_counter()
    if args.model=='A04':
        import importlib.util
        import onnxruntime as ort
        spec=importlib.util.spec_from_file_location('audited_indic_conformer',path/'model_onnx.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        # The publisher creates 28 sessions; bound each CPU fallback pool on this host.
        original_session=ort.InferenceSession
        def bounded_session(*session_args,**session_kwargs):
            options=ort.SessionOptions();options.intra_op_num_threads=4;options.inter_op_num_threads=1
            options.add_session_config_entry('session.intra_op.allow_spinning','0')
            options.add_session_config_entry('session.inter_op.allow_spinning','0')
            session_kwargs['sess_options']=options
            return original_session(*session_args,**session_kwargs)
        ort.InferenceSession=bounded_session
        try:model=module.IndicASRModel(module.IndicASRConfig(ts_folder=str(path)))
        finally:ort.InferenceSession=original_session
        env['onnx_session_options']=dict(intra_op_num_threads=4,inter_op_num_threads=1,allow_spinning=False)
        env['onnx_providers']={k:v.get_providers() for k,v in model.models.items() if hasattr(v,'get_providers')}
        (out/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
        if any('CUDAExecutionProvider' not in v for v in env['onnx_providers'].values()):raise RuntimeError('ONNX CUDA provider unavailable; do not report CPU fallback as GPU timing')
        locales=REGIONAL
        def infer(audio,locale):return model(torch.from_numpy(audio).unsqueeze(0),locale[:2],args.decoder)
    elif args.model=='A03':
        from transformers import AutoModel
        model=AutoModel.from_pretrained(path,torch_dtype=torch.float32,trust_remote_code=True,local_files_only=True).to('cuda').eval()
        locales=REGIONAL+['en-IN']
        def infer(audio,locale):return model.transcribe([audio])[0]
    elif args.model in ['A07','A09']:
        from qwen_asr import Qwen3ASRModel
        model=Qwen3ASRModel.from_pretrained(str(path),dtype=torch.bfloat16,device_map='cuda:0',max_inference_batch_size=1,max_new_tokens=1024)
        locales=['hi-IN','en-IN']
        def infer(audio,locale):return model.transcribe(audio=(audio,16000),language=LANG[locale])[0].text
    elif args.model in ['A08','A10']:
        from transformers import AutoProcessor,AutoModelForSpeechSeq2Seq
        processor=AutoProcessor.from_pretrained(path,local_files_only=True)
        model=AutoModelForSpeechSeq2Seq.from_pretrained(path,torch_dtype=torch.float16,local_files_only=True).to('cuda').eval()
        locales=[x for x in REGIONAL+['en-IN'] if x!='or-IN']
        def infer(audio,locale):
            inputs=processor(audio,sampling_rate=16000,return_tensors='pt',truncation=False,padding='longest',return_attention_mask=True)
            features=inputs.input_features.to('cuda',dtype=torch.float16)
            if features.shape[-1]<3000:features=torch.nn.functional.pad(features,(0,3000-features.shape[-1]))
            ids=model.generate(input_features=features,attention_mask=inputs.attention_mask.to('cuda'),language=locale[:2],task='transcribe',return_timestamps=True,max_new_tokens=None,max_length=int(model.config.max_target_positions))
            return processor.batch_decode(ids,skip_special_tokens=True)[0]
    else:
        from transformers import AutoProcessor,Wav2Vec2ForCTC
        processor=AutoProcessor.from_pretrained(path,local_files_only=True)
        model=Wav2Vec2ForCTC.from_pretrained(path,local_files_only=True).to('cuda').eval()
        locales=REGIONAL+['en-IN'];current=[None]
        def infer(audio,locale):
            if current[0]!=locale:
                processor.tokenizer.set_target_lang(CODES[locale]);model.load_adapter(CODES[locale],local_files_only=True);current[0]=locale
            inputs=processor(audio,sampling_rate=16000,return_tensors='pt').to('cuda')
            ids=model(**inputs).logits.argmax(dim=-1)
            return processor.batch_decode(ids)[0]
    torch.cuda.synchronize()
    env.update(model_initialization_s=time.perf_counter()-initialization_start,
        initialization_scope='after verified staging through imports and model construction; excludes warmups; not host cold boot',
        memory_scope='Torch allocator excludes ONNX and driver allocations; process RSS high-water includes loading and all prior trials',
        resident_torch_allocated_bytes=torch.cuda.memory_allocated(),resident_torch_reserved_bytes=torch.cuda.memory_reserved())
    if args.model in ['A08','A10']:env['generation_length_config']=dict(max_length=int(model.config.max_target_positions),max_new_tokens=None,includes_decoder_start_tokens=True)
    (out/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    completed=set()
    file=out/'file_records.jsonl'
    if file.exists():
        for line in file.read_text(encoding='utf-8').splitlines():
            r=json.loads(line)
            if r.get('ok'):completed.add((r['id'],r['condition'],r.get('decoder',decoder)))
    warmed=False
    for locale in locales:
        if not warmed:
            first=next(records([locale],limit=1,condition=args.condition))
            for i in range(3):
                with torch.inference_mode():infer(first['audio'],locale)
            warmed=True
        for row in records([locale],limit=args.limit,condition=args.condition):
            if (row['id'],row['condition'],decoder) in completed:continue
            rec={k:v for k,v in row.items() if k!='audio'}
            rec.update(run_id=stamp,mode='full_utterance',decoder=decoder,phase='coverage_sweep' if args.limit else 'accuracy_full_split',ok=False)
            try:
                torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
                with torch.inference_mode():hyp=infer(row['audio'],locale)
                torch.cuda.synchronize();elapsed=time.perf_counter()-start
                rec.update(ok=True,hypothesis=hyp,total_s=elapsed,audio_duration_s=len(row['audio'])/16000,rtf=elapsed/(len(row['audio'])/16000),
                    peak_torch_allocated_bytes=torch.cuda.max_memory_allocated(),peak_torch_reserved_bytes=torch.cuda.max_memory_reserved(),
                    process_lifetime_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,**score(row['reference'],hyp))
            except Exception as e:rec.update(hypothesis='',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),**score(row['reference'],''))
            with file.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            if row['index']%10==0 or not rec['ok']:print(json.dumps({k:rec.get(k) for k in ['id','ok','wer','rtf','error']}),flush=True)
    (out/f'DONE-{stamp}').write_text(json.dumps(vars(args)))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('model',choices=['A03','A04','A07','A09','A08','A10','A15']);p.add_argument('--limit',type=int);p.add_argument('--decoder',default='ctc',choices=['ctc','rnnt']);p.add_argument('--condition',default='clean',choices=['clean','g711_mulaw','g711_alaw']);main(p.parse_args())
