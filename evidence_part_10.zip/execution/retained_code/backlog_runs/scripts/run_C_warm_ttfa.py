#!/usr/bin/env python3
"""C re-run: warm model first, then p50 over several sequential TTFAs; keep N=2/N=4; document cold vs warm."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]
import numpy as np, torch, soundfile as sf
from transformers import AutoModel
OUT = Path("/workspace/backlog_runs/pack_C_sravaani_stream_warm")
OUT.mkdir(parents=True, exist_ok=True)
MODEL_ID = "ARTPARK-IISc/SraVaani-0.5-live"

def find_clip():
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
    for p in sorted(cache.rglob("*.wav")):
        return p
    sr=16000; t=np.linspace(0,2.0,sr*2,endpoint=False)
    wav=(0.1*np.sin(2*np.pi*220*t)).astype(np.float32)
    path=OUT/"fallback_tone.wav"; sf.write(path,wav,sr); return path

def stream_once(model, wav_path):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim>1: audio=audio.mean(axis=1)
    if sr!=16000:
        import librosa; audio=librosa.resample(audio, orig_sr=sr, target_sr=16000); sr=16000
    t0=time.perf_counter(); ttfa=None; partials=[]; final=None
    if hasattr(model,"new_stream") and hasattr(model,"stream_audio"):
        state=model.new_stream(); block=int(0.25*16000)
        for i in range(0,len(audio),block):
            text=model.stream_audio(state, audio[i:i+block])
            now=time.perf_counter()-t0
            if text and ttfa is None: ttfa=now
            if text: partials.append({"t":now,"text":text})
        if hasattr(model,"finish_stream"): final=model.finish_stream(state)
        elif partials: final=partials[-1]["text"]
        kind="new_stream/stream_audio"
    else:
        # fallback
        out=model.transcribe(audio) if hasattr(model,"transcribe") else None
        ttfa=time.perf_counter()-t0; final=out; kind="batch_fallback"
    return {"ttfa":ttfa,"partials":len(partials),"final":final,"kind":kind,"wall":time.perf_counter()-t0}

def main():
    clip=find_clip(); gpu=nvidia_info()
    print("loading", MODEL_ID, "clip", clip, flush=True)
    t_load=time.perf_counter()
    model=AutoModel.from_pretrained(MODEL_ID, trust_remote_code=True)
    if hasattr(model,"cuda"): model=model.cuda()
    load_s=time.perf_counter()-t_load
    # COLD first sequential (1)
    cold=stream_once(model, clip)
    # WARM: discard 1 warm-up then N sequential
    _=stream_once(model, clip)  # warm-up discard
    warm_runs=[]
    for i in range(8):
        warm_runs.append(stream_once(model, clip))
    warm_ttfas=[r["ttfa"] for r in warm_runs if r["ttfa"] is not None]
    # concurrent N=2 / N=4 on warm model
    def one(_): return stream_once(model, clip)["ttfa"]
    with ThreadPoolExecutor(2) as ex:
        n2=list(ex.map(one, range(2)))
    with ThreadPoolExecutor(4) as ex:
        n4=list(ex.map(one, range(4)))
    summary={
        "when": ist_now(), "gpu": gpu, "model": MODEL_ID, "load_s": load_s,
        "cold": cold,
        "warm_sequential": {"n": len(warm_ttfas), "ttfas": warm_ttfas, "summary": summarize_ttfas(warm_ttfas)},
        "n2": {"ttfas": n2, "summary": summarize_ttfas(n2)},
        "n4": {"ttfas": n4, "summary": summarize_ttfas(n4)},
        "note": "Cold = first inference after load. Warm = after 1 discarded warm-up; p50 over 8 sequential.",
    }
    write_json(OUT/"results.json", summary)
    md=[f"# SraVaani-0.5-live WARM TTFA re-run\n",
        f"**When:** {summary['when']}\n**GPU:** {gpu}\n**Load_s:** {load_s:.2f}\n",
        f"**Cold TTFA:** {cold.get('ttfa')}\n",
        f"**Warm sequential p50 (n={len(warm_ttfas)}):** {summary['warm_sequential']['summary']}\n",
        f"**N=2:** {summary['n2']}\n**N=4:** {summary['n4']}\n"]
    (OUT/"SUMMARY.md").write_text("\n".join(map(str,md)))
    write_json(OUT/"DONE.json", {"ok": True, "warm_p50": summary['warm_sequential']['summary'].get('p50') if summary['warm_sequential']['summary'] else None, "cold_ttfa": cold.get('ttfa')})
    print("DONE", summary['warm_sequential']['summary'], flush=True)

if __name__=="__main__":
    try: main()
    except Exception:
        traceback.print_exc()
        Path("/workspace/backlog_runs/pack_C_sravaani_stream_warm").mkdir(parents=True, exist_ok=True)
        write_json(Path("/workspace/backlog_runs/pack_C_sravaani_stream_warm")/"DONE.json", {"ok": False, "error": traceback.format_exc()})
        raise
