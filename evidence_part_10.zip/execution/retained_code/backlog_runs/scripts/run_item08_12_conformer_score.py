#!/usr/bin/env python3
"""Item 8 Kokoro WER + Item 12 IndicConformer tie-score across vendors."""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]
os.environ["OMP_NUM_THREADS"] = "1"

import numpy as np
import torch
import soundfile as sf
import jiwer
from transformers import AutoModel

ASR_ID = "ai4bharat/indic-conformer-600m-multilingual"

# Conformer supported-ish short codes
LANG_MAP = {
    "as": "as", "as-IN": "as", "bn": "bn", "bn-IN": "bn",
    "gu": "gu", "gu-IN": "gu", "hi": "hi", "hi-IN": "hi",
    "kn": "kn", "kn-IN": "kn", "ml": "ml", "ml-IN": "ml",
    "mr": "mr", "mr-IN": "mr", "or": "or", "or-IN": "or",
    "pa": "pa", "pa-IN": "pa", "ta": "ta", "ta-IN": "ta",
    "te": "te", "te-IN": "te", "en": "en", "en-IN": "en", "en-US": "en",
}

def norm(t):
    return re.sub(r"\s+", " ", (t or "").strip())

def load_wav16k(path):
    audio, sr = sf.read(str(path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    return audio.astype(np.float32)

def transcribe(model, wav_path, lang):
    audio = load_wav16k(wav_path)
    tensor = torch.from_numpy(audio).float().unsqueeze(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    with torch.inference_mode():
        out = model(tensor.to(device), lang, "ctc")
    if isinstance(out, (list, tuple)):
        return str(out[0])
    if isinstance(out, dict):
        return str(out.get("text") or out.get("transcription") or out)
    return str(out)

def score_one(model, wav, ref, lang, vendor, meta=None):
    conf_lang = LANG_MAP.get(lang) or LANG_MAP.get(lang.replace("_", "-")) or lang.split("-")[0].lower()
    # Skip English for Conformer if unsupported - still try 'en'
    rec = {"vendor": vendor, "wav": str(wav), "lang": lang, "conformer_lang": conf_lang,
           "reference": ref, "meta": meta or {}}
    try:
        hyp = transcribe(model, wav, conf_lang)
        rec["hypothesis"] = hyp
        rec["wer"] = float(jiwer.wer(norm(ref), norm(hyp))) if ref and hyp is not None else None
        rec["cer"] = float(jiwer.cer(norm(ref), norm(hyp))) if ref and hyp is not None else None
        rec["ok"] = True
    except Exception as e:
        rec["ok"] = False
        rec["error"] = f"{type(e).__name__}: {e}"
    return rec

def collect_kokoro():
    root = Path("/workspace/kokoro_hindi_english_probe")
    res = json.loads((root / "results.json").read_text(encoding="utf-8"))
    items = []
    for it in res.get("items", []):
        # Kokoro probe is English orthography; Conformer may not fit well for en
        # Score English with lang=en; note Whisper prior if any
        lang = "en"  # orthography is English
        items.append({
            "wav": it["path"] if Path(it["path"]).exists() else str(root / "wavs" / Path(it["path"]).name),
            "ref": it["text"],
            "lang": lang,
            "meta": {"kokoro_lang_code": it.get("lang_code"), "voice": it.get("voice"), "index": it.get("index")},
        })
    return items

def load_whisper_prior(vendor_dir):
    p = Path(vendor_dir) / "asr_metrics.json"
    if not p.exists():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    out = {}
    for r in data.get("results", []):
        loc = r.get("locale") or r.get("lang")
        out[loc] = {"whisper_wer": r.get("WER"), "whisper_cer": r.get("CER"),
                    "whisper_transcript": r.get("transcript"), "reference": r.get("reference")}
    return out

def collect_vendor(name, wav_dir, asr_dir=None):
    wav_dir = Path(wav_dir)
    priors = load_whisper_prior(asr_dir or wav_dir.parent)
    items = []
    # Prefer asr_metrics references
    if priors:
        for loc, meta in priors.items():
            # find wav
            cands = list(wav_dir.glob(f"{loc}*.wav")) + list(wav_dir.glob(f"{loc.split('-')[0]}*.wav"))
            # bodhan uses hi.wav etc
            short = loc.split("-")[0]
            cands += list(wav_dir.glob(f"{short}.wav")) + list(wav_dir.glob(f"{loc}.wav"))
            wav = None
            for c in cands:
                if c.exists():
                    wav = c
                    break
            if wav is None:
                continue
            items.append({"wav": str(wav), "ref": meta.get("reference"), "lang": loc,
                          "meta": {"whisper_wer": meta.get("whisper_wer"), "whisper_cer": meta.get("whisper_cer")}})
    else:
        for wav in sorted(wav_dir.glob("*.wav")):
            txt = wav.with_suffix(".txt")
            ref = txt.read_text(encoding="utf-8").strip() if txt.exists() else ""
            loc = wav.stem
            items.append({"wav": str(wav), "ref": ref, "lang": loc, "meta": {}})
    return name, items

def main():
    gpu = nvidia_info()
    assert gpu.get("cuda"), gpu
    print("load", ASR_ID, flush=True)
    model = AutoModel.from_pretrained(ASR_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    model = model.to("cuda").eval()

    # ---- Item 8 Kokoro ----
    k_items = collect_kokoro()
    k_rows = []
    for it in k_items:
        if not Path(it["wav"]).exists():
            continue
        # For English orthography Kokoro, Conformer may be weak; still score
        # Also try hi for Hindi-voice items? Stick to en for orthography fairness
        rec = score_one(model, it["wav"], it["ref"], it["lang"], "kokoro", it["meta"])
        k_rows.append(rec)
        print("K", Path(it["wav"]).name, rec.get("wer"), flush=True)

    # Note prior Whisper: none in probe; mark N/A
    d8 = Path(f"/workspace/backlog_runs/item_workspaces/pack_item08_kokoro_intelligibility_wer_{DATE}")
    d8.mkdir(parents=True, exist_ok=True)
    # copy a couple wavs into pack for evidence
    import shutil
    (d8 / "wavs").mkdir(exist_ok=True)
    for it in k_items[:3]:
        src = Path(it["wav"])
        if src.exists():
            shutil.copy2(src, d8 / "wavs" / src.name)
    k_payload = {
        "item": 8, "when": ist_now(), "gpu": gpu, "asr_id": ASR_ID,
        "n": len(k_rows),
        "wer_mean": float(np.mean([r["wer"] for r in k_rows if isinstance(r.get("wer"), float)])) if k_rows else None,
        "rows": k_rows,
        "prior_whisper": "not present in kokoro_hindi_english_probe (Whisper N/A); Conformer scored with lang=en on English orthography",
        "note": "Kokoro Hindi G2P/voice + English orthography; Conformer lang=en",
    }
    write_json(d8 / "results.json", k_payload)
    write_summary(d8, f"""# Item 8 -- Kokoro intelligibility WER

**When:** {k_payload['when']}
**ASR:** `{ASR_ID}`
**Status:** DONE
**n:** {k_payload['n']}
**WER mean:** {k_payload['wer_mean']}

## Table
| wav | voice | WER | CER |
|-----|-------|-----|-----|
""" + "\n".join(
        f"| {Path(r['wav']).name} | {(r.get('meta') or {}).get('voice')} | {r.get('wer')} | {r.get('cer')} |"
        for r in k_rows
    ) + f"""

## Prior Whisper
{k_payload['prior_whisper']}
""")
    z8, _ = finalize_pack(d8, f"pack_item08_kokoro_intelligibility_wer_{DATE}.zip")
    print("PACK8", z8, flush=True)

    # ---- Item 12 vendors ----
    vendors = [
        collect_vendor("pocket_tts", "/workspace/pocket_tts_qual/wavs", "/workspace/pocket_tts_qual"),
        collect_vendor("svara_tts", "/workspace/svara_tts_qual/wavs", "/workspace/svara_tts_qual"),
        collect_vendor("sooktam2", "/workspace/sooktam2_qual/wavs", "/workspace/sooktam2_qual"),
        collect_vendor("bodhan", "/workspace/bodhan_indic_speak_qual/wavs", "/workspace/bodhan_indic_speak_qual"),
        collect_vendor("voxtral_tts", "/workspace/voxtral_tts_qual/wavs", "/workspace/voxtral_tts_qual"),
    ]
    all_rows = []
    for vname, items in vendors:
        for it in items:
            # Skip locales Conformer can't do (e.g. es, fr) - only Indic+en
            lang = it["lang"]
            short = (LANG_MAP.get(lang) or lang.split("-")[0].lower())
            if short not in {"as","bn","gu","hi","kn","ml","mr","or","pa","ta","te","en"}:
                continue
            if not it.get("ref"):
                continue
            rec = score_one(model, it["wav"], it["ref"], lang, vname, it.get("meta"))
            all_rows.append(rec)
            print("V12", vname, lang, rec.get("wer"), flush=True)

    # rollup
    rollup = {}
    for r in all_rows:
        key = f"{r['vendor']}/{r['conformer_lang']}"
        rollup.setdefault(key, []).append(r)
    rollup_mean = {
        k: {
            "n": len(v),
            "wer_mean": float(np.mean([x["wer"] for x in v if isinstance(x.get("wer"), float)])) if v else None,
            "cer_mean": float(np.mean([x["cer"] for x in v if isinstance(x.get("cer"), float)])) if v else None,
        }
        for k, v in rollup.items()
    }
    by_vendor = {}
    for r in all_rows:
        by_vendor.setdefault(r["vendor"], []).append(r)
    vendor_mean = {
        k: {
            "n": len(v),
            "wer_mean": float(np.mean([x["wer"] for x in v if isinstance(x.get("wer"), float)])) if v else None,
        }
        for k, v in by_vendor.items()
    }

    d12 = Path(f"/workspace/backlog_runs/item_workspaces/pack_item12_indicconformer_tie_score_{DATE}")
    d12.mkdir(parents=True, exist_ok=True)
    payload = {
        "item": 12, "when": ist_now(), "gpu": gpu, "asr_id": ASR_ID,
        "n_scored": len(all_rows), "rollup_vendor_lang": rollup_mean,
        "rollup_vendor": vendor_mean, "rows": all_rows,
        "note": "IndicConformer positional API; Whisper kept in meta when present",
    }
    write_json(d12 / "results.json", payload)
    lines = ["| vendor/lang | n | WER mean | CER mean |", "|---|---|---|---|"]
    for k in sorted(rollup_mean):
        r = rollup_mean[k]
        lines.append(f"| {k} | {r['n']} | {r['wer_mean']} | {r['cer_mean']} |")
    write_summary(d12, f"""# Item 12 -- IndicConformer tie-score

**When:** {payload['when']}
**ASR:** `{ASR_ID}`
**Status:** DONE
**n_scored:** {payload['n_scored']}

## Vendors
Pocket TTS, svara-TTS, Sooktam-2, Bodhan, Voxtral TTS (not just IndicF5/Parler).

## Rollup WER by vendor/lang
{chr(10).join(lines)}

## Vendor means
{json.dumps(vendor_mean, indent=2)}
""")
    z12, _ = finalize_pack(d12, f"pack_item12_indicconformer_tie_score_{DATE}.zip")
    print("PACK12", z12, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
