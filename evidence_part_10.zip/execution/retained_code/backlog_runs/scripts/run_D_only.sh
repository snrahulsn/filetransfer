#!/bin/bash
set -u
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 ORT_NUM_THREADS=1
export OMP_WAIT_POLICY=PASSIVE TOKENIZERS_PARALLELISM=false
export HF_HOME=/workspace/hf_cache
export D_CAP_PER_LANG="${D_CAP_PER_LANG:-20}"
export D_TIMEOUT_S="${D_TIMEOUT_S:-1800}"
source /workspace/.hf_token_env 2>/dev/null || true
echo "=== D_only start $(date -Is) torch=$(python3 -c 'import torch;print(torch.__version__)') ==="
# Pin transformers to torch-2.4-compatible; keep existing torch
python3 -m pip install -q 'transformers==4.46.3' accelerate huggingface_hub torchaudio soundfile jiwer sentencepiece
python3 -m pip install -q nvidia-cudnn-cu12==9.1.0.70 onnxruntime-gpu==1.19.2
python3 - <<'PY'
import torch, transformers
print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
print('transformers', transformers.__version__)
import onnxruntime as ort
print('ort', ort.__version__, ort.get_available_providers())
PY
python3 /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py
echo "=== D_only end rc=$? $(date -Is) ==="
# If micro OK, expand
python3 - <<'PY' || exit 0
import json
from pathlib import Path
p=Path('/workspace/backlog_runs/pack_D_indicconformer_cudnn9/DONE.json')
d=json.loads(p.read_text())
print('DONE', d)
assert d.get('ok') and d.get('new_rtf') is not None and d.get('n_ok',0)>=10
PY
echo "Expanding to N=100"
export D_CAP_PER_LANG=100 D_TIMEOUT_S=7200
python3 /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py
echo "=== D100 end rc=$? $(date -Is) ==="
