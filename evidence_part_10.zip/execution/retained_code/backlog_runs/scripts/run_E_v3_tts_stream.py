#!/usr/bin/env python3
"""E v3: Voxtral TTS streaming TTFA via vllm serve --omni stream=true."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess, signal
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now(): return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p=Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str)+"\n", encoding="utf-8")

for p in (Path("/workspace/.hf_token_env"),):
    if p.exists():
        for line in p.read_text().splitlines():
            line=line.strip()
            if line.startswith("export "): line=line[7:]
            if "TOKEN=" in line and "=" in line:
                k,v=line.split("=",1); os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME","/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN",""))

OUT=Path("/workspace/tts_streaming_suite/voxtral_tts")
PACK=Path("/workspace/backlog_runs/pack_E_voxtral_tts_stream")
OUT.mkdir(parents=True, exist_ok=True); (OUT/"samples").mkdir(exist_ok=True); PACK.mkdir(parents=True, exist_ok=True)
MODEL="mistralai/Voxtral-4B-TTS-2603"
PORT=8010
NC="CC BY-NC 4.0 inherited — non-commercial / research only without separate Mistral license."


def measure_stream(text, voice, language, tag):
    import httpx
    url=f"http://127.0.0.1:{PORT}/v1/audio/speech"
    payload={"model":MODEL,"input":text,"voice":voice,"language":language,
             "stream":True,"stream_format":"audio","response_format":"pcm"}
    t0=time.perf_counter(); ttfa=None; nbytes=0; chunks=0
    pcm_path=OUT/"samples"/f"{tag}_stream.pcm"
    with httpx.stream("POST", url, json=payload, timeout=180.0) as r:
        r.raise_for_status()
        with open(pcm_path,"wb") as f:
            for chunk in r.iter_bytes():
                if not chunk: continue
                if ttfa is None: ttfa=time.perf_counter()-t0
                f.write(chunk); nbytes+=len(chunk); chunks+=1
    return {"lang":tag,"voice":voice,"ttfa_s":ttfa,"total_s":time.perf_counter()-t0,
            "bytes":nbytes,"chunks":chunks,"streaming":True,"pcm":str(pcm_path)}


def main():
    result={"model":MODEL,"license":"NC","license_note":NC,"timestamp":now(),
            "raspi":{"ran":False,"status":"NOT RUN — no Raspberry Pi hardware; no fabricated numbers"},
            "streaming":None,"ttfa_p50":None,"rows":[],"blocker":None}
    subprocess.run([sys.executable,"-m","pip","install","-q","httpx","soundfile","numpy"], check=False)
    # try vllm-omni; if missing, try plain vllm --omni
    subprocess.run([sys.executable,"-m","pip","install","-q","vllm-omni"], check=False)
    logf=OUT/"vllm_omni_serve.log"
    cmds=[
        ["vllm","serve",MODEL,"--omni","--port",str(PORT),"--trust-remote-code",
         "--compilation-config",'{"cudagraph_mode":"PIECEWISE"}'],
        [sys.executable,"-m","vllm.entrypoints.cli.main","serve",MODEL,"--omni","--port",str(PORT),
         "--trust-remote-code"],
    ]
    proc=None
    for c in cmds:
        try:
            print("SPAWN", c, flush=True)
            proc=subprocess.Popen(c, stdout=open(logf,"w"), stderr=subprocess.STDOUT)
            break
        except Exception as e:
            print("spawn fail", e, flush=True)
    if proc is None:
        result["blocker"]="could not spawn vllm --omni"
        result["streaming"]=False
        prior=Path("/workspace/voxtral_tts_qual/notes.md")
        if prior.exists() and "stream=true" in prior.read_text().lower():
            result["prior_qual_stream_true"]=True
        wj(OUT/"results.json", result); wj(PACK/"results.json", result)
        (PACK/"SUMMARY.md").write_text(
            f"# E Voxtral TTS streaming\n\n**License:** NC — {NC}\n**Streaming measured:** False\n"
            f"**Blocker:** {result['blocker']}\n**RasPi:** NOT RUN\n"
            f"**Prior qual stream=true:** {result.get('prior_qual_stream_true')}\n", encoding="utf-8")
        wj(PACK/"DONE.json", {"ok":False,"time":now(),"blocker":result["blocker"]})
        print("E_BLOCKED", flush=True); return

    import urllib.request
    ready=False
    for i in range(150):
        if proc.poll() is not None: break
        for path in (f"http://127.0.0.1:{PORT}/v1/models", f"http://127.0.0.1:{PORT}/health"):
            try:
                urllib.request.urlopen(path, timeout=2); ready=True; break
            except Exception: pass
        if ready: break
        time.sleep(5)
        if i%6==0: print(f"waiting omni {i*5}s", flush=True)
    if not ready:
        tail=logf.read_text(errors="replace")[-2500:] if logf.exists() else ""
        try: proc.terminate()
        except Exception: pass
        result.update({"blocker":"vllm-omni not ready","log_tail":tail,"streaming":False})
        wj(OUT/"results.json", result); wj(PACK/"results.json", result)
        (PACK/"SUMMARY.md").write_text(f"# E blocked\n\n```\n{tail}\n```\n**RasPi:** NOT RUN\n**License:** NC\n", encoding="utf-8")
        wj(PACK/"DONE.json", {"ok":False,"time":now(),"blocker":result["blocker"]})
        print("E_NOT_READY", flush=True); return

    texts=[("en","casual_female","English","Hello, your account balance is two thousand five hundred rupees."),
           ("hi","hi_female","Hindi","नमस्ते, आपके खाते में दो हजार पाँच सौ रुपये हैं।")]
    rows=[]
    for tag,voice,lang,text in texts:
        try: rows.append(measure_stream(text, voice, lang, tag))
        except Exception as e: rows.append({"lang":tag,"error":f"{type(e).__name__}: {e}","streaming":False})
        print("ROW", rows[-1], flush=True)
    try: proc.terminate(); proc.wait(timeout=30)
    except Exception:
        try: proc.kill()
        except Exception: pass
    ttfas=[r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"),(int,float))]
    result.update({"streaming":bool(ttfas),"stream_kind":"vllm_omni_audio_speech_stream_pcm" if ttfas else "failed",
                   "ttfa_p50":sorted(ttfas)[len(ttfas)//2] if ttfas else None,"ttfa_values":ttfas,"rows":rows})
    wj(OUT/"results.json", result); wj(PACK/"results.json", result)
    md=(f"# E Voxtral TTS streaming\n\n**When:** {now()}\n**License:** NC — {NC}\n"
        f"**Streaming:** {result['streaming']} ({result['stream_kind']})\n**TTFA p50:** {result['ttfa_p50']}\n"
        f"**RasPi:** NOT RUN\n\n## Rows\n"+ "\n".join(f"- {r}" for r in rows)+"\n")
    (OUT/"SUMMARY.md").write_text(md, encoding="utf-8"); (PACK/"SUMMARY.md").write_text(md, encoding="utf-8")
    wj(PACK/"DONE.json", {"ok":bool(ttfas),"time":now(),"ttfa_p50":result["ttfa_p50"]})
    print("E_DONE", result["ttfa_p50"], flush=True)


if __name__=="__main__":
    try: main()
    except Exception:
        err=traceback.format_exc()
        wj(PACK/"DONE.json", {"ok":False,"time":now(),"error":err[-2000:]})
        (PACK/"SUMMARY.md").write_text(f"# E FAILED\n\n```\n{err[-2000:]}\n```\n", encoding="utf-8")
        raise
