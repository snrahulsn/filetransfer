#!/usr/bin/env bash
set -uo pipefail
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export HF_HOME=/workspace/hf_cache
export HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
if [[ -f /workspace/.hf_token_env ]]; then set -a; source /workspace/.hf_token_env; set +a; fi
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-${HUGGING_FACE_HUB_TOKEN:-}}"
cd /workspace
LOG=/workspace/backlog_runs/gating_1234.log
exec > >(tee -a "$LOG") 2>&1
echo "==== GATING START $(date) ===="
python3 -m pip install -q soundfile librosa jiwer snac transformers accelerate huggingface_hub sentencepiece 2>&1 | tail -5 || true

run_one() {
  local name="$1" script="$2"
  echo "==== RUN $name $(date) ===="
  set +e
  python3 "/workspace/backlog_runs/scripts/$script"
  local rc=$?
  set -e
  echo "==== DONE $name rc=$rc $(date) ===="
  return 0
}

run_one gating1 run_gating1_sravaani_gpu_stream.py
run_one gating2 run_gating2_indicf5_locale_refs.py
run_one gating3 run_gating3_indicconformer_rescore.py
run_one gating4 run_gating4_maya1_stream_probe.py

python3 - <<'PY'
from pathlib import Path
import shutil
packs = [
  "pack_gating1_sravaani_gpu_stream",
  "pack_gating2_indicf5_locale_refs",
  "pack_gating3_indicconformer_rescore",
  "pack_gating4_maya1_stream_probe",
]
out = Path("/workspace/backlog_runs/packs_local")
out.mkdir(parents=True, exist_ok=True)
for name in packs:
  src = Path("/workspace/backlog_runs") / name
  if not src.exists():
    print("MISSING", src); continue
  dest = out / f"{name}.zip"
  if dest.exists(): dest.unlink()
  shutil.make_archive(str(dest.with_suffix("")), "zip", root_dir=str(src))
  print("ZIPPED", dest, dest.stat().st_size)
print("ALL_PACKED")
PY
echo "==== GATING COMPLETE $(date) ===="
# Marker for DONE files presence
python3 - <<'PY'
from pathlib import Path
for name in ["pack_gating1_sravaani_gpu_stream","pack_gating2_indicf5_locale_refs","pack_gating3_indicconformer_rescore","pack_gating4_maya1_stream_probe"]:
  d=Path("/workspace/backlog_runs")/name/"DONE.json"
  print(name, "DONE" if d.exists() else "NO_DONE", d.read_text()[:120].replace("\n"," ") if d.exists() else "")
PY
