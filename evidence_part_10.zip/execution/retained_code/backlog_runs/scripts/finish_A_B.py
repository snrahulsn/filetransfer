#!/usr/bin/env python3
"""Finish A_B: Whisper WER on existing wavs + streaming probes if missing."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas, save_wav

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf

AUDIO_MAYA = Path("/workspace/audio/maya1")
AUDIO_VEENA = Path("/workspace/audio/veena")
SUITE_MAYA = Path("/workspace/tts_streaming_suite/maya1")
SUITE_VEENA = Path("/workspace/tts_streaming_suite/veena_maya")
PACK = Path("/workspace/backlog_runs/pack_A_maya1_veena_synth_asr")
for p in [SUITE_MAYA/"samples", SUITE_VEENA/"samples", PACK]:
    p.mkdir(parents=True, exist_ok=True)

# Import generation helpers from A_B module by exec partial — simpler: reuse whisper via soundfile arrays
from transformers import AutoModelForSpeechSeq2Seq, AutoProcessor, pipeline
import jiwer

def whisper_score(items):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if device == "cuda" else torch.float32
    mid = "openai/whisper-large-v3"
    model = AutoModelForSpeechSeq2Seq.from_pretrained(mid, torch_dtype=dtype, low_cpu_mem_usage=True).to(device)
    proc = AutoProcessor.from_pretrained(mid)
    pipe = pipeline("automatic-speech-recognition", model=model, tokenizer=proc.tokenizer,
                    feature_extractor=proc.feature_extractor, torch_dtype=dtype,
                    device=0 if device=="cuda" else -1)
    rows = []
    for wav, ref, lang in items:
        audio, sr = sf.read(str(wav), dtype="float32")
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        hyp = pipe({"array": audio, "sampling_rate": sr}, generate_kwargs={"language": lang, "task": "transcribe"})["text"]
        ref_n = " ".join(ref.lower().split()); hyp_n = " ".join(hyp.lower().split())
        wer = float(jiwer.wer(ref_n, hyp_n)) if ref_n else 1.0
        cer = float(jiwer.cer(ref_n, hyp_n)) if ref_n else 1.0
        rows.append({"wav": str(wav), "ref": ref, "hyp": hyp, "lang": lang, "wer": wer, "cer": cer})
        print(Path(wav).name, "WER", wer, "CER", cer, "hyp", hyp[:80], flush=True)
    del model, pipe
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return rows

def main():
    gpu = nvidia_info()
    items = []
    for wav in sorted(AUDIO_MAYA.glob("*.wav")):
        txt = wav.with_suffix(".txt").read_text(encoding="utf-8").strip()
        items.append((wav, txt, "en"))
    for wav in sorted(AUDIO_VEENA.glob("*.wav")):
        txt = wav.with_suffix(".txt").read_text(encoding="utf-8").strip()
        lang = "hi" if "hi" in wav.name else "en"
        items.append((wav, txt, lang))
    print("scoring", len(items), "clips", flush=True)
    rows = whisper_score(items)
    write_json(PACK / "asr_metrics.json", {"model": "openai/whisper-large-v3", "rows": rows, "timestamp": ist_now(), "gpu": gpu})
    import shutil
    lines = [f"# Pack A — Maya1 & Veena synth + Whisper ASR\n\n**When:** {ist_now()}\n**GPU:** {gpu}\n\n",
             "| Wav | Lang | WER | CER |\n|---|---|---:|---:|\n"]
    for r in rows:
        lines.append(f"| {Path(r['wav']).name} | {r['lang']} | {r['wer']:.4f} | {r['cer']:.4f} |\n")
        shutil.copy2(r["wav"], PACK / Path(r["wav"]).name)
        t = Path(r["wav"]).with_suffix(".txt")
        if t.exists():
            shutil.copy2(t, PACK / t.name)
    # note streaming status from suite if present
    for suite in (SUITE_MAYA, SUITE_VEENA):
        if (suite/"results.json").exists():
            shutil.copy2(suite/"results.json", PACK / f"{suite.name}_stream_results.json")
        if (suite/"SUMMARY.md").exists():
            shutil.copy2(suite/"SUMMARY.md", PACK / f"{suite.name}_SUMMARY.md")
    (PACK / "SUMMARY.md").write_text("".join(lines), encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": True, "time": ist_now(), "n": len(rows)})
    print("FINISH_A DONE", flush=True)

if __name__ == "__main__":
    main()
