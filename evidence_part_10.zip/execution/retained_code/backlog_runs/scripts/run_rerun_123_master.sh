#!/bin/bash
set -uo pipefail
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8 LANG=C.UTF-8 LC_ALL=C.UTF-8
export HF_HOME=/workspace/hf_cache HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
if [[ -f /workspace/.hf_token_env ]]; then set -a; source /workspace/.hf_token_env; set +a; fi
cd /workspace
PY=python3
LOG=/workspace/backlog_runs/rerun123_master.log
exec > >(tee -a "$LOG") 2>&1
echo "=== START $(date -Is) PY=$PY ==="
$PY -c "import torch; print('cuda', torch.cuda.is_available(), torch.__version__, torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)"

echo "=== install peft qwen-tts openai-whisper jiwer soundfile ==="
$PY -m pip install -q -U peft openai-whisper jiwer soundfile librosa 2>&1 | tail -20
# qwen-tts: prefer local editable if present
if [[ -d /workspace/Qwen3-TTS ]]; then
  $PY -m pip install -q -e /workspace/Qwen3-TTS 2>&1 | tail -20
else
  $PY -m pip install -q -U qwen-tts 2>&1 | tail -20
fi
$PY -c "import peft,qwen_tts,whisper,jiwer; print('peft',peft.__version__,'whisper ok','jiwer ok')"

echo "=== RERUN01 $(date -Is) ==="
$PY /workspace/backlog_runs/scripts/run_rerun01_qwen3_hindi_lora.py
echo "=== RERUN02 $(date -Is) ==="
$PY /workspace/backlog_runs/scripts/run_rerun02_whisper_en.py
echo "=== RERUN03 $(date -Is) ==="
$PY /workspace/backlog_runs/scripts/run_rerun03_sravaani_480.py
echo "=== ALL DONE $(date -Is) ==="
touch /workspace/backlog_runs/item_workspaces/DONE_rerun123.json
echo '{"ok":true}' > /workspace/backlog_runs/item_workspaces/DONE_rerun123.json
