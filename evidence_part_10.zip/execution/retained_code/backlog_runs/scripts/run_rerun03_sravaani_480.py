#!/usr/bin/env python3
"""Rerun 03: SraVaani-0.5-live at 480ms lookahead -- accuracy (WER/CER) + TTFA context."""
from __future__ import annotations
import json, os, sys, time, traceback, inspect, re
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf
from transformers import AutoModel

try:
    import jiwer
except Exception:
    jiwer = None

MODEL_ID = "ARTPARK-IISc/SraVaani-0.5-live"
FLEURS = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
LOOKAHEAD_MS = 480
WORK = Path(f"/workspace/backlog_runs/item_workspaces/pack_rerun03_sravaani_480ms_accuracy_{DATE}")
PACK_NAME = f"pack_rerun03_sravaani_480ms_accuracy_{DATE}"

def load_audio(wav_path):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
        sr = 16000
    return audio.astype(np.float32), sr

def norm_text(t: str) -> str:
    t = (t or "").strip().lower()
    t = re.sub(r"[^\w\s\u0900-\u097F]", " ", t, flags=re.UNICODE)
    return re.sub(r"\s+", " ", t).strip()

def wer_cer(ref, hyp):
    ref_n, hyp_n = norm_text(ref), norm_text(hyp)
    if not ref_n:
        return {"wer": None, "cer": None, "ref": ref, "hyp": hyp}
    if jiwer is None:
        import difflib
        rw, hw = ref_n.split(), hyp_n.split()
        sm = difflib.SequenceMatcher(a=rw, b=hw)
        wer = 1.0 - sm.ratio()
        cer = 1.0 - difflib.SequenceMatcher(a=ref_n, b=hyp_n).ratio()
        return {"wer": float(wer), "cer": float(cer), "ref": ref, "hyp": hyp, "fallback": True, "ref_n": ref_n, "hyp_n": hyp_n}
    return {
        "wer": float(jiwer.wer(ref_n, hyp_n)),
        "cer": float(jiwer.cer(ref_n, hyp_n)),
        "ref": ref, "hyp": hyp, "ref_n": ref_n, "hyp_n": hyp_n,
    }

def pick_clips(n_hi=5, n_en=2):
    clips = []
    for lang, n in [("hi_in", n_hi), ("en_us", n_en)]:
        man = FLEURS / f"manifest_{lang}.jsonl"
        if not man.exists():
            continue
        rows = [json.loads(l) for l in man.read_text(encoding="utf-8").splitlines() if l.strip()]
        for r in rows[:n]:
            if Path(r["wav"]).exists():
                clips.append(r)
    return clips

def set_lookahead(model, ms):
    notes = []
    if hasattr(model, "set_lookahead_ms"):
        try:
            model.set_lookahead_ms(ms)
            notes.append(f"set_lookahead_ms({ms})")
            return True, notes
        except Exception as e:
            notes.append(f"set_lookahead_ms err: {e}")
    if hasattr(model, "set_att_context_size"):
        try:
            sig = str(inspect.signature(model.set_att_context_size))
            notes.append(f"set_att_context_size sig={sig}")
            # Card supported: [70,13]=1040ms, [70,6]=480ms, [70,1]=80ms, [70,0]=0
            mapping = {1040: 13, 480: 6, 80: 1, 0: 0}
            right = mapping.get(ms, max(0, int(round(ms / 80.0))))
            try:
                model.set_att_context_size([70, right])
                notes.append(f"set_att_context_size([70,{right}])")
                return True, notes
            except Exception:
                model.set_att_context_size(right)
                notes.append(f"set_att_context_size({right})")
                return True, notes
        except Exception as e:
            notes.append(f"set_att_context_size err: {e}")
    if hasattr(model, "config") and hasattr(model.config, "att_context_size"):
        try:
            mapping = {1040: 13, 480: 6, 80: 1, 0: 0}
            right = mapping.get(ms, max(0, int(round(ms / 80.0))))
            old = model.config.att_context_size
            if isinstance(old, (list, tuple)) and len(old) >= 2:
                model.config.att_context_size = [old[0], right]
            else:
                model.config.att_context_size = right
            notes.append(f"config.att_context_size -> {model.config.att_context_size}")
            return True, notes
        except Exception as e:
            notes.append(f"config mutate err: {e}")
    return False, notes

def stream_feed(model, audio, block_s=0.25, pace=False, want_partials=True):
    t0 = time.perf_counter()
    ttfa = None
    partials = []
    final = None
    err = None
    try:
        state = model.new_stream()
        block = int(block_s * 16000)
        for i in range(0, len(audio), block):
            chunk = audio[i : i + block]
            t_feed = time.perf_counter()
            text = model.stream_audio(state, chunk)
            now = time.perf_counter() - t0
            if text and ttfa is None:
                ttfa = now
            if want_partials and text:
                partials.append({"t": round(now, 4), "text": text})
            if pace:
                elapsed_chunk = time.perf_counter() - t_feed
                sleep_for = block_s - elapsed_chunk
                if sleep_for > 0:
                    time.sleep(sleep_for)
        if hasattr(model, "finalize"):
            final = model.finalize(state)
        elif hasattr(model, "finish_stream"):
            final = model.finish_stream(state)
        elif partials:
            final = partials[-1]["text"]
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
    total = time.perf_counter() - t0
    return {
        "ok": err is None,
        "error": err,
        "ttfa_s": ttfa,
        "total_s": round(total, 4),
        "n_partials": len(partials),
        "partials": partials[:30],
        "final": final,
        "paced": pace,
    }

def document_api(model):
    methods = {}
    for name in ("new_stream", "stream_audio", "finalize", "finish_stream", "set_att_context_size", "set_lookahead_ms", "transcribe"):
        if hasattr(model, name):
            fn = getattr(model, name)
            try:
                methods[name] = str(inspect.signature(fn))
            except Exception:
                methods[name] = "present"
        else:
            methods[name] = None
    cfg = {}
    if hasattr(model, "config"):
        for attr in ("att_context_size", "supported_att_context_sizes", "lookahead_seconds"):
            if hasattr(model.config, attr):
                try:
                    cfg[attr] = getattr(model.config, attr)
                except Exception:
                    pass
    return {"methods": methods, "config": cfg}

def main():
    gpu = nvidia_info()
    assert gpu.get("cuda"), gpu
    WORK.mkdir(parents=True, exist_ok=True)
    clips = pick_clips()
    assert len(clips) >= 7, f"need n>=7 clips, got {len(clips)}"
    print("clips", len(clips), flush=True)

    print("load", MODEL_ID, flush=True)
    t_load = time.perf_counter()
    model = AutoModel.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    model = model.to("cuda").eval()
    load_s = time.perf_counter() - t_load
    api = document_api(model)

    ok_set, set_notes = set_lookahead(model, LOOKAHEAD_MS)
    print("lookahead set", ok_set, set_notes, flush=True)
    # record post-set config
    api_after = document_api(model)

    # warm
    a0, _ = load_audio(clips[0]["wav"])
    _ = stream_feed(model, a0, pace=False, want_partials=False)

    rows = []
    for c in clips:
        audio, sr = load_audio(c["wav"])
        r = stream_feed(model, audio, pace=False)
        hyp = r.get("final") or (r["partials"][-1]["text"] if r.get("partials") else "")
        m = wer_cer(c.get("reference", ""), hyp or "")
        row = {
            "utt_id": c.get("utt_id"),
            "lang": c.get("lang"),
            "wav": c.get("wav"),
            "duration_s": c.get("duration_s"),
            "reference": c.get("reference"),
            "hypothesis": hyp,
            "hyp_n": m.get("hyp_n"),
            "ref_n": m.get("ref_n"),
            "ttfa_s": r.get("ttfa_s"),
            "n_partials": r.get("n_partials"),
            "total_s": r.get("total_s"),
            "ok": r.get("ok"),
            "error": r.get("error"),
            "wer": m.get("wer"),
            "cer": m.get("cer"),
        }
        rows.append(row)
        print("R3", row["utt_id"], "WER", row.get("wer"), "CER", row.get("cer"), "ttfa", row.get("ttfa_s"), flush=True)

    wers = [r["wer"] for r in rows if isinstance(r.get("wer"), (int, float))]
    cers = [r["cer"] for r in rows if isinstance(r.get("cer"), (int, float))]
    ttfas = [r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"), (int, float))]

    status = {
        "item": "rerun03",
        "when": ist_now(),
        "model_id": MODEL_ID,
        "lookahead_ms": LOOKAHEAD_MS,
        "lookahead_set_ok": ok_set,
        "lookahead_set_notes": set_notes,
        "gpu": gpu,
        "load_s": load_s,
        "n_clips": len(rows),
        "wer_summary": summarize_ttfas(wers),
        "cer_summary": summarize_ttfas(cers),
        "ttfa_summary": summarize_ttfas(ttfas),
        "api_before": api,
        "api_after": api_after,
        "rows": rows,
        "status": "DONE" if wers else "BLOCKED",
        "note": "Accuracy at 480ms lookahead decides ASR answer; same FLEURS clip set as item01 (5 hi + 2 en)",
    }
    write_json(WORK / "results.json", status)
    write_summary(WORK, f"""# Rerun03 -- SraVaani 480ms lookahead accuracy

**When:** {status['when']}
**Model:** `{MODEL_ID}`
**Lookahead:** {LOOKAHEAD_MS} ms (set_ok={ok_set}; notes={set_notes})
**Status:** {status['status']}
**GPU:** {gpu}

## Accuracy (streaming finalize vs FLEURS refs)
| Metric | Value |
|--------|-------|
| n clips | {status['n_clips']} |
| WER p50 | {status['wer_summary'].get('p50')} |
| WER mean | {status['wer_summary'].get('mean')} |
| CER p50 | {status['cer_summary'].get('p50')} |
| CER mean | {status['cer_summary'].get('mean')} |
| TTFA p50 (context) | {status['ttfa_summary'].get('p50')} |
| TTFA mean | {status['ttfa_summary'].get('mean')} |

## Per-clip
""" + "\n".join(
        f"- **{r['utt_id']}** WER={r.get('wer')} CER={r.get('cer')} ttfa={r.get('ttfa_s')} hyp={(r.get('hypothesis') or '')[:80]}"
        for r in rows
    ) + f"""

## API after set
```
{json.dumps(api_after, indent=2)}
```

## Note
Prior item03 reported latency-only for 480ms. This pack reports real WER/CER at 480ms.
""")
    z, _ = finalize_pack(WORK, f"{PACK_NAME}.zip")
    print("PACK_RERUN03", z, status["status"], flush=True)
    try:
        prog = Path("/workspace/backlog_runs/PROGRESS_RERUN.md")
        prog.parent.mkdir(parents=True, exist_ok=True)
        cur = prog.read_text(encoding="utf-8") if prog.exists() else "# PROGRESS RERUN\n"
        cur = cur.replace("| 3 SraVaani 480ms accuracy | PENDING |",
                          f"| 3 SraVaani 480ms accuracy | {status['status']} WER_p50={status['wer_summary'].get('p50')} |")
        if "| 3 SraVaani 480ms accuracy |" not in cur:
            cur += f"\n| 3 SraVaani 480ms accuracy | {status['status']} WER_p50={status['wer_summary'].get('p50')} |\n"
        prog.write_text(cur, encoding="ascii", errors="replace")
    except Exception as _pe:
        print("progress ping skip", _pe, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        WORK.mkdir(parents=True, exist_ok=True)
        write_json(WORK / "results.json", {"item": "rerun03", "status": "BLOCKED", "error": traceback.format_exc()[-3000:]})
        write_summary(WORK, f"# Rerun03 BLOCKED\n\n{traceback.format_exc()[-2000:]}\n")
        finalize_pack(WORK, f"{PACK_NAME}.zip")
