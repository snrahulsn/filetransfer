#!/usr/bin/env python3
"""F v5: Official vLLM Voxtral realtime schema; score 6 clips; TTFA + WER/CER."""
from __future__ import annotations
import asyncio, base64, json, os, re, sys, time, traceback, subprocess, signal, unicodedata
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now():
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for envp in (Path("/workspace/.hf_token_env"),):
    if envp.exists():
        for line in envp.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "): line = line[7:]
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN", ""))
os.environ["VLLM_USE_FLASHINFER_SAMPLER"] = "0"

OUT = Path("/workspace/voxtral_mini_realtime_asr")
PACK = Path("/workspace/backlog_runs/pack_F_voxtral_mini_realtime_asr_v2")
OUT.mkdir(parents=True, exist_ok=True)
PACK.mkdir(parents=True, exist_ok=True)
MODEL = "mistralai/Voxtral-Mini-4B-Realtime-2602"
PORT = int(os.environ.get("F_PORT", "8020"))

SCHEMA_DOC = {
    "client_to_server": [
        {"type": "session.update", "model": MODEL},
        {"type": "input_audio_buffer.commit"},
        {"type": "input_audio_buffer.append", "audio": "<base64 pcm16 16kHz mono>"},
        {"type": "input_audio_buffer.commit", "final": True},
    ],
    "server_to_client": ["session.created", "transcription.delta", "transcription.done", "error"],
    "prior_bug": "v4 nested OpenAI session{} + skipped initial commit; only session.created observed",
    "source": "https://docs.vllm.ai/en/latest/serving/online_serving/speech_to_text/ + openai_realtime_client.py",
}

def gather_clips():
    for cand in (OUT / "clips_manifest.json", Path("/workspace/backlog_runs/F_clips_stage/clips_manifest.json")):
        if cand.exists():
            clips = json.loads(cand.read_text(encoding="utf-8"))
            if clips:
                return clips[:6]
    clips = []
    d = OUT / "clips"
    if d.exists():
        for p in sorted(d.glob("*.wav"))[:6]:
            clips.append({"path": str(p), "lang": "unk", "utt_id": p.stem, "reference": ""})
    return clips[:6]

def normalize_text(s: str) -> str:
    s = unicodedata.normalize("NFKC", s or "")
    s = s.lower().strip()
    return re.sub(r"\s+", " ", s)

def edit_distance(a, b):
    n, m = len(a), len(b)
    dp = list(range(m + 1))
    for i in range(1, n + 1):
        prev, dp[0] = dp[0], i
        for j in range(1, m + 1):
            cur = dp[j]
            if a[i - 1] == b[j - 1]:
                dp[j] = prev
            else:
                dp[j] = 1 + min(prev, dp[j], dp[j - 1])
            prev = cur
    return dp[m]

def wer_cer(ref: str, hyp: str):
    rw, hw = normalize_text(ref).split(), normalize_text(hyp).split()
    w_err = edit_distance(rw, hw)
    wer = (w_err / max(1, len(rw))) if rw else (0.0 if not hw else 1.0)
    rc = list(normalize_text(ref).replace(" ", ""))
    hc = list(normalize_text(hyp).replace(" ", ""))
    c_err = edit_distance(rc, hc)
    cer = (c_err / max(1, len(rc))) if rc else (0.0 if not hc else 1.0)
    return {"wer": wer, "cer": cer, "w_err": w_err, "c_err": c_err, "ref_words": len(rw), "hyp_words": len(hw)}

async def transcribe_one(clip, uri, capture_frames=False):
    import websockets, soundfile as sf, numpy as np, librosa
    path = clip["path"]
    audio, sr = sf.read(path, dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    pcm = (np.clip(audio, -1, 1) * 32767).astype("int16").tobytes()
    t0 = time.perf_counter(); ttfa = None; parts = []; events = []; frames_out = []; frames_in = []; final_text = ""
    async with websockets.connect(uri, max_size=16_000_000, open_timeout=120) as ws:
        try:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=60))
            events.append({"recv": msg.get("type"), "keys": sorted(msg.keys())})
            if capture_frames:
                frames_in.append(msg)
            if msg.get("type") != "session.created":
                return {"path": path, "utt_id": clip.get("utt_id"), "lang": clip.get("lang"),
                        "reference": clip.get("reference", ""), "hypothesis": "", "ttfa_s": None,
                        "total_s": time.perf_counter() - t0, "error": f"unexpected bootstrap {msg.get('type')}",
                        "events": events, "frames_out": frames_out, "frames_in_tail": frames_in}
        except Exception as e:
            return {"path": path, "utt_id": clip.get("utt_id"), "error": f"bootstrap: {e}",
                    "hypothesis": "", "ttfa_s": None, "total_s": time.perf_counter() - t0,
                    "reference": clip.get("reference", ""), "events": events}

        su = {"type": "session.update", "model": MODEL}
        await ws.send(json.dumps(su)); frames_out.append(su); events.append({"sent": "session.update"})
        c0 = {"type": "input_audio_buffer.commit"}
        await ws.send(json.dumps(c0)); frames_out.append(c0); events.append({"sent": "input_audio_buffer.commit(start)"})
        chunk_size = 4096; n_chunks = 0
        for i in range(0, len(pcm), chunk_size):
            chunk = pcm[i:i + chunk_size]
            app = {"type": "input_audio_buffer.append", "audio": base64.b64encode(chunk).decode()}
            await ws.send(json.dumps(app)); n_chunks += 1
            if capture_frames and i == 0:
                frames_out.append({"type": "input_audio_buffer.append", "audio": f"<b64_len={len(app['audio'])} raw={len(chunk)}>"})
        events.append({"sent": "append", "chunks": n_chunks, "pcm_bytes": len(pcm)})
        cf = {"type": "input_audio_buffer.commit", "final": True}
        await ws.send(json.dumps(cf)); frames_out.append(cf); events.append({"sent": "input_audio_buffer.commit(final=True)"})

        deadline = time.perf_counter() + 120
        while time.perf_counter() < deadline:
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=30)
            except Exception as e:
                events.append({"recv_end": str(e)}); break
            data = json.loads(raw); typ = data.get("type", "")
            events.append({"type": typ, "keys": sorted(data.keys())})
            if capture_frames:
                frames_in.append({k: (f"<len {len(v)}>" if k == "audio" and isinstance(v, str) else v) for k, v in data.items()})
            if typ in ("transcription.delta", "response.audio_transcript.delta"):
                delta = data.get("delta") or ""
                if delta and ttfa is None: ttfa = time.perf_counter() - t0
                if delta: parts.append(str(delta))
            elif typ in ("transcription.done", "response.audio_transcript.done"):
                final_text = data.get("text") or "".join(parts)
                if final_text and ttfa is None: ttfa = time.perf_counter() - t0
                events.append({"done_usage": data.get("usage")}); break
            elif typ == "error":
                events.append({"error_payload": data.get("error") or data}); break
            else:
                # opportunistic extract
                delta = data.get("delta") or ""
                if delta and "transcript" in typ:
                    if ttfa is None: ttfa = time.perf_counter() - t0
                    parts.append(str(delta))
                if typ.endswith("done") and ("transcript" in typ or "transcription" in typ):
                    final_text = data.get("text") or "".join(parts)
                    if final_text and ttfa is None: ttfa = time.perf_counter() - t0
                    break

    text = final_text or "".join(parts)
    row = {"path": path, "utt_id": clip.get("utt_id"), "lang": clip.get("lang"),
           "reference": clip.get("reference", ""), "hypothesis": text, "ttfa_s": ttfa,
           "total_s": time.perf_counter() - t0, "events_n": len(events), "events": events,
           "frames_out": frames_out, "frames_in_tail": frames_in[-12:]}
    row["metrics"] = wer_cer(row["reference"], text)
    return row

def main():
    clips = gather_clips()
    wj(OUT / "clips_manifest.json", clips)
    wj(PACK / "schema.json", SCHEMA_DOC)
    print(f"clips={len(clips)} MODEL={MODEL} PACK={PACK}", flush=True)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "websockets", "soundfile", "librosa", "numpy"], check=False)

    logf = OUT / "vllm_serve_v5.log"
    cmd = [sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", MODEL,
           "--tokenizer-mode", "mistral", "--config-format", "mistral", "--load-format", "mistral",
           "--trust-remote-code", "--max-model-len", "8192", "--gpu-memory-utilization", "0.85",
           "--host", "127.0.0.1", "--port", str(PORT),
           "--compilation-config", '{"cudagraph_mode":"PIECEWISE"}',
           "--enforce-eager"]
    print("SPAWN", cmd, flush=True)
    proc = subprocess.Popen(cmd, stdout=open(logf, "w"), stderr=subprocess.STDOUT)
    import urllib.request
    ready = False
    for i in range(180):
        if proc.poll() is not None:
            print("vllm exited", proc.returncode, flush=True)
            # try alternate entrypoint
            cmd2 = ["vllm", "serve", MODEL, "--tokenizer-mode", "mistral",
                    "--config-format", "mistral", "--load-format", "mistral",
                    "--trust-remote-code", "--max-model-len", "8192",
                    "--gpu-memory-utilization", "0.85", "--host", "127.0.0.1", "--port", str(PORT),
                    "--compilation-config", '{"cudagraph_mode":"PIECEWISE"}', "--enforce-eager"]
            print("RETRY", cmd2, flush=True)
            proc = subprocess.Popen(cmd2, stdout=open(logf, "a"), stderr=subprocess.STDOUT)
            time.sleep(10)
            if proc.poll() is not None:
                break
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/v1/models", timeout=2)
            ready = True
            break
        except Exception:
            time.sleep(5)
            if i % 6 == 0:
                print(f"waiting... {i*5}s", flush=True)

    if not ready:
        tail = logf.read_text(errors="replace")[-5000:] if logf.exists() else ""
        try: proc.terminate()
        except Exception: pass
        result = {"ok": False, "blocker": "vllm not ready", "log_tail": tail, "model": MODEL,
                  "timestamp": now(), "clips_n": len(clips), "schema": SCHEMA_DOC}
        wj(OUT / "results_v5.json", result); wj(PACK / "results.json", result)
        (PACK / "SUMMARY.md").write_text(f"# F v5 BLOCKED\n\nvLLM not ready.\n\n```\n{tail[-2500:]}\n```\n", encoding="utf-8")
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "blocker": "vllm not ready"})
        print("F_BLOCKED_SERVE", flush=True); return

    uri = f"ws://127.0.0.1:{PORT}/v1/realtime"
    rows = []
    for i, c in enumerate(clips):
        try:
            row = asyncio.run(transcribe_one(c, uri, capture_frames=(i == 0)))
        except Exception as e:
            row = {"path": c.get("path"), "utt_id": c.get("utt_id"), "error": f"{type(e).__name__}: {e}",
                   "ttfa_s": None, "hypothesis": "", "reference": c.get("reference", "")}
        rows.append(row)
        print("ROW", {k: row.get(k) for k in ("utt_id", "ttfa_s", "hypothesis", "metrics", "error")}, flush=True)
        if i == 0:
            wj(PACK / "ws_frames_clip0.json", {
                "frames_out": row.get("frames_out"),
                "frames_in_tail": row.get("frames_in_tail"),
                "events": row.get("events"),
            })

    try:
        proc.send_signal(signal.SIGTERM); proc.wait(timeout=45)
    except Exception:
        try: proc.kill()
        except Exception: pass

    ttfas = [r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"), (int, float))]
    wers = [r["metrics"]["wer"] for r in rows if isinstance(r.get("metrics"), dict) and r.get("reference")]
    cers = [r["metrics"]["cer"] for r in rows if isinstance(r.get("metrics"), dict) and r.get("reference")]
    def p50(xs):
        return sorted(xs)[len(xs)//2] if xs else None
    scored = any((r.get("hypothesis") or "").strip() for r in rows)
    result = {
        "ok": bool(ttfas) and scored, "model": MODEL, "rows": rows, "clips_n": len(clips),
        "ttfa_p50": p50(ttfas), "wer_p50": p50(wers), "cer_p50": p50(cers), "timestamp": now(),
        "serve_flags": "--enforce-eager + cudagraph_mode=PIECEWISE; VLLM_USE_FLASHINFER_SAMPLER=0",
        "schema": SCHEMA_DOC,
        "blocker": None if (ttfas and scored) else "no transcription.delta/done after schema-aligned client",
    }
    wj(OUT / "results_v5.json", result); wj(PACK / "results.json", result)
    compact = [{k: r.get(k) for k in ("utt_id","lang","path","ttfa_s","total_s","hypothesis","reference","metrics","error","events_n")} for r in rows]
    wj(PACK / "results_compact.json", {"ok": result["ok"], "ttfa_p50": result["ttfa_p50"], "wer_p50": result["wer_p50"], "cer_p50": result["cer_p50"], "rows": compact})
    md = [
        "# F — Voxtral Mini 4B Realtime ASR (v5 schema-aligned)", "",
        f"**When:** {now()}", f"**Model:** `{MODEL}`", f"**OK:** {result['ok']}",
        f"**TTFA p50:** {result['ttfa_p50']}", f"**WER p50:** {result['wer_p50']}",
        f"**CER p50:** {result['cer_p50']}", f"**Clips:** {len(clips)}", "",
        "## WS schema used (working)",
        "1. recv `session.created`",
        "2. send `session.update` with flat `model`",
        "3. send `input_audio_buffer.commit` (start generation)",
        "4. send `input_audio_buffer.append` (pcm16 @ 16 kHz mono, base64)",
        "5. send `input_audio_buffer.commit` with `final: true`",
        "6. recv `transcription.delta` / `transcription.done`", "",
        "Prior v4 bug: nested OpenAI `session{}` + missing initial commit → only `session.created`.", "",
        "## Rows",
    ]
    for r in compact:
        md.append(f"- **{r.get('utt_id')}** ttfa={r.get('ttfa_s')} wer={((r.get('metrics') or {}).get('wer'))} hyp={(r.get('hypothesis') or '')[:120]!r}")
    if result.get("blocker"):
        md.append(f"\n## Blocker\n{result['blocker']}\n")
    (PACK / "SUMMARY.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    wj(PACK / "DONE.json", {"ok": result["ok"], "time": now(), "ttfa_p50": result["ttfa_p50"],
                             "wer_p50": result["wer_p50"], "cer_p50": result["cer_p50"],
                             "blocker": result.get("blocker")})
    print("F_DONE", result["ok"], result["ttfa_p50"], result["wer_p50"], flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "error": err[-2000:]})
        (PACK / "SUMMARY.md").write_text(f"# F v5 FAILED\n\n```\n{err[-2000:]}\n```\n", encoding="utf-8")
        raise
