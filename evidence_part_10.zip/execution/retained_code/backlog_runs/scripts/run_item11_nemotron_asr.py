#!/usr/bin/env python3
"""Item 11: NVIDIA Nemotron ASR streaming probe."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess, re
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

MODEL_ID = "nvidia/nemotron-3.5-asr-streaming-0.6b"
OUT = Path(f"/workspace/backlog_runs/item_workspaces/pack_item11_nvidia_nemotron_asr_{DATE}")
LOG = OUT / "install_deploy.log"
FLEURS = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")

def log(msg):
    OUT.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")
    print(msg, flush=True)

def pick_clips():
    clips = []
    for lang, n in [("en_us", 2), ("hi_in", 2)]:
        man = FLEURS / f"manifest_{lang}.jsonl"
        if not man.exists():
            continue
        for line in man.read_text(encoding="utf-8").splitlines()[:n]:
            r = json.loads(line)
            if Path(r["wav"]).exists():
                clips.append(r)
    return clips

def main():
    import numpy as np
    import soundfile as sf
    import torch
    try:
        import jiwer
    except Exception:
        jiwer = None

    gpu = nvidia_info()
    OUT.mkdir(parents=True, exist_ok=True)
    status = {"item": 11, "when": ist_now(), "gpu": gpu, "model_id": MODEL_ID}

    # Ensure deps
    try:
        import transformers
        log(f"transformers {transformers.__version__}")
    except Exception:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "transformers", "accelerate", "soundfile", "jiwer", "librosa"], timeout=600)

    clips = pick_clips()
    log(f"clips={len(clips)}")

    try:
        from transformers import AutoModel, AutoProcessor, AutoModelForSpeechSeq2Seq
        t0 = time.perf_counter()
        # Try several load paths
        model = None
        load_err = []
        for loader in ("AutoModel", "AutoModelForSpeechSeq2Seq"):
            try:
                cls = AutoModel if loader == "AutoModel" else AutoModelForSpeechSeq2Seq
                model = cls.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"], torch_dtype=torch.float16)
                model = model.to("cuda").eval()
                status["loader"] = loader
                break
            except Exception as e:
                load_err.append(f"{loader}: {e}")
                log(load_err[-1][:400])
        if model is None:
            # NeMo path
            try:
                import nemo.collections.asr as nemo_asr
                model = nemo_asr.models.ASRModel.from_pretrained(MODEL_ID)
                model = model.cuda().eval()
                status["loader"] = "nemo_asr"
            except Exception as e:
                load_err.append(f"nemo: {e}")
                raise RuntimeError(load_err)

        load_s = time.perf_counter() - t0
        status["load_s"] = load_s

        # Warm
        a0, sr0 = sf.read(clips[0]["wav"], dtype="float32")
        if a0.ndim > 1: a0 = a0.mean(axis=1)
        if sr0 != 16000:
            import librosa
            a0 = librosa.resample(a0, orig_sr=sr0, target_sr=16000)

        def stream_or_batch(audio, pace=False, block_s=0.25):
            """Prefer streaming API if present; else batch + fake paced feed timing for TTFA proxy."""
            t_start = time.perf_counter()
            ttfa = None
            partials = []
            final = None
            kind = "batch"
            try:
                if hasattr(model, "new_stream") and hasattr(model, "stream_audio"):
                    kind = "new_stream"
                    state = model.new_stream()
                    block = int(block_s * 16000)
                    for i in range(0, len(audio), block):
                        chunk = audio[i:i+block]
                        t_feed = time.perf_counter()
                        text = model.stream_audio(state, chunk)
                        now = time.perf_counter() - t_start
                        if text and ttfa is None:
                            ttfa = now
                        if text:
                            partials.append({"t": round(now,4), "text": text})
                        if pace:
                            rem = block_s - (time.perf_counter() - t_feed)
                            if rem > 0: time.sleep(rem)
                    final = model.finalize(state) if hasattr(model, "finalize") else (partials[-1]["text"] if partials else None)
                elif hasattr(model, "transcribe"):
                    kind = "transcribe"
                    # paced: wait until first audio second before calling (proxy)
                    if pace:
                        time.sleep(min(0.5, len(audio)/16000*0.1))
                    out = model.transcribe([audio])
                    final = out[0] if isinstance(out, (list, tuple)) else str(out)
                    ttfa = time.perf_counter() - t_start
                    partials = [{"t": ttfa, "text": final}]
                else:
                    kind = "forward"
                    # try processor path
                    try:
                        from transformers import AutoProcessor
                        proc = AutoProcessor.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
                        inputs = proc(audio, sampling_rate=16000, return_tensors="pt")
                        inputs = {k: v.to("cuda") if hasattr(v, "to") else v for k, v in inputs.items()}
                        with torch.inference_mode():
                            out = model.generate(**inputs) if hasattr(model, "generate") else model(**inputs)
                        final = proc.batch_decode(out)[0] if hasattr(proc, "batch_decode") else str(out)
                        ttfa = time.perf_counter() - t_start
                    except Exception:
                        with torch.inference_mode():
                            t = torch.from_numpy(audio).float().unsqueeze(0).to("cuda")
                            out = model(t)
                        final = str(out)
                        ttfa = time.perf_counter() - t_start
            except Exception as e:
                return {"ok": False, "error": traceback.format_exc()[-1200:], "kind": kind}
            return {"ok": True, "ttfa_s": ttfa, "final": final, "n_partials": len(partials),
                    "partials": partials[:20], "kind": kind, "total_s": time.perf_counter()-t_start, "paced": pace}

        # warm discard
        _ = stream_or_batch(a0.astype(np.float32), pace=False)

        rows = []
        paced_ttfas = []
        for c in clips:
            audio, sr = sf.read(c["wav"], dtype="float32")
            if audio.ndim > 1: audio = audio.mean(axis=1)
            if sr != 16000:
                import librosa
                audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
            audio = audio.astype(np.float32)
            r_batch = stream_or_batch(audio, pace=False)
            r_paced = stream_or_batch(audio, pace=True)
            hyp = r_batch.get("final") or ""
            wer = None
            if jiwer and c.get("reference") and hyp:
                wer = float(jiwer.wer(c["reference"].lower(), str(hyp).lower()))
            row = {
                "utt_id": c.get("utt_id"), "lang": c.get("lang"),
                "batch": r_batch, "paced": r_paced, "wer": wer, "reference": c.get("reference"),
            }
            rows.append(row)
            if isinstance(r_paced.get("ttfa_s"), float):
                paced_ttfas.append(r_paced["ttfa_s"])
            log(f"{c.get('utt_id')} wer={wer} ttfa_paced={r_paced.get('ttfa_s')} kind={r_batch.get('kind')}")

        status["rows"] = rows
        status["paced_ttfa"] = summarize_ttfas(paced_ttfas)
        status["status"] = "DONE" if any((r.get("batch") or {}).get("ok") for r in rows) else "BLOCKED"
    except Exception:
        status["status"] = "BLOCKED"
        status["error"] = traceback.format_exc()
        log(status["error"][-2500:])

    write_json(OUT / "results.json", status)
    write_summary(OUT, f"""# Item 11 -- NVIDIA Nemotron ASR streaming

**When:** {status['when']}
**Model:** `{MODEL_ID}`
**Status:** {status.get('status')}
**GPU:** {gpu}
**Load_s:** {status.get('load_s')}
**Loader:** {status.get('loader')}

## Paced TTFA
{json.dumps(status.get('paced_ttfa'), indent=2)}

## Rows (abbrev)
""" + "\n".join(
        f"- {r.get('utt_id')}: wer={r.get('wer')} paced_ttfa={(r.get('paced') or {}).get('ttfa_s')} kind={(r.get('batch') or {}).get('kind')}"
        for r in status.get("rows") or []
    ) + f"""

## Error / blockers
{(status.get('error') or 'none')[:2000]}
""")
    z, _ = finalize_pack(OUT, f"pack_item11_nvidia_nemotron_asr_{DATE}.zip")
    print("PACK11", z, status.get("status"), flush=True)

if __name__ == "__main__":
    main()
