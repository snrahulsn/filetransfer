#!/bin/bash
set -u
mkdir -p /workspace/backlog_runs/logs
source /workspace/.hf_token_env 2>/dev/null || true
export HF_HOME=/workspace/hf_cache
export D_CAP_PER_LANG="${D_CAP_PER_LANG:-20}"
export D_TIMEOUT_S="${D_TIMEOUT_S:-1800}"
echo "=== remote_DFE start $(date -Is) ===" | tee /workspace/backlog_runs/logs/remote_DFE.log

# Ensure transformers present before D
python3 -m pip install -q transformers accelerate huggingface_hub torchaudio soundfile jiwer sentencepiece nvidia-cudnn-cu12==9.1.0.70 onnxruntime-gpu==1.19.2 2>&1 | tee -a /workspace/backlog_runs/logs/remote_DFE.log | tail -5

echo "=== JOB D $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log
python3 /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py 2>&1 | tee /workspace/backlog_runs/logs/D.log
echo "=== JOB D rc=${PIPESTATUS[0]} $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log

# Expand to N=100 if micro OK
python3 - <<'PY' && {
import json
from pathlib import Path
p=Path('/workspace/backlog_runs/pack_D_indicconformer_cudnn9/DONE.json')
d=json.loads(p.read_text()) if p.exists() else {}
print('d_check', d)
ok = d.get('ok') and d.get('new_rtf') is not None and d.get('n_ok',0) >= 10 and not d.get('timed_out')
raise SystemExit(0 if ok else 1)
PY
  echo "D micro OK — N=100" | tee -a /workspace/backlog_runs/logs/remote_DFE.log
  export D_CAP_PER_LANG=100 D_TIMEOUT_S=7200
  python3 /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py 2>&1 | tee /workspace/backlog_runs/logs/D100.log
  echo "=== JOB D100 rc=${PIPESTATUS[0]} $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log
}

echo "=== JOB F $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log
python3 /workspace/backlog_runs/scripts/run_F_v2_voxtral_realtime.py 2>&1 | tee /workspace/backlog_runs/logs/F.log
echo "=== JOB F rc=${PIPESTATUS[0]} $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log

echo "=== JOB E $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log
python3 /workspace/backlog_runs/scripts/run_E_v2_voxtral_tts_stream.py 2>&1 | tee /workspace/backlog_runs/logs/E.log
echo "=== JOB E rc=${PIPESTATUS[0]} $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log

touch /workspace/backlog_runs/POD_JOBS_DONE
echo "=== remote_DFE end $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DFE.log
