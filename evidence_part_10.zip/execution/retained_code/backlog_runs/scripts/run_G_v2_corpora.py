#!/usr/bin/env python3
"""G: corpora polish — en_us PROXY (or en_in if available), ur_pk Pakistani, 8k telephony, bank SYNTHETIC."""
from __future__ import annotations
import json, os, sys, traceback, shutil
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now(): return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for p in (Path("/workspace/.hf_token_env"), Path("/workspace/.hf_token_env")):
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "): line = line[7:]
            if "TOKEN=" in line and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HF_DATASETS_AUDIO_DECODER", "soundfile")

OUT = Path("/workspace/corpora_proxies")
PACK = Path("/workspace/backlog_runs/pack_G_corpora_proxies")
OUT.mkdir(parents=True, exist_ok=True); PACK.mkdir(parents=True, exist_ok=True)
CACHE = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")


def from_cache(lang, n, label, out_dir: Path):
    import soundfile as sf
    out_dir.mkdir(parents=True, exist_ok=True)
    src = CACHE / lang
    meta = []
    wavs = sorted(src.glob("*.wav"))[:n] if src.exists() else []
    # also try manifest
    man = CACHE / "manifest_all.jsonl"
    if not wavs and man.exists():
        for line in man.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            if r.get("lang") == lang:
                wavs.append(Path(r["wav"]))
                if len(wavs) >= n:
                    break
    for i, w in enumerate(wavs[:n]):
        w = Path(w)
        if not w.exists():
            continue
        dest = out_dir / f"{lang}_{i:03d}.wav"
        shutil.copy2(w, dest)
        # reference
        text = ""
        for cand in (w.with_suffix(".txt"), out_dir / f"{lang}_{i:03d}.txt"):
            pass
        # pull from manifest if possible
        if man.exists() and not text:
            for line in man.read_text(encoding="utf-8").splitlines():
                r = json.loads(line)
                if Path(r.get("wav","")).name == w.name and r.get("lang") == lang:
                    text = r.get("reference", ""); break
        (out_dir / f"{lang}_{i:03d}.txt").write_text(text.strip() + "\n", encoding="utf-8")
        info = sf.info(str(dest))
        meta.append({"wav": str(dest), "text": text, "sr": info.samplerate, "label": label, "source": str(w)})
    wj(out_dir / "manifest.json", {"label": label, "n": len(meta), "items": meta, "source": str(src)})
    (out_dir / "LABEL.txt").write_text(label + "\n", encoding="utf-8")
    return meta


def try_en_in():
    """Prefer true Indian English if downloadable; else PROXY en_us."""
    note = "FLEURS has no en_in config."
    # Try Common Voice en-IN small slice via datasets if available
    try:
        from datasets import load_dataset, Audio
        import soundfile as sf
        import numpy as np
        out = OUT / "indian_english_commonvoice_en_IN"
        out.mkdir(parents=True, exist_ok=True)
        # mozilla-foundation/common_voice_17_0 config en may not be India-only; try indic_voices / indicTTS if present
        # Attempt: google/fleurs has no en_in — documented. Try ai4bharat/IndicVoices or similar lightly.
        tried = []
        for ds_id, conf, split in [
            ("google/fleurs", "en_in", "test"),  # expected fail
        ]:
            tried.append(f"{ds_id}/{conf}")
            try:
                ds = load_dataset(ds_id, conf, split=f"{split}[:3]", token=os.environ.get("HF_TOKEN"))
                ds = ds.cast_column("audio", Audio(sampling_rate=16000, decode=True))
                meta = []
                for i, row in enumerate(ds):
                    arr = np.asarray(row["audio"]["array"], dtype="float32")
                    sr = int(row["audio"]["sampling_rate"])
                    text = row.get("transcription") or row.get("sentence") or ""
                    wav = out / f"en_in_{i:03d}.wav"
                    sf.write(str(wav), arr, sr)
                    (out / f"en_in_{i:03d}.txt").write_text(str(text).strip() + "\n", encoding="utf-8")
                    meta.append({"wav": str(wav), "text": text, "sr": sr, "label": "Indian_English_en_IN"})
                wj(out / "manifest.json", {"label": "Indian_English_en_IN", "n": len(meta), "items": meta})
                (out / "LABEL.txt").write_text("Indian_English_en_IN\n", encoding="utf-8")
                return meta, f"downloaded {ds_id}/{conf}", tried
            except Exception as e:
                note = f"{ds_id}/{conf} failed: {e}"
        # fallback PROXY
        return None, note, tried
    except Exception as e:
        return None, f"en_in attempt error: {e}", []


def downsample_8k(items, out_dir: Path):
    import soundfile as sf
    import librosa
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for it in items[:8]:
        arr, sr = sf.read(it["wav"], dtype="float32")
        if arr.ndim > 1:
            arr = arr.mean(axis=1)
        arr8 = librosa.resample(arr, orig_sr=sr, target_sr=8000)
        path = out_dir / (Path(it["wav"]).stem + "_8k.wav")
        sf.write(str(path), arr8, 8000)
        (out_dir / (path.stem + ".txt")).write_text(it.get("text", "").strip() + "\n", encoding="utf-8")
        rows.append({
            "wav": str(path), "text": it.get("text", ""), "sr": 8000,
            "label": "8kHz_telephony_PROXY_downsampled", "source": it["wav"],
        })
    wj(out_dir / "manifest.json", {"label": "8kHz_telephony_PROXY_downsampled", "n": len(rows), "items": rows})
    (out_dir / "LABEL.txt").write_text(
        "8kHz_telephony_PROXY_downsampled — NOT native telephony; downsampled from 16 kHz FLEURS\n",
        encoding="utf-8")
    return rows


def synth_bank():
    out = OUT / "bank_call_SYNTHETIC"
    out.mkdir(parents=True, exist_ok=True)
    lines = [
        ("en", "Your one time password is 4 8 2 1 9 3. Please do not share it with anyone."),
        ("en", "Your account ending 1234 has been debited by rupees 15,250 on 21 September 2026."),
        ("hi", "आपका ओ टी पी है ७ ३ १ ५ ९ २। कृपया इसे किसी के साथ साझा न करें।"),
        ("hi", "आपके खाते से २१ सितंबर २०२६ को पंद्रह हज़ार दो सौ पचास रुपये काटे गए हैं।"),
    ]
    items = []
    for i, (lang, text) in enumerate(lines):
        (out / f"bank_{lang}_{i}.txt").write_text(text + "\n", encoding="utf-8")
        items.append({"lang": lang, "text": text, "label": "SYNTHETIC_bank_script", "audio": None})
    wj(out / "manifest.json", {
        "label": "SYNTHETIC_bank_call_scripts",
        "warning": "NOT real bank calls. Text scripts only.",
        "items": items,
    })
    (out / "LABEL.txt").write_text("SYNTHETIC_bank_call_scripts — NOT real bank audio\n", encoding="utf-8")
    return items


def main():
    # ensure deps
    subprocess = __import__("subprocess")
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "soundfile", "librosa", "numpy"], check=False)

    report = {"timestamp": now(), "sections": {}}
    en_in_meta, en_in_note, tried = try_en_in()
    report["sections"]["indian_english_attempt"] = {"note": en_in_note, "tried": tried, "n": len(en_in_meta or [])}

    en = []
    if en_in_meta:
        en = en_in_meta
        report["sections"]["english"] = {"n": len(en), "label": "en_IN"}
    else:
        en = from_cache("en_us", 5, "English_FLEURS_en_us_PROXY_NOT_en_IN", OUT / "english_fleurs_en_us_PROXY")
        report["sections"]["english"] = {
            "n": len(en),
            "label": "FLEURS en_us PROXY (NOT Indian English — FLEURS has no en_in)",
        }

    ur = from_cache("ur_pk", 5, "Pakistani_Urdu_FLEURS_ur_pk_NOT_Indian", OUT / "urdu_ur_pk_PAKISTANI")
    report["sections"]["urdu"] = {"n": len(ur), "label": "FLEURS ur_pk PAKISTANI (not India-locale)"}

    hi = from_cache("hi_in", 5, "Hindi_FLEURS_hi_in", OUT / "hindi_hi_in")
    report["sections"]["hindi"] = {"n": len(hi), "label": "FLEURS hi_in"}

    tel = downsample_8k(en + hi, OUT / "telephony_8k_PROXY")
    report["sections"]["telephony_8k"] = {
        "n": len(tel),
        "label": "8kHz_telephony_PROXY_downsampled",
        "note": "Downsampled from 16 kHz; not native telephony corpus",
    }

    bank = synth_bank()
    report["sections"]["bank_call"] = {"n": len(bank), "label": "SYNTHETIC"}

    wj(OUT / "SUMMARY.json", report)
    wj(PACK / "SUMMARY.json", report)
    md = f"# Corpora proxies\n\n**When:** {now()}\n\n"
    for k, v in report["sections"].items():
        md += f"- **{k}:** {v}\n"
    md += "\nLabels explicit. ur_pk=Pakistani. Bank=SYNTHETIC. en_us≠Indian English unless en_IN succeeded.\n"
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    (PACK / "SUMMARY.md").write_text(md, encoding="utf-8")
    wj(PACK / "DONE.json", {"ok": True, "time": now(), "telephony_n": len(tel)})
    print("G_DONE", report, flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "error": err[-2000:]})
        raise
