#!/usr/bin/env python3
"""Shared pack finalization: SUMMARY folder + zip + SHA256SUMS under packs_local."""
from __future__ import annotations
import hashlib, json, shutil, zipfile
from pathlib import Path

PACKS = Path("/workspace/backlog_runs/packs_local")
DATE = "2026-09-22"

def sha_dir(d: Path):
    lines = []
    for p in sorted(d.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS":
            lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(d)}")
    (d / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="ascii", errors="replace")

def write_summary(d: Path, text: str):
    # ASCII-safe: replace common unicode dashes
    text = text.replace("\u2014", "--").replace("\u2013", "-").replace("\u2018", "'").replace("\u2019", "'").replace("\u201c", '"').replace("\u201d", '"')
    (d / "SUMMARY.md").write_text(text, encoding="ascii", errors="replace")

def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

def finalize_pack(work: Path, zip_name: str):
    """Copy work dir to packs_local/<zip_stem>/ and zip it."""
    PACKS.mkdir(parents=True, exist_ok=True)
    stem = zip_name.replace(".zip", "")
    dest = PACKS / stem
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(work, dest)
    sha_dir(dest)
    zpath = PACKS / f"{stem}.zip"
    if zpath.exists():
        zpath.unlink()
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(dest.rglob("*")):
            if p.is_file():
                z.write(p, f"{stem}/{p.relative_to(dest)}")
    return zpath, dest
