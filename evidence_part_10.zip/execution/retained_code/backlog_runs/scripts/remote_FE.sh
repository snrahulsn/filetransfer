#!/bin/bash
set -u
source /workspace/.hf_token_env 2>/dev/null || true
export HF_HOME=/workspace/hf_cache
mkdir -p /workspace/backlog_runs/logs
echo "=== FE start $(date -Is) ===" | tee /workspace/backlog_runs/logs/remote_FE.log
# Ensure system vllm + transformers restored for F (may have been pinned down)
python3 -m pip install -q -U 'transformers>=4.51' 'huggingface_hub' 'tokenizers' 2>&1 | tail -5
python3 /workspace/backlog_runs/scripts/run_F_v3_realtime.py 2>&1 | tee /workspace/backlog_runs/logs/F.log
echo "=== F rc=${PIPESTATUS[0]} $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_FE.log
python3 /workspace/backlog_runs/scripts/run_E_v3_tts_stream.py 2>&1 | tee /workspace/backlog_runs/logs/E.log
echo "=== E rc=${PIPESTATUS[0]} $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_FE.log
touch /workspace/backlog_runs/POD_JOBS_DONE
echo "=== FE end $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_FE.log
