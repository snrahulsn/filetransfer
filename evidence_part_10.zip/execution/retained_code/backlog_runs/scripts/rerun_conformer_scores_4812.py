#!/usr/bin/env python3
"""Re-score item4 Odia wavs + items 8/12 with fixed Conformer device=cuda."""
from __future__ import annotations
import json, os, sys, traceback, re
from pathlib import Path
sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np, torch, soundfile as sf, jiwer
from transformers import AutoModel

ASR_ID = "ai4bharat/indic-conformer-600m-multilingual"
LANG_MAP = {
    "as":"as","as-IN":"as","bn":"bn","bn-IN":"bn","gu":"gu","gu-IN":"gu",
    "hi":"hi","hi-IN":"hi","kn":"kn","kn-IN":"kn","ml":"ml","ml-IN":"ml",
    "mr":"mr","mr-IN":"mr","or":"or","or-IN":"or","pa":"pa","pa-IN":"pa",
    "ta":"ta","ta-IN":"ta","te":"te","te-IN":"te","en":"en","en-IN":"en","en-US":"en",
}

def norm(t):
    return re.sub(r"\s+", " ", (t or "").strip())

def transcribe(model, wav_path, lang):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        try:
            import torchaudio
            wav = torch.from_numpy(np.asarray(audio, dtype=np.float32)).unsqueeze(0)
            audio = torchaudio.functional.resample(wav, sr, 16000).squeeze(0).cpu().numpy()
        except Exception:
            # linear resample fallback (np already imported at module level)
            n = int(round(len(audio) * 16000 / float(sr)))
            xp = np.linspace(0, 1, num=len(audio), endpoint=False)
            xq = np.linspace(0, 1, num=n, endpoint=False)
            audio = np.interp(xq, xp, np.asarray(audio, dtype=np.float64)).astype(np.float32)
    tensor = torch.from_numpy(np.asarray(audio, dtype=np.float32)).unsqueeze(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    with torch.inference_mode():
        out = model(tensor.to(device), lang, "ctc")
    if isinstance(out, (list, tuple)):
        out = out[0]
    if isinstance(out, dict):
        out = out.get("text") or out.get("transcript") or str(out)
    return str(out)

def score_one(model, wav, ref, lang, vendor, meta=None):
    conf_lang = LANG_MAP.get(lang) or LANG_MAP.get(lang.replace("_", "-")) or lang.split("-")[0].lower()
    rec = {"vendor": vendor, "wav": str(wav), "lang": lang, "conformer_lang": conf_lang,
           "reference": ref, "meta": meta or {}}
    try:
        hyp = transcribe(model, wav, conf_lang)
        rec["hypothesis"] = hyp
        rec["wer"] = float(jiwer.wer(norm(ref), norm(hyp))) if ref and hyp is not None else None
        rec["cer"] = float(jiwer.cer(norm(ref), norm(hyp))) if ref and hyp is not None else None
        rec["ok"] = True
    except Exception as e:
        rec["ok"] = False
        rec["error"] = f"{type(e).__name__}: {e}"
    return rec

def load_whisper_prior(vendor_dir):
    p = Path(vendor_dir) / "asr_metrics.json"
    if not p.exists():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    out = {}
    for r in data.get("results", []):
        loc = r.get("locale") or r.get("lang")
        out[loc] = {"whisper_wer": r.get("WER"), "whisper_cer": r.get("CER"),
                    "whisper_transcript": r.get("transcript"), "reference": r.get("reference")}
    return out

def collect_vendor(name, wav_dir, asr_dir=None):
    wav_dir = Path(wav_dir)
    priors = load_whisper_prior(asr_dir or wav_dir.parent)
    items = []
    if priors:
        for loc, meta in priors.items():
            short = loc.split("-")[0]
            cands = list(wav_dir.glob(f"{loc}*.wav")) + list(wav_dir.glob(f"{short}.wav")) + list(wav_dir.glob(f"{loc}.wav"))
            wav = next((c for c in cands if c.exists()), None)
            if wav is None or not meta.get("reference"):
                continue
            items.append({"wav": str(wav), "ref": meta.get("reference"), "lang": loc, "meta": meta})
    return name, items

def main():
    gpu = nvidia_info()
    print("load", ASR_ID, flush=True)
    model = AutoModel.from_pretrained(ASR_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])

    # Item 4
    d4 = Path(f"/workspace/backlog_runs/item_workspaces/pack_item04_indicf5_odia_resynth_{DATE}")
    payload4 = json.loads((d4 / "results.json").read_text())
    for r in payload4.get("results", []):
        if not r.get("ok"):
            continue
        try:
            hyp = transcribe(model, r["wav"], "or")
            r["hypothesis"] = hyp
            r["wer"] = float(jiwer.wer(norm(r["text"]), norm(hyp))) if hyp is not None else 1.0
            r["cer"] = float(jiwer.cer(norm(r["text"]), norm(hyp))) if hyp is not None else 1.0
            r.pop("asr_error", None)
            print("I4", r["id"], r.get("duration_s"), r["wer"], flush=True)
        except Exception:
            r["asr_error"] = traceback.format_exc()
            print("I4 FAIL", r["id"], flush=True)
            print(r["asr_error"][-500:], flush=True)
    prior = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs/wavs/or-IN.wav")
    short = "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।"
    if prior.exists():
        try:
            hyp = transcribe(model, prior, "or")
            payload4["prior_short"] = {
                "id": "or_prior_short", "wav": str(prior), "text": short,
                "duration_s": sf.info(str(prior)).duration, "hypothesis": hyp,
                "wer": float(jiwer.wer(norm(short), norm(hyp or ""))) if hyp else 1.0,
                "cer": float(jiwer.cer(norm(short), norm(hyp or ""))) if hyp else 1.0,
            }
            print("I4 prior", payload4["prior_short"]["wer"], flush=True)
        except Exception as e:
            payload4["prior_short"] = {"id": "or_prior_short", "error": str(e)}
    payload4["when"] = ist_now()
    payload4["rescored"] = True
    write_json(d4 / "results.json", payload4)
    lines = ["| id | duration_s | WER | CER |", "|----|------------|-----|-----|"]
    for r in payload4.get("results", []):
        lines.append("| {} | {} | {} | {} |".format(r.get("id"), r.get("duration_s"), r.get("wer"), r.get("cer")))
    write_summary(d4, "# Item 4 -- IndicF5 Odia re-synthesis\n\n**When:** {}\n**Status:** DONE (rescored)\n**ASR:** `{}`\n\n## New longer synth\n{}\n\n## Prior short\n{}\n\nNote: Longer Odia text still yielded ~1.6s IndicF5 audio.\n".format(
        payload4["when"], ASR_ID, "\n".join(lines), json.dumps(payload4.get("prior_short"), ensure_ascii=False, indent=2)))
    finalize_pack(d4, "pack_item04_indicf5_odia_resynth_{}.zip".format(DATE))

    # Item 8 Kokoro
    root = Path("/workspace/kokoro_hindi_english_probe")
    res = json.loads((root / "results.json").read_text(encoding="utf-8"))
    k_rows = []
    for it in res.get("items", []):
        wav = it["path"] if Path(it["path"]).exists() else str(root / "wavs" / Path(it["path"]).name)
        if not Path(wav).exists():
            continue
        rec = score_one(model, wav, it["text"], "en", "kokoro",
                        {"kokoro_lang_code": it.get("lang_code"), "voice": it.get("voice"), "index": it.get("index")})
        k_rows.append(rec)
        print("K", Path(wav).name, rec.get("wer"), flush=True)
    d8 = Path(" /workspace/backlog_runs/item_workspaces/pack_item08_kokoro_intelligibility_wer_{}".format(DATE).strip())
    d8 = Path(f"/workspace/backlog_runs/item_workspaces/pack_item08_kokoro_intelligibility_wer_{DATE}")
    d8.mkdir(parents=True, exist_ok=True)
    (d8 / "wavs").mkdir(exist_ok=True)
    import shutil
    for it in res.get("items", [])[:3]:
        src = Path(it["path"]) if Path(it["path"]).exists() else root / "wavs" / Path(it["path"]).name
        if src.exists():
            shutil.copy2(src, d8 / "wavs" / src.name)
    wers = [r["wer"] for r in k_rows if isinstance(r.get("wer"), float)]
    k_payload = {
        "item": 8, "when": ist_now(), "gpu": gpu, "asr_id": ASR_ID, "n": len(k_rows),
        "wer_mean": float(np.mean(wers)) if wers else None, "rows": k_rows,
        "prior_whisper": "not present in kokoro probe; Conformer lang=en on English orthography",
    }
    write_json(d8 / "results.json", k_payload)
    tlines = ["| wav | voice | WER | CER |", "|-----|-------|-----|-----|"]
    for r in k_rows:
        tlines.append("| {} | {} | {} | {} |".format(Path(r["wav"]).name, (r.get("meta") or {}).get("voice"), r.get("wer"), r.get("cer")))
    write_summary(d8, "# Item 8 -- Kokoro intelligibility WER\n\n**When:** {}\n**Status:** DONE\n**WER mean:** {}\n\n{}\n\n## Prior Whisper\n{}\n".format(
        k_payload["when"], k_payload["wer_mean"], "\n".join(tlines), k_payload["prior_whisper"]))
    finalize_pack(d8, f"pack_item08_kokoro_intelligibility_wer_{DATE}.zip")

    # Item 12
    vendors = [
        collect_vendor("pocket_tts", "/workspace/pocket_tts_qual/wavs", "/workspace/pocket_tts_qual"),
        collect_vendor("svara_tts", "/workspace/svara_tts_qual/wavs", "/workspace/svara_tts_qual"),
        collect_vendor("sooktam2", "/workspace/sooktam2_qual/wavs", "/workspace/sooktam2_qual"),
        collect_vendor("bodhan", "/workspace/bodhan_indic_speak_qual/wavs", "/workspace/bodhan_indic_speak_qual"),
        collect_vendor("voxtral_tts", "/workspace/voxtral_tts_qual/wavs", "/workspace/voxtral_tts_qual"),
    ]
    all_rows = []
    for vname, items in vendors:
        for it in items:
            short = LANG_MAP.get(it["lang"]) or it["lang"].split("-")[0].lower()
            if short not in {"as","bn","gu","hi","kn","ml","mr","or","pa","ta","te","en"}:
                continue
            rec = score_one(model, it["wav"], it["ref"], it["lang"], vname, it.get("meta"))
            all_rows.append(rec)
            print("V12", vname, it["lang"], rec.get("wer"), flush=True)
    rollup = {}
    for r in all_rows:
        key = f"{r['vendor']}/{r['conformer_lang']}"
        rollup.setdefault(key, []).append(r)
    rollup_mean = {
        k: {"n": len(v),
            "wer_mean": float(np.mean([x["wer"] for x in v if isinstance(x.get("wer"), float)])) if v else None,
            "cer_mean": float(np.mean([x["cer"] for x in v if isinstance(x.get("cer"), float)])) if v else None}
        for k, v in rollup.items()
    }
    by_vendor = {}
    for r in all_rows:
        by_vendor.setdefault(r["vendor"], []).append(r)
    vendor_mean = {
        k: {"n": len(v), "wer_mean": float(np.mean([x["wer"] for x in v if isinstance(x.get("wer"), float)])) if v else None}
        for k, v in by_vendor.items()
    }
    d12 = Path(f"/workspace/backlog_runs/item_workspaces/pack_item12_indicconformer_tie_score_{DATE}")
    d12.mkdir(parents=True, exist_ok=True)
    payload = {"item": 12, "when": ist_now(), "gpu": gpu, "asr_id": ASR_ID, "n_scored": len(all_rows),
               "rollup_vendor_lang": rollup_mean, "rollup_vendor": vendor_mean, "rows": all_rows}
    write_json(d12 / "results.json", payload)
    lines = ["| vendor/lang | n | WER mean | CER mean |", "|---|---|---|---|"]
    for k in sorted(rollup_mean):
        r = rollup_mean[k]
        lines.append("| {} | {} | {} | {} |".format(k, r["n"], r["wer_mean"], r["cer_mean"]))
    write_summary(d12, "# Item 12 -- IndicConformer tie-score\n\n**When:** {}\n**Status:** DONE\n**n_scored:** {}\n\n## Rollup\n{}\n\n## Vendor means\n{}\n".format(
        payload["when"], payload["n_scored"], "\n".join(lines), json.dumps(vendor_mean, indent=2)))
    finalize_pack(d12, f"pack_item12_indicconformer_tie_score_{DATE}.zip")
    print("DONE all rescores", flush=True)

if __name__ == "__main__":
    main()
