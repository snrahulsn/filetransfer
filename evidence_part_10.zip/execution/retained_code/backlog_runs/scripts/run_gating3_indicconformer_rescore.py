#!/usr/bin/env python3
"""Gating #3: Re-ASR TTS outputs with IndicConformer-600M (NOT Whisper). ORT thread isolation."""
from __future__ import annotations
import json, os, sys, time, traceback, glob, subprocess
from pathlib import Path

# ORT / BLAS thread isolation BEFORE importing ORT/torch-heavy stacks
for k, v in {
    "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1", "ORT_NUM_THREADS": "1",
    "OMP_WAIT_POLICY": "PASSIVE", "TOKENIZERS_PARALLELISM": "false",
}.items():
    os.environ[k] = v

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

OUT = Path("/workspace/backlog_runs/pack_gating3_indicconformer_rescore")
OUT.mkdir(parents=True, exist_ok=True)
REPO = "ai4bharat/indic-conformer-600m-multilingual"

# Locale → IndicConformer language id (ISO-ish short codes used by the model)
# Void Whisper langs called out: ml/bn/mr/te/or -- plus all IndicF5 official locales we can.
LANG_MAP = {
    "as-IN": "as", "bn-IN": "bn", "gu-IN": "gu", "hi-IN": "hi", "kn-IN": "kn",
    "ml-IN": "ml", "mr-IN": "mr", "or-IN": "or", "pa-IN": "pa", "ta-IN": "ta",
    "te-IN": "te",
    # parler / others sometimes use underscore
    "as_in": "as", "bn_in": "bn", "gu_in": "gu", "hi_in": "hi", "kn_in": "kn",
    "ml_in": "ml", "mr_in": "mr", "or_in": "or", "pa_in": "pa", "ta_in": "ta",
    "te_in": "te",
}

VOID_WHISPER_LANGS = {"ml", "bn", "mr", "te", "or"}  # figures VOID until this rescore


def install_ort():
    log = []
    if os.environ.get('SKIP_GATING3_PIP') == '1':
        write_json(OUT / 'install.json', {'skipped': True})
        return log
    cmds = [
        [sys.executable, "-m", "pip", "install", "-q", "nvidia-cudnn-cu12==9.1.0.70"],
        [sys.executable, "-m", "pip", "install", "-q", "onnxruntime-gpu==1.19.2"],
        [sys.executable, "-m", "pip", "install", "-q", "transformers==4.46.3", "accelerate",
         "huggingface_hub", "soundfile", "jiwer", "sentencepiece", "numpy", "librosa"],
    ]
    for c in cmds:
        p = subprocess.run(c, capture_output=True, text=True)
        log.append({"cmd": " ".join(c), "rc": p.returncode, "err": (p.stderr or "")[-300:]})
    cands = (
        glob.glob("/usr/local/lib/python*/dist-packages/nvidia/cudnn/lib")
        + glob.glob(str(Path(sys.prefix) / "lib/python*/site-packages/nvidia/cudnn/lib"))
        + glob.glob("/usr/local/lib/python*/dist-packages/nvidia/cublas/lib")
        + glob.glob(str(Path(sys.prefix) / "lib/python*/site-packages/nvidia/cublas/lib"))
    )
    if cands:
        os.environ["LD_LIBRARY_PATH"] = ":".join(dict.fromkeys(cands)) + ":" + os.environ.get("LD_LIBRARY_PATH", "")
    write_json(OUT / "install.json", {"log": log, "ld": os.environ.get("LD_LIBRARY_PATH", "")[:500]})
    return log


def patch_ort():
    import onnxruntime as ort
    Orig = ort.InferenceSession
    def wrapped(path_or_bytes, sess_options=None, providers=None, provider_options=None, **kw):
        so = sess_options or ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        try:
            so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        except Exception:
            pass
        if providers is None:
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        print(f"[ORT-PATCH] providers={providers} threads=1", flush=True)
        return Orig(path_or_bytes, sess_options=so, providers=providers, provider_options=provider_options, **kw)
    ort.InferenceSession = wrapped
    return ort.__version__, list(ort.get_available_providers())


def wer_cer(ref, hyp):
    import jiwer
    ref = (ref or "").strip()
    hyp = (hyp or "").strip()
    if not ref:
        return {"wer": None, "cer": None}
    if not hyp:
        return {"wer": 1.0, "cer": 1.0}
    return {
        "wer": float(jiwer.wer(ref, hyp)),
        "cer": float(jiwer.cer(ref, hyp)),
    }


def collect_tts_items():
    """Collect TTS wavs that fed Whisper lang scores (IndicF5 + parler for void langs)."""
    items = []
    # Prefer NEW per-locale IndicF5 pack if present
    g2 = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs")
    if (g2 / "results.json").exists():
        data = json.loads((g2 / "results.json").read_text(encoding="utf-8"))
        for r in data.get("results", []):
            if r.get("ok") and r.get("wav"):
                items.append({
                    "pack": "indicf5_locale_refs",
                    "tts": "ai4bharat/IndicF5",
                    "locale": r["locale"],
                    "wav": r["wav"],
                    "reference": r["sentence"],
                })
    # Always also score prior IndicF5 shared-ref wavs (for comparison / completeness)
    old = Path("/workspace/indic_f5_qual")
    old_res = old / "results.json"
    if old_res.exists():
        data = json.loads(old_res.read_text(encoding="utf-8"))
        # results may be list or under key
        rows = data.get("results") if isinstance(data, dict) else data
        wav_dir = old / "wavs"
        for r in rows or []:
            loc = r.get("locale")
            wav = wav_dir / f"{loc}.wav"
            if not wav.exists():
                continue
            # skip if already have locale_refs version as primary; still include as prior_shared_ref
            items.append({
                "pack": "indicf5_prior_shared_ref",
                "tts": "ai4bharat/IndicF5",
                "locale": loc,
                "wav": str(wav),
                "reference": r.get("sentence") or r.get("text"),
            })
    # Indic Parler for void langs
    parler = Path("/workspace/indic_parler_qual")
    if (parler / "results.json").exists():
        data = json.loads((parler / "results.json").read_text(encoding="utf-8"))
        rows = data.get("results") if isinstance(data, dict) else data
        for r in rows or []:
            loc = r.get("locale") or r.get("id")
            if not loc:
                continue
            code = LANG_MAP.get(loc) or LANG_MAP.get(str(loc).replace("_", "-"))
            # normalize
            short = (LANG_MAP.get(loc) or "")
            if short not in VOID_WHISPER_LANGS and loc.split("-")[0].lower() not in VOID_WHISPER_LANGS:
                # still include if wav exists under void set only? Task: re-ASR all relevant that fed ml/bn/mr/te/or
                loc_short = loc.split("-")[0].lower().split("_")[0]
                if loc_short not in VOID_WHISPER_LANGS:
                    continue
            wav = r.get("wav") or str(parler / "wavs" / f"{loc}.wav")
            if not Path(wav).exists():
                alt = parler / "wavs" / f"{loc}.wav"
                if alt.exists():
                    wav = str(alt)
                else:
                    continue
            items.append({
                "pack": "indic_parler",
                "tts": "ai4bharat/indic-parler-tts",
                "locale": loc,
                "wav": wav,
                "reference": r.get("sentence") or r.get("text") or r.get("prompt"),
            })
    # Dedup by (pack, locale)
    seen = set()
    uniq = []
    for it in items:
        k = (it["pack"], it["locale"])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(it)
    return uniq


def transcribe(model, wav, lang):
    """IndicASRModel.forward(wav, lang, decoding='ctc') -- positional lang (NOT language=)."""
    import numpy as np
    import soundfile as sf
    import librosa
    import torch
    audio, sr = sf.read(wav, dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    # Match pack_D torchaudio.load shape: [1, T] (batch/channel, samples)
    tensor = torch.from_numpy(np.asarray(audio, dtype=np.float32)).unsqueeze(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    with torch.inference_mode():
        out = model(tensor.to(device), lang, "ctc")
    if isinstance(out, (list, tuple)):
        out = out[0]
    if isinstance(out, dict):
        out = out.get("text") or out.get("transcript") or str(out)
    return str(out)


def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    install_ort()
    ort_ver, providers = patch_ort()
    print("ORT", ort_ver, providers, flush=True)

    from transformers import AutoModel
    print("Loading", REPO, flush=True)
    t0 = time.perf_counter()
    model = AutoModel.from_pretrained(REPO, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    load_s = time.perf_counter() - t0
    print("loaded", load_s, flush=True)

    items = collect_tts_items()
    write_json(OUT / "inputs.json", items)
    print("items", len(items), flush=True)

    scored = []
    by_lang = {}
    for it in items:
        loc = it["locale"]
        lang = LANG_MAP.get(loc) or LANG_MAP.get(loc.replace("-", "_")) or loc.split("-")[0].lower()
        rec = dict(it)
        rec["conformer_lang"] = lang
        rec["whisper_superseded"] = lang in VOID_WHISPER_LANGS
        try:
            t1 = time.perf_counter()
            hyp = transcribe(model, it["wav"], lang)
            if isinstance(hyp, dict):
                hyp = hyp.get("text") or hyp.get("transcript") or str(hyp)
            hyp = str(hyp)
            metrics = wer_cer(it.get("reference") or "", hyp)
            rec.update({"ok": True, "hypothesis": hyp, **metrics, "asr_s": time.perf_counter() - t1})
            print(f"OK {it['pack']} {loc} WER={metrics['wer']} CER={metrics['cer']}", flush=True)
        except Exception as e:
            rec.update({"ok": False, "error": f"{type(e).__name__}: {e}\n{traceback.format_exc()[-500:]}"})
            print("FAIL", loc, e, flush=True)
        scored.append(rec)
        by_lang.setdefault(lang, []).append(rec)

    # Per-lang rollup (prefer locale_refs pack for IndicF5 primary numbers)
    rollup = {}
    for lang, rows in by_lang.items():
        primary = [r for r in rows if r.get("pack") == "indicf5_locale_refs" and r.get("ok")]
        use = primary if primary else [r for r in rows if r.get("ok")]
        wers = [r["wer"] for r in use if r.get("wer") is not None]
        cers = [r["cer"] for r in use if r.get("cer") is not None]
        rollup[lang] = {
            "n": len(use),
            "wer_mean": sum(wers) / len(wers) if wers else None,
            "cer_mean": sum(cers) / len(cers) if cers else None,
            "whisper_superseded": lang in VOID_WHISPER_LANGS,
            "sources": sorted({r["pack"] for r in use}),
        }

    out = {
        "when": ist_now(),
        "asr_model": REPO,
        "gpu": gpu,
        "ort": {"version": ort_ver, "providers": providers, "thread_isolation": True},
        "load_s": load_s,
        "whisper_void_langs": sorted(VOID_WHISPER_LANGS),
        "note": "Whisper ml/bn/mr/te/or figures SUPERSEDED by IndicConformer-600M scores below.",
        "rollup_per_lang": rollup,
        "scored": scored,
    }
    write_json(OUT / "results.json", out)
    lines = [
        f"# Gating #3 -- IndicConformer-600M re-ASR (Whisper superseded)\n\n",
        f"**When:** {out['when']}\n**ASR:** `{REPO}`\n**ORT thread isolation:** yes (intra/inter=1)\n\n",
        "## Per-lang WER/CER (primary = IndicF5 locale-refs when available)\n\n",
        "| Lang | n | WER | CER | Whisper status |\n|------|---|-----|-----|----------------|\n",
    ]
    for lang in sorted(rollup):
        r = rollup[lang]
        st = "SUPERSEDED" if r["whisper_superseded"] else "re-scored"
        lines.append(f"| {lang} | {r['n']} | {r['wer_mean']} | {r['cer_mean']} | {st} |\n")
    lines.append("\nPrior Whisper numbers for ml/bn/mr/te/or are **VOID / SUPERSEDED**.\n")
    (OUT / "SUMMARY.md").write_text("".join(lines), encoding="utf-8")
    write_json(OUT / "DONE.json", {"ok": True, "n_scored": len(scored), "rollup": rollup})
    print("DONE", rollup, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        write_json(OUT / "DONE.json", {"ok": False, "error": traceback.format_exc()})
        raise
