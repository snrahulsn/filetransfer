#!/usr/bin/env python3
"""A: Maya1+Veena synth + Whisper WER. B: streaming TTFA / cancel / concurrency."""
from __future__ import annotations

import os
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import (
    ist_now,
    write_json,
    load_hf_token,
    nvidia_info,
    summarize_ttfas,
    save_wav,
)

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGINGFACE_HUB_CACHE", "/workspace/hf_cache/hub")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from snac import SNAC

AUDIO_MAYA = Path("/workspace/audio/maya1")
AUDIO_VEENA = Path("/workspace/audio/veena")
SUITE_MAYA = Path("/workspace/tts_streaming_suite/maya1")
SUITE_VEENA = Path("/workspace/tts_streaming_suite/veena_maya")
PACK = Path("/workspace/backlog_runs/pack_A_maya1_veena_synth_asr")
for p in (
    AUDIO_MAYA,
    AUDIO_VEENA,
    SUITE_MAYA / "samples",
    SUITE_VEENA / "samples",
    PACK,
):
    p.mkdir(parents=True, exist_ok=True)

CODE_START, CODE_END = 128257, 128258
SOH, EOH, SOA = 128259, 128260, 128261
START_HUMAN, END_HUMAN, START_AI, END_AI = 128259, 128260, 128261, 128262
TEXT_EOT = 128009
SNAC_MIN, SNAC_MAX = 128266, 156937
AUDIO_BASE = 128266
CODE_OFFSET = 128266


def decode_snac_maya(snac_model, tokens):
    if not tokens:
        return np.zeros(0, np.float32)
    frames = len(tokens) // 7
    tokens = tokens[: frames * 7]
    if frames == 0:
        return np.zeros(0, np.float32)
    l1, l2, l3 = [], [], []
    for i in range(frames):
        s = tokens[i * 7 : (i + 1) * 7]
        l1.append((s[0] - CODE_OFFSET) % 4096)
        l2.extend([(s[1] - CODE_OFFSET) % 4096, (s[4] - CODE_OFFSET) % 4096])
        l3.extend(
            [
                (s[2] - CODE_OFFSET) % 4096,
                (s[3] - CODE_OFFSET) % 4096,
                (s[5] - CODE_OFFSET) % 4096,
                (s[6] - CODE_OFFSET) % 4096,
            ]
        )
    device = next(snac_model.parameters()).device
    codes = [
        torch.tensor(lv, dtype=torch.long, device=device).unsqueeze(0)
        for lv in (l1, l2, l3)
    ]
    with torch.inference_mode():
        z = snac_model.quantizer.from_codes(codes)
        audio = snac_model.decoder(z)[0, 0].detach().float().cpu().numpy()
    if len(audio) > 2048:
        audio = audio[2048:]
    return audio.astype(np.float32)


def decode_snac_veena(snac_model, tokens):
    if not tokens or len(tokens) % 7 != 0:
        return np.zeros(0, np.float32)
    device = next(snac_model.parameters()).device
    codes_lvl = [[], [], []]
    offs = [AUDIO_BASE + i * 4096 for i in range(7)]
    for i in range(0, len(tokens), 7):
        codes_lvl[0].append(tokens[i] - offs[0])
        codes_lvl[1].append(tokens[i + 1] - offs[1])
        codes_lvl[1].append(tokens[i + 4] - offs[4])
        codes_lvl[2].append(tokens[i + 2] - offs[2])
        codes_lvl[2].append(tokens[i + 3] - offs[3])
        codes_lvl[2].append(tokens[i + 5] - offs[5])
        codes_lvl[2].append(tokens[i + 6] - offs[6])
    hierarchical = [
        torch.tensor(lv, dtype=torch.int32, device=device).unsqueeze(0)
        for lv in codes_lvl
    ]
    with torch.inference_mode():
        audio = snac_model.decode(hierarchical)
    return audio.squeeze().clamp(-1, 1).float().cpu().numpy().astype(np.float32)


def build_maya_prompt(tokenizer, description, text):
    soh = tokenizer.decode([SOH])
    eoh = tokenizer.decode([EOH])
    soa = tokenizer.decode([SOA])
    sos = tokenizer.decode([CODE_START])
    eot = tokenizer.decode([TEXT_EOT])
    bos = tokenizer.bos_token or ""
    return soh + bos + f'<description="{description}"> {text}' + eot + eoh + soa + sos


def sample_next(logits, temperature=0.4, top_p=0.9):
    logits = logits / temperature
    probs = torch.softmax(logits, dim=-1)
    sorted_probs, sorted_idx = torch.sort(probs, descending=True)
    cum = torch.cumsum(sorted_probs, dim=-1)
    mask = cum > top_p
    mask[..., 1:] = mask[..., :-1].clone()
    mask[..., 0] = False
    sorted_probs = sorted_probs.masked_fill(mask, 0.0)
    sorted_probs = sorted_probs / sorted_probs.sum(dim=-1, keepdim=True).clamp_min(1e-12)
    pick = torch.multinomial(sorted_probs, 1)
    return sorted_idx.gather(-1, pick)


def maya_token_stream(model, tokenizer, snac, description, text, max_new=500, cancel_after=None):
    prompt = build_maya_prompt(tokenizer, description, text)
    generated = tokenizer(prompt, return_tensors="pt")["input_ids"].to(model.device)
    t0 = time.perf_counter()
    ttfa = None
    chunks = []
    snac_buf = []
    cancelled = False
    err = None
    try:
        past = None
        with torch.inference_mode():
            for _ in range(max_new):
                if (
                    cancel_after is not None
                    and ttfa is not None
                    and (time.perf_counter() - t0) >= cancel_after
                ):
                    cancelled = True
                    break
                outs = model(
                    input_ids=generated if past is None else generated[:, -1:],
                    past_key_values=past,
                    use_cache=True,
                )
                past = outs.past_key_values
                next_id = sample_next(outs.logits[:, -1, :])
                tok = int(next_id.item())
                generated = torch.cat([generated, next_id], dim=-1)
                if tok == CODE_END:
                    break
                if SNAC_MIN <= tok <= SNAC_MAX:
                    snac_buf.append(tok)
                    if len(snac_buf) >= 7 and len(snac_buf) % 7 == 0:
                        piece = decode_snac_maya(snac, snac_buf[-7:])
                        if piece.size:
                            if ttfa is None:
                                ttfa = time.perf_counter() - t0
                            chunks.append(piece)
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
    total = time.perf_counter() - t0
    audio = np.concatenate(chunks) if chunks else np.zeros(0, np.float32)
    return audio, {
        "ok": err is None and (audio.size > 0 or cancelled),
        "error": err,
        "cancelled": cancelled,
        "ttfa_s": ttfa,
        "total_s": total,
        "n_chunks": len(chunks),
        "audio_duration_s": float(len(audio) / 24000) if len(audio) else 0.0,
        "sample_rate": 24000,
        "streaming": True,
        "stream_kind": "hf_token_stream_snac7",
        "n_snac": len(snac_buf),
        "note": "Official prod path is vLLM+SNAC; HF token-stream used for honest first-chunk TTFA",
    }


def maya_batch(model, tokenizer, snac, description, text, max_new=900):
    prompt = build_maya_prompt(tokenizer, description, text)
    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    t0 = time.perf_counter()
    with torch.inference_mode():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new,
            min_new_tokens=28,
            temperature=0.4,
            top_p=0.9,
            repetition_penalty=1.1,
            do_sample=True,
            eos_token_id=CODE_END,
            pad_token_id=tokenizer.pad_token_id,
        )
    gen = out[0, inputs["input_ids"].shape[1] :].tolist()
    snac_tokens = [t for t in gen if SNAC_MIN <= t <= SNAC_MAX]
    audio = decode_snac_maya(snac, snac_tokens)
    total = time.perf_counter() - t0
    return audio, {
        "ttfa_s": total,
        "total_s": total,
        "n_snac": len(snac_tokens),
        "streaming": False,
        "stream_kind": "batch_generate",
        "audio_duration_s": float(len(audio) / 24000) if len(audio) else 0.0,
    }


def veena_token_stream(model, tokenizer, snac, text, speaker="kavya", max_new=400, cancel_after=None):
    prompt = f"<spk_{speaker}> {text}"
    prompt_tokens = tokenizer.encode(prompt, add_special_tokens=False)
    input_tokens = [START_HUMAN, *prompt_tokens, END_HUMAN, START_AI, CODE_START]
    generated = torch.tensor([input_tokens], device=model.device)
    t0 = time.perf_counter()
    ttfa = None
    chunks = []
    snac_buf = []
    cancelled = False
    err = None
    try:
        past = None
        with torch.inference_mode():
            for _ in range(max_new):
                if (
                    cancel_after is not None
                    and ttfa is not None
                    and (time.perf_counter() - t0) >= cancel_after
                ):
                    cancelled = True
                    break
                outs = model(
                    input_ids=generated if past is None else generated[:, -1:],
                    past_key_values=past,
                    use_cache=True,
                )
                past = outs.past_key_values
                next_id = sample_next(outs.logits[:, -1, :])
                tok = int(next_id.item())
                generated = torch.cat([generated, next_id], dim=-1)
                if tok in (CODE_END, END_AI):
                    break
                if AUDIO_BASE <= tok < AUDIO_BASE + 7 * 4096:
                    snac_buf.append(tok)
                    if len(snac_buf) >= 7 and len(snac_buf) % 7 == 0:
                        piece = decode_snac_veena(snac, snac_buf[-7:])
                        if piece.size:
                            if ttfa is None:
                                ttfa = time.perf_counter() - t0
                            chunks.append(piece)
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
    total = time.perf_counter() - t0
    audio = np.concatenate(chunks) if chunks else np.zeros(0, np.float32)
    return audio, {
        "ok": err is None and (audio.size > 0 or cancelled),
        "error": err,
        "cancelled": cancelled,
        "ttfa_s": ttfa,
        "total_s": total,
        "n_chunks": len(chunks),
        "audio_duration_s": float(len(audio) / 24000) if len(audio) else 0.0,
        "sample_rate": 24000,
        "streaming": True,
        "stream_kind": "hf_token_stream_snac7_veena_offsets",
        "n_snac": len(snac_buf),
        "note": "Veena README is batch-only; custom token-stream for TTFA (not official stream API)",
    }


def veena_batch(model, tokenizer, snac, text, speaker="kavya"):
    prompt = f"<spk_{speaker}> {text}"
    prompt_tokens = tokenizer.encode(prompt, add_special_tokens=False)
    input_tokens = [START_HUMAN, *prompt_tokens, END_HUMAN, START_AI, CODE_START]
    input_ids = torch.tensor([input_tokens], device=model.device)
    max_tokens = min(int(len(text) * 1.3) * 7 + 21, 700)
    t0 = time.perf_counter()
    with torch.inference_mode():
        out = model.generate(
            input_ids,
            max_new_tokens=max_tokens,
            do_sample=True,
            temperature=0.4,
            top_p=0.9,
            repetition_penalty=1.05,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=[CODE_END, END_AI],
        )
    gen = out[0][len(input_tokens) :].tolist()
    snac_tokens = [t for t in gen if AUDIO_BASE <= t < AUDIO_BASE + 7 * 4096]
    snac_tokens = snac_tokens[: (len(snac_tokens) // 7) * 7]
    audio = decode_snac_veena(snac, snac_tokens)
    total = time.perf_counter() - t0
    return audio, {
        "ttfa_s": total,
        "total_s": total,
        "n_snac": len(snac_tokens),
        "streaming": False,
        "stream_kind": "batch_generate",
        "audio_duration_s": float(len(audio) / 24000) if len(audio) else 0.0,
    }


def whisper_score(items):
    from transformers import AutoModelForSpeechSeq2Seq, AutoProcessor, pipeline
    import jiwer

    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if device == "cuda" else torch.float32
    mid = "openai/whisper-large-v3"
    model = AutoModelForSpeechSeq2Seq.from_pretrained(
        mid, torch_dtype=dtype, low_cpu_mem_usage=True
    ).to(device)
    proc = AutoProcessor.from_pretrained(mid)
    pipe = pipeline(
        "automatic-speech-recognition",
        model=model,
        tokenizer=proc.tokenizer,
        feature_extractor=proc.feature_extractor,
        torch_dtype=dtype,
        device=0 if device == "cuda" else -1,
    )
    rows = []
    for wav, ref, lang in items:
        hyp = pipe(str(wav), generate_kwargs={"language": lang, "task": "transcribe"})["text"]
        ref_n = " ".join(ref.lower().split())
        hyp_n = " ".join(hyp.lower().split())
        wer = float(jiwer.wer(ref_n, hyp_n)) if ref_n else 1.0
        cer = float(jiwer.cer(ref_n, hyp_n)) if ref_n else 1.0
        rows.append({"wav": str(wav), "ref": ref, "hyp": hyp, "lang": lang, "wer": wer, "cer": cer})
    del model, pipe
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return rows


def run_concurrency(fn, n):
    try:
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=n) as ex:
            ttfas = list(ex.map(lambda _: fn(), range(n)))
        return {
            "n": n,
            "ttfas": ttfas,
            "wall_s": time.perf_counter() - t0,
            "summary": summarize_ttfas(ttfas),
        }
    except Exception as e:
        return {"n": n, "error": f"{type(e).__name__}: {e}"}


def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)

    print("Load SNAC...", flush=True)
    snac = SNAC.from_pretrained("hubertsiuzdak/snac_24khz").eval()
    if torch.cuda.is_available():
        snac = snac.cuda()

    print("Load maya-research/maya1...", flush=True)
    maya = AutoModelForCausalLM.from_pretrained(
        "maya-research/maya1",
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
    )
    maya_tok = AutoTokenizer.from_pretrained("maya-research/maya1", trust_remote_code=True)

    maya_specs = [
        {
            "id": "maya1_en_energetic",
            "lang": "en",
            "description": "Female, in her 30s with an American accent and is an event host, energetic, clear diction",
            "text": "Wow. This place looks even better than I imagined. How did they set all this up so perfectly?",
        },
        {
            "id": "maya1_en_calm",
            "lang": "en",
            "description": "Male, late 20s, neutral American, warm baritone, calm pacing",
            "text": "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM.",
        },
    ]
    maya_wavs = []
    for spec in maya_specs:
        print("Maya1 synth", spec["id"], flush=True)
        audio, meta = maya_batch(maya, maya_tok, snac, spec["description"], spec["text"])
        out = AUDIO_MAYA / f"{spec['id']}.wav"
        save_wav(out, audio, 24000, spec["text"])
        save_wav(SUITE_MAYA / "samples" / f"{spec['id']}.wav", audio, 24000, spec["text"])
        maya_wavs.append((out, spec["text"], spec["lang"], meta))
        print("  dur", meta["audio_duration_s"], "batch_ttfa", meta["ttfa_s"], flush=True)

    stream_desc = (
        "Realistic male voice in the 30s age with american accent. "
        "Normal pitch, warm timbre, conversational pacing."
    )
    stream_text = "Hello from Maya1 streaming probe. Your appointment is confirmed."
    stream_runs = []
    for i in range(2):
        audio, meta = maya_token_stream(
            maya, maya_tok, snac, stream_desc, stream_text, max_new=400
        )
        stream_runs.append(meta)
        if audio.size:
            save_wav(SUITE_MAYA / "samples" / f"stream_run{i}.wav", audio, 24000, stream_text)
    cancel_audio, cancel_meta = maya_token_stream(
        maya, maya_tok, snac, stream_desc, stream_text, max_new=400, cancel_after=0.5
    )
    if cancel_audio.size:
        save_wav(SUITE_MAYA / "samples" / "cancel.wav", cancel_audio, 24000, stream_text)

    conc = {}
    for n in (2, 4):
        conc[f"N{n}"] = run_concurrency(
            lambda: maya_token_stream(
                maya, maya_tok, snac, stream_desc, "Short concurrent probe.", max_new=160
            )[1].get("ttfa_s"),
            n,
        )

    maya_results = {
        "model_id": "maya-research/maya1",
        "gpu": gpu,
        "synth": [
            {"id": s["id"], "path": str(w), "meta": m}
            for s, (w, _, _, m) in zip(maya_specs, maya_wavs)
        ],
        "streaming": True,
        "stream_runs": stream_runs,
        "cancel": cancel_meta,
        "concurrency": conc,
        "ttfa_p50": summarize_ttfas([r.get("ttfa_s") for r in stream_runs]).get("p50"),
        "timestamp": ist_now(),
    }
    write_json(SUITE_MAYA / "results.json", maya_results)
    write_json(
        SUITE_MAYA / "config.json",
        {"model_id": "maya-research/maya1", "status": "OK", "streaming": True},
    )
    (SUITE_MAYA / "SUMMARY.md").write_text(
        f"# maya1 streaming\n\n**Status:** OK\n**Streaming:** True (`hf_token_stream_snac7`)\n"
        f"**TTFA p50:** {maya_results['ttfa_p50']}\n"
        f"**Cancel:** {cancel_meta.get('cancelled')} ttfa={cancel_meta.get('ttfa_s')}\n"
        f"**N=2:** {conc.get('N2')}\n**N=4:** {conc.get('N4')}\n\n"
        "Note: Official production path is vLLM+SNAC. This probe uses HF token-stream for honest first-chunk TTFA.\n",
        encoding="utf-8",
    )

    del maya
    torch.cuda.empty_cache()

    print("Load maya-research/Veena...", flush=True)
    try:
        veena = AutoModelForCausalLM.from_pretrained(
            "maya-research/Veena",
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
        )
    except Exception as e:
        print("bf16 failed, 4bit:", e, flush=True)
        from transformers import BitsAndBytesConfig

        qcfg = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        veena = AutoModelForCausalLM.from_pretrained(
            "maya-research/Veena",
            quantization_config=qcfg,
            device_map="auto",
            trust_remote_code=True,
        )
    veena_tok = AutoTokenizer.from_pretrained("maya-research/Veena", trust_remote_code=True)

    veena_specs = [
        {
            "id": "veena_hi_kavya",
            "speaker": "kavya",
            "lang": "hi",
            "text": "नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।",
        },
        {
            "id": "veena_en_agastya",
            "speaker": "agastya",
            "lang": "en",
            "text": "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM.",
        },
    ]
    veena_wavs = []
    for spec in veena_specs:
        print("Veena synth", spec["id"], flush=True)
        audio, meta = veena_batch(veena, veena_tok, snac, spec["text"], speaker=spec["speaker"])
        out = AUDIO_VEENA / f"{spec['id']}.wav"
        save_wav(out, audio, 24000, spec["text"])
        save_wav(SUITE_VEENA / "samples" / f"{spec['id']}.wav", audio, 24000, spec["text"])
        veena_wavs.append((out, spec["text"], spec["lang"], meta))
        print("  dur", meta["audio_duration_s"], "batch_ttfa", meta["ttfa_s"], flush=True)

    v_stream_runs = []
    for i in range(2):
        audio, meta = veena_token_stream(
            veena, veena_tok, snac, "Short Veena stream probe.", speaker="kavya", max_new=300
        )
        v_stream_runs.append(meta)
        if audio.size:
            save_wav(
                SUITE_VEENA / "samples" / f"stream_run{i}.wav",
                audio,
                24000,
                "Short Veena stream probe.",
            )
    v_cancel_a, v_cancel_m = veena_token_stream(
        veena,
        veena_tok,
        snac,
        "Cancel probe for Veena.",
        speaker="agastya",
        max_new=300,
        cancel_after=0.5,
    )
    if v_cancel_a.size:
        save_wav(SUITE_VEENA / "samples" / "cancel.wav", v_cancel_a, 24000, "Cancel probe for Veena.")

    v_conc = {}
    for n in (2, 4):
        v_conc[f"N{n}"] = run_concurrency(
            lambda: veena_token_stream(
                veena, veena_tok, snac, "Concurrent.", speaker="kavya", max_new=120
            )[1].get("ttfa_s"),
            n,
        )

    veena_results = {
        "model_id": "maya-research/Veena",
        "gpu": gpu,
        "synth": [
            {"id": s["id"], "path": str(w), "meta": m}
            for s, (w, _, _, m) in zip(veena_specs, veena_wavs)
        ],
        "streaming": True,
        "stream_kind": "custom token-stream (README batch-only)",
        "stream_runs": v_stream_runs,
        "cancel": v_cancel_m,
        "concurrency": v_conc,
        "ttfa_p50": summarize_ttfas([r.get("ttfa_s") for r in v_stream_runs]).get("p50"),
        "timestamp": ist_now(),
    }
    write_json(SUITE_VEENA / "results.json", veena_results)
    write_json(
        SUITE_VEENA / "config.json",
        {"model_id": "maya-research/Veena", "status": "OK", "streaming": True},
    )
    (SUITE_VEENA / "SUMMARY.md").write_text(
        f"# veena_maya streaming\n\n**Status:** OK\n**Streaming:** custom token-stream (README batch-only)\n"
        f"**TTFA p50:** {veena_results['ttfa_p50']}\n**Cancel:** {v_cancel_m.get('cancelled')}\n"
        f"**N=2:** {v_conc.get('N2')}\n**N=4:** {v_conc.get('N4')}\n",
        encoding="utf-8",
    )

    del veena
    torch.cuda.empty_cache()

    print("Whisper-large-v3 scoring...", flush=True)
    score_items = [(w, t, lang) for (w, t, lang, _) in maya_wavs + veena_wavs]
    asr_rows = whisper_score(score_items)
    write_json(
        PACK / "asr_metrics.json",
        {"model": "openai/whisper-large-v3", "rows": asr_rows, "timestamp": ist_now()},
    )
    write_json(
        PACK / "synth_meta.json",
        {"maya1": maya_results, "veena": veena_results, "gpu": gpu, "timestamp": ist_now()},
    )

    import shutil

    lines = [
        f"# Pack A — Maya1 & Veena synth + Whisper ASR\n\n**When:** {ist_now()}\n**GPU:** {gpu}\n\n",
        "| Wav | Lang | WER | CER |\n|---|---|---:|---:|\n",
    ]
    for r in asr_rows:
        lines.append(
            f"| {Path(r['wav']).name} | {r['lang']} | {r['wer']:.4f} | {r['cer']:.4f} |\n"
        )
        shutil.copy2(r["wav"], PACK / Path(r["wav"]).name)
        txt = Path(r["wav"]).with_suffix(".txt")
        if txt.exists():
            shutil.copy2(txt, PACK / txt.name)
    (PACK / "SUMMARY.md").write_text("".join(lines), encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": True, "time": ist_now()})
    print("A+B DONE", flush=True)


if __name__ == "__main__":
    main()
