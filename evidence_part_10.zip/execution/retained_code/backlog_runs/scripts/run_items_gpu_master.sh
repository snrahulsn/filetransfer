#!/usr/bin/env bash
set -uo pipefail
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8 LANG=C.UTF-8 LC_ALL=C.UTF-8
export HF_HOME=/workspace/hf_cache HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
if [[ -f /workspace/.hf_token_env ]]; then set -a; source /workspace/.hf_token_env; set +a; fi
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-${HUGGING_FACE_HUB_TOKEN:-}}"
export TOKENIZERS_PARALLELISM=false

VENV=/workspace/tts_streaming_suite/.venv_gpu
if [[ -x "$VENV/bin/python" ]]; then
  # shellcheck disable=SC1091
  source "$VENV/bin/activate"
fi
python -m pip install -q soundfile librosa jiwer snac peft accelerate huggingface_hub sentencepiece 2>&1 | tail -3 || true

LOG=/workspace/backlog_runs/items_1_13_gpu.log
mkdir -p /workspace/backlog_runs/item_workspaces /workspace/backlog_runs/packs_local
exec > >(tee -a "$LOG") 2>&1
echo "==== GPU MASTER START $(date) python=$(which python) ===="
python -c "import torch,transformers; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0), transformers.__version__)"

run() {
  local name="$1" script="$2"
  echo "==== RUN $name $(date) ===="
  set +e
  python "/workspace/backlog_runs/scripts/$script"
  local rc=$?
  set -e
  echo "==== DONE $name rc=$rc $(date) ===="
  return 0
}

run item123 run_item123_sravaani.py
run item04 run_item04_indicf5_odia.py
run item08_12 run_item08_12_conformer_score.py
run item05 run_item05_veena_qual.py
run item06 run_item06_qwen3_tts.py
run item07 run_item07_magpie.py
run item11 run_item11_nemotron_asr.py

echo "==== GPU MASTER COMPLETE $(date) ===="
ls -la /workspace/backlog_runs/packs_local/pack_item*.zip 2>/dev/null || true
python - <<'PY'
from pathlib import Path
import json
p=Path("/workspace/backlog_runs/packs_local")
for z in sorted(p.glob("pack_item*.zip")):
  print(z.name, z.stat().st_size)
PY
