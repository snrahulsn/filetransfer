#!/usr/bin/env python3
"""Item 7: NVIDIA Magpie TTS best-effort."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

MODEL_ID = "nvidia/magpie_tts_multilingual_357m"
OUT = Path(f"/workspace/backlog_runs/item_workspaces/pack_item07_nvidia_magpie_{DATE}")
LOG = OUT / "install_deploy.log"

def log(msg):
    OUT.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")
    print(msg, flush=True)

def main():
    gpu = nvidia_info()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "wavs").mkdir(exist_ok=True)
    status = {"item": 7, "when": ist_now(), "gpu": gpu, "model_id": MODEL_ID}

    # Try import nemo
    try:
        import nemo.collections.tts as nemo_tts
        log(f"nemo already present: {nemo_tts}")
    except Exception as e:
        log(f"nemo missing: {e}; attempting pip install nemo_toolkit[tts] (bounded)")
        cmd = [sys.executable, "-m", "pip", "install", "-q", "nemo_toolkit[tts]", "huggingface_hub"]
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        log(f"pip rc={p.returncode}\nstdout={p.stdout[-1500:]}\nstderr={p.stderr[-2000:]}")
        if p.returncode != 0:
            # try smaller
            p2 = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "nemo_toolkit"], capture_output=True, text=True, timeout=900)
            log(f"pip nemo_toolkit rc={p2.returncode}\n{p2.stderr[-1500:]}")

    rows = []
    try:
        import torch
        # MagpieTTS via NeMo restore
        try:
            from nemo.collections.tts.models import MagpieTTSModel
            log("using MagpieTTSModel")
            model = MagpieTTSModel.from_pretrained(MODEL_ID)
        except Exception as e1:
            log(f"MagpieTTSModel.from_pretrained fail: {e1}")
            try:
                from nemo.collections.tts.models import MagpieTTSModel as M
                model = M.restore_from(restore_path=None)  # will fail
            except Exception:
                # HF transformers path?
                from transformers import AutoModel
                model = AutoModel.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
                log("fallback AutoModel")

        model = model.cuda().eval() if hasattr(model, "cuda") else model
        texts = [
            ("hi", "आपकी बैठक कल दोपहर तीन बजे है।"),
            ("en", "Your meeting with Priya is tomorrow at three thirty PM."),
        ]
        for lang, text in texts:
            t0 = time.perf_counter()
            try:
                if hasattr(model, "generate_spectrogram") or hasattr(model, "tts"):
                    # NeMo API varies
                    if hasattr(model, "infer"):
                        out = model.infer(text=text, language=lang)
                    else:
                        out = model(text, language=lang)
                else:
                    out = model(text)
                # extract audio
                import numpy as np
                import soundfile as sf
                audio = out
                if isinstance(out, (list, tuple)):
                    audio = out[0]
                if hasattr(audio, "cpu"):
                    audio = audio.detach().float().cpu().numpy()
                audio = np.asarray(audio, dtype=np.float32).reshape(-1)
                path = OUT / "wavs" / f"magpie_{lang}.wav"
                sf.write(str(path), audio, 22050)
                rows.append({"lang": lang, "text": text, "ok": True, "wav": str(path),
                             "duration_s": len(audio)/22050.0, "gen_s": time.perf_counter()-t0})
            except Exception:
                rows.append({"lang": lang, "text": text, "ok": False, "error": traceback.format_exc()[-1500:]})
                log(f"synth fail {lang}: {rows[-1]['error'][:300]}")
        status["rows"] = rows
        status["status"] = "DONE" if any(r.get("ok") for r in rows) else "BLOCKED"
    except Exception:
        status["status"] = "BLOCKED"
        status["error"] = traceback.format_exc()
        log(status["error"][-2000:])

    write_json(OUT / "results.json", status)
    write_summary(OUT, f"""# Item 7 -- NVIDIA Magpie TTS

**When:** {status['when']}
**Model:** `{MODEL_ID}`
**Status:** {status.get('status')}
**GPU:** {gpu}

## Results
{json.dumps(rows, indent=2, default=str)[:2500]}

## Blockers / log (tail)
See install_deploy.log in pack.
""")
    # include log
    z, _ = finalize_pack(OUT, f"pack_item07_nvidia_magpie_{DATE}.zip")
    print("PACK7", z, status.get("status"), flush=True)

if __name__ == "__main__":
    main()
