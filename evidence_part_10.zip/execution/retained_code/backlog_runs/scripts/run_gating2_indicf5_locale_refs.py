#!/usr/bin/env python3
"""Gating #2: IndicF5 re-synth with PER-LOCALE reference voices + listening sheet."""
from __future__ import annotations
import json, os, sys, time, traceback, shutil, csv
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import soundfile as sf
import torch
from transformers import AutoModel

OUT = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs")
WAVS = OUT / "wavs"
REFS = OUT / "locale_refs"
WAVS.mkdir(parents=True, exist_ok=True)
REFS.mkdir(parents=True, exist_ok=True)

MODEL_ID = "ai4bharat/IndicF5"
PIN = "ba85abedf18dc479a447eaa0eccbd76ab78a47d5"
MODEL_PATH = "/workspace/indic_f5_qual/model_cache/IndicF5"
FLEURS = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
OFFICIAL_PROMPTS = Path("/workspace/indic_f5_qual/prompts")

# Same sentences as prior IndicF5 qual (so listening can compare apples-to-apples)
LOCALES = [
    ("as-IN", "as_in", "আপোনাৰ প্ৰিয়াৰ সৈতে মিটিং কাইলৈ দুপৰীয়া তিনি বজাত।", True),
    ("bn-IN", "bn_in", "আপনার মিটিং আগামীকাল দুপুর তিনটায়।", True),
    ("gu-IN", "gu_in", "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.", True),
    ("hi-IN", "hi_in", "आपकी बैठक कल दोपहर तीन बजे है।", True),
    ("kn-IN", "kn_in", "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.", True),
    ("ml-IN", "ml_in", "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.", True),
    ("mr-IN", "mr_in", "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.", True),
    ("or-IN", "or_in", "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।", True),
    ("pa-IN", "pa_in", "ਤੁਹਾਡੀ ਮੀਟਿੰਗ ਕੱਲ੍ਹ ਦੁਪਹਿਰ ਤਿੰਨ ਵਜੇ ਹੈ।", True),
    ("ta-IN", "ta_in", "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.", True),
    ("te-IN", "te_in", "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.", True),
]

# Official HF prompts (only these two ship with the model)
OFFICIAL = {
    "pa-IN": {
        "wav": "PAN_F_HAPPY_00001.wav",
        "text": "ਭਹੰਪੀ ਵਿੱਚ ਸਮਾਰਕਾਂ ਦੇ ਭਵਨ ਨਿਰਮਾਣ ਕਲਾ ਦੇ ਵੇਰਵੇ ਗੁੰਝਲਦਾਰ ਅਤੇ ਹੈਰਾਨ ਕਰਨ ਵਾਲੇ ਹਨ, ਜੋ ਮੈਨੂੰ ਖੁਸ਼ ਕਰਦੇ  ਹਨ।",
        "source": "ai4bharat/IndicF5 prompts/PAN_F_HAPPY_00001.wav",
    },
    "mr-IN": {
        "wav": "MAR_F_HAPPY_00001.wav",
        "text": None,  # filled from README / sidecar if present; else FLEURS fallback
        "source": "ai4bharat/IndicF5 prompts/MAR_F_HAPPY_00001.wav",
    },
}

def pick_fleurs_ref(lang_dir: str, max_dur=12.0, min_dur=2.0):
    """Pick a mid-length FLEURS clip as locale-matched reference voice."""
    man = FLEURS / f"manifest_{lang_dir}.jsonl"
    cands = []
    for line in man.read_text(encoding="utf-8").splitlines():
        r = json.loads(line)
        d = float(r.get("duration_s") or 0)
        if min_dur <= d <= max_dur and r.get("reference") and Path(r["wav"]).exists():
            cands.append(r)
    if not cands:
        # any
        for line in man.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            if Path(r["wav"]).exists() and r.get("reference"):
                cands.append(r)
                break
    # prefer ~4-8s
    cands.sort(key=lambda r: abs(float(r.get("duration_s", 0)) - 6.0))
    return cands[0]

def mar_ref_text():
    # Try to find MAR prompt text near model
    for p in [
        Path(MODEL_PATH) / "prompts" / "MAR_F_HAPPY_00001.txt",
        OFFICIAL_PROMPTS / "MAR_F_HAPPY_00001.txt",
    ]:
        if p.exists():
            return p.read_text(encoding="utf-8").strip()
    # Known MAR happy prompt from IndicF5 community / README variants -- if unknown, use FLEURS
    return None

def prepare_refs():
    refs = {}
    mar_txt = mar_ref_text()
    for locale, lang_dir, sentence, official in LOCALES:
        dest_wav = REFS / f"{locale}_ref.wav"
        dest_txt = REFS / f"{locale}_ref.txt"
        meta = {"locale": locale, "lang_dir": lang_dir}
        if locale in OFFICIAL and (OFFICIAL_PROMPTS / OFFICIAL[locale]["wav"]).exists():
            src = OFFICIAL_PROMPTS / OFFICIAL[locale]["wav"]
            text = OFFICIAL[locale]["text"]
            if locale == "mr-IN" and not text:
                text = mar_txt
            if text:
                shutil.copy2(src, dest_wav)
                dest_txt.write_text(text + "\n", encoding="utf-8")
                meta.update({"source": OFFICIAL[locale]["source"], "kind": "official_hf_prompt",
                             "ref_text": text, "ref_wav": str(dest_wav)})
                refs[locale] = meta
                continue
        # FLEURS locale-matched
        fr = pick_fleurs_ref(lang_dir)
        shutil.copy2(fr["wav"], dest_wav)
        dest_txt.write_text(fr["reference"].strip() + "\n", encoding="utf-8")
        meta.update({
            "source": f"FLEURS {lang_dir} utt {fr.get('utt_id')} (locale-matched native ref)",
            "kind": "fleurs_locale_matched",
            "ref_text": fr["reference"].strip(),
            "ref_wav": str(dest_wav),
            "fleurs": {k: fr.get(k) for k in ("utt_id", "duration_s", "fleurs_id")},
        })
        refs[locale] = meta
    write_json(OUT / "locale_refs.json", refs)
    return refs

def synthesize(refs):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    load_id = MODEL_PATH if Path(MODEL_PATH).joinpath("model.safetensors").exists() else MODEL_ID
    print("Loading", load_id, "on", device, flush=True)
    model = AutoModel.from_pretrained(load_id, trust_remote_code=True, token=os.environ["HF_TOKEN"], revision=PIN if load_id == MODEL_ID else None)
    model.infer_device = torch.device(device)
    if hasattr(model, "ema_model"):
        model.ema_model = model.ema_model.to(device)
    if hasattr(model, "vocoder"):
        model.vocoder = model.vocoder.to(device)

    rows = []
    for locale, lang_dir, sentence, officially_supported in LOCALES:
        ref = refs[locale]
        rec = {
            "locale": locale,
            "sentence": sentence,
            "officially_supported": officially_supported,
            "ref_kind": ref["kind"],
            "ref_source": ref["source"],
            "ref_wav": ref["ref_wav"],
            "ref_text": ref["ref_text"],
        }
        try:
            t0 = time.perf_counter()
            with torch.inference_mode():
                out = model(sentence, ref_audio_path=ref["ref_wav"], ref_text=ref["ref_text"])
            # out may be tensor or np
            if isinstance(out, tuple):
                audio = out[0]
            else:
                audio = out
            if hasattr(audio, "detach"):
                audio = audio.detach().float().cpu().numpy()
            audio = np.asarray(audio, dtype=np.float32).reshape(-1)
            # normalize lightly
            peak = float(np.max(np.abs(audio))) if len(audio) else 0.0
            if peak > 1.0:
                audio = audio / peak * 0.99
            wav_path = WAVS / f"{locale}.wav"
            sf.write(str(wav_path), audio, 24000)
            rec.update({
                "ok": True,
                "wav": str(wav_path),
                "duration_s": float(len(audio) / 24000),
                "synth_s": time.perf_counter() - t0,
                "peak": peak,
            })
            print("OK", locale, rec["duration_s"], flush=True)
        except Exception as e:
            rec.update({"ok": False, "error": f"{type(e).__name__}: {e}\n{traceback.format_exc()[-500:]}"})
            print("FAIL", locale, e, flush=True)
        rows.append(rec)
    return rows

def write_listening_sheet(rows, refs):
    """Listening sheet for human re-score; prior 11 scores VOID."""
    path = OUT / "listening_sheet.csv"
    fields = ["locale", "ref_kind", "ref_source", "sentence", "wav", "duration_s",
              "naturalness_1to5", "intelligibility_1to5", "speaker_similarity_1to5",
              "locale_match_ok", "notes", "prior_shared_ref_score_VOID"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({
                "locale": r["locale"],
                "ref_kind": r.get("ref_kind"),
                "ref_source": r.get("ref_source"),
                "sentence": r.get("sentence"),
                "wav": r.get("wav"),
                "duration_s": r.get("duration_s"),
                "naturalness_1to5": "",
                "intelligibility_1to5": "",
                "speaker_similarity_1to5": "",
                "locale_match_ok": "",
                "notes": "Re-synth with locale-matched ref; prior shared PAN ref listening scores VOID",
                "prior_shared_ref_score_VOID": "VOID",
            })
    md = OUT / "LISTENING_SHEET.md"
    lines = [
        "# IndicF5 listening sheet -- per-locale refs (gating #2)\n",
        f"**When:** {ist_now()}\n",
        "**Prior 11 listening scores:** **VOID** (were scored against a single shared Punjabi ref).\n",
        "**Policy:** each locale uses its own reference voice (official HF prompt where available: pa/mr; else FLEURS locale-matched native clip).\n",
        "\n| Locale | Ref kind | Wav | Fill naturalness | intelligibility | speaker_sim |\n|--------|----------|-----|------------------|-----------------|-------------|\n",
    ]
    for r in rows:
        lines.append(f"| {r['locale']} | {r.get('ref_kind')} | `{Path(r.get('wav') or '').name}` |  |  |  |\n")
    md.write_text("".join(lines), encoding="utf-8")
    return str(path)

def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    refs = prepare_refs()
    rows = synthesize(refs)
    sheet = write_listening_sheet(rows, refs)
    summary = {
        "when": ist_now(),
        "model_id": MODEL_ID,
        "revision": PIN,
        "gpu": gpu,
        "n_ok": sum(1 for r in rows if r.get("ok")),
        "n_fail": sum(1 for r in rows if not r.get("ok")),
        "prior_listening_scores": "VOID -- shared PAN_F_HAPPY ref across locales",
        "ref_policy": "per-locale: official HF prompts for pa-IN/mr-IN when text known; else FLEURS locale-matched",
        "results": rows,
        "listening_sheet_csv": sheet,
    }
    write_json(OUT / "results.json", summary)
    (OUT / "SUMMARY.md").write_text(
        f"""# Gating #2 -- IndicF5 per-locale reference voices

**When:** {summary['when']}
**Model:** `{MODEL_ID}` @ `{PIN}`
**Synth:** {summary['n_ok']}/{len(rows)} OK
**Prior listening scores:** **VOID** (single shared PAN ref)
**New policy:** locale-matched refs (see `locale_refs.json`)
**Listening sheet:** `listening_sheet.csv` + `LISTENING_SHEET.md` (blank for human re-score)

## Refs used
""" + "\n".join(f"- **{loc}**: {refs[loc]['kind']} -- {refs[loc]['source']}" for loc in refs)
    )
    write_json(OUT / "DONE.json", {"ok": summary["n_fail"] == 0, "n_ok": summary["n_ok"], "n_fail": summary["n_fail"]})
    print("DONE", summary["n_ok"], summary["n_fail"], flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        write_json(OUT / "DONE.json", {"ok": False, "error": traceback.format_exc()})
        raise
