#!/usr/bin/env python3
"""Gating #4: Maya1 streaming probe (TTFA, partials/chunks, cancel, N=2). Dedicated pack."""
from __future__ import annotations
import json, os, sys, time, traceback, inspect
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas, save_wav

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from snac import SNAC

OUT = Path("/workspace/backlog_runs/pack_gating4_maya1_stream_probe")
SAMPLES = OUT / "samples"
OUT.mkdir(parents=True, exist_ok=True)
SAMPLES.mkdir(parents=True, exist_ok=True)
MODEL_ID = "maya-research/maya1"

CODE_START, CODE_END = 128257, 128258
SOH, EOH, SOA = 128259, 128260, 128261
SNAC_MIN, SNAC_MAX = 128266, 156937
CODE_OFFSET = 128266
TEXT_EOT = 128009

def decode_snac_maya(snac_model, tokens):
    if not tokens:
        return np.zeros(0, np.float32)
    frames = len(tokens) // 7
    tokens = tokens[: frames * 7]
    if frames == 0:
        return np.zeros(0, np.float32)
    l1, l2, l3 = [], [], []
    for i in range(frames):
        s = tokens[i * 7 : (i + 1) * 7]
        l1.append((s[0] - CODE_OFFSET) % 4096)
        l2.extend([(s[1] - CODE_OFFSET) % 4096, (s[4] - CODE_OFFSET) % 4096])
        l3.extend([
            (s[2] - CODE_OFFSET) % 4096, (s[3] - CODE_OFFSET) % 4096,
            (s[5] - CODE_OFFSET) % 4096, (s[6] - CODE_OFFSET) % 4096,
        ])
    device = next(snac_model.parameters()).device
    codes = [torch.tensor(lv, dtype=torch.long, device=device).unsqueeze(0) for lv in (l1, l2, l3)]
    with torch.inference_mode():
        z = snac_model.quantizer.from_codes(codes)
        audio = snac_model.decoder(z)[0, 0].detach().float().cpu().numpy()
    if len(audio) > 2048:
        audio = audio[2048:]
    return audio.astype(np.float32)

def build_maya_prompt(tokenizer, description, text):
    soh = tokenizer.decode([SOH]); eoh = tokenizer.decode([EOH]); soa = tokenizer.decode([SOA])
    sos = tokenizer.decode([CODE_START]); eot = tokenizer.decode([TEXT_EOT])
    bos = tokenizer.bos_token or ""
    return soh + bos + f'<description="{description}"> {text}' + eot + eoh + soa + sos

def sample_next(logits, temperature=0.4, top_p=0.9):
    logits = logits / temperature
    probs = torch.softmax(logits, dim=-1)
    sorted_probs, sorted_idx = torch.sort(probs, descending=True)
    cum = torch.cumsum(sorted_probs, dim=-1)
    mask = cum > top_p
    mask[..., 1:] = mask[..., :-1].clone()
    mask[..., 0] = False
    sorted_probs = sorted_probs.masked_fill(mask, 0.0)
    sorted_probs = sorted_probs / sorted_probs.sum(dim=-1, keepdim=True).clamp_min(1e-12)
    pick = torch.multinomial(sorted_probs, 1)
    return sorted_idx.gather(-1, pick)

def maya_token_stream(model, tokenizer, snac, description, text, max_new=400, cancel_after=None):
    prompt = build_maya_prompt(tokenizer, description, text)
    generated = tokenizer(prompt, return_tensors="pt")["input_ids"].to(model.device)
    t0 = time.perf_counter(); ttfa = None; chunks = []; snac_buf = []; cancelled = False; err = None
    try:
        past = None
        with torch.inference_mode():
            for _ in range(max_new):
                if cancel_after is not None and ttfa is not None and (time.perf_counter() - t0) >= cancel_after:
                    cancelled = True
                    break
                outs = model(input_ids=generated if past is None else generated[:, -1:], past_key_values=past, use_cache=True)
                past = outs.past_key_values
                next_id = sample_next(outs.logits[:, -1, :])
                tok = int(next_id.item())
                generated = torch.cat([generated, next_id], dim=-1)
                if tok == CODE_END:
                    break
                if SNAC_MIN <= tok <= SNAC_MAX:
                    snac_buf.append(tok)
                    if len(snac_buf) >= 7 and len(snac_buf) % 7 == 0:
                        piece = decode_snac_maya(snac, snac_buf[-7:])
                        if piece.size:
                            if ttfa is None:
                                ttfa = time.perf_counter() - t0
                            chunks.append(piece)
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
    total = time.perf_counter() - t0
    audio = np.concatenate(chunks) if chunks else np.zeros(0, np.float32)
    return audio, {
        "ok": err is None and (audio.size > 0 or cancelled),
        "error": err, "cancelled": cancelled, "ttfa_s": ttfa, "total_s": total,
        "n_chunks": len(chunks), "audio_duration_s": float(len(audio) / 24000) if len(audio) else 0.0,
        "sample_rate": 24000, "streaming": True, "stream_kind": "hf_token_stream_snac7",
        "n_snac": len(snac_buf),
        "note": "Official prod path is vLLM+SNAC; HF token-stream used for honest first-chunk TTFA / partials",
    }

def document_api():
    return {
        "model_id": MODEL_ID,
        "streaming": True,
        "stream_kind": "hf_token_stream_snac7",
        "transport": "in-process HF generate token stream + SNAC decode every 7 audio tokens (NOT first-party WS/HTTP)",
        "ws_http": False,
        "official_prod": "vLLM + SNAC (per Maya docs); this probe uses HF for measurable TTFA",
        "partials": "Yes -- audio chunks emitted each SNAC frame (7 tokens)",
        "cancel": "Yes -- stop generation loop after first audio chunk + cancel_after seconds",
        "evidence": "Prior pack_A also measured streaming=True; this is the dedicated gating #4 pack (N=2 focus).",
    }

def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    api = document_api()
    write_json(OUT / "stream_api.json", api)

    print("Load", MODEL_ID, flush=True)
    t_load = time.perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID, torch_dtype=torch.bfloat16, device_map="cuda", trust_remote_code=True,
        token=os.environ["HF_TOKEN"],
    )
    tok = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    snac = SNAC.from_pretrained("hubertsiuzdak/snac_24khz").eval().to("cuda")
    load_s = time.perf_counter() - t_load

    desc = "Calm female voice, clear diction"
    text = "Your meeting with Priya is tomorrow at three thirty PM."

    # Warm discard
    _, _ = maya_token_stream(model, tok, snac, desc, text, max_new=120)

    # Sequential stream runs (partials)
    runs = []
    for i in range(3):
        audio, meta = maya_token_stream(model, tok, snac, desc, text, max_new=280)
        runs.append(meta)
        if audio.size and i == 0:
            save_wav(SAMPLES / "stream0.wav", audio, 24000, text)
        print("run", i, meta.get("ttfa_s"), "chunks", meta.get("n_chunks"), flush=True)

    # Cancel
    c_audio, cancel = maya_token_stream(model, tok, snac, desc, text, max_new=280, cancel_after=0.45)
    if c_audio.size:
        save_wav(SAMPLES / "cancel.wav", c_audio, 24000, text)

    # N=2 concurrent
    def one(_):
        _, m = maya_token_stream(model, tok, snac, desc, text, max_new=200)
        return m.get("ttfa_s")
    t0 = time.perf_counter()
    with ThreadPoolExecutor(2) as ex:
        n2 = list(ex.map(one, range(2)))
    n2_meta = {"n": 2, "ttfas": n2, "wall_s": time.perf_counter() - t0, "summary": summarize_ttfas(n2)}

    ttfas = [r.get("ttfa_s") for r in runs]
    results = {
        "when": ist_now(), "model_id": MODEL_ID, "gpu": gpu, "load_s": load_s,
        "stream_api": api,
        "stream_runs": runs,
        "ttfa_p50": summarize_ttfas(ttfas).get("p50"),
        "partials_run0": runs[0].get("n_chunks") if runs else None,
        "cancel": cancel,
        "concurrency": {"N2": n2_meta},
        "batch_only": False,
    }
    write_json(OUT / "results.json", results)
    (OUT / "SUMMARY.md").write_text(f"""# Gating #4 -- Maya1 streaming probe

**When:** {results['when']}
**Model:** `{MODEL_ID}`
**GPU:** {gpu}
**Load_s:** {load_s:.2f}

## Streaming
- **Streaming:** **True** (`hf_token_stream_snac7`)
- **WS/HTTP:** No first-party stream server (HF token-stream + SNAC)
- **Partials (chunks run0):** {results['partials_run0']}
- **TTFA p50 (n={len(ttfas)}):** **{results['ttfa_p50']}**
- **Cancel:** {cancel.get('cancelled')} (ttfa={cancel.get('ttfa_s')})
- **N=2 TTFA p50:** {n2_meta['summary'].get('p50')} wall={n2_meta['wall_s']:.3f}s

Not batch-only. Official prod path remains vLLM+SNAC; this probe measures HF stream TTFA honestly.
""", encoding="utf-8")
    write_json(OUT / "DONE.json", {
        "ok": True, "streaming": True, "ttfa_p50": results["ttfa_p50"],
        "cancel": cancel.get("cancelled"), "n2_p50": n2_meta["summary"].get("p50"),
    })
    print("DONE", results["ttfa_p50"], n2_meta, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        write_json(OUT / "DONE.json", {"ok": False, "error": traceback.format_exc()})
        raise
