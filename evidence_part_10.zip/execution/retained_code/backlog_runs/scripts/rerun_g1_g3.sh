#!/usr/bin/env bash
set -uo pipefail
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8 LANG=C.UTF-8 LC_ALL=C.UTF-8
export HF_HOME=/workspace/hf_cache HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
export SKIP_GATING3_PIP=1
if [[ -f /workspace/.hf_token_env ]]; then set -a; source /workspace/.hf_token_env; set +a; fi
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-${HUGGING_FACE_HUB_TOKEN:-}}"
cd /workspace
LOG=/workspace/backlog_runs/gating_rerun_g1_g3.log
exec > >(tee -a "$LOG") 2>&1
echo "==== RERUN START $(date) ===="
python3 -c "import torch; from transformers import AutoModel; print('torch', torch.__version__, torch.cuda.is_available())"
echo "==== G1 ===="
python3 /workspace/backlog_runs/scripts/run_gating1_sravaani_gpu_stream.py
echo "==== G1 rc=$? ===="
echo "==== G2 finalize ===="
python3 /workspace/backlog_runs/scripts/finalize_g2_from_results.py
echo "==== G3 ===="
python3 /workspace/backlog_runs/scripts/run_gating3_indicconformer_rescore.py
echo "==== G3 rc=$? ===="
# rezip
python3 - <<'PY'
from pathlib import Path
import shutil
out = Path("/workspace/backlog_runs/packs_local"); out.mkdir(parents=True, exist_ok=True)
for name in ["pack_gating1_sravaani_gpu_stream","pack_gating2_indicf5_locale_refs","pack_gating3_indicconformer_rescore","pack_gating4_maya1_stream_probe"]:
  src = Path("/workspace/backlog_runs")/name
  if not src.exists(): continue
  dest = out/f"{name}.zip"
  if dest.exists(): dest.unlink()
  shutil.make_archive(str(dest.with_suffix("")), "zip", root_dir=str(src))
  print("ZIPPED", dest, dest.stat().st_size)
PY
python3 - <<'PY'
import json
from pathlib import Path
for name in ["pack_gating1_sravaani_gpu_stream","pack_gating2_indicf5_locale_refs","pack_gating3_indicconformer_rescore","pack_gating4_maya1_stream_probe"]:
  d=json.loads((Path("/workspace/backlog_runs")/name/"DONE.json").read_text())
  print(name, "ok=", d.get("ok"), "keys", list(d)[:6])
PY
echo "==== RERUN COMPLETE $(date) ===="
