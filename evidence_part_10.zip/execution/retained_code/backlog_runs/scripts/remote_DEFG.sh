#!/bin/bash
set -u
export HF_HOME=/workspace/hf_cache
export TRANSFORMERS_CACHE=/workspace/hf_cache
export D_CAP_PER_LANG="${D_CAP_PER_LANG:-20}"
export D_TIMEOUT_S="${D_TIMEOUT_S:-1800}"
cd /workspace
source /workspace/.hf_token_env 2>/dev/null || source /workspace/.hf_token_env 2>/dev/null || true
mkdir -p /workspace/backlog_runs/logs
echo "=== remote_DEFG start $(date -Is) GPU=$(nvidia-smi -L | head -1) ===" | tee /workspace/backlog_runs/logs/remote_DEFG.log

run_job () {
  local name="$1"; shift
  echo "=== JOB $name $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DEFG.log
  python3 "$@" 2>&1 | tee /workspace/backlog_runs/logs/${name}.log
  local rc=${PIPESTATUS[0]}
  echo "=== JOB $name rc=$rc $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DEFG.log
  return $rc
}

# G first (CPU-ish) while we can; then D (GPU); then F; then E (also GPU — sequential)
run_job G /workspace/backlog_runs/scripts/run_G_v2_corpora.py || echo G_FAIL
run_job D /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py || echo D_FAIL

# If D got healthy RTF with cap=20, optionally bump to 100
if python3 - <<'PY'
import json
from pathlib import Path
p=Path('/workspace/backlog_runs/pack_D_indicconformer_cudnn9/DONE.json')
if not p.exists():
    raise SystemExit(1)
d=json.loads(p.read_text())
rtf=d.get('new_rtf')
ok=d.get('ok') and rtf is not None and d.get('n_ok',0)>=10
print('d_check', d)
raise SystemExit(0 if ok else 1)
PY
then
  echo "D micro OK — expanding to N=100/lang" | tee -a /workspace/backlog_runs/logs/remote_DEFG.log
  export D_CAP_PER_LANG=100
  export D_TIMEOUT_S=7200
  run_job D100 /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py || echo D100_FAIL
fi

run_job F /workspace/backlog_runs/scripts/run_F_v2_voxtral_realtime.py || echo F_FAIL
run_job E /workspace/backlog_runs/scripts/run_E_v2_voxtral_tts_stream.py || echo E_FAIL

touch /workspace/backlog_runs/POD_JOBS_DONE
echo "=== remote_DEFG end $(date -Is) ===" | tee -a /workspace/backlog_runs/logs/remote_DEFG.log
