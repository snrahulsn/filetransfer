#!/usr/bin/env python3
"""D: IndicConformer-600M FLEURS RTF with CUDA EP + thread isolation (cuDNN9)."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess, signal
from pathlib import Path

# Thread isolation MUST be set before ORT/numpy/torch import
for k, v in {
    "OMP_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1",
    "ORT_NUM_THREADS": "1",
    "OMP_WAIT_POLICY": "PASSIVE",
    "CUDA_MODULE_LOADING": "LAZY",
}.items():
    os.environ.setdefault(k, v)

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

ROOT = Path("/workspace/fleurs_asr_trio")
OUT = ROOT / "indic-conformer-600m" / "cudnn9_rerun_v2"
OUT.mkdir(parents=True, exist_ok=True)
PACK = Path("/workspace/backlog_runs/pack_D_indicconformer_cudnn9")
PACK.mkdir(parents=True, exist_ok=True)
OLD_RTF = 0.1612  # prior complete RTF was CPU fallback
REPO = "ai4bharat/indic-conformer-600m-multilingual"
REV = "e9b71b369c048e2c6b634d4c131061c34e441179"


def install_stack():
    log = []
    cmds = [
        [sys.executable, "-m", "pip", "install", "-q", "-U", "pip"],
        [sys.executable, "-m", "pip", "install", "-q", "nvidia-cudnn-cu12==9.1.0.70"],
        # 1.19.2+cu12 matches prior CUDA EP success note
        [sys.executable, "-m", "pip", "install", "-q", "onnxruntime-gpu==1.19.2"],
        [sys.executable, "-m", "pip", "install", "-q", "torchaudio", "jiwer", "soundfile", "librosa", "transformers", "sentencepiece", "huggingface_hub"],
    ]
    for c in cmds:
        p = subprocess.run(c, capture_output=True, text=True)
        log.append({"cmd": " ".join(c), "rc": p.returncode, "err": (p.stderr or "")[-500:]})
    import glob
    cands = glob.glob("/usr/local/lib/python*/dist-packages/nvidia/cudnn/lib") + \
            glob.glob(str(Path(sys.prefix) / "lib/python*/site-packages/nvidia/cudnn/lib"))
    if cands:
        os.environ["LD_LIBRARY_PATH"] = cands[0] + ":" + os.environ.get("LD_LIBRARY_PATH", "")
        log.append({"LD_LIBRARY_PATH_prepend": cands[0]})
    write_json(OUT / "install_log.json", log)
    return log


def patch_ort_session_defaults():
    """Monkeypatch ORT InferenceSession to force tiny thread pools."""
    import onnxruntime as ort
    _Orig = ort.InferenceSession
    def _wrapped(path_or_bytes, sess_options=None, providers=None, provider_options=None, **kw):
        so = sess_options or ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        if providers is None:
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        print(f"[ORT] InferenceSession providers={providers} threads=1", flush=True)
        return _Orig(path_or_bytes, sess_options=so, providers=providers, provider_options=provider_options, **kw)
    ort.InferenceSession = _wrapped
    return ort.get_available_providers()


def load_manifest(cap_per_lang: int):
    man = ROOT / "_fleurs_wav_cache" / "manifest_all.jsonl"
    if not man.exists():
        # alternate names seen on volume
        for alt in [ROOT / "_fleurs_wav_cache" / "manifest_all.jsonl",
                    ROOT / "_fleurs_wav_cache" / "manifest.jsonl"]:
            if alt.exists():
                man = alt
                break
    rows = []
    by = {}
    for line in man.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        lang = r.get("lang") or r.get("language")
        wav = r.get("wav") or r.get("path") or r.get("audio_path")
        if not lang or not wav:
            continue
        # skip English — unsupported by IN-22
        if lang.startswith("en_"):
            continue
        by.setdefault(lang, [])
        if len(by[lang]) >= cap_per_lang:
            continue
        # remap /workspace paths if needed
        p = Path(wav)
        if not p.exists():
            # try relative to cache
            cand = ROOT / "_fleurs_wav_cache" / lang / p.name
            if cand.exists():
                p = cand
        if not p.exists():
            continue
        ref = r.get("reference") or r.get("transcription") or r.get("text") or ""
        dur = float(r.get("duration_s") or r.get("duration") or 0.0)
        by[lang].append({"lang": lang, "wav": str(p), "reference": ref, "duration_s": dur, "utt_id": r.get("utt_id") or p.stem})
    for lang, items in by.items():
        rows.extend(items)
    return rows, str(man)


def run_eval(cap_per_lang: int, timeout_s: int):
    providers = patch_ort_session_defaults()
    write_json(OUT / "ort_providers.json", {"providers": providers, "time": ist_now(),
                                            "env": {k: os.environ.get(k) for k in
                                                    ["OMP_NUM_THREADS","MKL_NUM_THREADS","ORT_NUM_THREADS","LD_LIBRARY_PATH"]}})
    import torch
    from transformers import AutoModel
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading {REPO}@{REV} on {device}", flush=True)
    t0 = time.perf_counter()
    model = AutoModel.from_pretrained(REPO, revision=REV, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    model = model.to(device)
    model.eval()
    load_s = time.perf_counter() - t0
    print(f"model_load_s={load_s:.2f}", flush=True)

    rows, man = load_manifest(cap_per_lang)
    print(f"utterances={len(rows)} langs={sorted({r['lang'] for r in rows})} manifest={man}", flush=True)
    if not rows:
        raise RuntimeError("no utterances loaded from manifest")

    import torchaudio
    results = []
    total_audio = 0.0
    total_infer = 0.0
    t_all = time.perf_counter()
    hung = False
    for i, utt in enumerate(rows):
        if time.perf_counter() - t_all > timeout_s:
            hung = True
            print(f"TIMEOUT after {i} utts", flush=True)
            break
        wav, sr = torchaudio.load(utt["wav"])
        if wav.shape[0] > 1:
            wav = torch.mean(wav, dim=0, keepdim=True)
        if sr != 16000:
            wav = torchaudio.functional.resample(wav, sr, 16000)
        if utt["duration_s"] <= 0:
            utt["duration_s"] = float(wav.shape[-1] / 16000)
        total_audio += utt["duration_s"]
        ml = utt["lang"].split("_")[0]  # hi_in -> hi, ur_pk -> ur
        t1 = time.perf_counter()
        try:
            with torch.inference_mode():
                out = model(wav.to(device), ml, "ctc")
            if isinstance(out, (list, tuple)):
                out = out[0]
            hyp = (str(out) or "").strip()
            infer_s = time.perf_counter() - t1
            total_infer += infer_s
            rtf = infer_s / max(utt["duration_s"], 1e-9)
            results.append({**utt, "hypothesis": hyp, "infer_s": infer_s, "rtf": rtf, "ok": True})
            print(f"[{i+1}/{len(rows)}] {utt['utt_id']} rtf={rtf:.4f} hyp={hyp[:60]!r}", flush=True)
        except Exception as e:
            infer_s = time.perf_counter() - t1
            total_infer += infer_s
            results.append({**utt, "hypothesis": "", "infer_s": infer_s, "rtf": None, "ok": False, "error": f"{type(e).__name__}: {e}"})
            print(f"FAIL {utt['utt_id']}: {e}", flush=True)
        # progress checkpoint every 10
        if (i + 1) % 10 == 0:
            write_json(OUT / "partial_results.json", {
                "n": i + 1, "total_audio_s": total_audio, "total_infer_s": total_infer,
                "rtf": total_infer / max(total_audio, 1e-9), "time": ist_now(),
            })

    wall = time.perf_counter() - t_all
    ok = [r for r in results if r.get("ok")]
    overall_rtf = (total_infer / max(total_audio, 1e-9)) if total_audio else None
    # verify provider actually used: check nvidia-smi briefly via torch mem
    gpu_mem = None
    try:
        gpu_mem = torch.cuda.max_memory_allocated() / (1024**3)
    except Exception:
        pass
    summary = {
        "model": REPO, "revision": REV, "old_rtf_cpu_fallback": OLD_RTF,
        "new_rtf_cuda": overall_rtf, "n_ok": len(ok), "n_total": len(results),
        "n_planned": len(rows), "cap_per_lang": cap_per_lang,
        "total_audio_s": total_audio, "total_infer_s": total_infer, "wall_s": wall,
        "model_load_s": load_s, "ort_providers": providers, "device": device,
        "gpu": nvidia_info(), "gpu_max_mem_gb": gpu_mem, "hung_or_timeout": hung,
        "thread_env": {k: os.environ.get(k) for k in ["OMP_NUM_THREADS","MKL_NUM_THREADS","ORT_NUM_THREADS"]},
        "timestamp": ist_now(),
        "note": "Thread pools isolated (OMP/MKL/ORT=1 + ORT Sequential). Compare new_rtf_cuda vs old 0.1612 CPU fallback.",
    }
    # per-lang RTF
    per = {}
    for r in ok:
        per.setdefault(r["lang"], {"n": 0, "audio_s": 0.0, "infer_s": 0.0})
        per[r["lang"]]["n"] += 1
        per[r["lang"]]["audio_s"] += r["duration_s"]
        per[r["lang"]]["infer_s"] += r["infer_s"]
    for lang, m in per.items():
        m["rtf"] = m["infer_s"] / max(m["audio_s"], 1e-9)
    summary["per_lang"] = per
    write_json(OUT / "results.json", {"summary": summary, "utterances": results})
    write_json(OUT / "summary.json", summary)
    write_json(PACK / "summary.json", summary)
    write_json(PACK / "micro_results.json", {"summary": summary, "n_utterances": len(results)})
    md = [
        f"# IndicConformer-600M cuDNN9 CUDA RTF\n\n**When:** {ist_now()}\n",
        f"**GPU:** {summary['gpu']}\n**ORT providers:** {providers}\n",
        f"**Old RTF (CPU fallback):** {OLD_RTF}\n**New RTF (this run):** {overall_rtf}\n",
        f"**N ok/total:** {len(ok)}/{len(results)} (cap/lang={cap_per_lang})\n",
        f"**Audio/Infer/Wall s:** {total_audio:.1f} / {total_infer:.1f} / {wall:.1f}\n",
        f"**Timeout/hang:** {hung}\n**Thread env:** {summary['thread_env']}\n",
        f"**GPU max mem GiB:** {gpu_mem}\n\n## Per-lang RTF\n\n",
        "| Lang | N | RTF |\n|---|---:|---:|\n",
    ]
    for lang, m in sorted(per.items()):
        md.append(f"| {lang} | {m['n']} | {m['rtf']:.4f} |\n")
    (OUT / "SUMMARY.md").write_text("".join(md), encoding="utf-8")
    (PACK / "SUMMARY.md").write_text("".join(md), encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": overall_rtf is not None and len(ok) > 0, "time": ist_now(),
                                    "new_rtf": overall_rtf, "old_rtf": OLD_RTF, "n_ok": len(ok)})
    print("D DONE", json.dumps({k: summary[k] for k in ("new_rtf_cuda","n_ok","old_rtf_cpu_fallback","hung_or_timeout")}, indent=2), flush=True)
    return summary


def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    install_stack()
    # Prefer N=100/lang; if hang, caller may re-invoke with CAP=20
    cap = int(os.environ.get("D_CAP_PER_LANG", "100"))
    timeout = int(os.environ.get("D_TIMEOUT_S", "3600"))
    try:
        run_eval(cap, timeout)
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-2000:]}"
        write_json(PACK / "DONE.json", {"ok": False, "time": ist_now(), "error": err})
        (PACK / "SUMMARY.md").write_text(f"# D FAILED\n\n{err}\n", encoding="utf-8")
        print("D FAIL", err, flush=True)
        raise


if __name__ == "__main__":
    main()
