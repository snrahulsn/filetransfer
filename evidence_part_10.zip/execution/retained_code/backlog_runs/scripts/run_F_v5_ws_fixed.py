#!/usr/bin/env python3
"""F v5: Voxtral Mini Realtime — correct WS protocol (commit-before-append)."""
from __future__ import annotations
import asyncio, base64, json, os, sys, time, traceback, subprocess, signal
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now():
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for envp in (Path("/workspace/.hf_token_env"),):
    if envp.exists():
        for line in envp.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "TOKEN=" in line and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN", ""))
os.environ["VLLM_USE_FLASHINFER_SAMPLER"] = "0"
os.environ.setdefault("VLLM_DISABLE_COMPILE_CACHE", "1")

OUT = Path("/workspace/voxtral_mini_realtime_asr")
PACK = Path("/workspace/backlog_runs/pack_F_voxtral_mini_realtime_asr")
PACK_V5 = Path("/workspace/backlog_runs/pack_F_voxtral_mini_realtime_asr_v5")
OUT.mkdir(parents=True, exist_ok=True)
PACK.mkdir(parents=True, exist_ok=True)
PACK_V5.mkdir(parents=True, exist_ok=True)
MODEL = "mistralai/Voxtral-Mini-4B-Realtime-2602"
PORT = 8020

def gather_clips():
    man = OUT / "clips_manifest.json"
    if man.exists():
        try:
            return json.loads(man.read_text())[:6]
        except Exception:
            pass
    clips = []
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
    if cache.exists():
        for lang in ("hi_in", "en_us", "ta_in"):
            d = cache / lang
            if d.exists():
                for p in sorted(d.glob("*.wav"))[:2]:
                    clips.append({"path": str(p), "lang": lang})
    return clips[:6]

async def transcribe_one(path, uri):
    import websockets, soundfile as sf, numpy as np, librosa
    audio, sr = sf.read(path, dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    pcm = (np.clip(audio, -1, 1) * 32767).astype("int16").tobytes()
    t0 = time.perf_counter(); ttfa = None; parts = []; events = []; final_text = ""
    async with websockets.connect(uri, max_size=16_000_000, open_timeout=120) as ws:
        msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=60))
        events.append({"recv": msg.get("type"), "id": msg.get("id")})
        if msg.get("type") != "session.created":
            return {"path": path, "ttfa_s": None, "text": "", "error": f"unexpected bootstrap {msg}", "events_tail": events}
        # Official protocol: session.update(model) then commit (start), then append, then commit final
        await ws.send(json.dumps({"type": "session.update", "model": MODEL}))
        await ws.send(json.dumps({"type": "input_audio_buffer.commit"}))
        chunk_size = 4096
        for i in range(0, len(pcm), chunk_size):
            await ws.send(json.dumps({
                "type": "input_audio_buffer.append",
                "audio": base64.b64encode(pcm[i:i+chunk_size]).decode("utf-8"),
            }))
        await ws.send(json.dumps({"type": "input_audio_buffer.commit", "final": True}))
        deadline = time.perf_counter() + 120
        while time.perf_counter() < deadline:
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=30)
            except Exception as e:
                events.append({"recv_timeout_or_err": str(e)})
                break
            data = json.loads(raw); typ = data.get("type", "")
            events.append({"type": typ, "keys": list(data.keys())[:8]})
            if typ == "transcription.delta":
                delta = data.get("delta") or ""
                if delta and ttfa is None:
                    ttfa = time.perf_counter() - t0
                if delta:
                    parts.append(str(delta))
            elif typ == "transcription.done":
                final_text = data.get("text") or "".join(parts)
                if final_text and ttfa is None:
                    ttfa = time.perf_counter() - t0
                events.append({"usage": data.get("usage")})
                break
            elif typ == "error":
                events.append({"error": data.get("error") or data})
                break
    text = final_text or "".join(parts)
    return {"path": path, "ttfa_s": ttfa, "text": text, "total_s": time.perf_counter() - t0,
            "events_n": len(events), "events_tail": events[-20:]}

def write_pack(result):
    for P in (PACK, PACK_V5, OUT):
        wj(P / "results.json", result)
        wj(P / "results_v5.json", result)
    md = (f"# F Voxtral Mini Realtime ASR (v5 WS-fixed)\n\n**When:** {now()}\n**Model:** `{MODEL}`\n"
          f"**OK:** {result.get('ok')}\n**TTFA p50:** {result.get('ttfa_p50')}\n**Clips:** {result.get('clips_n')}\n"
          f"**Protocol:** session.created → session.update(model) → commit → append → commit final\n"
          f"**Serve:** {result.get('serve_flags')}\n\n## Rows\n"
          + "\n".join(f"- {r}" for r in result.get("rows", [])) + "\n")
    if result.get("blocker"):
        md += f"\n**Blocker:** {result['blocker']}\n"
    for P in (PACK, PACK_V5, OUT):
        (P / "SUMMARY.md").write_text(md, encoding="utf-8")
        wj(P / "DONE.json", {"ok": result.get("ok"), "time": now(), "ttfa_p50": result.get("ttfa_p50"),
                             "blocker": result.get("blocker")})

def main():
    clips = gather_clips()
    wj(OUT / "clips_manifest.json", clips)
    print(f"clips={len(clips)} OUT={OUT}", flush=True)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "websockets", "soundfile", "librosa", "numpy"], check=False)
    logf = OUT / "vllm_serve_v5.log"
    cmd = [sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", MODEL,
           "--tokenizer-mode", "mistral", "--config-format", "mistral", "--load-format", "mistral",
           "--trust-remote-code", "--max-model-len", "8192", "--gpu-memory-utilization", "0.85",
           "--host", "127.0.0.1", "--port", str(PORT),
           "--compilation-config", '{"cudagraph_mode":"PIECEWISE"}',
           "--enforce-eager"]
    print("SPAWN", cmd, flush=True)
    proc = subprocess.Popen(cmd, stdout=open(logf, "w"), stderr=subprocess.STDOUT)
    import urllib.request
    ready = False
    for i in range(150):
        if proc.poll() is not None:
            print("vllm exited early", proc.returncode, flush=True)
            break
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/v1/models", timeout=2)
            ready = True
            break
        except Exception:
            time.sleep(5)
            if i % 6 == 0:
                print(f"waiting... {i*5}s", flush=True)
    if not ready:
        tail = logf.read_text(errors="replace")[-4000:] if logf.exists() else ""
        try:
            proc.terminate()
        except Exception:
            pass
        result = {"ok": False, "blocker": "vllm not ready enforce-eager PIECEWISE", "log_tail": tail,
                  "model": MODEL, "timestamp": now(), "clips_n": len(clips), "rows": []}
        write_pack(result)
        print("F_BLOCKED", flush=True)
        return
    uri = f"ws://127.0.0.1:{PORT}/v1/realtime"
    rows = []
    for c in clips:
        path = c.get("path") or c.get("file") or c.get("wav")
        try:
            rows.append(asyncio.run(transcribe_one(path, uri)))
        except Exception as e:
            rows.append({"path": path, "error": f"{type(e).__name__}: {e}", "ttfa_s": None, "text": ""})
        print("ROW", {k: rows[-1].get(k) for k in ("path","ttfa_s","text","error","events_n")}, flush=True)
    try:
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=45)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    ttfas = [r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"), (int, float))]
    texts_ok = sum(1 for r in rows if (r.get("text") or "").strip())
    result = {"ok": bool(ttfas) and texts_ok > 0, "model": MODEL, "rows": rows, "clips_n": len(clips),
              "ttfa_p50": (sorted(ttfas)[len(ttfas)//2] if ttfas else None),
              "texts_ok": texts_ok, "timestamp": now(),
              "serve_flags": "--enforce-eager + cudagraph_mode=PIECEWISE; VLLM_USE_FLASHINFER_SAMPLER=0",
              "protocol": "commit-before-append (v5)"}
    if not result["ok"]:
        result["blocker"] = "WS connected but no transcription.delta/done (or empty text)" if ready else result.get("blocker")
    write_pack(result)
    print("F_DONE", result["ttfa_p50"], "texts_ok", texts_ok, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        write_pack({"ok": False, "blocker": err[-2000:], "rows": [], "clips_n": 0, "timestamp": now()})
        raise
