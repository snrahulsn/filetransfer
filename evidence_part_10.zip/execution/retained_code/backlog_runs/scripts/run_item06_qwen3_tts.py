#!/usr/bin/env python3
"""Item 6: Qwen3-TTS Base synth via qwen-tts + Hindi LoRA best-effort."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf

BASE = Path("/workspace/models/Qwen3-TTS-12Hz-0.6B-Base")
OUT = Path(f"/workspace/backlog_runs/item_workspaces/pack_item06_qwen3_tts_base_hi_lora_{DATE}")
LORA_ID = "aguken-ai/Qwen-3-TTS-12Hz-0.6B-Base-hi-LoRA-Finetuned"
FLEURS = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")

SEARCH_NOTES = {
    "queries": [
        "models?search=qwen3-tts-hindi",
        "models?search=Qwen3-TTS+LoRA",
        "models?author=xrahul16",
    ],
    "xrahul16_models": [],
    "candidates": [
        "aguken-ai/Qwen-3-TTS-12Hz-0.6B-Base-hi-LoRA-Finetuned (apache-2.0) -- SELECTED",
        "akashicmarga/qwen3-tts-hindi-lora (apache-2.0, MLX)",
        "littleFishhhh/Qwen3-TTS-12Hz-0.6B-Hindi-SFT-Merged (apache-2.0, merged SFT)",
    ],
    "selection_reason": "Matches 0.6B Base + Hindi LoRA + apache-2.0 + PEFT adapter (not MLX-only)",
}

PROMPTS = [
    {"id": "hi_short", "text": "आपकी बैठक कल दोपहर तीन बजे है।", "language": "Hindi", "lang": "hi"},
    {"id": "en_short", "text": "Your meeting with Priya is tomorrow at three thirty PM.", "language": "English", "lang": "en"},
]

def ensure_qwen_tts():
    try:
        import qwen_tts  # noqa
        return True, f"present {getattr(qwen_tts,'__version__', '?')}"
    except Exception:
        p = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", "qwen-tts"],
                           capture_output=True, text=True, timeout=600)
        try:
            import qwen_tts  # noqa
            return p.returncode == 0, f"installed rc={p.returncode} err={p.stderr[-400:]}"
        except Exception as e:
            return False, f"install failed rc={p.returncode} import={e} stderr={p.stderr[-800:]}"

def pick_ref(lang_dir):
    man = FLEURS / f"manifest_{lang_dir}.jsonl"
    for line in man.read_text(encoding="utf-8").splitlines():
        r = json.loads(line)
        if 3.0 <= float(r.get("duration_s") or 0) <= 8.0 and Path(r["wav"]).exists() and r.get("reference"):
            return r
    # fallback first
    r = json.loads(man.read_text(encoding="utf-8").splitlines()[0])
    return r

def synth_clone(tts, text, language, ref_wav, ref_text, out_wav):
    t0 = time.perf_counter()
    wavs, sr = tts.generate_voice_clone(
        text=text,
        language=language,
        ref_audio=str(ref_wav),
        ref_text=ref_text,
        x_vector_only_mode=False,
        non_streaming_mode=True,
        max_new_tokens=512,
        do_sample=True,
        top_k=50,
        top_p=0.95,
        temperature=0.7,
        repetition_penalty=1.05,
    )
    y = np.asarray(wavs[0], dtype=np.float32).reshape(-1)
    sf.write(str(out_wav), y, int(sr))
    gen_s = time.perf_counter() - t0
    dur = len(y) / float(sr)
    return {
        "ok": True, "wav": str(out_wav), "duration_s": dur, "sr": int(sr),
        "gen_s": gen_s, "rtf": gen_s / (dur + 1e-9),
        "rms": float(np.sqrt(np.mean(y * y))) if len(y) else 0.0,
        "peak": float(np.max(np.abs(y))) if len(y) else 0.0,
    }

def main():
    gpu = nvidia_info()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "wavs").mkdir(exist_ok=True)
    status = {"item": 6, "when": ist_now(), "gpu": gpu, "base_path": str(BASE), "search_notes": SEARCH_NOTES}

    ok_pkg, pkg_note = ensure_qwen_tts()
    status["qwen_tts_install"] = pkg_note
    if not ok_pkg:
        status["status"] = "BLOCKED"
        status["base_ok"] = False
        status["base_error"] = pkg_note
        write_json(OUT / "results.json", status)
        write_summary(OUT, f"# Item 6 BLOCKED\n\nqwen-tts install failed:\n{pkg_note}\n")
        finalize_pack(OUT, f"pack_item06_qwen3_tts_base_hi_lora_{DATE}.zip")
        return

    from qwen_tts import Qwen3TTSModel
    print("load base", BASE, flush=True)
    t0 = time.perf_counter()
    tts = Qwen3TTSModel.from_pretrained(
        str(BASE),
        device_map="cuda:0",
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    )
    status["base_load_s"] = time.perf_counter() - t0

    refs = {
        "hi": pick_ref("hi_in"),
        "en": pick_ref("en_us"),
    }
    status["refs"] = {k: {"wav": v["wav"], "text": v["reference"], "utt": v.get("utt_id")} for k, v in refs.items()}

    base_rows = []
    for p in PROMPTS:
        ref = refs["hi" if p["lang"] == "hi" else "en"]
        outw = OUT / "wavs" / f"base_{p['id']}.wav"
        try:
            r = synth_clone(tts, p["text"], p["language"], ref["wav"], ref["reference"], outw)
            r.update(p)
            r["ref_utt"] = ref.get("utt_id")
            base_rows.append(r)
            print("base", p["id"], r["duration_s"], r["rtf"], flush=True)
        except Exception:
            base_rows.append({**p, "ok": False, "error": traceback.format_exc()[-1500:]})
            print("base FAIL", p["id"], flush=True)
    status["base_rows"] = base_rows
    status["base_ok"] = any(r.get("ok") for r in base_rows)

    # Hindi LoRA best-effort: try peft on underlying model if exposed; else try merged SFT fallback note
    lora_status = {"lora_id": LORA_ID, "license": "apache-2.0"}
    try:
        # Probe underlying HF module
        inner = getattr(tts, "model", None) or getattr(tts, "tts_model", None) or getattr(tts, "_model", None)
        if inner is None:
            # inspect attrs
            attrs = [a for a in dir(tts) if not a.startswith("__")]
            lora_status["tts_attrs_sample"] = attrs[:40]
            raise RuntimeError("Could not find underlying nn.Module for PEFT attach")
        from peft import PeftModel
        print("attach LoRA", LORA_ID, flush=True)
        peft_model = PeftModel.from_pretrained(inner, LORA_ID, token=os.environ["HF_TOKEN"])
        # rebind if possible
        if hasattr(tts, "model"):
            tts.model = peft_model
        elif hasattr(tts, "tts_model"):
            tts.tts_model = peft_model
        else:
            tts._model = peft_model
        lora_rows = []
        for p in PROMPTS:
            if p["lang"] != "hi":
                continue
            ref = refs["hi"]
            outw = OUT / "wavs" / f"lora_{p['id']}.wav"
            try:
                r = synth_clone(tts, p["text"], p["language"], ref["wav"], ref["reference"], outw)
                r.update(p)
                lora_rows.append(r)
                print("lora", p["id"], r["duration_s"], flush=True)
            except Exception:
                lora_rows.append({**p, "ok": False, "error": traceback.format_exc()[-1200:]})
        lora_status["rows"] = lora_rows
        lora_status["ok"] = any(r.get("ok") for r in lora_rows)
    except Exception:
        lora_status["ok"] = False
        lora_status["error"] = traceback.format_exc()[-2500:]
        lora_status["stamp"] = "LoRA attach/synth failed; search notes retained; base may still be DONE"

    status["lora"] = lora_status
    if status["base_ok"] and lora_status.get("ok"):
        status["status"] = "DONE"
    elif status["base_ok"]:
        status["status"] = "DONE_BASE_LORA_FAILED"
    else:
        status["status"] = "BLOCKED"

    write_json(OUT / "results.json", status)
    write_summary(OUT, f"""# Item 6 -- Qwen3-TTS Base + Hindi LoRA

**When:** {status['when']}
**Base:** `{BASE}`
**Package:** qwen-tts ({pkg_note})
**Status:** {status['status']}
**GPU:** {gpu}

## Base synth (voice-clone API, short hi+en)
{json.dumps(base_rows, indent=2, default=str)[:2500]}

## Hindi LoRA search notes
{json.dumps(SEARCH_NOTES, indent=2)}

## LoRA (`{LORA_ID}`, apache-2.0)
ok={lora_status.get('ok')}
{(lora_status.get('error') or json.dumps(lora_status.get('rows'), indent=2, default=str))[:2000]}
""")
    z, _ = finalize_pack(OUT, f"pack_item06_qwen3_tts_base_hi_lora_{DATE}.zip")
    print("PACK6", z, status["status"], flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        OUT.mkdir(parents=True, exist_ok=True)
        write_json(OUT / "results.json", {"item": 6, "status": "BLOCKED", "error": traceback.format_exc(), "search_notes": SEARCH_NOTES})
        write_summary(OUT, f"# Item 6 BLOCKED\n\n{traceback.format_exc()[-2000:]}\n")
        finalize_pack(OUT, f"pack_item06_qwen3_tts_base_hi_lora_{DATE}.zip")
