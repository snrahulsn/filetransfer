#!/usr/bin/env python3
"""Rerun 01: peft + Hindi LoRA (adapters/hindi_female) on Qwen3-TTS Base."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
tok = load_hf_token()
os.environ["HF_TOKEN"] = tok
os.environ["HUGGING_FACE_HUB_TOKEN"] = tok

import numpy as np
import torch
import soundfile as sf
from huggingface_hub import snapshot_download, hf_hub_download

BASE = Path("/workspace/models/Qwen3-TTS-12Hz-0.6B-Base")
LORA_REPO = "aguken-ai/Qwen-3-TTS-12Hz-0.6B-Base-hi-LoRA-Finetuned"
COMBO = "hindi_female"
LORA_SCALE = 0.35
WORK = Path(f"/workspace/backlog_runs/item_workspaces/pack_rerun01_qwen3_hindi_lora_{DATE}")
PACK_NAME = f"pack_rerun01_qwen3_hindi_lora_{DATE}"
HI_TEXT = "आपकी बैठक कल दोपहर तीन बजे है।"

def pip_install(pkg):
    p = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", pkg],
                       capture_output=True, text=True, timeout=600)
    return p.returncode == 0, (p.stderr or p.stdout or "")[-600:]

def ensure_imports():
    notes = {}
    try:
        import peft
        notes["peft"] = getattr(peft, "__version__", "?")
    except Exception:
        ok, n = pip_install("peft")
        import peft
        notes["peft"] = f"{getattr(peft,'__version__','?')} installed:{ok} {n[:100]}"
    try:
        import qwen_tts
        notes["qwen_tts"] = "present"
    except Exception:
        if Path("/workspace/Qwen3-TTS").exists():
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-e", "/workspace/Qwen3-TTS"], timeout=600)
        else:
            pip_install("qwen-tts")
        import qwen_tts
        notes["qwen_tts"] = "installed"
    return notes

def synth_clone(tts, text, language, ref_wav, ref_text, out_wav, max_new_tokens=256):
    t0 = time.perf_counter()
    wavs, sr = tts.generate_voice_clone(
        text=text,
        language=language,
        ref_audio=str(ref_wav),
        ref_text=ref_text,
        x_vector_only_mode=False,
        non_streaming_mode=True,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        top_k=50,
        top_p=0.95,
        temperature=0.7,
        repetition_penalty=1.05,
    )
    y = np.asarray(wavs[0], dtype=np.float32).reshape(-1)
    sf.write(str(out_wav), y, int(sr))
    gen_s = time.perf_counter() - t0
    dur = len(y) / float(sr) if sr else 0.0
    peak = float(np.max(np.abs(y))) if len(y) else 0.0
    return {
        "ok": True, "wav": str(out_wav), "duration_s": round(dur, 4), "sr": int(sr),
        "gen_s": round(gen_s, 4), "rtf": round(gen_s / (dur + 1e-9), 4),
        "rms": float(np.sqrt(np.mean(y * y))) if len(y) else 0.0,
        "peak": peak,
        "language_arg": language, "max_new_tokens": max_new_tokens,
        "duration_plausible": bool(1.0 <= dur <= 8.0 and peak >= 1e-3),
        "near_silent": bool(peak < 1e-3),
    }

def main():
    gpu = nvidia_info()
    WORK.mkdir(parents=True, exist_ok=True)
    (WORK / "wavs").mkdir(exist_ok=True)
    status = {
        "item": "rerun01", "when": ist_now(), "gpu": gpu,
        "base_path": str(BASE), "lora_repo": LORA_REPO, "combo": COMBO,
        "lora_scale": LORA_SCALE, "lora_license": "apache-2.0", "hi_text": HI_TEXT,
    }
    notes = ensure_imports()
    status["imports"] = notes

    from qwen_tts import Qwen3TTSModel
    from peft import PeftModel

    print("download adapter", COMBO, flush=True)
    adapter_root = snapshot_download(
        LORA_REPO, token=tok,
        allow_patterns=[f"adapters/{COMBO}/*"],
    )
    adapter_path = str(Path(adapter_root) / "adapters" / COMBO)
    ref_wav = Path(adapter_path) / "ref.wav"
    ref_txt = Path(adapter_path) / "ref.txt"
    ref_text = ref_txt.read_text(encoding="utf-8").strip() if ref_txt.exists() else HI_TEXT
    status["adapter_path"] = adapter_path
    status["ref"] = {"wav": str(ref_wav), "text": ref_text}

    print("load base", BASE, flush=True)
    t0 = time.perf_counter()
    tts = Qwen3TTSModel.from_pretrained(
        str(BASE), device_map="cuda:0", dtype=torch.bfloat16, attn_implementation="sdpa",
    )
    status["base_load_s"] = round(time.perf_counter() - t0, 3)

    # Attach LoRA to underlying HF module (README wraps whole Qwen3TTSModel; we rebind .model)
    inner = getattr(tts, "model", None)
    if inner is None:
        status["status"] = "BLOCKED"
        status["error"] = "tts.model missing"
        write_json(WORK / "results.json", status)
        write_summary(WORK, "# Rerun01 BLOCKED\n\ntts.model missing\n")
        finalize_pack(WORK, f"{PACK_NAME}.zip")
        return

    print("PeftModel.from_pretrained", adapter_path, flush=True)
    peft_model = PeftModel.from_pretrained(inner, adapter_path, token=tok)
    tts.model = peft_model
    # Optional scale if available on peft wrapper or tts
    scale_note = None
    for obj_name, obj in (("tts", tts), ("peft_model", peft_model), ("inner", peft_model)):
        if hasattr(obj, "set_adapter_scale"):
            try:
                obj.set_adapter_scale(LORA_SCALE)
                scale_note = f"{obj_name}.set_adapter_scale({LORA_SCALE})"
                break
            except Exception as e:
                scale_note = f"{obj_name}.set_adapter_scale err: {e}"
    if scale_note is None:
        # peft scaling via set_adapter if present
        try:
            if hasattr(peft_model, "set_adapter"):
                peft_model.set_adapter("default")
            scale_note = "no set_adapter_scale; using default LoRA scale"
        except Exception as e:
            scale_note = f"scale skip: {e}"
    status["lora_attach"] = "ok"
    status["scale_note"] = scale_note

    # Base rejects language=Hindi; README uses voice-clone with adapter refs; try auto first
    lang_tries = ["auto", "english"]
    rows = []
    for lang in lang_tries:
        outw = WORK / "wavs" / f"lora_{COMBO}_{lang}.wav"
        try:
            r = synth_clone(tts, HI_TEXT, lang, ref_wav if ref_wav.exists() else status["ref"]["wav"],
                            ref_text, outw, max_new_tokens=256)
            r["id"] = f"lora_{COMBO}_{lang}"
            r["text"] = HI_TEXT
            rows.append(r)
            print("synth", lang, r["duration_s"], "plausible", r["duration_plausible"], flush=True)
            if r["duration_plausible"]:
                break
        except Exception:
            rows.append({
                "id": f"lora_{COMBO}_{lang}", "ok": False, "language_arg": lang,
                "text": HI_TEXT, "error": traceback.format_exc()[-1500:],
            })
            print("FAIL", lang, flush=True)

    status["rows"] = rows
    ok_rows = [r for r in rows if r.get("ok") and r.get("duration_plausible")]
    any_ok = [r for r in rows if r.get("ok")]
    if ok_rows:
        status["status"] = "DONE"
        status["selected"] = ok_rows[0]
        status["language_worked"] = ok_rows[0]["language_arg"]
    elif any_ok:
        status["status"] = "DONE_WITH_DURATION_FLAG"
        status["selected"] = any_ok[0]
        status["language_worked"] = any_ok[0]["language_arg"]
        status["duration_flag"] = True
    else:
        status["status"] = "BLOCKED"

    write_json(WORK / "results.json", status)
    sel = status.get("selected") or {}
    write_summary(WORK, f"""# Rerun01 -- Qwen3-TTS Base + Hindi LoRA

**When:** {status['when']}
**Status:** {status['status']}
**Base:** `{BASE}`
**LoRA repo:** `{LORA_REPO}` (apache-2.0)
**Adapter subfolder:** `adapters/{COMBO}` (NOT repo root -- adapter_config.json lives here)
**LoRA scale:** {LORA_SCALE} ({scale_note})
**Language that worked:** {status.get('language_worked')} (base rejects language=Hindi; used auto/english)
**GPU:** {gpu}

## Hindi text
(Unicode in results.json; ASCII summary omits Devanagari glyphs)

## Selected synth
- duration_s: {sel.get('duration_s')}
- rms/peak: {sel.get('rms')} / {sel.get('peak')}
- RTF: {sel.get('rtf')}
- duration_plausible: {sel.get('duration_plausible')}
- near_silent: {sel.get('near_silent')}
- language_arg: {sel.get('language_arg')}
- ref: adapter ref.wav / ref.txt

## All rows
{json.dumps(rows, indent=2, default=str, ensure_ascii=True)[:3500]}

## Notes
- Prior failure #1: missing peft.
- Prior failure #2 (this rerun first attempt): PeftModel pointed at repo root; adapters live under adapters/hindi_female|hindi_male.
- README quickstart: PeftModel.from_pretrained(adapter_path) + set_adapter_scale(0.35) + voice-clone with adapter ref.
""")
    z, _ = finalize_pack(WORK, f"{PACK_NAME}.zip")
    print("PACK_RERUN01", z, status["status"], flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        WORK.mkdir(parents=True, exist_ok=True)
        write_json(WORK / "results.json", {"item": "rerun01", "status": "BLOCKED", "error": traceback.format_exc()[-3000:]})
        write_summary(WORK, f"# Rerun01 BLOCKED\n\n{traceback.format_exc()[-2000:]}\n")
        finalize_pack(WORK, f"{PACK_NAME}.zip")
