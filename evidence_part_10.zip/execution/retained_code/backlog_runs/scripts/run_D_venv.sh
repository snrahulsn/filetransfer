#!/bin/bash
set -u
LOG=/workspace/backlog_runs/logs/D_venv.nohup
exec > >(tee -a "$LOG") 2>&1
echo "=== D_venv start $(date -Is) ==="
VENV=/workspace/backlog_runs/venvs/d_ort
mkdir -p /workspace/backlog_runs/venvs /workspace/backlog_runs/logs
python3 -m venv "$VENV"
source "$VENV/bin/activate"
python -m pip install -q -U pip wheel
# Matched stack: torch 2.4.1+cu124, transformers 4.46, ort-gpu 1.19.2, cudnn 9.1
python -m pip install -q torch==2.4.1 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124
python -m pip install -q transformers==4.46.3 accelerate huggingface_hub soundfile sentencepiece jiwer numpy
python -m pip install -q nvidia-cudnn-cu12==9.1.0.70
python -m pip install -q onnxruntime-gpu==1.19.2

# LD path for ORT CUDA — venv-local cudnn only (torch 2.4 matches 9.1)
CUDNN=$(python - <<'PY'
import glob,sys
print(':'.join(glob.glob(sys.prefix+'/lib/python*/site-packages/nvidia/cudnn/lib')+glob.glob(sys.prefix+'/lib/python*/site-packages/nvidia/cublas/lib')+glob.glob(sys.prefix+'/lib/python*/site-packages/nvidia/cuda_runtime/lib')))
PY
)
export LD_LIBRARY_PATH="$CUDNN:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 ORT_NUM_THREADS=1
export OMP_WAIT_POLICY=PASSIVE TOKENIZERS_PARALLELISM=false HF_HOME=/workspace/hf_cache
source /workspace/.hf_token_env 2>/dev/null || true
export D_CAP_PER_LANG="${D_CAP_PER_LANG:-20}" D_TIMEOUT_S="${D_TIMEOUT_S:-1800}"

python - <<'PY'
import torch, transformers, onnxruntime as ort
print('torch', torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0))
print('transformers', transformers.__version__)
print('ort', ort.__version__, ort.get_available_providers())
assert torch.cuda.is_available()
assert 'CUDAExecutionProvider' in ort.get_available_providers()
print('ENV_OK')
PY

python /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py
rc=$?
echo "=== D_venv micro rc=$rc $(date -Is) ==="
python - <<'PY' || exit $rc
import json
from pathlib import Path
d=json.loads(Path('/workspace/backlog_runs/pack_D_indicconformer_cudnn9/DONE.json').read_text())
print('DONE', d)
raise SystemExit(0 if d.get('ok') and d.get('new_rtf') is not None and d.get('n_ok',0)>=10 else 1)
PY
echo "Expanding N=100"
export D_CAP_PER_LANG=100 D_TIMEOUT_S=7200
python /workspace/backlog_runs/scripts/run_D_v2_cuda_rtf.py
echo "=== D_venv N100 rc=$? $(date -Is) ==="
