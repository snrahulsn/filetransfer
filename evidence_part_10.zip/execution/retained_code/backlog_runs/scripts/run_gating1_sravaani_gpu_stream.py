#!/usr/bin/env python3
"""Gating #1: SraVaani-0.5-live TRUE streaming on GPU (partials, TTFA p50, cancel, N=1/2/4)."""
from __future__ import annotations
import json, os, sys, time, traceback, inspect
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf
from transformers import AutoModel

OUT = Path("/workspace/backlog_runs/pack_gating1_sravaani_gpu_stream")
OUT.mkdir(parents=True, exist_ok=True)
MODEL_ID = "ARTPARK-IISc/SraVaani-0.5-live"  # same as prior pack_C

def find_clip():
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache/hi_in")
    for p in sorted(cache.glob("*.wav"))[:1]:
        return p
    # fallback tone
    sr = 16000
    t = np.linspace(0, 3.0, sr * 3, endpoint=False)
    wav = (0.1 * np.sin(2 * np.pi * 220 * t)).astype(np.float32)
    path = OUT / "fallback_tone.wav"
    sf.write(path, wav, sr)
    return path

def load_audio(wav_path):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
        sr = 16000
    return audio.astype(np.float32), sr

def stream_once(model, audio, cancel_after=None, block_s=0.25, want_partials=True, lookahead_ms=None):
    """True streaming via new_stream / stream_audio / finalize."""
    t0 = time.perf_counter()
    ttfa = None
    partials = []
    cancelled = False
    final = None
    err = None
    device = next(model.parameters()).device if hasattr(model, "parameters") else torch.device("cuda" if torch.cuda.is_available() else "cpu")
    try:
        if lookahead_ms is not None and hasattr(model, "set_lookahead_ms"):
            model.set_lookahead_ms(lookahead_ms)
        assert hasattr(model, "new_stream") and hasattr(model, "stream_audio"), "missing stream API"
        state = model.new_stream()
        block = int(block_s * 16000)
        for i in range(0, len(audio), block):
            if cancel_after is not None and ttfa is not None and (time.perf_counter() - t0) >= cancel_after:
                cancelled = True
                break
            chunk = audio[i : i + block]
            text = model.stream_audio(state, chunk)
            now = time.perf_counter() - t0
            if text and ttfa is None:
                ttfa = now
            if want_partials and text:
                partials.append({"t": round(now, 4), "text": text})
        if not cancelled:
            if hasattr(model, "finalize"):
                final = model.finalize(state)
            elif hasattr(model, "finish_stream"):
                final = model.finish_stream(state)
            elif partials:
                final = partials[-1]["text"]
        stream_kind = "new_stream/stream_audio/finalize"
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"
        stream_kind = "error"
    total = time.perf_counter() - t0
    return {
        "ok": err is None,
        "error": err,
        "ttfa_s": ttfa,
        "total_s": total,
        "cancelled": cancelled,
        "n_partials": len(partials),
        "partials": partials[:25],
        "final": final,
        "stream_kind": stream_kind,
        "device": str(device),
    }

def document_stream_api(model):
    """Document how streaming is exposed (Python API; no first-party WS/HTTP)."""
    methods = {}
    for name in ("new_stream", "stream_audio", "finalize", "finish_stream", "set_att_context_size",
                 "set_lookahead_ms", "transcribe"):
        if hasattr(model, name):
            fn = getattr(model, name)
            try:
                methods[name] = str(inspect.signature(fn))
            except Exception:
                methods[name] = "present"
        else:
            methods[name] = None
    cfg = {}
    if hasattr(model, "config"):
        c = model.config
        for attr in ("att_context_size", "supported_att_context_sizes", "lookahead_seconds"):
            if hasattr(c, attr):
                try:
                    cfg[attr] = getattr(c, attr)
                except Exception:
                    pass
    return {
        "transport": "in-process Python API (NOT WebSocket / NOT HTTP chunked server)",
        "evidence": "Model card documents mic loop: new_stream → stream_audio(pcm) → finalize(s). No WS/HTTP endpoint shipped in ARTPARK-IISc/SraVaani-0.5-live.",
        "methods": methods,
        "config": cfg,
        "chunk_policy": "Any float32 @16kHz block size; probe uses 0.25s blocks",
        "cancel": "No dedicated cancel() API; cancel = stop feeding stream_audio and discard state (soft abort)",
        "ws_http": False,
    }

def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    assert gpu.get("cuda") is True, f"GPU required for gating#1, got {gpu}"
    clip = find_clip()
    audio, sr = load_audio(clip)
    print("clip", clip, "dur", len(audio)/sr, flush=True)

    print("load", MODEL_ID, flush=True)
    t_load = time.perf_counter()
    model = AutoModel.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    model = model.to("cuda").eval()
    load_s = time.perf_counter() - t_load

    # Prove params on CUDA
    param_dev = str(next(model.parameters()).device)
    print("param_device", param_dev, "load_s", load_s, flush=True)
    assert "cuda" in param_dev, param_dev

    api_doc = document_stream_api(model)
    write_json(OUT / "stream_api.json", api_doc)

    # Warm-up discard (not counted)
    _ = stream_once(model, audio, want_partials=False)

    # N=1 sequential (8 runs for p50)
    n1_runs = [stream_once(model, audio) for _ in range(8)]
    n1_ttfas = [r["ttfa_s"] for r in n1_runs if r.get("ttfa_s") is not None]

    # Cancel probe
    cancel = stream_once(model, audio, cancel_after=0.12)

    # Concurrent N=2 / N=4
    def one(_):
        return stream_once(model, audio, want_partials=False).get("ttfa_s")
    conc = {}
    for n in (2, 4):
        t0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=n) as ex:
            ttfas = list(ex.map(one, range(n)))
        conc[f"N{n}"] = {"n": n, "ttfas": ttfas, "wall_s": time.perf_counter() - t0,
                         "summary": summarize_ttfas(ttfas)}

    # Optional: also measure cold after reload note already discarded; report first of n1 as warm
    results = {
        "when": ist_now(),
        "model_id": MODEL_ID,
        "gpu": gpu,
        "param_device": param_dev,
        "load_s": load_s,
        "clip": str(clip),
        "stream_api": api_doc,
        "n1_sequential": {
            "n": len(n1_ttfas),
            "ttfas": n1_ttfas,
            "summary": summarize_ttfas(n1_ttfas),
            "partials_run0": n1_runs[0].get("n_partials"),
            "runs_meta": [{"ok": r["ok"], "ttfa_s": r["ttfa_s"], "n_partials": r["n_partials"],
                           "stream_kind": r["stream_kind"], "cancelled": r["cancelled"]} for r in n1_runs],
        },
        "cancel": cancel,
        "concurrency": conc,
        "notes": [
            "True streaming via new_stream/stream_audio/finalize on CUDA.",
            "Prior warm pack_C may have been CPU due to cuDNN mismatch; this run asserts cuda param device.",
            "Cancel: soft abort (stop feeding); API has no cancel().",
            "No first-party WS/HTTP chunked server -- client embeds Python stream API.",
        ],
    }
    write_json(OUT / "results.json", results)
    md = f"""# Gating #1 -- SraVaani-0.5-live GPU streaming

**When:** {results['when']}
**Model:** `{MODEL_ID}` (same checkpoint as prior pack_C)
**GPU:** {gpu}
**Param device:** `{param_dev}`
**Load_s:** {load_s:.2f}

## Stream API
- **Transport:** in-process Python (`new_stream` → `stream_audio` → `finalize`)
- **WS/HTTP chunked:** **No** (not shipped by model card / repo)
- **Cancel API:** **No** dedicated cancel(); soft abort by stopping feeds (cancelled={cancel.get('cancelled')})

## Numbers (warm, after 1 discard)
| Metric | Value |
|--------|-------|
| N=1 TTFA p50 (n={len(n1_ttfas)}) | **{summarize_ttfas(n1_ttfas).get('p50')}** |
| N=1 TTFA mean | {summarize_ttfas(n1_ttfas).get('mean')} |
| Partials (run0) | {n1_runs[0].get('n_partials')} |
| Cancel soft-abort | {cancel.get('cancelled')} (ttfa={cancel.get('ttfa_s')}) |
| N=2 TTFA p50 | {conc['N2']['summary'].get('p50')} |
| N=4 TTFA p50 | {conc['N4']['summary'].get('p50')} |

## Supersedes
Prior pack_C warm TTFA (p50≈0.017s) suspected non-GPU / cuDNN mismatch. This pack is the gating GPU streaming measurement.
"""
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    write_json(OUT / "DONE.json", {
        "ok": True,
        "ttfa_p50": summarize_ttfas(n1_ttfas).get("p50"),
        "partials": n1_runs[0].get("n_partials"),
        "cancel": cancel.get("cancelled"),
        "cuda": True,
        "model": MODEL_ID,
    })
    print("DONE", results["n1_sequential"]["summary"], flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        write_json(OUT / "DONE.json", {"ok": False, "error": traceback.format_exc()})
        raise
