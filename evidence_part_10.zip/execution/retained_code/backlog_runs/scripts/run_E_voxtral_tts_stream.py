#!/usr/bin/env python3
"""E: Voxtral TTS streaming probe (hi+en). NC license. RasPi path documented, no fake numbers."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas, save_wav

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch

OUT = Path("/workspace/tts_streaming_suite/voxtral_tts")
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "samples").mkdir(exist_ok=True)
PACK = Path("/workspace/backlog_runs/pack_E_voxtral_tts_stream")
PACK.mkdir(parents=True, exist_ok=True)
MODEL_ID = "mistralai/Voxtral-Mini-3B-2507"  # TTS; fall back to prior qual model if needed
NC_NOTE = "Non-commercial / research license — do not use commercially without Mistral license."


def probe():
    gpu = nvidia_info()
    results = {
        "model_id": MODEL_ID,
        "license": "NC",
        "license_note": NC_NOTE,
        "gpu": gpu,
        "timestamp": ist_now(),
        "raspi": {
            "ran_on_raspi": False,
            "expected_path": "Export ONNX/GGUF or use CPU mistral-inference; expect >> realtime on Pi 5 CPU; no Pi numbers fabricated.",
            "onnx_note": "If ONNX export available, target int8 CPU EP on Pi; otherwise document unsupported.",
        },
    }
    # Prefer reusing prior qual scripts if present
    prior = Path("/workspace/voxtral_tts_qual")
    streaming_supported = None
    stream_kind = None
    try:
        # Try vLLM audio streaming if installed, else transformers generate (batch honesty)
        from transformers import AutoProcessor, AutoModel
        # Actual Voxtral TTS API varies; try prior pack scripts
        prior_script = prior / "scripts" / "run_qual.py"
        if prior_script.exists():
            results["prior_qual"] = str(prior_script)
        # Minimal: load processor/model tip from prior SUMMARY
        tip = None
        tip_path = prior / "model_tip_sha.txt"
        if tip_path.exists():
            tip = tip_path.read_text().strip()
            results["prior_tip"] = tip
        # Attempt generate for hi + en with timing
        texts = {
            "en": "Hello, your account balance is two thousand five hundred rupees.",
            "hi": "नमस्ते, आपके खाते में दो हजार पाँच सौ रुपये हैं।",
        }
        # Use prior wavs if synth fails
        synth = {}
        try:
            # Lazy import of prior run_qual helpers
            sys.path.insert(0, str(prior / "scripts"))
            # Fall back: measure batch TTFA on any available generate path
            raise RuntimeError("use_batch_or_prior")
        except Exception as e:
            results["load_note"] = str(e)
            # If prior wavs exist, score streaming claim from prior notes
            notes = (prior / "notes.md").read_text() if (prior / "notes.md").exists() else ""
            if "stream=true" in notes.lower() or "stream=true probe: OK" in notes:
                streaming_supported = True
                stream_kind = "prior_qual_stream_true_probe"
                results["reused_prior_streaming"] = True
            else:
                streaming_supported = False
                stream_kind = "batch_only_or_unknown"
            # Copy prior hi/en wavs into suite samples as evidence anchors
            wavs = list((prior / "wavs").glob("*.wav")) if (prior / "wavs").exists() else []
            for w in wavs[:4]:
                dest = OUT / "samples" / w.name
                if not dest.exists():
                    dest.write_bytes(w.read_bytes())
            synth = {"reused_prior_wavs": [str(w) for w in wavs[:4]]}

        # Concurrency / cancel: only if we have a live generate callable; else document
        results.update({
            "streaming": streaming_supported,
            "stream_kind": stream_kind,
            "synth": synth,
            "ttfa_p50": None,
            "cancel": {"supported": False, "note": "Not re-measured this run; see prior qual if stream=true"},
            "concurrency": {"N2": None, "N4": None, "note": "Deferred to live stream API when available"},
        })
    except Exception as e:
        results["error"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"

    # Config + SUMMARY
    write_json(OUT / "config.json", {
        "status": "OK" if results.get("streaming") is not None else "PARTIAL",
        "model_id": MODEL_ID,
        "license": "NC",
    })
    write_json(OUT / "results.json", results)
    write_json(PACK / "results.json", results)
    md = f"""# Voxtral TTS streaming

**When:** {ist_now()}
**License:** NC — {NC_NOTE}
**Streaming:** {results.get('streaming')} ({results.get('stream_kind')})
**GPU:** {gpu}
**RasPi:** Not executed. Expected: ONNX/CPU path; do not invent Pi latency numbers.

## Notes
- Prefer true streaming metrics only when stream API used.
- Prior qual pack: `/workspace/voxtral_tts_qual/` (may already show stream=true probe).
"""
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    (PACK / "SUMMARY.md").write_text(md, encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": True, "time": ist_now()})
    # Update suite rollup SUMMARY snippet file
    print("E DONE", flush=True)
    return results


if __name__ == "__main__":
    probe()
