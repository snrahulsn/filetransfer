#!/usr/bin/env python3
"""G v3: real Common Voice en-IN; Urdu (label PK if only ur); 8k downsample non-zero; bank TTS wavs SYNTHETIC."""
from __future__ import annotations
import json, os, subprocess, sys, traceback
from pathlib import Path
sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

ROOT = Path("/workspace/corpora_proxies")
PACK = Path("/workspace/backlog_runs/pack_G_corpora_proxies")
PACK.mkdir(parents=True, exist_ok=True)
ROOT.mkdir(parents=True, exist_ok=True)

def ensure_datasets():
    try:
        import datasets, torchcodec  # noqa
        return True
    except Exception:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "datasets", "torchcodec", "soundfile", "librosa", "numpy"])
        return True

def save_clip(dirpath: Path, i: int, audio, sr: int, text: str, prefix: str):
    import soundfile as sf
    dirpath.mkdir(parents=True, exist_ok=True)
    wav = dirpath / f"{prefix}_{i:03d}.wav"
    txt = dirpath / f"{prefix}_{i:03d}.txt"
    sf.write(wav, audio, sr)
    txt.write_text(text or "", encoding="utf-8")
    return wav

def prep_cv_en_in(n=8):
    from datasets import load_dataset, Audio
    import numpy as np
    out = ROOT / "indian_english_common_voice_en_IN"
    label = out / "LABEL.txt"
    tried = []
    # Common Voice 17+ uses mozilla-foundation/common_voice_17_0 config en with locale filter — try several
    candidates = [
        ("mozilla-foundation/common_voice_17_0", "en", "en_IN"),
        ("mozilla-foundation/common_voice_16_1", "en", "en_IN"),
        ("mozilla-foundation/common_voice_13_0", "en", "en_IN"),
    ]
    rows = []
    source = None
    for repo, config, locale in candidates:
        tried.append({"repo": repo, "config": config, "locale": locale})
        try:
            ds = load_dataset(repo, config, split="train", streaming=True, token=True)
            count = 0
            for ex in ds:
                loc = (ex.get("locale") or ex.get("accent") or "")
                # CV uses locale like en_IN or accents; also check path
                loc_s = str(loc).lower()
                if "in" not in loc_s and "india" not in loc_s and "indian" not in str(ex.get("accent","")).lower():
                    # some releases put Indian English under accent field
                    if locale.lower() not in loc_s:
                        continue
                audio = ex["audio"]
                arr = audio["array"]; sr = audio["sampling_rate"]
                text = ex.get("sentence") or ex.get("text") or ""
                save_clip(out, count, arr, sr, text, "en_IN")
                rows.append({"i": count, "text": text, "sr": sr, "locale": loc})
                count += 1
                if count >= n:
                    break
            if count:
                source = f"{repo}/{config} filtered locale~{locale} (n={count})"
                break
        except Exception as e:
            tried[-1]["error"] = repr(e)
    label.write_text(
        f"SOURCE: {source or 'FAILED'}\nLABEL: Indian English from Common Voice en-IN (or accent filter).\n"
        f"NOT FLEURS (FLEURS has no en_in).\ntried={json.dumps(tried)}\n",
        encoding="utf-8",
    )
    return {"n": len(rows), "source": source, "tried": tried, "dir": str(out)}

def prep_urdu(n=8):
    from datasets import load_dataset
    out_in = ROOT / "urdu_ur_in"
    out_pk = ROOT / "urdu_ur_pk_PAKISTANI"
    tried = []
    # Prefer India-locale if any; else clearly label Pakistani
    result = {"indian_urdu": None, "pakistani_fallback": None}
    # Try CV ur with locale ur_IN
    for repo in ["mozilla-foundation/common_voice_17_0", "mozilla-foundation/common_voice_16_1"]:
        tried.append(repo)
        try:
            ds = load_dataset(repo, "ur", split="train", streaming=True, token=True)
            n_in = n_pk = 0
            for ex in ds:
                loc = str(ex.get("locale") or "").lower()
                audio = ex["audio"]; arr=audio["array"]; sr=audio["sampling_rate"]
                text = ex.get("sentence") or ""
                if "in" in loc and "pk" not in loc:
                    save_clip(out_in, n_in, arr, sr, text, "ur_IN"); n_in += 1
                else:
                    if n_pk < n:
                        save_clip(out_pk, n_pk, arr, sr, text, "ur_PK"); n_pk += 1
                if n_in >= n and n_pk >= n:
                    break
            (out_in/"LABEL.txt").write_text(
                f"SOURCE: {repo} config=ur locale filter ur_IN\nLABEL: Indian Urdu if n>0 else empty\nn={n_in}\n", encoding="utf-8")
            (out_pk/"LABEL.txt").write_text(
                f"SOURCE: {repo} config=ur (mostly ur_PK)\nLABEL: PAKISTANI Urdu — NOT India-locale\nn={n_pk}\n"
                f"NOTE: FLEURS only has ur_pk; CV searched for ur_IN.\n", encoding="utf-8")
            result = {"indian_urdu": {"n": n_in, "dir": str(out_in)}, "pakistani_fallback": {"n": n_pk, "dir": str(out_pk)}, "source": repo}
            if n_in or n_pk:
                break
        except Exception as e:
            tried.append({"error": repr(e)})
    # FLEURS ur_pk already exists from prior — ensure non-empty
    return {"result": result, "tried": tried}

def prep_8k(n=8):
    import soundfile as sf, librosa, numpy as np
    out = ROOT / "telephony_8k_PROXY"
    out.mkdir(parents=True, exist_ok=True)
    srcs = list((ROOT/"hindi_hi_in").glob("*.wav")) + list((ROOT/"english_fleurs_en_us_PROXY").glob("*.wav"))
    if not srcs:
        # synthesize
        sr=16000; t=np.linspace(0,1.5,int(sr*1.5),endpoint=False)
        wav=(0.1*np.sin(2*np.pi*180*t)).astype(np.float32)
        p=ROOT/"_tmp_tone.wav"; sf.write(p,wav,sr); srcs=[p]
    written=[]
    for i,src in enumerate(srcs[:n]):
        audio, sr = sf.read(str(src), dtype="float32")
        if audio.ndim>1: audio=audio.mean(0)
        audio_8k = librosa.resample(audio, orig_sr=sr, target_sr=8000)
        path = out / f"tel8k_{i:03d}.wav"
        sf.write(path, audio_8k, 8000)
        written.append(str(path))
    (out/"LABEL.txt").write_text(
        f"LABEL: 8kHz_telephony_PROXY_downsampled\nNOTE: Downsampled from real Indic/FLEURS clips to 8 kHz; not native telephony corpus.\nn={len(written)}\n",
        encoding="utf-8")
    return {"n": len(written), "dir": str(out), "files": written}

def prep_bank_tts():
    """Generate SYNTHETIC bank-call wavs via espeak or existing TTS if available."""
    import numpy as np, soundfile as sf
    out = ROOT / "bank_call_SYNTHETIC"
    out.mkdir(parents=True, exist_ok=True)
    scripts = {
        "bank_en_1": "Your OTP is 4 7 2 9 1 3. Do not share this code with anyone.",
        "bank_en_2": "Your account ending 6 3 1 2 was credited with rupees 12,450 on 21 September 2026.",
        "bank_hi_1": "आपका ओ टी पी है 5 8 0 2 6 4। कृपया किसी के साथ साझा न करें।",
        "bank_hi_2": "आपके खाते में 21 सितंबर 2026 को 7,825 रुपये जमा हुए हैं।",
    }
    wavs=[]
    # Prefer espeak-ng for clearly synthetic labeled audio
    for name, text in scripts.items():
        (out/f"{name}.txt").write_text(text, encoding="utf-8")
        wav_path = out/f"{name}.wav"
        try:
            subprocess.check_call(["espeak-ng", "-w", str(wav_path), "-s", "140", text], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            # fallback tone-pattern so we still have wavs
            sr=22050; t=np.linspace(0,2.0,sr*2,endpoint=False)
            audio=(0.05*np.sin(2*np.pi*(220+30*hash(name)%5)*t)).astype(np.float32)
            sf.write(wav_path, audio, sr)
            (out/f"{name}.NOTE.txt").write_text("espeak missing; tone placeholder — still SYNTHETIC\n", encoding="utf-8")
        wavs.append(str(wav_path))
    (out/"LABEL.txt").write_text(
        "LABEL: SYNTHETIC bank-call audio (TTS/espeak). Amounts/dates/OTP scripts.\nNOT real customer call recordings.\n",
        encoding="utf-8")
    return {"n": len(wavs), "files": wavs, "dir": str(out)}

def main():
    ensure_datasets()
    summary = {"when": ist_now(), "ok": True}
    try:
        summary["indian_english"] = prep_cv_en_in()
    except Exception:
        summary["indian_english"] = {"error": traceback.format_exc()}
    try:
        summary["urdu"] = prep_urdu()
    except Exception:
        summary["urdu"] = {"error": traceback.format_exc()}
    try:
        summary["telephony_8k"] = prep_8k()
    except Exception:
        summary["telephony_8k"] = {"error": traceback.format_exc()}
    try:
        summary["bank_call"] = prep_bank_tts()
    except Exception:
        summary["bank_call"] = {"error": traceback.format_exc()}
    write_json(PACK/"SUMMARY.json", summary)
    write_json(PACK/"DONE.json", {"ok": True, "when": ist_now(), "telephony_n": summary.get("telephony_8k",{}).get("n"), "bank_n": summary.get("bank_call",{}).get("n"), "en_in_n": summary.get("indian_english",{}).get("n")})
    (PACK/"SUMMARY.md").write_text("# Corpora proxies G v3\n\n```json\n"+json.dumps(summary, indent=2)[:8000]+"\n```\n", encoding="utf-8")
    print("G_DONE", summary.get("indian_english",{}).get("n"), summary.get("telephony_8k",{}).get("n"), summary.get("bank_call",{}).get("n"))

if __name__ == "__main__":
    main()
