#!/usr/bin/env python3
"""C: SraVaani-0.5-live streaming TTFA / partials / cancel / N=2,4."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf
from transformers import AutoModel

OUT = Path("/workspace/fleurs_asr_trio/SraVaani-0.5-live/stream_probe")
OUT.mkdir(parents=True, exist_ok=True)
PACK = Path("/workspace/backlog_runs/pack_C_sravaani_stream")
PACK.mkdir(parents=True, exist_ok=True)
MODEL_ID = "ARTPARK-IISc/SraVaani-0.5-live"


def find_clip():
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
    for p in sorted(cache.rglob("*.wav")):
        return p
    # synthesize tone fallback
    sr = 16000
    t = np.linspace(0, 2.0, sr * 2, endpoint=False)
    wav = (0.1 * np.sin(2 * np.pi * 220 * t)).astype(np.float32)
    path = OUT / "fallback_tone.wav"
    sf.write(path, wav, sr)
    return path


def stream_once(model, wav_path, cancel_after=None, want_partials=True):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
        sr = 16000
    # Feed in ~0.25s blocks via new_stream / stream_audio if available
    t0 = time.perf_counter()
    ttfa = None
    partials = []
    cancelled = False
    final = None
    err = None
    try:
        if hasattr(model, "new_stream") and hasattr(model, "stream_audio"):
            state = model.new_stream()
            block = int(0.25 * 16000)
            for i in range(0, len(audio), block):
                if cancel_after is not None and ttfa is not None and (time.perf_counter() - t0) >= cancel_after:
                    cancelled = True
                    break
                chunk = audio[i : i + block]
                text = model.stream_audio(state, chunk)
                now = time.perf_counter() - t0
                if text and ttfa is None:
                    ttfa = now
                if want_partials and text:
                    partials.append({"t": now, "text": text})
            if hasattr(model, "finish_stream"):
                final = model.finish_stream(state)
            elif partials:
                final = partials[-1]["text"]
            stream_kind = "new_stream/stream_audio"
        else:
            # Fallback: chunked transcribe with verbose_chunks
            t0 = time.perf_counter()
            if cancel_after is not None:
                # Not truly cancellable via API — document honesty
                pass
            texts = model.transcribe([str(wav_path)], verbose_chunks=want_partials)
            total = time.perf_counter() - t0
            final = texts[0] if texts else ""
            ttfa = total  # batch TTFA honesty
            stream_kind = "transcribe_verbose_chunks_batchish"
            partials = [{"t": total, "text": final}] if final else []
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
        stream_kind = "error"
    total = time.perf_counter() - t0
    return {
        "ok": err is None,
        "error": err,
        "ttfa_s": ttfa,
        "total_s": total,
        "cancelled": cancelled,
        "n_partials": len(partials),
        "partials": partials[:20],
        "final": final,
        "stream_kind": stream_kind,
        "wav": str(wav_path),
    }


def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    clip = find_clip()
    print("clip", clip, flush=True)
    print("load", MODEL_ID, flush=True)
    model = AutoModel.from_pretrained(MODEL_ID, trust_remote_code=True)
    if torch.cuda.is_available():
        model = model.to("cuda")
    model.eval()
    if hasattr(model, "config") and hasattr(model.config, "supported_att_context_sizes"):
        print("lookaheads", model.config.supported_att_context_sizes, flush=True)

    runs = [stream_once(model, clip) for _ in range(2)]
    cancel = stream_once(model, clip, cancel_after=0.3)

    def one():
        return stream_once(model, clip, want_partials=False).get("ttfa_s")

    conc = {}
    for n in (2, 4):
        try:
            t0 = time.perf_counter()
            with ThreadPoolExecutor(max_workers=n) as ex:
                ttfas = list(ex.map(lambda _: one(), range(n)))
            conc[f"N{n}"] = {"n": n, "ttfas": ttfas, "wall_s": time.perf_counter() - t0,
                             "summary": summarize_ttfas(ttfas)}
        except Exception as e:
            conc[f"N{n}"] = {"n": n, "error": str(e)}

    results = {
        "model_id": MODEL_ID,
        "gpu": gpu,
        "timestamp": ist_now(),
        "stream_runs": runs,
        "cancel": cancel,
        "concurrency": conc,
        "ttfa_p50": summarize_ttfas([r.get("ttfa_s") for r in runs]).get("p50"),
        "notes": "Uses model.new_stream/stream_audio when present; else honest batch-ish transcribe.",
    }
    write_json(OUT / "results.json", results)
    write_json(PACK / "results.json", results)
    (OUT / "SUMMARY.md").write_text(
        f"# SraVaani-0.5-live streaming\n\n**When:** {ist_now()}\n**GPU:** {gpu}\n"
        f"**TTFA p50:** {results['ttfa_p50']}\n**Partials (run0):** {runs[0].get('n_partials')}\n"
        f"**Cancel:** {cancel.get('cancelled')} kind={cancel.get('stream_kind')}\n"
        f"**N=2:** {conc.get('N2')}\n**N=4:** {conc.get('N4')}\n",
        encoding="utf-8",
    )
    (PACK / "SUMMARY.md").write_text((OUT / "SUMMARY.md").read_text(), encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": True, "time": ist_now()})
    print("C DONE", flush=True)


if __name__ == "__main__":
    main()
