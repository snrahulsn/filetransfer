#!/usr/bin/env python3
"""Items 1-3: SraVaani streaming WER, wall-clock paced TTFA, lookahead sweep."""
from __future__ import annotations
import json, os, sys, time, traceback, inspect, re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf
from transformers import AutoModel

try:
    import jiwer
except Exception:
    jiwer = None

MODEL_ID = "ARTPARK-IISc/SraVaani-0.5-live"
FLEURS = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
LOOKAHEADS = [1040, 480, 80, 0]  # ms

def load_audio(wav_path):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
        sr = 16000
    return audio.astype(np.float32), sr

def norm_text(t: str) -> str:
    t = (t or "").strip().lower()
    t = re.sub(r"[^\w\s\u0900-\u097F]", " ", t, flags=re.UNICODE)
    return re.sub(r"\s+", " ", t).strip()

def wer_cer(ref, hyp):
    ref_n, hyp_n = norm_text(ref), norm_text(hyp)
    if not ref_n:
        return {"wer": None, "cer": None, "ref": ref, "hyp": hyp}
    if jiwer is None:
        # fallback simple
        rw, hw = ref_n.split(), hyp_n.split()
        # Levenshtein word
        import difflib
        sm = difflib.SequenceMatcher(a=rw, b=hw)
        edits = sum(n for tag, i1, i2, j1, j2 in sm.get_opcodes() for n in ([i2-i1] if tag!='equal' else [0]))
        # rough
        wer = 1.0 - sm.ratio()
        cer = 1.0 - difflib.SequenceMatcher(a=ref_n, b=hyp_n).ratio()
        return {"wer": float(wer), "cer": float(cer), "ref": ref, "hyp": hyp, "fallback": True}
    return {
        "wer": float(jiwer.wer(ref_n, hyp_n)),
        "cer": float(jiwer.cer(ref_n, hyp_n)),
        "ref": ref, "hyp": hyp,
        "ref_n": ref_n, "hyp_n": hyp_n,
    }

def pick_clips(n_hi=5, n_en=2):
    clips = []
    for lang, n in [("hi_in", n_hi), ("en_us", n_en)]:
        man = FLEURS / f"manifest_{lang}.jsonl"
        if not man.exists():
            continue
        rows = [json.loads(l) for l in man.read_text(encoding="utf-8").splitlines() if l.strip()]
        for r in rows[:n]:
            if Path(r["wav"]).exists():
                clips.append(r)
    return clips

def set_lookahead(model, ms):
    notes = []
    if hasattr(model, "set_lookahead_ms"):
        try:
            model.set_lookahead_ms(ms)
            notes.append(f"set_lookahead_ms({ms})")
            return True, notes
        except Exception as e:
            notes.append(f"set_lookahead_ms err: {e}")
    if hasattr(model, "set_att_context_size"):
        # Convert ms to frames roughly: SraVaani card uses att_context_size
        # 1040ms was default; try mapping: frames ~ ms/80 or similar
        # From card settings often [left, right] or single
        try:
            # common pattern: set_att_context_size([left, right]) where right relates to lookahead
            # Prefer direct if signature known
            sig = str(inspect.signature(model.set_att_context_size))
            notes.append(f"set_att_context_size sig={sig}")
            # Heuristic: right context frames = ms / 80 (12.5Hz-ish) or ms/40
            right = max(0, int(round(ms / 80.0)))
            try:
                model.set_att_context_size([70, right])
                notes.append(f"set_att_context_size([70,{right}])")
                return True, notes
            except Exception:
                model.set_att_context_size(right)
                notes.append(f"set_att_context_size({right})")
                return True, notes
        except Exception as e:
            notes.append(f"set_att_context_size err: {e}")
    # config mutation
    if hasattr(model, "config") and hasattr(model.config, "att_context_size"):
        try:
            right = max(0, int(round(ms / 80.0)))
            old = model.config.att_context_size
            if isinstance(old, (list, tuple)) and len(old) >= 2:
                model.config.att_context_size = [old[0], right]
            else:
                model.config.att_context_size = right
            notes.append(f"config.att_context_size -> {model.config.att_context_size}")
            return True, notes
        except Exception as e:
            notes.append(f"config mutate err: {e}")
    return False, notes

def stream_feed(model, audio, block_s=0.25, pace=False, cancel_after=None, want_partials=True):
    """Feed chunks; if pace=True, sleep to realtime wall-clock."""
    t0 = time.perf_counter()
    ttfa = None
    partials = []
    cancelled = False
    final = None
    err = None
    try:
        state = model.new_stream()
        block = int(block_s * 16000)
        for i in range(0, len(audio), block):
            if cancel_after is not None and ttfa is not None and (time.perf_counter() - t0) >= cancel_after:
                cancelled = True
                break
            chunk = audio[i : i + block]
            t_feed = time.perf_counter()
            text = model.stream_audio(state, chunk)
            now = time.perf_counter() - t0
            if text and ttfa is None:
                ttfa = now
            if want_partials and text:
                partials.append({"t": round(now, 4), "text": text})
            if pace:
                # sleep remaining to match chunk duration wall-clock
                elapsed_chunk = time.perf_counter() - t_feed
                sleep_for = block_s - elapsed_chunk
                if sleep_for > 0:
                    time.sleep(sleep_for)
        if not cancelled:
            if hasattr(model, "finalize"):
                final = model.finalize(state)
            elif hasattr(model, "finish_stream"):
                final = model.finish_stream(state)
            elif partials:
                final = partials[-1]["text"]
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
    total = time.perf_counter() - t0
    return {
        "ok": err is None,
        "error": err,
        "ttfa_s": ttfa,
        "total_s": round(total, 4),
        "cancelled": cancelled,
        "n_partials": len(partials),
        "partials": partials[:30],
        "final": final,
        "paced": pace,
    }

def document_api(model):
    methods = {}
    for name in ("new_stream", "stream_audio", "finalize", "finish_stream", "set_att_context_size", "set_lookahead_ms", "transcribe"):
        if hasattr(model, name):
            fn = getattr(model, name)
            try:
                methods[name] = str(inspect.signature(fn))
            except Exception:
                methods[name] = "present"
        else:
            methods[name] = None
    cfg = {}
    if hasattr(model, "config"):
        for attr in ("att_context_size", "supported_att_context_sizes", "lookahead_seconds"):
            if hasattr(model.config, attr):
                try:
                    cfg[attr] = getattr(model.config, attr)
                except Exception:
                    pass
    return {"methods": methods, "config": cfg}

def main():
    gpu = nvidia_info()
    print("GPU", gpu, flush=True)
    assert gpu.get("cuda"), gpu
    clips = pick_clips()
    assert clips, "no FLEURS clips"
    print("clips", len(clips), flush=True)

    print("load", MODEL_ID, flush=True)
    t_load = time.perf_counter()
    model = AutoModel.from_pretrained(MODEL_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    model = model.to("cuda").eval()
    load_s = time.perf_counter() - t_load
    api = document_api(model)
    print("api", api, flush=True)

    # Warm discard
    a0, _ = load_audio(clips[0]["wav"])
    _ = stream_feed(model, a0, pace=False, want_partials=False)

    # ---- Item 1: streaming WER ----
    item1_rows = []
    for c in clips:
        audio, sr = load_audio(c["wav"])
        r = stream_feed(model, audio, pace=False)
        hyp = r.get("final") or (r["partials"][-1]["text"] if r.get("partials") else "")
        m = wer_cer(c.get("reference", ""), hyp or "")
        row = {
            "utt_id": c.get("utt_id"),
            "lang": c.get("lang"),
            "wav": c.get("wav"),
            "duration_s": c.get("duration_s"),
            "reference": c.get("reference"),
            "hypothesis": hyp,
            "ttfa_s": r.get("ttfa_s"),
            "n_partials": r.get("n_partials"),
            "ok": r.get("ok"),
            "error": r.get("error"),
            **{k: m[k] for k in ("wer", "cer") if k in m},
        }
        item1_rows.append(row)
        print("I1", row["utt_id"], "WER", row.get("wer"), "ttfa", row.get("ttfa_s"), flush=True)

    wers = [r["wer"] for r in item1_rows if isinstance(r.get("wer"), (int, float))]
    item1 = {
        "item": 1,
        "model_id": MODEL_ID,
        "when": ist_now(),
        "gpu": gpu,
        "load_s": load_s,
        "n_clips": len(item1_rows),
        "wer_summary": summarize_ttfas(wers),  # reuse for p50/mean
        "cer_summary": summarize_ttfas([r["cer"] for r in item1_rows if isinstance(r.get("cer"), (int, float))]),
        "rows": item1_rows,
        "note": "Streaming finalize hyp vs FLEURS reference; prior gating1 had TTFA only",
    }

    # ---- Item 2: wall-clock paced ----
    paced_runs = []
    audio, sr = load_audio(clips[0]["wav"])
    for i in range(6):
        r = stream_feed(model, audio, pace=True, want_partials=True)
        paced_runs.append(r)
        print("I2 paced", i, "ttfa", r.get("ttfa_s"), "partials", r.get("n_partials"), flush=True)
    cancel = stream_feed(model, audio, pace=True, cancel_after=0.5)
    # also unpaced contrast on same clip
    unpaced = [stream_feed(model, audio, pace=False, want_partials=False) for _ in range(4)]
    item2 = {
        "item": 2,
        "when": ist_now(),
        "clip": clips[0].get("utt_id"),
        "paced_ttfa_summary": summarize_ttfas([r["ttfa_s"] for r in paced_runs]),
        "unpaced_ttfa_summary": summarize_ttfas([r["ttfa_s"] for r in unpaced]),
        "paced_partials_run0": paced_runs[0].get("n_partials"),
        "paced_runs_meta": [{"ok": r["ok"], "ttfa_s": r["ttfa_s"], "n_partials": r["n_partials"], "total_s": r["total_s"]} for r in paced_runs],
        "cancel": {"cancelled": cancel.get("cancelled"), "ttfa_s": cancel.get("ttfa_s"), "n_partials": cancel.get("n_partials")},
        "note": "pace=True sleeps per chunk to realtime wall-clock; prior 39ms was unpack/compute TTFA without pacing",
        "api": api,
    }

    # ---- Item 3: lookaheads ----
    la_table = []
    for ms in LOOKAHEADS:
        ok_set, notes = set_lookahead(model, ms)
        _ = stream_feed(model, audio, pace=False, want_partials=False)  # warm after setting
        runs = [stream_feed(model, audio, pace=True if ms == 1040 else False, want_partials=True) for _ in range(4)]
        # For fairness also unpaced for all
        runs_u = [stream_feed(model, audio, pace=False, want_partials=False) for _ in range(4)]
        finals = [r.get("final") for r in runs if r.get("final")]
        la_table.append({
            "lookahead_ms": ms,
            "set_ok": ok_set,
            "set_notes": notes,
            "paced_ttfa": summarize_ttfas([r["ttfa_s"] for r in runs]),
            "unpaced_ttfa": summarize_ttfas([r["ttfa_s"] for r in runs_u]),
            "partials_mean": float(np.mean([r["n_partials"] for r in runs])),
            "sample_final": (finals[0][:120] if finals else None),
        })
        print("I3 la", ms, la_table[-1]["unpaced_ttfa"], flush=True)

    item3 = {
        "item": 3,
        "when": ist_now(),
        "lookaheads_ms": LOOKAHEADS,
        "table": la_table,
        "api": api,
        "note": "Card settings 1040/480/80/0 ms; uses set_lookahead_ms or set_att_context_size/config fallback",
    }

    # Write packs
    base = Path("/workspace/backlog_runs/item_workspaces")
    # Item 1
    d1 = base / f"pack_item01_sravaani_streaming_wer_{DATE}"
    d1.mkdir(parents=True, exist_ok=True)
    write_json(d1 / "results.json", item1)
    write_summary(d1, f"""# Item 1 -- SraVaani-0.5-live streaming WER

**When:** {item1['when']}
**Model:** `{MODEL_ID}`
**GPU:** {gpu}
**Status:** DONE

## Accuracy (streaming finalize vs FLEURS refs)
| Metric | Value |
|--------|-------|
| n clips | {item1['n_clips']} |
| WER p50 | {item1['wer_summary'].get('p50')} |
| WER mean | {item1['wer_summary'].get('mean')} |
| CER p50 | {item1['cer_summary'].get('p50')} |
| CER mean | {item1['cer_summary'].get('mean')} |

## Note
Prior gating1 pack had TTFA only. This pack adds accuracy fields.

## Per-clip
""" + "\n".join(
        f"- **{r['utt_id']}** WER={r.get('wer')} CER={r.get('cer')} ttfa={r.get('ttfa_s')}"
        for r in item1_rows
    ))
    z1, _ = finalize_pack(d1, f"pack_item01_sravaani_streaming_wer_{DATE}.zip")
    print("PACK1", z1, flush=True)

    d2 = base / f"pack_item02_sravaani_paced_latency_{DATE}"
    d2.mkdir(parents=True, exist_ok=True)
    write_json(d2 / "results.json", item2)
    write_summary(d2, f"""# Item 2 -- SraVaani wall-clock paced latency

**When:** {item2['when']}
**Model:** `{MODEL_ID}`
**Status:** DONE

## Paced TTFA (realtime chunk feed)
| Metric | Value |
|--------|-------|
| paced TTFA p50 | {item2['paced_ttfa_summary'].get('p50')} |
| paced TTFA mean | {item2['paced_ttfa_summary'].get('mean')} |
| paced partials (run0) | {item2['paced_partials_run0']} |
| cancel soft-abort | {item2['cancel'].get('cancelled')} |
| unpaced TTFA p50 (contrast) | {item2['unpaced_ttfa_summary'].get('p50')} |

## Note
Prior ~39ms was unpack/compute TTFA without wall-clock pacing. This pack feeds audio at realtime pace.
Cancel = stop feeding stream_audio (no dedicated cancel API).
""")
    z2, _ = finalize_pack(d2, f"pack_item02_sravaani_paced_latency_{DATE}.zip")
    print("PACK2", z2, flush=True)

    d3 = base / f"pack_item03_sravaani_lookaheads_{DATE}"
    d3.mkdir(parents=True, exist_ok=True)
    write_json(d3 / "results.json", item3)
    lines = ["| lookahead_ms | set_ok | unpaced TTFA p50 | paced TTFA p50 | partials_mean |",
             "|---|---|---|---|---|"]
    for row in la_table:
        lines.append(
            f"| {row['lookahead_ms']} | {row['set_ok']} | {row['unpaced_ttfa'].get('p50')} | {row['paced_ttfa'].get('p50')} | {row['partials_mean']:.1f} |"
        )
    write_summary(d3, f"""# Item 3 -- SraVaani other lookaheads

**When:** {item3['when']}
**Model:** `{MODEL_ID}`
**Status:** DONE
**Lookaheads (ms):** {LOOKAHEADS}

## Comparison table
{chr(10).join(lines)}

## API
```
{json.dumps(api, indent=2)}
```

## Note
Only 1.04s was run previously. This pack sweeps 1040 / 480 / 80 / 0 ms via set_lookahead_ms or set_att_context_size/config.
""")
    z3, _ = finalize_pack(d3, f"pack_item03_sravaani_lookaheads_{DATE}.zip")
    print("PACK3", z3, flush=True)
    write_json(base / "DONE_item123.json", {"ok": True, "zips": [str(z1), str(z2), str(z3)]})

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        write_json(Path("/workspace/backlog_runs/item_workspaces/DONE_item123.json"),
                   {"ok": False, "error": traceback.format_exc()})
        raise
