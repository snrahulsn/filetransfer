#!/usr/bin/env python3
"""Micro WER/RTF for IndicConformer with thread caps; try CUDA then CPU."""
import os, time, json, glob
from pathlib import Path

os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["OMP_NUM_THREADS"] = "2"
os.environ["MKL_NUM_THREADS"] = "2"
# load token
for line in Path("/workspace/.hf_token_env").read_text().splitlines():
    if line.startswith("export "):
        line = line[7:]
    if "=" in line and "TOKEN" in line:
        k,v=line.split("=",1)
        os.environ[k.strip()] = v.strip().strip('"').strip("'")

cudnn = glob.glob("/usr/local/lib/python3.11/dist-packages/nvidia/cudnn/lib")
cublas = glob.glob("/usr/local/lib/python3.11/dist-packages/nvidia/cublas/lib")
os.environ["LD_LIBRARY_PATH"] = ":".join(cudnn+cublas+["/usr/local/cuda/lib64", os.environ.get("LD_LIBRARY_PATH","")])

import torch
torch.set_num_threads(2)
from transformers import AutoModel
import soundfile as sf
import numpy as np

OUT = Path("/workspace/backlog_runs/pack_D_indicconformer_cudnn9")
OUT.mkdir(parents=True, exist_ok=True)

import onnxruntime as ort
print("ort", ort.__version__, ort.get_available_providers(), flush=True)

repo = "ai4bharat/indic-conformer-600m-multilingual"
print("loading", flush=True)
t0 = time.time()
model = AutoModel.from_pretrained(repo, trust_remote_code=True, token=os.environ.get("HF_TOKEN"))
load_s = time.time() - t0
print("loaded", load_s, flush=True)
# move if possible
try:
    model = model.to("cuda")
except Exception as e:
    print("to_cuda_failed", e, flush=True)

# gather a few wavs from fleurs cache
cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
langs = ["hi_in", "en_us", "ta_in", "bn_in"]
items = []
for lang in langs:
    d = cache / lang
    if not d.exists():
        continue
    for wav in sorted(d.glob("*.wav"))[:5]:
        txt = wav.with_suffix(".txt")
        ref = txt.read_text(encoding="utf-8").strip() if txt.exists() else ""
        items.append((lang, wav, ref))
print("items", len(items), flush=True)

rows = []
audio_s = 0.0
infer_s = 0.0
for i, (lang, wav, ref) in enumerate(items):
    audio, sr = sf.read(str(wav), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(0)
    dur = len(audio) / sr
    audio_s += dur
    t1 = time.time()
    try:
        # trust_remote_code API varies — try common patterns
        if hasattr(model, "transcribe"):
            hyp = model.transcribe([str(wav)], language=lang.split("_")[0])[0]
        elif hasattr(model, "__call__"):
            hyp = model(str(wav), language=lang.split("_")[0])
        else:
            hyp = str(model(audio, sr))
        ok = True
        err = None
    except Exception as e:
        hyp = ""
        ok = False
        err = f"{type(e).__name__}: {e}"
    dt = time.time() - t1
    infer_s += dt
    rtf = dt / dur if dur > 0 else None
    rows.append({"lang": lang, "wav": str(wav), "ref": ref, "hyp": hyp, "ok": ok, "err": err, "dur_s": dur, "infer_s": dt, "rtf": rtf})
    print(f"[{i+1}/{len(items)}] {lang} ok={ok} rtf={rtf} err={err} hyp={str(hyp)[:60]}", flush=True)

overall_rtf = infer_s / audio_s if audio_s else None
summary = {
    "model": repo,
    "ort": ort.__version__,
    "providers": ort.get_available_providers(),
    "load_s": load_s,
    "n": len(rows),
    "ok": sum(1 for r in rows if r["ok"]),
    "audio_s": audio_s,
    "infer_s": infer_s,
    "overall_rtf": overall_rtf,
    "old_rtf_cpu_fallback": 0.1612,
    "note": "Micro re-run after pinning onnxruntime-gpu==1.19.2 (CUDA12) + nvidia-cudnn-cu12. Full 1200-utt CUDA EP run hung after 1 utt with ~1958 threads; this is a capped micro probe.",
    "rows": rows,
}
(OUT / "micro_results.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
(OUT / "SUMMARY.md").write_text(
    f"# IndicConformer-600M cuDNN9 / ORT CUDA probe\n\n"
    f"**ORT:** {ort.__version__} providers={ort.get_available_providers()}\n"
    f"**Load s:** {load_s:.2f}\n**N:** {len(rows)} ok={summary['ok']}\n"
    f"**Overall RTF (micro):** {overall_rtf}\n**Old RTF (CPU fallback):** 0.1612\n\n"
    f"{summary['note']}\n",
    encoding="utf-8",
)
print("MICRO_DONE", overall_rtf, flush=True)
