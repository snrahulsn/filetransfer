#!/usr/bin/env python3
import json
from pathlib import Path
import sys
sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json

OUT = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs")
r = json.loads((OUT / "results.json").read_text(encoding="utf-8"))
assert r.get("n_ok", 0) >= 11, r.get("n_ok")
md = f"""# Gating #2 -- IndicF5 per-locale reference voices

**When:** {r.get('when')} (finalized {ist_now()})
**Model:** `{r.get('model_id')}` rev `{r.get('revision')}`
**GPU:** {r.get('gpu')}

## Policy
- Prior 11 listening scores with shared PAN_F_HAPPY ref: **VOID**
- New policy: **per-locale** refs ({r.get('ref_policy')})

## Synth
- n_ok={r.get('n_ok')} n_fail={r.get('n_fail')}
- Listening sheet: `{r.get('listening_sheet_csv')}`

Locales OK: {', '.join(x['locale'] for x in r.get('results', []) if x.get('ok'))}
"""
(OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
write_json(OUT / "DONE.json", {
    "ok": True, "n_ok": r["n_ok"], "n_fail": r.get("n_fail", 0),
    "prior_listening_scores": "VOID", "ref_policy": "per-locale",
    "when": r.get("when"), "finalized": ist_now(),
})
print("G2 finalized", r["n_ok"])
