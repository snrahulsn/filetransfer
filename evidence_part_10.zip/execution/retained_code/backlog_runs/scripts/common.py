#!/usr/bin/env python3
from __future__ import annotations
import json, os
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

def ist_now() -> str:
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

def load_hf_token() -> str:
    tok = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if tok:
        return tok.strip()
    p = Path("/workspace/.hf_token_env")
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "TOKEN=" in line:
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    raise RuntimeError("HF_TOKEN missing")

def nvidia_info() -> dict:
    try:
        import torch
        if not torch.cuda.is_available():
            return {"cuda": False}
        p = torch.cuda.get_device_properties(0)
        return {
            "cuda": True,
            "name": torch.cuda.get_device_name(0),
            "capability": list(torch.cuda.get_device_capability(0)),
            "total_memory_gb": round(p.total_memory / (1024**3), 2),
            "torch": torch.__version__,
            "cudnn": torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else None,
        }
    except Exception as e:
        return {"error": str(e)}

def summarize_ttfas(vals):
    vals = sorted(v for v in vals if isinstance(v, (int, float)))
    if not vals:
        return {"n": 0}
    return {
        "n": len(vals),
        "mean": sum(vals) / len(vals),
        "p50": vals[len(vals) // 2],
        "min": vals[0],
        "max": vals[-1],
    }

def save_wav(path, audio, sr, text=None):
    import numpy as np
    import soundfile as sf
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    audio = np.asarray(audio, dtype=np.float32).reshape(-1)
    sf.write(str(path), audio, sr)
    if text is not None:
        path.with_suffix(".txt").write_text(text.strip() + "\n", encoding="utf-8")
        write_json(path.with_suffix(".json"), {
            "transcript": text, "sample_rate": sr,
            "duration_s": float(len(audio) / sr) if sr else 0.0, "path": str(path),
        })

def zip_dir(src: Path, dest_zip: Path):
    import shutil
    dest_zip = Path(dest_zip)
    if dest_zip.exists():
        dest_zip.unlink()
    base = str(dest_zip.with_suffix(""))
    shutil.make_archive(base, "zip", root_dir=str(src))
    return Path(base + ".zip")
