#!/usr/bin/env bash
set -uo pipefail
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8 LANG=C.UTF-8 LC_ALL=C.UTF-8
export HF_HOME=/workspace/hf_cache HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
if [[ -f /workspace/.hf_token_env ]]; then set -a; source /workspace/.hf_token_env; set +a; fi
source /workspace/tts_streaming_suite/.venv_gpu/bin/activate
LOG=/workspace/backlog_runs/items_post_master.log
exec > >(tee -a "$LOG") 2>&1
echo "==== POST MASTER START $(date) ===="
python /workspace/backlog_runs/scripts/rerun_conformer_scores_4812.py
echo "==== RESCORE rc=$? ===="
python /workspace/backlog_runs/scripts/run_item06_qwen3_tts.py
echo "==== ITEM06 RETRY rc=$? ===="
echo "==== POST MASTER DONE $(date) ===="
touch /workspace/backlog_runs/POST_MASTER_DONE
