#!/usr/bin/env python3
"""F v4: Voxtral Mini Realtime with --enforce-eager (avoids flashinfer nvcc --compress-mode)."""
from __future__ import annotations
import asyncio, base64, json, os, sys, time, traceback, subprocess, signal
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now():
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for envp in (Path("/workspace/.hf_token_env"), Path("/workspace/.hf_token_env")):
    if envp.exists():
        for line in envp.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "TOKEN=" in line and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN", ""))
os.environ["VLLM_USE_FLASHINFER_SAMPLER"] = "0"

# Prefer existing directories from prior backlog runs
OUT = Path("/workspace/voxtral_mini_realtime_asr")
PACK = Path("/workspace/backlog_runs/pack_F_voxtral_mini_realtime_asr")
OUT.mkdir(parents=True, exist_ok=True)
PACK.mkdir(parents=True, exist_ok=True)
MODEL = "mistralai/Voxtral-Mini-4B-Realtime-2602"
PORT = 8020

def gather_clips():
    for man in (OUT / "clips_manifest.json", OUT / "clips_manifest.json"):
        if man.exists():
            try:
                return json.loads(man.read_text())[:6]
            except Exception:
                pass
    clips = []
    for cache in (Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache"), Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")):
        if not cache.exists():
            continue
        for lang in ("hi_in", "en_us", "ta_in"):
            d = cache / lang
            if d.exists():
                for p in sorted(d.glob("*.wav"))[:2]:
                    clips.append({"path": str(p), "lang": lang})
        if clips:
            break
    return clips[:6]

async def transcribe_one(path, uri):
    import websockets, soundfile as sf, numpy as np, librosa
    audio, sr = sf.read(path, dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    pcm = (np.clip(audio, -1, 1) * 32767).astype("int16").tobytes()
    t0 = time.perf_counter(); ttfa = None; parts = []; events = []
    async with websockets.connect(uri, max_size=16_000_000, open_timeout=120) as ws:
        try:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=60))
            events.append({"recv": msg.get("type")})
        except Exception as e:
            events.append({"bootstrap_err": str(e)})
        await ws.send(json.dumps({
            "type": "session.update",
            "session": {"model": MODEL, "modalities": ["text"], "input_audio_format": "pcm16", "transcription_delay_ms": 480},
            "model": MODEL,
        }))
        step = int(16000 * 0.1) * 2
        for i in range(0, len(pcm), step):
            await ws.send(json.dumps({"type": "input_audio_buffer.append", "audio": base64.b64encode(pcm[i:i+step]).decode()}))
            await asyncio.sleep(0.01)
        await ws.send(json.dumps({"type": "input_audio_buffer.commit", "final": True}))
        deadline = time.perf_counter() + 90
        while time.perf_counter() < deadline:
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=15)
            except Exception:
                break
            data = json.loads(raw); typ = data.get("type", "")
            events.append({"type": typ})
            delta = data.get("delta") or data.get("transcript") or data.get("text") or ""
            if not delta and isinstance(data.get("transcription"), dict):
                delta = data["transcription"].get("text") or ""
            if delta and ttfa is None:
                ttfa = time.perf_counter() - t0
            if delta:
                parts.append(str(delta))
            if typ.endswith("done") or typ.endswith("completed") or "transcription.completed" in typ:
                break
    return {"path": path, "ttfa_s": ttfa, "text": "".join(parts), "total_s": time.perf_counter() - t0,
            "events_n": len(events), "events_tail": events[-12:]}

def main():
    clips = gather_clips()
    wj(OUT / "clips_manifest.json", clips)
    print(f"clips={len(clips)} OUT={OUT}", flush=True)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "websockets", "soundfile", "librosa", "numpy"], check=False)
    logf = OUT / "vllm_serve_v4b.log"
    # Prefer working CLI entry used earlier on this pod
    cmd = [sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", MODEL,
           "--tokenizer-mode", "mistral", "--config-format", "mistral", "--load-format", "mistral",
           "--trust-remote-code", "--max-model-len", "8192", "--gpu-memory-utilization", "0.85",
           "--host", "127.0.0.1", "--port", str(PORT),
           "--compilation-config", '{"cudagraph_mode":"PIECEWISE"}',
           "--enforce-eager"]
    print("SPAWN", cmd, flush=True)
    proc = subprocess.Popen(cmd, stdout=open(logf, "w"), stderr=subprocess.STDOUT)
    import urllib.request
    ready = False
    for i in range(120):
        if proc.poll() is not None:
            print("vllm exited early", proc.returncode, flush=True)
            break
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/v1/models", timeout=2)
            ready = True
            break
        except Exception:
            time.sleep(5)
            if i % 6 == 0:
                print(f"waiting... {i*5}s", flush=True)
    if not ready:
        tail = logf.read_text(errors="replace")[-3000:] if logf.exists() else ""
        try:
            proc.terminate()
        except Exception:
            pass
        result = {"ok": False, "blocker": "vllm not ready enforce-eager", "log_tail": tail, "model": MODEL, "timestamp": now(), "clips_n": len(clips)}
        wj(OUT / "results.json", result); wj(PACK / "results.json", result)
        (PACK / "SUMMARY.md").write_text(f"# F Voxtral Mini Realtime ASR\n\n**OK:** False\n**Blocker:** {result['blocker']}\n", encoding="utf-8")
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "blocker": result["blocker"]})
        print("F_BLOCKED", flush=True)
        return
    uri = f"ws://127.0.0.1:{PORT}/v1/realtime"
    rows = []
    for c in clips:
        try:
            rows.append(asyncio.run(transcribe_one(c.get("path") or c.get("file") or c.get("wav"), uri)))
        except Exception as e:
            rows.append({"path": c.get("path") or c.get("file") or c.get("wav"), "error": f"{type(e).__name__}: {e}"})
        print("ROW", rows[-1], flush=True)
    try:
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=30)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    ttfas = [r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"), (int, float))]
    result = {"ok": bool(ttfas), "model": MODEL, "rows": rows, "clips_n": len(clips),
              "ttfa_p50": (sorted(ttfas)[len(ttfas)//2] if ttfas else None), "timestamp": now(),
              "serve_flags": "--enforce-eager + cudagraph_mode=PIECEWISE; VLLM_USE_FLASHINFER_SAMPLER=0"}
    wj(OUT / "results.json", result); wj(PACK / "results.json", result)
    md = (f"# F Voxtral Mini Realtime ASR (v4 enforce-eager)\n\n**When:** {now()}\n**Model:** `{MODEL}`\n"
          f"**OK:** {result['ok']}\n**TTFA p50:** {result['ttfa_p50']}\n**Clips:** {len(clips)}\n\n## Rows\n"
          + "\n".join(f"- {r}" for r in rows) + "\n")
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    (PACK / "SUMMARY.md").write_text(md, encoding="utf-8")
    wj(PACK / "DONE.json", {"ok": result["ok"], "time": now(), "ttfa_p50": result["ttfa_p50"]})
    print("F_DONE", result["ttfa_p50"], flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "error": err[-2000:]})
        (PACK / "SUMMARY.md").write_text(f"# F FAILED\n\n```\n{err[-2000:]}\n```\n", encoding="utf-8")
        raise
