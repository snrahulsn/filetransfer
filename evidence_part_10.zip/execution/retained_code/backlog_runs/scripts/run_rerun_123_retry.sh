#!/bin/bash
set -uo pipefail
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8 LANG=C.UTF-8 LC_ALL=C.UTF-8
export HF_HOME=/workspace/hf_cache HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
if [[ -f /workspace/.hf_token_env ]]; then set -a; source /workspace/.hf_token_env; set +a; fi
cd /workspace
PY=python3
LOG=/workspace/backlog_runs/rerun123_retry.log
exec > >(tee -a "$LOG") 2>&1
echo "=== RETRY START $(date -Is) toklen=${#HF_TOKEN} ==="
$PY -m pip install -q -U peft openai-whisper jiwer soundfile librosa sentencepiece 2>&1 | tail -10
$PY -c "import peft,whisper,jiwer,sentencepiece; print('deps ok', peft.__version__)"
# Ensure progress file exists
mkdir -p /workspace/backlog_runs
cat > /workspace/backlog_runs/PROGRESS_RERUN.md <<EOF
# PROGRESS RERUN 1/2/3
| Item | Status |
|------|--------|
| 1 Qwen3 Hindi LoRA | IN_PROGRESS |
| 2 Whisper EN intelligibility | PENDING |
| 3 SraVaani 480ms accuracy | PENDING |
EOF
echo "=== RERUN01 $(date -Is) ==="
$PY /workspace/backlog_runs/scripts/run_rerun01_qwen3_hindi_lora.py
echo "=== RERUN02 $(date -Is) ==="
$PY /workspace/backlog_runs/scripts/run_rerun02_whisper_en.py
echo "=== RERUN03 $(date -Is) ==="
$PY /workspace/backlog_runs/scripts/run_rerun03_sravaani_480.py
echo "=== ALL RETRY DONE $(date -Is) ==="
echo '{"ok":true,"when":"'"$(date -Is)"'"}' > /workspace/backlog_runs/item_workspaces/DONE_rerun123.json
