#!/usr/bin/env python3
"""F: Qualify Voxtral Mini 4B Realtime ASR on short Indic+en clips."""
from __future__ import annotations
import json, os, sys, time, traceback, base64
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info, summarize_ttfas

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

OUT = Path("/workspace/voxtral_mini_realtime_asr")
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "clips").mkdir(exist_ok=True)
PACK = Path("/workspace/backlog_runs/pack_F_voxtral_mini_realtime_asr")
PACK.mkdir(parents=True, exist_ok=True)
MODEL = "mistralai/Voxtral-Mini-4B-Realtime-2602"


def gather_clips():
    clips = []
    # Prefer fleurs cache hi/en
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
    if cache.exists():
        for lang in ("hi_in", "en_in", "en_us"):
            for p in sorted((cache / lang).glob("*.wav"))[:3] if (cache / lang).exists() else []:
                clips.append({"path": str(p), "lang": lang, "source": "fleurs_cache"})
    # Also audio maya/veena if present
    for p in list(Path("/workspace/audio").rglob("*.wav"))[:4]:
        clips.append({"path": str(p), "lang": "mixed", "source": "audio_tree"})
    return clips[:8]


def try_vllm_realtime(clips):
    """Start vLLM realtime server if possible; else return blocker."""
    import subprocess, shutil
    if shutil.which("vllm") is None:
        # try python -m vllm
        pass
    # Check vllm import
    try:
        import vllm
        vver = getattr(vllm, "__version__", "unknown")
    except Exception as e:
        return {"ok": False, "blocker": f"vllm not importable: {e}", "clips": clips}

    # Launch server
    log = OUT / "vllm_serve.log"
    cmd = [
        sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", MODEL,
        "--tokenizer-mode", "mistral",
        "--config-format", "mistral",
        "--load-format", "mistral",
        "--trust-remote-code",
        "--max-model-len", "8192",
        "--gpu-memory-utilization", "0.85",
        "--host", "127.0.0.1", "--port", "8020",
    ]
    # Fallback simpler serve
    alt = [
        sys.executable, "-m", "vllm.entrypoints.openai.api_server",
        "--model", MODEL, "--host", "127.0.0.1", "--port", "8020",
        "--tokenizer-mode", "mistral", "--trust-remote-code",
    ]
    proc = None
    for c in (cmd, alt):
        try:
            proc = subprocess.Popen(c, stdout=open(log, "w"), stderr=subprocess.STDOUT)
            break
        except Exception as e:
            continue
    if proc is None:
        return {"ok": False, "blocker": "failed to spawn vllm", "vllm_version": vver}

    # Wait for port
    import urllib.request
    ready = False
    for _ in range(60):
        if proc.poll() is not None:
            break
        try:
            urllib.request.urlopen("http://127.0.0.1:8020/v1/models", timeout=2)
            ready = True
            break
        except Exception:
            time.sleep(5)
    if not ready:
        out = {"ok": False, "blocker": "vllm server not ready", "log_tail": log.read_text()[-2000:] if log.exists() else "", "vllm_version": vver}
        proc.terminate()
        return out

    # Transcribe via websocket realtime if websockets available; else HTTP transcription if exposed
    rows = []
    try:
        import asyncio, websockets
        async def one(path):
            uri = "ws://127.0.0.1:8020/v1/realtime"
            t0 = time.perf_counter()
            ttfa = None
            text_parts = []
            async with websockets.connect(uri, max_size=8_000_000) as ws:
                # session bootstrap (best-effort OpenAI-realtime-like)
                await ws.send(json.dumps({"type": "session.update", "session": {"model": MODEL, "modalities": ["text"], "transcription_delay_ms": 480}}))
                import soundfile as sf
                audio, sr = sf.read(path, dtype="float32")
                if audio.ndim > 1:
                    audio = audio.mean(0)
                # PCM16 16k
                if sr != 16000:
                    import librosa
                    audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
                pcm = (np.clip(audio, -1, 1) * 32767).astype("int16").tobytes()
                # append in chunks
                step = 16000  # 1s
                for i in range(0, len(pcm), step * 2):
                    chunk = pcm[i:i + step * 2]
                    await ws.send(json.dumps({"type": "input_audio_buffer.append", "audio": base64.b64encode(chunk).decode()}))
                await ws.send(json.dumps({"type": "input_audio_buffer.commit", "final": True}))
                while True:
                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=30)
                    except Exception:
                        break
                    data = json.loads(msg)
                    typ = data.get("type", "")
                    if "transcript" in typ or "transcription" in typ:
                        delta = data.get("delta") or data.get("transcript") or data.get("text") or ""
                        if delta and ttfa is None:
                            ttfa = time.perf_counter() - t0
                        if delta:
                            text_parts.append(str(delta))
                    if typ.endswith(".done") or typ.endswith("completed"):
                        break
            return {"path": path, "ttfa_s": ttfa, "text": "".join(text_parts), "total_s": time.perf_counter() - t0}

        import numpy as np
        for c in clips[:4]:
            try:
                rows.append(asyncio.get_event_loop().run_until_complete(one(c["path"])))
            except Exception as e:
                rows.append({"path": c["path"], "error": str(e)})
    except Exception as e:
        rows.append({"error": f"realtime client failed: {e}"})

    proc.terminate()
    try:
        proc.wait(timeout=10)
    except Exception:
        proc.kill()
    return {"ok": True, "vllm_version": vver, "rows": rows, "model": MODEL}


def main():
    import numpy as np
    gpu = nvidia_info()
    clips = gather_clips()
    write_json(OUT / "clips_manifest.json", clips)
    print("clips", len(clips), "gpu", gpu, flush=True)
    result = try_vllm_realtime(clips)
    result.update({"gpu": gpu, "timestamp": ist_now(), "model": MODEL})
    write_json(OUT / "results.json", result)
    write_json(PACK / "results.json", result)
    md = f"""# Voxtral Mini 4B Realtime ASR

**When:** {ist_now()}
**Model:** `{MODEL}`
**GPU:** {gpu}
**OK:** {result.get('ok')}
**Blocker:** {result.get('blocker')}
**Clips:** {len(clips)}
"""
    if result.get("rows"):
        md += "\n## Rows\n"
        for r in result["rows"]:
            md += f"- {r}\n"
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    (PACK / "SUMMARY.md").write_text(md, encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": bool(result.get("ok")), "time": ist_now(), "blocker": result.get("blocker")})
    print("F DONE", result.get("ok"), result.get("blocker"), flush=True)


if __name__ == "__main__":
    main()
