#!/usr/bin/env python3
"""E: Voxtral TTS streaming TTFA via vLLM-Omni /v1/audio/speech stream=true. NC license noted."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now(): return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for p in (Path("/workspace/.hf_token_env"), Path("/workspace/.hf_token_env")):
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "): line = line[7:]
            if "TOKEN=" in line and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN", ""))

OUT = Path("/workspace/tts_streaming_suite/voxtral_tts")
PACK = Path("/workspace/backlog_runs/pack_E_voxtral_tts_stream")
OUT.mkdir(parents=True, exist_ok=True); (OUT / "samples").mkdir(exist_ok=True); PACK.mkdir(parents=True, exist_ok=True)
MODEL = "mistralai/Voxtral-4B-TTS-2603"
PORT = int(os.environ.get("E_PORT", "8010"))
NC = "CC BY-NC 4.0 inherited — non-commercial / research only without separate Mistral license."


def try_install_omni():
    log = []
    cmds = [
        [sys.executable, "-m", "pip", "install", "-q", "-U", "pip", "httpx", "soundfile", "numpy"],
        # vllm-omni may not be on PyPI under that name; try both
        [sys.executable, "-m", "pip", "install", "-q", "vllm"],
        [sys.executable, "-m", "pip", "install", "-q", "vllm-omni"],
    ]
    for c in cmds:
        print("RUN", " ".join(c), flush=True)
        p = subprocess.run(c, capture_output=True, text=True)
        log.append({"cmd": c, "rc": p.returncode, "err": (p.stderr or "")[-600:]})
    wj(OUT / "install.json", log)
    return log


def measure_stream_ttfa(text, voice, language, lang_tag):
    import httpx
    url = f"http://127.0.0.1:{PORT}/v1/audio/speech"
    payload = {
        "model": MODEL, "input": text, "voice": voice, "language": language,
        "stream": True, "stream_format": "audio", "response_format": "pcm",
    }
    t0 = time.perf_counter()
    ttfa = None
    nbytes = 0
    chunks = 0
    with httpx.stream("POST", url, json=payload, timeout=180.0) as r:
        r.raise_for_status()
        for chunk in r.iter_bytes():
            if not chunk:
                continue
            if ttfa is None:
                ttfa = time.perf_counter() - t0
            nbytes += len(chunk)
            chunks += 1
    total = time.perf_counter() - t0
    # save raw pcm
    pcm_path = OUT / "samples" / f"{lang_tag}_stream.pcm"
    # re-request non-stream wav for archive if stream gave bytes
    wav_note = None
    try:
        payload2 = dict(payload); payload2["stream"] = False; payload2["response_format"] = "wav"
        del payload2["stream_format"]
        r2 = httpx.post(url, json=payload2, timeout=180.0)
        if r2.status_code == 200 and len(r2.content) > 1000:
            (OUT / "samples" / f"{lang_tag}.wav").write_bytes(r2.content)
            wav_note = "wav_saved"
    except Exception as e:
        wav_note = f"wav_fail:{e}"
    return {
        "lang": lang_tag, "voice": voice, "ttfa_s": ttfa, "total_s": total,
        "bytes": nbytes, "chunks": chunks, "wav_note": wav_note, "streaming": True,
    }


def main():
    gpu = {}
    try:
        import torch
        if torch.cuda.is_available():
            gpu = {"name": torch.cuda.get_device_name(0), "torch": torch.__version__}
    except Exception as e:
        gpu = {"error": str(e)}

    result = {
        "model": MODEL, "license": "NC", "license_note": NC, "gpu": gpu, "timestamp": now(),
        "raspi": {"ran": False, "status": "NOT RUN — no Raspberry Pi hardware available; no fabricated numbers"},
        "streaming": None, "ttfa": None, "rows": [], "blocker": None,
    }

    # Prefer live stream; if omni install/serve fails, document blocker (no fake TTFA)
    try_install_omni()

    logf = OUT / "vllm_omni_serve.log"
    serve_cmds = [
        ["vllm", "serve", MODEL, "--omni", "--port", str(PORT), "--trust-remote-code"],
        [sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", MODEL, "--omni", "--port", str(PORT)],
    ]
    proc = None
    for c in serve_cmds:
        try:
            print("SPAWN", c, flush=True)
            proc = subprocess.Popen(c, stdout=open(logf, "w"), stderr=subprocess.STDOUT)
            break
        except Exception as e:
            print("spawn fail", e, flush=True)
    if proc is None:
        result["blocker"] = "could not spawn vllm --omni"
        result["streaming"] = False
        # reuse prior qual stream=true OK note, but do NOT invent TTFA
        prior = Path("/workspace/voxtral_tts_qual/notes.md")
        if prior.exists() and "stream=true" in prior.read_text().lower():
            result["prior_qual_stream_true"] = True
        wj(OUT / "results.json", result); wj(PACK / "results.json", result)
        (PACK / "SUMMARY.md").write_text(
            f"# Voxtral TTS streaming\n\n**When:** {now()}\n**License:** NC — {NC}\n"
            f"**Streaming measured:** False\n**Blocker:** {result['blocker']}\n"
            f"**RasPi:** NOT RUN\n**Prior qual stream=true:** {result.get('prior_qual_stream_true')}\n",
            encoding="utf-8")
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "blocker": result["blocker"]})
        print("E_BLOCKED", result["blocker"], flush=True)
        return

    import urllib.request
    ready = False
    for i in range(120):
        if proc.poll() is not None:
            break
        for path in (f"http://127.0.0.1:{PORT}/v1/models", f"http://127.0.0.1:{PORT}/health"):
            try:
                urllib.request.urlopen(path, timeout=2); ready = True; break
            except Exception:
                pass
        if ready:
            break
        time.sleep(5)
        if i % 6 == 0:
            print(f"waiting omni... {i*5}s", flush=True)

    if not ready:
        tail = logf.read_text()[-2500:] if logf.exists() else ""
        try: proc.terminate()
        except Exception: pass
        result["blocker"] = "vllm-omni not ready"
        result["log_tail"] = tail
        result["streaming"] = False
        wj(OUT / "results.json", result); wj(PACK / "results.json", result)
        (PACK / "SUMMARY.md").write_text(
            f"# Voxtral TTS streaming\n\n**Blocker:** vllm-omni not ready\n\n```\n{tail}\n```\n"
            f"**RasPi:** NOT RUN\n**License:** NC\n", encoding="utf-8")
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "blocker": result["blocker"]})
        print("E_NOT_READY", flush=True)
        return

    texts = [
        ("en", "casual_female", "English", "Hello, your account balance is two thousand five hundred rupees."),
        ("hi", "hi_female", "Hindi", "नमस्ते, आपके खाते में दो हजार पाँच सौ रुपये हैं।"),
    ]
    rows = []
    for tag, voice, language, text in texts:
        try:
            rows.append(measure_stream_ttfa(text, voice, language, tag))
        except Exception as e:
            rows.append({"lang": tag, "error": f"{type(e).__name__}: {e}", "streaming": False})
        print("ROW", rows[-1], flush=True)

    try:
        proc.terminate(); proc.wait(timeout=30)
    except Exception:
        try: proc.kill()
        except Exception: pass

    ttfas = [r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"), (int, float))]
    result.update({
        "streaming": bool(ttfas),
        "stream_kind": "vllm_omni_audio_speech_stream_pcm" if ttfas else "failed",
        "ttfa_p50": sorted(ttfas)[len(ttfas)//2] if ttfas else None,
        "ttfa_values": ttfas,
        "rows": rows,
    })
    wj(OUT / "results.json", result); wj(PACK / "results.json", result)
    md = (
        f"# Voxtral TTS streaming\n\n**When:** {now()}\n**License:** NC — {NC}\n"
        f"**Streaming:** {result['streaming']} ({result['stream_kind']})\n"
        f"**TTFA p50:** {result['ttfa_p50']}\n**GPU:** {gpu}\n"
        f"**RasPi:** NOT RUN (no hardware)\n\n## Rows\n"
        + "\n".join(f"- {r}" for r in rows) + "\n"
    )
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    (PACK / "SUMMARY.md").write_text(md, encoding="utf-8")
    wj(PACK / "DONE.json", {"ok": bool(ttfas), "time": now(), "ttfa_p50": result["ttfa_p50"]})
    print("E_DONE", result["ttfa_p50"], flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "error": err[-2000:]})
        (PACK / "SUMMARY.md").write_text(f"# E FAILED\n\n```\n{err[-2000:]}\n```\n", encoding="utf-8")
        raise
