#!/usr/bin/env python3
"""Item 5: Veena fuller qualification pack."""
from __future__ import annotations
import json, os, sys, time, traceback, hashlib, re
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf
import jiwer

MODEL_CANDIDATES = ["maya-research/Veena", "MayaResearch/Veena"]
OUT = Path(f"/workspace/backlog_runs/item_workspaces/pack_item05_veena_full_qual_{DATE}")

# Documented speakers from prior pack / README
SPECS = [
    {"id": "veena_hi_kavya", "text": "आपकी बैठक कल दोपहर तीन बजे है।", "lang": "hi", "speaker": "kavya"},
    {"id": "veena_hi_kavya_long", "text": "नमस्ते, मेरा नाम राहुल है। आज का मौसम बहुत अच्छा है और बाज़ार में भीड़ कम है।", "lang": "hi", "speaker": "kavya"},
    {"id": "veena_en_agastya", "text": "Your meeting with Priya is tomorrow at three thirty PM.", "lang": "en", "speaker": "agastya"},
    {"id": "veena_en_agastya_long", "text": "Welcome to Indic Voice. Clear speech makes every product update feel premium.", "lang": "en", "speaker": "agastya"},
]

def decode_snac(snac_model, tokens):
    # Veena SNAC decode pattern from prior script
    import torch
    if not tokens:
        return np.zeros(0, dtype=np.float32)
    codes = torch.tensor(tokens, device=next(snac_model.parameters()).device).unsqueeze(0)
    # reshape depending on SNAC layout - try common 7-code groups
    try:
        from snac import SNAC
    except Exception:
        pass
    # Use prior offset pattern if available
    try:
        # codes as list of 7 codebooks
        if codes.numel() % 7 == 0:
            n = codes.numel() // 7
            c = codes.view(n, 7).T.unsqueeze(0)
            # some SNAC expect list
            audio = snac_model.decode([c[:, i, :] for i in range(7)])
        else:
            audio = snac_model.decode(codes)
        wav = audio.detach().float().cpu().numpy().reshape(-1)
        return wav
    except Exception:
        # alternate
        audio = snac_model.decode(codes)
        return audio.detach().float().cpu().numpy().reshape(-1)

def veena_generate(model, tokenizer, snac, text, speaker, max_new=600):
    # Prompt format from maya-research/Veena
    prompt = f"<speaker_{speaker}>\n{text}\n<audio>"
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    t0 = time.perf_counter()
    with torch.inference_mode():
        out = model.generate(**inputs, max_new_tokens=max_new, do_sample=True, temperature=0.4, top_p=0.9)
    gen_s = time.perf_counter() - t0
    new_tokens = out[0, inputs["input_ids"].shape[-1]:]
    # Extract SNAC token ids (Veena uses special audio token range)
    ids = new_tokens.tolist()
    # Filter to snac-like tokens - heuristic: tokens above a threshold
    # Prior script used specific offsets; reuse decode from text tokens
    # Try: look for tokens that map via tokenizer decode with <custom>
    snac_tokens = []
    for tid in ids:
        # Veena: audio codes typically offset
        snac_tokens.append(tid)
    # Better: use prior pack decode helpers by importing if present
    try:
        sys.path.insert(0, "/workspace/backlog_runs/scripts")
        from run_A_B_maya1_veena import decode_snac_veena, veena_batch
        audio, meta = veena_batch(model, tokenizer, snac, text, speaker=speaker)
        meta = dict(meta or {})
        meta["gen_s"] = meta.get("gen_s", gen_s)
        return np.asarray(audio, dtype=np.float32).reshape(-1), meta
    except Exception as e:
        return None, {"error": traceback.format_exc(), "gen_s": gen_s, "fallback_err": str(e)}

def whisper_score(wav_path, lang, ref):
    try:
        import whisper
        w = getattr(whisper_score, "_m", None)
        if w is None:
            w = whisper.load_model("base")
            whisper_score._m = w
        r = w.transcribe(str(wav_path), language=("hi" if lang.startswith("hi") else "en"))
        hyp = r.get("text", "")
        return {
            "hyp": hyp,
            "wer": float(jiwer.wer(ref.lower(), hyp.lower())) if hyp else None,
            "cer": float(jiwer.cer(ref.lower(), hyp.lower())) if hyp else None,
            "engine": "whisper-base",
        }
    except Exception as e:
        return {"error": str(e), "engine": "whisper-base"}

def conformer_score(wav_path, lang, ref):
    if not lang.startswith("hi"):
        return {"skipped": True, "reason": "conformer primarily for Indic; en optional"}
    try:
        m = getattr(conformer_score, "_m", None)
        if m is None:
            from transformers import AutoModel
            m = AutoModel.from_pretrained("ai4bharat/indic-conformer-600m-multilingual", trust_remote_code=True, token=os.environ["HF_TOKEN"])
            m.eval()  # ORT wrapper; no torch params
            conformer_score._m = m
        audio, sr = sf.read(str(wav_path), dtype="float32")
        if audio.ndim > 1: audio = audio.mean(axis=1)
        if sr != 16000:
            import librosa
            audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
        tensor = torch.from_numpy(audio).float().unsqueeze(0)
        with torch.inference_mode():
            out = m(tensor.to("cuda"), "hi", "ctc")
        hyp = out[0] if isinstance(out, (list, tuple)) else str(out)
        return {"hyp": hyp, "wer": float(jiwer.wer(ref, hyp)), "cer": float(jiwer.cer(ref, hyp)), "engine": "indic-conformer"}
    except Exception as e:
        return {"error": str(e)}

def main():
    gpu = nvidia_info()
    assert gpu.get("cuda"), gpu
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "wavs").mkdir(exist_ok=True)

    from transformers import AutoModelForCausalLM, AutoTokenizer
    from huggingface_hub import model_info, hf_hub_download

    model_id = None
    license_info = {}
    for mid in MODEL_CANDIDATES:
        try:
            info = model_info(mid, token=os.environ["HF_TOKEN"])
            model_id = mid
            license_info = {
                "id": mid,
                "license": getattr(info, "license", None) or (info.cardData or {}).get("license") if hasattr(info, "cardData") else None,
                "tags": list(getattr(info, "tags", None) or [])[:20],
                "sha": getattr(info, "sha", None),
            }
            break
        except Exception as e:
            license_info.setdefault("attempts", []).append({"id": mid, "error": str(e)})
    assert model_id, license_info

    print("model", model_id, license_info, flush=True)
    # SNAC
    from snac import SNAC
    snac = SNAC.from_pretrained("hubertsiuzdak/snac_24khz").to("cuda").eval()
    tok = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id, trust_remote_code=True, torch_dtype=torch.bfloat16, device_map="cuda"
    ).eval()

    rows = []
    for spec in SPECS:
        print("synth", spec["id"], flush=True)
        audio, meta = veena_generate(model, tok, snac, spec["text"], spec["speaker"])
        if audio is None or len(audio) < 100:
            rows.append({**spec, "ok": False, "meta": meta})
            continue
        # peak normalize
        peak = float(np.max(np.abs(audio)) + 1e-9)
        if peak > 1.0:
            audio = audio / peak * 0.95
        path = OUT / "wavs" / f"{spec['id']}.wav"
        sf.write(str(path), audio, 24000)
        dur = len(audio) / 24000.0
        rtf = (meta.get("gen_s") or 0) / dur if dur else None
        wh = whisper_score(path, spec["lang"], spec["text"])
        cf = conformer_score(path, spec["lang"], spec["text"]) if spec["lang"].startswith("hi") else {"skipped": True}
        rows.append({
            **spec, "ok": True, "wav": str(path), "duration_s": dur,
            "gen_s": meta.get("gen_s"), "rtf": rtf, "whisper": wh, "conformer": cf,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })
        print("  dur", dur, "rtf", rtf, "wer", wh.get("wer"), flush=True)

    # Document langs/voices from card/README
    langs_voices = {
        "documented_langs": ["hi", "en"],
        "documented_speakers": ["kavya", "agastya", "maitri", "vinaya"],  # common Veena voices; verify below
        "note": "Primary suite covers hi+en; other speakers listed from model card / prior docs when available",
    }
    try:
        # try read README
        from huggingface_hub import hf_hub_download
        readme = Path(hf_hub_download(model_id, "README.md", token=os.environ["HF_TOKEN"])).read_text(encoding="utf-8", errors="replace")
        (OUT / "README_excerpt.md").write_text(readme[:4000], encoding="utf-8", errors="replace")
        # extract speaker names
        speakers = sorted(set(re.findall(r"speaker[_\s]?([a-zA-Z]+)", readme, flags=re.I)))
        if speakers:
            langs_voices["readme_speakers"] = speakers
    except Exception as e:
        langs_voices["readme_error"] = str(e)

    payload = {
        "item": 5, "when": ist_now(), "gpu": gpu, "model_id": model_id,
        "license": license_info, "langs_voices": langs_voices, "rows": rows,
        "prior_thin_pack": "pack_A_maya1_veena_synth_asr.zip",
    }
    write_json(OUT / "results.json", payload)
    write_summary(OUT, f"""# Item 5 -- Veena full qualification

**When:** {payload['when']}
**Model:** `{model_id}`
**License:** {license_info.get('license')}
**Status:** DONE
**GPU:** {gpu}

## Langs / voices
{json.dumps(langs_voices, indent=2)}

## Synth suite
| id | lang | speaker | dur_s | RTF | Whisper WER | Conformer WER |
|----|------|---------|-------|-----|-------------|----------------|
""" + "\n".join(
        f"| {r.get('id')} | {r.get('lang')} | {r.get('speaker')} | {r.get('duration_s')} | {r.get('rtf')} | {(r.get('whisper') or {}).get('wer')} | {(r.get('conformer') or {}).get('wer')} |"
        for r in rows
    ) + """

## Notes
- Fuller pack vs thin pack_A (hi+en + timing + ASR + SHA256).
- Model id verified via HF API candidates maya-research/Veena and MayaResearch/Veena.
""")
    z, _ = finalize_pack(OUT, f"pack_item05_veena_full_qual_{DATE}.zip")
    print("PACK5", z, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        write_json(OUT / "results.json", {"item": 5, "ok": False, "error": traceback.format_exc()})
        write_summary(OUT, f"# Item 5 -- Veena -- FAILED\n\n```\n{traceback.format_exc()[-2000:]}\n```\n")
        finalize_pack(OUT, f"pack_item05_veena_full_qual_{DATE}.zip")
        raise
