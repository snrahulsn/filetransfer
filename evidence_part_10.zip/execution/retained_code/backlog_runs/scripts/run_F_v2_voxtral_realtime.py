#!/usr/bin/env python3
"""F: Voxtral Mini 4B Realtime ASR via vLLM /v1/realtime WebSocket."""
from __future__ import annotations
import asyncio, base64, json, os, sys, time, traceback, subprocess
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
def now(): return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
def wj(p, o):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(o, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for p in (Path("/workspace/.hf_token_env"), Path("/workspace/.hf_token_env")):
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "): line = line[7:]
            if "TOKEN=" in line and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN", ""))

OUT = Path("/workspace/voxtral_mini_realtime_asr")
PACK = Path("/workspace/backlog_runs/pack_F_voxtral_mini_realtime_asr")
OUT.mkdir(parents=True, exist_ok=True); PACK.mkdir(parents=True, exist_ok=True)
MODEL = "mistralai/Voxtral-Mini-4B-Realtime-2602"
PORT = int(os.environ.get("F_PORT", "8020"))


def gather_clips():
    clips = []
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
    for lang in ("hi_in", "en_us", "ta_in", "bn_in"):
        d = cache / lang
        if d.exists():
            for p in sorted(d.glob("*.wav"))[:2]:
                clips.append({"path": str(p), "lang": lang})
    for p in list(Path("/workspace/audio").rglob("*.wav"))[:4]:
        clips.append({"path": str(p), "lang": "mixed"})
    prep = OUT / "clips"
    if prep.exists():
        for p in sorted(prep.glob("*.wav"))[:6]:
            clips.append({"path": str(p), "lang": "prepared"})
    seen, out = set(), []
    for c in clips:
        if c["path"] not in seen:
            seen.add(c["path"]); out.append(c)
    return out[:6]


def install_vllm():
    log = []
    cmds = [
        [sys.executable, "-m", "pip", "install", "-q", "-U", "pip"],
        [sys.executable, "-m", "pip", "install", "-q", "mistral-common[audio]"],
        [sys.executable, "-m", "pip", "install", "-q", "websockets", "soundfile", "librosa", "numpy"],
        [sys.executable, "-m", "pip", "install", "-q", "vllm"],
    ]
    for c in cmds:
        print("RUN", " ".join(c), flush=True)
        p = subprocess.run(c, capture_output=True, text=True)
        log.append({"cmd": c, "rc": p.returncode, "err": (p.stderr or "")[-800:], "out": (p.stdout or "")[-400:]})
        if p.returncode != 0 and "vllm" in " ".join(c):
            wj(OUT / "vllm_install.json", log)
            return False, log, f"vllm install failed rc={p.returncode}: {(p.stderr or '')[-500:]}"
    wj(OUT / "vllm_install.json", log)
    try:
        import vllm
        return True, log, getattr(vllm, "__version__", "unknown")
    except Exception as e:
        return False, log, f"vllm import failed: {e}"


async def transcribe_one(path, uri):
    import websockets, soundfile as sf, numpy as np, librosa
    audio, sr = sf.read(path, dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    pcm = (np.clip(audio, -1, 1) * 32767).astype("int16").tobytes()
    t0 = time.perf_counter()
    ttfa = None
    parts, events = [], []
    async with websockets.connect(uri, max_size=16_000_000, open_timeout=60) as ws:
        try:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=30))
            events.append({"recv": msg.get("type")})
        except Exception as e:
            events.append({"bootstrap_recv_err": str(e)})
        await ws.send(json.dumps({
            "type": "session.update",
            "session": {
                "model": MODEL,
                "modalities": ["text"],
                "input_audio_format": "pcm16",
                "transcription_delay_ms": 480,
            },
            "model": MODEL,
        }))
        step = int(16000 * 0.1) * 2
        for i in range(0, len(pcm), step):
            chunk = pcm[i:i + step]
            await ws.send(json.dumps({
                "type": "input_audio_buffer.append",
                "audio": base64.b64encode(chunk).decode(),
            }))
            await asyncio.sleep(0.02)
        await ws.send(json.dumps({"type": "input_audio_buffer.commit", "final": True}))
        deadline = time.perf_counter() + 60
        while time.perf_counter() < deadline:
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=10)
            except Exception:
                break
            data = json.loads(raw)
            typ = data.get("type", "")
            events.append({"type": typ})
            delta = data.get("delta") or data.get("transcript") or data.get("text") or ""
            if not delta and isinstance(data.get("transcription"), dict):
                delta = data["transcription"].get("text") or ""
            if delta and ttfa is None:
                ttfa = time.perf_counter() - t0
            if delta:
                parts.append(str(delta))
            if typ.endswith("done") or typ.endswith("completed") or "transcription.completed" in typ:
                break
    return {
        "path": path, "ttfa_s": ttfa, "text": "".join(parts),
        "total_s": time.perf_counter() - t0, "events_n": len(events), "events_tail": events[-8:],
    }


def main():
    clips = gather_clips()
    wj(OUT / "clips_manifest.json", clips)
    print(f"clips={len(clips)}", flush=True)
    ok, log, ver_or_err = install_vllm()
    if not ok:
        result = {"ok": False, "blocker": ver_or_err, "clips": clips, "timestamp": now(), "model": MODEL}
        wj(OUT / "results.json", result); wj(PACK / "results.json", result)
        (PACK / "SUMMARY.md").write_text(
            f"# Voxtral Mini 4B Realtime ASR\n\n**When:** {now()}\n**OK:** False\n**Blocker:** {ver_or_err}\n"
            f"**Clips prepared:** {len(clips)}\n\nNo fake metrics.\n", encoding="utf-8")
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "blocker": ver_or_err})
        print("F_BLOCKED", ver_or_err, flush=True)
        return

    vver = ver_or_err
    logf = OUT / "vllm_serve.log"
    cmd = [
        sys.executable, "-m", "vllm.entrypoints.cli.main", "serve", MODEL,
        "--tokenizer-mode", "mistral", "--config-format", "mistral", "--load-format", "mistral",
        "--trust-remote-code", "--max-model-len", "8192", "--gpu-memory-utilization", "0.85",
        "--host", "127.0.0.1", "--port", str(PORT),
    ]
    alt = [
        "vllm", "serve", MODEL, "--tokenizer-mode", "mistral",
        "--host", "127.0.0.1", "--port", str(PORT), "--trust-remote-code",
        "--max-model-len", "8192", "--gpu-memory-utilization", "0.85",
    ]
    proc = None
    for c in (cmd, alt):
        try:
            print("SPAWN", c, flush=True)
            proc = subprocess.Popen(c, stdout=open(logf, "w"), stderr=subprocess.STDOUT)
            break
        except Exception as e:
            print("spawn fail", e, flush=True)
    if proc is None:
        result = {"ok": False, "blocker": "failed to spawn vllm", "vllm": vver, "timestamp": now()}
        wj(PACK / "results.json", result); wj(PACK / "DONE.json", {"ok": False, **result})
        (PACK / "SUMMARY.md").write_text(f"# F blocked\n\n{result}\n", encoding="utf-8")
        return

    import urllib.request
    ready = False
    for i in range(90):
        if proc.poll() is not None:
            break
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/v1/models", timeout=2)
            ready = True
            break
        except Exception:
            time.sleep(5)
            if i % 6 == 0:
                print(f"waiting vllm... {i*5}s", flush=True)
    if not ready:
        tail = logf.read_text()[-2500:] if logf.exists() else ""
        try:
            proc.terminate()
        except Exception:
            pass
        result = {"ok": False, "blocker": "vllm server not ready", "log_tail": tail, "vllm": vver, "timestamp": now()}
        wj(OUT / "results.json", result); wj(PACK / "results.json", result)
        (PACK / "SUMMARY.md").write_text(f"# F blocked — vLLM not ready\n\n```\n{tail}\n```\n", encoding="utf-8")
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "blocker": result["blocker"]})
        print("F_NOT_READY", flush=True)
        return

    uri = f"ws://127.0.0.1:{PORT}/v1/realtime"
    rows = []
    for c in clips:
        try:
            rows.append(asyncio.run(transcribe_one(c["path"], uri)))
        except Exception as e:
            rows.append({"path": c["path"], "error": f"{type(e).__name__}: {e}"})
        print("ROW", rows[-1], flush=True)

    try:
        proc.terminate(); proc.wait(timeout=20)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass

    ttfas = [r["ttfa_s"] for r in rows if isinstance(r.get("ttfa_s"), (int, float))]
    result = {
        "ok": True, "model": MODEL, "vllm": vver, "rows": rows, "clips_n": len(clips),
        "ttfa_p50": sorted(ttfas)[len(ttfas)//2] if ttfas else None, "timestamp": now(),
    }
    wj(OUT / "results.json", result); wj(PACK / "results.json", result)
    md = [
        f"# Voxtral Mini 4B Realtime ASR\n\n**When:** {now()}\n**Model:** `{MODEL}`\n**vLLM:** {vver}\n"
        f"**OK:** True\n**Clips:** {len(clips)}\n**TTFA p50:** {result['ttfa_p50']}\n\n## Rows\n"
    ]
    for r in rows:
        md.append(f"- {r}\n")
    (OUT / "SUMMARY.md").write_text("".join(md), encoding="utf-8")
    (PACK / "SUMMARY.md").write_text("".join(md), encoding="utf-8")
    wj(PACK / "DONE.json", {"ok": True, "time": now(), "ttfa_p50": result["ttfa_p50"]})
    print("F_DONE", result["ttfa_p50"], flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "error": err[-2000:]})
        (PACK / "SUMMARY.md").write_text(f"# F FAILED\n\n```\n{err[-2000:]}\n```\n", encoding="utf-8")
        raise
