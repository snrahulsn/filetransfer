#!/usr/bin/env python3
"""G: Small public corpus proxies with clear labels."""
from __future__ import annotations
import os, sys
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]
# Prefer soundfile decoding
os.environ.setdefault("HF_DATASETS_AUDIO_DECODER", "soundfile")

OUT = Path("/workspace/corpora_proxies")
OUT.mkdir(parents=True, exist_ok=True)
PACK = Path("/workspace/backlog_runs/pack_G_corpora_proxies")
PACK.mkdir(parents=True, exist_ok=True)


def save_samples(name, ds_id, config, split, n, label, out_dir):
    from datasets import Audio, load_dataset
    import soundfile as sf
    import numpy as np
    out_dir.mkdir(parents=True, exist_ok=True)
    ds = load_dataset(ds_id, config, split=f"{split}[:{n}]")
    # force soundfile decode path
    if "audio" in ds.column_names:
        ds = ds.cast_column("audio", Audio(sampling_rate=16000, decode=True))
    meta = []
    for i, row in enumerate(ds):
        audio = row["audio"]
        arr = np.asarray(audio["array"], dtype="float32")
        sr = int(audio.get("sampling_rate") or 16000)
        text = row.get("transcription") or row.get("sentence") or row.get("text") or ""
        wav = out_dir / f"{name}_{i:03d}.wav"
        sf.write(str(wav), arr, sr)
        (out_dir / f"{name}_{i:03d}.txt").write_text(str(text).strip() + "\n", encoding="utf-8")
        meta.append({"wav": str(wav), "text": text, "sr": sr, "label": label, "config": config})
    write_json(out_dir / "manifest.json", {"label": label, "dataset": ds_id, "config": config, "n": len(meta), "items": meta})
    (out_dir / "LABEL.txt").write_text(label + "\n", encoding="utf-8")
    return meta


def from_local_fleurs_cache(lang, n, label, out_dir):
    """Use pre-extracted wavs under fleurs_asr_trio if present."""
    import shutil
    cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache") / lang
    if not cache.exists():
        cache = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache") / lang
    out_dir.mkdir(parents=True, exist_ok=True)
    wavs = sorted(cache.glob("*.wav"))[:n] if cache.exists() else []
    meta = []
    for i, w in enumerate(wavs):
        dest = out_dir / f"{lang}_{i:03d}.wav"
        shutil.copy2(w, dest)
        txt = w.with_suffix(".txt")
        text = txt.read_text(encoding="utf-8").strip() if txt.exists() else ""
        (out_dir / f"{lang}_{i:03d}.txt").write_text(text + "\n", encoding="utf-8")
        meta.append({"wav": str(dest), "text": text, "sr": 16000, "label": label, "source": str(w)})
    write_json(out_dir / "manifest.json", {"label": label, "n": len(meta), "items": meta, "source": str(cache)})
    (out_dir / "LABEL.txt").write_text(label + "\n", encoding="utf-8")
    return meta


def downsample_8k(items, out_dir):
    import soundfile as sf
    import librosa
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for it in items[:6]:
        arr, sr = sf.read(it["wav"], dtype="float32")
        arr8 = librosa.resample(arr, orig_sr=sr, target_sr=8000)
        path = out_dir / (Path(it["wav"]).stem + "_8k.wav")
        sf.write(str(path), arr8, 8000)
        (out_dir / (path.stem + ".txt")).write_text(it.get("text","").strip() + "\n", encoding="utf-8")
        rows.append({"wav": str(path), "text": it.get("text",""), "sr": 8000, "label": "8kHz_telephony_PROXY_downsampled", "source": it["wav"]})
    write_json(out_dir / "manifest.json", {"label": "8kHz_telephony_PROXY_downsampled", "items": rows})
    (out_dir / "LABEL.txt").write_text("8kHz_telephony_PROXY_downsampled — not native telephony\n", encoding="utf-8")
    return rows


def synth_bank_scripts():
    out = OUT / "bank_call_SYNTHETIC"
    out.mkdir(parents=True, exist_ok=True)
    lines = [
        ("en", "Your one time password is 4 8 2 1 9 3. Please do not share it with anyone."),
        ("en", "Your account ending 1234 has been debited by rupees 15,250 on 21 September 2026."),
        ("hi", "आपका ओ टी पी है ७ ३ १ ५ ९ २। कृपया इसे किसी के साथ साझा न करें।"),
        ("hi", "आपके खाते से २१ सितंबर २०२६ को पंद्रह हज़ार दो सौ पचास रुपये काटे गए हैं।"),
    ]
    items = []
    for i, (lang, text) in enumerate(lines):
        (out / f"bank_{lang}_{i}.txt").write_text(text + "\n", encoding="utf-8")
        items.append({"lang": lang, "text": text, "label": "SYNTHETIC_bank_script", "audio": None})
    write_json(out / "manifest.json", {
        "label": "SYNTHETIC_bank_call_scripts",
        "warning": "NOT real bank calls. Text scripts only (amounts/dates/OTP).",
        "items": items,
    })
    (out / "LABEL.txt").write_text("SYNTHETIC_bank_call_scripts — NOT real bank audio\n", encoding="utf-8")
    return items


def main():
    report = {"timestamp": ist_now(), "sections": {}}
    en = []
    # FLEURS has en_us not en_in — label clearly as non-India-locale English proxy
    try:
        en = from_local_fleurs_cache("en_us", 5, "English_FLEURS_en_us_NOT_en_IN_locale_proxy", OUT / "english_fleurs_en_us_PROXY")
        if not en:
            en = save_samples("en_us", "google/fleurs", "en_us", "test", 5,
                              "English_FLEURS_en_us_NOT_en_IN_locale_proxy", OUT / "english_fleurs_en_us_PROXY")
        report["sections"]["english_proxy"] = {"n": len(en), "label": "FLEURS en_us (NOT en_IN — FLEURS has no en_in)"}
        # Also try Common Voice en if we want India-accent later — note absence of en_in in FLEURS
        report["sections"]["indian_english_note"] = "FLEURS has no en_in config. Used en_us as PROXY and labeled clearly. Prefer IndicTTS/CommonVoice en-IN for true Indian English."
    except Exception as e:
        report["sections"]["english_proxy"] = {"error": str(e)}

    try:
        ur = from_local_fleurs_cache("ur_pk", 5, "Pakistani_Urdu_FLEURS_ur_pk_NOT_Indian", OUT / "urdu_ur_pk_PAKISTANI")
        if not ur:
            ur = save_samples("ur_pk", "google/fleurs", "ur_pk", "test", 5,
                              "Pakistani_Urdu_FLEURS_ur_pk_NOT_Indian", OUT / "urdu_ur_pk_PAKISTANI")
        report["sections"]["urdu"] = {"n": len(ur), "label": "FLEURS ur_pk PAKISTANI (not India-locale)"}
    except Exception as e:
        report["sections"]["urdu"] = {"error": str(e)}

    hi = []
    try:
        hi = from_local_fleurs_cache("hi_in", 5, "Hindi_FLEURS_hi_in", OUT / "hindi_hi_in")
        if not hi:
            hi = save_samples("hi_in", "google/fleurs", "hi_in", "test", 5,
                              "Hindi_FLEURS_hi_in", OUT / "hindi_hi_in")
        report["sections"]["hindi"] = {"n": len(hi)}
    except Exception as e:
        report["sections"]["hindi"] = {"error": str(e)}

    try:
        tel = downsample_8k(en + hi, OUT / "telephony_8k_PROXY")
        report["sections"]["telephony_8k"] = {"n": len(tel), "label": "downsampled_proxy"}
    except Exception as e:
        report["sections"]["telephony_8k"] = {"error": str(e)}

    try:
        bank = synth_bank_scripts()
        report["sections"]["bank_call"] = {"n": len(bank), "label": "SYNTHETIC"}
    except Exception as e:
        report["sections"]["bank_call"] = {"error": str(e)}

    write_json(OUT / "SUMMARY.json", report)
    write_json(PACK / "SUMMARY.json", report)
    md = f"# Corpora proxies\n\n**When:** {ist_now()}\n\n"
    for k, v in report["sections"].items():
        md += f"- **{k}:** {v}\n"
    md += "\nLabels are explicit. ur_pk = Pakistani. Bank = SYNTHETIC. en_us ≠ Indian English.\n"
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    (PACK / "SUMMARY.md").write_text(md, encoding="utf-8")
    write_json(PACK / "DONE.json", {"ok": True, "time": ist_now()})
    print("G DONE", report, flush=True)


if __name__ == "__main__":
    main()
