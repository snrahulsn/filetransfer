#!/bin/bash
set -euo pipefail
cd /workspace
export HF_HOME=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-${HUGGING_FACE_HUB_TOKEN:-}}"
export VLLM_USE_FLASHINFER_SAMPLER=0
export VLLM_DISABLE_COMPILE_CACHE=1
mkdir -p /workspace/backlog_runs/incremental
echo "=== FE start $(date) ===" | tee /workspace/backlog_runs/incremental/FE_v5.log

# Ensure vllm present
python3 -m pip install -q 'vllm>=0.8' websockets soundfile librosa numpy httpx 2>&1 | tee -a /workspace/backlog_runs/incremental/FE_v5.log | tail -5 || true
python3 -c "import vllm; print('vllm', vllm.__version__)" | tee -a /workspace/backlog_runs/incremental/FE_v5.log

echo "=== F v5 ===" | tee -a /workspace/backlog_runs/incremental/FE_v5.log
python3 /workspace/backlog_runs/scripts/run_F_v5_ws_fixed.py 2>&1 | tee -a /workspace/backlog_runs/incremental/FE_v5.log

echo "=== E v3 ===" | tee -a /workspace/backlog_runs/incremental/FE_v5.log
python3 /workspace/backlog_runs/scripts/run_E_v3_tts_stream.py 2>&1 | tee -a /workspace/backlog_runs/incremental/FE_v5.log || true

# Copy packs evidence
mkdir -p /workspace/backlog_runs/pack_E_voxtral_tts_stream_v2
cp -a /workspace/backlog_runs/pack_E_voxtral_tts_stream/* /workspace/backlog_runs/pack_E_voxtral_tts_stream_v2/ 2>/dev/null || true
echo "=== FE done $(date) ===" | tee -a /workspace/backlog_runs/incremental/FE_v5.log
touch /workspace/backlog_runs/incremental/FE_v5.DONE
