#!/bin/bash
set -u
LOG=/workspace/backlog_runs/logs/after_D.nohup
exec >>"$LOG" 2>&1
echo "=== after_D wait $(date -Is) ==="
while pgrep -f run_D_v2_cuda_rtf.py >/dev/null; do
  line=$(tail -c 2000 /workspace/backlog_runs/logs/D_venv.nohup | tr "\r" "\n" | grep -E "^\\[[0-9]+/220\\]" | tail -1)
  echo "$(date +%H:%M:%S) $line"
  sleep 30
done
echo "=== D process ended $(date -Is) ==="
# Collect D pack
python3 - <<'PY'
import json, statistics, time
from pathlib import Path
p=Path("/workspace/backlog_runs/pack_D_indicconformer_cudnn9")
# Prefer results from latest run if script writes them
cands=list(p.glob("*.json"))
print("jsons", [c.name for c in cands])
# Parse RTF from log
rts=[]
for line in Path("/workspace/backlog_runs/logs/D_venv.nohup").read_text(errors="replace").replace("\r","\n").splitlines():
    if "rtf=" in line and line.strip().startswith("["):
        try:
            rts.append(float(line.split("rtf=")[1].split()[0]))
        except Exception:
            pass
summary={
  "n_rtf": len(rts),
  "rtf_mean": (sum(rts)/len(rts) if rts else None),
  "rtf_p50": (sorted(rts)[len(rts)//2] if rts else None),
  "rtf_min": (min(rts) if rts else None),
  "rtf_max": (max(rts) if rts else None),
  "old_cpu_rtf": 0.1612,
  "note": "CUDA EP active; compare to old CPU fallback 0.1612",
  "when": time.strftime("%Y-%m-%d %H:%M:%S IST"),
}
(p/"DONE.json").write_text(json.dumps({"ok": bool(rts), **summary}, indent=2))
(p/"SUMMARY.md").write_text("# IndicConformer CUDA+cuDNN9 RTF\n\n"+json.dumps(summary,indent=2)+"\n")
print(summary)
PY
# Zip D
cd /workspace/backlog_runs && zip -qr packs_local/pack_D_indicconformer_cudnn9_v2.zip pack_D_indicconformer_cudnn9
# Run C warm
export HF_HOME=/workspace/hf_cache
source /workspace/.hf_token_env 2>/dev/null || true
python3 /workspace/backlog_runs/scripts/run_C_warm_ttfa.py || echo C_FAIL
# Zip C
cd /workspace/backlog_runs && zip -qr packs_local/pack_C_sravaani_stream_warm.zip pack_C_sravaani_stream_warm 2>/dev/null || true
touch /workspace/backlog_runs/AFTER_D_DONE
echo "=== after_D complete $(date -Is) ==="
