#!/usr/bin/env python3
"""Item 4: IndicF5 Odia longer re-synthesis + IndicConformer WER."""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import torch
import soundfile as sf
import jiwer
from transformers import AutoModel

MODEL_ID = "ai4bharat/IndicF5"
PIN = "ba85abedf18dc479a447eaa0eccbd76ab78a47d5"
MODEL_PATH = "/workspace/indic_f5_qual/model_cache/IndicF5"
ASR_ID = "ai4bharat/indic-conformer-600m-multilingual"
REF_WAV = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs/locale_refs/or-IN_ref.wav")
REF_TXT = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs/locale_refs/or-IN_ref.txt")

# Longer Odia texts (multi-sentence) to avoid ~1s empty Conformer issue
LONG_ODIA = [
    {
        "id": "or_long_meeting",
        "text": (
            "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି। "
            "ଦୟାକରି ସମୟରେ ପହଞ୍ଚନ୍ତୁ ଏବଂ ଆବଶ୍ୟକ କାଗଜପତ୍ର ସହିତ ଆସନ୍ତୁ। "
            "ଯଦି କୌଣସି ପରିବର୍ତ୍ତନ ଥାଏ ତେବେ ଆମକୁ ଆଗରୁ ଜଣାନ୍ତୁ।"
        ),
    },
    {
        "id": "or_long_weather",
        "text": (
            "ଆଜି ଭୁବନେଶ୍ୱରରେ ଆଂଶିକ ମେଘାଚ୍ଛନ୍ନ ପାଗ ରହିବ ଏବଂ ବର୍ଷା ହେବାର ସମ୍ଭାବନା ଅଛି। "
            "ସନ୍ଧ୍ୟାରେ ତାପମାତ୍ରା କମିଯିବ ତେଣୁ ଗରମ ପୋଷାକ ରଖନ୍ତୁ। "
            "ଯାତ୍ରା କରିବା ପୂର୍ବରୁ ଟ୍ରାଫିକ୍ ସୂଚନା ଯାଞ୍ଚ କରନ୍ତୁ।"
        ),
    },
]

def norm(t):
    t = (t or "").strip()
    t = re.sub(r"\s+", " ", t)
    return t

def conformer_transcribe(model, wav_path, lang="or"):
    audio, sr = sf.read(str(wav_path), dtype="float32")
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    if sr != 16000:
        import librosa
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)
    tensor = torch.from_numpy(audio).float().unsqueeze(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    with torch.inference_mode():
        out = model(tensor.to(device), lang, "ctc")
    if isinstance(out, (list, tuple)):
        hyp = out[0]
    elif isinstance(out, dict):
        hyp = out.get("text") or out.get("transcription") or str(out)
    else:
        hyp = str(out)
    return hyp

def synth_indicf5(model, text, ref_audio, ref_text):
    import torch
    with torch.inference_mode():
        out = model(text, ref_audio_path=ref_audio, ref_text=ref_text)
    if isinstance(out, tuple):
        wav = out[0]
    elif isinstance(out, dict):
        wav = out.get("audio") or out.get("wav")
    else:
        wav = out
    if hasattr(wav, "detach"):
        wav = wav.detach().float().cpu().numpy()
    wav = np.asarray(wav, dtype=np.float32).reshape(-1)
    peak = float(np.max(np.abs(wav))) if len(wav) else 0.0
    if peak > 1.0:
        wav = wav / peak * 0.99
    return wav

def main():
    gpu = nvidia_info()
    assert gpu.get("cuda"), gpu
    out = Path(f"/workspace/backlog_runs/item_workspaces/pack_item04_indicf5_odia_resynth_{DATE}")
    wavs = out / "wavs"
    wavs.mkdir(parents=True, exist_ok=True)

    ref_text = REF_TXT.read_text(encoding="utf-8").strip() if REF_TXT.exists() else ""
    assert REF_WAV.exists(), REF_WAV
    print("ref", REF_WAV, "dur", sf.info(str(REF_WAV)).duration, flush=True)

    # Load IndicF5
    load_path = MODEL_PATH if Path(MODEL_PATH).exists() else MODEL_ID
    print("load IndicF5", load_path, flush=True)
    t0 = time.perf_counter()
    model = AutoModel.from_pretrained(load_path, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    model.infer_device = torch.device("cuda")
    if hasattr(model, "ema_model"):
        model.ema_model = model.ema_model.to("cuda")
    if hasattr(model, "vocoder"):
        model.vocoder = model.vocoder.to("cuda")
    model.eval()
    load_s = time.perf_counter() - t0

    results = []
    for spec in LONG_ODIA:
        print("synth", spec["id"], flush=True)
        t1 = time.perf_counter()
        try:
            audio = synth_indicf5(model, spec["text"], str(REF_WAV), ref_text)
            sr = 24000
            # detect sr from model if possible
            path = wavs / f"{spec['id']}.wav"
            sf.write(str(path), audio, sr)
            (wavs / f"{spec['id']}.txt").write_text(spec["text"] + "\n", encoding="utf-8")
            dur = len(audio) / sr
            results.append({
                "id": spec["id"], "ok": True, "wav": str(path), "text": spec["text"],
                "duration_s": dur, "synth_s": time.perf_counter() - t1, "sr": sr,
                "ref_wav": str(REF_WAV), "ref_text": ref_text,
            })
            print("  dur", dur, flush=True)
        except Exception as e:
            results.append({"id": spec["id"], "ok": False, "error": traceback.format_exc(), "text": spec["text"]})
            print("  FAIL", e, flush=True)

    # free TTS
    del model
    torch.cuda.empty_cache()

    # Score with IndicConformer
    print("load ASR", ASR_ID, flush=True)
    asr = AutoModel.from_pretrained(ASR_ID, trust_remote_code=True, token=os.environ["HF_TOKEN"])
    asr = asr.to("cuda").eval()
    for r in results:
        if not r.get("ok"):
            continue
        try:
            hyp = conformer_transcribe(asr, r["wav"], "or")
            r["hypothesis"] = hyp
            r["wer"] = float(jiwer.wer(norm(r["text"]), norm(hyp)))
            r["cer"] = float(jiwer.cer(norm(r["text"]), norm(hyp)))
            print("  WER", r["wer"], "hyp", (hyp or "")[:80], flush=True)
        except Exception:
            r["asr_error"] = traceback.format_exc()
            r["wer"] = None

    # Also score prior short clip for contrast if present
    prior = Path("/workspace/backlog_runs/pack_gating2_indicf5_locale_refs/wavs/or-IN.wav")
    prior_row = None
    if prior.exists():
        short_text = "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।"
        try:
            hyp = conformer_transcribe(asr, prior, "or")
            prior_row = {
                "id": "or_prior_short", "wav": str(prior), "text": short_text,
                "duration_s": sf.info(str(prior)).duration, "hypothesis": hyp,
                "wer": float(jiwer.wer(norm(short_text), norm(hyp or ""))) if hyp else 1.0,
                "cer": float(jiwer.cer(norm(short_text), norm(hyp or ""))) if hyp else 1.0,
                "note": "prior ~1.08s clip that yielded empty/WER 1.0",
            }
        except Exception as e:
            prior_row = {"id": "or_prior_short", "error": str(e)}

    payload = {
        "item": 4, "when": ist_now(), "gpu": gpu, "model_id": MODEL_ID, "load_s": load_s,
        "asr_id": ASR_ID, "results": results, "prior_short": prior_row,
        "note": "Re-synth longer Odia with strong locale ref; score IndicConformer positional lang=or",
    }
    write_json(out / "results.json", payload)
    ok_wers = [r["wer"] for r in results if isinstance(r.get("wer"), float)]
    write_summary(out, f"""# Item 4 -- IndicF5 Odia re-synthesis

**When:** {payload['when']}
**TTS:** `{MODEL_ID}`
**ASR:** `{ASR_ID}`
**Status:** DONE
**GPU:** {gpu}

## Problem
Prior or-IN locale-ref clip ~1.08s -> Conformer empty -> WER 1.0.

## New longer synth
| id | duration_s | WER | CER |
|----|------------|-----|-----|
""" + "\n".join(
        f"| {r.get('id')} | {r.get('duration_s')} | {r.get('wer')} | {r.get('cer')} |"
        for r in results
    ) + f"""

## Prior short (contrast)
{json.dumps(prior_row, ensure_ascii=False, indent=2) if prior_row else 'n/a'}

## Ref
- wav: `{REF_WAV}`
- text: {ref_text}
""")
    z, _ = finalize_pack(out, f"pack_item04_indicf5_odia_resynth_{DATE}.zip")
    print("PACK4", z, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise
