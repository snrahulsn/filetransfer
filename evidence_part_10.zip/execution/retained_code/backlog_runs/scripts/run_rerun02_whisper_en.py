#!/usr/bin/env python3
"""Rerun 02: Whisper large-v3 EN intelligibility for Veena, Kokoro, Maya1, Qwen3-TTS Base."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess, shutil, unicodedata, re
from pathlib import Path

sys.path.insert(0, "/workspace/backlog_runs/scripts")
from common import ist_now, write_json, load_hf_token, nvidia_info
from pack_util import finalize_pack, write_summary, DATE

os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ["HF_TOKEN"] = load_hf_token()
os.environ["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]

import numpy as np
import soundfile as sf
import torch

REF = "Your meeting with Priya is tomorrow at three thirty PM."
WORK = Path(f"/workspace/backlog_runs/item_workspaces/pack_rerun02_whisper_en_intelligibility_{DATE}")
PACK_NAME = f"pack_rerun02_whisper_en_intelligibility_{DATE}"
FLEURS = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
BASE = Path("/workspace/models/Qwen3-TTS-12Hz-0.6B-Base")

# Candidate wavs (prefer exact Priya sentence)
CANDIDATES = {
    "Veena": [
        "/workspace/backlog_runs/packs_local/pack_item05_veena_full_qual_2026-09-22/wavs/veena_en_agastya.wav",
    ],
    "Kokoro": [
        "/workspace/backlog_runs/packs_local/pack_item08_kokoro_intelligibility_wer_2026-09-22/wavs/01_your_meeting_with_priya_is_tomorrow_at_three_thirty_pm.wav",
        "/workspace/kokoro_hindi_english_probe/wavs/01_your_meeting_with_priya_is_tomorrow_at_three_thirty_pm.wav",
    ],
    "Maya1": [
        "/tmp/g4maya/samples/stream0.wav",  # may not exist on pod
        "/workspace/backlog_runs/packs_local/_staging_maya1_en_priya.wav",
        # pack_A extract if staged
        "/workspace/backlog_runs/packs_local/pack_gating4_maya1_stream_probe/samples/stream0.wav",
    ],
    "Qwen3-TTS Base": [
        "/workspace/backlog_runs/packs_local/pack_item06_qwen3_tts_base_hi_lora_2026-09-22/wavs/base_en_short.wav",
    ],
}

def normalize_text(s):
    s = unicodedata.normalize("NFC", s or "").strip().lower()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()

def compute_wer_cer(ref, hyp):
    from jiwer import cer, wer
    ref_n, hyp_n = normalize_text(ref), normalize_text(hyp)
    if not ref_n:
        return None, None, ref_n, hyp_n
    if not hyp_n:
        return 1.0, 1.0, ref_n, hyp_n
    try:
        w = float(wer(ref_n, hyp_n))
    except Exception:
        w = 1.0
    try:
        c = float(cer(ref_n, hyp_n))
    except Exception:
        c = 1.0
    return w, c, ref_n, hyp_n

def pip_install(pkg):
    p = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", pkg],
                       capture_output=True, text=True, timeout=900)
    return p.returncode == 0, (p.stderr or p.stdout or "")[-600:]

def audio_meta(wav):
    a, sr = sf.read(str(wav), dtype="float32")
    a = np.asarray(a).reshape(-1)
    dur = float(len(a) / sr) if sr else 0.0
    return {
        "duration_s": round(dur, 4),
        "sr": int(sr),
        "rms": float(np.sqrt(np.mean(a * a))) if len(a) else 0.0,
        "peak": float(np.max(np.abs(a))) if len(a) else 0.0,
    }


def load_wav_for_whisper(wav):
    """Load + resample to 16k float32 for whisper without ffmpeg."""
    import numpy as np
    a, sr = sf.read(str(wav), dtype="float32")
    a = np.asarray(a).reshape(-1)
    if sr != 16000:
        try:
            import librosa
            a = librosa.resample(a, orig_sr=sr, target_sr=16000)
        except Exception:
            # linear resample fallback
            import numpy as np
            n = int(round(len(a) * 16000 / float(sr)))
            xp = np.linspace(0, 1, num=len(a), endpoint=False)
            x = np.linspace(0, 1, num=n, endpoint=False)
            a = np.interp(x, xp, a).astype(np.float32)
        sr = 16000
    return a.astype(np.float32)

def pick_ref_en():
    man = FLEURS / "manifest_en_us.jsonl"
    for line in man.read_text(encoding="utf-8").splitlines():
        r = json.loads(line)
        if 3.0 <= float(r.get("duration_s") or 0) <= 8.0 and Path(r["wav"]).exists() and r.get("reference"):
            return r
    return json.loads(man.read_text(encoding="utf-8").splitlines()[0])

def resynth_qwen_en(out_wav, max_new_tokens=120):
    """Re-synth shorter EN Priya for Qwen3 Base (prior ~40s overlong)."""
    from qwen_tts import Qwen3TTSModel
    print("re-synth Qwen3 EN shorter", flush=True)
    tts = Qwen3TTSModel.from_pretrained(
        str(BASE), device_map="cuda:0", dtype=torch.bfloat16, attn_implementation="sdpa",
    )
    ref = pick_ref_en()
    t0 = time.perf_counter()
    wavs, sr = tts.generate_voice_clone(
        text=REF,
        language="English",
        ref_audio=str(ref["wav"]),
        ref_text=ref["reference"],
        x_vector_only_mode=False,
        non_streaming_mode=True,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        top_k=50,
        top_p=0.95,
        temperature=0.7,
        repetition_penalty=1.05,
    )
    y = np.asarray(wavs[0], dtype=np.float32).reshape(-1)
    sf.write(str(out_wav), y, int(sr))
    gen_s = time.perf_counter() - t0
    dur = len(y) / float(sr)
    del tts
    torch.cuda.empty_cache()
    return {
        "ok": True,
        "wav": str(out_wav),
        "duration_s": round(dur, 4),
        "gen_s": round(gen_s, 4),
        "rtf": round(gen_s / (dur + 1e-9), 4),
        "max_new_tokens": max_new_tokens,
        "ref_utt": ref.get("utt_id"),
        "label": "re-synth shorter (prior base_en_short ~40.88s overlong)",
    }

def stage_maya1():
    """Ensure Maya1 Priya wav available on volume from pack zip."""
    dest = Path("/workspace/backlog_runs/packs_local/_staging_maya1_en_priya.wav")
    if dest.exists() and dest.stat().st_size > 1000:
        return str(dest)
    # Extract from gating4 zip
    import zipfile
    zpath = Path("/workspace/backlog_runs/packs_local/pack_gating4_maya1_stream_probe.zip")
    if zpath.exists():
        with zipfile.ZipFile(zpath) as z:
            with z.open("samples/stream0.wav") as src, open(dest, "wb") as out:
                out.write(src.read())
        txt = dest.with_suffix(".txt")
        txt.write_text(REF + "\n", encoding="utf-8")
        return str(dest)
    return None

def main():
    gpu = nvidia_info()
    WORK.mkdir(parents=True, exist_ok=True)
    (WORK / "wavs").mkdir(exist_ok=True)
    status = {"item": "rerun02", "when": ist_now(), "gpu": gpu, "reference": REF,
              "judge": "openai-whisper/large-v3", "normalize": "NFC+lower+strip punct (svara run_qual)"}

    ok_w, note_w = pip_install("openai-whisper")
    ok_j, note_j = pip_install("jiwer")
    status["install"] = {"whisper": {"ok": ok_w, "note": note_w}, "jiwer": {"ok": ok_j, "note": note_j}}

    maya = stage_maya1()
    if maya:
        CANDIDATES["Maya1"] = [maya] + CANDIDATES["Maya1"]

    # Resolve / prepare wavs
    systems = {}
    qwen_note = None
    for name, paths in CANDIDATES.items():
        chosen = None
        for p in paths:
            if p and Path(p).exists() and Path(p).stat().st_size > 1000:
                chosen = p
                break
        if name == "Qwen3-TTS Base":
            # If overlong, re-synth
            need_resynth = True
            meta = None
            if chosen:
                meta = audio_meta(chosen)
                if 1.5 <= meta["duration_s"] <= 8.0:
                    need_resynth = False
            if need_resynth:
                outw = WORK / "wavs" / "qwen3_base_en_priya_short.wav"
                try:
                    qwen_note = resynth_qwen_en(outw)
                    chosen = str(outw)
                    meta = audio_meta(chosen)
                    qwen_note.update(meta)
                except Exception:
                    qwen_note = {"ok": False, "error": traceback.format_exc()[-2000:], "prior": meta}
                    if chosen:
                        # still score prior overlong, label clearly
                        shutil.copy2(chosen, WORK / "wavs" / "qwen3_base_en_priya_PRIOR_OVERLONG.wav")
                        qwen_note["using_prior_overlong"] = True
            else:
                shutil.copy2(chosen, WORK / "wavs" / "qwen3_base_en_priya.wav")
                chosen = str(WORK / "wavs" / "qwen3_base_en_priya.wav")
                qwen_note = {"ok": True, "reused": True, "meta": meta}
            systems[name] = {"wav": chosen, "source": "resynth_or_prior", "prep": qwen_note}
        else:
            if not chosen:
                systems[name] = {"wav": None, "error": "missing EN Priya wav"}
                continue
            dest = WORK / "wavs" / f"{name.replace(' ','_').replace('-','_').lower()}_en_priya.wav"
            shutil.copy2(chosen, dest)
            systems[name] = {"wav": str(dest), "source_wav": chosen, "meta": audio_meta(dest)}

    status["systems_prep"] = systems

    # Load whisper
    import whisper
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("load whisper large-v3", device, flush=True)
    asr = whisper.load_model("large-v3", device=device)

    rows = []
    for name in ["Veena", "Kokoro", "Maya1", "Qwen3-TTS Base"]:
        info = systems.get(name) or {}
        wav = info.get("wav")
        row = {"system": name, "reference": REF, "wav": wav}
        if not wav or not Path(wav).exists():
            row.update({"ok": False, "error": info.get("error") or "no wav", "WER": None, "CER": None})
            rows.append(row)
            continue
        meta = audio_meta(wav)
        row.update(meta)
        if name == "Qwen3-TTS Base" and qwen_note:
            row["qwen_prep"] = {k: qwen_note.get(k) for k in ("ok", "label", "max_new_tokens", "using_prior_overlong", "reused") if k in qwen_note or True}
            row["qwen_prep"] = {k: qwen_note[k] for k in qwen_note if k in ("ok", "label", "max_new_tokens", "using_prior_overlong", "reused", "duration_s")}
        try:
            audio16 = load_wav_for_whisper(wav)
            result = asr.transcribe(audio16, language="en", task="transcribe", fp16=(device == "cuda"))
            hyp = (result.get("text") or "").strip()
            w, c, ref_n, hyp_n = compute_wer_cer(REF, hyp)
            empty = not hyp
            fail = empty or (w is not None and w >= 0.9) or (c is not None and c >= 0.9)
            row.update({
                "ok": not fail,
                "hyp": hyp,
                "hyp_normalized": hyp_n,
                "ref_normalized": ref_n,
                "WER": None if w is None else round(w, 4),
                "CER": None if c is None else round(c, 4),
                "pass": not fail,
                "detected_language": result.get("language"),
            })
            print(name, "WER", row["WER"], "CER", row["CER"], "dur", row["duration_s"], "::", hyp[:80], flush=True)
        except Exception:
            row.update({"ok": False, "error": traceback.format_exc()[-1200:]})
        rows.append(row)

    status["rows"] = rows
    status["status"] = "DONE" if any(r.get("WER") is not None for r in rows) else "BLOCKED"
    write_json(WORK / "results.json", status)

    def fmt(r):
        return f"| {r.get('system')} | {r.get('duration_s')} | {(r.get('hyp') or '')[:60]} | {r.get('hyp_normalized')} | {r.get('WER')} | {r.get('CER')} | {r.get('ok')} |"

    table = "\n".join(fmt(r) for r in rows)
    write_summary(WORK, f"""# Rerun02 -- Whisper EN intelligibility

**When:** {status['when']}
**Status:** {status['status']}
**Judge:** openai-whisper large-v3 (same as svara_tts_qual/scripts/run_qual.py)
**Normalize:** NFC + lower + strip non-word (identical helper)
**Reference:** `{REF}`
**GPU:** {gpu}

## Table
| system | duration_s | hyp | hyp_normalized | WER | CER | ok |
|--------|------------|-----|----------------|-----|-----|----|
{table}

## Prep notes
- Veena: reuse pack_item05 veena_en_agastya.wav (exact Priya sentence)
- Kokoro: reuse pack_item08 01_your_meeting...wav
- Maya1: gating4 stream0.wav (exact Priya text); Mayal typo -> Maya1
- Qwen3-TTS Base: prior EN wav ~40.88s overlong; re-synth shorter if needed and label clearly

## Qwen prep
{json.dumps(qwen_note, indent=2, default=str)[:1500]}
""")
    z, _ = finalize_pack(WORK, f"{PACK_NAME}.zip")
    print("PACK_RERUN02", z, status["status"], flush=True)
    # progress ping
    try:
        prog = Path("/workspace/backlog_runs/PROGRESS_RERUN.md")
        prog.parent.mkdir(parents=True, exist_ok=True)
        cur = prog.read_text(encoding="utf-8") if prog.exists() else "# PROGRESS RERUN\n"
        cur = cur.replace("| 2 Whisper EN intelligibility | PENDING |",
                          f"| 2 Whisper EN intelligibility | {status['status']} n_scored={sum(1 for r in rows if r.get('WER') is not None)} |")
        if "| 2 Whisper EN intelligibility |" not in cur:
            cur += f"\n| 2 Whisper EN intelligibility | {status['status']} |\n"
        prog.write_text(cur, encoding="ascii", errors="replace")
    except Exception as _pe:
        print("progress ping skip", _pe, flush=True)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        WORK.mkdir(parents=True, exist_ok=True)
        write_json(WORK / "results.json", {"item": "rerun02", "status": "BLOCKED", "error": traceback.format_exc()[-3000:]})
        write_summary(WORK, f"# Rerun02 BLOCKED\n\n{traceback.format_exc()[-2000:]}\n")
        finalize_pack(WORK, f"{PACK_NAME}.zip")
