#!/usr/bin/env python3
"""D v2: sustained CUDA RTF for ai4bharat/indic-conformer-600m-multilingual."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess, glob
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

def now() -> str:
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

def wj(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

for k, v in {
    "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1", "ORT_NUM_THREADS": "1",
    "OMP_WAIT_POLICY": "PASSIVE", "TOKENIZERS_PARALLELISM": "false",
}.items():
    os.environ[k] = v

for p in (Path("/workspace/.hf_token_env"), Path("/workspace/.hf_token_env"), Path("/workspace/backlog_runs/.hf_token_env")):
    if p.exists():
        for line in p.read_text().splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "TOKEN=" in line and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
os.environ.setdefault("HF_HOME", "/workspace/hf_cache")
os.environ.setdefault("HUGGING_FACE_HUB_TOKEN", os.environ.get("HF_TOKEN", ""))

REPO = "ai4bharat/indic-conformer-600m-multilingual"
REV = "e9b71b369c048e2c6b634d4c131061c34e441179"
OLD_RTF = 0.1612
CACHE = Path("/workspace/fleurs_asr_trio/_fleurs_wav_cache")
MANIFEST = CACHE / "manifest_all.jsonl"
OUT = Path("/workspace/fleurs_asr_trio/indic-conformer-600m/cudnn9_rerun_v2")
PACK = Path("/workspace/backlog_runs/pack_D_indicconformer_cudnn9")
OUT.mkdir(parents=True, exist_ok=True)
PACK.mkdir(parents=True, exist_ok=True)
CAP = int(os.environ.get("D_CAP_PER_LANG", "20"))
TIMEOUT = int(os.environ.get("D_TIMEOUT_S", "1800"))


def install():
    log = []
    cmds = [
        [sys.executable, "-m", "pip", "install", "-q", "nvidia-cudnn-cu12==9.1.0.70"],
        [sys.executable, "-m", "pip", "install", "-q", "onnxruntime-gpu==1.19.2"],
        [sys.executable, "-m", "pip", "install", "-q", "transformers==4.46.3", "accelerate", "huggingface_hub",
         "soundfile", "torchaudio", "jiwer", "sentencepiece", "numpy"],
    ]
    for c in cmds:
        p = subprocess.run(c, capture_output=True, text=True)
        log.append({"cmd": c, "rc": p.returncode, "err": (p.stderr or "")[-400:]})
    cands = (
        glob.glob("/usr/local/lib/python*/dist-packages/nvidia/cudnn/lib")
        + glob.glob(str(Path(sys.prefix) / "lib/python*/site-packages/nvidia/cudnn/lib"))
        + glob.glob("/usr/local/lib/python*/dist-packages/nvidia/cublas/lib")
        + glob.glob(str(Path(sys.prefix) / "lib/python*/site-packages/nvidia/cublas/lib"))
    )
    if cands:
        os.environ["LD_LIBRARY_PATH"] = ":".join(dict.fromkeys(cands)) + ":" + os.environ.get("LD_LIBRARY_PATH", "")
        log.append({"ld": os.environ["LD_LIBRARY_PATH"][:400]})
    wj(OUT / "install.json", log)
    return log


def patch_ort():
    import onnxruntime as ort
    Orig = ort.InferenceSession
    def wrapped(path_or_bytes, sess_options=None, providers=None, provider_options=None, **kw):
        so = sess_options or ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        try:
            so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        except Exception:
            pass
        if providers is None:
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        print(f"[ORT-PATCH] providers={providers}", flush=True)
        return Orig(path_or_bytes, sess_options=so, providers=providers, provider_options=provider_options, **kw)
    ort.InferenceSession = wrapped
    return ort.__version__, list(ort.get_available_providers())


def load_items(cap):
    items = []
    by = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        lang = r["lang"]
        if lang.startswith("en_"):
            continue
        by.setdefault(lang, 0)
        if by[lang] >= cap:
            continue
        wav = Path(r["wav"])
        if not wav.exists():
            continue
        items.append({
            "utt_id": r.get("utt_id", wav.stem),
            "lang": lang,
            "wav": str(wav),
            "reference": r.get("reference", ""),
            "duration_s": float(r.get("duration_s") or 0.0),
        })
        by[lang] += 1
    return items


def model_lang(fleurs_lang: str) -> str:
    return fleurs_lang.split("_")[0]


def main():
    print(f"=== D v2 start {now()} cap={CAP} timeout={TIMEOUT}s ===", flush=True)
    install()
    ort_ver, providers = patch_ort()
    print("ORT", ort_ver, providers, flush=True)
    import torch
    torch.set_num_threads(1)
    from transformers import AutoModel
    import torchaudio

    device = "cuda" if torch.cuda.is_available() else "cpu"
    try:
        cudnn_ver = torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else None
    except Exception as e:
        cudnn_ver = f"err:{e}"
    gpu = {
        "name": torch.cuda.get_device_name(0) if device == "cuda" else None,
        "torch": torch.__version__,
        "cudnn": cudnn_ver,
    }
    print("GPU", gpu, "device", device, flush=True)

    t0 = time.perf_counter()
    model = AutoModel.from_pretrained(REPO, revision=REV, trust_remote_code=True, token=os.environ.get("HF_TOKEN"))
    model = model.to(device)
    model.eval()
    load_s = time.perf_counter() - t0
    print(f"loaded in {load_s:.1f}s", flush=True)

    items = load_items(CAP)
    print(f"items={len(items)} langs={sorted({i['lang'] for i in items})}", flush=True)
    if not items:
        raise SystemExit("no items from manifest")

    rows = []
    audio_s = infer_s = 0.0
    t_all = time.perf_counter()
    timed_out = False
    for i, utt in enumerate(items):
        if time.perf_counter() - t_all > TIMEOUT:
            timed_out = True
            print("TIMEOUT", flush=True)
            break
        wav, sr = torchaudio.load(utt["wav"])
        if wav.shape[0] > 1:
            wav = wav.mean(0, keepdim=True)
        if sr != 16000:
            wav = torchaudio.functional.resample(wav, sr, 16000)
        if utt["duration_s"] <= 0:
            utt["duration_s"] = float(wav.shape[-1] / 16000.0)
        audio_s += utt["duration_s"]
        ml = model_lang(utt["lang"])
        t1 = time.perf_counter()
        try:
            with torch.inference_mode():
                out = model(wav.to(device), ml, "ctc")
            if isinstance(out, (list, tuple)):
                out = out[0]
            hyp = (str(out) or "").strip()
            dt = time.perf_counter() - t1
            infer_s += dt
            rtf = dt / max(utt["duration_s"], 1e-9)
            rows.append({**utt, "hypothesis": hyp, "infer_s": dt, "rtf": rtf, "ok": True})
            print(f"[{i+1}/{len(items)}] {utt['utt_id']} rtf={rtf:.4f} hyp={hyp[:50]!r}", flush=True)
        except Exception as e:
            dt = time.perf_counter() - t1
            infer_s += dt
            rows.append({**utt, "hypothesis": "", "infer_s": dt, "rtf": None, "ok": False,
                         "error": f"{type(e).__name__}: {e}"})
            print(f"FAIL {utt['utt_id']}: {e}", flush=True)
        if (i + 1) % 10 == 0:
            wj(OUT / "partial.json", {"n": i + 1, "rtf": infer_s / max(audio_s, 1e-9), "time": now()})

    wall = time.perf_counter() - t_all
    ok = [r for r in rows if r.get("ok")]
    overall = (infer_s / max(audio_s, 1e-9)) if audio_s else None
    per = {}
    for r in ok:
        p = per.setdefault(r["lang"], {"n": 0, "audio_s": 0.0, "infer_s": 0.0})
        p["n"] += 1
        p["audio_s"] += r["duration_s"]
        p["infer_s"] += r["infer_s"]
    for p in per.values():
        p["rtf"] = p["infer_s"] / max(p["audio_s"], 1e-9)

    gpu_mem = None
    try:
        gpu_mem = torch.cuda.max_memory_allocated() / (1024 ** 3)
    except Exception:
        pass

    summary = {
        "model": REPO, "revision": REV,
        "old_rtf_cpu_fallback": OLD_RTF,
        "new_rtf": overall,
        "n_ok": len(ok), "n_total": len(rows), "cap_per_lang": CAP,
        "total_audio_s": audio_s, "total_infer_s": infer_s, "wall_s": wall,
        "model_load_s": load_s, "ort_version": ort_ver, "ort_providers": providers,
        "device": device, "gpu": gpu, "gpu_max_mem_gb": gpu_mem,
        "timed_out": timed_out,
        "thread_env": {k: os.environ.get(k) for k in ["OMP_NUM_THREADS", "MKL_NUM_THREADS", "ORT_NUM_THREADS"]},
        "per_lang": per, "timestamp": now(),
        "vs_old": None if overall is None else {
            "new_rtf": overall, "old_rtf": OLD_RTF,
            "speedup_vs_old": (OLD_RTF / overall) if overall > 0 else None,
            "note": "old 0.1612 was CPU-ORT fallback; this run aims for real CUDA EP with thread isolation",
        },
    }
    wj(OUT / "summary.json", summary)
    wj(OUT / "results.json", {"summary": summary, "utterances": rows})
    wj(PACK / "summary.json", summary)
    wj(PACK / "micro_results.json", {"summary": summary, "n": len(rows)})
    md = [
        f"# IndicConformer-600M cuDNN9 CUDA RTF (v2)\n\n**When:** {now()}\n",
        f"**GPU:** {gpu}\n**ORT:** {ort_ver} {providers}\n",
        f"**Old RTF (CPU fallback):** {OLD_RTF}\n**New RTF:** {overall}\n",
        f"**N ok/total:** {len(ok)}/{len(rows)} cap/lang={CAP}\n",
        f"**Audio/Infer/Wall:** {audio_s:.1f}/{infer_s:.1f}/{wall:.1f}s\n",
        f"**Timeout:** {timed_out}\n**GPU max mem GiB:** {gpu_mem}\n",
        f"**Threads:** {summary['thread_env']}\n\n## Per-lang\n\n| Lang | N | RTF |\n|---|---:|---:|\n",
    ]
    for lang, p in sorted(per.items()):
        md.append(f"| {lang} | {p['n']} | {p['rtf']:.4f} |\n")
    (OUT / "SUMMARY.md").write_text("".join(md), encoding="utf-8")
    (PACK / "SUMMARY.md").write_text("".join(md), encoding="utf-8")
    wj(PACK / "DONE.json", {"ok": bool(ok) and overall is not None, "time": now(),
                            "new_rtf": overall, "old_rtf": OLD_RTF, "n_ok": len(ok), "cap": CAP})
    print("D_V2_DONE", json.dumps({k: summary[k] for k in ("new_rtf", "n_ok", "old_rtf_cpu_fallback", "timed_out", "gpu_max_mem_gb")}, indent=2), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        err = traceback.format_exc()
        wj(PACK / "DONE.json", {"ok": False, "time": now(), "error": err[-2000:]})
        (PACK / "SUMMARY.md").write_text(f"# D FAILED\n\n```\n{err[-2000:]}\n```\n", encoding="utf-8")
        print(err, flush=True)
        raise
