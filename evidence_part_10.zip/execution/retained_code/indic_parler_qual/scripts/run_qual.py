#!/usr/bin/env python3
"""Full on-prem qualification for ai4bharat/indic-parler-tts."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(os.environ.get("QUAL_OUT", "/workspace/indic_parler_qual"))
WAVS = OUT / "wavs"
WAVS.mkdir(parents=True, exist_ok=True)
MODEL_ID = "ai4bharat/indic-parler-tts"
DESCRIPTION = (
    "A female speaker delivers speech with a neutral intonation and a moderate pace. "
    "The recording is of very high quality with very clear audio, with the speaker's "
    "voice sounding clear and very close up."
)

LOCALES = [
    ("en-IN", "Your meeting with Priya is tomorrow at three thirty PM."),
    ("hi-IN", "आपकी बैठक कल दोपहर तीन बजे है।"),
    ("bn-IN", "আপনার মিটিং আগামীকাল দুপুর তিনটায়।"),
    ("mr-IN", "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे."),
    ("te-IN", "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది."),
    ("ta-IN", "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு."),
    ("gu-IN", "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે."),
    ("kn-IN", "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ."),
    ("ml-IN", "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്."),
    ("ur-IN", "آپ کی میٹنگ کل دوپہر تین بجے ہے۔"),
    ("or-IN", "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।"),
    ("pa-IN", "ਤੁਹਾਡੀ ਮੀਟਿੰਗ ਕੱਲ੍ਹ ਦੁਪਹਿਰ ਤਿੰਨ ਵਜੇ ਹੈ।"),
]

# Whisper language codes (ISO-639-1 where available)
WHISPER_LANG = {
    "en-IN": "en",
    "hi-IN": "hi",
    "bn-IN": "bn",
    "mr-IN": "mr",
    "te-IN": "te",
    "ta-IN": "ta",
    "gu-IN": "gu",
    "kn-IN": "kn",
    "ml-IN": "ml",
    "ur-IN": "ur",
    "or-IN": None,  # Odia not in Whisper large-v3; try without force / use None
    "pa-IN": "pa",
}


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def record_versions():
    pkgs = [
        "parler-tts",
        "transformers",
        "torch",
        "soundfile",
        "huggingface_hub",
        "accelerate",
        "sentencepiece",
        "protobuf",
        "numpy",
        "openai-whisper",
        "jiwer",
        "librosa",
    ]
    versions = {}
    for p in pkgs:
        try:
            out = subprocess.check_output(
                [sys.executable, "-m", "pip", "show", p], text=True, stderr=subprocess.DEVNULL
            )
            info = {}
            for line in out.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    info[k.strip()] = v.strip()
            versions[p] = {
                "version": info.get("Version"),
                "location": info.get("Location"),
            }
        except Exception as e:
            versions[p] = {"version": None, "error": str(e)}
    # freeze subset
    freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)
    interesting = []
    keys = {p.lower().replace("-", "_") for p in pkgs} | {p.lower() for p in pkgs}
    for line in freeze.splitlines():
        name = line.split("==")[0].split("@")[0].lower().replace("-", "_")
        if any(k.replace("-", "_") in name for k in [p.lower() for p in pkgs]):
            interesting.append(line)
    versions["pip_freeze_subset"] = interesting
    (OUT / "versions.json").write_text(json.dumps(versions, indent=2, ensure_ascii=False))
    return versions


def download_and_pin():
    from huggingface_hub import snapshot_download, HfApi

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    PIN = os.environ.get("MODEL_REVISION", "7b527af5ee8ed1f9a28d80b19703ed9bb8ba10ca")
    api = HfApi(token=token)
    info = api.model_info(MODEL_ID)
    tip_sha = info.sha
    print(f"Model tip sha from API: {tip_sha}; using pin: {PIN}", flush=True)

    cache_dir = "/workspace/hf_cache"
    local_dir = str(OUT / "model_cache" / "indic-parler-tts")
    path = snapshot_download(
        repo_id=MODEL_ID,
        revision=PIN,
        token=token,
        cache_dir=cache_dir,
        local_dir=local_dir,
        local_dir_use_symlinks=False,
    )
    revision = PIN
    (OUT / "model_revision.txt").write_text(revision + "\n")
    print(f"Downloaded to {path}, pinned revision={revision}", flush=True)
    return revision, path


def synthesize_all(revision: str, model_path: str):
    import numpy as np
    import soundfile as sf
    import torch
    from parler_tts import ParlerTTSForConditionalGeneration
    from transformers import AutoTokenizer

    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    print(f"Loading model on {device} dtype={dtype} revision={revision}", flush=True)

    model = ParlerTTSForConditionalGeneration.from_pretrained(
        model_path if model_path else MODEL_ID,
        revision=revision,
        torch_dtype=dtype,
    ).to(device)
    tokenizer = AutoTokenizer.from_pretrained(model_path if model_path else MODEL_ID, revision=revision)
    desc_tok_name = model.config.text_encoder._name_or_path
    description_tokenizer = AutoTokenizer.from_pretrained(desc_tok_name)

    results = []
    for locale, sentence in LOCALES:
        rec = {
            "locale": locale,
            "sentence": sentence,
            "description": DESCRIPTION,
            "success": False,
            "error": None,
            "total_synthesis_time_s": None,
            "audio_duration_s": None,
            "RTF": None,
            "sample_rate": None,
            "sha256": None,
            "wav_path": f"wavs/{locale}.wav",
        }
        out_wav = WAVS / f"{locale}.wav"
        print(f"=== Synth {locale} ===", flush=True)
        try:
            desc_ids = description_tokenizer(DESCRIPTION, return_tensors="pt").to(device)
            prompt_ids = tokenizer(sentence, return_tensors="pt").to(device)
            if device == "cuda":
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            with torch.no_grad():
                generation = model.generate(
                    input_ids=desc_ids.input_ids,
                    attention_mask=desc_ids.attention_mask,
                    prompt_input_ids=prompt_ids.input_ids,
                    prompt_attention_mask=prompt_ids.attention_mask,
                )
            if device == "cuda":
                torch.cuda.synchronize()
            t1 = time.perf_counter()
            audio_arr = generation.cpu().float().numpy().squeeze()
            sr = int(model.config.sampling_rate)
            sf.write(str(out_wav), audio_arr, sr)
            dur = float(len(audio_arr) / sr)
            synth = float(t1 - t0)
            rec.update(
                {
                    "success": True,
                    "total_synthesis_time_s": round(synth, 4),
                    "audio_duration_s": round(dur, 4),
                    "RTF": round(synth / dur, 4) if dur > 0 else None,
                    "sample_rate": sr,
                    "sha256": sha256_file(out_wav),
                    "num_samples": int(len(audio_arr)),
                }
            )
            print(f"  OK synth={synth:.3f}s dur={dur:.3f}s RTF={rec['RTF']}", flush=True)
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {e}"
            rec["traceback"] = traceback.format_exc()
            print(f"  FAIL {rec['error']}", flush=True)
        results.append(rec)
        (OUT / "results.json").write_text(
            json.dumps(
                {
                    "model_id": MODEL_ID,
                    "revision": revision,
                    "description": DESCRIPTION,
                    "device": device,
                    "results": results,
                },
                indent=2,
                ensure_ascii=False,
            )
        )

    # free VRAM before ASR
    del model
    if device == "cuda":
        torch.cuda.empty_cache()
    return results, device


def clipping_analysis(results):
    import numpy as np
    import soundfile as sf

    clips = []
    for r in results:
        locale = r["locale"]
        wav = WAVS / f"{locale}.wav"
        entry = {
            "locale": locale,
            "peak_dBFS": None,
            "clipped": False,
            "clipped_samples": 0,
            "total_samples": 0,
            "error": None,
        }
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            clips.append(entry)
            continue
        audio, sr = sf.read(str(wav), dtype="float64")
        audio = np.asarray(audio).reshape(-1)
        entry["total_samples"] = int(audio.size)
        peak = float(np.max(np.abs(audio))) if audio.size else 0.0
        # dBFS relative to full scale 1.0
        if peak <= 0:
            entry["peak_dBFS"] = float("-inf")
        else:
            entry["peak_dBFS"] = round(20.0 * np.log10(peak), 4)
        # Actual clipped samples: at digital full scale |x| >= 1.0 (float) or near
        # For float wavs written by soundfile, check |x| >= 0.999
        clipped_mask = np.abs(audio) >= 0.999999
        n_clip = int(clipped_mask.sum())
        entry["clipped_samples"] = n_clip
        entry["clipped"] = bool(n_clip > 0 and abs(entry["peak_dBFS"] - 0.0) < 1e-3) or (
            n_clip > 0 and entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001
        )
        # Flag specifically: peak dBFS == 0 with actual clipped samples
        entry["flag_0dBFS_with_clipped_samples"] = bool(
            entry["peak_dBFS"] is not None
            and entry["peak_dBFS"] >= -0.001
            and n_clip > 0
        )
        clips.append(entry)
    (OUT / "clipping.json").write_text(json.dumps({"clipping": clips}, indent=2))
    return clips


def normalize_text(s: str) -> str:
    import unicodedata
    import re

    s = unicodedata.normalize("NFC", s or "")
    s = s.strip().lower()
    # remove punctuation-ish
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def compute_wer_cer(ref: str, hyp: str):
    from jiwer import cer, wer

    ref_n = normalize_text(ref)
    hyp_n = normalize_text(hyp)
    if not ref_n:
        return None, None, ref_n, hyp_n
    if not hyp_n:
        return 1.0, 1.0, ref_n, hyp_n
    try:
        w = float(wer(ref_n, hyp_n))
    except Exception:
        w = 1.0
    try:
        c = float(cer(ref_n, hyp_n))
    except Exception:
        c = 1.0
    return w, c, ref_n, hyp_n


def asr_all(results):
    import whisper
    import torch

    print("Loading Whisper large-v3 for ASR...", flush=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    asr_model = whisper.load_model("large-v3", device=device)
    asr_name = "openai-whisper/large-v3"

    metrics = {
        "asr_model": asr_name,
        "asr_notes": (
            "Whisper large-v3 multilingual used for all locales. "
            "Odia (or-IN) has no dedicated Whisper language code; transcribed without language force "
            "(or with auto-detect). Failure bar: empty transcript OR WER/CER >= ~0.9."
        ),
        "failure_bar": "empty transcript OR WER>=0.9 OR CER>=0.9",
        "results": [],
    }

    for r in results:
        locale = r["locale"]
        sentence = r["sentence"]
        wav = WAVS / f"{locale}.wav"
        entry = {
            "locale": locale,
            "reference": sentence,
            "transcript": None,
            "WER": None,
            "CER": None,
            "pass": False,
            "error": None,
            "whisper_language": WHISPER_LANG.get(locale),
        }
        print(f"=== ASR {locale} ===", flush=True)
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            metrics["results"].append(entry)
            continue
        try:
            lang = WHISPER_LANG.get(locale)
            kwargs = {"fp16": device == "cuda"}
            if lang:
                kwargs["language"] = lang
                kwargs["task"] = "transcribe"
            result = asr_model.transcribe(str(wav), **kwargs)
            transcript = (result.get("text") or "").strip()
            entry["transcript"] = transcript
            entry["detected_language"] = result.get("language")
            w, c, ref_n, hyp_n = compute_wer_cer(sentence, transcript)
            entry["WER"] = None if w is None else round(w, 4)
            entry["CER"] = None if c is None else round(c, 4)
            entry["ref_normalized"] = ref_n
            entry["hyp_normalized"] = hyp_n
            empty = not transcript
            fail = empty or (w is not None and w >= 0.9) or (c is not None and c >= 0.9)
            entry["pass"] = not fail
            entry["failure_reason"] = (
                "empty transcript"
                if empty
                else ("WER/CER >= 0.9" if fail else None)
            )
            print(
                f"  WER={entry['WER']} CER={entry['CER']} pass={entry['pass']} :: {transcript[:80]}",
                flush=True,
            )
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
            entry["traceback"] = traceback.format_exc()
            print(f"  FAIL {entry['error']}", flush=True)
        metrics["results"].append(entry)
        (OUT / "asr_metrics.json").write_text(json.dumps(metrics, indent=2, ensure_ascii=False))

    return metrics


def write_environment(wall_start: float, device: str, revision: str, versions: dict):
    import torch

    gpu = None
    if torch.cuda.is_available():
        gpu = {
            "name": torch.cuda.get_device_name(0),
            "capability": list(torch.cuda.get_device_capability(0)),
            "total_memory_gb": round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 2),
        }
    env = {
        "model_id": MODEL_ID,
        "revision": revision,
        "device": device,
        "gpu_vs_cpu": "GPU" if device == "cuda" else "CPU",
        "gpu": gpu,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "total_wall_clock_s": round(time.perf_counter() - wall_start, 2),
        "hostname": subprocess.check_output(["hostname"], text=True).strip(),
        "python": sys.version,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "package_versions_file": "versions.json",
        "key_versions": {k: v.get("version") if isinstance(v, dict) else v for k, v in versions.items() if k != "pip_freeze_subset"},
    }
    (OUT / "environment.json").write_text(json.dumps(env, indent=2))
    return env


def main():
    wall_start = time.perf_counter()
    print("=== Recording versions ===", flush=True)
    versions = record_versions()
    print("=== Download + pin ===", flush=True)
    revision, model_path = download_and_pin()
    print("=== Synthesize 12 locales ===", flush=True)
    results, device = synthesize_all(revision, model_path)
    print("=== Clipping ===", flush=True)
    clipping_analysis(results)
    print("=== ASR ===", flush=True)
    asr_all(results)
    print("=== Environment ===", flush=True)
    write_environment(wall_start, device, revision, versions)
    print("DONE qual core", flush=True)


if __name__ == "__main__":
    main()
