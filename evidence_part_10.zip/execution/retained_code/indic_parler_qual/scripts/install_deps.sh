#!/bin/bash
set -euo pipefail
export HF_HOME=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-}"
export PIP_CACHE_DIR=/workspace/hf_cache/pip
mkdir -p "$HF_HOME" "$PIP_CACHE_DIR" /workspace/indic_parler_qual/{wavs,scripts,model_cache}

echo "=== Installing system deps ==="
apt-get update -qq
apt-get install -y -qq libsndfile1 ffmpeg git >/dev/null

echo "=== Installing Python packages ==="
# torch already in runpod image; upgrade/ensure matching stack
pip3 install -U pip wheel setuptools
# parler-tts from GitHub (package on PyPI may lag)
pip3 install -U "git+https://github.com/huggingface/parler-tts.git"
pip3 install -U "transformers==4.46.1" soundfile huggingface_hub accelerate sentencepiece protobuf
pip3 install -U openai-whisper jiwer librosa numpy
# ensure torch still present
python3 -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)"

echo "=== pip show key pkgs ==="
for p in parler-tts transformers torch soundfile huggingface_hub openai-whisper jiwer; do
  pip3 show "$p" | egrep '^(Name|Version):' || true
done
echo "INSTALL_OK"
