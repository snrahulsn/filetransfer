from __future__ import annotations

import os

os.environ.setdefault("USE_TF", "0")
os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
os.environ.setdefault("USE_TORCH", "1")

"""On-prem qualification for mistralai/Voxtral-4B-TTS-2603 via vLLM-Omni /v1/audio/speech."""

import hashlib
import json
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(os.environ.get("QUAL_OUT") or "/workspace/voxtral_tts_qual")
WAVS = OUT / "wavs"
WAVS.mkdir(parents=True, exist_ok=True)
MODEL_ID = "mistralai/Voxtral-4B-TTS-2603"
PIN = os.environ.get("MODEL_REVISION", "b81be46c3777f88621676791b512bb01dc1cb970")
SR = 24000
BASE = os.environ.get("VOXTRAL_BASE", "http://127.0.0.1:8000/v1")

# Prefer female presets; Arabic only has ar_male in published list
LOCALES = [
    ("hi-IN", "hi_female", "Hindi", "आपकी बैठक कल दोपहर तीन बजे है।", True),
    ("en-US", "casual_female", "English", "Your meeting with Priya is tomorrow at three thirty PM.", True),
    ("fr-FR", "fr_female", "French", "Votre réunion avec Priya est demain à quinze heures trente.", True),
    ("es-ES", "es_female", "Spanish", "Su reunión con Priya es mañana a las tres y media de la tarde.", True),
    ("de-DE", "de_female", "German", "Ihr Meeting mit Priya ist morgen um halb vier nachmittags.", True),
    ("it-IT", "it_female", "Italian", "Il suo incontro con Priya è domani alle tre e trenta del pomeriggio.", True),
    ("pt-BR", "pt_female", "Portuguese", "A sua reunião com a Priya é amanhã às três e meia da tarde.", True),
    ("nl-NL", "nl_female", "Dutch", "Uw vergadering met Priya is morgen om half vier 's middags.", True),
    ("ar-SA", "ar_male", "Arabic", "اجتماعك مع بريا غداً في الثالثة والنصف مساءً.", True),
]

WHISPER_LANG = {
    "hi-IN": "hi", "en-US": "en", "fr-FR": "fr", "es-ES": "es", "de-DE": "de",
    "it-IT": "it", "pt-BR": "pt", "nl-NL": "nl", "ar-SA": "ar",
}


def write_text(p: Path, t: str) -> None:
    p.write_text(t, encoding="utf-8")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def record_versions():
    pkgs = ["vllm", "vllm-omni", "mistral_common", "torch", "soundfile", "httpx", "openai-whisper", "jiwer", "huggingface_hub", "numpy"]
    versions = {}
    for p in pkgs:
        try:
            out = subprocess.check_output([sys.executable, "-m", "pip", "show", p], text=True, stderr=subprocess.DEVNULL)
            info = {}
            for line in out.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    info[k.strip()] = v.strip()
            versions[p] = {"version": info.get("Version"), "location": info.get("Location")}
        except Exception as e:
            versions[p] = {"version": None, "error": str(e)}
    write_text(OUT / "versions.json", json.dumps(versions, indent=2))
    return versions


def download_and_pin():
    from huggingface_hub import snapshot_download, HfApi

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    tip = HfApi(token=token).model_info(MODEL_ID).sha
    print(f"tip={tip} pin={PIN}", flush=True)
    path = snapshot_download(
        MODEL_ID, revision=PIN, token=token, cache_dir="/workspace/hf_cache",
        local_dir=str(OUT / "model_cache" / "voxtral"), local_dir_use_symlinks=False,
    )
    write_text(OUT / "model_revision.txt", PIN + "\n")
    write_text(OUT / "model_tip_sha.txt", tip + "\n")
    return PIN, path


def start_server(model_path: str):
    log = open(OUT / "vllm_serve.log", "w")
    # Official card: vllm serve MODEL --omni
    cmd = ["vllm", "serve", MODEL_ID, "--omni", "--port", "8000", "--revision", PIN, "--enforce-eager"]
    env = os.environ.copy()
    if os.environ.get("HF_TOKEN"):
        env["HUGGING_FACE_HUB_TOKEN"] = os.environ["HF_TOKEN"]
    print("Starting", " ".join(cmd), flush=True)
    proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
    write_text(OUT / "vllm_serve.pid", str(proc.pid) + "\n")
    time.sleep(8)
    import urllib.request

    t0 = time.time()
    while time.time() - t0 < 1200:
        if proc.poll() is not None:
            raise RuntimeError(f"vllm exited early code={proc.returncode}; see vllm_serve.log")
        for url in (BASE.replace("/v1", "") + "/health", BASE + "/models"):
            try:
                with urllib.request.urlopen(url, timeout=5) as r:
                    if r.status == 200:
                        print("server ready via", url, flush=True)
                        return proc
            except Exception:
                pass
        time.sleep(5)
    raise TimeoutError("vllm serve not ready in 1200s")


def stop_server(proc):
    if proc is None:
        return
    try:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=45)
        except subprocess.TimeoutExpired:
            proc.kill()
    except Exception as e:
        print("stop warn", e, flush=True)


def synthesize_all(revision):
    import io
    import httpx
    import numpy as np
    import soundfile as sf

    results = []
    streaming_note = "stream=true probe pending"
    stream_ok = None
    for locale, voice, language, sentence, official in LOCALES:
        rec = {
            "locale": locale, "sentence": sentence, "voice": voice, "language": language,
            "officially_supported": official, "supported": official, "experimental": False,
            "success": False, "error": None, "sample_rate": SR, "wav_path": f"wavs/{locale}.wav",
            "voice_clone_3s": "NOT used (preset voices; public ckpt lacks encoder for ref_audio)",
        }
        out_wav = WAVS / f"{locale}.wav"
        print(f"=== Synth {locale} voice={voice} lang={language} ===", flush=True)
        payload = {
            "input": sentence, "model": MODEL_ID, "response_format": "wav",
            "voice": voice, "language": language,
        }
        try:
            t0 = time.perf_counter()
            r = httpx.post(f"{BASE}/audio/speech", json=payload, timeout=180.0)
            t1 = time.perf_counter()
            r.raise_for_status()
            audio, sr = sf.read(io.BytesIO(r.content), dtype="float32")
            audio = np.asarray(audio).reshape(-1)
            peak = float(np.max(np.abs(audio))) if audio.size else 0.0
            if peak < 1e-4 or audio.size < sr * 0.2:
                raise RuntimeError(f"SILENCE_OR_TOO_SHORT peak={peak} samples={audio.size}")
            sf.write(str(out_wav), audio, int(sr))
            dur = float(len(audio) / sr)
            synth = float(t1 - t0)
            rec.update({
                "success": True, "total_synthesis_time_s": round(synth, 4),
                "audio_duration_s": round(dur, 4), "RTF": round(synth / dur, 4) if dur > 0 else None,
                "sample_rate": int(sr), "sha256": sha256_file(out_wav),
                "num_samples": int(len(audio)), "peak_abs": peak,
            })
            print(f"  OK synth={synth:.3f}s dur={dur:.3f}s RTF={rec['RTF']}", flush=True)
            if stream_ok is None:
                try:
                    sp = dict(payload)
                    sp["stream"] = True
                    sp["response_format"] = "pcm"
                    sr2 = httpx.post(f"{BASE}/audio/speech", json=sp, timeout=180.0)
                    stream_ok = sr2.status_code == 200 and len(sr2.content) > 1000
                    streaming_note = f"stream=true probe: {'OK' if stream_ok else 'FAILED status='+str(sr2.status_code)}"
                except Exception as se:
                    streaming_note = f"stream=true probe FAILED: {type(se).__name__}: {se}"
                    stream_ok = False
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {e}"
            rec["traceback"] = traceback.format_exc()
            print(f"  FAIL {rec['error']}", flush=True)
        results.append(rec)
        write_text(OUT / "results.json", json.dumps({
            "model_id": MODEL_ID, "revision": revision,
            "voice_policy": "Preset female voices where available; ar_male for Arabic.",
            "streaming": streaming_note,
            "license_note": "CC BY-NC 4.0 inherited — see license_check.md",
            "results": results,
        }, indent=2, ensure_ascii=False))
    return results, streaming_note


def clipping_analysis(results):
    import numpy as np
    import soundfile as sf

    clips = []
    for r in results:
        locale = r["locale"]
        wav = WAVS / f"{locale}.wav"
        entry = {"locale": locale, "peak_dBFS": None, "clipped": False, "clipped_samples": 0, "total_samples": 0, "error": None}
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            clips.append(entry)
            continue
        audio, sr = sf.read(str(wav), dtype="float64")
        audio = np.asarray(audio).reshape(-1)
        entry["total_samples"] = int(audio.size)
        peak = float(np.max(np.abs(audio))) if audio.size else 0.0
        entry["peak_dBFS"] = float("-inf") if peak <= 0 else round(20.0 * np.log10(peak), 4)
        n = int((np.abs(audio) >= 0.999999).sum())
        entry["clipped_samples"] = n
        entry["clipped"] = bool(n > 0 and entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001)
        entry["flag_0dBFS_with_clipped_samples"] = bool(entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001 and n > 0)
        clips.append(entry)
    write_text(OUT / "clipping.json", json.dumps({"clipping": clips}, indent=2))
    return clips


def normalize_text(s):
    import re
    import unicodedata

    s = unicodedata.normalize("NFC", s or "").strip().lower()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()


def compute_wer_cer(ref, hyp):
    from jiwer import cer, wer

    ref_n, hyp_n = normalize_text(ref), normalize_text(hyp)
    if not ref_n:
        return None, None, ref_n, hyp_n
    if not hyp_n:
        return 1.0, 1.0, ref_n, hyp_n
    try:
        w = float(wer(ref_n, hyp_n))
    except Exception:
        w = 1.0
    try:
        c = float(cer(ref_n, hyp_n))
    except Exception:
        c = 1.0
    return w, c, ref_n, hyp_n


def asr_all(results):
    import torch
    import whisper

    print("Loading Whisper large-v3...", flush=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    asr = whisper.load_model("large-v3", device=device)
    metrics = {"asr_model": "openai-whisper/large-v3", "failure_bar": "empty transcript OR WER>=0.9 OR CER>=0.9", "results": []}
    for r in results:
        locale, sentence = r["locale"], r["sentence"]
        wav = WAVS / f"{locale}.wav"
        entry = {"locale": locale, "reference": sentence, "transcript": None, "WER": None, "CER": None, "pass": False,
                 "error": None, "whisper_language": WHISPER_LANG.get(locale)}
        print(f"=== ASR {locale} ===", flush=True)
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            metrics["results"].append(entry)
            continue
        try:
            kwargs = {"fp16": device == "cuda"}
            lang = WHISPER_LANG.get(locale)
            if lang:
                kwargs.update({"language": lang, "task": "transcribe"})
            result = asr.transcribe(str(wav), **kwargs)
            transcript = (result.get("text") or "").strip()
            entry["transcript"] = transcript
            entry["detected_language"] = result.get("language")
            w, c, ref_n, hyp_n = compute_wer_cer(sentence, transcript)
            entry["WER"] = None if w is None else round(w, 4)
            entry["CER"] = None if c is None else round(c, 4)
            entry["ref_normalized"] = ref_n
            entry["hyp_normalized"] = hyp_n
            empty = not transcript
            fail = empty or (w is not None and w >= 0.9) or (c is not None and c >= 0.9)
            entry["pass"] = not fail
            entry["failure_reason"] = "empty transcript" if empty else ("WER/CER >= 0.9" if fail else None)
            print(f"  WER={entry['WER']} CER={entry['CER']} pass={entry['pass']} :: {transcript[:80]}", flush=True)
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
            entry["traceback"] = traceback.format_exc()
        metrics["results"].append(entry)
        write_text(OUT / "asr_metrics.json", json.dumps(metrics, indent=2, ensure_ascii=False))
    return metrics


def write_environment(wall, device, revision, versions, streaming_note):
    import torch

    gpu = None
    if torch.cuda.is_available():
        gpu = {
            "name": torch.cuda.get_device_name(0),
            "capability": list(torch.cuda.get_device_capability(0)),
            "total_memory_gb": round(torch.cuda.get_device_properties(0).total_memory / (1024 ** 3), 2),
        }
    env = {
        "model_id": MODEL_ID, "revision": revision, "device": device,
        "gpu_vs_cpu": "GPU" if device == "cuda" else "CPU", "gpu": gpu,
        "torch_version": torch.__version__, "cuda_available": torch.cuda.is_available(),
        "total_wall_clock_s": round(time.perf_counter() - wall, 2),
        "hostname": subprocess.check_output(["hostname"], text=True).strip(),
        "python": sys.version, "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "streaming": streaming_note,
        "key_versions": {k: (v.get("version") if isinstance(v, dict) else v) for k, v in versions.items()},
    }
    write_text(OUT / "environment.json", json.dumps(env, indent=2))
    return env


def main():
    wall = time.perf_counter()
    proc = None
    try:
        versions = record_versions()
        revision, path = download_and_pin()
        proc = start_server(path)
        results, streaming_note = synthesize_all(revision)
        clipping_analysis(results)
        asr_all(results)
        write_environment(wall, "cuda", revision, versions, streaming_note)
        print("DONE voxtral qual core", flush=True)
    finally:
        stop_server(proc)


if __name__ == "__main__":
    main()
