#!/bin/bash
set -euo pipefail
export HF_HOME=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-}"
export PIP_CACHE_DIR=/workspace/hf_cache/pip
mkdir -p "$HF_HOME" "$PIP_CACHE_DIR" /workspace/voxtral_tts_qual/{wavs,scripts}
apt-get update -qq
apt-get install -y -qq libsndfile1 ffmpeg >/dev/null
pip3 install -U pip wheel setuptools
pip3 install -U "numpy>=1.26,<2.1" soundfile httpx openai-whisper jiwer librosa huggingface_hub
# vLLM + omni — try recent wheels
pip3 install -U "vllm>=0.8.0" || pip3 install -U vllm
pip3 install -U "vllm-omni" || pip3 install -U "git+https://github.com/vllm-project/vllm-omni.git" || echo "vllm-omni install soft-fail"
pip3 install -U "mistral_common>=1.5.0" || pip3 install -U mistral_common
python3 -c "import torch,vllm; print('torch',torch.__version__,'vllm',vllm.__version__, torch.cuda.get_device_name(0))"
python3 -c "import mistral_common; print('mistral_common', mistral_common.__version__)"
echo INSTALL_OK
