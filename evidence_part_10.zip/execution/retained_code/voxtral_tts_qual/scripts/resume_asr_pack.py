#!/usr/bin/env python3
"""Resume Voxtral qual after synth: ASR + environment + package. GPU is free (vLLM stopped)."""
from __future__ import annotations
import json, os, sys, time
from pathlib import Path
sys.path.insert(0, "/workspace/voxtral_tts_qual/scripts")
os.environ.setdefault("QUAL_OUT", "/workspace/voxtral_tts_qual")
os.environ.setdefault("USE_TF", "0")
os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
os.environ.setdefault("USE_TORCH", "1")
import run_qual as rq

OUT = rq.OUT
wall = time.perf_counter()
data = json.loads((OUT / "results.json").read_text(encoding="utf-8"))
results = data["results"]
streaming_note = data.get("streaming", "stream=true probe: OK")
revision = data.get("revision") or "b81be46c3777f88621676791b512bb01dc1cb970"
print(f"RESUME ASR for {len(results)} locales; GPU free check...", flush=True)
import torch
print("cuda_available", torch.cuda.is_available(), "mem", torch.cuda.mem_get_info() if torch.cuda.is_available() else None, flush=True)
versions = rq.record_versions()
rq.asr_all(results)
rq.write_environment(wall, "cuda", revision, versions, streaming_note)
print("DONE voxtral qual core (resume ASR)", flush=True)
