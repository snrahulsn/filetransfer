#!/bin/bash
set -euo pipefail
export HF_TOKEN='[REDACTED]'
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
export HF_HOME=/workspace/hf_cache
export QUAL_OUT=/workspace/voxtral_tts_qual
export USE_TF=0 TRANSFORMERS_NO_TF=1 USE_TORCH=1
echo 'ljousqqvw86gll' > /workspace/voxtral_tts_qual/pod_id.txt
cd /workspace/voxtral_tts_qual
bash scripts/install_deps.sh 2>&1 | tee install.log
python3 scripts/run_qual.py 2>&1 | tee qual.log
python3 scripts/package_results.py 2>&1 | tee -a qual.log || true
echo VOXTRAL_DONE
