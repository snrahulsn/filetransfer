#!/usr/bin/env python3
"""FLEURS ASR eval from prebuilt wav manifest. Fail loudly. No fabricated WER."""
from __future__ import annotations
import argparse, json, os, re, sys, time, traceback, unicodedata
from pathlib import Path
import numpy as np
import torch

MODEL_SPECS = {
    "SraVaani-0.5-live": {
        "repo_id": "ARTPARK-IISc/SraVaani-0.5-live",
        "revision": "29a15303a55673367134eee9e1d18cb1a2dcaabf",
        "kind": "sravaani05",
        "unsupported_langs": ["ur_in", "ur_pk"],
        "notes": "Streaming FastConformer-CTC; att_context [70,13] (1040ms). Urdu unsupported.",
    },
    "SraVaani-1.0": {
        "repo_id": "ARTPARK-IISc/SraVaani-1.0",
        "revision": "f5dd5358325a5208775b91dad98918e079ea2b27",
        "kind": "sravaani10",
        "unsupported_langs": ["ur_in", "ur_pk"],
        "notes": "Hybrid TDT-CTC FastConformer FP16. Urdu unsupported.",
    },
    "indic-conformer-600m": {
        "repo_id": "ai4bharat/indic-conformer-600m-multilingual",
        "revision": "e9b71b369c048e2c6b634d4c131061c34e441179",
        "kind": "indic_conformer",
        "unsupported_langs": ["en_us", "en_in"],
        "decode": "ctc",
        "notes": "IN-22 hybrid CTC+RNNT; eval uses CTC. English not in IN-22.",
    },
}
FLEURS_DATASET = "google/fleurs"
FLEURS_REVISION = "70bb2e84b976b7e960aa89f1c648e09c59f894dd"
LATIN_LANGS = {"en_us", "en_in"}

def die(msg, code=1):
    print(f"FATAL: {msg}", file=sys.stderr, flush=True)
    raise SystemExit(code)

def normalize_text(text: str, lang: str) -> str:
    text = unicodedata.normalize("NFKC", text or "")
    if lang in LATIN_LANGS:
        text = text.lower()
    text = re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def fleurs_to_model_lang(fleurs_code: str, kind: str):
    base = fleurs_code.split("_")[0]
    if kind == "indic_conformer":
        if base == "en":
            return None
        return base  # ur_pk -> ur, hi_in -> hi
    return base

def load_model(spec, device, hf_token, dtype_name):
    from transformers import AutoModel
    from huggingface_hub import whoami
    who = whoami(token=hf_token)
    name = who.get("name") if isinstance(who, dict) else getattr(who, "name", None)
    if name != "xrahul16":
        die(f"HF whoami expected xrahul16, got {who}")
    dtype = {"float16": torch.float16, "bfloat16": torch.bfloat16, "float32": torch.float32}[dtype_name]
    print(f"Loading {spec['repo_id']}@{spec['revision']} dtype={dtype_name} device={device}", flush=True)
    t0 = time.time()
    kw = dict(revision=spec["revision"], trust_remote_code=True, token=hf_token)
    if spec["kind"] != "indic_conformer":
        kw["torch_dtype"] = dtype
    model = AutoModel.from_pretrained(spec["repo_id"], **kw)
    model = model.to(device)
    if hasattr(model, "eval"):
        model.eval()
    if spec["kind"] == "sravaani05" and hasattr(model, "set_att_context_size"):
        left = model.config.att_context_size[0]
        model.set_att_context_size([left, 13])
        print(f"  att_context={[left,13]} lookahead={getattr(model.config,'lookahead_seconds','?')}", flush=True)
    load_s = time.time() - t0
    print(f"  model_load_s={load_s:.2f}", flush=True)
    return model, load_s, dtype_name

@torch.inference_mode()
def transcribe_one(model, kind, wav_path, lang, device, decode="ctc") -> str:
    if kind == "sravaani10":
        hyps = model.transcribe(wav_path, return_hypotheses=True)
        if isinstance(hyps, list):
            h = hyps[0]
            return ((h.text if hasattr(h, "text") else str(h)) or "").strip()
        return ((hyps.text if hasattr(hyps, "text") else str(hyps)) or "").strip()
    if kind == "sravaani05":
        out = model.transcribe([wav_path])
        if isinstance(out, (list, tuple)):
            return (out[0] or "").strip()
        return (str(out) or "").strip()
    if kind == "indic_conformer":
        import torchaudio
        wav, sr = torchaudio.load(wav_path)
        if wav.shape[0] > 1:
            wav = torch.mean(wav, dim=0, keepdim=True)
        if sr != 16000:
            wav = torchaudio.functional.resample(wav, sr, 16000)
        wav = wav.to(device)
        ml = fleurs_to_model_lang(lang, kind)
        if ml is None:
            raise RuntimeError(f"lang {lang} unsupported")
        out = model(wav, ml, decode)
        if isinstance(out, (list, tuple)):
            out = out[0]
        return (str(out) or "").strip()
    raise RuntimeError(f"unknown kind {kind}")

def compute_metrics(rows):
    import jiwer
    per_lang = {}
    all_refs, all_hyps = [], []
    for lang in sorted({r["lang"] for r in rows}):
        lr = [r for r in rows if r["lang"] == lang and r.get("ok")]
        if not lr:
            per_lang[lang] = {"n": 0, "wer": None, "cer": None, "skipped": True}
            continue
        refs = [normalize_text(r["reference"], lang) for r in lr]
        hyps = [normalize_text(r["hypothesis"], lang) for r in lr]
        pairs = [(a, b) for a, b in zip(refs, hyps) if a]
        if not pairs:
            per_lang[lang] = {"n": len(lr), "wer": None, "cer": None, "note": "all empty refs"}
            continue
        refs2, hyps2 = zip(*pairs)
        wer = float(jiwer.wer(list(refs2), list(hyps2)))
        cer = float(jiwer.cer(list(refs2), list(hyps2)))
        per_lang[lang] = {
            "n": len(lr), "n_scored": len(pairs),
            "wer": wer, "cer": cer,
            "audio_s": sum(r["duration_s"] for r in lr),
            "infer_s": sum(r["infer_s"] for r in lr),
            "rtf": (sum(r["infer_s"] for r in lr) / max(sum(r["duration_s"] for r in lr), 1e-9)),
        }
        all_refs.extend(refs2); all_hyps.extend(hyps2)
    micro = {}
    if all_refs:
        micro = {"n": len(all_refs), "wer": float(jiwer.wer(all_refs, all_hyps)), "cer": float(jiwer.cer(all_refs, all_hyps))}
    return {"per_lang": per_lang, "micro": micro}

def write_summary(out_dir, spec, config, metrics, throughput):
    lines = [f"# {out_dir.name} — FLEURS ASR", "",
             f"- Model: `{spec['repo_id']}`",
             f"- Revision: `{spec['revision']}`",
             f"- Device/dtype: `{config.get('device')}` / `{config.get('dtype')}`",
             f"- Dataset: `{config.get('dataset')}` revision `{config.get('dataset_revision')}` split=test",
             f"- Cap/lang: {config.get('cap_per_lang')}",
             f"- Normalization: NFKC; lower for Latin only; strip punctuation; collapse whitespace",
             f"- Decode: {config.get('decode_settings')}",
             f"- GPU: {throughput.get('gpu_name')}",
             f"- Notes: {spec.get('notes')}", "",
             "## Per-language WER / CER", "",
             "| Lang | N | WER | CER | RTF |", "|---|---:|---:|---:|---:|"]
    for lang, m in sorted(metrics["per_lang"].items()):
        if m.get("wer") is None:
            lines.append(f"| {lang} | {m.get('n', 0)} | — | — | — |")
        else:
            lines.append(f"| {lang} | {m['n']} | {100*m['wer']:.2f}% | {100*m['cer']:.2f}% | {m['rtf']:.3f} |")
    micro = metrics.get("micro") or {}
    lines += ["", "## Micro-average", ""]
    if micro:
        lines.append(f"- N={micro['n']}  WER={100*micro['wer']:.2f}%  CER={100*micro['cer']:.2f}%")
    else:
        lines.append("- (no scored utterances)")
    lines += ["", "## Throughput", "",
              f"- Total audio: {throughput.get('total_audio_s'):.1f}s",
              f"- Total infer: {throughput.get('total_infer_s'):.1f}s",
              f"- Overall RTF: {throughput.get('overall_rtf'):.4f}",
              f"- Utterances/s: {throughput.get('utt_per_s'):.3f}",
              f"- Model load: {throughput.get('model_load_s'):.1f}s", ""]
    skipped = config.get("skipped_langs") or []
    if skipped:
        lines += ["## Skipped languages", ""] + [f"- {s}" for s in skipped] + [""]
    (out_dir / "SUMMARY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-key", required=True, choices=list(MODEL_SPECS.keys()))
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--manifest", default="/workspace/fleurs_asr_trio/_fleurs_wav_cache/manifest_all.jsonl")
    ap.add_argument("--cap", type=int, default=100)
    ap.add_argument("--dtype", default="float16")
    ap.add_argument("--device", default=None)
    args = ap.parse_args()
    hf_token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if not hf_token: die("HF_TOKEN not set")
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    if device == "cuda" and not torch.cuda.is_available(): die("CUDA unavailable")
    spec = dict(MODEL_SPECS[args.model_key])
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    man = Path(args.manifest)
    if not man.exists(): die(f"manifest missing: {man}")
    utts = [json.loads(l) for l in man.read_text(encoding="utf-8").splitlines() if l.strip()]
    # per-lang cap + unsupported filter
    skipped = []
    by_lang = {}
    for u in utts:
        by_lang.setdefault(u["lang"], []).append(u)
    selected = []
    for lang, items in by_lang.items():
        if lang in spec.get("unsupported_langs", []):
            skipped.append(f"{lang}: unsupported by {spec['repo_id']}")
            continue
        selected.extend(items[:args.cap])
    if not selected: die("no utterances after filter")
    print(f"Evaluating {len(selected)} utts across {len({u['lang'] for u in selected})} langs", flush=True)
    gpu_name = torch.cuda.get_device_name(0) if device == "cuda" else None
    model, load_s, dtype_used = load_model(spec, device, hf_token, args.dtype)
    decode_settings = {
        "sravaani05": "transcribe(paths); att_context_size=[70,13]; CTC greedy",
        "sravaani10": "transcribe(path, return_hypotheses=True); hybrid TDT-CTC",
        "indic_conformer": f"model(wav, lang, '{spec.get('decode','ctc')}')",
    }[spec["kind"]]
    results = []; total_audio = 0.0; total_infer = 0.0
    t_all0 = time.time()
    for idx, utt in enumerate(selected):
        total_audio += utt["duration_s"]
        t0 = time.time()
        try:
            hyp = transcribe_one(model, spec["kind"], utt["wav"], utt["lang"], device, decode=spec.get("decode","ctc"))
            infer_s = time.time() - t0; total_infer += infer_s
            row = {**utt, "hypothesis": hyp, "infer_s": infer_s,
                   "rtf": infer_s / max(utt["duration_s"], 1e-9), "ok": True, "error": None}
        except Exception as e:
            infer_s = time.time() - t0; total_infer += infer_s
            row = {**utt, "hypothesis": "", "infer_s": infer_s, "rtf": None, "ok": False,
                   "error": f"{type(e).__name__}: {e}"}
            print(f"FAIL {utt['utt_id']}: {e}", flush=True)
        results.append(row)
        if (idx + 1) % 25 == 0 or idx == 0:
            print(f"[{idx+1}/{len(selected)}] {utt['utt_id']} ok={row['ok']} rtf={row.get('rtf')} hyp={row['hypothesis'][:60]!r}", flush=True)
    wall_s = time.time() - t_all0
    ok_rows = [r for r in results if r["ok"]]
    if not ok_rows: die(f"All {len(results)} utterances failed")
    metrics = compute_metrics(ok_rows)
    throughput = {
        "gpu_name": gpu_name, "device": device,
        "total_audio_s": total_audio, "total_infer_s": total_infer, "wall_s": wall_s,
        "overall_rtf": total_infer / max(total_audio, 1e-9),
        "utt_per_s": len(ok_rows) / max(total_infer, 1e-9),
        "model_load_s": load_s, "n_ok": len(ok_rows),
        "n_fail": sum(1 for r in results if not r["ok"]),
    }
    config = {
        "model_key": args.model_key, "repo_id": spec["repo_id"], "revision": spec["revision"],
        "dtype": dtype_used, "device": device, "gpu_name": gpu_name,
        "decode_settings": decode_settings, "dataset": FLEURS_DATASET,
        "dataset_revision": FLEURS_REVISION, "split": "test",
        "cap_per_lang": args.cap, "skipped_langs": skipped,
        "N_total": len(results), "N_ok": len(ok_rows),
        "normalization": {"unicode":"NFKC","case":"lower for Latin (en_*) only","punctuation":"strip","whitespace":"collapse"},
        "metrics_lib": "jiwer", "hf_whoami": "xrahul16", "notes": spec.get("notes"),
        "volume_id": "ul08t4z9qx", "manifest": str(man),
    }
    (out_dir / "config.json").write_text(json.dumps(config, indent=2)+"\n")
    payload = {"config": config, "throughput": throughput, "metrics": metrics, "utterances": results}
    (out_dir / "results.json").write_text(json.dumps(payload, indent=2)+"\n")
    write_summary(out_dir, spec, config, metrics, throughput)
    print(json.dumps({"done": args.model_key, "micro": metrics.get("micro"), "throughput": throughput}, indent=2), flush=True)

if __name__ == "__main__":
    main()
