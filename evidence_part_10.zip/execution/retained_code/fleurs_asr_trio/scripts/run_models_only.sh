#!/bin/bash
set -euo pipefail
export TMPDIR=/workspace/tmp
mkdir -p "$TMPDIR"
export HF_HOME=/workspace/hf_cache
export HUGGINGFACE_HUB_CACHE=/workspace/hf_cache/hub
export HF_HUB_CACHE=/workspace/hf_cache/hub
export HF_DATASETS_CACHE=/workspace/hf_cache/datasets
export HF_HUB_DISABLE_XET=1
unset TRANSFORMERS_CACHE || true
source /workspace/fleurs_asr_trio/.hf_token_env
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
OUT_ROOT=/workspace/fleurs_asr_trio
LOG=$OUT_ROOT/logs/models_$(date +%Y%m%d_%H%M%S).log
mkdir -p "$OUT_ROOT/logs"

python3 -c "from huggingface_hub import whoami; w=whoami(); print(w); assert w['name']=='xrahul16'" | tee -a "$LOG"
wc -l "$OUT_ROOT/_fleurs_wav_cache/manifest_all.jsonl" | tee -a "$LOG"

# Prefetch model artifacts
python3 - <<'PY' | tee -a "$LOG"
import os
from huggingface_hub import snapshot_download, whoami
assert whoami()["name"]=="xrahul16"
models=[
 ("ARTPARK-IISc/SraVaani-0.5-live","29a15303a55673367134eee9e1d18cb1a2dcaabf"),
 ("ARTPARK-IISc/SraVaani-1.0","f5dd5358325a5208775b91dad98918e079ea2b27"),
 ("ai4bharat/indic-conformer-600m-multilingual","e9b71b369c048e2c6b634d4c131061c34e441179"),
]
for repo, rev in models:
  print("prefetch", repo, rev, flush=True)
  p=snapshot_download(repo, revision=rev, token=os.environ["HF_TOKEN"])
  print("  ->", p, flush=True)
PY

run_one() {
  local key="$1"; local out="$2"
  mkdir -p "$out/scripts"
  cp -f "$OUT_ROOT/scripts/"*.py "$OUT_ROOT/scripts/"*.sh "$out/scripts/" 2>/dev/null || true
  echo "=== RUN $key $(date -Iseconds) ===" | tee -a "$LOG"
  python3 "$OUT_ROOT/scripts/run_fleurs_eval.py" --model-key "$key" --out-dir "$out" --cap 100 --dtype float16 \
    2>&1 | tee -a "$LOG" | tee "$out/run.log"
  echo "=== DONE $key $(date -Iseconds) ===" | tee -a "$LOG"
}

run_one "SraVaani-0.5-live" "$OUT_ROOT/SraVaani-0.5-live"
run_one "SraVaani-1.0" "$OUT_ROOT/SraVaani-1.0"
run_one "indic-conformer-600m" "$OUT_ROOT/indic-conformer-600m"
echo "=== ALL MODELS DONE $(date -Iseconds) ===" | tee -a "$LOG"
touch "$OUT_ROOT/logs/ALL_DONE"
