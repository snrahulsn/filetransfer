#!/bin/bash
set -euo pipefail
export HF_HOME=/workspace/hf_cache
export HUGGINGFACE_HUB_CACHE=/workspace/hf_cache/hub
export HF_DATASETS_CACHE=/workspace/hf_cache/datasets
unset TRANSFORMERS_CACHE || true
source /workspace/fleurs_asr_trio/.hf_token_env
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
OUT_ROOT=/workspace/fleurs_asr_trio
LOG=$OUT_ROOT/logs/run_$(date +%Y%m%d_%H%M%S).log
mkdir -p "$OUT_ROOT/logs" "$OUT_ROOT/_fleurs_wav_cache"

echo "=== setup $(date -Iseconds) ===" | tee -a "$LOG"
nvidia-smi | tee -a "$LOG"

python3 -m pip install -q -U pip
python3 -m pip install -q "torch==2.4.1" "torchaudio==2.4.1" --index-url https://download.pytorch.org/whl/cu124 2>&1 | tee -a "$LOG" || true
python3 -m pip install -q "transformers==4.46.3" "datasets==3.1.0" soundfile librosa jiwer sentencepiece "accelerate==1.1.1" huggingface_hub numpy 2>&1 | tee -a "$LOG"
python3 -m pip install -q "onnx==1.17.0" "onnxruntime-gpu==1.20.2" 2>&1 | tee -a "$LOG" || true

python3 -c "from huggingface_hub import whoami; w=whoami(); print(w); assert w['name']=='xrahul16'" | tee -a "$LOG"
python3 - <<'PY' | tee -a "$LOG"
import torch, transformers
from transformers import AutoModel
print("torch", torch.__version__, torch.cuda.get_device_name(0))
print("transformers", transformers.__version__, "AutoModel OK")
PY

echo "=== PREP FLEURS CACHE $(date -Iseconds) ===" | tee -a "$LOG"
python3 "$OUT_ROOT/scripts/prep_fleurs_cache.py" --cap 100 2>&1 | tee -a "$LOG"

run_one() {
  local key="$1"; local out="$2"
  mkdir -p "$out/scripts"
  cp -f "$OUT_ROOT/scripts/"*.py "$OUT_ROOT/scripts/"*.sh "$out/scripts/" 2>/dev/null || true
  echo "=== RUN $key $(date -Iseconds) ===" | tee -a "$LOG"
  python3 "$OUT_ROOT/scripts/run_fleurs_eval.py" --model-key "$key" --out-dir "$out" --cap 100 --dtype float16 \
    2>&1 | tee -a "$LOG" | tee "$out/run.log"
  echo "=== DONE $key $(date -Iseconds) ===" | tee -a "$LOG"
}

run_one "SraVaani-0.5-live" "$OUT_ROOT/SraVaani-0.5-live"
run_one "SraVaani-1.0" "$OUT_ROOT/SraVaani-1.0"
run_one "indic-conformer-600m" "$OUT_ROOT/indic-conformer-600m"
echo "=== ALL MODELS DONE $(date -Iseconds) ===" | tee -a "$LOG"
touch "$OUT_ROOT/logs/ALL_DONE"
