#!/usr/bin/env python3
"""Prepare FLEURS test wav cache via streaming (avoids full train materialization)."""
from __future__ import annotations
import argparse, json, os, sys, gc
from pathlib import Path
import numpy as np
import soundfile as sf

LANGS = [
    "hi_in","bn_in","te_in","ta_in","ml_in","mr_in",
    "gu_in","kn_in","pa_in","as_in","or_in","ur_in","en_us",
]
DATASET = "google/fleurs"
REVISION = "70bb2e84b976b7e960aa89f1c648e09c59f894dd"

def die(m):
    print("FATAL:", m, file=sys.stderr, flush=True); raise SystemExit(1)

def prep_lang(lang, out, cap, token):
    from datasets import load_dataset, Audio
    man_path = out / f"manifest_{lang}.jsonl"
    lang_dir = out / lang
    lang_dir.mkdir(parents=True, exist_ok=True)
    if man_path.exists():
        rows = [json.loads(l) for l in man_path.read_text().splitlines() if l.strip()]
        ok = sum(1 for r in rows if Path(r["wav"]).exists() and Path(r["wav"]).stat().st_size > 0)
        if len(rows) >= cap and ok >= cap:
            print(f"SKIP cached {lang} N={len(rows)}", flush=True)
            return rows[:cap]
    print(f"streaming {lang}...", flush=True)
    try:
        ds = load_dataset(DATASET, lang, split="test", revision=REVISION, token=token,
                          trust_remote_code=True, streaming=True)
    except Exception as e:
        print(f"WARN streaming+rev failed ({e}); retry...", flush=True)
        ds = load_dataset(DATASET, lang, split="test", token=token, trust_remote_code=True, streaming=True)
    ds = ds.cast_column("audio", Audio(sampling_rate=16000))
    rows = []
    for i, ex in enumerate(ds):
        if i >= cap:
            break
        aud = ex["audio"]
        arr = np.asarray(aud["array"], dtype=np.float32)
        if arr.ndim > 1:
            arr = arr.mean(axis=-1)
        sr = int(aud["sampling_rate"])
        uid = f"{i:04d}"
        wav = lang_dir / f"{uid}.wav"
        if not wav.exists() or wav.stat().st_size == 0:
            sf.write(str(wav), arr, sr, subtype="PCM_16")
        ref = ex.get("transcription") or ex.get("raw_transcription") or ""
        rows.append({
            "utt_id": f"{lang}/{uid}",
            "lang": lang,
            "wav": str(wav),
            "reference": ref,
            "duration_s": float(len(arr) / sr) if sr else 0.0,
            "fleurs_id": str(ex.get("id", "")),
        })
        if (i + 1) % 20 == 0:
            print(f"  {lang} {i+1}/{cap}", flush=True)
    man_path.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + "\n", encoding="utf-8")
    print(f"cached {lang} N={len(rows)}", flush=True)
    del ds; gc.collect()
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="/workspace/fleurs_asr_trio/_fleurs_wav_cache")
    ap.add_argument("--cap", type=int, default=100)
    ap.add_argument("--langs", default=",".join(LANGS))
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if not token: die("HF_TOKEN missing")
    from huggingface_hub import whoami
    w = whoami(token=token)
    name = w.get("name") if isinstance(w, dict) else getattr(w, "name", None)
    if name != "xrahul16": die(f"whoami={w}")
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    if args.force:
        for p in out.glob("manifest_*.jsonl"):
            p.unlink()
    langs = [x.strip() for x in args.langs.split(",") if x.strip()]
    all_rows = []; skipped = []
    for lang in langs:
        try:
            all_rows.extend(prep_lang(lang, out, args.cap, token))
        except Exception as e:
            skipped.append(f"{lang}: {e}")
            print(f"SKIP {lang}: {e}", flush=True)
            import traceback; traceback.print_exc()
    meta = {"dataset": DATASET, "revision": REVISION, "cap": args.cap,
            "n_total": len(all_rows), "skipped": skipped,
            "langs": sorted({r["lang"] for r in all_rows})}
    (out / "manifest_all.jsonl").write_text(
        "\n".join(json.dumps(r, ensure_ascii=False) for r in all_rows) + "\n", encoding="utf-8")
    (out / "meta.json").write_text(json.dumps(meta, indent=2) + "\n")
    print(json.dumps(meta, indent=2), flush=True)
    if not all_rows: die("no utterances")

if __name__ == "__main__":
    main()
