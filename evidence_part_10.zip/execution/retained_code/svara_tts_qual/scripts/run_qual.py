#!/usr/bin/env python3
"""On-prem qualification for kenpath/svara-tts-v1 (transformers+SNAC Space pattern)."""
from __future__ import annotations
import hashlib, json, os, re, subprocess, sys, time, traceback
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(os.environ.get("QUAL_OUT", "/workspace/svara_tts_qual"))
WAVS = OUT / "wavs"; WAVS.mkdir(parents=True, exist_ok=True)
MODEL_ID = "kenpath/svara-tts-v1"
PIN = os.environ.get("MODEL_REVISION", "db8a02fc1e4eab827ff6dda5bed3b56d4d2dd51e")
SR = 24000

# Prefer overlapping 12 + en-IN; attempt remaining 7 if feasible (all 19).
# Voice: {lang}_female / "Language (Female)" — Space uses "Language (Gender): text"
LOCALES = [
    # Overlap 12 with Parler/F5 + Indian English
    ("hi-IN", "Hindi", "hi", "आपकी बैठक कल दोपहर तीन बजे है।", True, "core"),
    ("bn-IN", "Bengali", "bn", "আপনার মিটিং আগামীকাল দুপুর তিনটায়।", True, "core"),
    ("mr-IN", "Marathi", "mr", "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.", True, "core"),
    ("te-IN", "Telugu", "te", "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.", True, "core"),
    ("kn-IN", "Kannada", "kn", "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.", True, "core"),
    ("ta-IN", "Tamil", "ta", "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.", True, "core"),
    ("gu-IN", "Gujarati", "gu", "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.", True, "core"),
    ("ml-IN", "Malayalam", "ml", "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.", True, "core"),
    ("pa-IN", "Punjabi", "pa", "ਤੁਹਾਡੀ ਮੀਟਿੰਗ ਕੱਲ੍ਹ ਦੁਪਹਿਰ ਤਿੰਨ ਵਜੇ ਹੈ।", True, "core"),
    ("as-IN", "Assamese", "as", "আপোনাৰ প্ৰিয়াৰ সৈতে মিটিং কাইলৈ দুপৰীয়া তিনি বজাত।", True, "core"),
    ("en-IN", "English", "en", "Your meeting with Priya is tomorrow at three thirty PM.", True, "core"),
    # Extra official langs (7) — attempt all 19 total with the ones below
    ("bho-IN", "Bhojpuri", "bho", "तोहार मीटिंग कल दोपहर तीन बजे बा।", True, "extra"),
    ("mag-IN", "Magahi", "mag", "तोहर मीटिंग काल दुपहर तीन बजे हई।", True, "extra"),
    ("hne-IN", "Chhattisgarhi", "hne", "तोर मीटिंग काल दोपहर तीन बजे हे।", True, "extra"),
    ("mai-IN", "Maithili", "mai", "अहाँक मीटिंग काल दुपहर तीन बजे अछि।", True, "extra"),
    ("brx-IN", "Bodo", "brx", "नोंथांनि मिटिं गाबोन मानदाननि थायै थिनि बजिआव दं।", True, "extra"),
    ("doi-IN", "Dogri", "doi", "तुंदी मीटिंग कल दोपहर त्रै बजे ऐ।", True, "extra"),
    ("ne-IN", "Nepali", "ne", "तपाईंको मीटिंग भोलि दिउँसो तीन बजे छ।", True, "extra"),
    ("sa-IN", "Sanskrit", "sa", "भवतः बैठकः श्वः मध्याह्ने त्रिवादने अस्ति।", True, "extra"),
]

WHISPER_LANG = {
    "hi-IN":"hi","bn-IN":"bn","mr-IN":"mr","te-IN":"te","kn-IN":"kn","ta-IN":"ta",
    "gu-IN":"gu","ml-IN":"ml","pa-IN":"pa","as-IN":None,"en-IN":"en",
    "bho-IN":"hi","mag-IN":"hi","hne-IN":"hi","mai-IN":"hi","brx-IN":None,
    "doi-IN":"hi","ne-IN":"ne","sa-IN":"sa",
}

def write_text(p: Path, t: str): p.write_text(t, encoding="utf-8")
def sha256_file(p: Path) -> str:
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for c in iter(lambda: f.read(1<<20), b""): h.update(c)
    return h.hexdigest()

def record_versions():
    pkgs=["transformers","torch","torchaudio","snac","soundfile","huggingface_hub","openai-whisper","jiwer","numpy","accelerate","safetensors"]
    versions={}
    for p in pkgs:
        try:
            out=subprocess.check_output([sys.executable,"-m","pip","show",p],text=True,stderr=subprocess.DEVNULL)
            info={}
            for line in out.splitlines():
                if ":" in line:
                    k,v=line.split(":",1); info[k.strip()]=v.strip()
            versions[p]={"version":info.get("Version"),"location":info.get("Location")}
        except Exception as e:
            versions[p]={"version":None,"error":str(e)}
    freeze=subprocess.check_output([sys.executable,"-m","pip","freeze"],text=True)
    versions["pip_freeze_subset"]=[l for l in freeze.splitlines() if any(x.replace("-","_").lower() in l.lower().replace("-","_") for x in pkgs)]
    write_text(OUT/"versions.json", json.dumps(versions,indent=2))
    return versions

def download_and_pin():
    from huggingface_hub import snapshot_download, HfApi
    token=os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    tip=HfApi(token=token).model_info(MODEL_ID).sha
    print(f"tip={tip} pin={PIN}", flush=True)
    path=snapshot_download(MODEL_ID, revision=PIN, token=token, cache_dir="/workspace/hf_cache",
                           local_dir=str(OUT/"model_cache"/"svara"), local_dir_use_symlinks=False)
    write_text(OUT/"model_revision.txt", PIN+"\n"); write_text(OUT/"model_tip_sha.txt", tip+"\n")
    return PIN, path

def process_prompt(tokenizer, language_label, gender, text, device):
    import torch
    prompt=f"{language_label} ({gender}): {text}"
    input_ids=tokenizer(prompt, return_tensors="pt").input_ids
    start=torch.tensor([[128259]], dtype=torch.int64)
    end=torch.tensor([[128009, 128260]], dtype=torch.int64)
    modified=torch.cat([start, input_ids, end], dim=1)
    attn=torch.ones_like(modified)
    return modified.to(device), attn.to(device), prompt

def parse_output(generated_ids):
    import torch
    token_to_find, token_to_remove = 128257, 128258
    token_indices=(generated_ids==token_to_find).nonzero(as_tuple=True)
    cropped=generated_ids[:, token_indices[1][-1]+1:] if len(token_indices[1])>0 else generated_ids
    processed=[row[row!=token_to_remove] for row in cropped]
    row=processed[0]
    trimmed=row[:(row.size(0)//7)*7]
    return [int(t.item())-128266 for t in trimmed]

def redistribute_codes(code_list, snac_model, device):
    import torch
    layer_1, layer_2, layer_3 = [], [], []
    for i in range((len(code_list)+1)//7):
        base=7*i
        layer_1.append(code_list[base+0])
        layer_2.append(code_list[base+1]-4096)
        layer_3.append(code_list[base+2]-(2*4096))
        layer_3.append(code_list[base+3]-(3*4096))
        layer_2.append(code_list[base+4]-(4*4096))
        layer_3.append(code_list[base+5]-(5*4096))
        layer_3.append(code_list[base+6]-(6*4096))
    codes=[torch.tensor(x, device=device).unsqueeze(0) for x in [layer_1, layer_2, layer_3]]
    with torch.inference_mode():
        audio=snac_model.decode(codes).detach().squeeze().cpu().numpy()
    return audio

def synthesize_all(revision, model_path):
    import numpy as np, soundfile as sf, torch
    from snac import SNAC
    from transformers import AutoModelForCausalLM, AutoTokenizer

    device="cuda" if torch.cuda.is_available() else "cpu"
    dtype=(torch.bfloat16 if (device=="cuda" and torch.cuda.is_bf16_supported()) else (torch.float16 if device=="cuda" else torch.float32))
    print(f"Loading SNAC + Svara on {device} dtype={dtype}", flush=True)
    snac=SNAC.from_pretrained("hubertsiuzdak/snac_24khz").to(device)
    tokenizer=AutoTokenizer.from_pretrained(model_path)
    model=AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=dtype).to(device)
    model.eval()

    results=[]
    for locale, lang_label, lang_code, sentence, official, group in LOCALES:
        voice_id=f"{lang_code}_female"
        voice_display=f"{lang_label} (Female)"
        rec={
            "locale":locale,"sentence":sentence,"language_label":lang_label,
            "voice_id":voice_id,"voice_display":voice_display,"gender":"Female",
            "emotion":"neutral (default; no tag)","group":group,
            "officially_supported":official,"supported":official,"experimental":False,
            "success":False,"error":None,"sample_rate":SR,"wav_path":f"wavs/{locale}.wav",
            "streaming_tested":False,
        }
        out_wav=WAVS/f"{locale}.wav"
        print(f"=== Synth {locale} voice={voice_display} ===", flush=True)
        if out_wav.exists() and out_wav.stat().st_size>1000 and os.environ.get("QUAL_FORCE")!="1":
            audio,sr=sf.read(str(out_wav)); audio=np.asarray(audio).reshape(-1)
            peak=float(np.max(np.abs(audio))) if audio.size else 0.0
            if peak>=1e-4:
                dur=float(len(audio)/sr)
                rec.update({"success":True,"audio_duration_s":round(dur,4),"sample_rate":int(sr),
                            "sha256":sha256_file(out_wav),"num_samples":int(len(audio)),
                            "resumed_existing_wav":True,"peak_abs":peak})
                results.append(rec); _dump(revision,device,results); continue
        try:
            ids,attn,prompt=process_prompt(tokenizer, lang_label, "Female", sentence, device)
            rec["prompt_text"]=prompt
            if device=="cuda": torch.cuda.synchronize()
            t0=time.perf_counter()
            with torch.inference_mode():
                gen=model.generate(input_ids=ids, attention_mask=attn, max_new_tokens=2048,
                                   do_sample=True, temperature=0.7, top_p=0.8,
                                   repetition_penalty=1.1, num_return_sequences=1, eos_token_id=128258)
            if device=="cuda": torch.cuda.synchronize()
            t1=time.perf_counter()
            codes=parse_output(gen)
            if not codes: raise RuntimeError("NO_AUDIO_TOKENS")
            audio=redistribute_codes(codes, snac, device)
            audio=np.asarray(audio, dtype=np.float32).reshape(-1)
            peak=float(np.max(np.abs(audio))) if audio.size else 0.0
            if peak<1e-4 or audio.size<SR*0.2: raise RuntimeError(f"SILENCE_OR_TOO_SHORT peak={peak}")
            sf.write(str(out_wav), audio, SR)
            dur=float(len(audio)/SR); synth=float(t1-t0)
            rec.update({"success":True,"total_synthesis_time_s":round(synth,4),"audio_duration_s":round(dur,4),
                        "RTF":round(synth/dur,4) if dur>0 else None,"sha256":sha256_file(out_wav),
                        "num_samples":int(len(audio)),"peak_abs":peak})
            print(f"  OK synth={synth:.3f}s dur={dur:.3f}s RTF={rec['RTF']}", flush=True)
        except Exception as e:
            rec["error"]=f"{type(e).__name__}: {e}"; rec["traceback"]=traceback.format_exc()
            print(f"  FAIL {rec['error']}", flush=True)
        results.append(rec); _dump(revision,device,results)
    del model, snac
    if device=="cuda": torch.cuda.empty_cache()
    return results, device

def _dump(revision, device, results):
    write_text(OUT/"results.json", json.dumps({
        "model_id":MODEL_ID,"revision":revision,
        "voice_policy":"Prefer female: Language (Female) / {lang}_female; emotion default neutral (no tag).",
        "inference_path":"transformers AutoModelForCausalLM + SNAC (HF Space pattern); streaming NOT tested in this pack.",
        "device":device,"results":results}, indent=2, ensure_ascii=False))

def clipping_analysis(results):
    import numpy as np, soundfile as sf
    clips=[]
    for r in results:
        locale=r["locale"]; wav=WAVS/f"{locale}.wav"
        entry={"locale":locale,"peak_dBFS":None,"clipped":False,"clipped_samples":0,"total_samples":0,"error":None}
        if not wav.exists() or not r.get("success"):
            entry["error"]="missing wav or synth failed"; clips.append(entry); continue
        audio,sr=sf.read(str(wav), dtype="float64"); audio=np.asarray(audio).reshape(-1)
        entry["total_samples"]=int(audio.size)
        peak=float(np.max(np.abs(audio))) if audio.size else 0.0
        entry["peak_dBFS"]=float("-inf") if peak<=0 else round(20.0*np.log10(peak),4)
        n=int((np.abs(audio)>=0.999999).sum()); entry["clipped_samples"]=n
        entry["clipped"]=bool(n>0 and entry["peak_dBFS"] is not None and entry["peak_dBFS"]>=-0.001)
        entry["flag_0dBFS_with_clipped_samples"]=bool(entry["peak_dBFS"] is not None and entry["peak_dBFS"]>=-0.001 and n>0)
        clips.append(entry)
    write_text(OUT/"clipping.json", json.dumps({"clipping":clips}, indent=2)); return clips

def normalize_text(s):
    import unicodedata, re
    s=unicodedata.normalize("NFC", s or "").strip().lower()
    s=re.sub(r"[^\w\s]"," ",s,flags=re.UNICODE)
    return re.sub(r"\s+"," ",s).strip()

def compute_wer_cer(ref, hyp):
    from jiwer import cer, wer
    ref_n, hyp_n = normalize_text(ref), normalize_text(hyp)
    if not ref_n: return None,None,ref_n,hyp_n
    if not hyp_n: return 1.0,1.0,ref_n,hyp_n
    try: w=float(wer(ref_n,hyp_n))
    except Exception: w=1.0
    try: c=float(cer(ref_n,hyp_n))
    except Exception: c=1.0
    return w,c,ref_n,hyp_n

def asr_all(results):
    import whisper, torch
    print("Loading Whisper large-v3...", flush=True)
    device="cuda" if torch.cuda.is_available() else "cpu"
    asr=whisper.load_model("large-v3", device=device)
    metrics={"asr_model":"openai-whisper/large-v3","failure_bar":"empty transcript OR WER>=0.9 OR CER>=0.9",
             "asr_notes":"Whisper large-v3; Assamese/Bodo auto-detect.", "results":[]}
    for r in results:
        locale, sentence=r["locale"], r["sentence"]
        wav=WAVS/f"{locale}.wav"
        entry={"locale":locale,"reference":sentence,"transcript":None,"WER":None,"CER":None,"pass":False,
               "error":None,"whisper_language":WHISPER_LANG.get(locale)}
        print(f"=== ASR {locale} ===", flush=True)
        if not wav.exists() or not r.get("success"):
            entry["error"]="missing wav or synth failed"; metrics["results"].append(entry); continue
        try:
            kwargs={"fp16": device=="cuda"}
            lang=WHISPER_LANG.get(locale)
            if lang: kwargs.update({"language":lang,"task":"transcribe"})
            result=asr.transcribe(str(wav), **kwargs)
            transcript=(result.get("text") or "").strip()
            entry["transcript"]=transcript; entry["detected_language"]=result.get("language")
            w,c,ref_n,hyp_n=compute_wer_cer(sentence, transcript)
            entry["WER"]=None if w is None else round(w,4)
            entry["CER"]=None if c is None else round(c,4)
            entry["ref_normalized"]=ref_n; entry["hyp_normalized"]=hyp_n
            empty=not transcript
            fail=empty or (w is not None and w>=0.9) or (c is not None and c>=0.9)
            entry["pass"]=not fail
            entry["failure_reason"]="empty transcript" if empty else ("WER/CER >= 0.9" if fail else None)
            print(f"  WER={entry['WER']} CER={entry['CER']} pass={entry['pass']} :: {transcript[:80]}", flush=True)
        except Exception as e:
            entry["error"]=f"{type(e).__name__}: {e}"; entry["traceback"]=traceback.format_exc()
            print(f"  FAIL {entry['error']}", flush=True)
        metrics["results"].append(entry)
        write_text(OUT/"asr_metrics.json", json.dumps(metrics, indent=2, ensure_ascii=False))
    return metrics

def write_environment(wall, device, revision, versions):
    import torch
    gpu=None
    if torch.cuda.is_available():
        gpu={"name":torch.cuda.get_device_name(0),"capability":list(torch.cuda.get_device_capability(0)),
             "total_memory_gb":round(torch.cuda.get_device_properties(0).total_memory/(1024**3),2)}
    env={"model_id":MODEL_ID,"revision":revision,"device":device,"gpu_vs_cpu":"GPU" if device=="cuda" else "CPU",
         "gpu":gpu,"torch_version":torch.__version__,"cuda_available":torch.cuda.is_available(),
         "total_wall_clock_s":round(time.perf_counter()-wall,2),
         "hostname":subprocess.check_output(["hostname"],text=True).strip(),
         "python":sys.version,"timestamp_utc":datetime.now(timezone.utc).isoformat(),
         "key_versions":{k:(v.get("version") if isinstance(v,dict) else v) for k,v in versions.items() if k!="pip_freeze_subset"},
         "streaming":"NOT tested (batch generate only; OpenAI-compatible /v1/audio/speech stream path not exercised)"}
    write_text(OUT/"environment.json", json.dumps(env, indent=2)); return env

def main():
    wall=time.perf_counter()
    versions=record_versions(); revision, path=download_and_pin()
    results, device=synthesize_all(revision, path)
    clipping_analysis(results); asr_all(results); write_environment(wall, device, revision, versions)
    print("DONE svara qual core", flush=True)

if __name__=="__main__":
    main()
