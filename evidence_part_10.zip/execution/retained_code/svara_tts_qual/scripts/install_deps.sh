#!/bin/bash
set -euo pipefail
export HF_HOME=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-}"
export PIP_CACHE_DIR=/workspace/hf_cache/pip
mkdir -p "$HF_HOME" "$PIP_CACHE_DIR" /workspace/svara_tts_qual/{wavs,scripts}
apt-get update -qq
apt-get install -y -qq libsndfile1 ffmpeg >/dev/null
pip3 install -U pip wheel setuptools
pip3 install -U "transformers>=4.41,<4.50" accelerate huggingface_hub safetensors sentencepiece protobuf
pip3 install -U snac soundfile numpy openai-whisper jiwer librosa
# keep numpy compatible
pip3 install -U "numpy>=1.26,<2.1"
python3 -c "import torch; print(torch.__version__, torch.cuda.is_available(), torch.cuda.get_device_name(0))"
python3 -c "from snac import SNAC; print('SNAC OK')"
echo INSTALL_OK
