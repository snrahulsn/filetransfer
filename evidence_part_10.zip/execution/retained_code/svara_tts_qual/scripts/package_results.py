#!/usr/bin/env python3
"""Package SUMMARY.md, notes.md, SHA256SUMS for a TTS qual pack."""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

OUT = Path(os.environ.get("QUAL_OUT") or os.environ.get("QUAL_OUT") or "/workspace/svara_tts_qual")
IST = ZoneInfo("Asia/Kolkata")
MODEL_LABEL = os.environ.get("MODEL_LABEL", OUT.name)

def ist_stamp():
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def load(name, default=None):
    p = OUT / name
    if not p.exists():
        return default
    if name.endswith(".json"):
        return json.loads(p.read_text(encoding="utf-8"))
    return p.read_text(encoding="utf-8")

def main():
    results = load("results.json", {})
    asr = load("asr_metrics.json", {})
    clip = load("clipping.json", {})
    env = load("environment.json", {})
    revision = (OUT / "model_revision.txt").read_text().strip() if (OUT / "model_revision.txt").exists() else "UNKNOWN"
    pod_id = (OUT / "pod_id.txt").read_text().strip() if (OUT / "pod_id.txt").exists() else "UNKNOWN"
    stamp = ist_stamp()

    rows_src = results.get("results") or results.get("locales") or []
    asr_src = asr.get("results") or asr.get("locales") or []
    clip_src = clip.get("clipping") or clip.get("results") or []
    asr_by = {r.get("locale"): r for r in asr_src}

    synth_ok = sum(1 for r in rows_src if r.get("success") or r.get("ok") or r.get("passed_synth"))
    synth_n = len(rows_src)
    asr_ok = sum(1 for r in asr_src if r.get("pass") or r.get("asr_pass"))
    asr_n = len(asr_src)
    fail_locales = [r.get("locale") for r in asr_src if not (r.get("pass") or r.get("asr_pass"))]
    clip_flags = sum(1 for c in clip_src if c.get("flag_0dBFS_with_clipped_samples") or c.get("flagged_0dBFS"))

    table = []
    for r in rows_src:
        loc = r.get("locale")
        a = asr_by.get(loc, {})
        synth = "OK" if (r.get("success") or r.get("ok")) else "FAIL"
        support = "official" if r.get("officially_supported", r.get("supported", True)) else "experimental"
        table.append(f"| {loc} | {synth} | {a.get('WER')} | {a.get('CER')} | {a.get('pass')} | {support} |")

    streaming = env.get("streaming") or results.get("streaming") or "NOT tested"
    summary = f"""# SUMMARY — {MODEL_LABEL} on-prem qualification

**Status:** COMPLETE  
**Packaged (IST):** {stamp}

## Results at a glance

| Item | Outcome |
|------|---------|
| Model revision | `{revision}` |
| Snapshot download | OK |
| Synth locales | **{synth_ok}/{synth_n}** success |
| ASR WER/CER pass | **{asr_ok}/{asr_n}** (fail: {', '.join(x for x in fail_locales if x) or 'none'}) |
| Clipping 0 dBFS flags | {clip_flags} locales flagged |
| Streaming | {streaming} |
| Pod | `{pod_id}` |
| Volume | `ul08t4z9qx` indic-voice — **retained** |

## Locale table (ASR)

| Locale | Synth | WER | CER | ASR pass | Support |
|--------|-------|-----|-----|----------|---------|
{chr(10).join(table)}

## Deliverables

`results.json`, `wavs/*.wav`, `asr_metrics.json`, `clipping.json`, `versions.json`,
`environment.json`, `model_revision.txt`, `notes.md`, `SHA256SUMS`, `SUMMARY.md`,
`license_check.md`, `scripts/`.

## Paths on box

`{OUT}/`
"""
    (OUT / "SUMMARY.md").write_text(summary, encoding="utf-8")
    notes = f"""# Notes — {MODEL_LABEL} qualification

**Packaged (IST):** {stamp}

## Streaming

{streaming}

## What ran

- Pod: `{pod_id}` (network volume `ul08t4z9qx`, US-IL-1).
- Revision: `{revision}`
- Synth: {synth_ok}/{synth_n}; ASR pass: {asr_ok}/{asr_n}
- Failed ASR locales: {', '.join(x for x in fail_locales if x) or 'none'}
- ASR bar: empty transcript OR WER>=0.9 OR CER>=0.9
- Silence fails loudly.

## Environment

- GPU: {env.get('gpu')}
- torch: {env.get('torch_version')}; device: {env.get('device')}
- Wall clock (qual core): {env.get('total_wall_clock_s')}s

## Caveats

- Network volume retained; pod STOPPED after copy-out (never delete volume).
- See license_check.md for license constraints.
"""
    (OUT / "notes.md").write_text(notes, encoding="utf-8")

    lines = []
    for p in sorted(OUT.rglob("*")):
        if not p.is_file():
            continue
        rel = str(p.relative_to(OUT))
        if rel.startswith(("model_cache/", "model_cache\\", "_", "prompts/.cache", "prompts/_bundle")):
            continue
        if rel.endswith((".log", ".pid", ".pyc")) or "/__pycache__/" in rel or "/.cache/" in rel:
            continue
        if rel in ("orchestrator.log", "install.log", "qual.log", "prepare_refs.log", "setup_cls.log", "vllm_serve.log"):
            continue
        lines.append(f"{sha256_file(p)}  {rel}")
    (OUT / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("PACKAGED", stamp, "synth", f"{synth_ok}/{synth_n}", "asr", f"{asr_ok}/{asr_n}")

if __name__ == "__main__":
    main()
