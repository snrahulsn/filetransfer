#!/usr/bin/env python3
"""Pocket TTS (kyutai + community) streaming TTFA / interrupt / concurrent."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np
import soundfile as sf

OUT = Path(os.environ.get("SUITE_OUT", "/workspace/tts_streaming_suite/pocket_tts"))
SAMPLES = OUT / "samples"
SAMPLES.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json  # noqa

REVS = {
    "kyutai/pocket-tts": "492522650173a0653b7575cdc25ae09810e5d741",
    "prasadvittaldev/pocket-tts-indian-english-male-indictts": "70cd874aa000d03812e2307d937760d3cc3c21a1",
    "saryps-labs/pocket-tts-hindi": "dbaa326069d20bfbdaeb625613736773741a24ea",
}

SPECS = [
    {
        "id": "official_en_alba",
        "label": "Official English alba",
        "model_id": "kyutai/pocket-tts",
        "language": "english",
        "config": None,
        "voice": "alba",
        "text": "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM.",
    },
    {
        "id": "indian_en_male",
        "label": "Community Indian English male",
        "model_id": "prasadvittaldev/pocket-tts-indian-english-male-indictts",
        "language": None,
        "config": "hf://prasadvittaldev/pocket-tts-indian-english-male-indictts/config.yaml@70cd874aa000d03812e2307d937760d3cc3c21a1",
        "voice": "hf://prasadvittaldev/pocket-tts-indian-english-male-indictts/voice_prompt.wav@70cd874aa000d03812e2307d937760d3cc3c21a1",
        "text": "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM.",
    },
    {
        "id": "hindi_saryps",
        "label": "Community Hindi saryps-labs",
        "model_id": "saryps-labs/pocket-tts-hindi",
        "language": None,
        "config": "hf://saryps-labs/pocket-tts-hindi/config.yaml@dbaa326069d20bfbdaeb625613736773741a24ea",
        "voice": "hf://saryps-labs/pocket-tts-hindi/samples/voice_01_f.wav@dbaa326069d20bfbdaeb625613736773741a24ea",
        "text": "नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।",
    },
]

def stream_gen(model, state, text, cancel_after_s=None, max_tokens=80):
    t0 = time.perf_counter()
    ttfa = None
    chunks = []
    cancelled = False
    err = None
    try:
        it = model.generate_audio_stream(model_state=state, text_to_generate=text, max_tokens=max_tokens)
        for a in it:
            now = time.perf_counter()
            a = np.asarray(a, dtype=np.float32).reshape(-1)
            if a.size == 0:
                continue
            if ttfa is None:
                ttfa = now - t0
            chunks.append(a.copy())
            if cancel_after_s is not None and (now - t0) >= cancel_after_s:
                cancelled = True
                try:
                    it.close()
                except Exception:
                    pass
                break
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-500:]}"
    total = time.perf_counter() - t0
    audio = np.concatenate(chunks) if chunks else np.zeros(0, dtype=np.float32)
    sr = getattr(model, "sample_rate", 24000) or 24000
    dur = float(len(audio) / sr) if len(audio) else 0.0
    return {
        "ok": err is None and (len(audio) > 0 or cancelled),
        "error": err,
        "cancelled": cancelled,
        "ttfa_s": ttfa,
        "total_s": total,
        "n_chunks": len(chunks),
        "chunk_samples": [int(len(c)) for c in chunks],
        "audio_duration_s": dur,
        "sample_rate": sr,
        "rtf": (total / dur) if dur > 0 else None,
        "streaming": True,
        "stream_kind": "TTSModel.generate_audio_stream",
        "audio": audio,
    }

def load_spec(spec):
    from pocket_tts import TTSModel
    kwargs = {"quantize": True}
    if spec.get("config"):
        kwargs["config"] = spec["config"]
        # community packs often need model weights from config
    elif spec.get("language"):
        kwargs["language"] = spec["language"]
    # pin revision via env if possible
    model = TTSModel.load_model(**kwargs)
    voice = spec["voice"]
    if isinstance(voice, str) and voice.startswith("hf://"):
        state = model.get_state_for_audio_prompt(voice)
    else:
        state = model.get_state_for_voice(voice) if hasattr(model, "get_state_for_voice") else model.get_state_for_audio_prompt(voice)
    return model, state

def main():
    import torch, pocket_tts
    device = "cuda" if torch.cuda.is_available() else "cpu"
    results = {
        "device": device,
        "pocket_tts_version": getattr(pocket_tts, "__version__", "unknown"),
        "streaming": True,
        "revisions_pinned": REVS,
        "voices": {},
        "probes": {},
    }
    print(f"device={device} pocket_tts={results['pocket_tts_version']}", flush=True)

    primary = None
    for spec in SPECS:
        sid = spec["id"]
        print(f"=== {sid} ===", flush=True)
        try:
            model, state = load_spec(spec)
            # warmup
            _ = stream_gen(model, state, "Warm up.", max_tokens=20)
            ttfas = []
            last = None
            for i in range(5):
                r = stream_gen(model, state, spec["text"])
                ttfas.append(r["ttfa_s"])
                last = r
                print(f"  run{i} ttfa={r['ttfa_s']*1000:.1f}ms chunks={r['n_chunks']}", flush=True)
            audio = last.pop("audio")
            sf.write(str(SAMPLES / f"{sid}_stream.wav"), audio, last["sample_rate"])
            rec = {**{k:v for k,v in last.items()}, "ttfa_summary": summarize_ttfas(ttfas), "spec": {k:v for k,v in spec.items() if k!='text'}, "text": spec["text"]}
            results["probes"][f"stream_{sid}"] = rec
            if primary is None:
                primary = (model, state, spec)
                results["ttfa_p50_s"] = summarize_ttfas(ttfas)["p50"]
                results["primary_voice"] = sid
        except Exception as e:
            results["probes"][f"stream_{sid}"] = {"ok": False, "error": f"{type(e).__name__}: {e}", "spec_id": sid}
            traceback.print_exc()

    if primary is None:
        raise RuntimeError("No pocket voice loaded successfully")
    model, state, spec = primary

    # cancel
    long_text = (spec["text"] + " ") * 3
    r = stream_gen(model, state, long_text, cancel_after_s=0.08, max_tokens=200)
    audio = r.pop("audio")
    if len(audio):
        sf.write(str(SAMPLES / "cancel.wav"), audio, r["sample_rate"])
    results["probes"]["cancel"] = r
    results["cancel_behavior"] = (
        f"closed generate_audio_stream after {0.08}s; chunks={r.get('n_chunks')} cancelled={r.get('cancelled')}"
    )

    def one(_i):
        rr = stream_gen(model, state, spec["text"])
        rr.pop("audio", None)
        return rr

    for n in (2, 4):
        t0 = time.perf_counter()
        outs = []
        with ThreadPoolExecutor(max_workers=n) as ex:
            for f in as_completed([ex.submit(one, i) for i in range(n)]):
                outs.append(f.result())
        wall = time.perf_counter() - t0
        ttfas = [o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"] = {
            "n": n, "wall_s": wall, "ok": sum(1 for o in outs if o.get("ok")),
            "ttfa_summary": summarize_ttfas(ttfas), "results": outs,
        }
        print(f"concurrent N={n} wall={wall:.3f} ok={sum(1 for o in outs if o.get('ok'))}/{n}", flush=True)

    write_json(OUT / "results.json", results)
    write_json(OUT / "config.json", {
        "models": REVS,
        "dtype": "int8/quantize=True",
        "device": device,
        "cmd": "TTSModel.load_model(...); generate_audio_stream(model_state, text)",
        "streaming": True,
        "sample_rate_hz": 24000,
        "pocket_tts_version": results["pocket_tts_version"],
    })
    p50 = results.get("ttfa_p50_s")
    cancel = results["probes"]["cancel"]
    n2 = results["probes"]["concurrent_n2"]["ttfa_summary"]
    n4 = results["probes"]["concurrent_n4"]["ttfa_summary"]
    (OUT / "SUMMARY.md").write_text(f"""# Pocket TTS streaming probe

**Status:** SUCCESS  
**Primary:** `{results.get('primary_voice')}` · device=`{device}` · streaming=`true`  
**API:** `TTSModel.generate_audio_stream`

## Key TTFA

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| primary stream | {p50} | 5-run p50 |
| cancel | {cancel.get('ttfa_s')} | cancelled={cancel.get('cancelled')} chunks={cancel.get('n_chunks')} |
| concurrent N=2 | mean {n2.get('mean')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} | ok={results['probes']['concurrent_n4']['ok']}/4 |

Community voices also probed where load succeeded — see results.json.
""", encoding="utf-8")
    print("WROTE", OUT / "results.json")

if __name__ == "__main__":
    main()
