# Pocket TTS streaming probe

**Status:** SUCCESS  
**Primary:** `official_en_alba` · device=`cuda` · streaming=`true`  
**API:** `TTSModel.generate_audio_stream`

## Key TTFA

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| primary stream | 0.0777431579772383 | 5-run p50 |
| cancel | 0.15751280495896935 | cancelled=True chunks=1 |
| concurrent N=2 | mean 0.11284598795464262 | ok=2/2 |
| concurrent N=4 | mean 0.1834569592610933 | ok=4/4 |

Community voices also probed where load succeeded — see results.json.
