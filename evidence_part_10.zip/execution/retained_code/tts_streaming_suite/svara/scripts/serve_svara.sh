#!/usr/bin/env bash
# Serve Kenpath/svara-tts-inference OpenAI API (no Docker — pip + uvicorn)
set -euo pipefail
ROOT=/workspace/svara_stream_work
REPO=$ROOT/svara-tts-inference
source "$ROOT/venv/bin/activate"
export HF_HUB_CACHE=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-${HUGGING_FACE_HUB_TOKEN:-}}"
export VLLM_MODEL="${VLLM_MODEL:-/workspace/svara_tts_qual/model_cache/svara}"
# fall back to hub id if local missing
if [ ! -d "$VLLM_MODEL" ]; then
  export VLLM_MODEL=kenpath/svara-tts-v1
fi
export VLLM_GPU_MEMORY_UTILIZATION="${VLLM_GPU_MEMORY_UTILIZATION:-0.85}"
export VLLM_MAX_MODEL_LEN="${VLLM_MAX_MODEL_LEN:-4096}"
export VLLM_DTYPE="${VLLM_DTYPE:-bfloat16}"
export SNAC_DEVICE="${SNAC_DEVICE:-cuda}"
export API_HOST=0.0.0.0
export API_PORT=8080
cd "$REPO/api"
exec python server.py
