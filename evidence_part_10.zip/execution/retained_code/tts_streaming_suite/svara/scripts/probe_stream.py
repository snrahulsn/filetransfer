#!/usr/bin/env python3
"""Probe Svara OpenAI-compatible POST /v1/audio/speech with stream:true."""
from __future__ import annotations
import argparse, concurrent.futures, json, os, struct, time, wave
from pathlib import Path
from typing import Any

import requests

SR = 24000

TEXTS = {
    "hi": "नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।",
    "en": "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM.",
}

VOICES = {
    "hi": "hi_female",
    "en": "en_female",
}


def pcm16_duration_s(n_bytes: int, sr: int = SR) -> float:
    return (n_bytes / 2) / float(sr)


def write_wav(path: Path, pcm: bytes, sr: int = SR):
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm)


def stream_speech(base: str, text: str, voice: str, fmt: str = "pcm",
                  stream: bool = True, timeout: float = 300.0,
                  cancel_after_s: float | None = None,
                  out_path: Path | None = None) -> dict[str, Any]:
    url = base.rstrip("/") + "/v1/audio/speech"
    payload = {
        "model": "svara-tts-v1",
        "input": text,
        "voice": voice,
        "response_format": fmt,
        "stream": stream,
    }
    t0 = time.perf_counter()
    ttfa = None
    chunks = []
    n_chunks = 0
    first_status = None
    headers_out = {}
    err = None
    cancelled = False
    try:
        with requests.post(url, json=payload, stream=True, timeout=timeout) as r:
            first_status = r.status_code
            headers_out = {k: v for k, v in r.headers.items()}
            if r.status_code >= 400:
                body = r.content[:2000]
                try:
                    body_txt = body.decode("utf-8", errors="replace")
                except Exception:
                    body_txt = repr(body)
                return {
                    "ok": False,
                    "status": r.status_code,
                    "error_body": body_txt,
                    "headers": headers_out,
                    "ttfa_s": None,
                    "total_s": time.perf_counter() - t0,
                }
            for chunk in r.iter_content(chunk_size=4096):
                if not chunk:
                    continue
                now = time.perf_counter()
                if ttfa is None:
                    ttfa = now - t0
                chunks.append(chunk)
                n_chunks += 1
                if cancel_after_s is not None and (now - t0) >= cancel_after_s:
                    cancelled = True
                    break
    except requests.RequestException as e:
        err = f"{type(e).__name__}: {e}"
    total = time.perf_counter() - t0
    audio = b"".join(chunks)
    # If wav/mp3, duration harder; for pcm use bytes
    dur = None
    if fmt == "pcm" and audio:
        dur = pcm16_duration_s(len(audio))
    elif fmt == "wav" and len(audio) > 44:
        # strip header approx
        dur = pcm16_duration_s(len(audio) - 44)
    rtf = (total / dur) if dur and dur > 0 else None
    if out_path is not None and audio:
        if fmt == "pcm":
            write_wav(out_path.with_suffix(".wav"), audio)
            out_path.with_suffix(".pcm").write_bytes(audio)
        else:
            out_path.write_bytes(audio)
    return {
        "ok": first_status == 200 and err is None and (len(audio) > 0 or cancelled),
        "status": first_status,
        "error": err,
        "cancelled": cancelled,
        "ttfa_s": ttfa,
        "total_s": total,
        "n_chunks": n_chunks,
        "audio_bytes": len(audio),
        "audio_duration_s": dur,
        "rtf": rtf,
        "headers": headers_out,
        "voice": voice,
        "format": fmt,
        "stream": stream,
        "text_chars": len(text),
    }


def concurrent_probe(base: str, n: int, lang: str = "en") -> dict[str, Any]:
    text = TEXTS[lang]
    voice = VOICES[lang]
    t0 = time.perf_counter()
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=n) as ex:
        futs = [ex.submit(stream_speech, base, text, voice, "pcm", True) for _ in range(n)]
        for f in concurrent.futures.as_completed(futs):
            results.append(f.result())
    wall = time.perf_counter() - t0
    ok = sum(1 for r in results if r.get("ok"))
    ttfas = [r["ttfa_s"] for r in results if r.get("ttfa_s") is not None]
    return {
        "n": n,
        "lang": lang,
        "wall_s": wall,
        "ok": ok,
        "ttfa_s_list": ttfas,
        "ttfa_s_mean": (sum(ttfas) / len(ttfas)) if ttfas else None,
        "ttfa_s_max": max(ttfas) if ttfas else None,
        "results": results,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=os.environ.get("SVARA_BASE", "http://127.0.0.1:8080"))
    ap.add_argument("--out", default="/workspace/svara_stream_probe")
    args = ap.parse_args()
    out = Path(args.out)
    samples = out / "samples"
    samples.mkdir(parents=True, exist_ok=True)

    results: dict[str, Any] = {"base": args.base, "probes": {}}

    # health / voices
    for path in ["/health", "/v1/voices"]:
        try:
            r = requests.get(args.base.rstrip("/") + path, timeout=30)
            results[path] = {"status": r.status_code, "body": r.text[:2000]}
        except Exception as e:
            results[path] = {"error": str(e)}

    # stream probes hi + en
    for lang in ["hi", "en"]:
        key = f"stream_{lang}"
        results["probes"][key] = stream_speech(
            args.base, TEXTS[lang], VOICES[lang], fmt="pcm", stream=True,
            out_path=samples / f"{lang}_stream.pcm",
        )
        # non-stream control
        results["probes"][f"nostream_{lang}"] = stream_speech(
            args.base, TEXTS[lang], VOICES[lang], fmt="pcm", stream=False,
            out_path=samples / f"{lang}_nostream.pcm",
        )

    # mid-utterance cancel
    results["probes"]["cancel_en"] = stream_speech(
        args.base, TEXTS["en"] + " " + TEXTS["en"], VOICES["en"], fmt="pcm",
        stream=True, cancel_after_s=0.5,
        out_path=samples / "en_cancel.pcm",
    )

    # concurrent
    results["probes"]["concurrent_n2"] = concurrent_probe(args.base, 2, "en")
    results["probes"]["concurrent_n4"] = concurrent_probe(args.base, 4, "en")

    (out / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({k: (v if k != "probes" else {pk: {kk: vv for kk, vv in pv.items() if kk != "headers"} for pk, pv in v.items()}) for k, v in results.items()}, indent=2)[:4000])
    print("WROTE", out / "results.json")


if __name__ == "__main__":
    main()
