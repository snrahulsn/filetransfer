# Svara-TTS OpenAI `/v1/audio/speech` stream probe

**Packaged:** 2026-09-18 10:37:21 IST  
**Status:** SUCCESS — stream:true endpoint available and measured  
**Pod:** `i1ft2jagjtvn0k` (RTX 6000 Ada, US-IL-1)  
**Volume:** `ul08t4z9qx` — **retained** (never deleted)  
**Model:** `kenpath/svara-tts-v1` @ `db8a02fc1e4eab827ff6dda5bed3b56d4d2dd51e` (local cache `/workspace/svara_tts_qual/model_cache/svara`)  
**Inference repo:** Kenpath/svara-tts-inference @ `4947c203f2c14ec7bbe0e7968e59c138c3eddfae`  
**Serve:** pip + `python api/server.py` (Docker unavailable on pod image)  
**dtype:** bfloat16 · **SNAC_DEVICE:** cuda · **FlashInfer sampler:** disabled (nvcc JIT incompatible)

## Key TTFA (time to first audio byte)

| Probe | TTFA (s) | Total (s) | Audio dur (s) | RTF | Notes |
|-------|---------:|----------:|--------------:|----:|-------|
| stream hi (`hi_female`) | 0.9264 | 4.129 | 4.181 | 0.987 | PCM stream |
| stream en (`en_female`) | 0.9350 | 5.319 | 5.717 | 0.930 | PCM stream |
| cancel mid-utterance en | 0.8948 | 0.895 | 0.085 | — | disconnect after ~0.5s; `1` chunk(s) received |
| concurrent N=2 | mean 0.9451 / max 0.9471 | wall 5.567 | — | — | ok=2/2 |
| concurrent N=4 | mean 1.0856 / max 1.1612 | wall 5.360 | — | — | ok=4/4 |

Non-stream control TTFA≈total (buffered): hi `5.545s`, en `5.047s`.

## Serve config (exact)

See `config.json`. Highlights:
- `VLLM_MODEL=/workspace/svara_tts_qual/model_cache/svara`
- `VLLM_DTYPE=bfloat16`, `VLLM_ENFORCE_EAGER=true`, `VLLM_ATTENTION_BACKEND=FLASH_ATTN`
- `VLLM_USE_FLASHINFER_SAMPLER=0` (required: flashinfer JIT failed with `nvcc fatal: Unknown option '--compress-mode=size'`)
- `SNAC_DEVICE=cuda`, port `8080`
- Official docker-compose path documented but not used (no `docker` on RunPod pytorch image)

## Files

- `scripts/probe_stream.py`, `scripts/serve_svara.sh`
- `results.json`, `config.json`, `SUMMARY.md`
- `samples/*.wav` (+ `.pcm`)
- `logs/server_log_excerpt.txt`
