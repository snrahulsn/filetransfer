"""Shared TTFA / cancel / concurrent helpers for TTS streaming suite."""
from __future__ import annotations
import json, statistics, time, traceback
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

def percentile(xs: list[float], p: float) -> Optional[float]:
    if not xs:
        return None
    xs = sorted(xs)
    if len(xs) == 1:
        return xs[0]
    k = (len(xs) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(xs) - 1)
    if f == c:
        return xs[f]
    return xs[f] + (xs[c] - xs[f]) * (k - f)

def summarize_ttfas(ttfas: list[float]) -> dict:
    ttfas = [t for t in ttfas if t is not None]
    if not ttfas:
        return {"n": 0, "p50": None, "p90": None, "mean": None, "min": None, "max": None, "values": []}
    return {
        "n": len(ttfas),
        "p50": percentile(ttfas, 50),
        "p90": percentile(ttfas, 90),
        "mean": sum(ttfas) / len(ttfas),
        "min": min(ttfas),
        "max": max(ttfas),
        "values": ttfas,
    }

def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
