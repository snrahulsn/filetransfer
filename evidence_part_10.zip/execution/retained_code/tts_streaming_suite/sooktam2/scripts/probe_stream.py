#!/usr/bin/env python3
"""Sooktam-2 streaming probe. Model has no true stream API — measure TTFA≈time-to-first-sample after decode / wall-to-WAV; interrupt via thread cancel if possible; concurrent N=2/4 separate processes."""
from __future__ import annotations
import json, os, sys, time, traceback, multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np

# Prefer model-bundled f5_tts (has hf_auto) over PyPI f5-tts
for _src in [
    Path("/workspace/sooktam2_qual/model_cache/sooktam2/src"),
    Path("/workspace/sooktam2_qual/model_cache/sooktam2_src/src"),
]:
    if (_src / "f5_tts" / "hf_auto.py").exists():
        sys.path.insert(0, str(_src))
        break
import soundfile as sf

OUT = Path(os.environ.get("SUITE_OUT", "/workspace/tts_streaming_suite/sooktam2"))
SAMPLES = OUT / "samples"
SAMPLES.mkdir(parents=True, exist_ok=True)
MODEL_ID = "bharatgenai/sooktam2"
PIN = os.environ.get("MODEL_REVISION", "eb270c0ceebd58e0e513820eb71c637e9f486a7b")
TEXT_HI = "नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।"
TEXT_EN = "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM."
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json  # noqa

_G = {}

def _resolve_model_path():
    cands = [
        Path("/workspace/sooktam2_qual/model_cache/sooktam2"),
        Path("/workspace/tts_streaming_suite/sooktam2/model_cache"),
    ]
    for c in cands:
        if c.exists() and any(c.iterdir()):
            return str(c)
    from huggingface_hub import snapshot_download
    return snapshot_download(MODEL_ID, revision=PIN, cache_dir=os.environ.get("HF_HUB_CACHE", "/workspace/hf_cache"),
                             local_dir=str(OUT / "model_cache"), local_dir_use_symlinks=False)

def _find_ref():
    prompts = Path("/workspace/sooktam2_qual/prompts")
    # Per-locale ref files from qual
    for key in ("hi-IN", "en-IN", "bn-IN"):
        wav = prompts / f"{key}_ref.wav"
        js = prompts / f"{key}_ref.json"
        if wav.exists():
            txt = ""
            if js.exists():
                try:
                    meta = json.loads(js.read_text(encoding="utf-8"))
                    txt = meta.get("text") or meta.get("transcript") or meta.get("ref_text") or ""
                except Exception:
                    txt = ""
            return str(wav), txt
    catalog = prompts / "refs_catalog.json"
    if catalog.exists():
        refs = json.loads(catalog.read_text(encoding="utf-8"))
        for key in ("hi-IN", "hi", "en-IN", "en"):
            if key in refs and isinstance(refs[key], dict):
                r = refs[key]
                wav = r.get("wav") or r.get("path") or r.get("ref_wav")
                txt = r.get("text") or r.get("transcript") or r.get("ref_text") or ""
                if wav and Path(wav).exists():
                    return wav, txt
    bundled = prompts / "bundled_ref.wav"
    if bundled.exists():
        return str(bundled), ""
    for p in Path("/workspace/sooktam2_qual").rglob("*ref*.wav"):
        return str(p), ""
    raise FileNotFoundError("No sooktam ref wav found")

def load_model():
    import torch
    from transformers import AutoModel
    path = _resolve_model_path()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = AutoModel.from_pretrained(path, trust_remote_code=True, token=os.environ.get("HF_TOKEN"))
    model = model.to(device)
    model.eval()
    ref_wav, ref_text = _find_ref()
    _G.update(model=model, device=device, path=path, ref_wav=ref_wav, ref_text=ref_text)
    return device, path

def infer_once(text: str, lang: str = "hindi"):
    import torch
    model = _G["model"]
    device = _G["device"]
    ref_wav, ref_text = _G["ref_wav"], _G["ref_text"]
    t0 = time.perf_counter()
    ttfa = None
    err = None
    audio = None
    sr = 24000
    out_wav = SAMPLES / f"_tmp_{os.getpid()}_{int(t0*1000)}.wav"
    try:
        if device == "cuda":
            torch.cuda.synchronize()
        with torch.no_grad():
            out = model.infer(
                ref_file=str(ref_wav),
                ref_text=ref_text,
                gen_text=text,
                tokenizer="cls",
                cls_language=lang,
                file_wave=str(out_wav),
            )
        if device == "cuda":
            torch.cuda.synchronize()
        # Prefer reading written wav (authoritative)
        if out_wav.exists():
            audio, sr = sf.read(str(out_wav))
            audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        elif isinstance(out, (tuple, list)) and len(out) >= 1:
            wav = out[0]
            sr = int(out[1]) if len(out) > 1 else sr
            if hasattr(wav, "detach"):
                wav = wav.detach().float().cpu().numpy()
            audio = np.asarray(wav, dtype=np.float32).reshape(-1)
            if audio.size and float(np.max(np.abs(audio))) > 1.5:
                audio = audio / 32768.0
        else:
            audio = np.zeros(0, dtype=np.float32)
        # No true streaming: TTFA = wall to complete WAV
        ttfa = time.perf_counter() - t0
    except Exception as e:
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"
        audio = np.zeros(0, dtype=np.float32)
    total = time.perf_counter() - t0
    if audio is None:
        audio = np.zeros(0, dtype=np.float32)
    dur = float(len(audio) / sr) if len(audio) else 0.0
    try:
        if out_wav.exists():
            out_wav.unlink()
    except Exception:
        pass
    return {
        "ok": err is None and len(audio) > 0,
        "error": err,
        "cancelled": False,
        "ttfa_s": ttfa if ttfa is not None else total,
        "total_s": total,
        "n_chunks": 1 if len(audio) else 0,
        "audio_duration_s": dur,
        "sample_rate": sr,
        "rtf": (total / dur) if dur > 0 else None,
        "streaming": False,
        "stream_kind": "full_utterance_infer",
        "audio": audio,
        "lang": lang,
        "text": text,
    }

def _proc_worker(text, pin, q):
    os.environ["MODEL_REVISION"] = pin
    try:
        load_model()
        r = infer_once(text)
        r.pop("audio", None)
        q.put(r)
    except Exception as e:
        q.put({"ok": False, "error": f"{type(e).__name__}: {e}", "ttfa_s": None})

def main():
    import torch
    device, path = load_model()
    results = {
        "model_id": MODEL_ID,
        "revision": PIN,
        "model_path": path,
        "device": device,
        "dtype": str(next(_G["model"].parameters()).dtype) if hasattr(_G["model"], "parameters") else "unknown",
        "streaming": False,
        "ref_wav": _G["ref_wav"],
        "probes": {},
    }
    print(f"sooktam device={device} path={path} ref={_G['ref_wav']}", flush=True)
    # warmup
    _ = infer_once("Warm up.", "hindi")
    ttfas = []
    last = None
    for i in range(5):
        r = infer_once(TEXT_HI, "hindi")
        ttfas.append(r["ttfa_s"])
        last = r
        print(f"hi run{i} ttfa={r['ttfa_s']:.3f}s dur={r['audio_duration_s']:.3f}", flush=True)
    audio = last.pop("audio")
    sf.write(str(SAMPLES / "hi_full.wav"), audio, last["sample_rate"])
    results["probes"]["stream_hi"] = {**last, "ttfa_summary": summarize_ttfas(ttfas)}
    results["ttfa_p50_s"] = summarize_ttfas(ttfas)["p50"]

    r = infer_once(TEXT_EN, "english")
    audio = r.pop("audio")
    if len(audio):
        sf.write(str(SAMPLES / "en_full.wav"), audio, r["sample_rate"])
    results["probes"]["stream_en"] = r

    # interrupt: attempt to kill a worker thread mid-infer (best-effort; model may not be cancellable)
    import threading
    cancel_rec = {"cancelled": False, "ttfa_s": None, "total_s": None, "ok": False, "note": ""}
    holder = {}
    def target():
        holder["r"] = infer_once(TEXT_HI + " " + TEXT_HI, "hindi")
    th = threading.Thread(target=target, daemon=True)
    t0 = time.perf_counter()
    th.start()
    time.sleep(0.5)
    # Cannot truly cancel CUDA kernel; document honest behavior
    th.join(timeout=120)
    cancel_rec["total_s"] = time.perf_counter() - t0
    if "r" in holder:
        rr = holder["r"]
        audio = rr.pop("audio", np.zeros(0))
        if len(audio):
            sf.write(str(SAMPLES / "hi_cancel_attempt.wav"), audio, rr.get("sample_rate", 24000))
        cancel_rec.update({k: rr.get(k) for k in ("ok", "ttfa_s", "total_s", "error")})
        cancel_rec["cancelled"] = False
        cancel_rec["note"] = "No cancellable generate API; mid-utterance interrupt NOT supported — full infer completed. Marked streaming=false."
    else:
        cancel_rec["note"] = "Thread still running after timeout; force-abandon (process-level)."
        cancel_rec["cancelled"] = True
    results["probes"]["cancel"] = cancel_rec
    results["cancel_behavior"] = cancel_rec["note"]

    # concurrent via threads (shared model)
    def one(text):
        rr = infer_once(text, "hindi")
        rr.pop("audio", None)
        return rr
    for n in (2, 4):
        t0 = time.perf_counter()
        outs = []
        with ThreadPoolExecutor(max_workers=n) as ex:
            for f in as_completed([ex.submit(one, TEXT_HI) for _ in range(n)]):
                outs.append(f.result())
        wall = time.perf_counter() - t0
        ttfas = [o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"] = {
            "n": n, "wall_s": wall, "ok": sum(1 for o in outs if o.get("ok")),
            "ttfa_summary": summarize_ttfas(ttfas), "results": outs,
            "executor": "ThreadPoolExecutor shared model",
        }
        print(f"concurrent N={n} wall={wall:.3f} ok={sum(1 for o in outs if o.get('ok'))}/{n}", flush=True)

    write_json(OUT / "results.json", results)
    write_json(OUT / "config.json", {
        "model_id": MODEL_ID,
        "model_revision": PIN,
        "model_path": path,
        "dtype": results["dtype"],
        "device": device,
        "cmd": "AutoModel.from_pretrained(...).infer(text, ref_audio, ref_text)",
        "streaming": False,
        "sample_rate_hz": 24000,
        "ref_wav": _G["ref_wav"],
    })
    p50 = results["ttfa_p50_s"]
    n2 = results["probes"]["concurrent_n2"]["ttfa_summary"]
    n4 = results["probes"]["concurrent_n4"]["ttfa_summary"]
    (OUT / "SUMMARY.md").write_text(f"""# Sooktam-2 streaming probe

**Status:** SUCCESS (streaming=false)  
**Model:** `{MODEL_ID}` @ `{PIN}`  
**Device:** `{device}`

## Key TTFA

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| full hi | {p50} | TTFA≈wall-to-complete WAV (no stream API) |
| cancel | n/a | {results['cancel_behavior']} |
| concurrent N=2 | mean {n2.get('mean')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} | ok={results['probes']['concurrent_n4']['ok']}/4 |
""", encoding="utf-8")
    print("WROTE", OUT / "results.json")

if __name__ == "__main__":
    main()
