# Sooktam-2 streaming probe

**Status:** SUCCESS (streaming=false)  
**Model:** `bharatgenai/sooktam2` @ `eb270c0ceebd58e0e513820eb71c637e9f486a7b`  
**Device:** `cuda`

## Key TTFA

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| full hi | 2.0784658120246604 | TTFA≈wall-to-complete WAV (no stream API) |
| cancel | n/a | No cancellable generate API; mid-utterance interrupt NOT supported — full infer completed. Marked streaming=false. |
| concurrent N=2 | mean 4.557571470562834 | ok=2/2 |
| concurrent N=4 | mean 9.260130232520169 | ok=4/4 |
