# Kokoro streaming probe

**Status:** SUCCESS  
**Model:** `hexgrad/Kokoro-82M` @ `f3ff3571791e39611d31c381e3a41a3af07b4987`  
**Device:** `cuda` · streaming=`true` (KPipeline generator)  
**kokoro:** 0.9.4

## Key TTFA

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| stream en | 0.0460 | 5-run p50; first generator audio chunk |
| cancel en | 0.12459633697289973 | cancelled=False chunks=1 |
| concurrent N=2 | mean 0.10730247100582346 / max 0.10812144400551915 | ok=2/2 |
| concurrent N=4 | mean 0.19262097476166673 / max 0.19621363596525043 | ok=4/4 |

See `results.json`, `config.json`, `samples/`, `scripts/probe_stream.py`.
