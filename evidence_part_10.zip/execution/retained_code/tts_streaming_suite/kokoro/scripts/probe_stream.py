#!/usr/bin/env python3
"""Kokoro (hexgrad/Kokoro-82M) streaming TTFA / cancel / concurrent probe."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np
import soundfile as sf

OUT = Path(os.environ.get("SUITE_OUT", "/workspace/tts_streaming_suite/kokoro"))
SAMPLES = OUT / "samples"
SAMPLES.mkdir(parents=True, exist_ok=True)
SR = 24000
MODEL_ID = "hexgrad/Kokoro-82M"
# Pin from hf cache if available
PIN = os.environ.get("MODEL_REVISION", "")
TEXT_EN = "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM."
TEXT_HI = "नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।"
VOICE_EN = "af_heart"
VOICE_HI = "hf_alpha"

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json  # noqa

def load_pipeline(lang_code: str, device: str):
    from kokoro import KPipeline
    return KPipeline(lang_code=lang_code, device=device)

def stream_once(pipeline, text: str, voice: str, cancel_after_s: float | None = None):
    t0 = time.perf_counter()
    ttfa = None
    chunks = []
    cancelled = False
    n = 0
    err = None
    try:
        gen = pipeline(text, voice=voice, speed=1.0)
        for item in gen:
            now = time.perf_counter()
            # KPipeline yields Result or (gs, ps, audio) depending on version
            audio = None
            if hasattr(item, "output") and item.output is not None:
                audio = item.output.audio
            elif isinstance(item, (tuple, list)) and len(item) >= 3:
                audio = item[2]
            if audio is None:
                continue
            if hasattr(audio, "detach"):
                audio = audio.detach().cpu().numpy()
            audio = np.asarray(audio, dtype=np.float32).reshape(-1)
            if audio.size == 0:
                continue
            if ttfa is None:
                ttfa = now - t0
            chunks.append(audio)
            n += 1
            if cancel_after_s is not None and (now - t0) >= cancel_after_s:
                cancelled = True
                # close generator early
                try:
                    gen.close()
                except Exception:
                    pass
                break
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
    total = time.perf_counter() - t0
    audio = np.concatenate(chunks) if chunks else np.zeros(0, dtype=np.float32)
    dur = float(len(audio) / SR) if len(audio) else 0.0
    return {
        "ok": err is None and (len(audio) > 0 or cancelled),
        "error": err,
        "cancelled": cancelled,
        "ttfa_s": ttfa,
        "total_s": total,
        "n_chunks": n,
        "audio_samples": int(len(audio)),
        "audio_duration_s": dur,
        "rtf": (total / dur) if dur > 0 else None,
        "streaming": True,
        "stream_kind": "KPipeline_generator_per_segment",
        "audio": audio,
    }

def main():
    import torch, kokoro
    device = "cuda" if torch.cuda.is_available() else "cpu"
    # resolve revision from cache tip file or hub
    revision = PIN
    try:
        from huggingface_hub import HfApi
        tip = HfApi(token=os.environ.get("HF_TOKEN")).model_info(MODEL_ID).sha
        if not revision:
            # try local snapshot
            cache = Path(os.environ.get("HF_HUB_CACHE", "/workspace/hf_cache"))
            snaps = list(cache.glob("models--hexgrad--Kokoro-82M/snapshots/*"))
            revision = snaps[0].name if snaps else tip
    except Exception as e:
        tip = None
        if not revision:
            revision = "unknown"
        print("rev lookup warn:", e)

    results = {
        "model_id": MODEL_ID,
        "revision": revision,
        "dtype": "fp32" if device == "cpu" else "fp32",
        "device": device,
        "kokoro_version": getattr(kokoro, "__version__", "unknown"),
        "streaming": True,
        "probes": {},
    }
    print(f"device={device} rev={revision} kokoro={results['kokoro_version']}", flush=True)

    pipe_en = load_pipeline("a", device)
    # warm-up (excluded from TTFA)
    _ = stream_once(pipe_en, "Warm up.", VOICE_EN)
    print("warmup done", flush=True)

    # repeated TTFA for p50
    ttfas = []
    last = None
    for i in range(5):
        r = stream_once(pipe_en, TEXT_EN, VOICE_EN)
        ttfas.append(r["ttfa_s"])
        last = r
        print(f"en run{i} ttfa={r['ttfa_s']:.4f}s chunks={r['n_chunks']} dur={r['audio_duration_s']:.3f}", flush=True)
    audio = last.pop("audio")
    sf.write(str(SAMPLES / "en_stream.wav"), audio, SR)
    results["probes"]["stream_en"] = {**last, "ttfa_summary": summarize_ttfas(ttfas)}
    results["ttfa_p50_s"] = summarize_ttfas(ttfas)["p50"]

    # Hindi if possible
    try:
        pipe_hi = load_pipeline("h", device)
        r = stream_once(pipe_hi, TEXT_HI, VOICE_HI)
        audio = r.pop("audio")
        if len(audio):
            sf.write(str(SAMPLES / "hi_stream.wav"), audio, SR)
        results["probes"]["stream_hi"] = r
    except Exception as e:
        results["probes"]["stream_hi"] = {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # cancel mid-utterance
    long_text = (TEXT_EN + " ") * 4
    r = stream_once(pipe_en, long_text, VOICE_EN, cancel_after_s=0.15)
    audio = r.pop("audio")
    if len(audio):
        sf.write(str(SAMPLES / "en_cancel.wav"), audio, SR)
    results["probes"]["cancel_en"] = r
    results["cancel_behavior"] = (
        "generator.close() after cancel_after_s; partial audio retained"
        if r.get("cancelled") else "cancel did not trigger (single segment faster than threshold?)"
    )

    # concurrent N=2/4 via threads (shared pipeline — note GIL/GPU serialization)
    def one(_n):
        rr = stream_once(pipe_en, TEXT_EN, VOICE_EN)
        rr.pop("audio", None)
        return rr

    for n in (2, 4):
        t0 = time.perf_counter()
        outs = []
        with ThreadPoolExecutor(max_workers=n) as ex:
            futs = [ex.submit(one, i) for i in range(n)]
            for f in as_completed(futs):
                outs.append(f.result())
        wall = time.perf_counter() - t0
        ttfas_c = [o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"] = {
            "n": n, "wall_s": wall, "ok": sum(1 for o in outs if o.get("ok")),
            "ttfa_summary": summarize_ttfas(ttfas_c), "results": outs,
            "note": "ThreadPool shared KPipeline; may serialize on CUDA/CPU",
        }
        print(f"concurrent N={n} wall={wall:.3f} ok={sum(1 for o in outs if o.get('ok'))}/{n}", flush=True)

    write_json(OUT / "results.json", results)
    cfg = {
        "model_id": MODEL_ID,
        "model_revision": revision,
        "dtype": results["dtype"],
        "device": device,
        "cmd": "KPipeline(lang_code).generator yield audio segments; TTFA=first yielded audio",
        "streaming": True,
        "sample_rate_hz": SR,
        "voices": {"en": VOICE_EN, "hi": VOICE_HI},
        "kokoro_version": results["kokoro_version"],
    }
    write_json(OUT / "config.json", cfg)
    p50 = results.get("ttfa_p50_s")
    cancel = results["probes"]["cancel_en"]
    n2 = results["probes"]["concurrent_n2"]["ttfa_summary"]
    n4 = results["probes"]["concurrent_n4"]["ttfa_summary"]
    md = f"""# Kokoro streaming probe

**Status:** SUCCESS  
**Model:** `{MODEL_ID}` @ `{revision}`  
**Device:** `{device}` · streaming=`true` (KPipeline generator)  
**kokoro:** {results['kokoro_version']}

## Key TTFA

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| stream en | {p50:.4f} | 5-run p50; first generator audio chunk |
| cancel en | {cancel.get('ttfa_s')} | cancelled={cancel.get('cancelled')} chunks={cancel.get('n_chunks')} |
| concurrent N=2 | mean {n2.get('mean')} / max {n2.get('max')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} / max {n4.get('max')} | ok={results['probes']['concurrent_n4']['ok']}/4 |

See `results.json`, `config.json`, `samples/`, `scripts/probe_stream.py`.
"""
    (OUT / "SUMMARY.md").write_text(md, encoding="utf-8")
    print("WROTE", OUT / "results.json")

if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(1)
