# Voxtral TTS streaming

**When:** 2026-09-21 09:03:08 IST
**License:** NC — Non-commercial / research license — do not use commercially without Mistral license.
**Streaming:** False (batch_only_or_unknown)
**GPU:** {'cuda': True, 'name': 'NVIDIA RTX 6000 Ada Generation', 'capability': [8, 9], 'total_memory_gb': 47.37, 'torch': '2.4.1+cu124', 'cudnn': 90100}
**RasPi:** Not executed. Expected: ONNX/CPU path; do not invent Pi latency numbers.

## Notes
- Prefer true streaming metrics only when stream API used.
- Prior qual pack: `/workspace/voxtral_mini_realtime_asr/` (may already show stream=true probe).
