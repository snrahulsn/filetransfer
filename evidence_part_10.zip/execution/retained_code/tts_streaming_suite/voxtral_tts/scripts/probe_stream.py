#!/usr/bin/env python3
"""Voxtral TTS streaming probe against vLLM-Omni /v1/audio/speech stream:true."""
from __future__ import annotations
import json, os, sys, time, traceback, subprocess, signal
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests
import numpy as np
import soundfile as sf
import wave, struct

OUT=Path(os.environ.get("SUITE_OUT","/workspace/tts_streaming_suite/voxtral_tts"))
SAMPLES=OUT/"samples"; SAMPLES.mkdir(parents=True, exist_ok=True)
MODEL_ID="mistralai/Voxtral-4B-TTS-2603"
PIN=os.environ.get("MODEL_REVISION","b81be46c3777f88621676791b512bb01dc1cb970")
BASE=os.environ.get("VOXTRAL_BASE","http://127.0.0.1:8000")
TEXT_HI="नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।"
TEXT_EN="Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM."
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json

def stream_speech(text, voice="hi_female", stream=True, cancel_after_s=None, fmt="wav"):
    url=BASE.rstrip("/")+"/v1/audio/speech"
    payload={"model": MODEL_ID, "input": text, "voice": voice, "response_format": fmt, "stream": stream}
    # try a few payload shapes
    t0=time.perf_counter(); ttfa=None; chunks=[]; n=0; err=None; cancelled=False; status=None; headers={}
    try:
        with requests.post(url, json=payload, stream=True, timeout=300) as r:
            status=r.status_code; headers=dict(r.headers)
            if r.status_code>=400:
                # try alternate voice / without model
                body=r.content[:500]
                return {"ok":False,"status":status,"error":body.decode("utf-8","replace"),"ttfa_s":None,"total_s":time.perf_counter()-t0,
                        "streaming":stream,"headers":headers,"n_chunks":0,"audio_bytes":0}
            for chunk in r.iter_content(chunk_size=4096):
                if not chunk: continue
                now=time.perf_counter()
                if ttfa is None: ttfa=now-t0
                chunks.append(chunk); n+=1
                if cancel_after_s is not None and (now-t0)>=cancel_after_s:
                    cancelled=True; break
    except Exception as e:
        err=f"{type(e).__name__}: {e}"
    total=time.perf_counter()-t0
    audio=b"".join(chunks)
    return {"ok": status==200 and err is None and (len(audio)>0 or cancelled), "status":status,"error":err,
            "cancelled":cancelled,"ttfa_s":ttfa,"total_s":total,"n_chunks":n,"audio_bytes":len(audio),
            "streaming":stream,"headers":headers,"audio_bytes_blob":audio,"voice":voice,"format":fmt}

def wait_health(timeout=900):
    t0=time.time()
    while time.time()-t0<timeout:
        try:
            r=requests.get(BASE.rstrip("/")+"/health", timeout=5)
            if r.status_code==200: return True
        except Exception:
            pass
        try:
            r=requests.get(BASE.rstrip("/")+"/v1/models", timeout=5)
            if r.status_code==200: return True
        except Exception:
            pass
        time.sleep(5)
    return False

def main():
    # assume server already running, or start if VOXTRAL_START=1
    if os.environ.get("VOXTRAL_START")=="1":
        log=open(OUT/"vllm_serve.log","w")
        cmd=["vllm","serve",MODEL_ID,"--omni","--port","8000","--revision",PIN,"--enforce-eager"]
        proc=subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT)
        (OUT/"vllm_serve.pid").write_text(str(proc.pid)+"\n")
        if not wait_health():
            raise RuntimeError("vllm serve not ready")
    elif not wait_health(timeout=30):
        print("WARN: server not up; probes may fail. Set VOXTRAL_START=1 to launch.", flush=True)

    results={"model_id":MODEL_ID,"revision":PIN,"base":BASE,"streaming":True,"probes":{}}
    # discover voice
    voice="female"
    for vtry in ["hi","hi_female","female","nova","alloy"]:
        probe=stream_speech("hi", voice=vtry, stream=True)
        if probe.get("ok"):
            voice=vtry; break
    results["voice_used"]=voice

    ttfas=[]; last=None
    for i in range(5):
        r=stream_speech(TEXT_EN, voice=voice, stream=True)
        blob=r.pop("audio_bytes_blob",b"")
        ttfas.append(r["ttfa_s"]); last={**r,"audio_saved":bool(blob)}
        if blob and i==4:
            (SAMPLES/"en_stream.bin").write_bytes(blob)
            # try wav
            try:
                if blob[:4]==b"RIFF":
                    (SAMPLES/"en_stream.wav").write_bytes(blob)
            except Exception:
                pass
        print(f"run{i} ttfa={r.get('ttfa_s')} status={r.get('status')} bytes={r.get('audio_bytes')}", flush=True)
    results["probes"]["stream_en"]={**last, "ttfa_summary":summarize_ttfas(ttfas)}
    results["ttfa_p50_s"]=summarize_ttfas(ttfas)["p50"]

    r=stream_speech(TEXT_HI, voice=voice, stream=True)
    blob=r.pop("audio_bytes_blob",b"")
    if blob: (SAMPLES/"hi_stream.bin").write_bytes(blob)
    results["probes"]["stream_hi"]=r

    r=stream_speech((TEXT_EN+" ")*3, voice=voice, stream=True, cancel_after_s=0.5)
    blob=r.pop("audio_bytes_blob",b"")
    if blob: (SAMPLES/"en_cancel.bin").write_bytes(blob)
    results["probes"]["cancel"]=r
    results["cancel_behavior"]=f"HTTP disconnect after 0.5s; cancelled={r.get('cancelled')} chunks={r.get('n_chunks')}"

    def one(_):
        rr=stream_speech(TEXT_EN, voice=voice, stream=True); rr.pop("audio_bytes_blob",None); return rr
    for n in (2,4):
        t0=time.perf_counter(); outs=[]
        with ThreadPoolExecutor(max_workers=n) as ex:
            for f in as_completed([ex.submit(one,i) for i in range(n)]): outs.append(f.result())
        wall=time.perf_counter()-t0
        ttfas=[o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"]={"n":n,"wall_s":wall,"ok":sum(1 for o in outs if o.get("ok")),
            "ttfa_summary":summarize_ttfas(ttfas),"results":outs}

    write_json(OUT/"results.json", results)
    write_json(OUT/"config.json", {"model_id":MODEL_ID,"model_revision":PIN,"dtype":"vllm-default",
        "device":"cuda","cmd":"vllm serve MODEL --omni; POST /v1/audio/speech stream:true",
        "streaming":True,"base":BASE,"voice":voice})
    p50=results.get("ttfa_p50_s"); n2=results["probes"]["concurrent_n2"]["ttfa_summary"]; n4=results["probes"]["concurrent_n4"]["ttfa_summary"]
    (OUT/"SUMMARY.md").write_text(f"""# Voxtral TTS streaming probe

**Status:** {'SUCCESS' if results.get('ttfa_p50_s') else 'PARTIAL/FAIL'} · streaming=`true` (bonus)  
**Model:** `{MODEL_ID}` @ `{PIN}`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| stream en | {p50} | HTTP chunk TTFA |
| cancel | {results['probes']['cancel'].get('ttfa_s')} | {results['cancel_behavior']} |
| concurrent N=2 | mean {n2.get('mean')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} | ok={results['probes']['concurrent_n4']['ok']}/4 |
""", encoding="utf-8")
    print("WROTE", OUT/"results.json")

if __name__=="__main__":
    main()
