#!/usr/bin/env python3
"""Indic Parler-TTS streaming probe. Prefer ParlerTTSStreamer if available."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np
import soundfile as sf

OUT = Path(os.environ.get("SUITE_OUT", "/workspace/tts_streaming_suite/indic_parler"))
SAMPLES = OUT / "samples"
SAMPLES.mkdir(parents=True, exist_ok=True)
MODEL_ID = "ai4bharat/indic-parler-tts"
PIN = os.environ.get("MODEL_REVISION", "7b527af5ee8ed1f9a28d80b19703ed9bb8ba10ca")
TEXT_HI = "नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।"
TEXT_EN = "Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM."
DESC_HI = "Divya's voice is monotone yet slightly fast in delivery, with a very close recording that almost has no background noise."
DESC_EN = "A female speaker delivers a slightly expressive and animated speech with a moderate speed and pitch. The recording is of very high quality, with the speaker's voice sounding clear and very close up."
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json  # noqa

_G = {}

def resolve_path():
    for c in [Path("/workspace/indic_parler_qual/model_cache/indic-parler-tts"),
              Path("/workspace/hf_cache")]:
        if c.name.endswith("indic-parler-tts") and c.exists():
            return str(c)
    from huggingface_hub import snapshot_download
    return snapshot_download(MODEL_ID, revision=PIN, cache_dir=os.environ.get("HF_HUB_CACHE","/workspace/hf_cache"),
                             local_dir=str(OUT/"model_cache"), local_dir_use_symlinks=False)

def load():
    import torch
    from transformers import AutoTokenizer
    from parler_tts import ParlerTTSForConditionalGeneration
    path = resolve_path()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    model = ParlerTTSForConditionalGeneration.from_pretrained(path, revision=None if path.startswith("/") else PIN).to(device, dtype=dtype)
    tok = AutoTokenizer.from_pretrained(path)
    _G.update(model=model, tok=tok, device=device, dtype=dtype, path=path, sr=model.config.sampling_rate)
    return device, path

def try_streamer(text, description, cancel_after_s=None):
    import torch
    model, tok, device = _G["model"], _G["tok"], _G["device"]
    t0 = time.perf_counter()
    ttfa = None
    chunks = []
    cancelled = False
    err = None
    stream_kind = None
    try:
        from parler_tts import ParlerTTSStreamer
        streamer = ParlerTTSStreamer(model, device=device, play_steps=10)
        stream_kind = "ParlerTTSStreamer"
        inputs = tok(description, return_tensors="pt").to(device)
        prompt = tok(text, return_tensors="pt").to(device)
        gen_kwargs = dict(
            input_ids=inputs.input_ids,
            prompt_input_ids=prompt.input_ids,
            attention_mask=inputs.attention_mask,
            prompt_attention_mask=prompt.attention_mask,
            streamer=streamer,
            do_sample=True,
            temperature=1.0,
        )
        # generate in background thread
        import threading
        holder = {"err": None}
        def run_gen():
            try:
                with torch.inference_mode():
                    model.generate(**gen_kwargs)
            except Exception as e:
                holder["err"] = e
        th = threading.Thread(target=run_gen, daemon=True)
        th.start()
        for audio_chunk in streamer:
            now = time.perf_counter()
            if audio_chunk is None:
                continue
            a = audio_chunk
            if hasattr(a, "detach"):
                a = a.detach().float().cpu().numpy()
            a = np.asarray(a, dtype=np.float32).reshape(-1)
            if a.size == 0:
                continue
            if ttfa is None:
                ttfa = now - t0
            chunks.append(a)
            if cancel_after_s is not None and (now - t0) >= cancel_after_s:
                cancelled = True
                break
        th.join(timeout=5 if cancelled else 300)
        if holder["err"] and not chunks:
            raise holder["err"]
    except Exception as e:
        # fallback full generate
        stream_kind = f"full_generate_fallback ({type(e).__name__}: {e})"
        try:
            with torch.inference_mode():
                inputs = tok(description, return_tensors="pt").to(device)
                prompt = tok(text, return_tensors="pt").to(device)
                generation = model.generate(
                    input_ids=inputs.input_ids,
                    prompt_input_ids=prompt.input_ids,
                    attention_mask=inputs.attention_mask,
                    prompt_attention_mask=prompt.attention_mask,
                    do_sample=True,
                    temperature=1.0,
                )
            audio_arr = generation.float().cpu().numpy().squeeze()
            chunks = [np.asarray(audio_arr, dtype=np.float32).reshape(-1)]
            ttfa = time.perf_counter() - t0  # wall-to-complete
            if cancel_after_s is not None:
                cancelled = False  # cannot cancel mid
        except Exception as e2:
            err = f"{type(e2).__name__}: {e2}"
    total = time.perf_counter() - t0
    audio = np.concatenate(chunks) if chunks else np.zeros(0, dtype=np.float32)
    sr = _G["sr"]
    dur = float(len(audio)/sr) if len(audio) else 0.0
    streaming = stream_kind == "ParlerTTSStreamer"
    return {
        "ok": err is None and (len(audio)>0 or cancelled),
        "error": err,
        "cancelled": cancelled,
        "ttfa_s": ttfa,
        "total_s": total,
        "n_chunks": len(chunks),
        "audio_duration_s": dur,
        "sample_rate": sr,
        "rtf": (total/dur) if dur>0 else None,
        "streaming": streaming,
        "stream_kind": stream_kind,
        "audio": audio,
    }

def main():
    device, path = load()
    results = {
        "model_id": MODEL_ID, "revision": PIN, "model_path": path,
        "device": device, "dtype": str(_G["dtype"]), "streaming": None, "probes": {},
    }
    print(f"parler device={device}", flush=True)
    _ = try_streamer("Warm up.", DESC_EN)
    ttfas=[]
    last=None
    for i in range(5):
        r = try_streamer(TEXT_EN, DESC_EN)
        ttfas.append(r["ttfa_s"]); last=r
        print(f"en run{i} ttfa={r['ttfa_s']} streaming={r['streaming']} kind={r['stream_kind']}", flush=True)
    audio=last.pop("audio"); sf.write(str(SAMPLES/"en_stream.wav"), audio, last["sample_rate"])
    results["probes"]["stream_en"]={**last, "ttfa_summary": summarize_ttfas(ttfas)}
    results["ttfa_p50_s"]=summarize_ttfas(ttfas)["p50"]
    results["streaming"]=last["streaming"]

    r=try_streamer(TEXT_HI, DESC_HI)
    audio=r.pop("audio");
    if len(audio): sf.write(str(SAMPLES/"hi_stream.wav"), audio, r["sample_rate"])
    results["probes"]["stream_hi"]=r

    r=try_streamer((TEXT_EN+" ")*3, DESC_EN, cancel_after_s=0.5)
    audio=r.pop("audio")
    if len(audio): sf.write(str(SAMPLES/"en_cancel.wav"), audio, r["sample_rate"])
    results["probes"]["cancel"]=r
    results["cancel_behavior"]=("stopped consuming ParlerTTSStreamer after 0.5s" if r.get("cancelled")
                                else "cancel not applicable / full generate completed")

    def one(_):
        rr=try_streamer(TEXT_EN, DESC_EN); rr.pop("audio",None); return rr
    for n in (2,4):
        t0=time.perf_counter(); outs=[]
        with ThreadPoolExecutor(max_workers=n) as ex:
            for f in as_completed([ex.submit(one,i) for i in range(n)]):
                outs.append(f.result())
        wall=time.perf_counter()-t0
        ttfas=[o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"]={"n":n,"wall_s":wall,"ok":sum(1 for o in outs if o.get("ok")),
            "ttfa_summary":summarize_ttfas(ttfas),"results":outs}
        print(f"concurrent N={n} wall={wall:.3f}", flush=True)

    write_json(OUT/"results.json", results)
    write_json(OUT/"config.json", {
        "model_id": MODEL_ID, "model_revision": PIN, "model_path": path,
        "dtype": str(_G["dtype"]), "device": device,
        "cmd": "ParlerTTSStreamer if available else model.generate(...)",
        "streaming": results["streaming"], "sample_rate_hz": _G["sr"],
    })
    p50=results["ttfa_p50_s"]; n2=results["probes"]["concurrent_n2"]["ttfa_summary"]; n4=results["probes"]["concurrent_n4"]["ttfa_summary"]
    (OUT/"SUMMARY.md").write_text(f"""# Indic Parler streaming probe

**Status:** SUCCESS · streaming=`{results['streaming']}`  
**Model:** `{MODEL_ID}` @ `{PIN}` · device=`{device}`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| stream en | {p50} | kind={results['probes']['stream_en'].get('stream_kind')} |
| cancel | {results['probes']['cancel'].get('ttfa_s')} | {results['cancel_behavior']} |
| concurrent N=2 | mean {n2.get('mean')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} | ok={results['probes']['concurrent_n4']['ok']}/4 |
""", encoding="utf-8")
    print("WROTE", OUT/"results.json")

if __name__=="__main__":
    main()
