# Indic Parler streaming probe

**Status:** SUCCESS · streaming=`True`  
**Model:** `ai4bharat/indic-parler-tts` @ `7b527af5ee8ed1f9a28d80b19703ed9bb8ba10ca` · device=`cuda`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| stream en | 0.2661045310087502 | kind=ParlerTTSStreamer |
| cancel | 0.17646515101660043 | stopped consuming ParlerTTSStreamer after 0.5s |
| concurrent N=2 | mean 0.5301349229412153 | ok=2/2 |
| concurrent N=4 | mean 0.7391678090207279 | ok=4/4 |
