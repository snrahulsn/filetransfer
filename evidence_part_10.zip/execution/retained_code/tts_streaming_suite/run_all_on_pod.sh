#!/usr/bin/env bash
set -euo pipefail
export HF_HUB_CACHE=${HF_HUB_CACHE:-/workspace/hf_cache}
export TRANSFORMERS_CACHE=${TRANSFORMERS_CACHE:-/workspace/hf_cache}
export HF_HOME=${HF_HOME:-/workspace/hf_cache}
SUITE=/workspace/tts_streaming_suite
LOG=$SUITE/pod_run.log
exec > >(tee -a "$LOG") 2>&1
echo "=== TTS streaming suite pod run $(date -Iseconds) ==="
nvidia-smi || true
python3 -V

# Ensure suite is on volume (caller should scp/rsync)
cd "$SUITE"

# Install lightweight deps for each probe as needed into a shared venv if missing
VENV=/workspace/tts_streaming_suite/.venv
if [[ ! -d $VENV ]]; then
  python3 -m venv "$VENV"
fi
# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install -q -U pip wheel
pip install -q numpy soundfile requests huggingface_hub accelerate safetensors

run_one() {
  local name="$1"; shift
  local dir="$SUITE/$name"
  echo "===== START $name $(date -Iseconds) ====="
  if [[ -f $dir/results.json ]] && python3 -c "import json; d=json.load(open('$dir/results.json')); raise SystemExit(0 if d.get('ttfa_p50_s') is not None or d.get('status')=='MISSING' or d.get('probes') else 1)" 2>/dev/null; then
    echo "SKIP $name — results already present"
    return 0
  fi
  SUITE_OUT="$dir" "$@"
  echo "===== DONE $name $(date -Iseconds) ====="
}

# Order: lighter / cached first
# Kokoro
pip install -q "kokoro>=0.9.4" misaki[en,hi] 2>/dev/null || pip install -q "kokoro>=0.9.4" "misaki[en]"
apt-get install -y -qq espeak-ng >/dev/null 2>&1 || true
run_one kokoro python3 "$SUITE/kokoro/scripts/probe_stream.py" || echo "FAIL kokoro"

# Pocket
pip install -q "pocket-tts==3.1.0" 2>/dev/null || pip install -q pocket-tts
run_one pocket_tts python3 "$SUITE/pocket_tts/scripts/probe_stream.py" || echo "FAIL pocket"

# Indic Parler
pip install -q "git+https://github.com/huggingface/parler-tts.git" transformers torchaudio 2>/dev/null || pip install -q parler-tts transformers
run_one indic_parler python3 "$SUITE/indic_parler/scripts/probe_stream.py" || echo "FAIL parler"

# IndicF5 / Sooktam (f5-tts / transformers trust_remote_code)
pip install -q transformers torchaudio librosa 2>/dev/null || true
# f5 deps from prior install scripts if present
if [[ -f /workspace/indic_f5_qual/scripts/install_deps.sh ]]; then
  bash /workspace/indic_f5_qual/scripts/install_deps.sh || true
fi
run_one indic_f5 python3 "$SUITE/indic_f5/scripts/probe_stream.py" || echo "FAIL indic_f5"

if [[ -f /workspace/sooktam2_qual/scripts/install_deps.sh ]]; then
  bash /workspace/sooktam2_qual/scripts/install_deps.sh || true
fi
run_one sooktam2 python3 "$SUITE/sooktam2/scripts/probe_stream.py" || echo "FAIL sooktam2"

# Bodhan
if [[ -f /workspace/bodhan_indic_speak_qual/scripts/install_deps.sh ]]; then
  bash /workspace/bodhan_indic_speak_qual/scripts/install_deps.sh || true
fi
run_one bodhan_indic_speak python3 "$SUITE/bodhan_indic_speak/scripts/probe_stream.py" || echo "FAIL bodhan"

# Voxtral — expensive; only if vllm-omni already installed from prior qual
if command -v vllm >/dev/null 2>&1 || python3 -c "import vllm" 2>/dev/null; then
  VOXTRAL_START=1 run_one voxtral_tts python3 "$SUITE/voxtral_tts/scripts/probe_stream.py" || echo "FAIL voxtral"
else
  echo "SKIP voxtral — vllm not installed (bonus)"
  mkdir -p "$SUITE/voxtral_tts"
  echo '{"status":"SKIPPED","reason":"vllm/vllm-omni not installed on this pod image; bonus item","streaming":null}' > "$SUITE/voxtral_tts/results.json"
fi

# Svara already done — ensure copied
if [[ ! -f $SUITE/svara/results.json && -f /workspace/svara_stream_probe/results.json ]]; then
  mkdir -p "$SUITE/svara"
  cp -a /workspace/svara_stream_probe/{results.json,config.json,SUMMARY.md} "$SUITE/svara/" || true
fi

echo "=== ALL PROBES FINISHED $(date -Iseconds) ==="
python3 "$SUITE/build_rollup.py"
