# CONFIGS — TTS streaming suite

**Packaged:** 2026-09-18 17:32:44 IST

## Kokoro (`kokoro`)
```json
{
  "model_id": "hexgrad/Kokoro-82M",
  "model_revision": "f3ff3571791e39611d31c381e3a41a3af07b4987",
  "dtype": "fp32",
  "device": "cuda",
  "cmd": "KPipeline(lang_code).generator yield audio segments; TTFA=first yielded audio",
  "streaming": true,
  "sample_rate_hz": 24000,
  "voices": {
    "en": "af_heart",
    "hi": "hf_alpha"
  },
  "kokoro_version": "0.9.4"
}
```

## Veena/Maya (`veena_maya`)
```json
{
  "status": "MISSING",
  "model_id": null,
  "note": "Veena/Maya/Mayal not present; skipped"
}
```

## Mayal (`mayal`)
```json
{
  "status": "MISSING",
  "model_id": null,
  "note": "Veena/Maya/Mayal not present; skipped"
}
```

## Indic Parler (`indic_parler`)
```json
{
  "model_id": "ai4bharat/indic-parler-tts",
  "model_revision": "7b527af5ee8ed1f9a28d80b19703ed9bb8ba10ca",
  "model_path": "/workspace/indic_parler_qual/model_cache/indic-parler-tts",
  "dtype": "torch.bfloat16",
  "device": "cuda",
  "cmd": "ParlerTTSStreamer if available else model.generate(...)",
  "streaming": true,
  "sample_rate_hz": 44100
}
```

## IndicF5 (`indic_f5`)
```json
{
  "model_id": "ai4bharat/IndicF5",
  "model_revision": "ba85abedf18dc479a447eaa0eccbd76ab78a47d5",
  "model_path": "/workspace/indic_f5_qual/model_cache/IndicF5",
  "dtype": "fp32/model-default",
  "device": "cuda",
  "cmd": "AutoModel(...)(text, ref_audio, ref_text)",
  "streaming": false,
  "sample_rate_hz": 24000,
  "ref_wav": "/workspace/indic_f5_qual/prompts/PAN_F_HAPPY_00001.wav"
}
```

## Pocket TTS (`pocket_tts`)
```json
{
  "models": {
    "kyutai/pocket-tts": "492522650173a0653b7575cdc25ae09810e5d741",
    "prasadvittaldev/pocket-tts-indian-english-male-indictts": "70cd874aa000d03812e2307d937760d3cc3c21a1",
    "saryps-labs/pocket-tts-hindi": "dbaa326069d20bfbdaeb625613736773741a24ea"
  },
  "dtype": "int8/quantize=True",
  "device": "cuda",
  "cmd": "TTSModel.load_model(...); generate_audio_stream(model_state, text)",
  "streaming": true,
  "sample_rate_hz": 24000,
  "pocket_tts_version": "unknown"
}
```

## Svara-TTS (`svara`)
```json
{
  "packaged_at": "2026-09-18 10:37:21 IST",
  "pod_id": "i1ft2jagjtvn0k",
  "volume_id": "ul08t4z9qx",
  "gpu": "NVIDIA RTX 6000 Ada Generation",
  "data_center": "US-IL-1",
  "model_id": "kenpath/svara-tts-v1",
  "model_path": "/workspace/svara_tts_qual/model_cache/svara",
  "model_revision": "db8a02fc1e4eab827ff6dda5bed3b56d4d2dd51e",
  "inference_repo": "https://github.com/Kenpath/svara-tts-inference",
  "inference_git_rev": "4947c203f2c14ec7bbe0e7968e59c138c3eddfae",
  "dtype": "bfloat16",
  "endpoint": "POST /v1/audio/speech",
  "stream_flag": true,
  "sample_rate_hz": 24000,
  "voices_probed": {
    "hi": "hi_female",
    "en": "en_female"
  },
  "endpoint_flags": {
    "VLLM_MODEL": "/workspace/svara_tts_qual/model_cache/svara",
    "VLLM_GPU_MEMORY_UTILIZATION": "0.85",
    "VLLM_MAX_MODEL_LEN": "4096",
    "VLLM_DTYPE": "bfloat16",
    "VLLM_ENFORCE_EAGER": "true",
    "VLLM_ATTENTION_BACKEND": "FLASH_ATTN",
    "VLLM_USE_FLASHINFER_SAMPLER": "0",
    "SNAC_DEVICE": "cuda",
    "API_HOST": "0.0.0.0",
    "API_PORT": "8080"
  },
  "serve_method": "pip (no Docker on RunPod image) + python api/server.py",
  "docker_note": "Official path is docker-compose up (Dockerfile nvidia/cuda:12.8.0). Pod image had NO docker binary; used pip install of Kenpath/svara-tts-inference requirements + vllm 0.29.0 instead.",
  "pip_cmd": [
    "git clone https://github.com/Kenpath/svara-tts-inference.git",
    "python3 -m venv /workspace/svara_stream_work/venv && source .../activate",
    "pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu124  # later overwritten by vllm to 2.13.0+cu130",
    "pip install langcodes language_data snac 'transformers>=4.30.0' fastapi uvicorn pydantic python-dotenv pyyaml soundfile numpy hf-transfer",
    "pip install 'vllm>=0.17.0' flashinfer-python torchcodec",
    "apt-get install -y ffmpeg libsndfile1",
    "cd api && VLLM_MODEL=... VLLM_USE_FLASHINFER_SAMPLER=0 VLLM_ATTENTION_BACKEND=FLASH_ATTN python server.py"
  ],
  "versions": {
    "torch": "2.13.0+cu130",
    "cuda": "13.0",
    "vllm": "0.29.0",
    "transformers": "5.17.0",
    "fastapi": "0.136.3",
    "snac": "1.2.1",
    "gpu": "NVIDIA RTX 6000 Ada Generation"
  },
  "torch_version": "2.13.0+cu130",
  "cuda_version": "13.0",
  "key_ttfa": {
    "stream_hi_s": 0.9263933070469648,
    "stream_en_s": 0.9349814869929105,
    "cancel_en_s": 0.8948324370430782,
    "concurrent_n2_mean_s": 0.9450904880068265,
    "concurrent_n4_mean_s": 1.085587494453648
  },
  "stream_available": true
}
```

## Sooktam-2 (`sooktam2`)
```json
{
  "model_id": "bharatgenai/sooktam2",
  "model_revision": "eb270c0ceebd58e0e513820eb71c637e9f486a7b",
  "model_path": "/workspace/sooktam2_qual/model_cache/sooktam2",
  "dtype": "torch.float32",
  "device": "cuda",
  "cmd": "AutoModel.from_pretrained(...).infer(text, ref_audio, ref_text)",
  "streaming": false,
  "sample_rate_hz": 24000,
  "ref_wav": "/workspace/sooktam2_qual/prompts/hi-IN_ref.wav"
}
```

## Bodhan Indic-Speak (bonus) (`bodhan_indic_speak`)
```json
{
  "model_id": "bodhan-ai/indic-speak",
  "model_revision": "76e0814f189321efe550011850cd288dae366aad",
  "model_path": "/workspace/bodhan_indic_speak_qual/model_cache/indic-speak",
  "dtype": "model-default",
  "device": "cuda",
  "cmd": "inference.TTS(path)(text, speaker=...)",
  "streaming": false,
  "sample_rate_hz": 24000
}
```

## Voxtral TTS (bonus) (`voxtral_tts`)
```json
{
  "status": "SKIPPED",
  "model_id": "mistralai/Voxtral-4B-TTS-2603"
}
```

