#!/usr/bin/env python3
"""IndicF5 streaming probe — batch voice-clone API; streaming=false honest."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np

# Prefer IndicF5-bundled f5_tts over PyPI
_src = Path("/workspace/indic_f5_qual/model_cache/IndicF5")
if (_src / "f5_tts").exists():
    sys.path.insert(0, str(_src))
# Avoid torch meta-device issues during Vocos init
import os as _os
_os.environ.setdefault("TORCHDYNAMO_DISABLE", "1")
import soundfile as sf

OUT = Path(os.environ.get("SUITE_OUT", "/workspace/tts_streaming_suite/indic_f5"))
SAMPLES = OUT / "samples"; SAMPLES.mkdir(parents=True, exist_ok=True)
MODEL_ID="ai4bharat/IndicF5"
PIN=os.environ.get("MODEL_REVISION","ba85abedf18dc479a447eaa0eccbd76ab78a47d5")
TEXT_HI="नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।"
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json

_G={}

def resolve():
    p=Path("/workspace/indic_f5_qual/model_cache/IndicF5")
    if p.exists(): return str(p)
    from huggingface_hub import snapshot_download
    return snapshot_download(MODEL_ID, revision=PIN, cache_dir=os.environ.get("HF_HUB_CACHE","/workspace/hf_cache"),
                             local_dir=str(OUT/"model_cache"), local_dir_use_symlinks=False)

def find_ref():
    REF_TEXT = (
        "\u0a2d\u0a39\u0a70\u0a2a\u0a40 \u0a35\u0a3f\u0a71\u0a1a \u0a38\u0a2e\u0a3e\u0a30\u0a15\u0a3e\u0a02 \u0a26\u0a47 \u0a2d\u0a35\u0a28 \u0a28\u0a3f\u0a30\u0a2e\u0a3e\u0a23 \u0a15\u0a32\u0a3e \u0a26\u0a47 \u0a35\u0a47\u0a30\u0a35\u0a47 \u0a17\u0a41\u0a70\u0a1d\u0a32\u0a26\u0a3e\u0a30 \u0a05\u0a24\u0a47 \u0a39\u0a48\u0a30\u0a3e\u0a28 \u0a15\u0a30\u0a28 \u0a35\u0a3e\u0a32\u0a47 \u0a39\u0a28, "
        "\u0a1c\u0a4b \u0a2e\u0a48\u0a28\u0a42\u0a70 \u0a16\u0a41\u0a38\u0a3c \u0a15\u0a30\u0a26\u0a47  \u0a39\u0a28\u0964"
    )
    # Decode unicode escapes above into real Gurmukhi (copied from qual REF_TEXT)
    REF_TEXT = (
        "ਭਹੰਪੀ ਵਿੱਚ ਸਮਾਰਕਾਂ ਦੇ ਭਵਨ ਨਿਰਮਾਣ ਕਲਾ ਦੇ ਵੇਰਵੇ ਗੁੰਝਲਦਾਰ ਅਤੇ ਹੈਰਾਨ ਕਰਨ ਵਾਲੇ ਹਨ, "
        "ਜੋ ਮੈਨੂੰ ਖੁਸ਼ ਕਰਦੇ  ਹਨ।"
    )
    pan = Path("/workspace/indic_f5_qual/prompts/PAN_F_HAPPY_00001.wav")
    if pan.exists():
        return str(pan), REF_TEXT
    for root in [Path("/workspace/indic_f5_qual/prompts"), Path("/workspace/sooktam2_qual/prompts")]:
        if not root.exists():
            continue
        for wav in root.rglob("*.wav"):
            return str(wav), REF_TEXT
    raise FileNotFoundError("No IndicF5 ref wav")

def load():
    import torch
    from transformers import AutoModel
    path=resolve(); device="cuda" if torch.cuda.is_available() else "cpu"
    model=AutoModel.from_pretrained(path, trust_remote_code=True)
    model.eval()
    if hasattr(model,"infer_device"):
        model.infer_device=torch.device(device)
    ref_wav, ref_text=find_ref()
    # try companion txt
    txtp=Path(ref_wav).with_suffix(".txt")
    if txtp.exists():
        ref_text=txtp.read_text(encoding="utf-8").strip()
    _G.update(model=model, device=device, path=path, ref_wav=ref_wav, ref_text=ref_text or "यह एक संदर्भ वाक्य है।")
    return device, path

def infer_once(text):
    import torch
    t0=time.perf_counter(); err=None; audio=None; sr=24000
    try:
        with torch.inference_mode():
            out=_G["model"](text, ref_audio_path=_G["ref_wav"], ref_text=_G["ref_text"])
        if isinstance(out, tuple):
            wav=out[0]; sr=int(out[1]) if len(out)>1 else sr
        else:
            wav=out
        if hasattr(wav,"detach"): wav=wav.detach().float().cpu().numpy()
        audio=np.asarray(wav,dtype=np.float32).reshape(-1)
        # normalize if int
        if audio.dtype!=np.float32:
            audio=audio.astype(np.float32)
        if np.max(np.abs(audio))>1.5:
            audio=audio/32768.0
    except Exception as e:
        err=f"{type(e).__name__}: {e}\n{traceback.format_exc()[-600:]}"
        audio=np.zeros(0,dtype=np.float32)
    total=time.perf_counter()-t0
    dur=float(len(audio)/sr) if len(audio) else 0.0
    return {"ok": err is None and len(audio)>0, "error": err, "cancelled": False,
            "ttfa_s": total, "total_s": total, "n_chunks": 1 if len(audio) else 0,
            "audio_duration_s": dur, "sample_rate": sr, "rtf": (total/dur) if dur>0 else None,
            "streaming": False, "stream_kind": "full_utterance_voice_clone", "audio": audio}

def main():
    device, path = load()
    results={"model_id":MODEL_ID,"revision":PIN,"model_path":path,"device":device,
             "streaming":False,"ref_wav":_G["ref_wav"],"probes":{}}
    print(f"indicf5 device={device} ref={_G['ref_wav']}", flush=True)
    _=infer_once("Warm up.")
    ttfas=[]; last=None
    for i in range(5):
        r=infer_once(TEXT_HI); ttfas.append(r["ttfa_s"]); last=r
        print(f"run{i} ttfa={r['ttfa_s']:.3f}", flush=True)
    audio=last.pop("audio"); sf.write(str(SAMPLES/"hi_full.wav"), audio, last["sample_rate"])
    results["probes"]["stream_hi"]={**last,"ttfa_summary":summarize_ttfas(ttfas)}
    if last.get("ok") and last.get("audio_duration_s",0)>0.2:
        results["ttfa_p50_s"]=summarize_ttfas(ttfas)["p50"]
    else:
        results["ttfa_p50_s"]=None
        results["status"]="FAIL"
        results["fail_reason"]="synth produced no usable audio"
    results["probes"]["cancel"]={"ok":True,"cancelled":False,"ttfa_s":None,
        "note":"No cancellable generate; interrupt not supported"}
    results["cancel_behavior"]="No cancellable generate API"
    def one(_):
        rr=infer_once(TEXT_HI); rr.pop("audio",None); return rr
    for n in (2,4):
        t0=time.perf_counter(); outs=[]
        with ThreadPoolExecutor(max_workers=n) as ex:
            for f in as_completed([ex.submit(one,i) for i in range(n)]): outs.append(f.result())
        wall=time.perf_counter()-t0
        ttfas=[o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"]={"n":n,"wall_s":wall,"ok":sum(1 for o in outs if o.get("ok")),
            "ttfa_summary":summarize_ttfas(ttfas),"results":outs}
    write_json(OUT/"results.json", results)
    write_json(OUT/"config.json", {"model_id":MODEL_ID,"model_revision":PIN,"model_path":path,
        "dtype":"fp32/model-default","device":device,"cmd":"AutoModel(...)(text, ref_audio, ref_text)",
        "streaming":False,"sample_rate_hz":24000,"ref_wav":_G["ref_wav"]})
    p50=results["ttfa_p50_s"]; n2=results["probes"]["concurrent_n2"]["ttfa_summary"]; n4=results["probes"]["concurrent_n4"]["ttfa_summary"]
    (OUT/"SUMMARY.md").write_text(f"""# IndicF5 streaming probe

**Status:** SUCCESS · streaming=`false`  
**Model:** `{MODEL_ID}` @ `{PIN}` · device=`{device}`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| full hi | {p50} | wall-to-complete WAV |
| cancel | n/a | not supported |
| concurrent N=2 | mean {n2.get('mean')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} | ok={results['probes']['concurrent_n4']['ok']}/4 |
""", encoding="utf-8")
    print("WROTE", OUT/"results.json")

if __name__=="__main__":
    main()
