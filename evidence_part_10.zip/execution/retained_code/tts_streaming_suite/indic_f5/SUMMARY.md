# IndicF5 streaming probe

**Status:** SUCCESS · streaming=`false`  
**Model:** `ai4bharat/IndicF5` @ `ba85abedf18dc479a447eaa0eccbd76ab78a47d5` · device=`cuda`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| full hi | 2.2174561040010303 | wall-to-complete WAV |
| cancel | n/a | not supported |
| concurrent N=2 | mean 4.571044865471777 | ok=2/2 |
| concurrent N=4 | mean 9.493184296268737 | ok=4/4 |
