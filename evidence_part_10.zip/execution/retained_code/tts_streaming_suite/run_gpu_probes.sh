#!/usr/bin/env bash
set -euo pipefail
export HF_HUB_CACHE=/workspace/hf_cache
export TRANSFORMERS_CACHE=/workspace/hf_cache
export HF_HOME=/workspace/hf_cache
export HF_HUB_ENABLE_HF_TRANSFER=1
SUITE=/workspace/tts_streaming_suite
cd "$SUITE"
LOG=$SUITE/pod_gpu_run.log
exec > >(tee -a "$LOG") 2>&1
echo "=== GPU probes start $(date -Iseconds) ==="
nvidia-smi

VENV=$SUITE/.venv_gpu
if [[ ! -x $VENV/bin/python ]]; then
  python3 -m venv "$VENV"
fi
source "$VENV/bin/activate"
pip install -q -U pip wheel
pip install -q numpy soundfile requests "huggingface_hub[hf_transfer]" accelerate safetensors

run() {
  local name=$1; shift
  echo "===== $name $(date -Iseconds) ====="
  if [[ -f $SUITE/$name/results.json ]]; then
    if python3 -c "import json; d=json.load(open('$SUITE/$name/results.json'));
import sys
ok=d.get('ttfa_p50_s') is not None or (d.get('probes') and any(isinstance(v,dict) and v.get('ttfa_s') for v in d['probes'].values()))
sys.exit(0 if ok else 1)"; then
      echo "SKIP $name already has TTFA"
      return 0
    fi
  fi
  SUITE_OUT=$SUITE/$name "$@" || echo "FAIL $name exit=$?"
}

# --- Sooktam2 ---
# reuse install from sooktam qual if possible
if [[ -f /workspace/sooktam2_qual/scripts/install_deps.sh ]]; then
  bash /workspace/sooktam2_qual/scripts/install_deps.sh || true
fi
pip install -q transformers torchaudio librosa einops 2>/dev/null || true
run sooktam2 python "$SUITE/sooktam2/scripts/probe_stream.py"

# --- IndicF5 ---
if [[ -f /workspace/indic_f5_qual/scripts/install_deps.sh ]]; then
  bash /workspace/indic_f5_qual/scripts/install_deps.sh || true
fi
run indic_f5 python "$SUITE/indic_f5/scripts/probe_stream.py"

# --- Indic Parler ---
pip install -q "git+https://github.com/huggingface/parler-tts.git" || pip install -q parler-tts
run indic_parler python "$SUITE/indic_parler/scripts/probe_stream.py"

# --- Bodhan ---
if [[ -f /workspace/bodhan_indic_speak_qual/scripts/install_deps.sh ]]; then
  bash /workspace/bodhan_indic_speak_qual/scripts/install_deps.sh || true
fi
# need snac vocos etc - try import
run bodhan_indic_speak python "$SUITE/bodhan_indic_speak/scripts/probe_stream.py"

# --- Kokoro on GPU (re-measure; overwrite CPU numbers) ---
pip install -q "kokoro>=0.9.4" "misaki[en]" soundfile
apt-get install -y -qq espeak-ng >/dev/null 2>&1 || true
# force re-run by removing ttfa marker? keep CPU as device note — re-run on cuda
rm -f "$SUITE/kokoro/results.json"
run kokoro python "$SUITE/kokoro/scripts/probe_stream.py"

# --- Pocket on GPU if quick ---
pip install -q "pocket-tts==3.1.0" || pip install -q pocket-tts
rm -f "$SUITE/pocket_tts/results.json"
run pocket_tts python "$SUITE/pocket_tts/scripts/probe_stream.py"

# --- Voxtral bonus if vllm present ---
if python -c "import vllm" 2>/dev/null; then
  VOXTRAL_START=1 run voxtral_tts python "$SUITE/voxtral_tts/scripts/probe_stream.py"
else
  # try install is heavy — skip if not present
  echo "SKIP voxtral — vllm not in venv (bonus)"
  python - <<'PY'
import json
from pathlib import Path
p=Path('/workspace/tts_streaming_suite/voxtral_tts')
p.mkdir(exist_ok=True)
(p/'results.json').write_text(json.dumps({"status":"SKIPPED","reason":"vllm not installed in suite venv; prior qual had stream=true OK but full TTFA/cancel/concurrent not re-measured here","streaming":None})+'\n')
(p/'SUMMARY.md').write_text('# Voxtral TTS — SKIPPED (bonus)\n\nvllm/vllm-omni not installed in streaming suite venv. Prior qual noted stream=true OK. Not fabricating metrics.\n')
(p/'config.json').write_text(json.dumps({"status":"SKIPPED","model_id":"mistralai/Voxtral-4B-TTS-2603"})+'\n')
PY
fi

python "$SUITE/build_rollup.py"
echo "=== GPU probes done $(date -Iseconds) ==="
