# maya1 streaming

**Status:** OK
**Streaming:** True (`hf_token_stream_snac7`)
**TTFA p50:** 0.11062570288777351
**Cancel:** True ttfa=0.09888433618471026
**N=2:** {'n': 2, 'ttfas': [0.25024744868278503, 0.24773972993716598], 'wall_s': 4.24587856978178, 'summary': {'n': 2, 'mean': 0.2489935893099755, 'p50': 0.25024744868278503, 'min': 0.24773972993716598, 'max': 0.25024744868278503}}
**N=4:** {'n': 4, 'ttfas': [0.7299505919218063, 0.6541859512217343, 0.65152687439695, 0.6517228009179235], 'wall_s': 8.654230906162411, 'summary': {'n': 4, 'mean': 0.6718465546146035, 'p50': 0.6541859512217343, 'min': 0.65152687439695, 'max': 0.7299505919218063}}

Note: Official production path is vLLM+SNAC. This probe uses HF token-stream for honest first-chunk TTFA.
