# TTS streaming suite — rollup

**Packaged:** 2026-09-18 17:32:44 IST
**Volume:** `ul08t4z9qx` (retained — never deleted)

## TTFA / interrupt / concurrent

| Vendor | Status | streaming | TTFA p50 (s) | Cancel | N=2 mean TTFA | N=4 mean TTFA |
|--------|--------|-----------|-------------:|--------|--------------:|--------------:|
| Kokoro | OK | True | 0.0460 | cancelled=False ttfa=0.12459633697289973 | 0.1073 | 0.1926 |
| Veena/Maya | MISSING | None | — | — | — | — |
| Mayal | MISSING | None | — | — | — | — |
| Indic Parler | OK | True | 0.2661 | cancelled=True ttfa=0.17646515101660043 | 0.5301 | 0.7392 |
| IndicF5 | OK | False | 2.2175 | cancelled=False ttfa=None | 4.5710 | 9.4932 |
| Pocket TTS | OK | True | 0.0777 | cancelled=True ttfa=0.15751280495896935 | 0.1128 | 0.1835 |
| Svara-TTS | OK | True | 0.9350 | cancelled=True ttfa=0.8948324370430782 chunks=1 | 0.9451 | 1.0856 |
| Sooktam-2 | OK | False | 2.0785 | cancelled=False ttfa=3.202881531091407 | 4.5576 | 9.2601 |
| Bodhan Indic-Speak (bonus) | OK | False | 7.3468 | cancelled=False ttfa=None | 33.3267 | 43.0449 |
| Voxtral TTS (bonus) | SKIPPED | None | — | — | — | — |

## Notes
- TTFA = time-to-first-audio (first streamed chunk) when `streaming=true`; otherwise wall time to first full sample / complete WAV.
- No fabricated stream metrics: vendors without a stream API are marked `streaming=false`.
- Svara copied from `/workspace/svara_stream_probe` (not re-run).
- Veena/Maya/Mayal marked MISSING when packs/models absent.

## Per-vendor artifacts
Each vendor dir: `scripts/`, `results.json`, `config.json`, `SUMMARY.md`, `samples/`.

