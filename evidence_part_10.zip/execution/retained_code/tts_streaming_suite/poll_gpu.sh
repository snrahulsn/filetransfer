#!/usr/bin/env bash
set -euo pipefail
source /home/box/agent-data/runpod.env
UA="Mozilla/5.0 (compatible; GrokBot/1.0)"
LOG=/workspace/tts_streaming_suite/gpu_poll.log
PODS=(i1ft2jagjtvn0k klzivom1puwe87 ljousqqvw86gll xap8tflys7mfgo rvtykuxqr0lke6)
GPUS=(
  "NVIDIA RTX 6000 Ada Generation"
  "NVIDIA GeForce RTX 4090"
  "NVIDIA GeForce RTX 3090"
  "NVIDIA A40"
  "NVIDIA RTX A6000"
  "NVIDIA L40"
  "NVIDIA L40S"
  "NVIDIA RTX 4000 Ada Generation"
  "NVIDIA RTX 5000 Ada Generation"
  "NVIDIA RTX 2000 Ada Generation"
  "NVIDIA A100 80GB PCIe"
  "NVIDIA A100-SXM4-80GB"
  "NVIDIA H100 PCIe"
  "NVIDIA GeForce RTX 4080"
  "NVIDIA GeForce RTX 5090"
)
echo "poll restart $(date -Iseconds)" | tee -a "$LOG"
while true; do
  for pid in "${PODS[@]}"; do
    out=$(curl -s -A "$UA" -H "Authorization: Bearer $RUNPOD_API_KEY" -H "Content-Type: application/json" \
      -d "{\"query\":\"mutation { podResume(input: {podId: \\\"$pid\\\"}) { id desiredStatus } }\"}" \
      https://api.runpod.io/graphql || true)
    if echo "$out" | python3 -c "import json,sys; d=json.load(sys.stdin); raise SystemExit(0 if d.get('data',{}).get('podResume') else 1)" 2>/dev/null; then
      echo "RESUMED $pid $(date -Iseconds) $out" | tee -a "$LOG"
      echo "$pid" > /workspace/runpod_pod_id.txt
      echo RESUMED > /workspace/tts_streaming_suite/POD_READY
      exit 0
    fi
  done
  for gpu in "${GPUS[@]}"; do
    payload=$(GPU="$gpu" python3 - <<'PY'
import json, os
gpu=os.environ["GPU"]
q = f'''mutation {{ podFindAndDeployOnDemand(input: {{
  name: "tts-streaming-suite"
  imageName: "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04"
  gpuTypeId: "{gpu}"
  cloudType: SECURE
  dataCenterId: "US-IL-1"
  networkVolumeId: "ul08t4z9qx"
  volumeMountPath: "/workspace"
  containerDiskInGb: 50
  volumeInGb: 0
  ports: "22/tcp"
  supportPublicIp: true
  startSsh: true
}}) {{ id desiredStatus machine {{ gpuDisplayName dataCenterId }} costPerHr }} }}'''
print(json.dumps({"query": q}))
PY
)
    out=$(curl -s -A "$UA" -H "Authorization: Bearer $RUNPOD_API_KEY" -H "Content-Type: application/json" -d "$payload" https://api.runpod.io/graphql || true)
    if echo "$out" | python3 -c "import json,sys; d=json.load(sys.stdin); raise SystemExit(0 if d.get('data',{}).get('podFindAndDeployOnDemand') else 1)" 2>/dev/null; then
      echo "CREATED $gpu $(date -Iseconds) $out" | tee -a "$LOG"
      echo "$out" > /workspace/tts_stream_pod_create.json
      python3 -c "import json; d=json.load(open('/workspace/tts_stream_pod_create.json')); print(d['data']['podFindAndDeployOnDemand']['id'])" > /workspace/runpod_pod_id.txt
      echo CREATED > /workspace/tts_streaming_suite/POD_READY
      exit 0
    fi
  done
  echo "no capacity $(date -Iseconds)" | tee -a "$LOG"
  sleep 30
done
