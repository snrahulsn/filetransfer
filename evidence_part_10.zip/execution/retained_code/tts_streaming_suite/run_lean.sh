#!/usr/bin/env bash
set -euo pipefail
export HF_HUB_CACHE=/workspace/hf_cache TRANSFORMERS_CACHE=/workspace/hf_cache HF_HOME=/workspace/hf_cache
SUITE=/workspace/tts_streaming_suite
cd "$SUITE"
source "$SUITE/.venv_gpu/bin/activate"
LOG=$SUITE/pod_lean_run.log
exec > >(tee -a "$LOG") 2>&1
echo "=== lean start $(date -Iseconds) ==="

# Kill heavy sooktam install if still going
pkill -f "sooktam2_qual/scripts/install_deps" || true
pkill -f "indictrans|tensorflow==2.15" || true
sleep 2

# Minimal shared deps
pip install -q -U pip
pip install -q numpy soundfile requests huggingface_hub accelerate safetensors transformers torchaudio librosa einops sentencepiece protobuf

run_bg() {
  local name=$1; shift
  echo "LAUNCH $name $(date -Iseconds)"
  (
    set +e
    echo "===== START $name $(date -Iseconds) =====" >> "$SUITE/${name}_probe.log"
    SUITE_OUT=$SUITE/$name "$@" >> "$SUITE/${name}_probe.log" 2>&1
    echo "===== END $name exit=$? $(date -Iseconds) =====" >> "$SUITE/${name}_probe.log"
  ) &
  echo $! > "$SUITE/${name}.pid"
}

# Install per-vendor extras then launch

# Sooktam - try without full tensorflow stack; trust_remote_code model
pip install -q "f5-tts" 2>/dev/null || true
# If f5-tts pulls too much, still try probe — model may only need transformers
run_bg sooktam2 python "$SUITE/sooktam2/scripts/probe_stream.py"

# IndicF5 - similar
run_bg indic_f5 python "$SUITE/indic_f5/scripts/probe_stream.py"

# Wait a bit so they don't OOM together — actually serialize heavy models
wait $(cat "$SUITE/sooktam2.pid") || true
echo "sooktam done $(date -Iseconds)"
wait $(cat "$SUITE/indic_f5.pid") || true
echo "indic_f5 done $(date -Iseconds)"

# Parler
pip install -q "git+https://github.com/huggingface/parler-tts.git" || pip install -q parler-tts
run_bg indic_parler python "$SUITE/indic_parler/scripts/probe_stream.py"
wait $(cat "$SUITE/indic_parler.pid") || true

# Bodhan
pip install -q snac vocos 2>/dev/null || true
# install from bodhan deps if exists but avoid full reinstall
if [[ -f /workspace/bodhan_indic_speak_qual/scripts/install_deps.sh ]]; then
  # only pip packages that are missing
  python -c "import snac,vocos" 2>/dev/null || bash /workspace/bodhan_indic_speak_qual/scripts/install_deps.sh || true
fi
run_bg bodhan_indic_speak python "$SUITE/bodhan_indic_speak/scripts/probe_stream.py"
wait $(cat "$SUITE/bodhan_indic_speak.pid") || true

# Kokoro GPU remeasure
pip install -q "kokoro>=0.9.4" "misaki[en]" 
apt-get install -y -qq espeak-ng >/dev/null 2>&1 || true
rm -f "$SUITE/kokoro/results.json"
run_bg kokoro python "$SUITE/kokoro/scripts/probe_stream.py"
wait $(cat "$SUITE/kokoro.pid") || true

# Pocket GPU
pip install -q "pocket-tts==3.1.0" || pip install -q pocket-tts
rm -f "$SUITE/pocket_tts/results.json"
run_bg pocket_tts python "$SUITE/pocket_tts/scripts/probe_stream.py"
wait $(cat "$SUITE/pocket_tts.pid") || true

# Voxtral skip unless vllm already there
if python -c "import vllm" 2>/dev/null; then
  VOXTRAL_START=1 run_bg voxtral_tts python "$SUITE/voxtral_tts/scripts/probe_stream.py"
  wait $(cat "$SUITE/voxtral_tts.pid") || true
else
  python - <<'PY'
import json
from pathlib import Path
p=Path('/workspace/tts_streaming_suite/voxtral_tts')
(p/'results.json').write_text(json.dumps({"status":"SKIPPED","reason":"vllm not in lean venv; bonus","streaming":None,"model_id":"mistralai/Voxtral-4B-TTS-2603","revision":"b81be46c3777f88621676791b512bb01dc1cb970"})+'\n')
(p/'SUMMARY.md').write_text('# Voxtral TTS — SKIPPED (bonus)\n\nvllm not installed. Prior qual: stream=true OK. No fabricated TTFA.\n')
(p/'config.json').write_text(json.dumps({"status":"SKIPPED","model_id":"mistralai/Voxtral-4B-TTS-2603"})+'\n')
print('voxtral skipped')
PY
fi

python "$SUITE/build_rollup.py"
echo "=== lean DONE $(date -Iseconds) ==="
