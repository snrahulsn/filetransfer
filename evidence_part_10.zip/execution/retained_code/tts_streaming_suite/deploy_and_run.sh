#!/usr/bin/env bash
set -euo pipefail
source /home/box/agent-data/runpod.env
UA="Mozilla/5.0 (compatible; GrokBot/1.0)"
POD=$(cat /workspace/runpod_pod_id.txt | tr -d '\n')
echo "Waiting for pod $POD runtime..."
for i in $(seq 1 120); do
  out=$(curl -s -A "$UA" -H "Authorization: Bearer $RUNPOD_API_KEY" -H "Content-Type: application/json" \
    -d "{\"query\":\"query { pod(input: {podId: \\\"$POD\\\"}) { id desiredStatus runtime { ports { ip isIpPublic privatePort publicPort type } } machine { gpuDisplayName dataCenterId } } }\"}" \
    https://api.runpod.io/graphql)
  echo "$out" > /workspace/tts_streaming_suite/pod_status.json
  python3 - <<'PY'
import json
from pathlib import Path
d=json.load(open("/workspace/tts_streaming_suite/pod_status.json"))
pod=d["data"]["pod"]
print(pod["desiredStatus"], flush=True)
rt=pod.get("runtime") or {}
ports=rt.get("ports") or []
ip=port=None
for p in ports:
  if p.get("privatePort")==22 and p.get("isIpPublic"):
    ip=p["ip"]; port=p["publicPort"]
if ip and port:
  Path("/workspace/runpod_ip.txt").write_text(ip+"\n")
  Path("/workspace/runpod_port.txt").write_text(str(port)+"\n")
  print(f"SSH {ip}:{port}", flush=True)
  raise SystemExit(0)
raise SystemExit(2)
PY
  rc=$?
  if [[ $rc -eq 0 ]]; then break; fi
  sleep 5
done
IP=$(cat /workspace/runpod_ip.txt | tr -d '\n')
PORT=$(cat /workspace/runpod_port.txt | tr -d '\n')
SSH=(ssh -i /home/box/.ssh/runpod_smoke -o StrictHostKeyChecking=no -o UserKnownHostsFile=/home/box/.ssh/known_hosts -o ConnectTimeout=15 -p "$PORT" root@"$IP")
echo "SSH to $IP:$PORT"
for i in $(seq 1 60); do
  if "${SSH[@]}" 'echo SSH_OK' 2>/dev/null; then break; fi
  sleep 5
done
# Sync suite scripts onto volume (pod /workspace IS the volume)
rsync -av -e "ssh -i /home/box/.ssh/runpod_smoke -o StrictHostKeyChecking=no -p $PORT" \
  /workspace/tts_streaming_suite/ root@"$IP":/workspace/tts_streaming_suite/ \
  --exclude '.venv' --exclude '.venv_cpu' --exclude '.venv_pocket' --exclude 'samples/*.wav' --exclude 'samples/*.bin' --exclude 'samples/*.pcm'
# Also ensure box-side results for kokoro/pocket/svara are on volume
rsync -av -e "ssh -i /home/box/.ssh/runpod_smoke -o StrictHostKeyChecking=no -p $PORT" \
  /workspace/tts_streaming_suite/kokoro/ /workspace/tts_streaming_suite/pocket_tts/ /workspace/tts_streaming_suite/svara/ \
  root@"$IP":/workspace/tts_streaming_suite/ 2>/dev/null || true

# Better: rsync whole suite including CPU results
rsync -av -e "ssh -i /home/box/.ssh/runpod_smoke -o StrictHostKeyChecking=no -p $PORT" \
  /workspace/tts_streaming_suite/ root@"$IP":/workspace/tts_streaming_suite/ \
  --exclude '.venv*' --exclude '__pycache__'

"${SSH[@]}" 'bash /workspace/tts_streaming_suite/run_all_on_pod.sh' 
# Copy results back
rsync -av -e "ssh -i /home/box/.ssh/runpod_smoke -o StrictHostKeyChecking=no -p $PORT" \
  root@"$IP":/workspace/tts_streaming_suite/ /workspace/tts_streaming_suite/ \
  --exclude '.venv*' --exclude '__pycache__'
echo DEPLOY_DONE
