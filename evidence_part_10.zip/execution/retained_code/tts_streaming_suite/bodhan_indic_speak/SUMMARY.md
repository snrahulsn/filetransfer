# Bodhan Indic-Speak streaming probe

**Status:** SUCCESS · streaming=`false` (bonus)  
**Model:** `bodhan-ai/indic-speak` @ `76e0814f189321efe550011850cd288dae366aad` · device=`cuda`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| full hi | 7.3467902899719775 | wall-to-complete |
| cancel | n/a | not supported |
| concurrent N=2 | mean 33.3267164369463 | ok=2/2 |
| concurrent N=4 | mean 43.044939102459466 | ok=4/4 |
