#!/usr/bin/env python3
"""Bodhan Indic-Speak streaming probe — no true stream; wall-to-WAV; concurrent threads."""
from __future__ import annotations
import json, os, sys, time, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np
import soundfile as sf

OUT=Path(os.environ.get("SUITE_OUT","/workspace/tts_streaming_suite/bodhan_indic_speak"))
SAMPLES=OUT/"samples"; SAMPLES.mkdir(parents=True, exist_ok=True)
MODEL_ID="bodhan-ai/indic-speak"
PIN=os.environ.get("MODEL_REVISION","76e0814f189321efe550011850cd288dae366aad")
TEXT_HI="नमस्ते, मेरा नाम राहुल है और आज की मीटिंग तीन बजे है।"
TEXT_EN="Hello, my name is Rahul and your meeting with Priya is tomorrow at three thirty PM."
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from _common_stream_utils import summarize_ttfas, write_json
_G={}

def resolve():
    cands = [
        Path("/workspace/bodhan_indic_speak_qual/model_cache/indic-speak"),
        Path("/workspace/hf_cache/models--bodhan-ai--indic-speak/snapshots") / PIN,
    ]
    for c in cands:
        if c.exists() and (c / "inference.py").exists():
            return str(c)
    cache = Path(os.environ.get("HF_HUB_CACHE", "/workspace/hf_cache")) / "models--bodhan-ai--indic-speak" / "snapshots"
    if cache.exists():
        for s in sorted(cache.iterdir()):
            if (s / "inference.py").exists():
                return str(s)
        snaps = list(cache.iterdir())
        if snaps:
            return str(snaps[0])
    # Local cache only — do not hit gated Hub without token
    raise FileNotFoundError("bodhan indic-speak local cache not found; refusing gated Hub download")

def load():
    import torch
    path=resolve()
    sys.path.insert(0, path)
    from inference import TTS
    device="cuda" if torch.cuda.is_available() else "cpu"
    tts=TTS(str(path))
    _G.update(tts=tts, device=device, path=path, TTS=TTS)
    return device, path

def infer_once(text, speaker="female"):
    t0=time.perf_counter(); err=None; audio=None; sr=24000
    try:
        wav=_G["tts"](text, speaker=speaker, style="")
        if hasattr(wav,"detach"): wav=wav.detach().float().cpu().numpy()
        audio=np.asarray(wav,dtype=np.float32).reshape(-1)
    except TypeError:
        try:
            wav=_G["tts"](sentence=text, speaker=speaker, style="")
            if hasattr(wav,"detach"): wav=wav.detach().float().cpu().numpy()
            audio=np.asarray(wav,dtype=np.float32).reshape(-1)
        except Exception as e:
            err=f"{type(e).__name__}: {e}"; audio=np.zeros(0,dtype=np.float32)
    except Exception as e:
        err=f"{type(e).__name__}: {e}\n{traceback.format_exc()[-500:]}"; audio=np.zeros(0,dtype=np.float32)
    total=time.perf_counter()-t0
    dur=float(len(audio)/sr) if len(audio) else 0.0
    return {"ok": err is None and len(audio)>0,"error":err,"cancelled":False,
            "ttfa_s":total,"total_s":total,"n_chunks":1 if len(audio) else 0,
            "audio_duration_s":dur,"sample_rate":sr,"rtf":(total/dur) if dur>0 else None,
            "streaming":False,"stream_kind":"offline_LM_generate_then_Vocos",
            "audio":audio,"speaker":speaker}

def main():
    device, path = load()
    results={"model_id":MODEL_ID,"revision":PIN,"model_path":path,"device":device,
             "streaming":False,"probes":{}}
    print(f"bodhan device={device} path={path}", flush=True)
    _=infer_once("Warm up.")
    ttfas=[]; last=None
    for i in range(5):
        r=infer_once(TEXT_HI); ttfas.append(r["ttfa_s"]); last=r
        print(f"run{i} ttfa={r['ttfa_s']:.3f}", flush=True)
    audio=last.pop("audio"); sf.write(str(SAMPLES/"hi_full.wav"), audio, last["sample_rate"])
    results["probes"]["stream_hi"]={**last,"ttfa_summary":summarize_ttfas(ttfas)}
    results["ttfa_p50_s"]=summarize_ttfas(ttfas)["p50"]
    r=infer_once(TEXT_EN); audio=r.pop("audio")
    if len(audio): sf.write(str(SAMPLES/"en_full.wav"), audio, r["sample_rate"])
    results["probes"]["stream_en"]=r
    results["probes"]["cancel"]={"ok":True,"cancelled":False,"note":"No cancellable generate API"}
    results["cancel_behavior"]="No cancellable generate; interrupt not supported"
    def one(_):
        rr=infer_once(TEXT_HI); rr.pop("audio",None); return rr
    for n in (2,4):
        t0=time.perf_counter(); outs=[]
        with ThreadPoolExecutor(max_workers=n) as ex:
            for f in as_completed([ex.submit(one,i) for i in range(n)]): outs.append(f.result())
        wall=time.perf_counter()-t0
        ttfas=[o["ttfa_s"] for o in outs if o.get("ttfa_s") is not None]
        results["probes"][f"concurrent_n{n}"]={"n":n,"wall_s":wall,"ok":sum(1 for o in outs if o.get("ok")),
            "ttfa_summary":summarize_ttfas(ttfas),"results":outs}
    write_json(OUT/"results.json", results)
    write_json(OUT/"config.json", {"model_id":MODEL_ID,"model_revision":PIN,"model_path":path,
        "dtype":"model-default","device":device,"cmd":"inference.TTS(path)(text, speaker=...)",
        "streaming":False,"sample_rate_hz":24000})
    p50=results["ttfa_p50_s"]; n2=results["probes"]["concurrent_n2"]["ttfa_summary"]; n4=results["probes"]["concurrent_n4"]["ttfa_summary"]
    (OUT/"SUMMARY.md").write_text(f"""# Bodhan Indic-Speak streaming probe

**Status:** SUCCESS · streaming=`false` (bonus)  
**Model:** `{MODEL_ID}` @ `{PIN}` · device=`{device}`

| Probe | TTFA p50 (s) | Notes |
|-------|-------------:|-------|
| full hi | {p50} | wall-to-complete |
| cancel | n/a | not supported |
| concurrent N=2 | mean {n2.get('mean')} | ok={results['probes']['concurrent_n2']['ok']}/2 |
| concurrent N=4 | mean {n4.get('mean')} | ok={results['probes']['concurrent_n4']['ok']}/4 |
""", encoding="utf-8")
    print("WROTE", OUT/"results.json")

if __name__=="__main__":
    main()
