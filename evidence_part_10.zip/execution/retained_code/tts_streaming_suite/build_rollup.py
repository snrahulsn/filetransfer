#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone, timedelta
IST = timezone(timedelta(hours=5, minutes=30))
ROOT = Path("/workspace/tts_streaming_suite")
VENDORS = [
    ("kokoro", "Kokoro", True),
    ("veena_maya", "Veena/Maya", False),
    ("mayal", "Mayal", False),
    ("indic_parler", "Indic Parler", True),
    ("indic_f5", "IndicF5", True),
    ("pocket_tts", "Pocket TTS", True),
    ("svara", "Svara-TTS", True),
    ("sooktam2", "Sooktam-2", True),
    ("bodhan_indic_speak", "Bodhan Indic-Speak (bonus)", False),
    ("voxtral_tts", "Voxtral TTS (bonus)", False),
]

def load(p: Path):
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))

def extract(name, data):
    if data is None:
        return {"vendor": name, "status": "MISSING_RESULTS", "streaming": None, "ttfa_p50_s": None,
                "cancel": None, "n2_mean": None, "n4_mean": None, "notes": "no results.json"}
    if data.get("status") in ("MISSING", "SKIPPED"):
        return {"vendor": name, "status": data["status"], "streaming": data.get("streaming"),
                "ttfa_p50_s": None, "cancel": None, "n2_mean": None, "n4_mean": None,
                "notes": data.get("reason") or data.get("note") or data["status"]}
    probes = data.get("probes") or {}
    row_notes = ""
    # svara shape uses nested probes without ttfa_p50 at top
    ttfa = data.get("ttfa_p50_s")
    if ttfa is None:
        # try stream_* summaries
        for k, v in probes.items():
            if k.startswith("stream") and isinstance(v, dict):
                if "ttfa_summary" in v and v["ttfa_summary"].get("p50") is not None:
                    ttfa = v["ttfa_summary"]["p50"]; break
                if v.get("ttfa_s") is not None:
                    ttfa = v["ttfa_s"]; break
    # svara key_ttfa from config
    cancel = probes.get("cancel") or probes.get("cancel_en")
    cancel_note = None
    if isinstance(cancel, dict):
        cancel_note = f"cancelled={cancel.get('cancelled')} ttfa={cancel.get('ttfa_s')}"
    n2 = probes.get("concurrent_n2") or {}
    n4 = probes.get("concurrent_n4") or {}
    def mean_of(block):
        if not isinstance(block, dict): return None
        s = block.get("ttfa_summary") or {}
        if s.get("mean") is not None: return s["mean"]
        if block.get("ttfa_s_mean") is not None: return block["ttfa_s_mean"]
        vals = block.get("ttfa_s_list") or []
        return (sum(vals)/len(vals)) if vals else None
    streaming = data.get("streaming")
    if streaming is None:
        for k,v in probes.items():
            if isinstance(v, dict) and "streaming" in v:
                streaming = v["streaming"]; break
    status = "OK" if ttfa is not None else ("OK" if data.get("stream_available") else "PARTIAL")
    # Downgrade if primary stream probe failed / empty audio
    for pk, pv in probes.items():
        if pk.startswith("stream") and isinstance(pv, dict):
            if pv.get("ok") is False or (pv.get("audio_duration_s") is not None and pv.get("audio_duration_s", 1) < 0.05):
                status = "FAIL"
                ttfa = None
                row_notes = pv.get("error") or "stream probe failed / empty audio"
                break
    else:
        row_notes = ""

    if name == "svara" and data.get("probes", {}).get("stream_hi"):
        # copy from known structure
        sh = data["probes"]["stream_hi"]
        se = data["probes"].get("stream_en", {})
        ttfa = sh.get("ttfa_s")
        # p50 approx from hi/en
        vals = [x for x in [sh.get("ttfa_s"), se.get("ttfa_s")] if x is not None]
        ttfa = sorted(vals)[len(vals)//2] if vals else ttfa
        status = "OK"
        streaming = True
        cancel = data["probes"].get("cancel_en")
        cancel_note = f"cancelled={cancel.get('cancelled')} ttfa={cancel.get('ttfa_s')} chunks={cancel.get('n_chunks')}" if cancel else None
        n2 = data["probes"].get("concurrent_n2", {})
        n4 = data["probes"].get("concurrent_n4", {})
    return {
        "vendor": name,
        "status": status,
        "streaming": streaming,
        "ttfa_p50_s": ttfa,
        "cancel": cancel_note or data.get("cancel_behavior"),
        "n2_mean": mean_of(n2),
        "n4_mean": mean_of(n4),
        "notes": (row_notes if "row_notes" in dir() and row_notes else None) or data.get("stream_kind") or data.get("fail_reason") or "",
        "model_id": data.get("model_id"),
        "revision": data.get("revision") or data.get("model_revision"),
        "device": data.get("device"),
    }

rows = []
configs = []
for key, label, _ in VENDORS:
    d = ROOT / key
    res = load(d / "results.json")
    cfg = load(d / "config.json")
    row = extract(key, res)
    row["label"] = label
    rows.append(row)
    configs.append({"vendor": key, "label": label, "config": cfg, "results_present": res is not None})

now = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")
lines = [
    f"# TTS streaming suite — rollup",
    f"",
    f"**Packaged:** {now}",
    f"**Volume:** `ul08t4z9qx` (retained — never deleted)",
    f"",
    f"## TTFA / interrupt / concurrent",
    f"",
    f"| Vendor | Status | streaming | TTFA p50 (s) | Cancel | N=2 mean TTFA | N=4 mean TTFA |",
    f"|--------|--------|-----------|-------------:|--------|--------------:|--------------:|",
]
for r in rows:
    def fmt(x):
        if x is None: return "—"
        if isinstance(x, float): return f"{x:.4f}"
        return str(x)[:60]
    lines.append(
        f"| {r['label']} | {r['status']} | {r['streaming']} | {fmt(r['ttfa_p50_s'])} | {fmt(r['cancel'])} | {fmt(r['n2_mean'])} | {fmt(r['n4_mean'])} |"
    )
lines += [
    "",
    "## Notes",
    "- TTFA = time-to-first-audio (first streamed chunk) when `streaming=true`; otherwise wall time to first full sample / complete WAV.",
    "- No fabricated stream metrics: vendors without a stream API are marked `streaming=false`.",
    "- Svara copied from `/workspace/svara_stream_probe` (not re-run).",
    "- Veena/Maya/Mayal marked MISSING when packs/models absent.",
    "",
    "## Per-vendor artifacts",
    "Each vendor dir: `scripts/`, `results.json`, `config.json`, `SUMMARY.md`, `samples/`.",
    "",
]
(ROOT / "SUMMARY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
(ROOT / "rollup.json").write_text(json.dumps({"packaged_at": now, "rows": rows}, indent=2) + "\n", encoding="utf-8")

cfg_md = [f"# CONFIGS — TTS streaming suite", f"", f"**Packaged:** {now}", f""]
for c in configs:
    cfg_md.append(f"## {c['label']} (`{c['vendor']}`)")
    cfg_md.append("```json")
    cfg_md.append(json.dumps(c["config"], indent=2, ensure_ascii=False) if c["config"] else "null")
    cfg_md.append("```")
    cfg_md.append("")
(ROOT / "CONFIGS.md").write_text("\n".join(cfg_md) + "\n", encoding="utf-8")
print("Wrote SUMMARY.md CONFIGS.md rollup.json")
for r in rows:
    print(f"  {r['label']}: status={r['status']} streaming={r['streaming']} ttfa_p50={r['ttfa_p50_s']}")
