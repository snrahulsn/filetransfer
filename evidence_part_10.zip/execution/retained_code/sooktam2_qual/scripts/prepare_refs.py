#!/usr/bin/env python3
"""Fetch short clean SPRINGLab/IndicTTS refs without torchcodec.

Decodes audio via soundfile only. Caps scan per locale; falls back to
model-bundled Hindi ref.wav when a locale cannot be resolved quickly.
"""
from __future__ import annotations

import io
import json
import os
import shutil
from pathlib import Path

os.environ["HF_DATASETS_AUDIO_BACKEND"] = "soundfile"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

OUT = Path(os.environ.get("QUAL_OUT") or os.environ.get("QUAL_OUT") or "/workspace/sooktam2_qual")
PROMPTS = OUT / "prompts"
PROMPTS.mkdir(parents=True, exist_ok=True)

SPRING = {
    "hi-IN": ("SPRINGLab/IndicTTS-Hindi", "hindi"),
    "mr-IN": ("SPRINGLab/IndicTTS_Marathi", "marathi"),
    "gu-IN": ("SPRINGLab/IndicTTS_Gujarati", "gujarati"),
    "ta-IN": ("SPRINGLab/IndicTTS_Tamil", "tamil"),
    "te-IN": ("SPRINGLab/IndicTTS_Telugu", "telugu"),
    "kn-IN": ("SPRINGLab/IndicTTS_Kannada", "kannada"),
    "bn-IN": ("SPRINGLab/IndicTTS_Bengali", "bengali"),
    "ml-IN": ("SPRINGLab/IndicTTS_Malayalam", "malayalam"),
    "or-IN": ("SPRINGLab/IndicTTS_Odia", "odia"),
    "pa-IN": ("SPRINGLab/IndicTTS_Punjabi", "punjabi"),
    "en-IN": ("SPRINGLab/IndicTTS-English", "english"),
}

BUNDLED_REF_TEXT = (
    "सर, मैं तब से यह कह रहा हूँ कि मैंने अपना टिकट कैंसल कर दिया है, "
    "लेकिन अब तक मेरे पैसे वापस नहीं आए हैं। आप इस मामले को देखेंगे भी या नहीं?"
)
MAX_SCAN = int(os.environ.get("REF_MAX_SCAN", "250"))
MIN_DUR = 2.5
PREF_DUR = 4.0


def is_female(g) -> bool:
    if g is None:
        return False
    if g == 0 or g == "0":
        return True
    s = str(g).strip().lower()
    return s in {"female", "f", "woman", "0"}


def write_wav(path: Path, audio, sr: int) -> float:
    import numpy as np
    import soundfile as sf

    a = np.asarray(audio, dtype=np.float32).reshape(-1)
    max_s = 8.0
    if len(a) / max(sr, 1) > max_s:
        a = a[: int(max_s * sr)]
    peak = float(abs(a).max()) if a.size else 0.0
    if peak > 0:
        a = a / peak * 0.95
    sf.write(str(path), a, int(sr))
    return float(len(a) / sr)


def decode_audio(audio_obj):
    import numpy as np
    import soundfile as sf

    if isinstance(audio_obj, dict) and audio_obj.get("array") is not None:
        return np.asarray(audio_obj["array"], dtype=np.float32).reshape(-1), int(audio_obj["sampling_rate"])
    if isinstance(audio_obj, dict) and audio_obj.get("bytes"):
        arr, sr = sf.read(io.BytesIO(audio_obj["bytes"]), dtype="float32")
        return np.asarray(arr, dtype=np.float32).reshape(-1), int(sr)
    if isinstance(audio_obj, dict) and audio_obj.get("path"):
        try:
            arr, sr = sf.read(audio_obj["path"], dtype="float32")
        except Exception:
            import librosa
            arr, sr = librosa.load(audio_obj["path"], sr=None, mono=True)
        return np.asarray(arr, dtype=np.float32).reshape(-1), int(sr)
    raise ValueError(f"bad audio obj: {type(audio_obj)} keys={list(audio_obj) if isinstance(audio_obj, dict) else None}")


def ensure_bundled() -> Path:
    from huggingface_hub import hf_hub_download

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    dest = PROMPTS / "bundled_ref.wav"
    if not dest.exists() or dest.stat().st_size < 1000:
        p = hf_hub_download(
            "bharatgenai/sooktam2", "ref.wav", token=token, local_dir=str(PROMPTS / "_bundle")
        )
        shutil.copy2(p, dest)
    return dest


def save_meta(locale, meta):
    (PROMPTS / f"{locale}_ref.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def pick_clip(ds_id: str, locale: str) -> dict:
    from datasets import Audio, load_dataset

    print(f"Streaming clips from {ds_id} for {locale} (soundfile, max_scan={MAX_SCAN})...", flush=True)
    ds = load_dataset(ds_id, split="train", streaming=True)
    try:
        ds = ds.cast_column("audio", Audio(decode=False))
    except Exception as e:
        print(f"  cast warn: {e}", flush=True)

    best = None  # (score, meta, arr, sr)
    any_ok = None
    for i, ex in enumerate(ds):
        if i >= MAX_SCAN:
            break
        text = (ex.get("text") or "").strip()
        if not text:
            continue
        try:
            arr, sr = decode_audio(ex["audio"])
        except Exception as e:
            if i < 5:
                print(f"  decode skip i={i}: {e}", flush=True)
            continue
        dur = float(arr.size / max(sr, 1))
        if dur < MIN_DUR or arr.size < int(sr * MIN_DUR):
            continue
        female = is_female(ex.get("gender"))
        # Prefer female + duration near PREF_DUR..8s
        score = (2 if female else 0) + min(dur, 8.0) / 8.0
        cand = {
            "locale": locale,
            "dataset": ds_id,
            "ref_wav": f"{locale}_ref.wav",
            "ref_text": text,
            "sample_rate": sr,
            "duration_s": round(min(dur, 8.0), 3),
            "gender": "female" if female else str(ex.get("gender")),
            "index_streamed": i,
            "license_note": "SPRINGLab IndicTTS; see dataset card (typically CC-BY-4.0)",
        }
        if any_ok is None:
            any_ok = (score, cand, arr, sr)
        if female and (best is None or score > best[0]):
            best = (score, cand, arr, sr)
            # early exit if good enough female clip
            if dur >= PREF_DUR:
                break
        if i and i % 50 == 0:
            print(f"  scanned {i} best_female={best is not None}", flush=True)

    chosen = best or any_ok
    if chosen is None:
        raise RuntimeError(f"No usable clip in first {MAX_SCAN} of {ds_id}")
    _, meta, arr, sr = chosen
    dur_w = write_wav(PROMPTS / meta["ref_wav"], arr, sr)
    meta["duration_s"] = round(dur_w, 3)
    save_meta(locale, meta)
    print(
        f"  OK {locale} gender={meta['gender']} dur~{meta['duration_s']}s text={meta['ref_text'][:60]}",
        flush=True,
    )
    return meta


def fallback_bundled(locale: str, cls_lang: str, reason: str) -> dict:
    bundled = ensure_bundled()
    dest = PROMPTS / f"{locale}_ref.wav"
    shutil.copy2(bundled, dest)
    meta = {
        "locale": locale,
        "dataset": "bharatgenai/sooktam2",
        "ref_wav": dest.name,
        "ref_text": BUNDLED_REF_TEXT,
        "cls_language": cls_lang,
        "gender": "unknown",
        "fallback": True,
        "fallback_reason": reason,
        "source": "model-bundled ref.wav (Hindi)",
    }
    save_meta(locale, meta)
    print(f"  FALLBACK {locale}: {reason}", flush=True)
    return meta


def main():
    ensure_bundled()
    catalog = {}
    for locale, (ds, cls_lang) in SPRING.items():
        meta_path = PROMPTS / f"{locale}_ref.json"
        wav_path = PROMPTS / f"{locale}_ref.wav"
        if (
            meta_path.exists()
            and wav_path.exists()
            and wav_path.stat().st_size > 20000  # reject tiny/weak refs
            and not json.loads(meta_path.read_text(encoding="utf-8")).get("fallback")
        ):
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            # re-fetch if duration too short
            if float(meta.get("duration_s") or 0) >= MIN_DUR:
                print(f"Reuse {locale}", flush=True)
                meta["cls_language"] = cls_lang
                catalog[locale] = meta
                continue
        try:
            meta = pick_clip(ds, locale)
            meta["cls_language"] = cls_lang
            catalog[locale] = meta
        except Exception as e:
            catalog[locale] = fallback_bundled(locale, cls_lang, f"{type(e).__name__}: {e}")

    # Urdu: always bundled Hindi ref (no SPRINGLab Urdu)
    catalog["ur-IN"] = fallback_bundled(
        "ur-IN", "urdu", "No SPRINGLab IndicTTS Urdu; using model-bundled Hindi ref"
    )

    out = PROMPTS / "refs_catalog.json"
    out.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    print("WROTE", out, "n=", len(catalog))
    for loc, m in catalog.items():
        print(f"  {loc}: {m.get('ref_wav')} dur={m.get('duration_s')} fallback={m.get('fallback', False)}")


if __name__ == "__main__":
    main()
