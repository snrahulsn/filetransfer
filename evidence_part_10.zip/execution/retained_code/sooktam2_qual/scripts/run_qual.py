from __future__ import annotations
import os
os.environ.setdefault("USE_TF", "0")
os.environ.setdefault("TRANSFORMERS_NO_TF", "1")
os.environ.setdefault("USE_TORCH", "1")

#!/usr/bin/env python3
"""On-prem qualification for bharatgenai/sooktam2 (12 locales)."""

import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(os.environ.get("QUAL_OUT") or os.environ.get("QUAL_OUT") or "/workspace/sooktam2_qual")
WAVS = OUT / "wavs"
WAVS.mkdir(parents=True, exist_ok=True)
PROMPTS = OUT / "prompts"
MODEL_ID = "bharatgenai/sooktam2"
PIN = os.environ.get("MODEL_REVISION", "eb270c0ceebd58e0e513820eb71c637e9f486a7b")
SAMPLE_RATE = 24000

LOCALES = [
    ("hi-IN", "आपकी बैठक कल दोपहर तीन बजे है।", "hindi", True),
    ("mr-IN", "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.", "marathi", True),
    ("gu-IN", "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.", "gujarati", True),
    ("ta-IN", "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.", "tamil", True),
    ("te-IN", "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.", "telugu", True),
    ("kn-IN", "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.", "kannada", True),
    ("bn-IN", "আপনার মিটিং আগামীকাল দুপুর তিনটায়।", "bengali", True),
    ("ml-IN", "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.", "malayalam", True),
    ("or-IN", "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।", "odia", True),
    ("ur-IN", "آپ کی میٹنگ کل دوپہر تین بجے ہے۔", "urdu", True),
    ("pa-IN", "ਤੁਹਾਡੀ ਮੀਟਿੰਗ ਕੱਲ੍ਹ ਦੁਪਹਿਰ ਤਿੰਨ ਵਜੇ ਹੈ।", "punjabi", True),
    ("en-IN", "Your meeting with Priya is tomorrow at three thirty PM.", "english", True),
]

WHISPER_LANG = {
    "hi-IN": "hi", "mr-IN": "mr", "gu-IN": "gu", "ta-IN": "ta", "te-IN": "te",
    "kn-IN": "kn", "bn-IN": "bn", "ml-IN": "ml", "or-IN": None, "ur-IN": "ur",
    "pa-IN": "pa", "en-IN": "en",
}


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def record_versions():
    pkgs = [
        "f5-tts", "transformers", "torch", "torchaudio", "soundfile",
        "huggingface_hub", "accelerate", "numpy", "openai-whisper", "jiwer",
        "librosa", "safetensors", "datasets",
    ]
    versions = {}
    for p in pkgs:
        try:
            out = subprocess.check_output(
                [sys.executable, "-m", "pip", "show", p], text=True, stderr=subprocess.DEVNULL
            )
            info = {}
            for line in out.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    info[k.strip()] = v.strip()
            versions[p] = {"version": info.get("Version"), "location": info.get("Location")}
        except Exception as e:
            versions[p] = {"version": None, "error": str(e)}
    freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)
    versions["pip_freeze_subset"] = [
        l for l in freeze.splitlines()
        if any(x.replace("-", "_").lower() in l.lower().replace("-", "_") for x in pkgs)
    ]
    write_text(OUT / "versions.json", json.dumps(versions, indent=2, ensure_ascii=False))
    return versions


def download_and_pin():
    from huggingface_hub import snapshot_download, HfApi

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    tip = HfApi(token=token).model_info(MODEL_ID).sha
    print(f"tip={tip} pin={PIN}", flush=True)
    local_dir = str(OUT / "model_cache" / "sooktam2")
    path = snapshot_download(
        MODEL_ID,
        revision=PIN,
        token=token,
        cache_dir="/workspace/hf_cache",
        local_dir=local_dir,
        local_dir_use_symlinks=False,
    )
    write_text(OUT / "model_revision.txt", PIN + "\n")
    write_text(OUT / "model_tip_sha.txt", tip + "\n")
    return PIN, path


def load_refs():
    cands = [
        PROMPTS / "refs_catalog.json",
        PROMPTS / "refs_catalog.json",
        *sorted(PROMPTS.glob("refs*.json")),
    ]
    for path in cands:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    raise FileNotFoundError(f"No refs catalog under {PROMPTS}")


def dump_results(revision, device, results):
    write_text(
        OUT / "results.json",
        json.dumps(
            {
                "model_id": MODEL_ID,
                "revision": revision,
                "prompt_policy": (
                    "Per-locale female SPRINGLab/IndicTTS ref (2-8s) with matching transcript; "
                    "ur-IN uses model-bundled Hindi ref.wav (no SPRINGLab Urdu set)."
                ),
                "device": device,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        ),
    )


def synthesize_all(revision, model_path):
    import numpy as np
    import soundfile as sf
    import torch
    from transformers import AutoModel

    device = "cuda" if torch.cuda.is_available() else "cpu"
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    print(f"Loading {MODEL_ID} on {device} from {model_path}", flush=True)
    model = AutoModel.from_pretrained(model_path, trust_remote_code=True, token=token)
    if hasattr(model, "to"):
        try:
            model = model.to(device)
        except Exception as e:
            print("model.to warn:", e, flush=True)

    refs = load_refs()
    results = []
    for locale, sentence, cls_lang, official in LOCALES:
        ref = refs[locale]
        ref_wav = PROMPTS / ref["ref_wav"]
        if not ref_wav.exists():
            alt = PROMPTS / f"{locale}_ref.wav"
            ref_wav = alt if alt.exists() else PROMPTS / "bundled_ref.wav"
        ref_text = ref.get("ref_text") or ref.get("text")
        rec = {
            "locale": locale,
            "sentence": sentence,
            "cls_language": cls_lang,
            "officially_supported": official,
            "supported": official,
            "experimental": False,
            "ref_audio_path": str(ref_wav),
            "ref_audio_name": ref_wav.name,
            "ref_text": ref_text,
            "ref_source": ref.get("dataset") or ref.get("source"),
            "success": False,
            "error": None,
            "sample_rate": SAMPLE_RATE,
            "wav_path": f"wavs/{locale}.wav",
        }
        out_wav = WAVS / f"{locale}.wav"
        print(f"=== Synth {locale} cls={cls_lang} ref={ref_wav.name} ===", flush=True)
        if out_wav.exists() and out_wav.stat().st_size > 1000 and os.environ.get("QUAL_FORCE") != "1":
            audio, sr = sf.read(str(out_wav))
            audio = np.asarray(audio).reshape(-1)
            peak = float(np.max(np.abs(audio))) if audio.size else 0.0
            if peak >= 1e-4:
                dur = float(len(audio) / sr)
                rec.update({
                    "success": True,
                    "audio_duration_s": round(dur, 4),
                    "sample_rate": int(sr),
                    "sha256": sha256_file(out_wav),
                    "num_samples": int(len(audio)),
                    "resumed_existing_wav": True,
                    "peak_abs": peak,
                })
                results.append(rec)
                dump_results(revision, device, results)
                continue
            print("  SILENCE existing — re-synth", flush=True)
        try:
            if device == "cuda":
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            with torch.no_grad():
                out = model.infer(
                    ref_file=str(ref_wav),
                    ref_text=ref_text,
                    gen_text=sentence,
                    tokenizer="cls",
                    cls_language=cls_lang,
                    file_wave=str(out_wav),
                )
            if device == "cuda":
                torch.cuda.synchronize()
            t1 = time.perf_counter()
            if isinstance(out, (tuple, list)) and len(out) >= 2:
                wav, sr = out[0], out[1]
                audio = np.asarray(wav).reshape(-1).astype(np.float32)
                if audio.size and float(np.max(np.abs(audio))) > 1.5:
                    audio = audio / 32768.0
                sr = int(sr or SAMPLE_RATE)
                sf.write(str(out_wav), audio, sr)
            audio, sr = sf.read(str(out_wav))
            audio = np.asarray(audio).reshape(-1).astype(np.float32)
            peak = float(np.max(np.abs(audio))) if audio.size else 0.0
            if peak < 1e-4 or audio.size < sr * 0.2:
                raise RuntimeError(f"SILENCE_OR_TOO_SHORT peak={peak} samples={audio.size}")
            dur = float(len(audio) / sr)
            synth = float(t1 - t0)
            rec.update({
                "success": True,
                "total_synthesis_time_s": round(synth, 4),
                "audio_duration_s": round(dur, 4),
                "RTF": round(synth / dur, 4) if dur > 0 else None,
                "sample_rate": int(sr),
                "sha256": sha256_file(out_wav),
                "num_samples": int(len(audio)),
                "peak_abs": peak,
            })
            print(f"  OK synth={synth:.3f}s dur={dur:.3f}s RTF={rec['RTF']} peak={peak:.4f}", flush=True)
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {e}"
            rec["traceback"] = traceback.format_exc()
            print(f"  FAIL {rec['error']}", flush=True)
        results.append(rec)
        dump_results(revision, device, results)

    del model
    if device == "cuda":
        torch.cuda.empty_cache()
    return results, device


def clipping_analysis(results):
    import numpy as np
    import soundfile as sf

    clips = []
    for r in results:
        locale = r["locale"]
        wav = WAVS / f"{locale}.wav"
        entry = {
            "locale": locale,
            "peak_dBFS": None,
            "clipped": False,
            "clipped_samples": 0,
            "total_samples": 0,
            "error": None,
        }
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            clips.append(entry)
            continue
        audio, sr = sf.read(str(wav), dtype="float64")
        audio = np.asarray(audio).reshape(-1)
        entry["total_samples"] = int(audio.size)
        peak = float(np.max(np.abs(audio))) if audio.size else 0.0
        entry["peak_dBFS"] = float("-inf") if peak <= 0 else round(20.0 * np.log10(peak), 4)
        n_clip = int((np.abs(audio) >= 0.999999).sum())
        entry["clipped_samples"] = n_clip
        entry["clipped"] = bool(n_clip > 0 and entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001)
        entry["flag_0dBFS_with_clipped_samples"] = bool(
            entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001 and n_clip > 0
        )
        clips.append(entry)
    write_text(OUT / "clipping.json", json.dumps({"clipping": clips}, indent=2))
    return clips


def normalize_text(s: str) -> str:
    import unicodedata
    import re

    s = unicodedata.normalize("NFC", s or "").strip().lower()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()


def compute_wer_cer(ref, hyp):
    from jiwer import cer, wer

    ref_n, hyp_n = normalize_text(ref), normalize_text(hyp)
    if not ref_n:
        return None, None, ref_n, hyp_n
    if not hyp_n:
        return 1.0, 1.0, ref_n, hyp_n
    try:
        w = float(wer(ref_n, hyp_n))
    except Exception:
        w = 1.0
    try:
        c = float(cer(ref_n, hyp_n))
    except Exception:
        c = 1.0
    return w, c, ref_n, hyp_n


def asr_all(results):
    import whisper
    import torch

    print("Loading Whisper large-v3...", flush=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    asr_model = whisper.load_model("large-v3", device=device)
    metrics = {
        "asr_model": "openai-whisper/large-v3",
        "failure_bar": "empty transcript OR WER>=0.9 OR CER>=0.9",
        "asr_notes": "Whisper large-v3; Odia auto-detect (no lang code).",
        "results": [],
    }
    for r in results:
        locale, sentence = r["locale"], r["sentence"]
        wav = WAVS / f"{locale}.wav"
        entry = {
            "locale": locale,
            "reference": sentence,
            "transcript": None,
            "WER": None,
            "CER": None,
            "pass": False,
            "error": None,
            "whisper_language": WHISPER_LANG.get(locale),
        }
        print(f"=== ASR {locale} ===", flush=True)
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            metrics["results"].append(entry)
            continue
        try:
            kwargs = {"fp16": device == "cuda"}
            lang = WHISPER_LANG.get(locale)
            if lang:
                kwargs.update({"language": lang, "task": "transcribe"})
            result = asr_model.transcribe(str(wav), **kwargs)
            transcript = (result.get("text") or "").strip()
            entry["transcript"] = transcript
            entry["detected_language"] = result.get("language")
            w, c, ref_n, hyp_n = compute_wer_cer(sentence, transcript)
            entry["WER"] = None if w is None else round(w, 4)
            entry["CER"] = None if c is None else round(c, 4)
            entry["ref_normalized"] = ref_n
            entry["hyp_normalized"] = hyp_n
            empty = not transcript
            fail = empty or (w is not None and w >= 0.9) or (c is not None and c >= 0.9)
            entry["pass"] = not fail
            entry["failure_reason"] = (
                "empty transcript" if empty else ("WER/CER >= 0.9" if fail else None)
            )
            print(
                f"  WER={entry['WER']} CER={entry['CER']} pass={entry['pass']} :: {transcript[:80]}",
                flush=True,
            )
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
            entry["traceback"] = traceback.format_exc()
            print(f"  FAIL {entry['error']}", flush=True)
        metrics["results"].append(entry)
        write_text(OUT / "asr_metrics.json", json.dumps(metrics, indent=2, ensure_ascii=False))
    return metrics


def write_environment(wall_start, device, revision, versions):
    import torch

    gpu = None
    if torch.cuda.is_available():
        gpu = {
            "name": torch.cuda.get_device_name(0),
            "capability": list(torch.cuda.get_device_capability(0)),
            "total_memory_gb": round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 2),
        }
    env = {
        "model_id": MODEL_ID,
        "revision": revision,
        "device": device,
        "gpu_vs_cpu": "GPU" if device == "cuda" else "CPU",
        "gpu": gpu,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "total_wall_clock_s": round(time.perf_counter() - wall_start, 2),
        "hostname": subprocess.check_output(["hostname"], text=True).strip(),
        "python": sys.version,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "key_versions": {
            k: (v.get("version") if isinstance(v, dict) else v)
            for k, v in versions.items()
            if k != "pip_freeze_subset"
        },
    }
    write_text(OUT / "environment.json", json.dumps(env, indent=2))
    return env


def main():
    wall = time.perf_counter()
    print("=== versions ===", flush=True)
    versions = record_versions()
    print("=== download ===", flush=True)
    revision, model_path = download_and_pin()
    print("=== synth ===", flush=True)
    results, device = synthesize_all(revision, model_path)
    print("=== clipping ===", flush=True)
    clipping_analysis(results)
    print("=== asr ===", flush=True)
    asr_all(results)
    print("=== env ===", flush=True)
    write_environment(wall, device, revision, versions)
    print("DONE sooktam2 qual core", flush=True)


if __name__ == "__main__":
    main()
