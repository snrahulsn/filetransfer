#!/bin/bash
set -euo pipefail
export HF_HOME=/workspace/hf_cache
export HUGGINGFACE_HUB_CACHE=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-}"
export PIP_CACHE_DIR=/workspace/hf_cache/pip
mkdir -p "$HF_HOME" "$PIP_CACHE_DIR" /workspace/sooktam2_qual/{wavs,scripts,prompts,model_cache}

echo "=== system ==="
apt-get update -qq
apt-get install -y -qq libsndfile1 ffmpeg git sox >/dev/null

echo "=== base python ==="
pip3 install -U pip wheel setuptools
pip3 install -U "torch==2.4.1" "torchaudio==2.4.1" --index-url https://download.pytorch.org/whl/cu124 || \
  pip3 install -U torch torchaudio

echo "=== sooktam2 CLS setup (clone tip + setup-cls.sh) ==="
CLONE=/workspace/sooktam2_qual/model_cache/sooktam2_src
if [ ! -f "$CLONE/setup-cls.sh" ]; then
  rm -rf "$CLONE"
  GIT_LFS_SKIP_SMUDGE=1 git clone https://huggingface.co/bharatgenai/sooktam2 "$CLONE"
fi
cd "$CLONE"
# setup-cls installs heavy TF deps; try, but continue if partial
bash setup-cls.sh 2>&1 | tee /workspace/sooktam2_qual/setup_cls.log || echo "setup-cls had errors; continuing"
pip3 install -e . --no-cache-dir 2>&1 | tee -a /workspace/sooktam2_qual/setup_cls.log || \
  pip3 install -U "f5-tts" || pip3 install -U "git+https://github.com/SWivid/F5-TTS.git"

pip3 install -U soundfile huggingface_hub accelerate sentencepiece protobuf safetensors
pip3 install -U openai-whisper jiwer librosa numpy datasets
pip3 install -U "transformers>=4.41.2,<4.50"

python3 -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)"
python3 -c "import f5_tts; print('f5_tts OK')" || python3 -c "from f5_tts.api import F5TTS; print('f5_tts.api OK')" || echo "f5_tts import soft-fail"
echo "INSTALL_OK"
