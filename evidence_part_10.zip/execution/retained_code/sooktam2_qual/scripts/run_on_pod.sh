#!/bin/bash
set -euo pipefail
export HF_TOKEN='[REDACTED]'
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
export HF_HOME=/workspace/hf_cache
export QUAL_OUT=/workspace/sooktam2_qual
export HF_DATASETS_AUDIO_BACKEND=soundfile
echo 'ljousqqvw86gll' > /workspace/sooktam2_qual/pod_id.txt
cd /workspace/sooktam2_qual
python3 scripts/prepare_refs.py 2>&1 | tee prepare_refs.log
python3 scripts/run_qual.py 2>&1 | tee qual.log
python3 scripts/package_results.py 2>&1 | tee -a qual.log || true
echo SOOKTAM_DONE
