# SUMMARY — Pocket TTS Indic + Indian English on-prem qualification

**Status:** COMPLETE  
**Packaged (IST):** 2026-09-16 15:23:04 IST

## Results at a glance

| Item | Outcome |
|------|---------|
| Official Indic support | **NONE** (en/fr/de/pt/it/es only) |
| Official tip SHA (`kyutai/pocket-tts`) | `492522650173a0653b7575cdc25ae09810e5d741` |
| English weight pin (package) | `@39592ff23c9ef80098bb74895d104c26275fe2c9` |
| Synth locales | **4/4** success |
| ASR WER/CER pass | **4/4** |
| Clipping 0 dBFS flags | 1 locales flagged |
| Runtime | Box **CPU** (`pocket-tts==3.1.0`); RunPod not used |
| Volume | N/A (local box); RunPod volume `ul08t4z9qx` untouched |

## Locale table (ASR)

| Locale | Model | Synth | WER | CER | ASR pass |
|--------|-------|-------|-----|-----|----------|
| en-IN | kyutai/pocket-tts | OK | 0.3 | 0.2222 | True |
| hi-IN | saryps-labs/pocket-tts-hindi | OK | 0.2 | 0.1154 | True |
| te-IN | prasadvittaldev/pocket-tts-telugu-female-syspin | OK | 0.3125 | 0.0882 | True |
| ta-IN | prasadvittaldev/pocket-tts-tamil-female-audiobook | OK | 0.0625 | 0.027 | True |

## Extra load probes

| Probe | Loadable |
|-------|----------|
| Thanushttk/pocket-tts-hindi | True |
| prasadvittaldev/pocket-tts-hindi-female-syspin | True |
| Arjun4707/pocket-tts-gu-base | False |

## Deliverables

`results.json`, `wavs/*.wav` (4), `asr_metrics.json`, `clipping.json`, `versions.json`, `environment.json`, `model_revision.txt`, `model_revisions.json`, `extra_load_probes.json`, `notes.md`, `SHA256SUMS`, `SUMMARY.md`, `license_check.md`, `scripts/run_qual.py`.

## Paths on box

`/workspace/pocket_tts_qual/`
