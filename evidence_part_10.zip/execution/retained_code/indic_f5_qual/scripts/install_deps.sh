#!/bin/bash
set -euo pipefail
export HF_HOME=/workspace/hf_cache
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN:-}"
export PIP_CACHE_DIR=/workspace/hf_cache/pip
mkdir -p "$HF_HOME" "$PIP_CACHE_DIR" /workspace/indic_f5_qual/{wavs,scripts,prompts,model_cache}

echo "=== Installing system deps ==="
apt-get update -qq
apt-get install -y -qq libsndfile1 ffmpeg git >/dev/null

echo "=== Installing Python packages ==="
pip3 install -U pip wheel setuptools
# IndicF5 package from GitHub (pulls f5_tts + deps)
pip3 install -U "git+https://github.com/ai4bharat/IndicF5.git"
pip3 install -U soundfile huggingface_hub accelerate sentencepiece protobuf safetensors
pip3 install -U openai-whisper jiwer librosa numpy
# transformers often needed with trust_remote_code AutoModel
pip3 install -U "transformers==4.49.0"
python3 -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)"

echo "=== pip show key pkgs ==="
for p in transformers torch soundfile huggingface_hub openai-whisper jiwer f5_tts; do
  pip3 show "$p" 2>/dev/null | egrep '^(Name|Version):' || echo "missing $p"
done
echo "INSTALL_OK"
