#!/bin/bash
set -euo pipefail
source /home/box/agent-data/runpod.env
export HF_TOKEN="${HF_TOKEN:-}"
OUT=/workspace/indic_f5_qual
SSH_KEY=/home/box/.ssh/runpod_smoke
PUB=$(cat ${SSH_KEY}.pub)
POD_ID_FILE=$OUT/pod_id.txt
EXISTING=i1ft2jagjtvn0k
UA="Mozilla/5.0"
API=https://api.runpod.io/graphql

gql() {
  local q="$1"
  curl -sS --max-time 90 -A "$UA" -H "Authorization: Bearer $RUNPOD_API_KEY" \
    -H "Content-Type: application/json" "$API" \
    -d "$(python3 -c "import json,sys; print(json.dumps({'query':sys.argv[1]}))" "$q")"
}

get_ports() {
  local pid="$1"
  gql "query { myself { pods { id desiredStatus runtime { ports { ip isIpPublic privatePort publicPort type } } } } }" \
    | python3 -c "
import json,sys
pid=sys.argv[1]
d=json.load(sys.stdin)
for p in d['data']['myself']['pods']:
  if p['id']==pid:
    print(p['desiredStatus'])
    rt=p.get('runtime') or {}
    for port in (rt.get('ports') or []):
      if port.get('privatePort')==22 and port.get('type')=='tcp':
        print(port['ip'], port['publicPort'])
        break
" "$pid"
}

try_resume() {
  echo "=== try resume $EXISTING ==="
  local r
  r=$(gql "mutation { podResume(input: { podId: \"$EXISTING\" }) { id desiredStatus costPerHr } }")
  echo "$r" | head -c 400; echo
  echo "$r" | python3 -c "import json,sys; d=json.load(sys.stdin); sys.exit(0 if d.get('data',{}).get('podResume') else 1)" && {
    echo "$EXISTING" > "$POD_ID_FILE"
    return 0
  }
  return 1
}

try_create() {
  python3 <<'PY'
import json, os, urllib.request, sys
API="https://api.runpod.io/graphql"
key=os.environ["RUNPOD_API_KEY"]
UA="Mozilla/5.0"
PUB=open("/home/box/.ssh/runpod_smoke.pub").read().strip()
HF=os.environ.get("HF_TOKEN","")

def gql(q):
    body=json.dumps({"query":q}).encode()
    req=urllib.request.Request(API,data=body,headers={
        "Authorization":f"Bearer {key}","Content-Type":"application/json","User-Agent":UA},method="POST")
    with urllib.request.urlopen(req,timeout=120) as resp:
        return json.loads(resp.read().decode())

gpus=[
 "NVIDIA RTX 6000 Ada Generation","NVIDIA RTX 5000 Ada Generation","NVIDIA GeForce RTX 4090",
 "NVIDIA GeForce RTX 3090","NVIDIA RTX A6000","NVIDIA RTX A5000","NVIDIA L40S","NVIDIA L40",
 "NVIDIA A40","NVIDIA GeForce RTX 4080","NVIDIA RTX 4000 Ada Generation","NVIDIA GeForce RTX 5090",
 "NVIDIA A100 80GB PCIe","NVIDIA RTX A4000","NVIDIA GeForce RTX 3080 Ti","NVIDIA GeForce RTX 3080",
]
for cloud in ["SECURE","COMMUNITY"]:
  for gpu in gpus:
    q=f'''mutation {{
      podFindAndDeployOnDemand(input: {{
        name: "indic-f5-qual"
        imageName: "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04"
        gpuTypeId: "{gpu}"
        gpuCount: 1
        cloudType: {cloud}
        dataCenterId: "US-IL-1"
        networkVolumeId: "ul08t4z9qx"
        volumeMountPath: "/workspace"
        containerDiskInGb: 40
        volumeInGb: 0
        ports: "22/tcp"
        supportPublicIp: true
        startSsh: true
        env: [{{ key: "PUBLIC_KEY", value: {json.dumps(PUB)} }}, {{ key: "HF_TOKEN", value: {json.dumps(HF)} }}]
      }}) {{
        id machine {{ gpuDisplayName dataCenterId }} desiredStatus costPerHr
      }}
    }}'''
    print(f"Try {cloud}/{gpu}", flush=True)
    try:
      r=gql(q)
    except Exception as e:
      print(" EXC", e); continue
    if r.get("errors"):
      print(" ", r["errors"][0].get("message","")[:120]); continue
    pod=r["data"]["podFindAndDeployOnDemand"]
    print("CREATED", pod)
    open("/workspace/indic_f5_qual/pod_create.json","w").write(json.dumps(r,indent=2))
    open("/workspace/indic_f5_qual/pod_id.txt","w").write(pod["id"]+"\n")
    sys.exit(0)
sys.exit(2)
PY
}

wait_ssh() {
  local pid="$1"
  local i=0
  while [ $i -lt 90 ]; do
    local info
    info=$(get_ports "$pid" || true)
    echo "[wait $i] $info"
    local status ip port
    status=$(echo "$info" | sed -n '1p')
    ip=$(echo "$info" | sed -n '2p' | awk '{print $1}')
    port=$(echo "$info" | sed -n '2p' | awk '{print $2}')
    if [ "$status" = "RUNNING" ] && [ -n "${ip:-}" ] && [ -n "${port:-}" ]; then
      echo "$ip" > "$OUT/pod_ip.txt"
      echo "$port" > "$OUT/pod_port.txt"
      # try ssh
      if ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
          -o ConnectTimeout=10 -p "$port" root@"$ip" 'echo SSH_OK; hostname; nvidia-smi -L' 2>/dev/null; then
        return 0
      fi
    fi
    i=$((i+1))
    sleep 5
  done
  return 1
}

# Main: retry until pod up (max ~45 min)
deadline=$(( $(date +%s) + 5400 ))
POD=""
while [ $(date +%s) -lt $deadline ]; do
  if try_resume || try_create; then
    POD=$(cat "$POD_ID_FILE")
    echo "POD=$POD"
    if wait_ssh "$POD"; then
      echo "POD_READY"
      break
    else
      echo "SSH wait failed; stop and retry"
      gql "mutation { podStop(input: { podId: \"$POD\" }) { id desiredStatus } }" || true
      sleep 20
    fi
  else
    echo "No capacity; sleep 45s"
    sleep 45
  fi
done

if [ ! -f "$OUT/pod_ip.txt" ]; then
  echo "FAILED to get pod"; exit 1
fi

IP=$(cat "$OUT/pod_ip.txt")
PORT=$(cat "$OUT/pod_port.txt")
POD=$(cat "$POD_ID_FILE")
SSH=(ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -p "$PORT" root@"$IP")
SCP=(scp -i "$SSH_KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -P "$PORT")

echo "=== Deploy scripts to pod volume ==="
# Ensure dest dirs on volume (pod /workspace is the network volume)
"${SSH[@]}" 'mkdir -p /workspace/indic_f5_qual/{scripts,wavs,prompts}'

# Sync scripts + prompts from box
"${SCP[@]}" -r "$OUT/scripts" root@"$IP":/workspace/indic_f5_qual/
"${SCP[@]}" "$OUT/prompts/"*.wav root@"$IP":/workspace/indic_f5_qual/prompts/ || true
"${SCP[@]}" "$OUT/license_check.md" root@"$IP":/workspace/indic_f5_qual/ || true

echo "=== Sync model_cache to volume (if present on box) ==="
if [ -d "$OUT/model_cache/IndicF5" ]; then
  "${SSH[@]}" "mkdir -p /workspace/indic_f5_qual/model_cache"
  rsync -az -e "ssh -i $SSH_KEY -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -p $PORT" \
    "$OUT/model_cache/IndicF5/" root@"$IP":/workspace/indic_f5_qual/model_cache/IndicF5/ || \
  "${SCP[@]}" -r "$OUT/model_cache/IndicF5" root@"$IP":/workspace/indic_f5_qual/model_cache/
fi


echo "=== Install + run qual on pod ==="
"${SSH[@]}" "bash -lc '
set -euo pipefail
export HF_TOKEN=\"$HF_TOKEN\"
export HUGGING_FACE_HUB_TOKEN=\"$HF_TOKEN\"
export QUAL_OUT=/workspace/indic_f5_qual
export MODEL_REVISION=ba85abedf18dc479a447eaa0eccbd76ab78a47d5
export HF_HOME=/workspace/hf_cache
cd /workspace/indic_f5_qual
bash scripts/install_deps.sh 2>&1 | tee install.log
python3 scripts/run_qual.py 2>&1 | tee qual.log
python3 scripts/package_results.py 2>&1 | tee -a qual.log
echo POD_QUAL_DONE
'"

echo "=== Copy results back to box ==="
mkdir -p "$OUT/wavs"
"${SCP[@]}" -r root@"$IP":/workspace/indic_f5_qual/results.json \
  root@"$IP":/workspace/indic_f5_qual/asr_metrics.json \
  root@"$IP":/workspace/indic_f5_qual/clipping.json \
  root@"$IP":/workspace/indic_f5_qual/versions.json \
  root@"$IP":/workspace/indic_f5_qual/environment.json \
  root@"$IP":/workspace/indic_f5_qual/model_revision.txt \
  root@"$IP":/workspace/indic_f5_qual/notes.md \
  root@"$IP":/workspace/indic_f5_qual/SUMMARY.md \
  root@"$IP":/workspace/indic_f5_qual/SHA256SUMS \
  root@"$IP":/workspace/indic_f5_qual/license_check.md \
  root@"$IP":/workspace/indic_f5_qual/install.log \
  root@"$IP":/workspace/indic_f5_qual/qual.log \
  "$OUT/" || true
"${SCP[@]}" root@"$IP":/workspace/indic_f5_qual/wavs/*.wav "$OUT/wavs/" || true
# also refresh scripts from pod if package updated
"${SCP[@]}" -r root@"$IP":/workspace/indic_f5_qual/prompts "$OUT/" || true

echo "=== Stop pod (retain volume) ==="
gql "mutation { podStop(input: { podId: \"$POD\" }) { id desiredStatus } }"
echo STOPPED "$POD"
echo ALL_DONE
