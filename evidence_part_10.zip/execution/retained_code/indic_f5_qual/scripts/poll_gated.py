#!/usr/bin/env python3
"""Poll HF gated access for IndicF5. Exit 0 when download works, 1 on timeout."""
import os, sys, time
from datetime import datetime, timezone

def ist_now():
    # box is Asia/Kolkata
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S IST")

TOKEN = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
INTERVAL = int(os.environ.get("POLL_INTERVAL_S", "180"))  # 3 min
MAX_WAIT = int(os.environ.get("POLL_MAX_S", "1800"))  # 30 min
OUT = os.environ.get("QUAL_OUT", "/workspace/indic_f5_qual")

def try_download():
    from huggingface_hub import hf_hub_download
    p = hf_hub_download(
        "ai4bharat/IndicF5",
        "config.json",
        token=TOKEN,
        revision="ba85abedf18dc479a447eaa0eccbd76ab78a47d5",
    )
    return p

def main():
    t0 = time.time()
    attempt = 0
    while True:
        attempt += 1
        elapsed = time.time() - t0
        print(f"[{ist_now()}] attempt={attempt} elapsed={elapsed:.0f}s trying config.json...", flush=True)
        try:
            p = try_download()
            print(f"ACCESS_OK path={p}", flush=True)
            open(os.path.join(OUT, "ACCESS_OK"), "w").write(f"{ist_now()}\n{p}\n")
            # remove STATUS_BLOCKED if present once access works
            return 0
        except Exception as e:
            print(f"  still blocked: {type(e).__name__}: {e}", flush=True)
        if elapsed >= MAX_WAIT:
            print("POLL_TIMEOUT", flush=True)
            return 1
        sleep_for = min(INTERVAL, max(1, MAX_WAIT - int(elapsed)))
        print(f"  sleeping {sleep_for}s...", flush=True)
        time.sleep(sleep_for)

if __name__ == "__main__":
    sys.exit(main())
