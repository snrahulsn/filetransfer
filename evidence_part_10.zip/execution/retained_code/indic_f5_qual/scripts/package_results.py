#!/usr/bin/env python3
"""Write SUMMARY.md, notes.md, SHA256SUMS after qual core completes."""
from __future__ import annotations
import hashlib, json, os, subprocess
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

OUT = Path(os.environ.get("QUAL_OUT", "/workspace/indic_f5_qual"))
IST = ZoneInfo("Asia/Kolkata")

def ist_stamp():
    return datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S IST")

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    results = json.loads((OUT / "results.json").read_text())
    asr = json.loads((OUT / "asr_metrics.json").read_text())
    clip = json.loads((OUT / "clipping.json").read_text())
    env = json.loads((OUT / "environment.json").read_text())
    revision = (OUT / "model_revision.txt").read_text().strip()
    pod_id = (OUT / "pod_id.txt").read_text().strip() if (OUT / "pod_id.txt").exists() else "UNKNOWN"
    stamp = ist_stamp()

    synth_ok = sum(1 for r in results["results"] if r.get("success"))
    synth_n = len(results["results"])
    asr_ok = sum(1 for r in asr["results"] if r.get("pass"))
    asr_n = len(asr["results"])
    fail_locales = [r["locale"] for r in asr["results"] if not r.get("pass")]
    clip_flags = sum(1 for c in clip["clipping"] if c.get("flag_0dBFS_with_clipped_samples"))

    # Locale table
    asr_by = {r["locale"]: r for r in asr["results"]}
    synth_by = {r["locale"]: r for r in results["results"]}
    rows = []
    for r in results["results"]:
        loc = r["locale"]
        a = asr_by.get(loc, {})
        rows.append(
            f"| {loc} | {'OK' if r.get('success') else 'FAIL'} | {a.get('WER')} | {a.get('CER')} | {a.get('pass')} | "
            f"{'official' if r.get('officially_supported') else 'experimental'} |"
        )

    summary = f"""# SUMMARY — ai4bharat/IndicF5 on-prem qualification

**Status:** COMPLETE  
**Packaged (IST):** {stamp}

## Results at a glance

| Item | Outcome |
|------|---------|
| Model revision | `{revision}` |
| Snapshot download | OK |
| Synth locales | **{synth_ok}/{synth_n}** success |
| ASR WER/CER pass | **{asr_ok}/{asr_n}** (fail: {', '.join(fail_locales) or 'none'}) |
| Clipping 0 dBFS flags | {clip_flags} locales flagged |
| Streaming | **N/A** (IndicF5 voice-clone batch API; no streamer tested) |
| Ref prompt | `{results.get('ref_audio_name')}` (female happy; consistent across locales) |
| Pod | `{pod_id}` |
| Volume | `ul08t4z9qx` indic-voice 200GB — **retained** |

## Locale table (ASR)

| Locale | Synth | WER | CER | ASR pass | Support |
|--------|-------|-----|-----|----------|---------|
{chr(10).join(rows)}

## Assamese sentence (crafted)

`as-IN`: আপোনাৰ প্ৰিয়াৰ সৈতে মিটিং কাইলৈ দুপৰীয়া তিনি বজাত।  
(Meeting/time with name Priya, analogous to Parler en-IN / Hindi meeting sentences.)

## Deliverables

`results.json`, `wavs/*.wav`, `asr_metrics.json`, `clipping.json`, `versions.json`,
`environment.json`, `model_revision.txt`, `notes.md`, `SHA256SUMS`, `SUMMARY.md`,
`license_check.md`, `scripts/`, `prompts/`.

## Paths on box

`/workspace/indic_f5_qual/`
"""
    (OUT / "SUMMARY.md").write_text(summary)

    notes = f"""# Notes — IndicF5 qualification

**Packaged (IST):** {stamp}

## Streaming observation

**Streaming is N/A** for this evidence pack. IndicF5 is used via the batch
`AutoModel` forward (`text`, `ref_audio_path`, `ref_text`) voice-clone API.
No streaming / chunked playback path was tested.

## Prompt / voice-clone policy

- Single consistent **female happy** reference: `prompts/PAN_F_HAPPY_00001.wav`
  (official README example; also present in HF `prompts/` after gated download).
- Matching `ref_text` (Punjabi) from the model README.
- Same prompt for all 12 locale rows so speaker identity stays fixed.
- Source of prompt wav before gated Agree: public GitHub raw URL under
  `AI4Bharat/IndicF5/prompts/`.

## en-IN experimental

`en-IN` is **not** in the official IndicF5 language list (11 Indian languages).
It was attempted anyway. Meta fields: `officially_supported=false`,
`experimental=true`; on synth failure set `supported=false`.

## What ran

- Pod: `{pod_id}` (network volume `ul08t4z9qx`, US-IL-1).
- Model: `ai4bharat/IndicF5` @ `{revision}` via `snapshot_download`.
- Synth: 11 official + en-IN experimental.
- ASR: openai-whisper large-v3; Assamese/Odia without forced language code.
- Clipping analysis on all wavs.

## ASR pass bar

Failure if empty transcript OR WER>=0.9 OR CER>=0.9.

ASR pass count: **{asr_ok}/{asr_n}**. Failed locales: {', '.join(fail_locales) or 'none'}.

## Environment highlights

- GPU: {env.get('gpu')}
- torch: {env.get('torch_version')}; device: {env.get('device')}
- Wall clock (qual core): {env.get('total_wall_clock_s')}s

## Caveats

- Gated HF Agree required before first successful download.
- Network volume retained; pod STOPPED after copy-out (never delete volume).
"""
    (OUT / "notes.md").write_text(notes)

    # SHA256SUMS
    lines = []
    for p in sorted(OUT.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(OUT)
        s = str(rel)
        if s.startswith("model_cache/") or s.startswith("_") or s in ("poll.log", "poll.pid", "qual.log", "install.log", "ACCESS_OK"):
            continue
        if "/__pycache__/" in s or s.endswith(".pyc"):
            continue
        lines.append(f"{sha256_file(p)}  {s}")
    (OUT / "SHA256SUMS").write_text("\n".join(lines) + "\n")
    print("PACKAGED", stamp)

if __name__ == "__main__":
    main()
