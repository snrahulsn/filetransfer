#!/usr/bin/env python3
"""Full on-prem qualification for ai4bharat/IndicF5."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(os.environ.get("QUAL_OUT", "/workspace/indic_f5_qual"))
WAVS = OUT / "wavs"
WAVS.mkdir(parents=True, exist_ok=True)
PROMPTS = OUT / "prompts"
MODEL_ID = "ai4bharat/IndicF5"
PIN = os.environ.get("MODEL_REVISION", "ba85abedf18dc479a447eaa0eccbd76ab78a47d5")
SAMPLE_RATE = 24000

# Consistent voice-clone prompt (female, happy/calm) — official README example.
# Same ref for all locales so speaker identity is held constant across the matrix.
REF_AUDIO_NAME = "PAN_F_HAPPY_00001.wav"
REF_TEXT = (
    "ਭਹੰਪੀ ਵਿੱਚ ਸਮਾਰਕਾਂ ਦੇ ਭਵਨ ਨਿਰਮਾਣ ਕਲਾ ਦੇ ਵੇਰਵੇ ਗੁੰਝਲਦਾਰ ਅਤੇ ਹੈਰਾਨ ਕਰਨ ਵਾਲੇ ਹਨ, "
    "ਜੋ ਮੈਨੂੰ ਖੁਸ਼ ਕਰਦੇ  ਹਨ।"
)

# Official 11 + experimental en-IN.
# Overlapping locales reuse the SAME fixed sentences as indic_parler_qual.
# Assamese crafted: meeting/time with name "Priya" analogous to en-IN.
LOCALES = [
    ("as-IN", "আপোনাৰ প্ৰিয়াৰ সৈতে মিটিং কাইলৈ দুপৰীয়া তিনি বজাত।", True),
    ("bn-IN", "আপনার মিটিং আগামীকাল দুপুর তিনটায়।", True),
    ("gu-IN", "તમારી મીટિંગ આવતીકાલે બપોરે ત્રણ વાગ્યે છે.", True),
    ("hi-IN", "आपकी बैठक कल दोपहर तीन बजे है।", True),
    ("kn-IN", "ನಿಮ್ಮ ಮೀಟಿಂಗ್ ನಾಳೆ ಮಧ್ಯಾಹ್ನ ಮೂರು ಗಂಟೆಗೆ ಇದೆ.", True),
    ("ml-IN", "നിങ്ങളുടെ മീറ്റിംഗ് നാളെ ഉച്ചയ്ക്ക് മൂന്ന് മണിക്കാണ്.", True),
    ("mr-IN", "तुमची मीटिंग उद्या दुपारी तीन वाजता आहे.", True),
    ("or-IN", "ଆପଣଙ୍କ ମିଟିଂ ଆସନ୍ତାକାଲି ଦ୍ୱିପ୍ରହର ତିନିଟାରେ ଅଛି।", True),
    ("pa-IN", "ਤੁਹਾਡੀ ਮੀਟਿੰਗ ਕੱਲ੍ਹ ਦੁਪਹਿਰ ਤਿੰਨ ਵਜੇ ਹੈ।", True),
    ("ta-IN", "உங்கள் சந்திப்பு நாளை மதியம் மூன்று மணிக்கு.", True),
    ("te-IN", "మీ మీటింగ్ రేపు మధ్యాహ్నం మూడు గంటలకు ఉంది.", True),
    ("en-IN", "Your meeting with Priya is tomorrow at three thirty PM.", False),  # experimental
]

WHISPER_LANG = {
    "as-IN": None,  # Assamese not in Whisper large-v3 language list; auto-detect
    "bn-IN": "bn",
    "gu-IN": "gu",
    "hi-IN": "hi",
    "kn-IN": "kn",
    "ml-IN": "ml",
    "mr-IN": "mr",
    "or-IN": None,  # Odia not in Whisper; auto-detect
    "pa-IN": "pa",
    "ta-IN": "ta",
    "te-IN": "te",
    "en-IN": "en",
}



def write_text_utf8(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def record_versions():
    pkgs = [
        "f5_tts",
        "transformers",
        "torch",
        "torchaudio",
        "soundfile",
        "huggingface_hub",
        "accelerate",
        "sentencepiece",
        "protobuf",
        "numpy",
        "openai-whisper",
        "jiwer",
        "librosa",
        "vocos",
        "safetensors",
    ]
    versions = {}
    for p in pkgs:
        try:
            out = subprocess.check_output(
                [sys.executable, "-m", "pip", "show", p], text=True, stderr=subprocess.DEVNULL
            )
            info = {}
            for line in out.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    info[k.strip()] = v.strip()
            versions[p] = {"version": info.get("Version"), "location": info.get("Location")}
        except Exception as e:
            versions[p] = {"version": None, "error": str(e)}
    freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)
    interesting = []
    for line in freeze.splitlines():
        name = line.split("==")[0].split("@")[0].lower().replace("-", "_")
        if any(p.lower().replace("-", "_") in name for p in pkgs):
            interesting.append(line)
    versions["pip_freeze_subset"] = interesting
    write_text_utf8(OUT / "versions.json", json.dumps(versions, indent=2, ensure_ascii=False))
    return versions


def download_and_pin():
    from huggingface_hub import snapshot_download, HfApi

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    api = HfApi(token=token)
    info = api.model_info(MODEL_ID)
    tip_sha = info.sha
    print(f"Model tip sha from API: {tip_sha}; using pin: {PIN}", flush=True)

    cache_dir = "/workspace/hf_cache"
    local_dir = str(OUT / "model_cache" / "IndicF5")
    # Prefer existing local snapshot (may include our patched model.py)
    if Path(local_dir).joinpath("model.safetensors").exists() and Path(local_dir).joinpath("model.py").exists():
        print(f"Reusing existing local snapshot at {local_dir}", flush=True)
        path = local_dir
    else:
        path = snapshot_download(
            repo_id=MODEL_ID,
            revision=PIN,
            token=token,
            cache_dir=cache_dir,
            local_dir=local_dir,
            local_dir_use_symlinks=False,
        )
    write_text_utf8(OUT / "model_revision.txt", PIN + "\n")
    print(f"Downloaded to {path}, pinned revision={PIN}", flush=True)

    # Ensure prompts available next to OUT (copy from HF snapshot if present)
    snap_prompts = Path(path) / "prompts"
    PROMPTS.mkdir(parents=True, exist_ok=True)
    if snap_prompts.is_dir():
        for wav in snap_prompts.glob("*.wav"):
            dest = PROMPTS / wav.name
            if not dest.exists():
                shutil.copy2(wav, dest)
                print(f"Copied prompt {wav.name} from snapshot", flush=True)
    return PIN, path


def ensure_ref_audio() -> Path:
    ref = PROMPTS / REF_AUDIO_NAME
    if not ref.exists():
        raise FileNotFoundError(
            f"Missing reference prompt {ref}. Expected female PAN_F_HAPPY wav under prompts/."
        )
    return ref


def synthesize_all(revision: str, model_path: str):
    import numpy as np
    import soundfile as sf
    import torch
    from transformers import AutoModel

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading IndicF5 on {device} revision={revision} path={model_path}", flush=True)

    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    # Prefer local snapshot dir (has model.safetensors + prompts + remote code)
    load_id = model_path if model_path else MODEL_ID
    model = AutoModel.from_pretrained(
        load_id,
        trust_remote_code=True,
        token=token,
    )
    # Ensure device attr used by INF5Model.forward
    # INF5Model uses infer_device (PreTrainedModel.device is a read-only property)
    model.infer_device = torch.device(device)
    if hasattr(model, "ema_model"):
        model.ema_model = model.ema_model.to(device)
    if hasattr(model, "vocoder"):
        model.vocoder = model.vocoder.to(device)

    ref_path = ensure_ref_audio()
    results = []
    for locale, sentence, officially_supported in LOCALES:
        rec = {
            "locale": locale,
            "sentence": sentence,
            "officially_supported": officially_supported,
            "supported": officially_supported,  # may flip false for en-IN on failure
            "experimental": not officially_supported,
            "ref_audio_path": str(ref_path),
            "ref_audio_name": REF_AUDIO_NAME,
            "ref_text": REF_TEXT,
            "success": False,
            "error": None,
            "total_synthesis_time_s": None,
            "audio_duration_s": None,
            "RTF": None,
            "sample_rate": SAMPLE_RATE,
            "sha256": None,
            "wav_path": f"wavs/{locale}.wav",
        }
        out_wav = WAVS / f"{locale}.wav"
        print(f"=== Synth {locale} (official={officially_supported}) ===", flush=True)
        if out_wav.exists() and out_wav.stat().st_size > 1000 and os.environ.get("QUAL_FORCE") != "1":
            try:
                import soundfile as sf
                import numpy as np
                audio, sr = sf.read(str(out_wav))
                audio = np.asarray(audio).reshape(-1)
                dur = float(len(audio) / sr) if sr else 0.0
                rec.update({
                    "success": True,
                    "total_synthesis_time_s": None,
                    "audio_duration_s": round(dur, 4),
                    "RTF": None,
                    "sample_rate": int(sr),
                    "sha256": sha256_file(out_wav),
                    "num_samples": int(len(audio)),
                    "resumed_existing_wav": True,
                })
                print(f"  RESUME existing wav dur={dur:.3f}s", flush=True)
                results.append(rec)
                write_text_utf8(OUT / "results.json", json.dumps({
                    "model_id": MODEL_ID,
                    "revision": revision,
                    "ref_audio_name": REF_AUDIO_NAME,
                    "ref_text": REF_TEXT,
                    "prompt_policy": (
                        "Single consistent female happy Punjabi prompt "
                        f"{REF_AUDIO_NAME} (README example) for all locales; voice-clone style."
                    ),
                    "device": device,
                    "results": results,
                }, indent=2, ensure_ascii=False))
                continue
            except Exception as e:
                print(f"  resume failed ({e}); re-synth", flush=True)
        try:
            if device == "cuda":
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            with torch.no_grad():
                audio = model(
                    sentence,
                    ref_audio_path=str(ref_path),
                    ref_text=REF_TEXT,
                )
            if device == "cuda":
                torch.cuda.synchronize()
            t1 = time.perf_counter()

            audio = np.asarray(audio)
            if audio.dtype == np.int16:
                audio = audio.astype(np.float32) / 32768.0
            else:
                audio = audio.astype(np.float32)
            audio = audio.reshape(-1)
            sr = SAMPLE_RATE
            sf.write(str(out_wav), audio, sr)
            dur = float(len(audio) / sr)
            synth = float(t1 - t0)
            rec.update(
                {
                    "success": True,
                    "total_synthesis_time_s": round(synth, 4),
                    "audio_duration_s": round(dur, 4),
                    "RTF": round(synth / dur, 4) if dur > 0 else None,
                    "sample_rate": sr,
                    "sha256": sha256_file(out_wav),
                    "num_samples": int(len(audio)),
                }
            )
            print(f"  OK synth={synth:.3f}s dur={dur:.3f}s RTF={rec['RTF']}", flush=True)
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {e}"
            rec["traceback"] = traceback.format_exc()
            if not officially_supported:
                rec["supported"] = False
                rec["experimental_note"] = (
                    "en-IN not in official IndicF5 language list; attempt failed or unsupported."
                )
            print(f"  FAIL {rec['error']}", flush=True)
        results.append(rec)
        write_text_utf8(OUT / "results.json", 
            json.dumps(
                {
                    "model_id": MODEL_ID,
                    "revision": revision,
                    "ref_audio_name": REF_AUDIO_NAME,
                    "ref_text": REF_TEXT,
                    "prompt_policy": (
                        "Single consistent female happy Punjabi prompt "
                        f"{REF_AUDIO_NAME} (README example) for all locales; voice-clone style."
                    ),
                    "device": device,
                    "results": results,
                },
                indent=2,
                ensure_ascii=False,
            )
        )

    del model
    if device == "cuda":
        torch.cuda.empty_cache()
    return results, device


def clipping_analysis(results):
    import numpy as np
    import soundfile as sf

    clips = []
    for r in results:
        locale = r["locale"]
        wav = WAVS / f"{locale}.wav"
        entry = {
            "locale": locale,
            "peak_dBFS": None,
            "clipped": False,
            "clipped_samples": 0,
            "total_samples": 0,
            "error": None,
        }
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            clips.append(entry)
            continue
        audio, sr = sf.read(str(wav), dtype="float64")
        audio = np.asarray(audio).reshape(-1)
        entry["total_samples"] = int(audio.size)
        peak = float(np.max(np.abs(audio))) if audio.size else 0.0
        if peak <= 0:
            entry["peak_dBFS"] = float("-inf")
        else:
            entry["peak_dBFS"] = round(20.0 * np.log10(peak), 4)
        clipped_mask = np.abs(audio) >= 0.999999
        n_clip = int(clipped_mask.sum())
        entry["clipped_samples"] = n_clip
        entry["clipped"] = bool(n_clip > 0 and entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001)
        entry["flag_0dBFS_with_clipped_samples"] = bool(
            entry["peak_dBFS"] is not None and entry["peak_dBFS"] >= -0.001 and n_clip > 0
        )
        clips.append(entry)
    write_text_utf8(OUT / "clipping.json", json.dumps({"clipping": clips}, indent=2))
    return clips


def normalize_text(s: str) -> str:
    import unicodedata
    import re

    s = unicodedata.normalize("NFC", s or "")
    s = s.strip().lower()
    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def compute_wer_cer(ref: str, hyp: str):
    from jiwer import cer, wer

    ref_n = normalize_text(ref)
    hyp_n = normalize_text(hyp)
    if not ref_n:
        return None, None, ref_n, hyp_n
    if not hyp_n:
        return 1.0, 1.0, ref_n, hyp_n
    try:
        w = float(wer(ref_n, hyp_n))
    except Exception:
        w = 1.0
    try:
        c = float(cer(ref_n, hyp_n))
    except Exception:
        c = 1.0
    return w, c, ref_n, hyp_n


def asr_all(results):
    import whisper
    import torch

    print("Loading Whisper large-v3 for ASR...", flush=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    asr_model = whisper.load_model("large-v3", device=device)
    asr_name = "openai-whisper/large-v3"

    metrics = {
        "asr_model": asr_name,
        "asr_notes": (
            "Whisper large-v3 multilingual used for all locales. "
            "Assamese (as-IN) and Odia (or-IN) have no dedicated Whisper language code; "
            "transcribed with auto-detect. Failure bar: empty transcript OR WER/CER >= ~0.9."
        ),
        "failure_bar": "empty transcript OR WER>=0.9 OR CER>=0.9",
        "results": [],
    }

    for r in results:
        locale = r["locale"]
        sentence = r["sentence"]
        wav = WAVS / f"{locale}.wav"
        entry = {
            "locale": locale,
            "reference": sentence,
            "transcript": None,
            "WER": None,
            "CER": None,
            "pass": False,
            "error": None,
            "whisper_language": WHISPER_LANG.get(locale),
            "officially_supported": r.get("officially_supported"),
            "experimental": r.get("experimental"),
        }
        print(f"=== ASR {locale} ===", flush=True)
        if not wav.exists() or not r.get("success"):
            entry["error"] = "missing wav or synth failed"
            if r.get("experimental"):
                entry["supported"] = False
            metrics["results"].append(entry)
            continue
        try:
            lang = WHISPER_LANG.get(locale)
            kwargs = {"fp16": device == "cuda"}
            if lang:
                kwargs["language"] = lang
                kwargs["task"] = "transcribe"
            result = asr_model.transcribe(str(wav), **kwargs)
            transcript = (result.get("text") or "").strip()
            entry["transcript"] = transcript
            entry["detected_language"] = result.get("language")
            w, c, ref_n, hyp_n = compute_wer_cer(sentence, transcript)
            entry["WER"] = None if w is None else round(w, 4)
            entry["CER"] = None if c is None else round(c, 4)
            entry["ref_normalized"] = ref_n
            entry["hyp_normalized"] = hyp_n
            empty = not transcript
            fail = empty or (w is not None and w >= 0.9) or (c is not None and c >= 0.9)
            entry["pass"] = not fail
            entry["failure_reason"] = (
                "empty transcript" if empty else ("WER/CER >= 0.9" if fail else None)
            )
            print(
                f"  WER={entry['WER']} CER={entry['CER']} pass={entry['pass']} :: {transcript[:80]}",
                flush=True,
            )
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
            entry["traceback"] = traceback.format_exc()
            print(f"  FAIL {entry['error']}", flush=True)
        metrics["results"].append(entry)
        write_text_utf8(OUT / "asr_metrics.json", json.dumps(metrics, indent=2, ensure_ascii=False))

    return metrics


def write_environment(wall_start: float, device: str, revision: str, versions: dict):
    import torch

    gpu = None
    if torch.cuda.is_available():
        gpu = {
            "name": torch.cuda.get_device_name(0),
            "capability": list(torch.cuda.get_device_capability(0)),
            "total_memory_gb": round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 2),
        }
    env = {
        "model_id": MODEL_ID,
        "revision": revision,
        "device": device,
        "gpu_vs_cpu": "GPU" if device == "cuda" else "CPU",
        "gpu": gpu,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "total_wall_clock_s": round(time.perf_counter() - wall_start, 2),
        "hostname": subprocess.check_output(["hostname"], text=True).strip(),
        "python": sys.version,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "package_versions_file": "versions.json",
        "key_versions": {
            k: v.get("version") if isinstance(v, dict) else v
            for k, v in versions.items()
            if k != "pip_freeze_subset"
        },
        "ref_audio_name": REF_AUDIO_NAME,
    }
    write_text_utf8(OUT / "environment.json", json.dumps(env, indent=2))
    return env


def main():
    wall_start = time.perf_counter()
    print("=== Recording versions ===", flush=True)
    versions = record_versions()
    print("=== Download + pin ===", flush=True)
    revision, model_path = download_and_pin()
    print("=== Synthesize locales ===", flush=True)
    results, device = synthesize_all(revision, model_path)
    print("=== Clipping ===", flush=True)
    clipping_analysis(results)
    print("=== ASR ===", flush=True)
    asr_all(results)
    print("=== Environment ===", flush=True)
    write_environment(wall_start, device, revision, versions)
    print("DONE qual core", flush=True)


if __name__ == "__main__":
    main()
