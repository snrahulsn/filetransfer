#!/usr/bin/env python3
"""Minimal RunPod control: resume existing pod or create RTX in US-IL-1; stop."""
from __future__ import annotations
import json, os, sys, time, urllib.request

API = "https://api.runpod.io/graphql"
UA = "Mozilla/5.0 (compatible; indic-f5-qual/1.0)"
VOL = "ul08t4z9qx"
DC = "US-IL-1"
EXISTING = "i1ft2jagjtvn0k"

def gql(query, variables=None):
    key = os.environ["RUNPOD_API_KEY"]
    body = json.dumps({"query": query, "variables": variables or {}}).encode()
    req = urllib.request.Request(
        API, data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json", "User-Agent": UA},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode())
    if data.get("errors"):
        raise RuntimeError(data["errors"])
    return data["data"]

def pods():
    return gql("""query { myself { pods { id name desiredStatus machine { gpuDisplayName dataCenterId } costPerHr networkVolumeId } } }""")["myself"]["pods"]

def resume(pod_id):
    # Try podResume
    try:
        return gql(
            """mutation ($podId: String!) { podResume(input: { podId: $podId }) { id desiredStatus } }""",
            {"podId": pod_id},
        )
    except Exception as e:
        print("podResume failed:", e)
        raise

def stop(pod_id):
    return gql(
        """mutation ($podId: String!) { podStop(input: { podId: $podId }) { id desiredStatus } }""",
        {"podId": pod_id},
    )

def create_rtx():
    # Prefer create on-demand RTX 6000 Ada in US-IL-1 with volume
    mutation = """
    mutation {
      podFindAndDeployOnDemand(input: {
        name: "indic-f5-qual"
        imageName: "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04"
        gpuTypeId: "NVIDIA RTX 6000 Ada Generation"
        cloudType: SECURE
        dataCenterId: "US-IL-1"
        networkVolumeId: "ul08t4z9qx"
        volumeMountPath: "/workspace"
        containerDiskInGb: 50
        volumeInGb: 0
        ports: "22/tcp"
        supportPublicIp: true
        startSsh: true
      }) {
        id imageName machineId machine { gpuDisplayName dataCenterId } desiredStatus costPerHr
      }
    }
    """
    return gql(mutation)

def wait_running(pod_id, timeout=600):
    t0 = time.time()
    while time.time() - t0 < timeout:
        for p in pods():
            if p["id"] == pod_id:
                print("status", p["desiredStatus"], flush=True)
                if p["desiredStatus"] == "RUNNING":
                    return p
        time.sleep(5)
    raise TimeoutError(pod_id)

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    if cmd == "status":
        print(json.dumps(pods(), indent=2))
    elif cmd == "resume":
        pid = sys.argv[2] if len(sys.argv) > 2 else EXISTING
        print(json.dumps(resume(pid), indent=2))
        wait_running(pid)
    elif cmd == "create":
        r = create_rtx()
        print(json.dumps(r, indent=2))
        open("/workspace/indic_f5_qual/pod_create.json", "w").write(json.dumps(r))
        pid = r["podFindAndDeployOnDemand"]["id"]
        open("/workspace/indic_f5_qual/pod_id.txt", "w").write(pid + "\n")
        wait_running(pid)
    elif cmd == "stop":
        pid = sys.argv[2] if len(sys.argv) > 2 else open("/workspace/indic_f5_qual/pod_id.txt").read().strip()
        print(json.dumps(stop(pid), indent=2))
    elif cmd == "ensure":
        # Prefer resume existing EXITED pod in same DC with volume
        plist = pods()
        for p in plist:
            if p["id"] == EXISTING or (p.get("networkVolumeId") == VOL and "IL" in str(p.get("machine", {}).get("dataCenterId", ""))):
                print("found", p)
                if p["desiredStatus"] != "RUNNING":
                    try:
                        resume(p["id"])
                        wait_running(p["id"])
                        open("/workspace/indic_f5_qual/pod_id.txt", "w").write(p["id"] + "\n")
                        print("RESUMED", p["id"])
                        return
                    except Exception as e:
                        print("resume failed, will create:", e)
        print("creating new...")
        main_create = create_rtx()
        print(json.dumps(main_create, indent=2))
        open("/workspace/indic_f5_qual/pod_create.json", "w").write(json.dumps(main_create))
        pid = main_create["podFindAndDeployOnDemand"]["id"]
        open("/workspace/indic_f5_qual/pod_id.txt", "w").write(pid + "\n")
        wait_running(pid)
    else:
        raise SystemExit("usage: status|resume|create|stop|ensure")

if __name__ == "__main__":
    # load env
    envp = "/home/box/agent-data/runpod.env"
    if os.path.exists(envp):
        for line in open(envp):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    main()
