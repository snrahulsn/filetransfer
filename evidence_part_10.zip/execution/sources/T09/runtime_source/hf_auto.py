"""HF Auto classes entrypoint for remote loading (used by AutoModel/AutoTokenizer)."""

import os
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
_SRC = os.path.join(_ROOT, "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from f5_tts.hf_auto import (  # noqa: E402
    F5TTSConfig,
    F5TTSAutoModel,
    F5TTSTokenizer,
    register_f5tts_auto,
)

__all__ = ["F5TTSConfig", "F5TTSAutoModel", "F5TTSTokenizer", "register_f5tts_auto"]
