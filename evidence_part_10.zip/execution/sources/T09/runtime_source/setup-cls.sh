#!/bin/bash
set -e


# apt update
# apt-get install libavformat-dev libavdevice-dev -y
# if gpu is available
if [ -n "$(lspci | grep NVIDIA)" ]; then
    apt-get install libcudnn9-cuda-12 -y
fi
pip install torch==2.6.0 torchaudio==2.6.0 torchvision==0.21.0 transformers==4.41.2 huggingface-hub==0.24.7 indic-nlp-library==0.92


echo "Installing dependencies for prepare_cls_version.py..."
pip install \
    datasets==4.5.0 \
    tqdm \
    indo-arabic-transliteration==0.1.5 \
    indic-unified-parser==1.0.6 \
    indic-numtowords==1.1.0 \
    indic-nlp-library==0.92 \
    git+https://github.com/libindic/indic-trans.git@0287fa62289968f0ce06cbe2df61cfadf4088c75 \
    urduhack==1.1.1 \
    keras==2.15.0 \
    tensorflow==2.15.0 \
    tensorflow-addons==0.23.0 \
    fastapi==0.128.7 \
    uvicorn==0.40.0

pip install indic_unified_parser==1.0.6 indo-arabic-transliteration==0.1.5 indic-numtowords==1.1.0
pip install click==8.0.1
pip install -e . --no-cache-dir
