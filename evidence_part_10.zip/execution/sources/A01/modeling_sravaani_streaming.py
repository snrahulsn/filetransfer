"""
HF `transformers` inference wrapper for the SraVaani CACHE-AWARE STREAMING TDT model.

Wraps the exported TorchScript graphs (cache-aware encoder + fused prednet/joint) and
carries the streaming state across chunks. Runtime deps: torch, transformers,
sentencepiece. **No nemo_toolkit.**

Two ways to use it:

    # 1) whole file, decoded chunk-by-chunk in streaming mode (simulates a live stream)
    model = AutoModel.from_pretrained(REPO, trust_remote_code=True).to("cuda").eval()
    print(model.transcribe(["sample.wav"])[0])

    # 2) a real live stream: push raw audio as it arrives
    s = model.new_stream()
    for pcm_block in mic():                       # any block size, float32 @16 kHz
        text = model.stream_audio(s, pcm_block)   # returns the text so far
    text = model.finalize(s)                      # flush the tail
"""
import os
from dataclasses import dataclass, field
from typing import List, Optional

import torch
from transformers import PreTrainedModel
from transformers.modeling_outputs import ModelOutput

from .configuration_sravaani_streaming import SraVaaniStreamingConfig


def _resolve_artifacts_dir(path, token=None, revision=None, cache_dir=None):
    """Local directory holding the TorchScript graph + preproc.pt + tokenizer.model.

    `path` is either a local export dir (used as-is) or a Hub repo id. In the repo-id case
    transformers only fetches config.json and the custom code -- our assets are not weights
    it knows how to resolve -- so pull them here and hand back the snapshot directory.
    """
    if os.path.isdir(path):
        return str(path)
    from huggingface_hub import hf_hub_download
    from huggingface_hub.utils import EntryNotFoundError

    dl = dict(repo_id=str(path), token=token, revision=revision, cache_dir=cache_dir)
    graph = None
    for name in ("model-asr-streaming.fp16.ts", "model-asr-streaming.ts"):
        try:
            graph = hf_hub_download(filename=name, **dl)
            break
        except EntryNotFoundError:
            continue
    if graph is None:
        raise FileNotFoundError(
            "no model-asr-streaming[.fp16].ts in repo %s" % path)
    for name in ("preproc.pt", "tokenizer.model"):
        hf_hub_download(filename=name, **dl)
    return os.path.dirname(graph)


def _read_audio(path):
    """Load audio to a mono float32 tensor + sample rate, without torchaudio."""
    try:
        import soundfile as sf
    except ImportError:
        sf = None
    if sf is not None:
        data, sr = sf.read(str(path), dtype="float32", always_2d=True)
        return torch.from_numpy(data).mean(dim=1).float(), int(sr)
    import wave
    import numpy as np
    with wave.open(str(path), "rb") as w:
        sr, n, ch, sw = w.getframerate(), w.getnframes(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(n)
    if sw == 2:
        a = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    elif sw == 1:
        a = (np.frombuffer(raw, dtype=np.uint8).astype(np.float32) - 128.0) / 128.0
    elif sw == 4:
        a = np.frombuffer(raw, dtype="<i4").astype(np.float32) / 2147483648.0
    else:
        raise ValueError("unsupported WAV sample width: %d bytes (install soundfile)" % sw)
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return torch.from_numpy(a.copy()).float(), int(sr)


def _resample(wav, sr_from, sr_to):
    """Fourier-method resampling (scipy.signal.resample style), pure torch."""
    sr_from, sr_to = int(sr_from), int(sr_to)
    if sr_from == sr_to or wav.shape[-1] == 0:
        return wav
    n = wav.shape[-1]
    n_new = max(int(round(n * sr_to / sr_from)), 1)
    X = torch.fft.rfft(wav)
    Y = torch.zeros(n_new // 2 + 1, dtype=X.dtype, device=wav.device)
    k = min(X.shape[-1], Y.shape[-1])
    Y[:k] = X[:k]
    return (torch.fft.irfft(Y, n=n_new) * (n_new / n)).float()


def _normalize_per_feature(x, seq_len, constant):
    B, _, max_time = x.shape
    steps = torch.arange(max_time, device=x.device).unsqueeze(0).expand(B, max_time)
    valid = steps < seq_len.unsqueeze(1)
    denom = valid.sum(dim=1)
    mean = torch.where(valid.unsqueeze(1), x, torch.zeros_like(x)).sum(dim=2) / denom.unsqueeze(1)
    var = torch.sum(torch.where(valid.unsqueeze(1), x - mean.unsqueeze(2), torch.zeros_like(x)) ** 2,
                    dim=2) / (denom.unsqueeze(1) - 1.0)
    std = torch.sqrt(var).masked_fill(torch.sqrt(var).isnan(), 0.0) + constant
    return (x - mean.unsqueeze(2)) / std.unsqueeze(2)


@dataclass
class StreamState:
    """Everything that must persist between chunks of one audio stream.

    The encoder caches are the cache-aware part; (h, c, last_token) is the TDT prediction
    network state. Dropping any of them and restarting per chunk is exactly the bug that
    makes naive chunked ASR lose words across boundaries.
    """
    cache_last_channel: torch.Tensor       # (B, layers, last_channel_cache_size, d_model)
    cache_last_time: torch.Tensor          # (B, layers, d_model, last_time_cache_size)
    cache_last_channel_len: torch.Tensor   # (B,)
    h: Optional[torch.Tensor] = None       # (pred_rnn_layers, B, pred_hidden); TDT only
    c: Optional[torch.Tensor] = None       # TDT only
    last_token: List[int] = field(default_factory=list)   # per-stream last emitted token (TDT)
    prev_id: List[int] = field(default_factory=list)      # per-stream last argmax id (CTC collapse)
    tokens: List[List[int]] = field(default_factory=list)  # per-stream token history
    audio: Optional[torch.Tensor] = None   # (B, samples) raw buffer, live mode only
    feat_idx: int = 0                      # next feature frame to consume
    step: int = 0
    finished: bool = False


@dataclass
class Hypothesis:
    text: str
    y_sequence: List[int]
    score: float = 0.0


class SraVaaniStreamingModel(PreTrainedModel):
    """Cache-aware streaming TDT ASR wrapped for HF transformers (load via AutoModel)."""

    config_class = SraVaaniStreamingConfig
    main_input_name = "input_features"

    def __init__(self, config: SraVaaniStreamingConfig):
        super().__init__(config)
        self._anchor = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
        self._artifacts_dir = getattr(config, "_name_or_path", ".") or "."
        self.encoder = None
        self.decoder_joint = None   # TDT builds only this ...
        self.ctc_decoder = None     # ... and CTC only this.
        self._loaded = False
        self._io_dtype = torch.float32
        self._req_dtype = None
        self.post_init()

    # ---------------------------------------------------------------- loading
    def _ensure_loaded(self, device=None):
        if self._loaded:
            return
        d = self._artifacts_dir
        dev = device or self._anchor.device
        on_cpu = (torch.device(dev).type == "cpu")
        # Graphs ship fp16 but exported unfrozen, so weights are real parameters. CPU has no
        # fp16 conv kernel -> upcast to fp32. GPU keeps fp16 only if the user asked for it.
        want_fp16 = (self._req_dtype == torch.float16) or (self._anchor.dtype == torch.float16)

        def cast(mod):
            params = list(mod.parameters())
            target = torch.float16 if (want_fp16 and not on_cpu and params) else torch.float32
            if params and params[0].dtype != target:
                mod = mod.half() if target == torch.float16 else mod.float()
            return mod, target

        combined = next((os.path.join(d, n) for n in ("model-asr-streaming.fp16.ts",
                                                      "model-asr-streaming.ts")
                         if os.path.exists(os.path.join(d, n))), None)
        if combined is None:
            raise FileNotFoundError("model-asr-streaming.fp16.ts not found in %s" % d)
        mod, io = cast(torch.jit.load(combined, map_location=dev).eval())
        self.encoder = mod.encoder
        if self.config.decoder_type == "ctc":
            self.ctc_decoder = mod.ctc_decoder
        else:
            self.decoder_joint = mod.decoder_joint
        self._io_dtype = io
        pp = torch.load(os.path.join(d, "preproc.pt"), map_location="cpu")
        self._p = pp["params"]
        self.register_buffer("_window", pp["window"].to(dev), persistent=False)
        self.register_buffer("_fb", pp["fb"].to(dev), persistent=False)

        # fp16 safety probe. The graph is traced, so .half() converts the WEIGHTS but leaves
        # tensors the graph builds at runtime (the subsampling length mask) as fp32; that mask
        # then promotes a conv input back to fp32 and collides with the fp16 conv weight
        # ("Input type FloatTensor and weight type HalfTensor"). Rather than crash mid-stream,
        # run one tiny encoder forward here; if fp16 fails, transparently upcast to fp32 (still
        # plenty fast on GPU) and warn. A future export that fixes the mask dtype passes the
        # probe and keeps real fp16 -- no code change needed.
        if io == torch.float16:
            if not self._fp16_encoder_ok(dev):
                self.encoder = self.encoder.float()
                if self.ctc_decoder is not None:
                    self.ctc_decoder = self.ctc_decoder.float()
                if self.decoder_joint is not None:
                    self.decoder_joint = self.decoder_joint.float()
                self._io_dtype = torch.float32
                import warnings
                warnings.warn("fp16 not supported by this exported graph (traced mask stays "
                              "fp32); running fp32 on %s instead." % dev)
        self._loaded = True

    def _fp16_encoder_ok(self, dev):
        """One minimal encoder forward on zeros; False if it raises a dtype mismatch."""
        cfg = self.config
        w = cfg.chunk_size + cfg.pre_encode_cache_size
        try:
            self.encoder(
                torch.zeros(1, cfg.feat_in, w, device=dev, dtype=torch.float16),
                torch.tensor([w], device=dev, dtype=torch.int64),
                torch.zeros(1, cfg.enc_n_layers, cfg.last_channel_cache_size, cfg.enc_d_model,
                            device=dev, dtype=torch.float16),
                torch.zeros(1, cfg.enc_n_layers, cfg.enc_d_model, cfg.last_time_cache_size,
                            device=dev, dtype=torch.float16),
                torch.zeros(1, device=dev, dtype=torch.int64),
            )
            return True
        except RuntimeError:
            return False

    @classmethod
    def from_pretrained(cls, path, *args, **kwargs):
        token = kwargs.get("token", kwargs.get("use_auth_token"))
        revision = kwargs.get("revision")
        cache_dir = kwargs.get("cache_dir")
        config = kwargs.pop("config", None) or SraVaaniStreamingConfig.from_pretrained(
            path, token=token, revision=revision, cache_dir=cache_dir)
        config._name_or_path = path
        model = cls(config)
        model._artifacts_dir = _resolve_artifacts_dir(
            path, token=token, revision=revision, cache_dir=cache_dir)
        dtype = kwargs.get("torch_dtype", None)
        if isinstance(dtype, str):
            dtype = None if dtype == "auto" else getattr(torch, dtype, None)
        if dtype in (torch.float16, torch.float32):
            model._req_dtype = dtype
            if dtype == torch.float16:
                model = model.half()
        return model

    def _get_tokenizer(self):
        if getattr(self, "_sp", None) is None:
            import sentencepiece as spm
            self._sp = spm.SentencePieceProcessor(
                model_file=os.path.join(self._artifacts_dir, "tokenizer.model"))
        return self._sp

    # ---------------------------------------------------------------- latency switch
    def set_att_context_size(self, att_context_size):
        """Switch the streaming lookahead at runtime, e.g. [70, 6] (~480 ms).

        ONE exported graph serves every lookahead the model was trained with: in
        chunked_limited mode the lookahead is realized by how many feature frames you feed
        per step (chunk_size = subsampling_factor * (1 + right_context)), which is a dynamic
        input, not something baked into the trace. So switching latency is just a chunk-size
        change -- no re-export, no reload.

        The one hard limit is that you cannot exceed the lookahead the graph was TRACED at:
        the encoder's streaming_post_process trims each chunk's output to valid_out_len,
        which IS a baked constant (= export right_context + 1). A larger chunk would get its
        tail silently cut. Export at the largest lookahead you ever want (the converter
        does this by default) and switch downward freely.

        Call this between utterances, not mid-stream: chunk size and the caches must agree.
        """
        cfg = self.config
        acs = [int(x) for x in att_context_size]
        exp_right = int(cfg.export_att_context_size[1])
        if acs[1] > exp_right:
            raise ValueError(
                "lookahead %d exceeds the exported graph's %d (outputs would be truncated to "
                "valid_out_len=%d). Re-export with --att_context_size %d %d."
                % (acs[1], exp_right, exp_right + 1, acs[0], acs[1]))
        if acs not in [list(a) for a in cfg.supported_att_context_sizes]:
            raise ValueError("att_context_size %s was not trained; supported: %s"
                             % (acs, cfg.supported_att_context_sizes))
        cfg.att_context_size = acs
        cfg.chunk_size = cfg.shift_size = cfg.subsampling_factor * (1 + acs[1])
        return self

    def set_lookahead_ms(self, ms):
        """Pick the trained lookahead closest to `ms` milliseconds (0 -> lowest latency)."""
        cfg = self.config
        per_step_ms = cfg.subsampling_factor * 10.0  # 80 ms per encoder frame @16 kHz
        best = min(cfg.supported_att_context_sizes, key=lambda a: abs(a[1] * per_step_ms - ms))
        return self.set_att_context_size(best)

    # ---------------------------------------------------------------- features
    @torch.no_grad()
    def extract_features(self, wav, wav_len):
        """Mel features for a full waveform, normalized over the whole utterance."""
        self._ensure_loaded()
        p, dev = self._p, self._anchor.device
        n_fft, hop, win = p["n_fft"], p["hop_length"], p["win_length"]
        wav, wav_len = wav.to(dev).float(), wav_len.to(dev)
        seq_len = torch.div(wav_len, hop, rounding_mode="floor")
        tmask = torch.arange(wav.shape[1], device=dev).unsqueeze(0) < wav_len.unsqueeze(1)
        x = torch.cat((wav[:, :1], wav[:, 1:] - p["preemph"] * wav[:, :-1]), dim=1).masked_fill(~tmask, 0.0)
        spec = torch.stft(x, n_fft=n_fft, hop_length=hop, win_length=win, window=self._window.float(),
                          center=True, pad_mode="constant", return_complex=True)
        x = torch.view_as_real(spec)
        x = torch.sqrt(x.pow(2).sum(-1)).pow(p["mag_power"])
        x = torch.matmul(self._fb.float(), x)
        x = torch.log(x + p["log_zero_guard_value"])
        x = _normalize_per_feature(x, seq_len, p["CONSTANT"])
        max_len = x.size(-1)
        m = torch.arange(max_len, device=dev).repeat(x.size(0), 1) >= seq_len.unsqueeze(1)
        return x.masked_fill(m.unsqueeze(1), p["pad_value"]), seq_len

    # ---------------------------------------------------------------- state
    @torch.no_grad()
    def new_stream(self, batch_size=1):
        """Allocate a fresh StreamState (all caches zeroed, blank prediction state)."""
        self._ensure_loaded()
        cfg, dev, dt = self.config, self._anchor.device, self._io_dtype
        is_tdt = cfg.decoder_type != "ctc"
        zeros = lambda: torch.zeros(cfg.pred_rnn_layers, batch_size, cfg.pred_hidden,
                                    device=dev, dtype=dt)
        return StreamState(
            cache_last_channel=torch.zeros(batch_size, cfg.enc_n_layers,
                                           cfg.last_channel_cache_size, cfg.enc_d_model,
                                           device=dev, dtype=dt),
            cache_last_time=torch.zeros(batch_size, cfg.enc_n_layers, cfg.enc_d_model,
                                        cfg.last_time_cache_size, device=dev, dtype=dt),
            cache_last_channel_len=torch.zeros(batch_size, device=dev, dtype=torch.int64),
            # The prednet state exists only for TDT; CTC's only carried decode state is the
            # last argmax id, which the repeat-collapse needs across the chunk seam.
            h=zeros() if is_tdt else None,
            c=zeros() if is_tdt else None,
            last_token=[cfg.blank_id] * batch_size,
            prev_id=[cfg.blank_id] * batch_size,
            tokens=[[] for _ in range(batch_size)],
        )

    # ---------------------------------------------------------------- decoding
    @torch.no_grad()
    def _greedy_chunk(self, enc_out, T, state, b):
        """TDT greedy over one chunk's encoder frames, resuming the prednet state.

        Mirrors NeMo's greedy TDT loop: at each frame, emit up to max_symbols tokens; the
        duration head says how many frames to skip. State (h, c, last_token) persists across
        chunk boundaries, which is what keeps words whole across the seam.
        """
        cfg, dev = self.config, self._anchor.device
        nd, blank, durs = cfg.num_durations, cfg.blank_id, cfg.durations
        h = state.h[:, b:b + 1].contiguous()
        c = state.c[:, b:b + 1].contiguous()
        last = state.last_token[b]
        tlen = torch.ones(1, dtype=torch.int32, device=dev)
        new_tokens = []
        t = 0
        while t < T:
            f = enc_out.narrow(2, t, 1)
            added, need = 0, True
            while need and added < cfg.max_symbols:
                tgt = torch.tensor([[last]], dtype=torch.int32, device=dev)
                logits, _, h2, c2 = self.decoder_joint(f, tgt, tlen, h, c)
                logits = logits[0, 0, 0]
                k = int(logits[:-nd].argmax().item())
                skip = durs[int(logits[-nd:].argmax().item())]
                if k != blank:
                    new_tokens.append(k)
                    h, c, last = h2, c2, k
                added += 1
                t += skip
                need = (skip == 0)
            if added == cfg.max_symbols:
                t += 1
        state.h[:, b:b + 1], state.c[:, b:b + 1] = h, c
        state.last_token[b] = last
        state.tokens[b].extend(new_tokens)
        return new_tokens

    @torch.no_grad()
    def _greedy_chunk_ctc(self, ids, state, b):
        """CTC greedy over one chunk's argmax ids: collapse repeats, drop blanks.

        state.prev_id carries the previous frame's id ACROSS the chunk boundary. Without it a
        token straddling the seam (…5 5 | 5 5…) would be emitted twice — the CTC equivalent of
        the prednet-state bug that breaks naive chunked RNNT.
        """
        blank, prev = self.config.blank_id, state.prev_id[b]
        new_tokens = []
        for k in ids:
            if k != prev and k != blank:
                new_tokens.append(k)
            prev = k
        state.prev_id[b] = prev
        state.tokens[b].extend(new_tokens)
        return new_tokens

    @torch.no_grad()
    def stream_features(self, state, feats, feat_len):
        """Run ONE chunk of mel features through the cache-aware encoder + TDT decoder.

        feats: (B, feat_in, chunk_size + pre_encode_cache_size) — the caller must already
        have prepended the pre-encode cache frames (see _chunk_with_cache).
        Returns the newly emitted tokens per stream.
        """
        self._ensure_loaded()
        dev = self._anchor.device
        enc, enc_len, ch_next, t_next, len_next = self.encoder(
            feats.to(dev).to(self._io_dtype),
            feat_len.to(dev).to(torch.int64),
            state.cache_last_channel,
            state.cache_last_time,
            state.cache_last_channel_len,
        )
        state.cache_last_channel, state.cache_last_time, state.cache_last_channel_len = ch_next, t_next, len_next
        state.step += 1
        if self.config.decoder_type == "ctc":
            # (B, D, T) -> log_probs (B, T, V+1); one decoder call for the whole chunk.
            ids = self.ctc_decoder(enc).argmax(dim=-1)
            return [self._greedy_chunk_ctc(ids[b, :int(enc_len[b].item())].tolist(), state, b)
                    for b in range(enc.size(0))]
        return [self._greedy_chunk(enc[b:b + 1], int(enc_len[b].item()), state, b)
                for b in range(enc.size(0))]

    def _chunk_with_cache(self, feats, idx):
        """Slice feature frames [idx, idx+chunk) and prepend pre_encode_cache_size frames.

        pad_and_drop_preencoded convention: on step 0 the left context is zeros, so every
        chunk has the same shape and the graph's baked-in drop_extra_pre_encoded is correct.
        """
        cfg = self.config
        pec, pad_value = cfg.pre_encode_cache_size, float(self._p["pad_value"])
        B, F, T = feats.shape
        chunk = feats[:, :, idx: idx + cfg.chunk_size]
        start = max(idx - pec, 0)
        cache = feats[:, :, start:idx]
        if cache.size(-1) < pec:  # step 0 (or near it): zero-pad the missing left context
            pad = torch.full((B, F, pec - cache.size(-1)), pad_value,
                             dtype=feats.dtype, device=feats.device)
            cache = torch.cat((pad, cache), dim=-1)
        x = torch.cat((cache, chunk), dim=-1)
        return x, chunk.size(-1)

    # ---------------------------------------------------------------- live API
    @torch.no_grad()
    def stream_audio(self, state, pcm, sampling_rate=16000):
        """Push raw audio into a live stream; decode whatever complete chunks it completes.

        pcm: 1-D float32 samples (any block size). Returns the transcript so far.
        Features are (re)computed on the buffered audio, so normalization statistics come
        from everything heard up to now — which is what NeMo's non-online normalization does
        for a file, applied causally here.
        """
        self._ensure_loaded()
        cfg = self.config
        wav = torch.as_tensor(pcm, dtype=torch.float32).reshape(1, -1)
        if sampling_rate != cfg.sample_rate:
            wav = _resample(wav, sampling_rate, cfg.sample_rate)
        state.audio = wav if state.audio is None else torch.cat((state.audio.cpu(), wav), dim=1)
        feats, flen = self.extract_features(state.audio, torch.tensor([state.audio.shape[1]]))
        avail = int(flen[0].item())
        while avail - state.feat_idx >= cfg.chunk_size:
            x, n = self._chunk_with_cache(feats[:, :, :avail], state.feat_idx)
            self.stream_features(state, x, torch.tensor([x.shape[-1]]))
            state.feat_idx += cfg.shift_size
        return self._text(state, 0)

    @torch.no_grad()
    def finalize(self, state):
        """Flush the trailing partial chunk and return the final transcript."""
        if state.finished or state.audio is None:
            return self._text(state, 0)
        cfg = self.config
        feats, flen = self.extract_features(state.audio, torch.tensor([state.audio.shape[1]]))
        avail = int(flen[0].item())
        while state.feat_idx < avail:
            remaining = avail - state.feat_idx
            if remaining < cfg.min_sampling_frames:  # too short to produce an encoder frame
                break
            x, n = self._chunk_with_cache(feats[:, :, :avail], state.feat_idx)
            self.stream_features(state, x, torch.tensor([x.shape[-1]]))
            state.feat_idx += cfg.shift_size
        state.finished = True
        return self._text(state, 0)

    def _text(self, state, b):
        return self._get_tokenizer().decode(state.tokens[b])

    # ---------------------------------------------------------------- file API
    @torch.no_grad()
    def transcribe(self, audio, return_hypotheses=False, verbose_chunks=False, **kwargs):
        """Transcribe files by simulating a live stream over them (chunk by chunk).

        This is the streaming path, not an offline forward: the same caches and prednet state
        are carried across chunks exactly as they would be for a mic.
        """
        self._ensure_loaded()
        cfg = self.config
        items = [audio] if isinstance(audio, (str, bytes, os.PathLike)) else list(audio)
        results = []
        for a in items:
            if isinstance(a, (str, bytes, os.PathLike)):
                wav, sr = _read_audio(a)
                if sr != cfg.sample_rate:
                    wav = _resample(wav, sr, cfg.sample_rate)
            else:
                wav = torch.as_tensor(a, dtype=torch.float32).reshape(-1)
            feats, flen = self.extract_features(wav.unsqueeze(0), torch.tensor([wav.shape[0]]))
            T = int(flen[0].item())
            state = self.new_stream(1)
            idx = 0
            while idx < T:
                n_new = min(cfg.chunk_size, T - idx)
                if n_new < cfg.min_sampling_frames:
                    break
                x, _ = self._chunk_with_cache(feats[:, :, :T], idx)
                toks = self.stream_features(state, x, torch.tensor([x.shape[-1]]))[0]
                if verbose_chunks:
                    t = (idx + n_new) * 0.01
                    print("[%6.2fs] %s" % (t, self._text(state, 0)))
                idx += cfg.shift_size
            text = self._text(state, 0)
            results.append(Hypothesis(text=text, y_sequence=state.tokens[0])
                           if return_hypotheses else text)
        return results

    @torch.no_grad()
    def forward(self, input_features, feature_lengths=None, **kwargs):
        """Single cache-less encoder pass over one chunk (mostly for HF-API compatibility)."""
        self._ensure_loaded()
        state = self.new_stream(input_features.size(0))
        if feature_lengths is None:
            feature_lengths = torch.full((input_features.size(0),), input_features.size(-1),
                                         dtype=torch.long, device=input_features.device)
        toks = self.stream_features(state, input_features, feature_lengths)
        return ModelOutput(token_lists=toks, state=state)
