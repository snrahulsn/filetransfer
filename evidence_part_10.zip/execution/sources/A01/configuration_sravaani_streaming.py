from transformers import PretrainedConfig


class SraVaaniStreamingConfig(PretrainedConfig):
    """Config for the SraVaani cache-aware streaming TDT (RNNT) ASR model."""

    model_type = "sravaani_streaming_tdt"

    def __init__(
        self,
        vocab_size=5000,
        blank_id=5000,
        durations=(0, 1, 2, 3, 4),
        num_durations=5,
        pred_hidden=640,
        pred_rnn_layers=1,
        max_symbols=10,
        enc_d_model=1024,
        enc_n_layers=17,
        feat_in=128,
        sample_rate=16000,
        subsampling_factor=8,
        # --- cache-aware streaming params (from encoder.streaming_cfg) ---
        decoder_type="tdt",         # "tdt" (prednet/joint) or "ctc" (aux CTC head only)
        att_context_size=(70, 13),
        supported_att_context_sizes=((70, 13), (70, 6), (70, 1), (70, 0)),
        export_att_context_size=(70, 13),  # the lookahead the graph was TRACED at (the max)
        chunk_size=112,             # feature frames fed per step (excl. pre-encode cache)
        shift_size=112,             # feature frames advanced per step
        pre_encode_cache_size=9,    # feature frames of left context prepended to each chunk
        last_channel_cache_size=70,  # encoder frames of attention cache
        last_time_cache_size=8,     # conv cache width
        min_sampling_frames=1,      # drop a trailing chunk shorter than this
        **kwargs,
    ):
        self.vocab_size = vocab_size
        self.blank_id = blank_id
        self.decoder_type = decoder_type
        self.durations = list(durations)
        self.num_durations = num_durations
        self.pred_hidden = pred_hidden
        self.pred_rnn_layers = pred_rnn_layers
        self.max_symbols = max_symbols
        self.enc_d_model = enc_d_model
        self.enc_n_layers = enc_n_layers
        self.feat_in = feat_in
        self.sample_rate = sample_rate
        self.subsampling_factor = subsampling_factor
        self.att_context_size = list(att_context_size)
        self.supported_att_context_sizes = [list(a) for a in supported_att_context_sizes]
        self.export_att_context_size = list(export_att_context_size)
        self.chunk_size = chunk_size
        self.shift_size = shift_size
        self.pre_encode_cache_size = pre_encode_cache_size
        self.last_channel_cache_size = last_channel_cache_size
        self.last_time_cache_size = last_time_cache_size
        self.min_sampling_frames = min_sampling_frames
        super().__init__(**kwargs)

    @property
    def chunk_seconds(self):
        return self.chunk_size * 0.01  # hop_length/sample_rate = 10 ms per feature frame

    @property
    def lookahead_seconds(self):
        return self.att_context_size[1] * self.subsampling_factor * 0.01
