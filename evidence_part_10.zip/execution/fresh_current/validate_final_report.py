#!/usr/bin/env python3
"""Release checks for the two-table report and blind listening package."""

import hashlib
import json
import subprocess
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "ONE_PAGE_REPORT.html"
REPORT_PDF = ROOT / "ONE_PAGE_REPORT.pdf"
FRESH = ROOT / "execution/fresh_current"
LISTENING = ROOT / "LISTENING_REVIEW"
GROK_REVIEW = ROOT / "execution/grok_review.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


class ReportParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.tables = 0
        self.audio = []
        self.hrefs = []
        self.blockers = 0
        self.grok_scores = 0

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "table":
            self.tables += 1
        if values.get("class") == "blocker":
            self.blockers += 1
        if "quality" in values.get("class", "").split() and "g" in values.get("class", "").split():
            self.grok_scores += 1
        if "href" in values:
            self.hrefs.append(values["href"])
        if "data-audio" in values:
            self.audio.append(values["data-audio"])


def assert_local_links(paths: list[str]) -> None:
    missing = []
    for value in paths:
        if value.startswith(("http://", "https://", "#")):
            continue
        path = REPORT.parent / unquote(value.split("#", 1)[0])
        if not path.is_file():
            missing.append(value)
    assert not missing, f"Missing report targets: {missing[:20]}"


def validate_model_evidence() -> tuple[int, int]:
    asr_ids = [f"A{i:02d}" for i in range(1, 16)]
    tts_ids = [f"T{i:02d}" for i in range(1, 20)]
    missing = []
    for model_id in asr_ids + tts_ids:
        directory = FRESH / model_id
        if not list(directory.glob("*records*.jsonl")):
            missing.append(model_id)
    assert not missing, f"Models without records: {missing}"
    return len(asr_ids), len(tts_ids)


def validate_listening_package() -> int:
    key = json.loads((LISTENING / "blind_key.json").read_text())
    manifest = json.loads((LISTENING / "package_manifest.json").read_text())
    assert manifest["clip_count"] == len(key)
    for row in key:
        source = FRESH / row["source_file"]
        blind = LISTENING / "clips" / (row["id"] + source.suffix)
        expected = row["sha256"]
        assert source.is_file() and blind.is_file(), row["id"]
        assert sha256(source) == expected, source
        assert sha256(blind) == expected, blind
    return len(key)


def validate_grok_review() -> int:
    data = json.loads(GROK_REVIEW.read_text())
    rows = data["rows"]
    assert data["clip_count"] == len(rows) == 107
    assert len({row["id"] for row in rows}) == len(rows)
    expected_ids = {row["id"] for row in json.loads((LISTENING / "blind_key.json").read_text())}
    assert {row["id"] for row in rows} == expected_ids
    for row in rows:
        assert type(row["overall_score"]) is int and 1 <= row["overall_score"] <= 5
        assert type(row["correct"]) is bool
        assert isinstance(row["mispronunciations"], list)
        assert isinstance(row["naturalness_issues"], list)
    for source, expected_hash in data["source_sha256"].items():
        path = Path(source)
        if not path.is_absolute():
            path = ROOT / path
        assert path.is_file() and sha256(path) == expected_hash
    return len(rows)


def main() -> None:
    parser = ReportParser()
    parser.feed(REPORT.read_text())
    assert parser.tables == 2, parser.tables
    assert parser.blockers == 0, parser.blockers
    assert parser.audio, "No report audio controls"
    assert_local_links(parser.hrefs + parser.audio)
    asr_models, tts_models = validate_model_evidence()
    listening_clips = validate_listening_package()
    grok_clips = validate_grok_review()
    assert parser.grok_scores > 0, "No Grok scores linked from the TTS table"
    pdf_info = subprocess.check_output(["pdfinfo", str(REPORT_PDF)], text=True)
    pages_line = next(line for line in pdf_info.splitlines() if line.startswith("Pages:"))
    pdf_pages = int(pages_line.split(":", 1)[1].strip())
    assert pdf_pages == 1, pdf_pages
    result = {
        "report_tables": parser.tables,
        "report_audio_controls": len(parser.audio),
        "report_local_links": len(parser.hrefs),
        "report_blockers": parser.blockers,
        "asr_models_with_records": asr_models,
        "tts_models_with_records": tts_models,
        "listening_clips_verified": listening_clips,
        "grok_clips_verified": grok_clips,
        "report_grok_score_links": parser.grok_scores,
        "pdf_pages": pdf_pages,
        "report_sha256": sha256(REPORT),
        "report_pdf_sha256": sha256(REPORT_PDF),
        "listening_page_sha256": sha256(LISTENING / "index.html"),
    }
    (ROOT / "execution/final_report_validation.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result))


if __name__ == "__main__":
    main()
