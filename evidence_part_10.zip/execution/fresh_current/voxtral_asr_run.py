"""Pinned experimental Transformers Voxtral realtime API with causally delivered audio."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0')
import argparse,datetime,hashlib,importlib.metadata,json,pathlib,queue,threading,time,traceback
import numpy as np,torch
from transformers import VoxtralRealtimeForConditionalGeneration,VoxtralRealtimeProcessor,TextIteratorStreamer,StoppingCriteria,StoppingCriteriaList
from asr_corpus import records
from metrics import score
ROOT=pathlib.Path('/workspace/speechbench_20260924');OUT=ROOT/'A02';OUT.mkdir(exist_ok=True)
torch.set_num_threads(4)
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while b:=f.read(8388608):h.update(b)
    return h.hexdigest()
class Stop(StoppingCriteria):
    def __init__(self,event):self.event=event
    def __call__(self,input_ids,scores,**kwargs):return self.event.is_set()
def paced(model,processor,audio):
    cancel=threading.Event();q=queue.Queue();releases=[];events=[];errors=[]
    torch.cuda.synchronize();start=time.perf_counter()
    def produce():
        for begin in range(0,len(audio),320):
            end=min(begin+320,len(audio));due=end/16000
            cancel.wait(max(0,start+due-time.perf_counter()))
            if cancel.is_set():break
            released=time.perf_counter()-start;releases.append(dict(end_sample=end,due_s=due,released_s=released))
            q.put(audio[begin:end].copy())
        q.put(None)
    producer=threading.Thread(target=produce,daemon=True);producer.start()
    buffer=np.empty(0,dtype=np.float32);ended=False;max_queue=0
    padding=int(processor.num_right_pad_tokens*processor.raw_audio_length_per_tok)
    def take(begin,end):
        nonlocal buffer,ended,max_queue
        while len(buffer)<end and not ended:
            piece=q.get(timeout=180);max_queue=max(max_queue,q.qsize())
            if piece is None:ended=True;buffer=np.pad(buffer,(0,padding))
            else:buffer=np.concatenate((buffer,piece))
        if len(buffer)<end:return None
        return buffer[begin:end]
    worker=None
    try:
        first=take(0,processor.num_samples_first_audio_chunk)
        if first is None:raise ValueError('Clip shorter than the required first streaming chunk including EOS padding')
        inputs=processor(first,is_streaming=True,is_first_audio_chunk=True,return_tensors='pt').to(model.device,dtype=model.dtype)
        def features():
            yield inputs.input_features
            frame=processor.num_mel_frames_first_audio_chunk
            while not cancel.is_set():
                begin=frame*processor.feature_extractor.hop_length-processor.feature_extractor.win_length//2
                end=begin+processor.num_samples_per_audio_chunk
                piece=take(begin,end)
                if piece is None:break
                chunk=processor(piece,is_streaming=True,is_first_audio_chunk=False,return_tensors='pt').to(model.device,dtype=model.dtype)
                yield chunk.input_features
                frame+=processor.audio_length_per_tok
        streamer=TextIteratorStreamer(processor.tokenizer,skip_prompt=True,skip_special_tokens=True,clean_up_tokenization_spaces=True,timeout=180)
        def generate():
            try:
                with torch.inference_mode():model.generate(input_ids=inputs.input_ids,input_features=features(),num_delay_tokens=inputs.num_delay_tokens,
                    streamer=streamer,stopping_criteria=StoppingCriteriaList([Stop(cancel)]),do_sample=False)
            except Exception as e:errors.append((type(e).__name__,str(e),traceback.format_exc()));streamer.end()
        worker=threading.Thread(target=generate,daemon=True);worker.start();text=''
        for chunk in streamer:
            if chunk:text+=chunk;events.append(dict(at_s=time.perf_counter()-start,text=text))
        worker.join(10)
        if worker.is_alive():raise RuntimeError('Generation did not terminate after streamer completion')
        if errors:raise RuntimeError(repr(errors))
        torch.cuda.synchronize();elapsed=time.perf_counter()-start
        return text,dict(total_s=elapsed,first_partial_s=events[0]['at_s'] if events else None,finalization_lag_s=elapsed-len(audio)/16000,
            partial_events=events,producer_events=releases,max_queue_frames=max_queue,max_release_lateness_s=max(x['released_s']-x['due_s'] for x in releases),
            eos_right_padding_samples=padding,received_all_input_audio=ended)
    finally:
        cancel.set();producer.join(5)
        if worker is not None:
            worker.join(5)
            if worker.is_alive():raise SystemExit('Native generation worker failed to stop; terminate process before another trial')
def main(limit):
    job=json.loads((ROOT/'A02_download.json').read_text());path=pathlib.Path(job['path']);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    if not path.is_dir():
        cache=pathlib.Path(os.environ.get('HF_HUB_CACHE','/workspace/hf_cache/hub'))
        fallback=cache/('models--'+job['repo'].replace('/','--'))/'snapshots'/job['revision']
        if not fallback.is_dir():raise FileNotFoundError(f"Pinned snapshot unavailable at {path} or {fallback}")
        path=fallback
    weight_files=sorted(path.glob('*.safetensors'))
    if not weight_files:raise FileNotFoundError(f'No model safetensor files under {path}')
    load_path=path
    if not (path/'model.safetensors').is_file():
        load_path=pathlib.Path('/tmp/voxtral_transformers_compat')
        load_path.mkdir(parents=True,exist_ok=True)
        for source in path.iterdir():
            target=load_path/source.name
            if not target.exists():target.symlink_to(source.resolve(),target_is_directory=source.is_dir())
        (load_path/'model.safetensors').symlink_to(weight_files[0].resolve())
    env=dict(run_id=stamp,model=job['repo'],revision=job['revision'],weights_sha256={p.name:sha(p) for p in weight_files},runner_sha256=sha(__file__),
        torch=torch.__version__,transformers=importlib.metadata.version('transformers'),mistral_common=importlib.metadata.version('mistral-common'),gpu=torch.cuda.get_device_name(0),
        precision='bfloat16',streaming_api='experimental Transformers generator; independent 20ms producer; EOS-only right padding',hf_offline=True,network_namespace_isolated=False)
    (OUT/f'environment-{stamp}.json').write_text(json.dumps(env,indent=2))
    processor=VoxtralRealtimeProcessor.from_pretrained(load_path,local_files_only=True)
    model=VoxtralRealtimeForConditionalGeneration.from_pretrained(load_path,dtype=torch.bfloat16,device_map='cuda:0',local_files_only=True).eval()
    for locale in ['hi-IN','en-IN']:
        samples=list(records([locale],limit=limit))
        for i,row in enumerate([samples[0]]*3+samples):
            rec={k:v for k,v in row.items() if k!='audio'}
            rec.update(run_id=stamp,phase='warmup' if i<3 else 'streaming_smoke',mode='native_incremental_transformers_paced_20ms',ok=False,audio_duration_s=len(row['audio'])/16000)
            try:
                text,timing=paced(model,processor,row['audio']);rec.update(ok=True,hypothesis=text,**timing,**score(row['reference'],text))
                if not timing['received_all_input_audio']:raise RuntimeError('Generation ended before all input audio was consumed')
            except Exception as e:rec.update(ok=False,error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
            with (OUT/'stream_records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            print(json.dumps({k:rec.get(k) for k in ['locale','phase','ok','wer','first_partial_s','error']}),flush=True)
            if not rec['ok']:break
    if os.environ.get('ASR_STAGE')=='stream':
        (OUT/'DONE-smoke').write_text(f'Streaming evaluation completed at {limit} clips per supported locale.\n');return
    for locale in ['hi-IN','en-IN']:
        for row in records([locale],limit=3):
            rec={k:v for k,v in row.items() if k!='audio'}
            rec.update(run_id=stamp,phase='coverage_sweep',coverage_limit_per_locale=3,mode='full_utterance_transformers',ok=False,audio_duration_s=len(row['audio'])/16000)
            try:
                torch.cuda.synchronize();start=time.perf_counter()
                inputs=processor(row['audio'],return_tensors='pt').to(model.device,dtype=model.dtype)
                with torch.inference_mode():tokens=model.generate(**inputs,do_sample=False)
                text=processor.batch_decode(tokens,skip_special_tokens=True)[0]
                torch.cuda.synchronize();elapsed=time.perf_counter()-start
                rec.update(ok=True,hypothesis=text,total_s=elapsed,rtf=elapsed/(len(row['audio'])/16000),**score(row['reference'],text))
            except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),**score(row['reference'],''))
            with (OUT/'file_records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
    (OUT/'DONE-smoke').write_text('Streaming smoke and 3-file per-locale coverage sweep attempted; full qualification pending.\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=2);main(p.parse_args().limit)
