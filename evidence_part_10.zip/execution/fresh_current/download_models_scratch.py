"""Download only pinned runtime assets; avoid duplicate weight formats."""
import os,pathlib,re,json,datetime
os.environ['HF_HOME']='/workspace/hf_cache'
os.environ['HF_HUB_CACHE']='/workspace/hf_cache/hub'
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
from huggingface_hub import snapshot_download
ROOT=pathlib.Path('/workspace/speechbench_20260924')
token=re.search(r'hf_[A-Za-z0-9]+',pathlib.Path('/workspace/.hf_token_env').read_text()).group()
for job in json.loads((ROOT/os.environ.get('JOB_MANIFEST','download_jobs.json')).read_text()):
    rec={**job,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        path=snapshot_download(repo_id=job['repo'],revision=job['revision'],allow_patterns=job['files'],token=token,cache_dir=os.environ.get('MODEL_CACHE','/workspace/hf_cache/hub'),max_workers=2)
        rec.update(status='downloaded',path=path)
    except Exception as e:rec.update(status='failed',error_type=type(e).__name__,error=str(e).replace(token,'[REDACTED]'))
    (ROOT/(job['id']+'_download.json')).write_text(json.dumps(rec,indent=2))
    print(json.dumps({k:rec.get(k) for k in ['id','status','path','error_type']}),flush=True)
