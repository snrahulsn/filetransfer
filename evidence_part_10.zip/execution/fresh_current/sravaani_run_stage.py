"""Pinned SraVaani: full-test file accuracy plus independently paced native streams."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',HF_HOME='/workspace/hf_cache')
import hashlib,io,json,pathlib,queue,threading,time,traceback,datetime
import numpy as np
import pyarrow.parquet as pq
import soundfile as sf
import torch
torch.set_num_threads(4)
from transformers import AutoModel
from metrics import score
from asr_corpus import records as corpus_records

ROOT=pathlib.Path('/workspace/speechbench_20260924')
OUT=ROOT/'A01';OUT.mkdir(exist_ok=True)
PIN='29a15303a55673367134eee9e1d18cb1a2dcaabf'
MODEL=pathlib.Path('/workspace/hf_cache/models--ARTPARK-IISc--SraVaani-0.5-live/snapshots')/PIN
DATA=pathlib.Path(os.environ.get('DATA_ROOT','/workspace/speechbench_20260924/datasets'))

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        while c:=f.read(4*1024*1024):h.update(c)
    return h.hexdigest()

def records():
    for lang in ['hi','bn','mr','ta','te','gu','kn','ml','or']:
        path=DATA/'google--fleurs'/'parquet-data'/f'{lang}_in'/'test-00000-of-00001.parquet'
        if not path.exists():raise FileNotFoundError(path)
        index=0
        for batch in pq.ParquetFile(path).iter_batches(batch_size=8):
            for row in batch.to_pylist():
                audio,sr=sf.read(io.BytesIO(row['audio']['bytes']),dtype='float32')
                if sr!=16000 or audio.ndim!=1:raise ValueError('Unexpected FLEURS format')
                yield dict(locale=lang+'-IN',id=f'fleurs/{lang}_in/test/{index}',index=index,
                           reference=row['transcription'],raw_reference=row['raw_transcription'],
                           dataset_revision='70bb2e84b976b7e960aa89f1c648e09c59f894dd',audio=audio)
                index+=1

def paced(model,audio):
    """Independent producer releases each 20ms frame only after its full capture time."""
    state=model.new_stream(); q=queue.Queue(); cancel=threading.Event()
    torch.cuda.synchronize();t0=time.perf_counter();trace=[];producer_events=[]
    def produce():
        for begin in range(0,len(audio),320):
            if cancel.is_set():break
            end=min(begin+320,len(audio));due=end/16000
            cancel.wait(max(0,t0+due-time.perf_counter()))
            if cancel.is_set():break
            actual=time.perf_counter()-t0
            producer_events.append({'end_sample':end,'due_s':due,'released_s':actual})
            q.put((end,actual,audio[begin:end]))
        q.put(None)
    thread=threading.Thread(target=produce,daemon=True);thread.start()
    old='';max_queue=0
    try:
        while (item:=q.get(timeout=180)) is not None:
            end,released,chunk=item
            max_queue=max(max_queue,q.qsize())
            text=model.stream_audio(state,chunk)
            if text!=old:
                trace.append({'at_s':time.perf_counter()-t0,'audio_seen_s':end/16000,'text':text});old=text
        final=model.finalize(state);torch.cuda.synchronize();finished=time.perf_counter()-t0
    finally:cancel.set();thread.join(5)
    return final,dict(total_s=finished,finalization_lag_s=finished-len(audio)/16000,
                      first_partial_s=trace[0]['at_s'] if trace else None,partial_events=trace,
                      producer_events=producer_events,max_queue_frames=max_queue,
                      max_release_lateness_s=max(x['released_s']-x['due_s'] for x in producer_events))

def main():
    run_id=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    completed=set()
    for p in [OUT/'stream_records.jsonl',OUT/'file_records.jsonl']:
        if p.exists():
            for line in p.read_text().splitlines():
                r=json.loads(line);completed.add((r['id'],r['mode'],r['lookahead_ms']))
    source_hashes={p.name:digest(p) for p in MODEL.iterdir() if p.suffix in ['.py','.pt','.ts','.model','.json']}
    env=dict(run_id=run_id,model='ARTPARK-IISc/SraVaani-0.5-live',revision=PIN,files=source_hashes,
             gpu=torch.cuda.get_device_name(0),torch=torch.__version__,cuda=torch.version.cuda,
             requested_dtype='float32',runner_sha256=digest(__file__),hf_offline=True,network_namespace_isolated=False)
    print('Loading pinned SraVaani',flush=True)
    model=AutoModel.from_pretrained(str(MODEL),trust_remote_code=True,torch_dtype=torch.float32,local_files_only=True).to('cuda').eval()
    model.new_stream()
    env['effective_io_dtype']=str(model._io_dtype)
    (OUT/f'environment-{run_id}.json').write_text(json.dumps(env,indent=2))
    model.set_lookahead_ms(480)
    for _ in range(3):model.transcribe([np.zeros(16000,dtype=np.float32)])
    # Native streaming timing first, to prove correct operation in every locale.
    for row in corpus_records(limit=2) if os.environ.get('ASR_STAGE','all')!='file' else []:
        for lookahead in [0,80,480,1040]:
            if (row['id'],'native_stream_paced_20ms',lookahead) in completed:continue
            model.set_lookahead_ms(lookahead)
            rec={k:v for k,v in row.items() if k!='audio'}
            rec.update(run_id=run_id,mode='native_stream_paced_20ms',lookahead_ms=lookahead,ok=False)
            try:
                hyp,timing=paced(model,row['audio'])
                rec.update(ok=True,hypothesis=hyp,**timing,**score(row['reference'],hyp))
            except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
            with (OUT/'stream_records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            print(json.dumps({k:rec.get(k) for k in ['id','mode','lookahead_ms','ok','wer','error']}),flush=True)
    model.set_lookahead_ms(480)
    for row in corpus_records() if os.environ.get('ASR_STAGE','all')!='stream' else []:
        if (row['id'],'whole_file_chunked_encoder_full_utterance_normalization',480) in completed:continue
        rec={k:v for k,v in row.items() if k!='audio'}
        rec.update(run_id=run_id,mode='whole_file_chunked_encoder_full_utterance_normalization',lookahead_ms=480,ok=False)
        try:
            torch.cuda.synchronize();start=time.perf_counter()
            hyp=model.transcribe([row['audio']])[0]
            torch.cuda.synchronize();elapsed=time.perf_counter()-start
            rec.update(ok=True,hypothesis=hyp,total_s=elapsed,audio_duration_s=len(row['audio'])/16000,
                       rtf=elapsed/(len(row['audio'])/16000),**score(row['reference'],hyp))
        except Exception as e:rec.update(error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
        with (OUT/'file_records.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        if row['index']%50==0:print(json.dumps({k:rec.get(k) for k in ['id','ok','wer','error']}),flush=True)
    (OUT/('DONE-'+os.environ.get('ASR_STAGE','all'))).write_text('Requested stage complete; inspect records for failures. Full latency study pending.\n')

if __name__=='__main__':main()
